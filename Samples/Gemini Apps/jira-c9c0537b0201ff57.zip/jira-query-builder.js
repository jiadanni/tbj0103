/**
 * JIRA Query Builder Module
 * Constructs JQL (JIRA Query Language) queries for ticket searches
 * 
 * @module api/atlassian/jira/jira-query-builder
 */

import { generateLabelVariations } from '../shared/atlassian-config.js';

/**
 * Build JQL query for JIRA ticket search
 * @param {string[]} searchTerms - Search terms extracted from case
 * @param {string|null} projectKey - JIRA project key to filter by
 * @returns {string} JQL query string
 */
export function buildJQLQuery(searchTerms, projectKey = null, isRelaxed = false) {
  if (!searchTerms || searchTerms.length === 0) {
    // Even with no search terms, still filter by project if provided
    let baseJql = 'statusCategory IN ("To Do", "In Progress")';

    // In strict mode (default), restrict to Bugs. In relaxed mode, allow all types.
    if (!isRelaxed) {
      baseJql += ' AND type = Bug';
    }

    baseJql += ' ORDER BY priority DESC, created DESC';

    if (projectKey) {
      baseJql = `project = "${escapeJQLString(projectKey)}" AND ${baseJql}`;
    }
    return baseJql;
  }

  // Build text search part - search in summary, description, comments, and labels
  const textSearches = searchTerms.map(term => {
    // Escape quotes in the term
    const escapedTerm = escapeJQLString(term);

    // For phrases (containing spaces), use exact phrase matching in text fields
    if (term.includes(' ')) {
      return `text ~ "${escapedTerm}"`;
    } else {
      // For single words, search in multiple fields including labels
      // Labels field uses exact matching, so we search both the term and common variations
      const labelVariations = generateLabelVariations(term);
      const labelSearches = labelVariations.map(variation => `labels = "${variation}"`).join(' OR ');

      return `(summary ~ "${escapedTerm}" OR description ~ "${escapedTerm}" OR comment ~ "${escapedTerm}" OR ${labelSearches})`;
    }
  });

  let jql = textSearches.join(' OR ');

  // Add project filter if specified - use exact project match for better filtering
  if (projectKey) {
    jql = `project = "${escapeJQLString(projectKey)}" AND (${jql})`;
  }

  // Add status filter - exclude Done items
  jql = `(${jql}) AND statusCategory IN ("To Do", "In Progress")`;

  // Add issue type filter - focus on Bugs only in strict mode
  if (!isRelaxed) {
    jql += ' AND type = Bug';
  }

  // Exclude accessibility items
  jql += ' AND reporter != "712020:6b388ed8-8951-43c0-8ab4-73f5352c72a8" AND reporter != "Jira LevelAccess Service Account" AND reporter != "557058:f58131cb-b67d-43c7-b30d-6b58d40bd077"';

  // Only check customer facing tickets in strict mode
  if (!isRelaxed) {
    jql += ' AND "Customer Facing[Dropdown]"="Yes"';
  }

  // Order by priority and recency
  jql += ' ORDER BY priority DESC, created DESC';

  return jql;
}

/**
 * Build a simple JQL query with minimal filters
 * @param {string} projectKey - JIRA project key
 * @returns {string} JQL query string
 */
export function buildSimpleJQLQuery(projectKey) {
  if (!projectKey) {
    return 'statusCategory IN ("To Do", "In Progress") AND type = Bug ORDER BY priority DESC, created DESC';
  }
  return `project = "${escapeJQLString(projectKey)}" AND statusCategory IN ("To Do", "In Progress") AND type = Bug ORDER BY priority DESC, created DESC`;
}

/**
 * Escape special characters in JQL query strings.
 * Standard JQL escaping: double-up backslashes first, then escape double quotes.
 * 
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
export function escapeJQLString(text) {
  if (!text) return '';
  return text
    .replace(/\\/g, '\\\\') // Escape backslashes first
    .replace(/"/g, '\\"');  // Then escape double quotes
}
