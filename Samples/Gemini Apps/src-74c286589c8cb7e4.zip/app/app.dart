import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:expense_stalker_mobile/src/app/home_shell.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/session_manager.dart';
import 'package:expense_stalker_mobile/src/widgets/error_boundary.dart';
import 'package:expense_stalker_mobile/src/widgets/lock_screen.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class ExpenseStalkerApp extends StatefulWidget {
  const ExpenseStalkerApp({
    super.key,
    required this.store,
    required this.settings,
  });

  final ExpenseStore store;
  final AppSettingsStore settings;

  @override
  State<ExpenseStalkerApp> createState() => _ExpenseStalkerAppState();
}

class _ExpenseStalkerAppState extends State<ExpenseStalkerApp> with WidgetsBindingObserver {
  late final AuthService _authService;
  late final SessionManager _sessionManager;
  bool _isLocked = false;
  bool _isInitialized = false;
  bool _showPrivacyScreen = false; // Hide content when app is in background

  static const _screenshotChannel = MethodChannel('com.expensestalker/screenshot');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _authService = AuthService();
    _sessionManager = SessionManager(_authService);
    _initializeAuth();

    // Listen for screenshot protection setting changes
    screenshotProtectionNotifier.addListener(_onScreenshotProtectionChanged);
  }

  Future<void> _initializeAuth() async {
    await _authService.initialize();
    if (!mounted) return;

    final isAuthEnabled = await _authService.isAuthEnabled();
    if (!mounted) return;

    // Always set up the lock callback so it works when auth is enabled later
    _sessionManager.startSession(context, onLock: () {
      if (mounted) {
        setState(() => _isLocked = true);
      }
    });

    // Apply initial screenshot protection setting
    final preventScreenshots = await _authService.preventScreenshots();
    if (!mounted) return;

    _setScreenshotProtection(preventScreenshots);

    if (mounted) {
      setState(() {
        _isLocked = isAuthEnabled;
        _isInitialized = true;
      });
    }

    // Listen for settings changes that affect period boundaries
    widget.settings.addListener(_onSettingsChanged);
  }

  void _onScreenshotProtectionChanged(bool enabled) {
    _setScreenshotProtection(enabled);
  }

  Future<void> _setScreenshotProtection(bool enabled) async {
    try {
      await _screenshotChannel.invokeMethod('setSecureFlag', {'enabled': enabled});
    } on PlatformException {
      // Platform doesn't support screenshot protection, ignore
    } on MissingPluginException {
      // Method channel not implemented on this platform, ignore
    }
  }
  
  void _onSettingsChanged() {
    // Invalidate expense store cache when period-related settings change
    widget.store.invalidatePaymentsCache();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      // App going to background - show privacy screen immediately
      _onBackground();
    } else if (state == AppLifecycleState.resumed) {
      // App returning from foreground - check if we need to lock
      _onResume();
    }
  }

  void _onBackground() {
    // Show privacy screen immediately to hide content in app switcher
    setState(() => _showPrivacyScreen = true);
    _sessionManager.enterStandby();
  }

  Future<void> _onResume() async {
    // Check if the delay timeout has expired and we need to lock
    final shouldLock = await _sessionManager.shouldLockOnResume();

    if (shouldLock && mounted) {
      // Delay has expired - trigger the lock which will show the auth challenge
      // _showPrivacyScreen is already true from _onBackground
      _sessionManager.lock();
    } else if (mounted) {
      // Within grace period - hide privacy screen to show content
      setState(() => _showPrivacyScreen = false);
    }
  }

  @override
  void dispose() {
    widget.settings.removeListener(_onSettingsChanged);
    screenshotProtectionNotifier.removeListener(_onScreenshotProtectionChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onUnlock() {
    setState(() {
      _isLocked = false;
      _showPrivacyScreen = false; // Clear privacy screen after successful auth
    });
    // Tell session manager the user has authenticated successfully
    _sessionManager.unlock();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const MaterialApp(
        home: Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return AppSettingsScope(
      store: widget.settings,
      child: ExpenseStoreScope(
        store: widget.store,
        child: AnimatedBuilder(
          animation: widget.settings,
          builder: (context, _) {
            final preset = widget.settings.appThemePreset;
            final fontFamily = widget.settings.fontFamily;
            final lightTheme = _buildTheme(preset, Brightness.light, fontFamily);
            final darkTheme = _buildTheme(preset, Brightness.dark, fontFamily);
            return MaterialApp(
                title: 'Expense Stalker',
                builder: (context, child) {
                  final mediaQuery = MediaQuery.of(context);
                  final textScale =
                      mediaQuery.textScaleFactor * widget.settings.textScaleFactor;
                  return MediaQuery(
                    data: mediaQuery.copyWith(textScaler: TextScaler.linear(textScale)),
                    child: child ?? const SizedBox.shrink(),
                  );
                },
                localizationsDelegates: const [
                  AppLocalizations.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],
                supportedLocales: const [
                  Locale('en'),
                ],
                themeMode: widget.settings.themeMode,
                theme: lightTheme,
                darkTheme: darkTheme,
                home: _isLocked
                    ? LockScreen(
                        authService: _authService,
                        onUnlock: _onUnlock,
                      )
                    : _showPrivacyScreen
                        ? const _PrivacyScreen()
                        : const ErrorBoundary(
                            child: HomeShell(),
                          ),
              );
          },
        ),
      ),
    );
  }

  /// Builds a full ThemeData based on the selected AppThemePreset.
  /// Creates a cohesive theme where the palette influences backgrounds,
  /// surfaces, and accents throughout the entire app.
  ThemeData _buildTheme(AppThemePreset preset, Brightness brightness, String? fontFamily) {
    final isDark = brightness == Brightness.dark;
    final palette = ThemeSettings.getPalette(preset);

    if (preset == AppThemePreset.monochrome) {
      // Grayscale colors for monochrome theme - uses palette colors
      final ColorScheme scheme;
      if (isDark) {
        scheme = ColorScheme.dark(
          primary: const Color(0xFF9E9E9E),       // Gray 500
          onPrimary: Colors.black,
          primaryContainer: const Color(0xFF424242), // Gray 800
          onPrimaryContainer: const Color(0xFFE0E0E0),
          secondary: const Color(0xFF757575),     // Gray 600
          onSecondary: Colors.white,
          secondaryContainer: const Color(0xFF616161),
          onSecondaryContainer: const Color(0xFFEEEEEE),
          tertiary: const Color(0xFFBDBDBD),
          surface: palette.surfaceDark,
          onSurface: const Color(0xFFE8E8E8),
          surfaceContainerHighest: palette.surfaceContainerDark,
          surfaceContainerHigh: palette.surfaceContainerDark,
          surfaceContainer: palette.surfaceDark,
          surfaceContainerLow: palette.backgroundDark,
          surfaceContainerLowest: palette.backgroundDark,
          outline: const Color(0xFF616161),
          outlineVariant: const Color(0xFF424242),
          shadow: Colors.black,
        );
      } else {
        scheme = ColorScheme.light(
          primary: const Color(0xFF424242),       // Gray 800
          onPrimary: Colors.white,
          primaryContainer: const Color(0xFFE0E0E0), // Gray 300
          onPrimaryContainer: const Color(0xFF212121),
          secondary: const Color(0xFF757575),     // Gray 600
          onSecondary: Colors.white,
          secondaryContainer: const Color(0xFFBDBDBD),
          onSecondaryContainer: const Color(0xFF212121),
          tertiary: const Color(0xFF616161),
          surface: palette.surfaceLight,
          onSurface: const Color(0xFF212121),
          surfaceContainerHighest: palette.surfaceContainerLight,
          surfaceContainerHigh: palette.surfaceContainerLight,
          surfaceContainer: palette.surfaceLight,
          surfaceContainerLow: palette.backgroundLight,
          surfaceContainerLowest: palette.backgroundLight,
          outline: const Color(0xFF9E9E9E),
          outlineVariant: const Color(0xFFE0E0E0),
          shadow: const Color(0x33000000),        // Black with 20% opacity
        );
      }
      return ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        fontFamily: fontFamily,
        brightness: brightness,
        scaffoldBackgroundColor: palette.background(brightness),
      );
    }

    // For non-monochrome presets, use fromSeed and override with palette colors
    final seedColor = palette.primary;
    
    // Generate the base scheme from the seed
    var scheme = ColorScheme.fromSeed(
      seedColor: seedColor,
      brightness: brightness,
    );

    // Override with the palette-defined surface and background colors
    // This creates a cohesive theme where the palette defines the overall look
    scheme = scheme.copyWith(
      surface: palette.surface(brightness),
      surfaceContainerHighest: palette.surfaceContainer(brightness),
      surfaceContainerHigh: palette.surfaceContainer(brightness),
      surfaceContainer: palette.surface(brightness),
      surfaceContainerLow: palette.background(brightness),
      surfaceContainerLowest: palette.background(brightness),
      // Use a subtle surface tint for elevation differentiation
      surfaceTint: scheme.primary.withValues(alpha: isDark ? 0.08 : 0.05),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: fontFamily,
      scaffoldBackgroundColor: palette.background(brightness),
      dividerTheme: DividerThemeData(
        color: isDark ? Colors.white.withValues(alpha: 0.1) : Colors.black.withValues(alpha: 0.1),
      ),
      // Use theme-aware surface tints for elevated components
      appBarTheme: AppBarTheme(
        surfaceTintColor: scheme.surfaceTint,
        backgroundColor: palette.surface(brightness),
      ),
      cardTheme: CardThemeData(
        surfaceTintColor: scheme.surfaceTint,
        color: palette.surface(brightness),
      ),
      navigationBarTheme: NavigationBarThemeData(
        surfaceTintColor: scheme.surfaceTint,
        indicatorColor: scheme.secondaryContainer,
        backgroundColor: palette.surface(brightness),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: palette.surface(brightness),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: palette.surface(brightness),
      ),
      // Style chips to match the theme
      chipTheme: ChipThemeData(
        backgroundColor: palette.surfaceContainer(brightness),
        selectedColor: scheme.secondaryContainer,
        labelStyle: TextStyle(color: scheme.onSurface),
        secondaryLabelStyle: TextStyle(color: scheme.onSurfaceVariant),
        side: BorderSide(color: scheme.outlineVariant),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}

/// Privacy screen shown when app goes to background to hide sensitive data.
/// Intentionally minimal - just shows the app icon, no text to confuse users.
class _PrivacyScreen extends StatelessWidget {
  const _PrivacyScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        child: Center(
          child: Icon(
            Icons.account_balance_wallet_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
          ),
        ),
      ),
    );
  }
}
