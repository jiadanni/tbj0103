class AppConstants {
  // Animation Durations
  static const Duration animationFast = Duration(milliseconds: 150);
  static const Duration animationNormal = Duration(milliseconds: 200);
  static const Duration animationSlow = Duration(milliseconds: 300);
  static const Duration animationPageTransition = Duration(milliseconds: 400);

  // SnackBar Durations
  static const Duration snackBarShort = Duration(seconds: 2);
  static const Duration snackBarNormal = Duration(seconds: 3);
  static const Duration snackBarLong = Duration(seconds: 5);

  // Layout limits
  static const int maxLabelLength = 100;
  static const int maxNotesLength = 500;
  static const int maxAmountLength = 9;
  static const int maxBalanceLength = 10;

  // Debounce
  static const Duration saveDebounceDuration = Duration(seconds: 2);

  // Layout Dimensions
  static const double paddingXSmall = 4.0;
  static const double paddingSmall = 8.0;
  static const double paddingNormal = 12.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;
  
  static const double radiusXSmall = 4.0;
  static const double radiusSmall = 6.0;
  static const double radiusMedium = 8.0;
  static const double radiusButton = 10.0;
  static const double radiusLarge = 12.0;
  static const double radiusXLarge = 16.0;
  static const double radiusIconBox = 14.0;
  static const double radiusSheetTop = 20.0;
  static const double radiusDialog = 24.0;

  // Interaction Thresholds
  static const double scrollThresholdNormal = 200.0;
  static const double pinchScaleThreshold = 0.92;
  static const double opacityPast = 0.62;

  // Specific Layout Heights/Sizes
  static const double appBarExtendedHeight = 96.0;
  static const double dialogIconSize = 44.0;
  static const int pageSizeDefault = 50;
  static const double buttonHeightPrimary = 56.0;
  static const double buttonHeightSecondary = 48.0;
}
