import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/widgets/debt_payment_calculator.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'upsert_planner_item_style.dart';

const String _kNewMoneyPotId = 'new_money_pot';

class DebtFieldsSection extends StatelessWidget {
  const DebtFieldsSection({
    super.key,
    required this.remainingBalanceController,
    required this.balanceCurrency,
    required this.exchangeRateController,
    required this.selectedMoneyPotId,
    required this.amountController,
    required this.dayController,
    required this.frequency,
    required this.startDate,
    required this.isEditMode,
    required this.isPaidOff,
    required this.onBalanceCurrencyChanged,
    required this.onMoneyPotChanged,
    required this.onIsPaidOffChanged,
    required this.buildCompactCheckbox,
  });

  final TextEditingController remainingBalanceController;
  final AppCurrency? balanceCurrency;
  final TextEditingController exchangeRateController;
  final String? selectedMoneyPotId;
  final TextEditingController amountController;
  final TextEditingController dayController;
  final RecurrenceFrequency? frequency;
  final DateTime startDate;
  final bool isEditMode;
  final bool isPaidOff;
  final ValueChanged<AppCurrency?> onBalanceCurrencyChanged;
  final ValueChanged<String?> onMoneyPotChanged;
  final ValueChanged<bool> onIsPaidOffChanged;
  final Widget Function({
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) buildCompactCheckbox;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final settings = AppSettingsScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        UpsertPlannerItemStyle.labeledField(
          context: context,
          label: l10n.remainingBalanceLabel,
          child: TextField(
            controller: remainingBalanceController,
            style: TextStyle(color: textPrimary, fontSize: 14),
            decoration: UpsertPlannerItemStyle.compactInput(
              context,
              '0.00',
              floatingLabel: false,
            ),
            keyboardType: const TextInputType.numberWithOptions(
              signed: false,
              decimal: true,
            ),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
              LengthLimitingTextInputFormatter(AppConstants.maxBalanceLength),
            ],
            textInputAction: TextInputAction.next,
          ),
        ),
        const SizedBox(height: 12),

        // Balance Currency dropdown
        Row(
          children: [
            Expanded(
              child: DropdownButtonFormField<AppCurrency?>(
                value: balanceCurrency,
                decoration: UpsertPlannerItemStyle.compactInput(context, 'Balance Currency'),
                items: [
                  DropdownMenuItem<AppCurrency?>(
                    value: null,
                    child: Text('Same as app (${currencySymbol(settings.currency)})'),
                  ),
                  ...AppCurrency.values.map((c) => DropdownMenuItem<AppCurrency?>(
                        value: c,
                        child: Text(currencyLabel(c)),
                      )),
                ],
                onChanged: onBalanceCurrencyChanged,
                style: TextStyle(color: textPrimary, fontSize: 13),
                dropdownColor: surface,
              ),
            ),
            if (balanceCurrency != null) ...[
              const SizedBox(width: 8),
              SizedBox(
                width: 80,
                child: TextField(
                  controller: exchangeRateController,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  decoration: UpsertPlannerItemStyle.compactInput(
                    context,
                    'Rate',
                    floatingLabel: false,
                    hintText: '1.08',
                  ),
                  keyboardType: const TextInputType.numberWithOptions(
                    signed: false,
                    decimal: true,
                  ),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,4}')),
                  ],
                  textInputAction: TextInputAction.next,
                ),
              ),
            ],
          ],
        ),
        if (balanceCurrency != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              '1 ${currencySymbol(settings.currency)} = ${exchangeRateController.text.isEmpty ? "?" : exchangeRateController.text} ${currencySymbol(balanceCurrency!)}',
              style: TextStyle(color: textSecondary, fontSize: 11),
            ),
          ),

        // Track in Money Pot Toggle
        SwitchListTile(
          title: Text(
            'Track in Money Pots',
            style: TextStyle(fontSize: 13, color: textPrimary),
          ),
          value: selectedMoneyPotId != null,
          onChanged: (bool value) {
            if (value) {
              onMoneyPotChanged(_kNewMoneyPotId);
            } else {
              onMoneyPotChanged(null);
            }
          },
          contentPadding: EdgeInsets.zero,
          visualDensity: VisualDensity.compact,
        ),

        if (selectedMoneyPotId != null) ...[
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: selectedMoneyPotId,
            decoration: UpsertPlannerItemStyle.compactInput(context, 'Select Money Pot'),
            items: [
              const DropdownMenuItem<String>(
                value: _kNewMoneyPotId,
                child: Text('Create New Pot'),
              ),
              ...settings.moneyPots.map((pot) => DropdownMenuItem<String>(
                    value: pot.id,
                    child: Text(pot.name),
                  )),
            ],
            onChanged: (value) {
              onMoneyPotChanged(value);
              // Handle relative internal logic in parent if needed, 
              // or handle balance sync via callbacks.
            },
            style: TextStyle(color: textPrimary, fontSize: 13),
            dropdownColor: surface,
          ),
        ],
        const SizedBox(height: 6),

        DebtPaymentCalculator(
          remainingBalanceController: remainingBalanceController,
          amountController: amountController,
          dayOfMonthController: dayController,
          frequency: frequency,
          startDate: startDate,
          exchangeRate: double.tryParse(exchangeRateController.text),
          balanceCurrency: balanceCurrency,
          appCurrency: settings.currency,
        ),
        if (isEditMode) ...[
          const SizedBox(height: 4),
          buildCompactCheckbox(
            value: isPaidOff,
            onChanged: (v) => onIsPaidOffChanged(v ?? false),
            label: l10n.markAsPaidOff,
            subtitle: l10n.paidOffHelperText,
          ),
        ],
      ],
    );
  }
}
