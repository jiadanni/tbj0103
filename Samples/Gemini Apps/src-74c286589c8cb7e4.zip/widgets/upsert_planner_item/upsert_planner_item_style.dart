import 'package:flutter/material.dart';

/// Common styling and helper widgets for UpsertPlannerItem.
class UpsertPlannerItemStyle {
  const UpsertPlannerItemStyle._();

  static InputDecoration compactInput(
    BuildContext context,
    String label, {
    String? helperText,
    String? errorText,
    String? hintText,
    Widget? suffixIcon,
    TextStyle? helperStyle,
    Widget? prefix,
    bool floatingLabel = true,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant;

    return InputDecoration(
      labelText: floatingLabel ? label : null,
      hintText: floatingLabel ? hintText : (hintText ?? label),
      labelStyle: TextStyle(color: textSecondary, fontSize: 12),
      hintStyle: TextStyle(
          color: textSecondary.withValues(alpha: 0.6), fontSize: 13),
      helperText: helperText,
      helperStyle: helperStyle ?? TextStyle(color: textSecondary, fontSize: 10),
      helperMaxLines: 1,
      errorText: errorText,
      errorStyle: const TextStyle(fontSize: 10),
      suffixIcon: suffixIcon,
      prefix: prefix,
      filled: true,
      fillColor: surface,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: colorScheme.error),
      ),
      floatingLabelBehavior: floatingLabel
          ? FloatingLabelBehavior.auto
          : FloatingLabelBehavior.never,
      counterText: '',
    );
  }

  static Widget labeledField({
    required BuildContext context,
    required String label,
    required Widget child,
    bool showLabel = true,
  }) {
    if (!showLabel) return child;
    final textSecondary = Theme.of(context).colorScheme.onSurfaceVariant;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 4),
          child: Text(
            label,
            style: TextStyle(
              color: textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        child,
      ],
    );
  }

  static Widget buildCompactCheckbox({
    required BuildContext context,
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;

    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: Checkbox(
                value: value,
                onChanged: onChanged,
                visualDensity: VisualDensity.compact,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(color: textPrimary, fontSize: 13),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(color: textSecondary, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
