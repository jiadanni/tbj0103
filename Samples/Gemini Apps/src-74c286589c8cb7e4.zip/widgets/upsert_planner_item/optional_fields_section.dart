import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/display_helpers.dart';
import 'upsert_planner_item_style.dart';

class OptionalFieldsSection extends StatefulWidget {
  const OptionalFieldsSection({
    super.key,
    required this.categoryController,
    required this.categoryFocusNode,
    required this.categoryLayerLink,
    required this.selectedCategory,
    required this.companyController,
    required this.isSalary,
    required this.isQuickAdd,
    required this.notesController,
    required this.isIncomeMode,
    required this.type,
    required this.onCategorySelected,
    required this.onIsSalaryChanged,
    required this.onIsQuickAddChanged,
    required this.buildCompactCheckbox,
  });

  final TextEditingController categoryController;
  final FocusNode categoryFocusNode;
  final LayerLink categoryLayerLink;
  final String? selectedCategory;
  final TextEditingController companyController;
  final bool isSalary;
  final bool isQuickAdd;
  final TextEditingController notesController;
  final bool isIncomeMode;
  final PaymentType type;
  final ValueChanged<String?> onCategorySelected;
  final ValueChanged<bool> onIsSalaryChanged;
  final ValueChanged<bool> onIsQuickAddChanged;
  
  /// Callback to build the compact checkbox which depends on parent theme state
  final Widget Function({
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) buildCompactCheckbox;

  @override
  State<OptionalFieldsSection> createState() => _OptionalFieldsSectionState();
}

class _OptionalFieldsSectionState extends State<OptionalFieldsSection> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;
    final surfaceVariant = colorScheme.surfaceContainerLow;
    
    final settings = AppSettingsScope.of(context);
    final store = ExpenseStoreScope.read(context);

    return Container(
      decoration: BoxDecoration(
        color: surfaceVariant,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          // Header tap area
          InkWell(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.tune_outlined, size: 16, color: textSecondary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      l10n.moreOptions,
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.5 : 0,
                    duration: AppConstants.animationNormal,
                    child: Icon(Icons.keyboard_arrow_down, size: 18, color: textSecondary),
                  ),
                ],
              ),
            ),
          ),
          // Expandable content
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category & Company row with labels
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: l10n.category,
                          child: RawAutocomplete<String>(
                            textEditingController: widget.categoryController,
                            focusNode: widget.categoryFocusNode,
                            optionsBuilder: (TextEditingValue textEditingValue) {
                              final suggestions = getCategorySuggestions(
                                isIncome: widget.isIncomeMode,
                                mode: settings.categoryPresetMode,
                                userCategories: store.getUserCategories(isIncome: widget.isIncomeMode),
                              );

                              if (textEditingValue.text.isEmpty) {
                                return suggestions;
                              }
                              return suggestions.where((option) {
                                return option.toLowerCase().contains(textEditingValue.text.toLowerCase());
                              });
                            },
                            onSelected: (String selection) {
                              widget.onCategorySelected(selection);
                            },
                            fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
                              return CompositedTransformTarget(
                                link: widget.categoryLayerLink,
                                child: TextField(
                                  controller: controller,
                                  focusNode: focusNode,
                                  style: TextStyle(color: textPrimary, fontSize: 14),
                                  decoration: UpsertPlannerItemStyle.compactInput(context, 'Select or type', floatingLabel: false),
                                  onChanged: (value) {
                                    widget.onCategorySelected(value.trim().isEmpty ? null : value.trim());
                                  },
                                  onSubmitted: (_) => onFieldSubmitted(),
                                ),
                              );
                            },
                            optionsViewBuilder: (context, onSelected, options) {
                              return CompositedTransformFollower(
                                link: widget.categoryLayerLink,
                                showWhenUnlinked: false,
                                offset: const Offset(0, 40),
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Material(
                                    elevation: 8.0,
                                    borderRadius: BorderRadius.circular(8),
                                    color: surface,
                                    child: Container(
                                      width: 180,
                                      constraints: const BoxConstraints(maxHeight: 180),
                                      child: ListView.builder(
                                        padding: const EdgeInsets.symmetric(vertical: 4),
                                        shrinkWrap: true,
                                        itemCount: options.length,
                                        itemBuilder: (BuildContext context, int index) {
                                          final option = options.elementAt(index);
                                          return InkWell(
                                            onTap: () => onSelected(option),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                              child: Text(
                                                option,
                                                style: TextStyle(color: textPrimary, fontSize: 13),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: 'Company',
                          child: TextField(
                            controller: widget.companyController,
                            style: TextStyle(color: textPrimary, fontSize: 14),
                            decoration: UpsertPlannerItemStyle.compactInput(context, 'Enter company', floatingLabel: false),
                          ),
                        ),
                      ),
                    ],
                  ),
                  // Salary toggle - only for recurring income
                  if (widget.isIncomeMode && widget.type == PaymentType.recurringIncome) ...[
                    const SizedBox(height: 8),
                    widget.buildCompactCheckbox(
                      value: widget.isSalary,
                      onChanged: (v) => widget.onIsSalaryChanged(v ?? false),
                      label: l10n.primarySalary,
                      subtitle: l10n.primarySalaryHint,
                    ),
                  ],
                  const SizedBox(height: 8),
                  widget.buildCompactCheckbox(
                    value: widget.isQuickAdd,
                    onChanged: (v) => widget.onIsQuickAddChanged(v ?? false),
                    label: 'Quick Add Capability',
                    subtitle: 'Enable quick adding from planner screen',
                  ),
                  const SizedBox(height: 12),
                  // Notes field with label
                  UpsertPlannerItemStyle.labeledField(
                    context: context,
                    label: 'Notes',
                    child: TextField(
                      controller: widget.notesController,
                      style: TextStyle(color: textPrimary, fontSize: 14),
                      decoration: UpsertPlannerItemStyle.compactInput(context, 'Add notes (optional)', floatingLabel: false),
                      maxLength: AppConstants.maxNotesLength,
                      maxLines: 2,
                      textInputAction: TextInputAction.done,
                    ),
                  ),
                ],
              ),
            ),
            crossFadeState: _isExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: AppConstants.animationNormal,
          ),
        ],
      ),
    );
  }
}
