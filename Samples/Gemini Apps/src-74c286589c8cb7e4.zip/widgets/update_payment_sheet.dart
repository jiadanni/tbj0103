import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Bottom sheet for editing an existing payment entry (the "Actual" record).
/// 
/// Allows modifying the actual amount, date, and notes.
/// Returns the updated [PaymentEntry] on save, or null if cancelled.
class UpdatePaymentSheet extends StatefulWidget {
  const UpdatePaymentSheet({
    super.key,
    required this.payment,
    this.title,
  });

  final PaymentEntry payment;
  final String? title;

  @override
  State<UpdatePaymentSheet> createState() => _UpdatePaymentSheetState();
}

class _UpdatePaymentSheetState extends State<UpdatePaymentSheet> {
  late final TextEditingController _amountController;
  late final TextEditingController _notesController;
  late DateTime _date;
  String? _selectedMoneyPotId;

  @override
  void initState() {
    super.initState();
    final payment = widget.payment;
    // Store absolute value
    _amountController = TextEditingController(
      text: (payment.amountCents.abs() / 100).toStringAsFixed(2),
    );
    _notesController = TextEditingController(text: payment.notes ?? '');
    _date = payment.date;
    _selectedMoneyPotId = payment.moneyPotId;
  }

  @override
  void dispose() {
    _amountController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context)!;
    final settings = AppSettingsScope.read(context);
    final colorScheme = Theme.of(context).colorScheme;

    final backgroundTop = isDark ? const Color(0xFF1A1D27) : const Color(0xFFF8F9FC);
    final backgroundBottom = isDark ? const Color(0xFF0F1118) : const Color(0xFFF0F2F8);
    final surface = isDark ? const Color(0xFF252A3A) : Colors.white;
    final border = isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06);
    final textPrimary = isDark ? Colors.white : const Color(0xFF1A1D27);
    final textSecondary = isDark ? Colors.white60 : const Color(0xFF6B7280);

    // Determines if income based on payment type (not user toggleable here)
    final isIncome = widget.payment.type.isIncomeType;
    final accentColor = isIncome ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    InputDecoration compactInput(String label, {String? hintText}) {
      return InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: textSecondary, fontSize: 12),
        filled: true,
        fillColor: surface,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundTop, backgroundBottom],
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppConstants.radiusSheetTop)),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 6, 16, 16 + bottomInset),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Text(
                  widget.title ?? 'Edit Payment Details',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: textPrimary,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),

                // Read-only Label
                Text(
                  widget.payment.label,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: textPrimary,
                  ),
                  textAlign: TextAlign.center,
                ),
                if (widget.payment.scheduledAmountCents != null) ...[
                   const SizedBox(height: 4),
                   Text(
                     'Scheduled: ${formatMoneyFromCents(widget.payment.scheduledAmountCents!, settings.currency)}',
                     style: TextStyle(color: textSecondary, fontSize: 12),
                     textAlign: TextAlign.center,
                   ),
                ],
                const SizedBox(height: 20),

                // Amount & Date Row
                Row(
                  children: [
                     // Amount Field
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _amountController,
                        style: TextStyle(color: textPrimary, fontSize: 16, fontWeight: FontWeight.w600),
                        decoration: compactInput('Actual Amount').copyWith(
                          prefixIcon: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              isIncome ? '+' : '−',
                              style: TextStyle(
                                fontSize: 16, 
                                fontWeight: FontWeight.bold,
                                color: accentColor,
                              ),
                            ),
                          ),
                          prefixIconConstraints: const BoxConstraints(minWidth: 40, minHeight: 0),
                        ),
                        keyboardType: TextInputType.numberWithOptions(
                          signed: false,
                          decimal: settings.showCents,
                        ),
                        inputFormatters: [
                          if (settings.showCents)
                            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                          else
                            FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(AppConstants.maxAmountLength),
                        ],
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Date Picker
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: _pickDate,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: border),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Date', style: TextStyle(color: textSecondary, fontSize: 10)),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Icon(Icons.calendar_today, size: 14, color: textPrimary),
                                  const SizedBox(width: 6),
                                  Text(
                                    DateFormat.MMMd().format(_date),
                                    style: TextStyle(color: textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Notes
                TextField(
                  controller: _notesController,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  decoration: compactInput('Notes').copyWith(
                    hintText: 'Add notes for this payment...',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 24),

                // Track in Money Pot Checkbox
                if (!widget.payment.type.isIncomeType) ...[
                   const SizedBox(height: 12),
                   DropdownButtonFormField<String>(
                     value: _selectedMoneyPotId,
                     decoration: compactInput('Track in Money Pot'),
                     items: [
                       const DropdownMenuItem<String>(
                         value: null,
                         child: Text('None'),
                       ),
                       ...settings.moneyPots.map((pot) => DropdownMenuItem<String>(
                         value: pot.id,
                         child: Text(pot.name),
                       )),
                     ],
                     onChanged: (value) => setState(() => _selectedMoneyPotId = value),
                     style: TextStyle(color: textPrimary, fontSize: 13),
                     dropdownColor: surface,
                   ),
                ],

                const SizedBox(height: 24),

                // Save Button
                FilledButton(
                  onPressed: _handleSave,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppConstants.radiusButton),
                    ),
                  ),
                  child: Text(
                    l10n.save,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _date = picked);
    }
  }

  void _handleSave() {
    final rawAmountCents = tryParseMoneyToCents(_amountController.text);
    if (rawAmountCents == null) {
      return; // Invalid amount
    }
    
    // Apply rounding
    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    // Maintain sign based on PaymentType
    final signedAmountCents = widget.payment.type.isIncomeType 
        ? finalAmountCents 
        : -finalAmountCents;

    final updated = widget.payment.copyWith(
      amountCents: signedAmountCents,
      date: _date,
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      moneyPotId: _selectedMoneyPotId,
    );

    Navigator.pop(context, updated);
  }
}
