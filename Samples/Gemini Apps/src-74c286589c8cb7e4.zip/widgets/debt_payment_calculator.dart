import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';

/// Displays the estimated payoff date for a debt payment plan.
///
/// Shows a card with:
/// - The calculated final payment date
/// - Number of remaining payments
///
/// Only renders if all required inputs are valid (remaining balance, amount, frequency).
class DebtPaymentCalculator extends StatelessWidget {
  const DebtPaymentCalculator({
    super.key,
    required this.remainingBalanceController,
    required this.amountController,
    required this.dayOfMonthController,
    required this.frequency,
    required this.startDate,
    this.exchangeRate,
    this.balanceCurrency,
    this.appCurrency,
  });

  final TextEditingController remainingBalanceController;
  final TextEditingController amountController;
  final TextEditingController dayOfMonthController;
  final RecurrenceFrequency? frequency;
  final DateTime startDate;
  final double? exchangeRate;
  final AppCurrency? balanceCurrency;
  final AppCurrency? appCurrency;

  @override
  Widget build(BuildContext context) {
    final remainingBalanceCents = tryParseMoneyToCents(remainingBalanceController.text);
    final amountCents = tryParseMoneyToCents(amountController.text);

    if (remainingBalanceCents == null || remainingBalanceCents <= 0 ||
        amountCents == null || amountCents <= 0 || frequency == null) {
      return const SizedBox.shrink();
    }

    // Calculate effective payment amount considering exchange rate
    final effectivePaymentCents = exchangeRate != null && exchangeRate! > 0
        ? (amountCents * exchangeRate!).round()
        : amountCents;

    // Create a temporary item to calculate the date
    final tempItem = PlannerItem(
      id: 'temp',
      label: 'temp',
      amountCents: amountCents,
      dayOfMonth: int.tryParse(dayOfMonthController.text) ?? 1,
      type: PaymentType.debt,
      startDate: startDate,
      frequency: frequency,
      remainingBalanceCents: remainingBalanceCents,
      exchangeRate: exchangeRate,
    );

    final finalDate = tempItem.calculateFinalPaymentDate();
    if (finalDate == null) return const SizedBox.shrink();

    final paymentsNeeded = (remainingBalanceCents / effectivePaymentCents).ceil();
    final formattedDate = '${finalDate.year}-${finalDate.month.toString().padLeft(2, '0')}-${finalDate.day.toString().padLeft(2, '0')}';

    final hasExchangeRate = exchangeRate != null && exchangeRate! > 0 && balanceCurrency != null;

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  size: 16,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Estimated payoff date',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              formattedDate,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$paymentsNeeded ${paymentsNeeded == 1 ? 'payment' : 'payments'} remaining',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            if (hasExchangeRate) ...[
              const SizedBox(height: 4),
              Text(
                'Each payment = ${currencySymbol(balanceCurrency!)}${(effectivePaymentCents / 100).toStringAsFixed(2)} toward balance',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
