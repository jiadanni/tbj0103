import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class SummaryCards extends StatelessWidget {
  const SummaryCards({
    super.key,
    required this.plannedCents,
    required this.paidCents,
    this.currency = AppCurrency.eur,
  });

  final int plannedCents;
  final int paidCents;
  final AppCurrency currency;

  @override
  Widget build(BuildContext context) {
    final deltaCents = plannedCents - paidCents;

    return Row(
      children: [
        Expanded(
            child: _SummaryCard(
            label: AppLocalizations.of(context)!.plannedLabel,
            cents: plannedCents,
            currency: currency,
            color: plannedCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
            child: _SummaryCard(
            label: AppLocalizations.of(context)!.paidLabel,
            cents: paidCents,
            currency: currency,
            color: paidCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
            child: _SummaryCard(
            label: AppLocalizations.of(context)!.deltaLabel,
            cents: deltaCents,
            currency: currency,
            color: deltaCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.cents,
    required this.currency,
    required this.color,
  });

  final String label;
  final int cents;
  final AppCurrency currency;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              formatMoneyFromCents(cents, currency),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: color,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
