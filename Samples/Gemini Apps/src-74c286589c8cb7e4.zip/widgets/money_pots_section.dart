import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_money_pot_sheet.dart';

class MoneyPotsSection extends StatelessWidget {
  const MoneyPotsSection({
    super.key,
    required this.settings,
    this.month,
    this.items = const [],
  });

  final AppSettingsStore settings;
  
  /// The month being displayed. If provided, debt balances will be projected
  /// based on assumed payments between the current month and this month.
  final DateTime? month;
  
  /// List of planner items to look up linked debt items for balance projection.
  final List<PlannerItem> items;

  @override
  Widget build(BuildContext context) {
    final pots = settings.moneyPots;
    final creditColor = settings.creditColor;
    final debitColor = settings.debitColor;

    return Column(
      children: [
        Divider(height: 1, color: Theme.of(context).dividerColor.withValues(alpha: 0.5)),
        
        // Header Row
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppConstants.paddingNormal,
            vertical: AppConstants.paddingSmall,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Long-press to edit section label
              GestureDetector(
                onLongPress: () => _editLabel(context),
                child: Tooltip(
                  message: 'Long-press to rename',
                  child: Text(
                    settings.moneyPotsSettings.sectionLabel, 
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                       color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add_circle_outline, size: 20),
                onPressed: () => _editPot(context, null),
                visualDensity: VisualDensity.compact,
                splashRadius: 20,
                tooltip: 'Add Money Pot',
              ),
            ],
          ),
        ),
        
        if (pots.isEmpty)
           Padding(
             padding: const EdgeInsets.only(
               bottom: AppConstants.paddingSmall,
               left: AppConstants.paddingNormal,
               right: AppConstants.paddingNormal,
             ),
             child: Text(
               'No pots configured',
               style: Theme.of(context).textTheme.bodySmall?.copyWith(
                 color: Theme.of(context).colorScheme.outline,
                 fontStyle: FontStyle.italic,
               ),
             ),
           )
        else if (pots.length >= 2)
          // Grid layout for 2+ pots to use all horizontal space
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppConstants.paddingNormal,
              vertical: AppConstants.paddingSmall,
            ),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 2.5,
                crossAxisSpacing: AppConstants.paddingSmall,
                mainAxisSpacing: AppConstants.paddingSmall,
              ),
              itemCount: pots.length,
              itemBuilder: (context, index) => _buildPotCard(context, pots[index], creditColor, debitColor),
            ),
          )
        else
          // Single pot uses full width tile
          ...pots.map((pot) => _buildPotTile(context, pot, creditColor, debitColor)),
          
      ],
    );
  }

  /// Calculates the projected balance for a debt pot based on assumed payments.
  /// 
  /// For future months, the balance is reduced by (monthsAway * paymentAmount).
  int _calculateProjectedBalance(MoneyPot pot) {
    // Only project balances for debt pots
    if (pot.type != MoneyPotType.debt) {
      return pot.amountCents;
    }
    
    // If no month context, return current balance
    if (month == null) {
      return pot.amountCents;
    }
    
    // Find linked planner item to get the monthly payment amount
    PlannerItem? linkedItem;
    for (final item in items) {
      if (item.moneyPotId == pot.id) {
        linkedItem = item;
        break;
      }
    }
    
    // No linked item or no payment amount
    if (linkedItem == null || linkedItem.amountCents >= 0) {
      return pot.amountCents;
    }
    
    // Calculate months from now to the displayed month
    final now = DateTime.now();
    final currentMonth = monthOnly(now);
    final displayMonth = monthOnly(month!);
    
    // If current or past month, show actual balance
    if (!displayMonth.isAfter(currentMonth)) {
      return pot.amountCents;
    }
    
    // Calculate months away
    final monthsAway = (displayMonth.year - currentMonth.year) * 12 + 
                       (displayMonth.month - currentMonth.month);
    
    // Payment amount per month (as positive value)
    // Apply exchange rate if payment currency differs from pot currency (represented by linkedItem.exchangeRate)
    var paymentPerMonth = linkedItem.amountCents.abs();
    if (linkedItem.exchangeRate != null && linkedItem.exchangeRate! > 0) {
      paymentPerMonth = (paymentPerMonth * linkedItem.exchangeRate!).round();
    }
    
    // Project the balance (can't go below zero)
    final projectedBalance = pot.amountCents - (monthsAway * paymentPerMonth);
    return projectedBalance > 0 ? projectedBalance : 0;
  }

  Widget _buildPotCard(BuildContext context, MoneyPot pot, Color creditColor, Color debitColor) {
    final displayColor = pot.type == MoneyPotType.savings ? creditColor : debitColor;
    final projectedAmount = _calculateProjectedBalance(pot);
    final isProjected = projectedAmount != pot.amountCents;

    return InkWell(
      onTap: () => _editPot(context, pot),
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.all(AppConstants.paddingSmall),
        decoration: BoxDecoration(
          border: Border.all(
            color: Theme.of(context).dividerColor.withValues(alpha: 0.3),
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              pot.name,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Row(
              children: [
                if (isProjected)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Icon(
                      Icons.trending_down,
                      size: 12,
                      color: displayColor.withValues(alpha: 0.7),
                    ),
                  ),
                Expanded(
                  child: Text(
                    formatMoneyFromCents(
                      projectedAmount,
                      pot.currency ?? settings.currencySettings.currency,
                      showCents: settings.showCents,
                    ),
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: displayColor,
                      fontWeight: FontWeight.w600,
                      fontFeatures: const [FontFeature.tabularFigures()],
                      fontStyle: isProjected ? FontStyle.italic : null,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPotTile(BuildContext context, MoneyPot pot, Color creditColor, Color debitColor) {
     final displayColor = pot.type == MoneyPotType.savings ? creditColor : debitColor;
     final projectedAmount = _calculateProjectedBalance(pot);
     final isProjected = projectedAmount != pot.amountCents;

    return InkWell(
      onTap: () => _editPot(context, pot),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingNormal,
          vertical: 6.0, 
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(pot.name, style: Theme.of(context).textTheme.bodyMedium),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Show "(projected)" indicator for future months
                if (isProjected)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Icon(
                      Icons.trending_down,
                      size: 14,
                      color: displayColor.withValues(alpha: 0.7),
                    ),
                  ),
                Text(
                  formatMoneyFromCents(projectedAmount, pot.currency ?? settings.currencySettings.currency, showCents: settings.showCents),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: displayColor,
                    fontWeight: FontWeight.w600,
                    fontFeatures: const [FontFeature.tabularFigures()],
                    // Slightly reduce opacity for projected values
                    fontStyle: isProjected ? FontStyle.italic : null,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editLabel(BuildContext context) async {
    final controller = TextEditingController(text: settings.moneyPotsSettings.sectionLabel);
    
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Section'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Section Label',
            hintText: 'e.g., Savings Goals, Tracked Debts',
          ),
          onSubmitted: (value) => Navigator.of(context).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    
    if (result != null && result.isNotEmpty) {
      settings.moneyPotsSettings.sectionLabel = result;
    }
  }

  Future<void> _editPot(BuildContext context, MoneyPot? pot) async {
    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => UpsertMoneyPotSheet(initialPot: pot),
    );

    if (result is MoneyPot) {
      if (pot == null) {
        settings.moneyPotsSettings.addMoneyPot(result);
      } else {
        settings.moneyPotsSettings.updateMoneyPot(result);
      }
    } else if (result is DeletePotMarker) {
       if (pot != null) {
         settings.moneyPotsSettings.removeMoneyPot(pot.id);
       }
    }
  }
}
