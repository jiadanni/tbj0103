import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/accounts/accounts_screen.dart';


class AccountSelector extends StatelessWidget {
  const AccountSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final accounts = store.accounts;
    final currentAccount = store.currentAccount;
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppConstants.paddingSmall),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
      ),
      child: PopupMenuButton<String>(
        tooltip: 'Switch Account',
        offset: const Offset(0, 48),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppConstants.paddingSmall,
            vertical: AppConstants.paddingSmall,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (currentAccount.isTestData)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Icon(
                    Icons.science_outlined,
                    size: 16,
                    color: theme.colorScheme.secondary,
                  ),
                ),
              Expanded(
                child: Text(
                  currentAccount.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
              Icon(
                Icons.arrow_drop_down,
                color: theme.colorScheme.primary,
                size: 24,
              ),
            ],
          ),
        ),
        itemBuilder: (context) {
          final items = <PopupMenuEntry<String>>[];
          
          // Add account switching options
          for (final account in accounts) {
            items.add(
              CheckedPopupMenuItem<String>(
                value: account.id,
                checked: account.id == currentAccount.id,
                child: Row(
                  children: [
                    if (account.isTestData)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: Icon(
                          Icons.science_outlined,
                          size: 16,
                          color: theme.colorScheme.secondary,
                        ),
                      ),
                    Expanded(
                      child: Text(
                        account.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
          
          // Add divider and manage accounts option
          items.add(const PopupMenuDivider());
          items.add(
            PopupMenuItem<String>(
              value: '_manage_accounts',
              child: Row(
                children: [
                  Icon(
                    Icons.settings_outlined,
                    size: 20,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 12),
                  const Text('Manage Accounts'),
                ],
              ),
            ),
          );
          
          return items;
        },
        onSelected: (value) {
          if (value == '_manage_accounts') {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const AccountsScreen(),
              ),
            );
          } else {
            store.switchAccount(value);
          }
        },
      ),
    );
  }
}
