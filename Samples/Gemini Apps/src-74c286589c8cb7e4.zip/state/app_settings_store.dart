import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/planner_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';

export 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
export 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/planner_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';

class AppSettingsStore extends ChangeNotifier {
  AppSettingsStore._(
    this._storage,
    this.themeSettings,
    this.currencySettings,
    this.plannerSettings,
    this.moneyPotsSettings,
    this._regionPresetId,
  ) {
    themeSettings.addListener(notifyListeners);
    currencySettings.addListener(notifyListeners);
    plannerSettings.addListener(notifyListeners);
    moneyPotsSettings.addListener(notifyListeners);
  }

  final StorageProvider _storage;

  final ThemeSettings themeSettings;
  final CurrencySettings currencySettings;
  final PlannerSettings plannerSettings;
  final MoneyPotsSettings moneyPotsSettings;
  
  String _regionPresetId;
  
  // Reference to ExpenseStore for account-specific settings delegation
  ExpenseStore? _expenseStore;
  
  /// Bind the ExpenseStore after both are initialized.
  /// This allows paycheck settings to be read from the current account.
  void bindExpenseStore(ExpenseStore store) {
    _expenseStore = store;
    store.addListener(notifyListeners);
  }

  static const _kRegionPreset = 'settings.regionPreset';
  
  // Forward keys for loadOrCreate convenience (though usage is internal now)
  static const _kThemeMode = 'settings.themeMode';
  static const _kCurrency = 'settings.currency';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';
  static const _kDayFormat = 'settings.dayFormat';
  static const _kPlannerSwipeLeft = 'settings.planner.swipeLeft';
  static const _kPlannerSwipeRight = 'settings.planner.swipeRight';
  static const _kPlannerTapAction = 'settings.planner.tapAction';
  static const _kPaymentSwipeLeft = 'settings.payment.swipeLeft';
  static const _kPaymentSwipeRight = 'settings.payment.swipeRight';
  static const _kPaymentDisplayMode = 'settings.payment.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kPlannerUseZeroBaseline = 'settings.planner.useZeroBaseline';
  static const _kPlannerShowClearedItems = 'settings.planner.showClearedItems';
  static const _kPlannerSortOrder = 'settings.planner.sortOrder';
  static const _kPlannerDateSortMode = 'settings.planner.dateSortMode';
  static const _kViewPeriodMode = 'settings.viewPeriodMode';
  static const _kPaycheckDay = 'settings.paycheckDay';
  static const _kPaycheckBusinessAdjust = 'settings.paycheck.businessAdjust';
  static const _kPaycheckBusinessAdjustDirection = 'settings.paycheck.businessAdjustDirection';
  static const _kColorPreset = 'settings.colors.preset';
  static const _kAppThemePreset = 'settings.colors.appThemePreset';
  static const _kDebitColor = 'settings.colors.debit';
  static const _kCreditColor = 'settings.colors.credit';
  static const _kNeutralColor = 'settings.colors.neutral';
  static const _kPlannerGroupByDate = 'settings.planner.groupByDate';
  static const _kPlannerGroupByTheme = 'settings.planner.groupByTheme';
  static const _kPlannerShowPaymentOrigin = 'settings.planner.showPaymentOrigin';
  static const _kMonthCardDisplayMode = 'settings.planner.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode = 'settings.planner.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayMode = 'settings.planner.multiMonthDisplayMode';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kTextScalePreset = 'settings.textScale';
  static const _kFontPreset = 'settings.fontPreset';
  static const _kPlannerViewMode = 'settings.planner.viewMode';
  static const _kShowCents = 'settings.currency.showCents';
  static const _kRoundingIncrement = 'settings.currency.roundingIncrement';
  static const _kPaymentsFilterType = 'settings.payments.filterType';
  static const _kPaymentsGroupBy = 'settings.payments.groupBy';
  static const _kPaymentsShowArchived = 'settings.payments.showArchived';
  static const _kCategoryPresetMode = 'settings.planner.categoryPresetMode';
  static const _kMoneyPots = 'settings.moneyPots';
  static const _kMoneyPotsSectionLabel = 'settings.moneyPots.sectionLabel';

  // ===========================================================================
  // Static Data Access Accessors (Delegated)
  // ===========================================================================

  Map<ColorPreset, (int, int, int)> get presetColors => ThemeSettings.presetColors;

  // ===========================================================================
  // Proxied Getters
  // ===========================================================================

  String get regionPresetId => _regionPresetId;
  List<RegionPreset> get regionPresets => AppSettingsPresets.regionPresets;
  RegionPreset get regionPreset => AppSettingsPresets.regionPresetForId(_regionPresetId);

  // Theme Proxies
  ThemeMode get themeMode => themeSettings.themeMode;
  ColorPreset get colorPreset => themeSettings.colorPreset;
  AppThemePreset get appThemePreset => themeSettings.appThemePreset;
  Color get debitColor => themeSettings.debitColor;
  Color get creditColor => themeSettings.creditColor;
  Color get neutralColor => themeSettings.neutralColor;
  Color get themeSeedColor => themeSettings.themeSeedColor;
  TextScalePreset get textScalePreset => themeSettings.textScalePreset;
  FontPreset get fontPreset => themeSettings.fontPreset;
  double get textScaleFactor => themeSettings.textScaleFactor;
  String? get fontFamily => themeSettings.fontFamily;

  // Currency Proxies
  AppCurrency get currency => currencySettings.currency;
  int get currentBalanceCents => currencySettings.currentBalanceCents;
  bool get showCents => currencySettings.showCents;
  int get roundingIncrement => currencySettings.roundingIncrement;

  // Planner Proxies
  DayFormat get dayFormat => plannerSettings.dayFormat;
  PlannerSwipeAction get plannerSwipeLeft => plannerSettings.plannerSwipeLeft;
  PlannerSwipeAction get plannerSwipeRight => plannerSettings.plannerSwipeRight;
  PlannerTapAction get plannerTapAction => plannerSettings.plannerTapAction;
  PaymentSwipeAction get paymentSwipeLeft => plannerSettings.paymentSwipeLeft;
  PaymentSwipeAction get paymentSwipeRight => plannerSettings.paymentSwipeRight;
  PaymentDisplayMode get paymentDisplayMode => plannerSettings.paymentDisplayMode;
  bool get enableTabSwipe => plannerSettings.enableTabSwipe;
  bool get plannerUseZeroBaseline => plannerSettings.plannerUseZeroBaseline;
  bool get plannerShowClearedItems => plannerSettings.plannerShowClearedItems;
  PlannerSortOrder get plannerSortOrder => plannerSettings.plannerSortOrder;
  PlannerDateSortMode get plannerDateSortMode => plannerSettings.plannerDateSortMode;
  ViewPeriodMode get viewPeriodMode => plannerSettings.viewPeriodMode;
  
  // Account-specific settings - delegate to current account when available
  int? get paycheckDay => _expenseStore?.currentAccount.paycheckDay ?? plannerSettings.paycheckDay;
  bool get isPaycheckModeConfigured => paycheckDay != null;
  bool get paycheckBusinessAdjust => _expenseStore?.currentAccount.paycheckBusinessAdjust ?? plannerSettings.paycheckBusinessAdjust;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection => _expenseStore?.currentAccount.paycheckBusinessAdjustDirection ?? plannerSettings.paycheckBusinessAdjustDirection;
  int get startingBalanceCents => _expenseStore?.currentAccount.startingBalanceCents ?? currencySettings.currentBalanceCents;
  bool get plannerGroupByDate => plannerSettings.plannerGroupByDate;
  bool get plannerGroupByTheme => plannerSettings.plannerGroupByTheme;
  bool get plannerShowPaymentOrigin => plannerSettings.plannerShowPaymentOrigin;
  MonthCardDisplayMode get monthCardDisplayMode => plannerSettings.monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => plannerSettings.monthTotalsDisplayMode;
  MultiMonthDisplayMode get multiMonthDisplayMode => plannerSettings.multiMonthDisplayMode;
  TerminologyPreset get terminologyPreset => plannerSettings.terminologyPreset;
  PlannerViewMode get plannerViewMode => plannerSettings.plannerViewMode;
  PaymentsFilterType get paymentsFilterType => plannerSettings.paymentsFilterType;
  PaymentsGroupBy get paymentsGroupBy => plannerSettings.paymentsGroupBy;
  bool get paymentsShowArchived => plannerSettings.paymentsShowArchived;
  CategoryPresetMode get categoryPresetMode => plannerSettings.categoryPresetMode;

  List<MoneyPot> get moneyPots => moneyPotsSettings.moneyPots;

  // ===========================================================================
  // Proxied Setters
  // ===========================================================================

  set themeMode(ThemeMode value) => themeSettings.themeMode = value;
  set colorPreset(ColorPreset value) => themeSettings.colorPreset = value;
  set appThemePreset(AppThemePreset value) => themeSettings.appThemePreset = value;
  set debitColor(Color value) => themeSettings.debitColor = value;
  set creditColor(Color value) => themeSettings.creditColor = value;
  set neutralColor(Color value) => themeSettings.neutralColor = value;
  set textScalePreset(TextScalePreset value) => themeSettings.textScalePreset = value;
  set fontPreset(FontPreset value) => themeSettings.fontPreset = value;

  set currency(AppCurrency value) => currencySettings.currency = value;
  
  // =====================
  // Logic for region preset
  // =====================

  set regionPresetId(String value) {
    if (_regionPresetId == value) return;
    _regionPresetId = value;
    _storage.setString(_kRegionPreset, value);
    final preset = AppSettingsPresets.regionPresetForId(value);
    final locale = AppSettingsPresets.localeFromPlatform();
    final nextCurrency = preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
    final nextDayFormat = preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);
    
    currencySettings.currency = nextCurrency;
    plannerSettings.dayFormat = nextDayFormat;
    notifyListeners();
  }

  // Setters for proxies
  set currentBalanceCents(int value) => currencySettings.currentBalanceCents = value;
  set showCents(bool value) => currencySettings.showCents = value;
  set roundingIncrement(int value) => currencySettings.roundingIncrement = value;

  set dayFormat(DayFormat value) => plannerSettings.dayFormat = value;
  set plannerSwipeLeft(PlannerSwipeAction value) => plannerSettings.plannerSwipeLeft = value;
  set plannerSwipeRight(PlannerSwipeAction value) => plannerSettings.plannerSwipeRight = value;
  set plannerTapAction(PlannerTapAction value) => plannerSettings.plannerTapAction = value;
  set paymentSwipeLeft(PaymentSwipeAction value) => plannerSettings.paymentSwipeLeft = value;
  set paymentSwipeRight(PaymentSwipeAction value) => plannerSettings.paymentSwipeRight = value;
  set paymentDisplayMode(PaymentDisplayMode value) => plannerSettings.paymentDisplayMode = value;
  set enableTabSwipe(bool value) => plannerSettings.enableTabSwipe = value;
  set plannerUseZeroBaseline(bool value) => plannerSettings.plannerUseZeroBaseline = value;
  set plannerShowClearedItems(bool value) => plannerSettings.plannerShowClearedItems = value;
  set plannerSortOrder(PlannerSortOrder value) => plannerSettings.plannerSortOrder = value;
  set plannerDateSortMode(PlannerDateSortMode value) => plannerSettings.plannerDateSortMode = value;
  set viewPeriodMode(ViewPeriodMode value) => plannerSettings.viewPeriodMode = value;
  
  // Paycheck setters - delegate to account when available
  set paycheckDay(int? value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckDay(value);
    } else {
      plannerSettings.paycheckDay = value;
    }
  }
  
  set paycheckBusinessAdjust(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjust(value);
    } else {
      plannerSettings.paycheckBusinessAdjust = value;
    }
  }
  
  set paycheckBusinessAdjustDirection(PaycheckAdjustDirection value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjustDirection(value);
    } else {
      plannerSettings.paycheckBusinessAdjustDirection = value;
    }
  }
  
  set startingBalanceCents(int value) {
    if (_expenseStore != null) {
      _expenseStore!.updateStartingBalance(value);
    } else {
      currencySettings.currentBalanceCents = value;
    }
  }
  set plannerGroupByDate(bool value) => plannerSettings.plannerGroupByDate = value;
  set plannerGroupByTheme(bool value) => plannerSettings.plannerGroupByTheme = value;
  set plannerShowPaymentOrigin(bool value) => plannerSettings.plannerShowPaymentOrigin = value;
  set monthCardDisplayMode(MonthCardDisplayMode value) => plannerSettings.monthCardDisplayMode = value;
  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) => plannerSettings.monthTotalsDisplayMode = value;
  set multiMonthDisplayMode(MultiMonthDisplayMode value) => plannerSettings.multiMonthDisplayMode = value;
  set terminologyPreset(TerminologyPreset value) => plannerSettings.terminologyPreset = value;
  set plannerViewMode(PlannerViewMode value) => plannerSettings.plannerViewMode = value;
  set paymentsFilterType(PaymentsFilterType value) => plannerSettings.paymentsFilterType = value;
  set paymentsGroupBy(PaymentsGroupBy value) => plannerSettings.paymentsGroupBy = value;
  set paymentsShowArchived(bool value) => plannerSettings.paymentsShowArchived = value;
  set categoryPresetMode(CategoryPresetMode value) => plannerSettings.categoryPresetMode = value;

  static Future<AppSettingsStore> loadOrCreate() async {
    final storage = await StorageProvider.create();
    try {
      // Load all values
      final themeMode = AppSettingsCodecs.decodeThemeMode(await storage.getString(_kThemeMode)) ?? ThemeMode.system;
      final currencyStored = await storage.getString(_kCurrency);
      final balance = await storage.getInt(_kCurrentBalanceCents) ?? 0;
      final dayFormatStored = await storage.getString(_kDayFormat);
      final swipeLeft = AppSettingsCodecs.decodeSwipeAction(await storage.getString(_kPlannerSwipeLeft)) ?? PlannerSwipeAction.off;
      final swipeRight = AppSettingsCodecs.decodeSwipeAction(await storage.getString(_kPlannerSwipeRight)) ?? PlannerSwipeAction.off;
      final plannerTapAction = AppSettingsCodecs.decodePlannerTapAction(await storage.getString(_kPlannerTapAction)) ?? PlannerTapAction.archive;
      final paymentSwipeLeft = AppSettingsCodecs.decodePaymentSwipeAction(await storage.getString(_kPaymentSwipeLeft)) ?? PaymentSwipeAction.off;
      final paymentSwipeRight = AppSettingsCodecs.decodePaymentSwipeAction(await storage.getString(_kPaymentSwipeRight)) ?? PaymentSwipeAction.off;
      final paymentDisplayMode = AppSettingsCodecs.decodePaymentDisplayMode(await storage.getString(_kPaymentDisplayMode)) ?? PaymentDisplayMode.automatic;
      final enableTabSwipe = await storage.getBool(_kEnableTabSwipe) ?? false;
      final useZeroBaseline = await storage.getBool(_kPlannerUseZeroBaseline) ?? false;
      final showClearedItems = await storage.getBool(_kPlannerShowClearedItems) ?? true;
      
      final regionPresetId = await storage.getString(_kRegionPreset) ?? AppSettingsPresets.autoPresetId;
      final preset = AppSettingsPresets.regionPresetForId(regionPresetId);
      final locale = AppSettingsPresets.localeFromPlatform();
      final fallbackCurrency = preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
      final fallbackDayFormat = preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);
      
      final resolvedCurrency = decodeCurrency(currencyStored) ?? fallbackCurrency;
      final resolvedDayFormat = AppSettingsCodecs.decodeDayFormat(dayFormatStored) ?? fallbackDayFormat;
      
      final sortOrder = AppSettingsCodecs.decodeSortOrder(await storage.getString(_kPlannerSortOrder)) ?? PlannerSortOrder.chronological;
      final dateSortMode = AppSettingsCodecs.decodePlannerDateSortMode(await storage.getString(_kPlannerDateSortMode)) ?? PlannerDateSortMode.scheduledDate;
      final viewPeriodMode = AppSettingsCodecs.decodeViewPeriodMode(await storage.getString(_kViewPeriodMode)) ?? ViewPeriodMode.calendar;
      final paycheckDay = await storage.getInt(_kPaycheckDay);
      final paycheckBusinessAdjust = await storage.getBool(_kPaycheckBusinessAdjust) ?? true;
      final paycheckBusinessAdjustDirection = AppSettingsCodecs.decodeAdjustDirection(await storage.getString(_kPaycheckBusinessAdjustDirection)) ?? PaycheckAdjustDirection.after;
      
      final colorPreset = AppSettingsCodecs.decodeColorPreset(await storage.getString(_kColorPreset)) ?? ColorPreset.classic;
      final appThemePreset = AppSettingsCodecs.decodeAppThemePreset(await storage.getString(_kAppThemePreset)) ?? AppThemePreset.monochrome;
      
      final defaultColors = ThemeSettings.presetColors[colorPreset]!;
       final debitColorValue = await storage.getInt(_kDebitColor) ?? defaultColors.$1;
       final creditColorValue = await storage.getInt(_kCreditColor) ?? defaultColors.$2;
       final neutralColorValue = await storage.getInt(_kNeutralColor) ?? defaultColors.$3;
      
      final plannerGroupByDate = await storage.getBool(_kPlannerGroupByDate) ?? false;
      final plannerGroupByTheme = await storage.getBool(_kPlannerGroupByTheme) ?? false;
      final plannerShowPaymentOrigin = await storage.getBool(_kPlannerShowPaymentOrigin) ?? false;
      
      final monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(await storage.getString(_kMonthCardDisplayMode)) ?? MonthCardDisplayMode.full;
      final monthTotalsDisplayMode = AppSettingsCodecs.decodeMonthTotalsDisplayMode(await storage.getString(_kMonthTotalsDisplayMode)) ?? MonthTotalsDisplayMode.includeCleared;
      final multiMonthDisplayMode = AppSettingsCodecs.decodeMultiMonthDisplayMode(await storage.getString(_kMultiMonthDisplayMode)) ?? MultiMonthDisplayMode.automatic;
      
      final terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(await storage.getString(_kTerminologyPreset)) ?? TerminologyPreset.defaultTerms;
      final textScalePreset = AppSettingsCodecs.decodeTextScalePreset(await storage.getString(_kTextScalePreset)) ?? TextScalePreset.normal;
      final fontPreset = AppSettingsCodecs.decodeFontPreset(await storage.getString(_kFontPreset)) ?? FontPreset.system;
      final plannerViewMode = AppSettingsCodecs.decodePlannerViewMode(await storage.getString(_kPlannerViewMode)) ?? PlannerViewMode.month;
      
      final showCents = await storage.getBool(_kShowCents) ?? true;
      final roundingIncrement = await storage.getInt(_kRoundingIncrement) ?? 0;
      
      final paymentsFilterType = AppSettingsCodecs.decodePaymentsFilterType(await storage.getString(_kPaymentsFilterType)) ?? PaymentsFilterType.all;
      final paymentsGroupBy = AppSettingsCodecs.decodePaymentsGroupBy(await storage.getString(_kPaymentsGroupBy)) ?? PaymentsGroupBy.none;
      final paymentsShowArchived = await storage.getBool(_kPaymentsShowArchived) ?? false;
      final categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(await storage.getString(_kCategoryPresetMode)) ?? CategoryPresetMode.defaultPresets;

      final moneyPotsJson = await storage.getString(_kMoneyPots);
      List<MoneyPot> moneyPots = [];
      if (moneyPotsJson != null) {
        try {
          final List<dynamic> list = jsonDecode(moneyPotsJson);
          moneyPots = list.map((e) => MoneyPot.fromJson(e)).toList();
        } catch (e) {
           debugLog(LogCategory.persistence, 'Failed to decode money pots', error: e);
        }
      }
      
      final moneyPotsSectionLabel = await storage.getString(_kMoneyPotsSectionLabel);

      return AppSettingsStore._(
        storage,
        ThemeSettings(
            storage,
            initialThemeMode: themeMode,
            initialColorPreset: colorPreset,
            initialAppThemePreset: appThemePreset,
             initialDebitColor: debitColorValue,
             initialCreditColor: creditColorValue,
             initialNeutralColor: neutralColorValue,
             initialTextScalePreset: textScalePreset,
            initialFontPreset: fontPreset,
        ),
        CurrencySettings(
            storage,
            initialCurrency: resolvedCurrency,
            initialBalanceCents: balance,
            initialShowCents: showCents,
            initialRoundingIncrement: roundingIncrement,
        ),
        PlannerSettings(
            storage,
            initialDayFormat: resolvedDayFormat,
            initialSwipeLeft: swipeLeft,
            initialSwipeRight: swipeRight,
            initialTapAction: plannerTapAction,
            initialPaymentSwipeLeft: paymentSwipeLeft,
            initialPaymentSwipeRight: paymentSwipeRight,
            initialPaymentDisplayMode: paymentDisplayMode,
            initialEnableTabSwipe: enableTabSwipe,
            initialUseZeroBaseline: useZeroBaseline,
            initialShowClearedItems: showClearedItems,
            initialSortOrder: sortOrder,
            initialDateSortMode: dateSortMode,
            initialViewPeriodMode: viewPeriodMode,
            initialPaycheckDay: paycheckDay,
            initialPaycheckBusinessAdjust: paycheckBusinessAdjust,
            initialPaycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
            initialGroupByDate: plannerGroupByDate,
            initialGroupByTheme: plannerGroupByTheme,
            initialShowPaymentOrigin: plannerShowPaymentOrigin,
            initialMonthCardDisplayMode: monthCardDisplayMode,
            initialMonthTotalsDisplayMode: monthTotalsDisplayMode,
            initialMultiMonthDisplayMode: multiMonthDisplayMode,
            initialTerminologyPreset: terminologyPreset,
            initialViewMode: plannerViewMode,
            initialPaymentsFilterType: paymentsFilterType,
            initialPaymentsGroupBy: paymentsGroupBy,
            initialPaymentsShowArchived: paymentsShowArchived,
            initialCategoryPresetMode: categoryPresetMode,
        ),
        MoneyPotsSettings(
          storage, 
          initialMoneyPots: moneyPots,
          initialSectionLabel: moneyPotsSectionLabel,
        ),
        regionPresetId,
      );
    } catch (error, stackTrace) {
        debugLog(LogCategory.persistence, 'Failed to load settings', error: error, stackTrace: stackTrace);
        rethrow;
    }
  }

  @override
  void dispose() {
    themeSettings.removeListener(notifyListeners);
    currencySettings.removeListener(notifyListeners);
    plannerSettings.removeListener(notifyListeners);
    themeSettings.dispose();
    currencySettings.dispose();
    plannerSettings.dispose();
    moneyPotsSettings.dispose();
    super.dispose();
  }
}

class AppSettingsScope extends InheritedNotifier<AppSettingsStore> {
  const AppSettingsScope({
    super.key,
    required AppSettingsStore store,
    required super.child,
  }) : super(notifier: store);

  static AppSettingsStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppSettingsScope>();
    assert(scope != null, 'AppSettingsScope not found in widget tree.');
    return scope!.notifier!;
  }

  static AppSettingsStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppSettingsScope>();
    assert(scope != null, 'AppSettingsScope not found in widget tree.');
    return scope!.notifier!;
  }
}
