import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

/// Handles data migration between different storage providers.
///
/// Primarily used to move data from plaintext SharedPreferences to
/// encrypted FlutterSecureStorage when encryption is enabled.
class StorageMigration {
  const StorageMigration._();

  /// Migrates all data from [from] to [to].
  ///
  /// Currently assumes [from] is SharedPreferences and we want to move
  /// all keys to the new provider.
  ///
  /// Returns true when all migrated keys are verified and removed.
  static Future<bool> migrate({
    required StorageProvider from,
    required StorageProvider to,
  }) async {
    debugLog(LogCategory.persistence, 'Starting storage migration...');

    // Known keys to migrate
    final keys = [
      'expense.selectedMonth',
      'expense.plannerItems',
      'expense.payments',
      'settings.themeMode',
      'settings.currency',
      'settings.currentBalanceCents',
      'settings.dayFormat',
      'settings.planner.swipeLeft',
      'settings.planner.swipeRight',
      'settings.planner.tapAction',
      'settings.payment.swipeLeft',
      'settings.payment.swipeRight',
      'settings.payment.displayMode',
      'settings.navigation.enableTabSwipe',
      'settings.planner.useZeroBaseline',
      'settings.planner.showClearedItems',
      'settings.planner.sortOrder',
      'settings.regionPreset',
      'settings.viewPeriodMode',
      'settings.paycheckDay',
      'settings.paycheck.businessAdjust',
      'settings.paycheck.businessAdjustDirection',
      'settings.textScale',
      'settings.fontPreset',
      // Auth settings migration - ensures these move to secure storage
      'auth.enabled',
      'auth.use_biometrics',
      'auth.auto_lock_minutes',
      'auth.delay_before_auth_seconds',
      'auth.prevent_screenshots',
      'auth.pin_hash',
    ];

    int migratedCount = 0;
    
    // Phase 1: Copy and Verify ALL keys
    // We do not delete anything from 'from' in this phase.
    // If this phase fails for ANY key, we abort and leave 'from' untouched.
    final pendingDeletes = <String>[];
    
    for (final key in keys) {
      final value = await _readValue(from, key);
      if (value == null) continue;

      final verified = await _writeAndVerify(to, key, value);
      if (!verified) {
        debugLog(
          LogCategory.persistence,
          'Migration validation failed for key "$key". Aborting migration.',
        );
        // Abort entirely. Existing data in 'to' might be partial, but 'from' is intact.
        // We will retry next launch.
        return false;
      }
      pendingDeletes.add(key);
    }
    
    // Phase 2: Delete from Source
    // Only reached if Phase 1 was 100% successful for all available keys.
    int deleteFailures = 0;
    for (final key in pendingDeletes) {
      final removed = await from.remove(key);
      if (!removed) {
         debugLog(
          LogCategory.persistence,
          'Migration warning: Failed to delete plaintext key "$key" after successful copy.',
        );
        deleteFailures++;
      } else {
        migratedCount++;
      }
    }

    debugLog(
      LogCategory.persistence,
      'Storage migration complete. Migrated $migratedCount keys.',
    );

    if (deleteFailures > 0) {
      debugLog(
        LogCategory.persistence,
        'Storage migration finished with $deleteFailures deletion failures.',
      );
      // We return true because the data IS safely in the new storage.
      // The leftover data in old storage is messy but not data loss.
      return true;
    }

    return true;
  }
}

enum _StoredValueKind { string, int, bool }

class _StoredValue {
  const _StoredValue(this.kind, this.value);

  final _StoredValueKind kind;
  final Object value;
}

Future<_StoredValue?> _readValue(StorageProvider from, String key) async {
  final stringVal = await from.getString(key);
  if (stringVal != null) return _StoredValue(_StoredValueKind.string, stringVal);

  final intVal = await from.getInt(key);
  if (intVal != null) return _StoredValue(_StoredValueKind.int, intVal);

  final boolVal = await from.getBool(key);
  if (boolVal != null) return _StoredValue(_StoredValueKind.bool, boolVal);

  return null;
}

Future<bool> _writeAndVerify(
  StorageProvider to,
  String key,
  _StoredValue value,
) async {
  switch (value.kind) {
    case _StoredValueKind.string:
      if (!await to.setString(key, value.value as String)) return false;
      return await to.getString(key) == value.value;
    case _StoredValueKind.int:
      if (!await to.setInt(key, value.value as int)) return false;
      return await to.getInt(key) == value.value;
    case _StoredValueKind.bool:
      if (!await to.setBool(key, value.value as bool)) return false;
      return await to.getBool(key) == value.value;
  }
}
