import 'dart:async';
import 'package:flutter/widgets.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/util/async_queue.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/test_data_generator.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';

class ExpenseStore extends ChangeNotifier {
  ExpenseStore({
    required List<Account> accounts,
    required Account currentAccount,
    required DateTime selectedMonth,
    required List<PlannerItem> plannerItems,
    required List<PaymentEntry> payments,
    ExpensePersistence? persistence,
  }) : _accounts = List.unmodifiable(accounts),
       _currentAccount = currentAccount,
       _selectedMonth = monthOnly(selectedMonth),
       _plannerItems = List.unmodifiable(plannerItems),
       _payments = List.unmodifiable(payments),
       _persistence = persistence;

  List<Account> _accounts;
  Account _currentAccount;
  DateTime _selectedMonth;
  List<PlannerItem> _plannerItems;
  List<PaymentEntry> _payments;
  final ExpensePersistence? _persistence;
  Timer? _debounceTimer;
  final AsyncQueue _saveQueue = AsyncQueue();

  /// Guards against concurrent account operations (switch, create, delete, rename).
  /// Prevents race conditions when multiple async account operations overlap.
  bool _accountOperationInProgress = false;

  /// The account ID being switched to, used to detect superseded switches.
  String? _pendingSwitchAccountId;

  List<Account> get accounts => _accounts;
  Account get currentAccount => _currentAccount;
  DateTime get selectedMonth => _selectedMonth;
  ExpensePersistence? get persistence => _persistence;

  Future<void> saveNow() async {
    final p = _persistence;
    if (p == null) return;
    _debounceTimer?.cancel();
    await _saveQueue.enqueue(() => p.save(_currentAccount.id, _snapshot()));
  }

  static Future<ExpenseStore> loadOrCreate() async {
    final persistence = await ExpensePersistence.create();
    try {
      final accounts = await persistence.loadAccounts();
      final currentAccountId = await persistence.getCurrentAccountId();
      
      Account selectedAccount;
      if (accounts.isEmpty) {
        // First run or no accounts: create a default Main Account
        selectedAccount = Account.create(name: 'Main Account');
        await persistence.saveAccounts([selectedAccount]);
        await persistence.setCurrentAccountId(selectedAccount.id);
        
        final store = ExpenseStore(
          accounts: [selectedAccount],
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          plannerItems: [],
          payments: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      selectedAccount = accounts.firstWhere(
        (a) => a.id == currentAccountId,
        orElse: () => accounts.first,
      );

      final snapshot = await persistence.load(selectedAccount.id);
      if (snapshot == null) {
        // Account exists but data is missing? Unusual but handle it
        final store = ExpenseStore(
          accounts: accounts,
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          plannerItems: [],
          payments: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      return ExpenseStore(
        accounts: accounts,
        currentAccount: selectedAccount,
        selectedMonth: DateTime.now(),
        plannerItems: snapshot.plannerItems,
        payments: snapshot.payments,
        persistence: persistence,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to load expenses, creating emergency account',
        error: error,
        stackTrace: stackTrace,
      );
      final emergencyAccount = Account.create(name: 'Rescue Account');
      return ExpenseStore(
        accounts: [emergencyAccount],
        currentAccount: emergencyAccount,
        selectedMonth: DateTime.now(),
        plannerItems: [],
        payments: [],
        persistence: persistence,
      );
    }
  }
  
  /// Factory for tests
  factory ExpenseStore.withSampleData() {
    final account = Account.create(name: 'Test Account', isTestData: true);
    final (plannerItems, payments) = TestDataGenerator.generate(size: TestDatasetSize.standard);
    return ExpenseStore(
      accounts: [account],
      currentAccount: account,
      selectedMonth: DateTime.now(),
      plannerItems: plannerItems,
      payments: payments,
    );
  }

  Future<void> switchAccount(String accountId) async {
    if (accountId == _currentAccount.id) return;
    final persistence = _persistence;
    if (persistence == null) return;

    // Track this as the pending switch - supersedes any earlier pending switch
    _pendingSwitchAccountId = accountId;

    // If another account operation is in progress, queue this switch
    // The pending ID ensures only the latest requested switch executes
    if (_accountOperationInProgress) {
      debugLog(
        LogCategory.persistence,
        'Account switch to $accountId queued - operation in progress',
      );
      return;
    }

    _accountOperationInProgress = true;
    try {
      // Ensure current work is saved before switching
      _debounceTimer?.cancel();
      await _saveQueue.enqueue(() => persistence.save(_currentAccount.id, _snapshot()));

      // Check if this switch was superseded by a newer request
      if (_pendingSwitchAccountId != accountId) {
        debugLog(
          LogCategory.persistence,
          'Account switch to $accountId superseded by $_pendingSwitchAccountId',
        );
        return;
      }

      // Validate account still exists (could have been deleted concurrently)
      final nextAccount = _accounts.cast<Account?>().firstWhere(
        (a) => a?.id == accountId,
        orElse: () => null,
      );
      if (nextAccount == null) {
        debugLog(
          LogCategory.persistence,
          'Account $accountId no longer exists, aborting switch',
        );
        return;
      }

      final snapshot = await persistence.load(accountId);

      // Final check: still the intended switch target after async load?
      if (_pendingSwitchAccountId != accountId) {
        debugLog(
          LogCategory.persistence,
          'Account switch to $accountId superseded after load',
        );
        return;
      }

      if (snapshot != null) {
        _currentAccount = nextAccount;
        _selectedMonth = monthOnly(DateTime.now());
        _plannerItems = List.unmodifiable(snapshot.plannerItems);
        _payments = List.unmodifiable(snapshot.payments);

        await persistence.setCurrentAccountId(accountId);

        _invalidatePlannerItemCaches();
        _invalidatePaymentCache();
        notifyListeners();
      }
    } finally {
      _accountOperationInProgress = false;
      _pendingSwitchAccountId = null;
    }
  }

  Future<void> createAccount(String name, {TestDatasetSize? testSize}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    // Wait for any in-progress operation to complete
    if (_accountOperationInProgress) {
      debugLog(
        LogCategory.persistence,
        'Create account "$name" waiting for operation to complete',
      );
      // Simple spin-wait with delay - in production, consider a proper queue
      while (_accountOperationInProgress) {
        await Future.delayed(const Duration(milliseconds: 50));
      }
    }

    _accountOperationInProgress = true;
    try {
      final newAccount = Account.create(name: name, isTestData: testSize != null);
      final List<Account> updatedAccounts = List.from(_accounts)..add(newAccount);

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      if (testSize != null) {
        final (plannerItems, payments) = TestDataGenerator.generate(size: testSize);
        final snapshot = ExpenseSnapshot(
          selectedMonth: monthOnly(DateTime.now()),
          plannerItems: plannerItems,
          payments: payments,
        );
        await persistence.save(newAccount.id, snapshot);
      } else {
        await persistence.save(newAccount.id, ExpenseSnapshot(
          selectedMonth: monthOnly(DateTime.now()),
          plannerItems: [],
          payments: [],
        ));
      }

      notifyListeners();
    } finally {
      _accountOperationInProgress = false;
    }
  }

  Future<void> deleteAccount(String accountId) async {
    if (_accounts.length <= 1) return; // Prevent deleting the last account

    final persistence = _persistence;
    if (persistence == null) return;

    // Wait for any in-progress operation to complete
    if (_accountOperationInProgress) {
      debugLog(
        LogCategory.persistence,
        'Delete account $accountId waiting for operation to complete',
      );
      while (_accountOperationInProgress) {
        await Future.delayed(const Duration(milliseconds: 50));
      }
    }

    _accountOperationInProgress = true;
    try {
      // Re-validate after acquiring lock (account list may have changed)
      if (_accounts.length <= 1) return;
      if (!_accounts.any((a) => a.id == accountId)) {
        debugLog(
          LogCategory.persistence,
          'Account $accountId already deleted, skipping',
        );
        return;
      }

      final updatedAccounts = _accounts.where((a) => a.id != accountId).toList();
      await persistence.saveAccounts(updatedAccounts);
      await persistence.deleteAccountData(accountId);

      _accounts = List.unmodifiable(updatedAccounts);

      final needsSwitch = accountId == _currentAccount.id;

      // Release lock before potential recursive switchAccount call
      _accountOperationInProgress = false;

      if (needsSwitch) {
        await switchAccount(_accounts.first.id);
      } else {
        notifyListeners();
      }
    } catch (e) {
      _accountOperationInProgress = false;
      rethrow;
    }
  }

  Future<void> renameAccount(String accountId, String newName) async {
    final persistence = _persistence;
    if (persistence == null) return;

    // Wait for any in-progress operation to complete
    if (_accountOperationInProgress) {
      debugLog(
        LogCategory.persistence,
        'Rename account $accountId waiting for operation to complete',
      );
      while (_accountOperationInProgress) {
        await Future.delayed(const Duration(milliseconds: 50));
      }
    }

    _accountOperationInProgress = true;
    try {
      // Re-validate after acquiring lock
      final index = _accounts.indexWhere((a) => a.id == accountId);
      if (index < 0) {
        debugLog(
          LogCategory.persistence,
          'Account $accountId not found for rename',
        );
        return;
      }

      final updatedAccount = _accounts[index].copyWith(
        name: newName,
        lastModified: DateTime.now(),
      );

      final List<Account> updatedAccounts = List.from(_accounts);
      updatedAccounts[index] = updatedAccount;

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      if (accountId == _currentAccount.id) {
        _currentAccount = updatedAccount;
      }

      notifyListeners();
    } finally {
      _accountOperationInProgress = false;
    }
  }

  // --- Account-specific settings updates ---

  /// Update the paycheck day for the current account
  Future<void> updatePaycheckDay(int? day) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final clampedDay = day == null ? null : day.clamp(1, 31);
    final updatedAccount = _currentAccount.copyWith(
      paycheckDay: clampedDay,
      clearPaycheckDay: day == null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck business day adjustment setting
  Future<void> updatePaycheckBusinessAdjust(bool adjust) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjust: adjust,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck adjust direction
  Future<void> updatePaycheckBusinessAdjustDirection(PaycheckAdjustDirection direction) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjustDirection: direction,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the starting balance for the current account
  Future<void> updateStartingBalance(int cents) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      startingBalanceCents: cents,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> _updateCurrentAccount(Account updatedAccount, ExpensePersistence persistence) async {
    final index = _accounts.indexWhere((a) => a.id == updatedAccount.id);
    if (index < 0) return;

    final List<Account> updatedAccounts = List.from(_accounts);
    updatedAccounts[index] = updatedAccount;

    await persistence.saveAccounts(updatedAccounts);
    _accounts = List.unmodifiable(updatedAccounts);
    _currentAccount = updatedAccount;

    notifyListeners();
  }

  List<PlannerItem>? _cachedActivePlannerItems;
  List<PlannerItem>? _cachedArchivedPlannerItems;
  List<PaymentEntry>? _cachedSelectedMonthPayments;
  String? _cachedPaymentsCacheKey;
  final Map<String, Timer> _recentlyClearedTimers = {};
  final Set<String> _recentlyClearedPlannerItemIds = {};

  // Debounce duration for saving to persistence. Named to document intent.
  static const Duration _kSaveDebounce = Duration(milliseconds: 350);
  static const Duration _kClearedVisibleDuration = Duration(seconds: 5);

  /// Replace an item with the same `id` in [list] or add it if missing.
  /// Returns a new unmodifiable list.
  static List<T> _replaceOrAddById<T>(List<T> list, T item, String Function(T) idOf) {
    final index = list.indexWhere((e) => idOf(e) == idOf(item));
    final next = list.toList(growable: true);
    if (index >= 0) {
      next[index] = item;
    } else {
      next.add(item);
    }
    return List.unmodifiable(next);
  }

  void setSelectedMonth(DateTime month) {
    final next = monthOnly(month);
    if (_selectedMonth.year == next.year && _selectedMonth.month == next.month) {
      return;
    }
    _selectedMonth = next;
    _invalidatePaymentCache();
    _touch();
  }

  List<PlannerItem> get plannerItems => _plannerItems;

  /// Returns all active (non-archived) planner items.
  List<PlannerItem> get activePlannerItems {
    return _cachedActivePlannerItems ??=
        _plannerItems.where((p) => !p.archived).toList(growable: false);
  }

  List<PlannerItem> get archivedPlannerItems {
    return _cachedArchivedPlannerItems ??=
        _plannerItems.where((p) => p.archived).toList(growable: false);
  }

  List<PaymentEntry> get payments => _payments;

  Set<String> get recentlyClearedPlannerItemIds =>
      Set.unmodifiable(_recentlyClearedPlannerItemIds);

  List<PaymentEntry> paymentsForMonth(DateTime month, {PeriodInfo? periodInfo}) {
    if (periodInfo != null) {
      return _payments
          .where((p) => !p.date.isBefore(periodInfo.start) && !p.date.isAfter(periodInfo.end))
          .toList(growable: false)
        ..sort((a, b) => b.date.compareTo(a.date));
    }
    
    final m = monthOnly(month);
    return _payments
        .where((p) => p.date.year == m.year && p.date.month == m.month)
        .toList(growable: false)
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  List<PaymentEntry> paymentsForSelectedMonth({PeriodInfo? periodInfo}) {
    final cacheKey = periodInfo != null 
        ? '${periodInfo.start.millisecondsSinceEpoch}_${periodInfo.end.millisecondsSinceEpoch}'
        : '${_selectedMonth.year}${_selectedMonth.month.toString().padLeft(2, '0')}';
    
    if (_cachedSelectedMonthPayments != null &&
        _cachedPaymentsCacheKey == cacheKey) {
      return _cachedSelectedMonthPayments!;
    }

    _cachedPaymentsCacheKey = cacheKey;
    _cachedSelectedMonthPayments = paymentsForMonth(_selectedMonth, periodInfo: periodInfo);
    return _cachedSelectedMonthPayments!;
  }
  
  void invalidatePaymentsCache() {
    _cachedPaymentsCacheKey = null;
    _cachedSelectedMonthPayments = null;
    notifyListeners();
  }

  int plannedTotalCentsForSelectedMonth() {
    return activePlannerItems.fold(0, (sum, p) => sum + p.amountCents);
  }

  int paidTotalCentsForSelectedMonth() {
    return paymentsForSelectedMonth().fold(0, (sum, p) => sum + p.amountCents);
  }

  List<String> getUserCategories({required bool isIncome}) {
    final categories = <String>{};
    for (final item in _plannerItems) {
      if (item.type.isIncomeType == isIncome) {
        final cat = item.category;
        if (cat != null && cat.isNotEmpty) {
          categories.add(cat);
        }
      }
    }
    for (final payment in _payments) {
      if (payment.type.isIncomeType == isIncome) {
        if (payment.category != null && payment.category!.isNotEmpty) {
          categories.add(payment.category!);
        }
      }
    }
    return categories.toList()..sort();
  }

  void goToPreviousMonth() {
    _selectedMonth = monthOnly(DateTime.utc(_selectedMonth.year, _selectedMonth.month - 1));
    _touch();
  }

  void goToNextMonth() {
    _selectedMonth = monthOnly(DateTime.utc(_selectedMonth.year, _selectedMonth.month + 1));
    _touch();
  }

  void upsertPlannerItem(PlannerItem item) {
    _plannerItems = _replaceOrAddById<PlannerItem>(_plannerItems, item, (p) => p.id);
    _invalidatePlannerItemCaches();
    _touch();
  }

  void setPlannerItemArchived(String id, bool archived) {
    final index = _plannerItems.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final next = _plannerItems.toList(growable: true);
    next[index] = next[index].copyWith(archived: archived);
    _plannerItems = List.unmodifiable(next);

    if (!archived) {
      _payments = List.unmodifiable(_payments.where((p) => p.plannerItemId != id));
      _invalidatePaymentCache();
    }
    _invalidatePlannerItemCaches();
    _touch();
  }

  void deletePlannerItem(String id) {
    _plannerItems = List.unmodifiable(_plannerItems.where((p) => p.id != id));
    _payments = List.unmodifiable(_payments.where((p) => p.plannerItemId != id));
    _invalidatePlannerItemCaches();
    _invalidatePaymentCache();
    _touch();
  }

  void upsertPayment(PaymentEntry entry) {
    final normalized = entry.copyWith(date: dateOnly(entry.date));
    _payments = _replaceOrAddById<PaymentEntry>(_payments, normalized, (p) => p.id);
    _invalidatePaymentCache();
    _touch();
  }

  void markPlannerItemClearedTemporarily(String id, {Duration? duration}) {
    _recentlyClearedPlannerItemIds.add(id);
    _recentlyClearedTimers.remove(id)?.cancel();
    _recentlyClearedTimers[id] = Timer(
      duration ?? _kClearedVisibleDuration,
      () {
        if (_recentlyClearedPlannerItemIds.remove(id)) {
          notifyListeners();
        }
        _recentlyClearedTimers.remove(id)?.cancel();
      },
    );
    notifyListeners();
  }

  void clearPlannerItemClearedTemporarily(String id) {
    _recentlyClearedTimers.remove(id)?.cancel();
    if (_recentlyClearedPlannerItemIds.remove(id)) {
      notifyListeners();
    }
  }

  void deletePayment(String id) {
    _payments = List.unmodifiable(_payments.where((p) => p.id != id));
    _invalidatePaymentCache();
    _touch();
  }

  void clearAllData() {
    _selectedMonth = monthOnly(DateTime.now());
    _plannerItems = const [];
    _payments = const [];
    _invalidatePlannerItemCaches();
    _invalidatePaymentCache();
    _touch();
  }

  ExpenseSnapshot createSnapshot() => _snapshot();

  Future<bool> importSnapshot(ExpenseSnapshot snapshot) async {
    try {
      final persistence = _persistence ?? await ExpensePersistence.create();
      if (!persistence.validateSnapshot(snapshot)) return false;

      _selectedMonth = monthOnly(snapshot.selectedMonth);
      _plannerItems = List.unmodifiable(snapshot.plannerItems);
      _payments = List.unmodifiable(snapshot.payments);
      _invalidatePlannerItemCaches();
      _invalidatePaymentCache();
      _touch();
      return true;
    } catch (error, stackTrace) {
      debugLog(LogCategory.persistence, 'Failed to import snapshot', error: error, stackTrace: stackTrace);
      return false;
    }
  }

  void _invalidatePlannerItemCaches() {
    _cachedActivePlannerItems = null;
    _cachedArchivedPlannerItems = null;
  }

  void _invalidatePaymentCache() {
    _cachedSelectedMonthPayments = null;
    _cachedPaymentsCacheKey = null;
  }

  void _touch() {
    notifyListeners();
    _scheduleSave();
  }

  void _scheduleSave() {
    final persistence = _persistence;
    if (persistence == null) return;

    final accountId = _currentAccount.id;
    _debounceTimer?.cancel();
    _debounceTimer = Timer(_kSaveDebounce, () {
      _saveQueue.enqueue(() async {
        try {
          await persistence.save(accountId, _snapshot());
        } catch (error, stackTrace) {
          debugLog(LogCategory.persistence, 'Failed to save snapshot for account $accountId', error: error, stackTrace: stackTrace);
          ErrorTracker.instance.trackError(ErrorContext(
            category: 'persistence',
            message: 'Failed to save account $accountId',
            severity: ErrorSeverity.error,
            error: error,
            additionalData: {'stack': stackTrace.toString()},
          ));
        }
      });
    });
  }

  ExpenseSnapshot _snapshot() => ExpenseSnapshot(
    selectedMonth: _selectedMonth,
    plannerItems: _plannerItems,
    payments: _payments,
  );

  @override
  void dispose() {
    _debounceTimer?.cancel();
    for (final timer in _recentlyClearedTimers.values) timer.cancel();
    _recentlyClearedTimers.clear();
    _saveQueue.enqueue(() async {});
    _saveQueue.clear();
    super.dispose();
  }
}

class ExpenseStoreScope extends InheritedNotifier<ExpenseStore> {
  const ExpenseStoreScope({super.key, required ExpenseStore store, required super.child}) : super(notifier: store);

  static ExpenseStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<ExpenseStoreScope>();
    assert(scope != null, 'ExpenseStoreScope not found in widget tree.');
    return scope!.notifier!;
  }

  static ExpenseStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<ExpenseStoreScope>();
    assert(scope != null, 'ExpenseStoreScope not found in widget tree.');
    return scope!.notifier!;
  }
}
