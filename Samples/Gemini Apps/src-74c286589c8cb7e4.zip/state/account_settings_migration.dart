import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

/// Migrates global paycheck settings to account-specific settings.
/// This is a one-time migration that runs when the app starts.
class AccountSettingsMigration {
  static const _kMigrationCompleteKey = 'migration.accountSettingsComplete';
  static const _kPaycheckDay = 'settings.paycheckDay';
  static const _kPaycheckBusinessAdjust = 'settings.paycheck.businessAdjust';
  static const _kPaycheckBusinessAdjustDirection = 'settings.paycheck.businessAdjustDirection';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';

  /// Run the migration if it hasn't been done yet
  static Future<void> runIfNeeded(StorageProvider storage, ExpensePersistence persistence) async {
    final alreadyMigrated = await storage.getBool(_kMigrationCompleteKey) ?? false;
    if (alreadyMigrated) {
      debugLog(LogCategory.persistence, 'Account settings migration already complete');
      return;
    }

    await _migrate(storage, persistence);
    await storage.setBool(_kMigrationCompleteKey, true);
    debugLog(LogCategory.persistence, 'Account settings migration completed');
  }

  static Future<void> _migrate(StorageProvider storage, ExpensePersistence persistence) async {
    // Read existing global settings
    final paycheckDay = await storage.getInt(_kPaycheckDay);
    final paycheckBusinessAdjust = await storage.getBool(_kPaycheckBusinessAdjust) ?? true;
    final paycheckBusinessAdjustDirectionStr = await storage.getString(_kPaycheckBusinessAdjustDirection);
    final paycheckBusinessAdjustDirection = AppSettingsCodecs.decodeAdjustDirection(paycheckBusinessAdjustDirectionStr) 
        ?? PaycheckAdjustDirection.after;
    final startingBalanceCents = await storage.getInt(_kCurrentBalanceCents) ?? 0;

    // Apply to all existing accounts
    final accounts = await persistence.loadAccounts();
    if (accounts.isEmpty) {
      debugLog(LogCategory.persistence, 'No accounts to migrate settings to');
      return;
    }

    final updatedAccounts = accounts.map((account) {
      // Only update if the account doesn't already have settings
      if (account.paycheckDay != null) {
        return account; // Already has settings, skip
      }
      return account.copyWith(
        paycheckDay: paycheckDay,
        clearPaycheckDay: paycheckDay == null,
        paycheckBusinessAdjust: paycheckBusinessAdjust,
        paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
        startingBalanceCents: startingBalanceCents,
        lastModified: DateTime.now(),
      );
    }).toList();

    await persistence.saveAccounts(updatedAccounts);
    debugLog(LogCategory.persistence, 'Migrated settings to ${updatedAccounts.length} accounts');
  }
}

