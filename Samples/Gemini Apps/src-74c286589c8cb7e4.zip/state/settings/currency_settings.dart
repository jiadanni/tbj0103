import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

class CurrencySettings extends ChangeNotifier {
  CurrencySettings(this._storage, {
    required AppCurrency initialCurrency,
    required int initialBalanceCents,
    required bool initialShowCents,
    required int initialRoundingIncrement,
  }) : _currency = initialCurrency,
       _currentBalanceCents = initialBalanceCents,
       _showCents = initialShowCents,
       _roundingIncrement = initialRoundingIncrement;

  final StorageProvider _storage;

  static const _kCurrency = 'settings.currency';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';
  static const _kShowCents = 'settings.currency.showCents';
  static const _kRoundingIncrement = 'settings.currency.roundingIncrement';

  AppCurrency _currency;
  int _currentBalanceCents;
  bool _showCents;
  int _roundingIncrement;

  AppCurrency get currency => _currency;
  int get currentBalanceCents => _currentBalanceCents;
  bool get showCents => _showCents;
  int get roundingIncrement => _roundingIncrement;

  set currency(AppCurrency value) {
    if (_currency == value) return;
    _currency = value;
    _storage.setString(_kCurrency, encodeCurrency(value));
    notifyListeners();
  }

  set currentBalanceCents(int value) {
    if (_currentBalanceCents == value) return;
    _currentBalanceCents = value;
    _storage.setInt(_kCurrentBalanceCents, value);
    notifyListeners();
  }

  set showCents(bool value) {
    if (_showCents == value) return;
    _showCents = value;
    _storage.setBool(_kShowCents, value);
    notifyListeners();
  }

  set roundingIncrement(int value) {
    if (_roundingIncrement == value) return;
    _roundingIncrement = value;
    _storage.setInt(_kRoundingIncrement, value);
    notifyListeners();
  }
}
