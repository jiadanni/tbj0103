import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';

class PlannerSettings extends ChangeNotifier {
  PlannerSettings(this._storage, {
    required DayFormat initialDayFormat,
    required PlannerSwipeAction initialSwipeLeft,
    required PlannerSwipeAction initialSwipeRight,
    required PlannerTapAction initialTapAction,
    required PaymentSwipeAction initialPaymentSwipeLeft,
    required PaymentSwipeAction initialPaymentSwipeRight,
    required PaymentDisplayMode initialPaymentDisplayMode,
    required bool initialEnableTabSwipe,
    required bool initialUseZeroBaseline,
    required bool initialShowClearedItems,
    required PlannerSortOrder initialSortOrder,
    required PlannerDateSortMode initialDateSortMode,
    required ViewPeriodMode initialViewPeriodMode,
    required int? initialPaycheckDay,
    required bool initialPaycheckBusinessAdjust,
    required PaycheckAdjustDirection initialPaycheckBusinessAdjustDirection,
    required bool initialGroupByDate,
    required bool initialGroupByTheme,
    required bool initialShowPaymentOrigin,
    required MonthCardDisplayMode initialMonthCardDisplayMode,
    required MonthTotalsDisplayMode initialMonthTotalsDisplayMode,
    required MultiMonthDisplayMode initialMultiMonthDisplayMode,
    required TerminologyPreset initialTerminologyPreset,
    required PlannerViewMode initialViewMode,
    required PaymentsFilterType initialPaymentsFilterType,
    required PaymentsGroupBy initialPaymentsGroupBy,
    required bool initialPaymentsShowArchived,
    required CategoryPresetMode initialCategoryPresetMode,
  }) : _dayFormat = initialDayFormat,
       _plannerSwipeLeft = initialSwipeLeft,
       _plannerSwipeRight = initialSwipeRight,
       _plannerTapAction = initialTapAction,
       _paymentSwipeLeft = initialPaymentSwipeLeft,
       _paymentSwipeRight = initialPaymentSwipeRight,
       _paymentDisplayMode = initialPaymentDisplayMode,
       _enableTabSwipe = initialEnableTabSwipe,
       _plannerUseZeroBaseline = initialUseZeroBaseline,
       _plannerShowClearedItems = initialShowClearedItems,
       _plannerSortOrder = initialSortOrder,
       _plannerDateSortMode = initialDateSortMode,
       _viewPeriodMode = initialViewPeriodMode,
       _paycheckDay = initialPaycheckDay,
       _paycheckBusinessAdjust = initialPaycheckBusinessAdjust,
       _paycheckBusinessAdjustDirection = initialPaycheckBusinessAdjustDirection,
       _plannerGroupByDate = initialGroupByDate,
       _plannerGroupByTheme = initialGroupByTheme,
       _plannerShowPaymentOrigin = initialShowPaymentOrigin,
       _monthCardDisplayMode = initialMonthCardDisplayMode,
       _monthTotalsDisplayMode = initialMonthTotalsDisplayMode,
       _multiMonthDisplayMode = initialMultiMonthDisplayMode,
       _terminologyPreset = initialTerminologyPreset,
       _plannerViewMode = initialViewMode,
       _paymentsFilterType = initialPaymentsFilterType,
       _paymentsGroupBy = initialPaymentsGroupBy,
       _paymentsShowArchived = initialPaymentsShowArchived,
       _categoryPresetMode = initialCategoryPresetMode;

  final StorageProvider _storage;

  // Keys
  static const _kDayFormat = 'settings.dayFormat';
  static const _kPlannerSwipeLeft = 'settings.planner.swipeLeft';
  static const _kPlannerSwipeRight = 'settings.planner.swipeRight';
  static const _kPlannerTapAction = 'settings.planner.tapAction';
  static const _kPaymentSwipeLeft = 'settings.payment.swipeLeft';
  static const _kPaymentSwipeRight = 'settings.payment.swipeRight';
  static const _kPaymentDisplayMode = 'settings.payment.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kPlannerUseZeroBaseline = 'settings.planner.useZeroBaseline';
  static const _kPlannerShowClearedItems = 'settings.planner.showClearedItems';
  static const _kPlannerSortOrder = 'settings.planner.sortOrder';
  static const _kPlannerDateSortMode = 'settings.planner.dateSortMode';
  static const _kViewPeriodMode = 'settings.viewPeriodMode';
  static const _kPaycheckDay = 'settings.paycheckDay';
  static const _kPaycheckBusinessAdjust = 'settings.paycheck.businessAdjust';
  static const _kPaycheckBusinessAdjustDirection = 'settings.paycheck.businessAdjustDirection';
  static const _kPlannerGroupByDate = 'settings.planner.groupByDate';
  static const _kPlannerShowPaymentOrigin = 'settings.planner.showPaymentOrigin';
  static const _kPlannerGroupByTheme = 'settings.planner.groupByTheme';
  static const _kMonthCardDisplayMode = 'settings.planner.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode = 'settings.planner.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayMode = 'settings.planner.multiMonthDisplayMode';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kPlannerViewMode = 'settings.planner.viewMode';
  static const _kPaymentsFilterType = 'settings.payments.filterType';
  static const _kPaymentsGroupBy = 'settings.payments.groupBy';
  static const _kPaymentsShowArchived = 'settings.payments.showArchived';
  static const _kCategoryPresetMode = 'settings.planner.categoryPresetMode';

  DayFormat _dayFormat;
  PlannerSwipeAction _plannerSwipeLeft;
  PlannerSwipeAction _plannerSwipeRight;
  PlannerTapAction _plannerTapAction;
  PaymentSwipeAction _paymentSwipeLeft;
  PaymentSwipeAction _paymentSwipeRight;
  PaymentDisplayMode _paymentDisplayMode;
  bool _enableTabSwipe;
  bool _plannerUseZeroBaseline;
  bool _plannerShowClearedItems;
  PlannerSortOrder _plannerSortOrder;
  PlannerDateSortMode _plannerDateSortMode;
  ViewPeriodMode _viewPeriodMode;
  int? _paycheckDay;
  bool _paycheckBusinessAdjust;
  PaycheckAdjustDirection _paycheckBusinessAdjustDirection;
  bool _plannerGroupByDate;
  bool _plannerGroupByTheme;
  bool _plannerShowPaymentOrigin;
  MonthCardDisplayMode _monthCardDisplayMode;
  MonthTotalsDisplayMode _monthTotalsDisplayMode;
  MultiMonthDisplayMode _multiMonthDisplayMode;
  TerminologyPreset _terminologyPreset;
  PlannerViewMode _plannerViewMode;
  PaymentsFilterType _paymentsFilterType;
  PaymentsGroupBy _paymentsGroupBy;
  bool _paymentsShowArchived;
  CategoryPresetMode _categoryPresetMode;

  DayFormat get dayFormat => _dayFormat;
  PlannerSwipeAction get plannerSwipeLeft => _plannerSwipeLeft;
  PlannerSwipeAction get plannerSwipeRight => _plannerSwipeRight;
  PlannerTapAction get plannerTapAction => _plannerTapAction;
  PaymentSwipeAction get paymentSwipeLeft => _paymentSwipeLeft;
  PaymentSwipeAction get paymentSwipeRight => _paymentSwipeRight;
  PaymentDisplayMode get paymentDisplayMode => _paymentDisplayMode;
  bool get enableTabSwipe => _enableTabSwipe;
  bool get plannerUseZeroBaseline => _plannerUseZeroBaseline;
  bool get plannerShowClearedItems => _plannerShowClearedItems;
  PlannerSortOrder get plannerSortOrder => _plannerSortOrder;
  PlannerDateSortMode get plannerDateSortMode => _plannerDateSortMode;
  ViewPeriodMode get viewPeriodMode => _viewPeriodMode;
  int? get paycheckDay => _paycheckDay;
  bool get isPaycheckModeConfigured => _paycheckDay != null;
  bool get paycheckBusinessAdjust => _paycheckBusinessAdjust;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection => _paycheckBusinessAdjustDirection;
  bool get plannerGroupByDate => _plannerGroupByDate;
  bool get plannerGroupByTheme => _plannerGroupByTheme;
  bool get plannerShowPaymentOrigin => _plannerShowPaymentOrigin;
  MonthCardDisplayMode get monthCardDisplayMode => _monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => _monthTotalsDisplayMode;
  MultiMonthDisplayMode get multiMonthDisplayMode => _multiMonthDisplayMode;
  TerminologyPreset get terminologyPreset => _terminologyPreset;
  PlannerViewMode get plannerViewMode => _plannerViewMode;
  PaymentsFilterType get paymentsFilterType => _paymentsFilterType;
  PaymentsGroupBy get paymentsGroupBy => _paymentsGroupBy;
  bool get paymentsShowArchived => _paymentsShowArchived;
  CategoryPresetMode get categoryPresetMode => _categoryPresetMode;

  set dayFormat(DayFormat value) {
    if (_dayFormat == value) return;
    _dayFormat = value;
    _storage.setString(_kDayFormat, AppSettingsCodecs.encodeDayFormat(value));
    notifyListeners();
  }

  set plannerSwipeLeft(PlannerSwipeAction value) {
    if (_plannerSwipeLeft == value) return;
    _plannerSwipeLeft = value;
    _storage.setString(_kPlannerSwipeLeft, AppSettingsCodecs.encodeSwipeAction(value));
    notifyListeners();
  }

  set plannerSwipeRight(PlannerSwipeAction value) {
    if (_plannerSwipeRight == value) return;
    _plannerSwipeRight = value;
    _storage.setString(_kPlannerSwipeRight, AppSettingsCodecs.encodeSwipeAction(value));
    notifyListeners();
  }

  set plannerTapAction(PlannerTapAction value) {
    if (_plannerTapAction == value) return;
    _plannerTapAction = value;
    _storage.setString(_kPlannerTapAction, AppSettingsCodecs.encodePlannerTapAction(value));
    notifyListeners();
  }

  set paymentSwipeLeft(PaymentSwipeAction value) {
    if (_paymentSwipeLeft == value) return;
    _paymentSwipeLeft = value;
    _storage.setString(_kPaymentSwipeLeft, AppSettingsCodecs.encodePaymentSwipeAction(value));
    notifyListeners();
  }

  set paymentSwipeRight(PaymentSwipeAction value) {
    if (_paymentSwipeRight == value) return;
    _paymentSwipeRight = value;
    _storage.setString(_kPaymentSwipeRight, AppSettingsCodecs.encodePaymentSwipeAction(value));
    notifyListeners();
  }

  set paymentDisplayMode(PaymentDisplayMode value) {
    if (_paymentDisplayMode == value) return;
    _paymentDisplayMode = value;
    _storage.setString(_kPaymentDisplayMode, AppSettingsCodecs.encodePaymentDisplayMode(value));
    notifyListeners();
  }

  set enableTabSwipe(bool value) {
    if (_enableTabSwipe == value) return;
    _enableTabSwipe = value;
    _storage.setBool(_kEnableTabSwipe, value);
    notifyListeners();
  }

  set plannerUseZeroBaseline(bool value) {
    if (_plannerUseZeroBaseline == value) return;
    _plannerUseZeroBaseline = value;
    _storage.setBool(_kPlannerUseZeroBaseline, value);
    notifyListeners();
  }

  set plannerShowClearedItems(bool value) {
    if (_plannerShowClearedItems == value) return;
    _plannerShowClearedItems = value;
    _storage.setBool(_kPlannerShowClearedItems, value);
    notifyListeners();
  }

  set plannerSortOrder(PlannerSortOrder value) {
    if (_plannerSortOrder == value) return;
    _plannerSortOrder = value;
    _storage.setString(_kPlannerSortOrder, AppSettingsCodecs.encodeSortOrder(value));
    notifyListeners();
  }

  set plannerDateSortMode(PlannerDateSortMode value) {
    if (_plannerDateSortMode == value) return;
    _plannerDateSortMode = value;
    _storage.setString(_kPlannerDateSortMode, AppSettingsCodecs.encodePlannerDateSortMode(value));
    notifyListeners();
  }

  set viewPeriodMode(ViewPeriodMode value) {
    if (_viewPeriodMode == value) return;
    _viewPeriodMode = value;
    _storage.setString(_kViewPeriodMode, AppSettingsCodecs.encodeViewPeriodMode(value));
    notifyListeners();
  }

  set paycheckDay(int? value) {
    if (_paycheckDay == value) return;
    if (value == null) {
      _paycheckDay = null;
      _storage.remove(_kPaycheckDay);
    } else {
      _paycheckDay = value.clamp(1, 31);
      _storage.setInt(_kPaycheckDay, _paycheckDay!);
    }
    notifyListeners();
  }

  set paycheckBusinessAdjust(bool value) {
    if (_paycheckBusinessAdjust == value) return;
    _paycheckBusinessAdjust = value;
    _storage.setBool(_kPaycheckBusinessAdjust, value);
    notifyListeners();
  }

  set paycheckBusinessAdjustDirection(PaycheckAdjustDirection value) {
    if (_paycheckBusinessAdjustDirection == value) return;
    _paycheckBusinessAdjustDirection = value;
    _storage.setString(
      _kPaycheckBusinessAdjustDirection,
      AppSettingsCodecs.encodeAdjustDirection(value),
    );
    notifyListeners();
  }

  set plannerGroupByDate(bool value) {
    if (_plannerGroupByDate == value) return;
    _plannerGroupByDate = value;
    _storage.setBool(_kPlannerGroupByDate, value);
    notifyListeners();
  }

  set plannerGroupByTheme(bool value) {
    if (_plannerGroupByTheme == value) return;
    _plannerGroupByTheme = value;
    _storage.setBool(_kPlannerGroupByTheme, value);
    notifyListeners();
  }

  set plannerShowPaymentOrigin(bool value) {
    if (_plannerShowPaymentOrigin == value) return;
    _plannerShowPaymentOrigin = value;
    _storage.setBool(_kPlannerShowPaymentOrigin, value);
    notifyListeners();
  }

  set monthCardDisplayMode(MonthCardDisplayMode value) {
    if (_monthCardDisplayMode == value) return;
    _monthCardDisplayMode = value;
    _storage.setString(_kMonthCardDisplayMode, AppSettingsCodecs.encodeMonthCardDisplayMode(value));
    notifyListeners();
  }

  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) {
    if (_monthTotalsDisplayMode == value) return;
    _monthTotalsDisplayMode = value;
    _storage.setString(
      _kMonthTotalsDisplayMode,
      AppSettingsCodecs.encodeMonthTotalsDisplayMode(value),
    );
    notifyListeners();
  }

  set multiMonthDisplayMode(MultiMonthDisplayMode value) {
    if (_multiMonthDisplayMode == value) return;
    _multiMonthDisplayMode = value;
    _storage.setString(_kMultiMonthDisplayMode, AppSettingsCodecs.encodeMultiMonthDisplayMode(value));
    notifyListeners();
  }

  set terminologyPreset(TerminologyPreset value) {
    if (_terminologyPreset == value) return;
    _terminologyPreset = value;
    _storage.setString(_kTerminologyPreset, AppSettingsCodecs.encodeTerminologyPreset(value));
    notifyListeners();
  }

  set plannerViewMode(PlannerViewMode value) {
    if (_plannerViewMode == value) return;
    _plannerViewMode = value;
    _storage.setString(_kPlannerViewMode, AppSettingsCodecs.encodePlannerViewMode(value));
    notifyListeners();
  }

  set paymentsFilterType(PaymentsFilterType value) {
    if (_paymentsFilterType == value) return;
    _paymentsFilterType = value;
    _storage.setString(_kPaymentsFilterType, AppSettingsCodecs.encodePaymentsFilterType(value));
    notifyListeners();
  }

  set paymentsGroupBy(PaymentsGroupBy value) {
    if (_paymentsGroupBy == value) return;
    _paymentsGroupBy = value;
    _storage.setString(_kPaymentsGroupBy, AppSettingsCodecs.encodePaymentsGroupBy(value));
    notifyListeners();
  }

  set paymentsShowArchived(bool value) {
    if (_paymentsShowArchived == value) return;
    _paymentsShowArchived = value;
    _storage.setBool(_kPaymentsShowArchived, value);
    notifyListeners();
  }

  set categoryPresetMode(CategoryPresetMode value) {
    if (_categoryPresetMode == value) return;
    _categoryPresetMode = value;
    _storage.setString(
      _kCategoryPresetMode,
      AppSettingsCodecs.encodeCategoryPresetMode(value),
    );
    notifyListeners();
  }
}
