import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

class MoneyPotsSettings extends ChangeNotifier {
  MoneyPotsSettings(
    this._storage, {
    required List<MoneyPot> initialMoneyPots,
    String? initialSectionLabel,
  }) : _moneyPots = initialMoneyPots,
       _sectionLabel = initialSectionLabel ?? 'Money Pots';

  final StorageProvider _storage;

  static const _kMoneyPots = 'settings.moneyPots';
  static const _kSectionLabel = 'settings.moneyPots.sectionLabel';
  static const defaultSectionLabel = 'Money Pots';

  List<MoneyPot> _moneyPots;
  String _sectionLabel;

  List<MoneyPot> get moneyPots => List.unmodifiable(_moneyPots);
  
  String get sectionLabel => _sectionLabel;
  
  set sectionLabel(String value) {
    if (_sectionLabel == value) return;
    _sectionLabel = value;
    _storage.setString(_kSectionLabel, value);
    notifyListeners();
  }

  void addMoneyPot(MoneyPot pot) {
    _moneyPots = [..._moneyPots, pot];
    _save();
    notifyListeners();
  }

  void updateMoneyPot(MoneyPot pot) {
    final index = _moneyPots.indexWhere((p) => p.id == pot.id);
    if (index != -1) {
      final newPots = List<MoneyPot>.from(_moneyPots);
      newPots[index] = pot;
      _moneyPots = newPots;
      _save();
      notifyListeners();
    }
  }

  void removeMoneyPot(String id) {
    _moneyPots = _moneyPots.where((p) => p.id != id).toList();
    _save();
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final jsonList = _moneyPots.map((p) => p.toJson()).toList();
      await _storage.setString(_kMoneyPots, jsonEncode(jsonList));
    } catch (e, stack) {
      debugLog(LogCategory.persistence, 'Failed to save money pots', error: e, stackTrace: stack);
    }
  }
}
