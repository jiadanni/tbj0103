
import 'package:expense_stalker_mobile/src/models/currency.dart';

enum DayFormat {
  number, // e.g., "1", "2", "28"
  ordinal, // e.g., "1st", "2nd", "28th"
}

enum PaymentDisplayMode {
  automatic, // Auto-fit based on zoom level
  full, // Full name: "Monthly Rent"
  acronym, // Acronym: "MR"
  icon, // Icon only
}

/// Display mode for month card view (no icon option - doesn't work well with categories)
enum MonthCardDisplayMode {
  full, // Full name: "Monthly Rent"
  acronym, // Acronym: "MR"
}

/// Display mode for month totals in single month view.
enum MonthTotalsDisplayMode {
  includeCleared, // Totals include cleared items
  showClearedRow, // Totals include cleared items + extra cleared row
}

/// Display mode for multi-month grid view (optional override or automatic)
enum MultiMonthDisplayMode {
  automatic, // Auto-fit based on zoom level (uses effectiveDisplayMode)
  full, // Full name
  acronym, // Acronym
  icon, // Icon only
}

enum PlannerSwipeAction { off, edit, archive }

enum PlannerTapAction { archive, menu }

enum PaymentSwipeAction { off, edit, delete }

enum PlannerSortOrder { chronological, reverseChronological }

enum PlannerDateSortMode {
  scheduledDate, // Sort by when payments were supposed to happen
  actualDate,    // Sort by when payments were actually recorded
}

enum ViewPeriodMode {
  calendar, // Traditional calendar month (1st - last day)
  paycheck, // Custom period based on payday (e.g., 25th - 24th)
}

enum PaycheckAdjustDirection { before, after }


/// Color preset options for debit/credit amounts
enum ColorPreset {
  classic,    // Red / Green (default)
  ocean,      // Coral / Teal
  sunset,     // Orange / Purple
  monochrome, // Gray tones
  forest,     // Brown / Forest Green
  berry,      // Pink / Cyan
  lavender,   // Purple / Lime
  earth,      // Rust / Olive
  mint,       // Magenta / Mint
  warm,       // Amber / Sky Blue
  custom,     // User-defined colors
}

/// Preset options for the overall app theme (primary color)
enum AppThemePreset {
  classic,    // Indigo (Original)
  ocean,      // Teal
  sunset,     // Deep Orange
  monochrome, // BlueGrey (Default)
  forest,     // Green
  berry,      // Pink/Magenta
  lavender,   // Purple
  midnight,   // Deep Blue
  rose,       // Rose/Coral
  mint,       // Mint Green
}

/// Terminology presets for customizing UI labels
enum TerminologyPreset {
  defaultTerms,  // "Scheduled", "Paid", "Mark Paid"
  bills,         // "Bills", "Paid", "Mark Paid"
  budget,        // "Budget", "Done", "Mark Done"
}

enum TextScalePreset {
  small,
  normal,
  large,
  extraLarge,
}

enum FontPreset {
  system,
  monospace,
}

/// View mode for the planner screen (single month, grid, or spreadsheet)
enum PlannerViewMode {
  month,      // Single month with PageView
  grid,       // Multi-month grid view
  sheet,      // Horizontal spreadsheet view
}

/// Filter options for the payments/scheduled screen
enum PaymentsFilterType {
  all,              // Show all items
  income,           // Show only income items (recurring + one-off)
  expenses,         // Show only expense items (recurring + one-off)
  debt,             // Show only debt items
  oneOff,           // Show only one-off items (income + expense)
  recurring,        // Show only recurring items (income + expense)
}

/// Grouping options for the payments/scheduled screen
enum PaymentsGroupBy {
  none,             // No grouping (flat list)
  category,         // Group by income/expense category
  type,             // Group by payment type
  company,          // Group by company/provider
  dueDate,          // Group by next due date
}

/// Modes for category suggestions
enum CategoryPresetMode {
  defaultPresets,   // Use predefined categories (default)
  customOnly,       // Use only categories already used by the user
  both,             // Use both predefined and user categories
}

class RegionPreset {
  const RegionPreset({
    required this.id,
    required this.label,
    this.currency,
    this.dayFormat,
  });

  final String id;
  final String label;
  final AppCurrency? currency;
  final DayFormat? dayFormat;
}
