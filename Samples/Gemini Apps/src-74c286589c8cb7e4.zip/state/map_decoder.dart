class MapDecoder {
  final Map<String, Object?> map;

  MapDecoder(this.map);

  String? getString(String key) {
    final value = map[key];
    return value is String ? value : null;
  }

  String requireString(String key) {
    final v = getString(key);
    if (v == null) throw FormatException('Missing required string for "$key"');
    return v;
  }

  int? getInt(String key) {
    final v = map[key];
    if (v is int) return v;
    if (v is String) return int.tryParse(v);
    return null;
  }

  int requireInt(String key) {
    final v = getInt(key);
    if (v == null) throw FormatException('Missing required int for "$key"');
    return v;
  }

  bool? getBool(String key) {
    final v = map[key];
    if (v is bool) return v;
    if (v is String) return v.toLowerCase() == 'true';
    return null;
  }

  DateTime? getIsoDateTime(String key) {
    final s = getString(key);
    if (s == null) return null;
    try {
      return DateTime.parse(s).toLocal();
    } catch (_) {
      return null;
    }
  }

  DateTime? getMillisDate(String key) {
    final v = map[key];
    if (v is int) return DateTime.fromMillisecondsSinceEpoch(v);
    if (v is String) {
      final parsed = int.tryParse(v);
      if (parsed != null) return DateTime.fromMillisecondsSinceEpoch(parsed);
    }
    return null;
  }

  double? getDouble(String key) {
    final v = map[key];
    if (v is double) return v;
    if (v is int) return v.toDouble();
    if (v is String) return double.tryParse(v);
    return null;
  }
}
