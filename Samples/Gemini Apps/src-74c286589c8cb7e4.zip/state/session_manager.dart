import 'dart:async';
import 'package:flutter/widgets.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';

/// Manages user session and lock functionality.
///
/// Handles app lock state when resuming from background.
/// Note: Autolock (inactivity timeout) has been removed as device lock handles this.
class SessionManager extends ChangeNotifier {
  SessionManager(this._authService);

  final AuthService _authService;

  DateTime? _lastStandbyTime;
  bool _isLocked = true;
  VoidCallback? _onLockCallback;

  /// Whether the app is currently locked.
  bool get isLocked => _isLocked;

  /// Start monitoring session activity.
  Future<void> startSession(BuildContext context, {VoidCallback? onLock}) async {
    _onLockCallback = onLock;

    if (!await _authService.isAuthEnabled()) {
      _isLocked = false;
      notifyListeners();
      return;
    }

    _isLocked = false;
    notifyListeners();
  }

  /// Record that the app is going to standby (background).
  /// Does NOT immediately lock - just records the time for grace period calculation.
  Future<void> enterStandby() async {
    if (!await _authService.isAuthEnabled()) return;
    _lastStandbyTime = DateTime.now();
  }

  /// Called when app returns from background. Checks if grace period has expired.
  /// Returns true if the app should be locked, false if within grace period.
  Future<bool> shouldLockOnResume() async {
    if (!await _authService.isAuthEnabled()) return false;
    if (_lastStandbyTime == null) return false;

    final delaySeconds = await _authService.getDelayBeforeAuthSeconds();
    final timeSinceStandby = DateTime.now().difference(_lastStandbyTime!).inSeconds;

    // If within grace period, don't lock
    if (timeSinceStandby < delaySeconds) {
      _lastStandbyTime = null; // Clear standby time
      return false;
    }

    // Grace period expired, lock the app
    return true;
  }

  /// Lock the session immediately.
  Future<void> lock() async {
    if (!await _authService.isAuthEnabled()) return;

    _isLocked = true;
    notifyListeners();
    _onLockCallback?.call();
  }

  /// Unlock the session after successful authentication.
  void unlock() {
    _isLocked = false;
    _lastStandbyTime = null;
    notifyListeners();
  }

  /// Stop the session (cleanup).
  void stopSession() {
    // No-op - autolock timer removed
  }

  @override
  void dispose() {
    stopSession();
    super.dispose();
  }
}
