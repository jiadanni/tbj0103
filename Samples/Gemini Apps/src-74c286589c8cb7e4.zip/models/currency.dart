/// Metadata about a currency's formatting requirements.
///
/// This abstraction supports currencies with different subunit ratios:
/// - Most currencies (USD, EUR, GBP): 100 subunits per unit (cents)
/// - Zero-decimal currencies (JPY, VND, KRW): 1 subunit per unit (no decimals)
/// - Three-decimal currencies (KWD, BHD, OMR): 1000 subunits per unit (fils)
class CurrencyInfo {
  const CurrencyInfo({
    required this.code,
    required this.symbol,
    required this.decimalDigits,
    required this.subunitRatio,
    this.symbolPosition = SymbolPosition.before,
    this.groupSeparator = ',',
    this.decimalSeparator = '.',
  });

  /// ISO 4217 currency code (e.g., "USD", "EUR", "VND").
  final String code;

  /// Currency symbol for display (e.g., "$", "€", "₫").
  final String symbol;

  /// Number of decimal places to display (0, 2, or 3).
  final int decimalDigits;

  /// How many minor units make up one major unit.
  /// - 100 for most currencies (cents)
  /// - 1 for zero-decimal currencies (yen, dong)
  /// - 1000 for three-decimal currencies (dinar)
  final int subunitRatio;

  /// Whether symbol appears before or after the amount.
  final SymbolPosition symbolPosition;

  /// Character used to separate thousands (e.g., "," or ".").
  final String groupSeparator;

  /// Character used for decimal point (e.g., "." or ",").
  final String decimalSeparator;

  /// Converts a major unit value (e.g., 12.50) to minor units (e.g., 1250).
  int toMinorUnits(double majorUnits) {
    return (majorUnits * subunitRatio).round();
  }

  /// Converts minor units (e.g., 1250) to major units (e.g., 12.50).
  double toMajorUnits(int minorUnits) {
    return minorUnits / subunitRatio;
  }
}

/// Position of currency symbol relative to amount.
enum SymbolPosition {
  before, // $100
  after,  // 100€
}

/// Supported currencies in the app.
///
/// When adding new currencies, also add their metadata to [currencyInfo].
enum AppCurrency {
  eur,
  usd,
  gbp,
}

/// Currency metadata lookup.
///
/// Provides formatting information for each supported currency.
/// When adding new currencies to [AppCurrency], add corresponding
/// metadata here.
const Map<AppCurrency, CurrencyInfo> currencyInfo = {
  AppCurrency.eur: CurrencyInfo(
    code: 'EUR',
    symbol: '€',
    decimalDigits: 2,
    subunitRatio: 100,
  ),
  AppCurrency.usd: CurrencyInfo(
    code: 'USD',
    symbol: r'$',
    decimalDigits: 2,
    subunitRatio: 100,
  ),
  AppCurrency.gbp: CurrencyInfo(
    code: 'GBP',
    symbol: '£',
    decimalDigits: 2,
    subunitRatio: 100,
  ),
};

/// Gets the [CurrencyInfo] for a currency, with fallback to USD.
CurrencyInfo getCurrencyInfo(AppCurrency currency) {
  return currencyInfo[currency] ?? currencyInfo[AppCurrency.usd]!;
}

String currencyLabel(AppCurrency currency) {
  final info = getCurrencyInfo(currency);
  return '${info.code} (${info.symbol})';
}

String currencySymbol(AppCurrency currency) {
  return getCurrencyInfo(currency).symbol;
}

/// Returns the number of decimal digits for a currency.
int currencyDecimalDigits(AppCurrency currency) {
  return getCurrencyInfo(currency).decimalDigits;
}

/// Returns the subunit ratio for a currency (e.g., 100 for cents).
int currencySubunitRatio(AppCurrency currency) {
  return getCurrencyInfo(currency).subunitRatio;
}

String encodeCurrency(AppCurrency currency) => currency.name;

AppCurrency? decodeCurrency(String? raw) {
  return switch (raw) {
    'eur' => AppCurrency.eur,
    'usd' => AppCurrency.usd,
    'gbp' => AppCurrency.gbp,
    _ => null,
  };
}
