import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;

enum RecurrenceFrequency {
  weekly('Weekly'),
  biweekly('Bi-weekly'),
  monthly('Monthly'),
  quarterly('Quarterly'),
  yearly('Yearly');

  const RecurrenceFrequency(this.label);
  final String label;
}

class PlannerItem extends Equatable {
  const PlannerItem({
    required this.id,
    required this.label,
    required this.amountMinorUnits,
    required this.dayOfMonth,
    required this.type,
    required this.startDate,
    this.frequency,
    this.notes,
    this.archived = false,
    this.paidOffDate,
    this.remainingBalanceCents,
    this.originalAmountCents,
    this.category,
    this.company,
    this.isSalary = false,
    this.useAsPaycheckBoundary = false,
    this.moneyPotId,
    this.isQuickAdd = false,
    this.balanceCurrency,
    this.exchangeRate,
  });

  final String id;
  final String label;
  final int amountMinorUnits;
  final int dayOfMonth;
  final DateTime startDate;
  final String? notes;
  final PaymentType type;
  final RecurrenceFrequency? frequency;
  final bool archived;
  final DateTime? paidOffDate;
  final int? remainingBalanceCents;
  final int? originalAmountCents;

  /// Optional category for organizing items (e.g., "Housing", "Food", "Salary").
  /// Unified with PaymentEntry category handling.
  final String? category;

  /// Optional company/provider name (e.g., "Electric Co", "Comcast", "Acme Corp").
  /// Tracks the source or destination of the payment.
  final String? company;

  /// Whether this income item is a primary salary source.
  /// Used to identify salary payments and optionally sync paycheck period settings.
  /// Only meaningful for recurringIncome type items.
  final bool isSalary;

  /// Whether this salary defines a paycheck period boundary.
  /// Multiple salaries can be boundaries simultaneously (e.g., dual-income households).
  /// Only meaningful for recurringIncome type items marked as isSalary.
  final bool useAsPaycheckBoundary;

  /// ID of the Money Pot linked to this planner item.
  /// If set, the item's remaining balance may be synced with the pot.
  final String? moneyPotId;

  /// Whether this item should appear in the "Quick Add" menu on the planner screen.
  final bool isQuickAdd;

  /// Currency code for the remaining balance (e.g., usd, eur).
  /// If null, the balance is in the app's default currency.
  final AppCurrency? balanceCurrency;

  /// Exchange rate: how many balance currency units per 1 payment currency unit.
  /// Example: If loan is in USD and you pay in EUR, rate of 1.08 means 1 EUR = 1.08 USD.
  /// Used in payoff calculations to convert payment amounts.
  final double? exchangeRate;

  PlannerItem copyWith({
    String? label,
    int? amountMinorUnits,
    int? dayOfMonth,
    DateTime? startDate,
    Object? notes = sentinel,
    PaymentType? type,
    Object? frequency = sentinel,
    bool? archived,
    Object? paidOffDate = sentinel,
    Object? remainingBalanceCents = sentinel,
    Object? originalAmountCents = sentinel,
    Object? category = sentinel,
    Object? company = sentinel,
    bool? isSalary,
    bool? useAsPaycheckBoundary,
    Object? moneyPotId = sentinel,
    bool? isQuickAdd,
    Object? balanceCurrency = sentinel,
    Object? exchangeRate = sentinel,
  }) {
    return PlannerItem(
      id: id,
      label: label ?? this.label,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      dayOfMonth: dayOfMonth ?? this.dayOfMonth,
      startDate: startDate ?? this.startDate,
      notes: notes == sentinel ? this.notes : notes as String?,
      type: type ?? this.type,
      frequency:
          frequency == sentinel ? this.frequency : frequency as RecurrenceFrequency?,
      archived: archived ?? this.archived,
      paidOffDate:
          paidOffDate == sentinel ? this.paidOffDate : paidOffDate as DateTime?,
      remainingBalanceCents: remainingBalanceCents == sentinel
          ? this.remainingBalanceCents
          : remainingBalanceCents as int?,
      originalAmountCents: originalAmountCents == sentinel
          ? this.originalAmountCents
          : originalAmountCents as int?,
      category: category == sentinel ? this.category : category as String?,
      company: company == sentinel ? this.company : company as String?,
      isSalary: isSalary ?? this.isSalary,
      useAsPaycheckBoundary:
          useAsPaycheckBoundary ?? this.useAsPaycheckBoundary,
      moneyPotId:
          moneyPotId == sentinel ? this.moneyPotId : moneyPotId as String?,
      isQuickAdd: isQuickAdd ?? this.isQuickAdd,
      balanceCurrency: balanceCurrency == sentinel
          ? this.balanceCurrency
          : balanceCurrency as AppCurrency?,
      exchangeRate:
          exchangeRate == sentinel ? this.exchangeRate : exchangeRate as double?,
    );
  }

  @override
  List<Object?> get props => [id, label, amountMinorUnits, dayOfMonth, startDate, notes, type, frequency, archived, paidOffDate, remainingBalanceCents, originalAmountCents, category, company, isSalary, useAsPaycheckBoundary, moneyPotId, isQuickAdd, balanceCurrency, exchangeRate];

  /// Determines if this planner item should be displayed in a given month.
  ///
  /// Uses the `startDate` to determine when items should begin appearing.
  /// All items respect their start date - they won't appear before it.
  ///
  /// **Semantics by PaymentType:**
  /// - `oneOff`: Only appears in the month matching startDate
  /// - `debt`: Appears from startDate onwards until paid off
  /// - `recurring`: Appears based on frequency starting from startDate:
  ///   - `monthly`: Every month
  ///   - `quarterly`: Every 3 months on calendar quarter months
  ///   - `yearly`: Once per year
  ///   - `weekly`/`biweekly`: Every month (sub-monthly scheduling not yet supported)
  bool shouldAppearInMonth(DateTime month) {
    // Normalize to month-only for comparison (using UTC)
    final normalizedMonth = DateMath.toUtcMonth(month);
    final normalizedStart = DateMath.toUtcMonth(startDate);
    
    // Item shouldn't appear before its start date
    if (normalizedMonth.isBefore(normalizedStart)) {
      return false;
    }
    
    // One-off items only appear in their start month
    if (type == PaymentType.oneOff || type == PaymentType.oneOffIncome) {
      return normalizedMonth.year == normalizedStart.year &&
             normalizedMonth.month == normalizedStart.month;
    }
    
    // Debt items appear from start date until paid off
    if (type == PaymentType.debt) {
      if (paidOffDate != null) {
        final normalizedPaidOff = DateMath.toUtcMonth(paidOffDate!);
        return !normalizedMonth.isAfter(normalizedPaidOff);
      }

      if (remainingBalanceCents != null && remainingBalanceCents! <= 0) {
        return false;
      }
      
      // If no manual paid off date, use calculated final payment date
      final calculatedFinalDate = calculateFinalPaymentDate();
      if (calculatedFinalDate != null) {
        final normalizedFinalDate = DateMath.toUtcMonth(calculatedFinalDate);
        return !normalizedMonth.isAfter(normalizedFinalDate);
      }
      
      return true;
    }
    
    // Spending envelopes and recurring items depend on frequency
    // Both follow the same appearance logic based on their frequency setting
    if (type == PaymentType.spendingEnvelope || 
        type == PaymentType.recurring || 
        type == PaymentType.recurringIncome) {
      if (frequency == null) {
        // No frequency specified, appear every month
        return true;
      }
      
      final monthsSinceStart = (normalizedMonth.year - normalizedStart.year) * 12 +
                               (normalizedMonth.month - normalizedStart.month);
      
      switch (frequency!) {
        case RecurrenceFrequency.weekly:
        case RecurrenceFrequency.biweekly:
        case RecurrenceFrequency.monthly:
          return true; // Appear every month
        case RecurrenceFrequency.quarterly:
          final firstQuarterlyDate = _firstQuarterlyPaymentDate();
          final normalizedFirst = DateMath.toUtcMonth(firstQuarterlyDate);
          if (normalizedMonth.isBefore(normalizedFirst)) return false;
          final monthsSinceFirst = month_math.monthsBetween(
            normalizedFirst,
            normalizedMonth,
          );
          return monthsSinceFirst % 3 == 0;
        case RecurrenceFrequency.yearly:
          return monthsSinceStart % 12 == 0;
      }
    }
    
    // Fallback: Recurring items depend on frequency (legacy path)
    
    final monthsSinceStart = (normalizedMonth.year - normalizedStart.year) * 12 +
                             (normalizedMonth.month - normalizedStart.month);
    
    switch (frequency!) {
      case RecurrenceFrequency.weekly:
      case RecurrenceFrequency.biweekly:
      case RecurrenceFrequency.monthly:
        return true; // Appear every month
      case RecurrenceFrequency.quarterly:
        final firstQuarterlyDate = _firstQuarterlyPaymentDate();
        final normalizedFirst = DateMath.toUtcMonth(firstQuarterlyDate);
        if (normalizedMonth.isBefore(normalizedFirst)) return false;
        final monthsSinceFirst = month_math.monthsBetween(
          normalizedFirst,
          normalizedMonth,
        );
        return monthsSinceFirst % 3 == 0;
      case RecurrenceFrequency.yearly:
        return monthsSinceStart % 12 == 0;
    }
  }

  /// Calculates the first quarterly payment date on or after [startDate].
  ///
  /// Quarterly months are: March (3), June (6), September (9), December (12).
  /// The formula `(3 - (month % 3)) % 3` gives months to next quarter:
  /// - Jan (1) → 2 months to Mar
  /// - Feb (2) → 1 month to Mar
  /// - Mar (3) → 0 months (already quarterly)
  /// - Apr (4) → 2 months to Jun
  /// - ...
  /// - Dec (12) → 0 months (already quarterly)
  ///
  /// Handles year transitions correctly via [month_math.addMonths].
  DateTime _firstQuarterlyPaymentDate() {
    final start = DateMath.toUtcDate(startDate);
    final startMonth = start.month;

    // Calculate months until the next quarterly month (Mar, Jun, Sep, Dec)
    final monthsToNextQuarter = (3 - (startMonth % 3)) % 3;
    final firstQuarterMonth = month_math.addMonths(
      DateTime.utc(start.year, start.month, 1),
      monthsToNextQuarter,
    );

    // Use effective day (handle months with fewer days, e.g., dayOfMonth=31 in Feb)
    final firstQuarterDay = _effectiveDayOfMonth(
      firstQuarterMonth.year,
      firstQuarterMonth.month,
    );

    var candidate = DateTime.utc(
      firstQuarterMonth.year,
      firstQuarterMonth.month,
      firstQuarterDay,
    );

    // Edge case: if the quarterly month matches but the day is before startDate's day,
    // we need to advance to the next quarter
    if (candidate.isBefore(start)) {
      final nextQuarterMonth = month_math.addMonths(
        DateTime.utc(candidate.year, candidate.month, 1),
        3,
      );
      final nextQuarterDay = _effectiveDayOfMonth(
        nextQuarterMonth.year,
        nextQuarterMonth.month,
      );
      candidate = DateTime.utc(
        nextQuarterMonth.year,
        nextQuarterMonth.month,
        nextQuarterDay,
      );
    }

    return candidate;
  }

  int _effectiveDayOfMonth(int year, int month) {
    final maxDay = DateTime.utc(year, month + 1, 0).day;
    return dayOfMonth <= maxDay ? dayOfMonth : maxDay;
  }

  /// Maximum number of payments before we consider the calculation unreasonable.
  /// 1200 payments = 100 years of monthly payments, which is a sensible upper bound.
  static const int _maxReasonablePayments = 1200;

  /// Calculates the estimated final payment date for debt items.
  ///
  /// Returns null if:
  /// - Item is not a debt type
  /// - No remaining balance is set
  /// - Payment amount is zero or negative
  /// - No frequency is set
  /// - Calculated payoff exceeds 100 years (sanity check)
  ///
  /// The calculation assumes regular payments of `amountMinorUnits` at the
  /// specified `frequency` starting from the next scheduled occurrence
  /// on or after `fromDate` (defaults to now).
  DateTime? calculateFinalPaymentDate({DateTime? fromDate}) {
    // Only applicable to debt items
    if (type != PaymentType.debt) return null;

    // Need remaining balance to calculate
    if (remainingBalanceCents == null || remainingBalanceCents! <= 0) return null;

    // Need non-zero payment amount (use absolute value for expenses).
    final paymentAmountRaw = amountMinorUnits.abs();
    if (paymentAmountRaw == 0) return null;

    // Apply exchange rate conversion if set
    // exchangeRate represents: 1 payment currency = X balance currency
    final paymentAmount = exchangeRate != null && exchangeRate! > 0
        ? (paymentAmountRaw * exchangeRate!).round()
        : paymentAmountRaw;

    // Sanity check: if payment amount after conversion is zero or negative, bail
    if (paymentAmount <= 0) return null;

    // Need frequency for recurring debt
    if (frequency == null) return null;

    final anchor = fromDate ?? DateTime.now().toUtc();
    
    // Find the next scheduled payment date on or after the anchor date
    // This ensures we calculate payoffs relative to "now" (or specified time)
    // rather than the original start date (which might be years ago).
    DateTime baseDate;
    if (!startDate.isBefore(anchor)) {
      baseDate = startDate;
    } else {
      // startDate is in the past, find next occurrence
      switch (frequency!) {
        case RecurrenceFrequency.weekly:
          final daysDiff = anchor.difference(startDate).inDays;
          // Calculate weeks passed using floating point division then ceil
          // to ensure we land on or after anchor
          // Note: using 7.0 to force double division
          final weeksPassed = (daysDiff / 7.0).ceil(); 
          // If anchor is exactly on a recurrence, weeksPassed might be exact, 
          // add(weeks*7) lands exactly on anchor.
          // If anchor is 1 day after a recurrence, weeksPassed increases by 1,
          // landing on next recurrence.
          // Safety check: ensure weeksPassed is non-negative (it is since start < anchor)
          baseDate = startDate.add(Duration(days: (weeksPassed < 0 ? 0 : weeksPassed) * 7));
          
          // Verify we didn't undershoot due to DST/time weirdness (unlikely with UTC)
          if (baseDate.isBefore(anchor)) {
             baseDate = baseDate.add(const Duration(days: 7));
          }
          break;
          
        case RecurrenceFrequency.biweekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final fortnightsPassed = (daysDiff / 14.0).ceil();
          baseDate = startDate.add(Duration(days: (fortnightsPassed < 0 ? 0 : fortnightsPassed) * 14));
          
          if (baseDate.isBefore(anchor)) {
             baseDate = baseDate.add(const Duration(days: 14));
          }
          break;
          
        case RecurrenceFrequency.monthly:
        case RecurrenceFrequency.quarterly:
        case RecurrenceFrequency.yearly:
          // Month-based logic
          final monthsPerPeriod = switch (frequency!) {
             RecurrenceFrequency.monthly => 1,
             RecurrenceFrequency.quarterly => 3,
             RecurrenceFrequency.yearly => 12,
             _ => 1, // unreachable
          };
          
          final monthsDiff = 
              (anchor.year - startDate.year) * 12 + 
              (anchor.month - startDate.month);
          
          // Rough estimate of periods passed
          var periodsPassed = (monthsDiff / monthsPerPeriod).floor();
           
          // Try candidate
          var candidate = month_math.addMonths(startDate, periodsPassed * monthsPerPeriod);
          // If we haven't reached anchor (accounting for day of month), move forward one period at a time
          while (candidate.isBefore(anchor)) {
             periodsPassed++;
             candidate = month_math.addMonths(startDate, periodsPassed * monthsPerPeriod);
          }
          baseDate = candidate;
          break;
      }
    }
    
    // Calculate number of payments needed
    final paymentsNeeded = (remainingBalanceCents! / paymentAmount).ceil();
    if (paymentsNeeded <= 0) return baseDate;

    // Sanity check: prevent unreasonable calculations (e.g., tiny payments on huge debt)
    // This prevents potential integer overflow and nonsensical 1000+ year payoff dates
    if (paymentsNeeded > _maxReasonablePayments) return null;

    // Calculate final date by adding (payments - 1) periods to baseDate
    // Logic: If I need 1 payment, I satisfy it on baseDate.
    // If I need 2, I satisfy next one on baseDate + 1 period.
    final additionalPeriods = paymentsNeeded - 1;
    
    switch (frequency!) {
      case RecurrenceFrequency.weekly:
        return baseDate.add(Duration(days: additionalPeriods * 7));
      case RecurrenceFrequency.biweekly:
        return baseDate.add(Duration(days: additionalPeriods * 14));
      case RecurrenceFrequency.monthly:
        return month_math.addMonths(baseDate, additionalPeriods);
      case RecurrenceFrequency.quarterly:
        return month_math.addMonths(baseDate, additionalPeriods * 3);
      case RecurrenceFrequency.yearly:
        return month_math.addMonths(baseDate, additionalPeriods * 12);
    }
  }

  /// Returns the progress percentage (0-100) of debt payment.
  ///
  /// Returns null if not applicable (not debt or no remaining balance set).
  /// Calculates progress as: (originalAmount - remainingBalance) / originalAmount * 100
  double? getDebtProgressPercentage() {
    if (type != PaymentType.debt || remainingBalanceCents == null) return null;
    if (remainingBalanceCents! <= 0) return 100.0;
    
    // If originalAmountCents is not set, fall back to using remainingBalance as original
    final original = originalAmountCents ?? remainingBalanceCents!;
    if (original <= 0) return 0.0;
    
    final paid = original - remainingBalanceCents!;
    final percentage = (paid / original) * 100.0;
    
    // Clamp between 0 and 100
    return percentage.clamp(0.0, 100.0);
  }
}
