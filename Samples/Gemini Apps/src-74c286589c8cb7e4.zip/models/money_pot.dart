import 'package:uuid/uuid.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';

enum MoneyPotType {
  savings,
  debt;

  String get id => name;
}

class MoneyPot {
  final String id;
  final String name;
  final int amountCents;
  final MoneyPotType type;
  final AppCurrency? currency;

  const MoneyPot({
    required this.id,
    required this.name,
    required this.amountCents,
    required this.type,
    this.currency,
  });

  factory MoneyPot.create({
    required String name,
    required int amountCents,
    required MoneyPotType type,
    AppCurrency? currency,
  }) {
    return MoneyPot(
      id: const Uuid().v4(),
      name: name,
      amountCents: amountCents,
      type: type,
      currency: currency,
    );
  }

  MoneyPot copyWith({
    Object? name = sentinel,
    Object? amountCents = sentinel,
    Object? type = sentinel,
    Object? currency = sentinel,
  }) {
    return MoneyPot(
      id: id,
      name: name == sentinel ? this.name : name as String,
      amountCents:
          amountCents == sentinel ? this.amountCents : amountCents as int,
      type: type == sentinel ? this.type : type as MoneyPotType,
      currency: currency == sentinel ? this.currency : currency as AppCurrency?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'amountCents': amountCents,
      'type': type.id,
      'currency': currency?.name,
    };
  }

  factory MoneyPot.fromJson(Map<String, dynamic> json) {
    return MoneyPot(
      id: json['id'] as String,
      name: json['name'] as String,
      amountCents: json['amountCents'] as int,
      type: MoneyPotType.values.firstWhere(
        (e) => e.id == json['type'],
        orElse: () => MoneyPotType.savings,
      ),
      currency: decodeCurrency(json['currency']),
    );
  }
}
