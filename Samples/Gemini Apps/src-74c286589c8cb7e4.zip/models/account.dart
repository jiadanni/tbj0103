import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

class Account extends Equatable {
  final String id;
  final String name;
  final DateTime createdAt;
  final DateTime lastModified;
  final bool isTestData;
  
  // Account-specific settings (previously global)
  final int? paycheckDay;
  final bool paycheckBusinessAdjust;
  final PaycheckAdjustDirection paycheckBusinessAdjustDirection;
  final int startingBalanceCents;

  const Account({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.lastModified,
    this.isTestData = false,
    this.paycheckDay,
    this.paycheckBusinessAdjust = false,
    this.paycheckBusinessAdjustDirection = PaycheckAdjustDirection.before,
    this.startingBalanceCents = 0,
  });

  factory Account.create({
    required String name,
    bool isTestData = false,
    int? paycheckDay,
    bool paycheckBusinessAdjust = false,
    PaycheckAdjustDirection paycheckBusinessAdjustDirection = PaycheckAdjustDirection.before,
    int startingBalanceCents = 0,
  }) {
    final now = DateTime.now();
    return Account(
      id: const Uuid().v4(),
      name: name,
      createdAt: now,
      lastModified: now,
      isTestData: isTestData,
      paycheckDay: paycheckDay,
      paycheckBusinessAdjust: paycheckBusinessAdjust,
      paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
      startingBalanceCents: startingBalanceCents,
    );
  }

  Account copyWith({
    String? name,
    DateTime? lastModified,
    bool? isTestData,
    int? paycheckDay,
    bool clearPaycheckDay = false,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
  }) {
    return Account(
      id: id,
      name: name ?? this.name,
      createdAt: createdAt,
      lastModified: lastModified ?? this.lastModified,
      isTestData: isTestData ?? this.isTestData,
      paycheckDay: clearPaycheckDay ? null : (paycheckDay ?? this.paycheckDay),
      paycheckBusinessAdjust: paycheckBusinessAdjust ?? this.paycheckBusinessAdjust,
      paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection ?? this.paycheckBusinessAdjustDirection,
      startingBalanceCents: startingBalanceCents ?? this.startingBalanceCents,
    );
  }

  /// Whether paycheck mode is configured for this account
  bool get isPaycheckModeConfigured => paycheckDay != null;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'lastModified': lastModified.millisecondsSinceEpoch,
      'isTestData': isTestData,
      'paycheckDay': paycheckDay,
      'paycheckBusinessAdjust': paycheckBusinessAdjust,
      'paycheckBusinessAdjustDirection': paycheckBusinessAdjustDirection.name,
      'startingBalanceCents': startingBalanceCents,
    };
  }

  factory Account.fromJson(Map<String, dynamic> json) {
    return Account(
      id: json['id'] as String,
      name: json['name'] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(json['createdAt'] as int),
      lastModified: DateTime.fromMillisecondsSinceEpoch(json['lastModified'] as int),
      isTestData: json['isTestData'] as bool? ?? false,
      paycheckDay: json['paycheckDay'] as int?,
      paycheckBusinessAdjust: json['paycheckBusinessAdjust'] as bool? ?? false,
      paycheckBusinessAdjustDirection: _parseAdjustDirection(json['paycheckBusinessAdjustDirection']),
      startingBalanceCents: json['startingBalanceCents'] as int? ?? 0,
    );
  }

  static PaycheckAdjustDirection _parseAdjustDirection(dynamic value) {
    if (value == null) return PaycheckAdjustDirection.before;
    if (value is String) {
      return PaycheckAdjustDirection.values.firstWhere(
        (e) => e.name == value,
        orElse: () => PaycheckAdjustDirection.before,
      );
    }
    return PaycheckAdjustDirection.before;
  }

  @override
  List<Object?> get props => [
    id, name, createdAt, lastModified, isTestData,
    paycheckDay, paycheckBusinessAdjust, paycheckBusinessAdjustDirection, startingBalanceCents,
  ];
}
