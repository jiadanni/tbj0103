import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';

/// Available month counts for the grid zoom control.
const List<int> gridZoomOptions = [2, 4, 6, 8, 12];

/// Available zoom stages for sheet view (maps to GridZoomStage).
const List<int> sheetZoomOptions = [2, 4, 6];

/// A compact row of segmented buttons for selecting month count in grid view.
/// Single-tap selection with clear visual feedback of current state.
class GridZoomButtons extends StatelessWidget {
  const GridZoomButtons({
    super.key,
    required this.currentMonths,
    required this.onChanged,
  });

  final int currentMonths;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      height: 28,
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (int i = 0; i < gridZoomOptions.length; i++) ...[
            _ZoomButton(
              months: gridZoomOptions[i],
              isSelected: currentMonths == gridZoomOptions[i],
              onTap: () => onChanged(gridZoomOptions[i]),
            ),
          ],
        ],
      ),
    );
  }
}

class _ZoomButton extends StatelessWidget {
  const _ZoomButton({
    required this.months,
    required this.isSelected,
    required this.onTap,
  });

  final int months;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? colorScheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          '$months',
          style: theme.textTheme.labelSmall?.copyWith(
            color: isSelected
                ? colorScheme.onPrimary
                : colorScheme.onSurfaceVariant,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

/// A compact slider for controlling zoom level in grid view.
/// Provides continuous visual feedback with discrete snapping to available options.
class GridZoomSlider extends StatelessWidget {
  const GridZoomSlider({
    super.key,
    required this.currentMonths,
    required this.onChanged,
  });

  final int currentMonths;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    // Find index of current value
    final currentIndex = gridZoomOptions.indexOf(currentMonths);
    final sliderValue = currentIndex >= 0 ? currentIndex.toDouble() : 0.0;

    return SizedBox(
      width: 120,
      height: 28,
      child: Row(
        children: [
          // Zoom in icon (fewer months = more zoom)
          Icon(
            Icons.zoom_in,
            size: 14,
            color: colorScheme.onSurfaceVariant,
          ),
          Expanded(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 3,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                activeTrackColor: colorScheme.primary,
                inactiveTrackColor: colorScheme.surfaceContainerHighest,
                thumbColor: colorScheme.primary,
                overlayColor: colorScheme.primary.withValues(alpha: 0.2),
              ),
              child: Slider(
                value: sliderValue,
                min: 0,
                max: (gridZoomOptions.length - 1).toDouble(),
                divisions: gridZoomOptions.length - 1,
                onChanged: (value) {
                  final index = value.round();
                  if (index >= 0 && index < gridZoomOptions.length) {
                    onChanged(gridZoomOptions[index]);
                  }
                },
              ),
            ),
          ),
          // Zoom out icon (more months = less zoom)
          Icon(
            Icons.zoom_out,
            size: 14,
            color: colorScheme.onSurfaceVariant,
          ),
        ],
      ),
    );
  }
}

/// Combined widget showing both the slider and current month count label.
class GridZoomSliderWithLabel extends StatelessWidget {
  const GridZoomSliderWithLabel({
    super.key,
    required this.currentMonths,
    required this.onChanged,
  });

  final int currentMonths;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GridZoomSlider(
          currentMonths: currentMonths,
          onChanged: onChanged,
        ),
        const SizedBox(width: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            '$currentMonths',
            style: theme.textTheme.labelSmall?.copyWith(
              color: colorScheme.onPrimaryContainer,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}

/// A compact row of segmented buttons for selecting zoom stage in sheet view.
class SheetZoomButtons extends StatelessWidget {
  const SheetZoomButtons({
    super.key,
    required this.currentStage,
    required this.onChanged,
  });

  final GridZoomStage currentStage;
  final ValueChanged<GridZoomStage> onChanged;

  int _stageToMonths(GridZoomStage stage) => switch (stage) {
    GridZoomStage.twoMonths => 2,
    GridZoomStage.fourMonths => 4,
    GridZoomStage.sixMonths => 6,
  };

  GridZoomStage _monthsToStage(int months) => switch (months) {
    2 => GridZoomStage.twoMonths,
    4 => GridZoomStage.fourMonths,
    6 => GridZoomStage.sixMonths,
    _ => GridZoomStage.twoMonths,
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final currentMonths = _stageToMonths(currentStage);

    return Container(
      height: 28,
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final months in sheetZoomOptions)
            _ZoomButton(
              months: months,
              isSelected: currentMonths == months,
              onTap: () => onChanged(_monthsToStage(months)),
            ),
        ],
      ),
    );
  }
}
