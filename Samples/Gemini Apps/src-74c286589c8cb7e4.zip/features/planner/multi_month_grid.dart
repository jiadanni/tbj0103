import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/payment_display.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';

typedef PaymentsForMonth = List<PaymentEntry> Function(DateTime month);

/// A multi-month grid view that displays months as cards in a grid layout.
/// Dynamically adjusts columns and rows based on viewport dimensions.
class MultiMonthGrid extends StatelessWidget {
  const MultiMonthGrid({
    super.key,
    required this.months,
    required this.items,
    required this.paymentsForMonth,
    required this.currency,
    required this.currentMonth,
    required this.showClearedForCurrentMonth,
    required this.recentlyClearedItemIds,
    required this.sortOrder,
    required this.dayFormat,
    required this.columnsPerRow,
    required this.startingBalanceCents,
    required this.settings,
    required this.displayMode,
    this.onMonthTapped,
  });

  final List<DateTime> months;
  final List<PlannerItem> items;
  final PaymentsForMonth paymentsForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final bool showClearedForCurrentMonth;
  final Set<String> recentlyClearedItemIds;
  final PlannerSortOrder sortOrder;
  final DayFormat dayFormat;
  final int columnsPerRow;
  final int startingBalanceCents;
  final AppSettingsStore settings;
  final PaymentDisplayMode displayMode;
  final void Function(DateTime month)? onMonthTapped;

  // Base card dimensions for grid layout
  static const double baseCardWidth = 160.0;
  static const double baseCardHeight = 280.0;
  static const double cardMargin = 2.0;
  static const double outerCardWidth = baseCardWidth + cardMargin * 2;
  static const double outerCardHeight = baseCardHeight + cardMargin * 2;
  static const double minCardWidth = 100.0;
  static const double minCardHeight = 150.0;

  @override
  Widget build(BuildContext context) {
    // Use base card dimensions directly since InteractiveViewer provides unconstrained layout
    final cardWidth = baseCardWidth;
    final cardHeight = baseCardHeight;
    final computedMonths = _buildMonthData();

    // Calculate how many rows we need for all months
    final totalRows = (computedMonths.length / columnsPerRow).ceil();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int row = 0; row < totalRows; row++)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (int col = 0; col < columnsPerRow; col++)
                Builder(
                  builder: (context) {
                    final index = row * columnsPerRow + col;
                    if (index >= computedMonths.length) {
                      return SizedBox(
                        width: cardWidth,
                        height: cardHeight,
                      );
                    }
                    final monthData = computedMonths[index];
                    return _MonthGridCard(
                      data: monthData,
                      currency: currency,
                      dayFormat: dayFormat,
                      width: cardWidth,
                      height: cardHeight,
                      settings: settings,
                      displayMode: displayMode,
                      onTapped: onMonthTapped,
                    );
                  },
                ),
            ],
          ),
      ],
    );
  }

  List<_GridMonthData> _buildMonthData() {
    final monthSeeds = <_GridMonthSeed>[];
    final currentNormalized = monthOnly(currentMonth);

    DateTime? clearedDateFor(PlannerItem item, List<PaymentEntry> payments, DateTime month) {
      PaymentEntry? best;
      for (final payment in payments) {
        if (!paymentMatchesPlannerItem(payment, item, month, settings)) continue;
        if (best == null || payment.date.isAfter(best.date)) best = payment;
      }
      return best?.date;
    }

    for (final month in months) {
      final normalized = monthOnly(month);
      final monthPayments = paymentsForMonth(month);
      final isCurrent =
          normalized.year == currentNormalized.year && normalized.month == currentNormalized.month;
      final showCleared = isCurrent ? showClearedForCurrentMonth : true;

      // Get period info for label
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

      // Filter items to only those that should appear in this month
      final monthItems = items.where((item) => item.shouldAppearInMonth(month)).toList(growable: false);

      // Build item data for all items (needed for accurate totals and balance)
      final allItemData = monthItems
          .map(
            (item) => _GridItemData(
              item: item,
              clearedDate: clearedDateFor(item, monthPayments, month),
            ),
          )
          .toList(growable: false);

      // Filter items for display purposes only
      // Filter items for display purposes only
      final displayItems = showCleared
          ? allItemData
          : allItemData
              .where(
                (data) =>
                    data.clearedDate == null ||
                    (isCurrent && recentlyClearedItemIds.contains(data.item.id)),
              )
              .toList();
      final orderedItems = orderedPlannerItems(
        displayItems.map((d) => d.item).toList(),
        sortOrder,
        viewMode: settings.viewPeriodMode,
        periodInfo: periodInfo,
      );
      final orderedItemData = orderedItems
          .map(
            (item) => allItemData.firstWhere((data) => data.item.id == item.id),
          )
          .toList(growable: false);

      // Compute net change for propagation
      // For current month, only count uncleared items (as cleared are already in starting balance)
      // For other months, count all items.
      final netChangeCents = allItemData.where((data) {
        if (!isCurrent) return true;
        return data.clearedDate == null;
      }).fold<int>(0, (sum, data) => sum + data.item.amountCents);

      monthSeeds.add(
        _GridMonthSeed(
          month: month,
          items: orderedItemData,
          isPast: monthOnly(month).isBefore(currentMonth),
          isCurrent: isCurrent,
          totalCents: netChangeCents, // This is the net change for this period
          periodLabel: periodInfo.label,
        ),
      );
    }

    final monthData = <_GridMonthData>[];
    final currentIndex = monthSeeds.indexWhere((seed) => seed.isCurrent);
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;
    
    // We'll calculate balances by iterating forward from the earliest month
    final startBalances = List<int>.filled(monthSeeds.length, 0);
    final cumulativeBalances = List<int>.filled(monthSeeds.length, 0);
    
    var runningBalance = startingBalanceCents;
    
    for (var i = 0; i < monthSeeds.length; i++) {
        // For months before baseIndex, we don't have a reliable starting balance,
        // so we'll just show 0 or something neutral.
        if (i < baseIndex) {
            startBalances[i] = 0;
            cumulativeBalances[i] = monthSeeds[i].totalCents;
        } else if (i == baseIndex) {
            startBalances[i] = startingBalanceCents;
            cumulativeBalances[i] = startingBalanceCents + monthSeeds[i].totalCents;
            runningBalance = cumulativeBalances[i];
        } else {
            startBalances[i] = runningBalance;
            cumulativeBalances[i] = runningBalance + monthSeeds[i].totalCents;
            runningBalance = cumulativeBalances[i];
        }
    }

    for (var i = 0; i < monthSeeds.length; i++) {
      final seed = monthSeeds[i];
      monthData.add(
        _GridMonthData(
          month: seed.month,
          items: seed.items,
          isPast: seed.isPast,
          isCurrent: seed.isCurrent,
          isFirst: i == 0,
          totalCents: seed.totalCents,
          startBalanceCents: startBalances[i],
          cumulativeBalanceCents: cumulativeBalances[i],
          periodLabel: seed.periodLabel,
        ),
      );
    }

    return monthData;
  }
}

class _GridMonthSeed {
  const _GridMonthSeed({
    required this.month,
    required this.items,
    required this.isPast,
    required this.isCurrent,
    required this.totalCents,
    required this.periodLabel,
  });

  final DateTime month;
  final List<_GridItemData> items;
  final bool isPast;
  final bool isCurrent;
  final int totalCents;
  final String periodLabel;
}

class _GridMonthData {
  const _GridMonthData({
    required this.month,
    required this.items,
    required this.isPast,
    required this.isCurrent,
    required this.isFirst,
    required this.totalCents,
    required this.startBalanceCents,
    required this.cumulativeBalanceCents,
    required this.periodLabel,
  });

  final DateTime month;
  final List<_GridItemData> items;
  final bool isPast;
  final bool isCurrent;
  final bool isFirst;
  final int totalCents;
  final int startBalanceCents;
  final int cumulativeBalanceCents;
  final String periodLabel;
}

class _GridItemData {
  const _GridItemData({required this.item, required this.clearedDate});

  final PlannerItem item;
  final DateTime? clearedDate;
}

class _MonthGridCard extends StatelessWidget {
  const _MonthGridCard({
    required this.data,
    required this.currency,
    required this.dayFormat,
    required this.width,
    required this.height,
    required this.settings,
    required this.displayMode,
    this.onTapped,
  });

  final _GridMonthData data;
  final AppCurrency currency;
  final DayFormat dayFormat;
  final double width;
  final double height;
  final AppSettingsStore settings;
  final PaymentDisplayMode displayMode;
  final void Function(DateTime month)? onTapped;

  /// Builds the display label with optional company suffix.
  String _buildDisplayLabel(String baseLabel, PlannerItem item) {
    if (settings.plannerShowPaymentOrigin && item.company != null && item.company!.isNotEmpty) {
      return '$baseLabel (${item.company})';
    }
    return baseLabel;
  }

  @override
  Widget build(BuildContext context) {
    final month = data.month;
    final isPast = data.isPast;
    final isCurrent = data.isCurrent;
    final visibleItems = data.items;
    final periodNet = data.totalCents;

    final headerColor = isPast
        ? Theme.of(context).colorScheme.surfaceContainerLow
        : Theme.of(context).colorScheme.surfaceContainerHigh;

    // Adjust font sizes based on card dimensions
    final isCompact = width < 120 || height < 150;
    final headerFontSize = isCompact ? 10.0 : 12.0;
    final itemFontSize = isCompact ? 8.0 : 10.0;
    final dayFontSize = isCompact ? 7.0 : 9.0;
    final totalFontSize = isCompact ? 8.0 : 9.0;
    final padding = isCompact ? 3.0 : 6.0;

    final card = Container(
      width: width,
      height: height,
      margin: const EdgeInsets.all(MultiMonthGrid.cardMargin),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: isCurrent 
              ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.8)
              : Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.2),
          width: isCurrent ? 2 : 1,
        ),
        boxShadow: [
          if (isCurrent)
            BoxShadow(
              color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
              blurRadius: 4,
              spreadRadius: 1,
            ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 2,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header - compact single line
          Container(
            padding: EdgeInsets.symmetric(horizontal: padding, vertical: isCompact ? 2 : 3),
            color: headerColor,
            child: Text(
              data.periodLabel,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    fontSize: headerFontSize,
                    fontWeight: FontWeight.w600,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Items list - scrollable to prevent overflow
          Expanded(
            child: settings.plannerGroupByDate
                ? _buildGroupedList(
                    context,
                    visibleItems,
                    isCurrent,
                    isCompact,
                    itemFontSize,
                    dayFontSize,
                    padding,
                  )
                : _buildFlatList(
                    context,
                    visibleItems,
                    isCurrent,
                    isCompact,
                    itemFontSize,
                    dayFontSize,
                    padding,
                  ),
          ),
          // Footer - condensed single line showing cumulative balance
          InkWell(
            onTap: () {
              // Toggle zero baseline mode
              settings.plannerUseZeroBaseline = !settings.plannerUseZeroBaseline;
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: padding, vertical: isCompact ? 2 : 3),
              decoration: BoxDecoration(
                color: headerColor,
                border: Border(
                  top: BorderSide(
                    color: Theme.of(context).dividerColor.withValues(alpha: 0.3),
                  ),
                ),
              ),
              child: Row(
                children: [
                  // Period net change (compact)
                  Text(
                    formatMoneyFromCents(periodNet, currency, showCents: settings.showCents),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          fontSize: totalFontSize,
                          fontWeight: FontWeight.w500,
                          fontFeatures: const [FontFeature.tabularFigures()],
                          color: periodNet < 0
                              ? settings.debitColor
                              : periodNet > 0
                                  ? settings.creditColor
                                  : null,
                        ),
                  ),
                  const Spacer(),
                  // Cumulative/ending balance (most important)
                  Text(
                    formatMoneyFromCents(data.cumulativeBalanceCents, currency, showCents: settings.showCents),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          fontSize: totalFontSize,
                          fontWeight: FontWeight.w600,
                          fontFeatures: const [FontFeature.tabularFigures()],
                          color: data.cumulativeBalanceCents < 0
                              ? settings.debitColor
                              : data.cumulativeBalanceCents > 0
                                  ? settings.creditColor
                                  : null,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );

    // Tap to navigate to month view
    final tappable = GestureDetector(
      onTap: onTapped != null
          ? () {
              HapticFeedback.selectionClick();
              onTapped!(month);
            }
          : null,
      child: card,
    );

    if (!isPast) return tappable;
    return Opacity(opacity: 0.62, child: tappable);
  }

  Widget _buildFlatList(
    BuildContext context,
    List<_GridItemData> visibleItems,
    bool isCurrent,
    bool isCompact,
    double itemFontSize,
    double dayFontSize,
    double padding,
  ) {
    final month = data.month;
    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: padding, vertical: 2),
      physics: const ClampingScrollPhysics(),
      itemCount: visibleItems.length,
      itemBuilder: (context, index) {
        final itemData = visibleItems[index];
        return _buildItemRow(
          context,
          itemData,
          month,
          isCurrent,
          isCompact,
          itemFontSize,
          dayFontSize,
          showDay: true,
        );
      },
    );
  }

  Widget _buildGroupedList(
    BuildContext context,
    List<_GridItemData> visibleItems,
    bool isCurrent,
    bool isCompact,
    double itemFontSize,
    double dayFontSize,
    double padding,
  ) {
    final month = data.month;
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );

    // Group items by day
    final groups = <int, List<_GridItemData>>{};
    for (final itemData in visibleItems) {
      final clearedDate = itemData.clearedDate;
      final day = clearedDate?.day ?? effectiveDayOfMonth(itemData.item.dayOfMonth, month);
      (groups[day] ??= []).add(itemData);
    }

    // Sort groups using the same logic as item sorting (handles paycheck mode correctly)
    final sortedDays = groups.keys.toList();
    sortedDays.sort((a, b) {
      final aSortValue = daySortValue(a, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      final bSortValue = daySortValue(b, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      // Apply sort order (chronological or reverse)
      return settings.plannerSortOrder == PlannerSortOrder.chronological
          ? aSortValue.compareTo(bSortValue)
          : bSortValue.compareTo(aSortValue);
    });

    // Build grouped widget list
    final widgets = <Widget>[];
    for (int i = 0; i < sortedDays.length; i++) {
      final day = sortedDays[i];
      final groupItems = groups[day]!;
      final hasMultipleItems = groupItems.length > 1;

      // Only show group header if there are multiple items on this day
      if (hasMultipleItems) {
        widgets.add(
          Container(
            padding: EdgeInsets.only(
              left: padding,
              right: padding,
              top: i == 0 ? 2 : 4,
              bottom: 1,
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 0),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: Text(
                    formatDayOfMonth(day, dayFormat),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontSize: dayFontSize - 1,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Container(
                    height: 0.5,
                    color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3),
                  ),
                ),
              ],
            ),
          ),
        );

        // Add items in this group (without day prefix since header shows it)
        for (final itemData in groupItems) {
          widgets.add(
            Padding(
              padding: EdgeInsets.symmetric(horizontal: padding),
              child: _buildItemRow(
                context,
                itemData,
                month,
                isCurrent,
                isCompact,
                itemFontSize,
                dayFontSize,
                showDay: false,
              ),
            ),
          );
        }
      } else {
        // Single item - show inline with day (like flat view)
        widgets.add(
          Padding(
            padding: EdgeInsets.symmetric(horizontal: padding),
            child: _buildItemRow(
              context,
              groupItems.first,
              month,
              isCurrent,
              isCompact,
              itemFontSize,
              dayFontSize,
              showDay: true,
            ),
          ),
        );
      }
    }

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 2),
      physics: const ClampingScrollPhysics(),
      children: widgets,
    );
  }

  Widget _buildItemRow(
    BuildContext context,
    _GridItemData itemData,
    DateTime month,
    bool isCurrent,
    bool isCompact,
    double itemFontSize,
    double dayFontSize, {
    required bool showDay,
  }) {
    final item = itemData.item;
    final clearedDate = itemData.clearedDate;
    final isCleared = clearedDate != null;
    final displayDay = effectiveDayOfMonth(item.dayOfMonth, month);

    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 0.5),
      child: Row(
        children: [
          // Day (only if showDay is true)
          if (showDay)
            SizedBox(
              width: isCompact ? 14 : 20,
              child: Text(
                formatDayOfMonth(displayDay, dayFormat),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontSize: dayFontSize,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                textAlign: TextAlign.left,
              ),
            ),
          if (showDay) SizedBox(width: isCompact ? 4 : 6),
          // Label (with icon/acronym/full support based on displayMode)
          Expanded(
            child: displayMode == PaymentDisplayMode.icon
                ? Icon(
                    getPaymentIcon(item.label, type: item.type),
                    size: itemFontSize + 2,
                    color: (isCleared && isCurrent)
                        ? Theme.of(context).colorScheme.onSurfaceVariant
                        : Theme.of(context).colorScheme.onSurface,
                  )
                : displayMode == PaymentDisplayMode.acronym
                    ? Text(
                        _buildDisplayLabel(generateAcronym(item.label), item),
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: itemFontSize,
                              fontWeight: FontWeight.bold,
                              color: (isCleared && isCurrent)
                                  ? Theme.of(context).colorScheme.onSurfaceVariant
                                  : Theme.of(context).colorScheme.onSurface,
                            ),
                      )
                    : Text(
                        _buildDisplayLabel(item.label, item),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: itemFontSize,
                              color: (isCleared && isCurrent)
                                  ? Theme.of(context).colorScheme.onSurfaceVariant
                                  : null,
                            ),
                      ),
          ),
          // Amount
          Text(
            formatMoneyFromCents(item.amountCents, currency, showCents: settings.showCents),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontSize: dayFontSize,
                  fontFeatures: const [FontFeature.tabularFigures()],
                  color: item.amountCents < 0
                      ? settings.debitColor
                      : settings.creditColor,
                ),
          ),
        ],
      ),
    );

    // Only dim cleared items in the current period
    if (isCleared && isCurrent) {
      return Opacity(opacity: 0.5, child: row);
    }
    return row;
  }
}

/// Calculate optimal grid dimensions for a target month count
GridDimensions calculateGridDimensions({
  required double viewportWidth,
  required double viewportHeight,
  required int targetMonthCount,
}) {
  double bestWidthUsage = 0.0;
  double bestScale = 0.0;
  int bestCountDiff = 1 << 30;
  int bestColumns = 2;
  int bestRows = 1;

  final minScaleX = MultiMonthGrid.minCardWidth / MultiMonthGrid.outerCardWidth;
  final minScaleY = MultiMonthGrid.minCardHeight / MultiMonthGrid.outerCardHeight;
  final minScale = math.max(minScaleX, minScaleY);

  for (int cols = 1; cols <= 6; cols++) {
    final rows = (targetMonthCount / cols).ceil();
    if (rows < 1) continue;

    final totalWidth = cols * MultiMonthGrid.outerCardWidth;
    final totalHeight = rows * MultiMonthGrid.outerCardHeight;
    if (totalWidth <= 0 || totalHeight <= 0) continue;

    final scale = math.min(
      viewportWidth / totalWidth,
      viewportHeight / totalHeight,
    );
    if (scale <= 0 || scale < minScale) continue;

    final widthUsage = (totalWidth * scale) / viewportWidth;
    final countDiff = (cols * rows - targetMonthCount).abs();
    if (widthUsage > bestWidthUsage + 0.0001) {
      bestWidthUsage = widthUsage;
      bestColumns = cols;
      bestRows = rows;
      bestScale = scale;
      bestCountDiff = countDiff;
      continue;
    }

    if ((widthUsage - bestWidthUsage).abs() > 0.0001) continue;
    if (countDiff < bestCountDiff) {
      bestColumns = cols;
      bestRows = rows;
      bestScale = scale;
      bestCountDiff = countDiff;
      continue;
    }
    if (countDiff != bestCountDiff) continue;
    if (scale > bestScale + 0.0001 ||
        ((scale - bestScale).abs() <= 0.0001 && cols > bestColumns)) {
      bestColumns = cols;
      bestRows = rows;
      bestScale = scale;
    }
  }

  return GridDimensions(columns: bestColumns, rows: bestRows);
}

class GridDimensions {
  final int columns;
  final int rows;

  const GridDimensions({required this.columns, required this.rows});

  int get totalMonths => columns * rows;
}
