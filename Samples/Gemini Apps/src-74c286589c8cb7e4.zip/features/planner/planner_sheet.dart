import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/payment_display.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/display_helpers.dart';

typedef PaymentsForMonth = List<PaymentEntry> Function(DateTime month);

class PlannerSheet extends StatelessWidget {
  const PlannerSheet({
    super.key,
    required this.months,
    required this.items,
    required this.paymentsForMonth,
    required this.currency,
    required this.currentMonth,
    required this.showClearedForCurrentMonth,
    required this.recentlyClearedItemIds,
    required this.startingBalanceCents,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    this.onMonthTapped,
  });

  final List<DateTime> months;
  final List<PlannerItem> items;
  final PaymentsForMonth paymentsForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final bool showClearedForCurrentMonth;
  final Set<String> recentlyClearedItemIds;
  final int startingBalanceCents;
  final GridZoomStage zoomStage;
  final PlannerSortOrder sortOrder;
  final DayFormat dayFormat;
  final PaymentDisplayMode displayMode;
  final AppSettingsStore settings;
  final void Function(DateTime month)? onMonthTapped;

  static const double _kDayWidth = 18;
  static const double _kLabelWidth = 60;
  static const double _kAmountWidth = 48;
  static const double _kRowHeight = 20;
  static const double _kColumnPadding = 4;

  static const double columnWidth = _kDayWidth + _kLabelWidth + _kAmountWidth + _kColumnPadding * 2;

  DateTime? _clearedDateFor(PlannerItem item, List<PaymentEntry> payments, DateTime month) {
    for (final payment in payments) {
      if (paymentMatchesPlannerItem(payment, item, month, settings)) return payment.date;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final rowHeight = _rowHeightForStage(zoomStage);
    final border = BorderSide.none;
    final width = months.length * columnWidth;
    final rowCount = items.length;
    const footerRowCount = 2;
    final height = rowCount * rowHeight + rowHeight * (1 + footerRowCount);
    final normalizedCurrent = monthOnly(currentMonth);
    final currentIndex = months.indexWhere(
      (month) => monthOnly(month) == normalizedCurrent,
    );
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;

    final monthTotals = <int>[];
    for (final month in months) {
        final monthPayments = paymentsForMonth(month);
        final isCurrent = monthOnly(month) == normalizedCurrent;
        
        final netChange = items.where((item) => item.shouldAppearInMonth(month)).where((item) {
            if (!isCurrent) return true;
            return _clearedDateFor(item, monthPayments, month) == null;
        }).fold<int>(0, (sum, item) => sum + item.amountCents);
        
        monthTotals.add(netChange);
    }

    final startBalances = List<int>.filled(months.length, 0);
    final cumulativeBalances = List<int>.filled(months.length, 0);
    
    var runningBalance = startingBalanceCents;
    
    for (var i = 0; i < months.length; i++) {
        if (i < baseIndex) {
            startBalances[i] = 0;
            cumulativeBalances[i] = monthTotals[i];
        } else if (i == baseIndex) {
            startBalances[i] = startingBalanceCents;
            cumulativeBalances[i] = startingBalanceCents + monthTotals[i];
            runningBalance = cumulativeBalances[i];
        } else {
            startBalances[i] = runningBalance;
            cumulativeBalances[i] = runningBalance + monthTotals[i];
            runningBalance = cumulativeBalances[i];
        }
    }

    return Material(
      color: Theme.of(context).colorScheme.surface,
      child: SizedBox(
        width: width,
        height: height,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (int i = 0; i < months.length; i++)
              MonthSheetColumn(
                month: months[i],
                items: items,
                payments: paymentsForMonth(months[i]),
                currency: currency,
                border: border,
                dayWidth: _kDayWidth,
                labelWidth: _kLabelWidth,
                amountWidth: _kAmountWidth,
                rowHeight: rowHeight,
                columnPadding: _kColumnPadding,
                isFirst: i == 0,
                showCleared: () {
                  final normalized = monthOnly(months[i]);
                  final isCurrent = normalized.year == currentMonth.year &&
                      normalized.month == currentMonth.month;
                  return isCurrent ? showClearedForCurrentMonth : true;
                }(),
                recentlyClearedItemIds: recentlyClearedItemIds,
                zoomStage: zoomStage,
                sortOrder: sortOrder,
                dayFormat: dayFormat,
                displayMode: displayMode,
                settings: settings,
                currentPeriodMonth: currentMonth,
                isFirstColumn: i == 0,
                startBalanceCents: startBalances[i],
                netTotalCents: monthTotals[i],
                cumulativeBalanceCents: cumulativeBalances[i],
                onTapped: onMonthTapped,
              ),
          ],
        ),
      ),
    );
  }

  double _rowHeightForStage(GridZoomStage stage) {
    switch (stage) {
      case GridZoomStage.sixMonths:
        return 28;
      case GridZoomStage.fourMonths:
        return 24;
      case GridZoomStage.twoMonths:
        return _kRowHeight;
    }
  }
}

class MonthSheetColumn extends StatelessWidget {
  const MonthSheetColumn({super.key,
    required this.month,
    required this.items,
    required this.payments,
    required this.currency,
    required this.border,
    required this.dayWidth,
    required this.labelWidth,
    required this.amountWidth,
    required this.rowHeight,
    required this.columnPadding,
    required this.isFirst,
    required this.showCleared,
    required this.recentlyClearedItemIds,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    required this.currentPeriodMonth,
    required this.isFirstColumn,
    required this.startBalanceCents,
    required this.netTotalCents,
    required this.cumulativeBalanceCents,
    this.onTapped,
  });

  final DateTime month;
  final List<PlannerItem> items;
  final List<PaymentEntry> payments;
  final AppCurrency currency;
  final BorderSide border;
  final double dayWidth;
  final double labelWidth;
  final double amountWidth;
  final double rowHeight;
  final double columnPadding;
  final bool isFirst;
  final bool showCleared;
  final Set<String> recentlyClearedItemIds;
  final GridZoomStage zoomStage;
  final PlannerSortOrder sortOrder;
  final DayFormat dayFormat;
  final void Function(DateTime month)? onTapped;
  final PaymentDisplayMode displayMode;
  final AppSettingsStore settings;
  final DateTime currentPeriodMonth;
  final bool isFirstColumn;
  final int startBalanceCents;
  final int netTotalCents;
  final int cumulativeBalanceCents;

  /// Builds the display label with optional company suffix.
  String _buildDisplayLabel(String baseLabel, PlannerItem item) {
    if (settings.plannerShowPaymentOrigin && item.company != null && item.company!.isNotEmpty) {
      return '$baseLabel (${item.company})';
    }
    return baseLabel;
  }

  @override
  Widget build(BuildContext context) {
    final monthNormalized = monthOnly(month);
    final isPast = monthNormalized.isBefore(currentPeriodMonth);
    final isCurrent = monthNormalized.year == currentPeriodMonth.year &&
        monthNormalized.month == currentPeriodMonth.month;
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    final rows = _buildRows(periodInfo);
    final headerLabel = settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured
        ? periodInfo.label
        : gridHeaderLabel(
            month,
            zoomStage,
            Localizations.localeOf(context),
          );

    final totalColumnWidth = dayWidth + labelWidth + amountWidth + columnPadding * 2;
    final dividerColor = Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3);

    final headerBackground = isPast
        ? Theme.of(context).colorScheme.surfaceContainerLow
        : Theme.of(context).colorScheme.surfaceContainerHighest;
    final headerStyle = Theme.of(context).textTheme.labelSmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 11,
          fontWeight: FontWeight.w600,
        );
    final dayStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 10,
        );
    final labelStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          fontSize: 10,
        );
    final amountStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 10,
        );
    final endLabel =
        settings.viewPeriodMode == ViewPeriodMode.paycheck ? 'EOP' : 'EOM';

    final content = Container(
      width: totalColumnWidth,
      decoration: BoxDecoration(
        color: isCurrent 
            ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.05)
            : null,
        border: Border(
          left: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : (isFirst ? BorderSide.none : BorderSide(color: dividerColor, width: 1)),
          top: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
          right: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
          bottom: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Container(
            width: totalColumnWidth,
            height: rowHeight,
            padding: EdgeInsets.symmetric(horizontal: columnPadding),
            decoration: BoxDecoration(
              color: headerBackground,
              border: Border(
                bottom: BorderSide(color: dividerColor, width: 1),
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              headerLabel,
              style: headerStyle,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Data rows (grouped or flat based on settings)
          ..._buildDataRows(
            context,
            rows: rows,
            isCurrent: isCurrent,
            totalColumnWidth: totalColumnWidth,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            dayWidth: dayWidth,
            amountWidth: amountWidth,
            dividerColor: dividerColor,
            dayStyle: dayStyle,
            labelStyle: labelStyle,
            amountStyle: amountStyle,
            periodInfo: periodInfo,
          ),
          _FooterRow(
            label: 'Start',
            value: formatMoneyFromCents(startBalanceCents, currency, showCents: settings.showCents),
            valueColor: startBalanceCents < 0
                ? settings.debitColor
                : startBalanceCents > 0
                    ? settings.creditColor
                    : null,
            onTap: () {
              settings.plannerUseZeroBaseline = !settings.plannerUseZeroBaseline;
            },
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            totalColumnWidth: totalColumnWidth,
            background: headerBackground,
            dividerColor: dividerColor,
          ),
          _FooterRow(
            label: endLabel,
            value: formatMoneyFromCents(netTotalCents, currency, showCents: settings.showCents),
            valueColor: netTotalCents < 0
                ? settings.debitColor
                : netTotalCents > 0
                    ? settings.creditColor
                    : null,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            totalColumnWidth: totalColumnWidth,
            background: headerBackground,
            dividerColor: dividerColor,
          ),
          _FooterRow(
            label: '$endLabel(C)',
            value: isFirstColumn
                ? ''
                : formatMoneyFromCents(cumulativeBalanceCents, currency, showCents: settings.showCents),
            valueColor: cumulativeBalanceCents < 0
                ? settings.debitColor
                : cumulativeBalanceCents > 0
                    ? settings.creditColor
                    : null,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            totalColumnWidth: totalColumnWidth,
            background: headerBackground,
            dividerColor: dividerColor,
          ),
        ],
      ),
    );

    // Tap to navigate to month view
    final tappable = GestureDetector(
      onTap: onTapped != null
          ? () {
              HapticFeedback.selectionClick();
              onTapped!(month);
            }
          : null,
      child: content,
    );

    if (!isPast) return tappable;
    return Opacity(opacity: 0.62, child: tappable);
  }

  List<Widget> _buildDataRows(
    BuildContext context, {
    required List<_SheetRow> rows,
    required bool isCurrent,
    required double totalColumnWidth,
    required double rowHeight,
    required double columnPadding,
    required double dayWidth,
    required double amountWidth,
    required Color dividerColor,
    required TextStyle? dayStyle,
    required TextStyle? labelStyle,
    required TextStyle? amountStyle,
    required PeriodInfo periodInfo,
  }) {
    if (!settings.plannerGroupByDate) {
      // Flat list - original behavior
      return rows.map((row) {
        return _buildRowWidget(
          context,
          row: row,
          isCurrent: isCurrent,
          totalColumnWidth: totalColumnWidth,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          dayWidth: dayWidth,
          amountWidth: amountWidth,
          dividerColor: dividerColor,
          dayStyle: dayStyle,
          labelStyle: labelStyle,
          amountStyle: amountStyle,
          showDay: true,
          isGroupStart: false,
        );
      }).toList();
    }

    // Grouped list - group by day with visual headers
    // We need to group by the actual day number for sorting, not the formatted string
    final groups = <int, List<_SheetRow>>{};
    for (final row in rows) {
      // Parse day number from formatted string or use item's dayOfMonth
      final dayNum = effectiveDayOfMonth(row.item.dayOfMonth, month);
      (groups[dayNum] ??= []).add(row);
    }

    // Sort groups using the same logic as item sorting (handles paycheck mode correctly)
    final sortedDays = groups.keys.toList();
    sortedDays.sort((a, b) {
      final aSortValue = daySortValue(a, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      final bSortValue = daySortValue(b, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      // Apply sort order (chronological or reverse)
      return sortOrder == PlannerSortOrder.chronological
          ? aSortValue.compareTo(bSortValue)
          : bSortValue.compareTo(aSortValue);
    });

    final widgets = <Widget>[];
    for (int groupIdx = 0; groupIdx < sortedDays.length; groupIdx++) {
      final day = sortedDays[groupIdx];
      final groupItems = groups[day]!;
      final hasMultipleItems = groupItems.length > 1;

      // Only show group header if there are multiple items on this day
      if (hasMultipleItems) {
        // Add a compact group header row
        widgets.add(
          Container(
            width: totalColumnWidth,
            height: rowHeight * 0.7,
            padding: EdgeInsets.symmetric(horizontal: columnPadding),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
              border: Border(
                bottom: BorderSide(
                  color: dividerColor.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Text(
                  formatDayOfMonth(day, dayFormat),
                  style: dayStyle?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 9,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Container(
                    height: 0.5,
                    color: dividerColor.withValues(alpha: 0.3),
                  ),
                ),
              ],
            ),
          ),
        );

        // Add items in this group (without day column since header shows it)
        for (final row in groupItems) {
          widgets.add(
            _buildRowWidget(
              context,
              row: row,
              isCurrent: isCurrent,
              totalColumnWidth: totalColumnWidth,
              rowHeight: rowHeight,
              columnPadding: columnPadding,
              dayWidth: dayWidth,
              amountWidth: amountWidth,
              dividerColor: dividerColor,
              dayStyle: dayStyle,
              labelStyle: labelStyle,
              amountStyle: amountStyle,
              showDay: false,
              isGroupStart: false,
            ),
          );
        }
      } else {
        // Single item - show inline with day (like flat view)
        widgets.add(
          _buildRowWidget(
            context,
            row: groupItems.first,
            isCurrent: isCurrent,
            totalColumnWidth: totalColumnWidth,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            dayWidth: dayWidth,
            amountWidth: amountWidth,
            dividerColor: dividerColor,
            dayStyle: dayStyle,
            labelStyle: labelStyle,
            amountStyle: amountStyle,
            showDay: true,
            isGroupStart: false,
          ),
        );
      }
    }

    return widgets;
  }

  Widget _buildRowWidget(
    BuildContext context, {
    required _SheetRow row,
    required bool isCurrent,
    required double totalColumnWidth,
    required double rowHeight,
    required double columnPadding,
    required double dayWidth,
    required double amountWidth,
    required Color dividerColor,
    required TextStyle? dayStyle,
    required TextStyle? labelStyle,
    required TextStyle? amountStyle,
    required bool showDay,
    required bool isGroupStart,
  }) {
    return Opacity(
      opacity: (row.isCleared && isCurrent) ? 0.5 : 1.0,
      child: Container(
        width: totalColumnWidth,
        height: rowHeight,
        padding: EdgeInsets.symmetric(horizontal: columnPadding),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: dividerColor.withValues(alpha: 0.15),
              width: 0.5,
            ),
          ),
        ),
        child: Row(
          children: [
            // Day (only if showDay is true)
            if (showDay)
              SizedBox(
                width: dayWidth,
                child: Text(
                  row.day,
                  style: dayStyle,
                  textAlign: TextAlign.left,
                ),
              ),
            // Label - use Expanded to prevent overflow
            Expanded(
              child: displayMode == PaymentDisplayMode.icon
                  ? Icon(
                      getPaymentIcon(row.label, type: row.item.type),
                      size: 14,
                      color: (row.isCleared && isCurrent)
                          ? Theme.of(context).colorScheme.onSurfaceVariant
                          : Theme.of(context).colorScheme.onSurface,
                    )
                  : displayMode == PaymentDisplayMode.acronym
                      ? Text(
                          _buildDisplayLabel(generateAcronym(row.label), row.item),
                          maxLines: 1,
                          overflow: TextOverflow.clip,
                          style: labelStyle?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: (row.isCleared && isCurrent)
                                ? Theme.of(context).colorScheme.onSurfaceVariant
                                : Theme.of(context).colorScheme.onSurface,
                          ),
                        )
                      : Text(
                          _buildDisplayLabel(row.label, row.item),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: (row.isCleared && isCurrent)
                              ? labelStyle?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                )
                              : labelStyle,
                        ),
            ),
            // Amount
            SizedBox(
              width: amountWidth,
              child: Text(
                formatMoneyFromCents(row.amountCents, currency, showCents: settings.showCents),
                textAlign: TextAlign.right,
                style: amountStyle?.copyWith(
                  color: row.item.type.isIncomeType
                      ? settings.creditColor
                      : settings.debitColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<_SheetRow> _buildRows(PeriodInfo periodInfo) {
    PaymentEntry? paymentFor(PlannerItem item) {
      PaymentEntry? best;
      for (final payment in payments) {
        if (!paymentMatchesPlannerItem(payment, item, month, settings)) continue;
        if (best == null || payment.date.isAfter(best.date)) best = payment;
      }
      return best;
    }

    final rows = <_SheetRow>[];
    // Filter items to only those that should appear in this month
    final monthItems = items.where((item) => item.shouldAppearInMonth(month)).toList(growable: false);
    final sortedItems = orderedPlannerItems(
      monthItems,
      sortOrder,
      viewMode: settings.viewPeriodMode,
      periodInfo: periodInfo,
    );
    for (final item in sortedItems) {
      final payment = paymentFor(item);
      final displayValues = getDisplayValues(
        item: item,
        month: month,
        payment: payment,
      );
      final isCleared = payment != null;
      if (!showCleared &&
          isCleared &&
          !recentlyClearedItemIds.contains(item.id)) {
        continue;
      }
      rows.add(
        _SheetRow(
          day: formatDayOfMonth(displayValues.date.day, dayFormat),
          label: item.label,
          amountCents: displayValues.amountCents,
          isCleared: isCleared,
          item: item,
        ),
      );
    }
    return rows;
  }
}

class _SheetRow {
  const _SheetRow({
    required this.day,
    required this.label,
    required this.amountCents,
    required this.isCleared,
    required this.item,
  });

  final String day;
  final String label;
  final int amountCents;
  final bool isCleared;
  final PlannerItem item;
}

class _FooterRow extends StatelessWidget {
  const _FooterRow({
    required this.label,
    required this.value,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    this.valueColor,
    this.onTap,
  });

  final String label;
  final String value;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final Color? valueColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.labelSmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 11,
          fontWeight: FontWeight.w600,
        );

    Widget row = Container(
      width: totalColumnWidth,
      height: rowHeight,
      padding: EdgeInsets.symmetric(horizontal: columnPadding),
      decoration: BoxDecoration(
        color: background,
        border: Border(
          top: BorderSide(color: dividerColor, width: 1),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: style,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            value,
            style: style?.copyWith(color: valueColor),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: row,
        ),
      );
    }
    return row;
  }
}
