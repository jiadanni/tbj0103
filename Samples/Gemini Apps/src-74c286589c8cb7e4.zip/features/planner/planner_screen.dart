import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_screen_controller.dart';
import 'package:expense_stalker_mobile/src/features/planner/view_mode_builders.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/planner/quick_add_helpers.dart';
import 'package:expense_stalker_mobile/src/features/planner/widgets/grid_zoom_controls.dart';
import 'package:expense_stalker_mobile/src/widgets/account_selector.dart';


class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key});

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  // View mode is now persisted in AppSettingsStore.plannerViewMode
  double _lastScale = 1.0;
  bool _hasAdjustedForPaycheckMode = false;
  int _monthWindowSize = PlannerScreenController.monthWindowSize;
  bool _didScheduleInitialMonthSync = false;

  late PlannerScreenController _controller;

  @override
  void initState() {
    super.initState();
    _controller = PlannerScreenController(
      monthOrigin: monthOnly(DateTime.now()),
      pageController: PageController(initialPage: PlannerScreenController.monthOriginPage),
      sheetTransformController: TransformationController(),
      gridTransformController: TransformationController(),
    );

    // Schedule check for paycheck mode after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkAndAdjustForPaycheckMode();
    });
  }

  void _checkAndAdjustForPaycheckMode() {
    if (_hasAdjustedForPaycheckMode || !mounted) return;

    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    // If we're in paycheck mode and it's configured, ensure we're showing the current period
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      final now = DateTime.now();
      final correctMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        now,
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

      // Only update if different from current selected month
      if (store.selectedMonth.year != correctMonth.year ||
          store.selectedMonth.month != correctMonth.month) {
        store.setSelectedMonth(correctMonth);
      }
    }

    _hasAdjustedForPaycheckMode = true;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _setViewMode(AppSettingsStore settings, PlannerViewMode mode) {
    if (settings.plannerViewMode == mode) return;
    settings.plannerViewMode = mode;
    if (mode == PlannerViewMode.grid) {
      _controller.didInitGridTransform = false;
    } else if (mode == PlannerViewMode.sheet) {
      _controller.didInitSheetTransform = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final earliestMonth = _computeEarliestMonth(store);
        final effectiveSelectedMonth = store.selectedMonth.isBefore(earliestMonth)
            ? earliestMonth
            : store.selectedMonth;
        final latestMonth = _computeLatestMonth(
          earliestMonth,
          effectiveSelectedMonth,
        );
        final monthWindowSize = monthsBetween(earliestMonth, latestMonth) + 1;
        _monthWindowSize = monthWindowSize;

        final nextOrigin = monthOnly(
          month_math.addMonths(
            earliestMonth,
            PlannerScreenController.monthOriginPage,
          ),
        );
        if (_controller.monthOrigin != nextOrigin) {
          _controller.monthOrigin = nextOrigin;
        }
        _ensureSelectedMonthWithinRange(store, earliestMonth);
        _syncMonthPageIfNeeded(effectiveSelectedMonth, monthWindowSize);
        return ListenableBuilder(
          listenable: settings,
          builder: (context, _) {
            final now = DateTime.now();
            final todayLabel = dateLabel(now);
            final selectedMonth = effectiveSelectedMonth;
            final selectedMonthOnly = monthOnly(selectedMonth);
            final viewMode = settings.plannerViewMode;

            // Determine current period reference month for paycheck mode
            final DateTime currentPeriodMonth;
            if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
                settings.isPaycheckModeConfigured) {
              currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
                now,
                settings.paycheckDay!,
                businessAdjust: settings.paycheckBusinessAdjust,
                adjustDirection: settings.paycheckBusinessAdjustDirection,
              );
            } else {
              currentPeriodMonth = monthOnly(now);
            }

            final isSelectedCurrentPeriod =
                selectedMonthOnly.year == currentPeriodMonth.year &&
                    selectedMonthOnly.month == currentPeriodMonth.month;

            return Scaffold(
              body: SafeArea(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        AppConstants.paddingMedium,
                        AppConstants.paddingNormal,
                        AppConstants.paddingMedium,
                        AppConstants.paddingSmall,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: const AccountSelector(),
                          ),
                          Visibility(
                            maintainSize: true,
                            maintainAnimation: true,
                            maintainState: true,
                            visible: isSelectedCurrentPeriod && viewMode != PlannerViewMode.sheet,
                            child: ListenableBuilder(
                              listenable: settings,
                              builder: (context, _) {
                                final showCleared = settings.plannerShowClearedItems;
                                final terminology = Terminology.of(context);
                                return IconButton(
                                  tooltip: showCleared
                                      ? terminology.showPaidLabel
                                      : terminology.hidePaidLabel,
                                  onPressed: () =>
                                      settings.plannerShowClearedItems = !showCleared,
                                  icon: Icon(
                                    showCleared
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                  ),
                                );
                              },
                            ),
                          ),
                          if (viewMode == PlannerViewMode.grid)
                            ListenableBuilder(
                              listenable: _controller.gridTransformController,
                              builder: (context, _) {
                                final currentTargetMonths = _controller.gridTargetMonths;
                                // Use segmented buttons for quick single-tap zoom control
                                return GridZoomButtons(
                                  currentMonths: currentTargetMonths,
                                  onChanged: (value) {
                                    setState(() {
                                      _controller.jumpToGridMonths(value);
                                    });
                                  },
                                );
                              },
                            ),
                          if (viewMode == PlannerViewMode.sheet)
                            ListenableBuilder(
                              listenable: _controller.sheetTransformController,
                              builder: (context, _) {
                                final currentStage = _controller.sheetZoomStageForWidth(
                                  _controller.lastSheetViewportWidth ?? 0,
                                );
                                // Use segmented buttons for quick single-tap zoom control
                                return SheetZoomButtons(
                                  currentStage: currentStage,
                                  onChanged: _controller.jumpToZoomStage,
                                );
                              },
                            ),
                          PopupMenuButton<PlannerViewMode>(
                            tooltip: AppLocalizations.of(context)!.viewMode,
                            icon: const Icon(Icons.view_agenda_outlined),
                            onSelected: (mode) => _setViewMode(settings, mode),
                            itemBuilder: (context) => [
                              CheckedPopupMenuItem<PlannerViewMode>(
                                value: PlannerViewMode.month,
                                checked: viewMode == PlannerViewMode.month,
                                child: Text(AppLocalizations.of(context)!.singleMonthView),
                              ),
                              CheckedPopupMenuItem<PlannerViewMode>(
                                value: PlannerViewMode.grid,
                                checked: viewMode == PlannerViewMode.grid,
                                child: Text(AppLocalizations.of(context)!.multiMonthGrid),
                              ),
                              CheckedPopupMenuItem<PlannerViewMode>(
                                value: PlannerViewMode.sheet,
                                checked: viewMode == PlannerViewMode.sheet,
                                child: Text(AppLocalizations.of(context)!.spreadsheetView),
                              ),
                            ],
                          ),
                          IconButton(
                            tooltip: 'Quick Add',
                            onPressed: () => showQuickAddFlow(context, store),
                            icon: const Icon(Icons.flash_on),
                          ),
                          IconButton(
                            tooltip: AppLocalizations.of(context)!.optionsTitle,
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const OptionsScreen(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.settings_outlined),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          if (viewMode == PlannerViewMode.month) {
                            return GestureDetector(
                              onScaleStart: (_) {
                                _lastScale = 1.0;
                              },
                              onScaleUpdate: (details) {
                                _lastScale = details.scale;
                              },
                              onScaleEnd: (_) {
                                if (_lastScale < AppConstants.pinchScaleThreshold) {
                                  _setViewMode(settings, PlannerViewMode.grid);
                                }
                                _lastScale = 1.0;
                              },
                              child: buildMonthView(
                                context: context,
                                pageController: _controller.pageController,
                                store: store,
                                settings: settings,
                                monthOrigin: _controller.monthOrigin,
                                monthOriginPage: PlannerScreenController.monthOriginPage,
                                monthWindowSize: _monthWindowSize,
                                onPinchOut: () {
                                  _setViewMode(settings, PlannerViewMode.grid);
                                },
                                onPageChanged: (index) {
                                  store.setSelectedMonth(
                                    monthForPage(
                                      _controller.monthOrigin,
                                      index,
                                      PlannerScreenController.monthOriginPage,
                                    ),
                                  );
                                },
                                paymentsBuilder: (month) => (month, periodInfo) =>
                                    store.paymentsForMonth(month, periodInfo: periodInfo),
                              ),
                            );
                          }

                          if (viewMode == PlannerViewMode.grid) {
                            _controller.lastGridViewportWidth = constraints.maxWidth;
                            _controller.lastGridViewportHeight = constraints.maxHeight;
                            _controller.ensureInitialGridTransform(
                              viewportWidth: constraints.maxWidth,
                              viewportHeight: constraints.maxHeight,
                            );
                            final gridDimensions = _controller.gridDimensionsForViewport(
                              viewportWidth: constraints.maxWidth,
                              viewportHeight: constraints.maxHeight,
                            );

                            return buildGridView(
                              context: context,
                              gridTransformController: _controller.gridTransformController,
                              store: store,
                              settings: settings,
                              viewportWidth: constraints.maxWidth,
                              selectedMonth: selectedMonth,
                              gridColumns: gridDimensions.columns,
                              onInitGridTransform: () {},
                              onMonthTapped: (month) {
                                store.setSelectedMonth(month);
                                _setViewMode(settings, PlannerViewMode.month);
                                _jumpToSelectedMonth(store);
                              },
                              paymentsBuilder: (month) => (month, periodInfo) =>
                                  store.paymentsForMonth(month, periodInfo: periodInfo),
                            );
                          }

                          _controller.lastSheetViewportWidth = constraints.maxWidth;
                          _controller.ensureInitialSheetTransform(
                            viewportWidth: constraints.maxWidth,
                          );

                          final zoomStage = _controller.sheetZoomStageForWidth(
                            constraints.maxWidth,
                          );
                          final baseBalance = settings.plannerUseZeroBaseline
                              ? 0
                              : settings.currentBalanceCents;

                          return buildSheetView(
                            context: context,
                            sheetTransformController: _controller.sheetTransformController,
                            store: store,
                            settings: settings,
                            viewportWidth: constraints.maxWidth,
                            selectedMonth: selectedMonth,
                            zoomStage: zoomStage,
                            startingBalanceCents: baseBalance,
                            onInitSheetTransform: () {},
                            onMonthTapped: (month) {
                              store.setSelectedMonth(month);
                              _setViewMode(settings, PlannerViewMode.month);
                              _jumpToSelectedMonth(store);
                            },
                            paymentsBuilder: (month) => (month, periodInfo) =>
                                store.paymentsForMonth(month, periodInfo: periodInfo),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _jumpToSelectedMonth(ExpenseStore store) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _syncMonthPageIfNeeded(store.selectedMonth, _monthWindowSize);
    });
  }

  DateTime _computeEarliestMonth(ExpenseStore store) {
    final items = store.activePlannerItems;
    final nowMonth = monthOnly(DateTime.now());
    if (items.isEmpty) return nowMonth;
    var earliest = monthOnly(items.first.startDate);
    for (final item in items.skip(1)) {
      final start = monthOnly(item.startDate);
      if (start.isBefore(earliest)) earliest = start;
    }
    return earliest.isAfter(nowMonth) ? nowMonth : earliest;
  }

  DateTime _computeLatestMonth(DateTime earliestMonth, DateTime selectedMonth) {
    final nowMonth = monthOnly(DateTime.now());
    final base = _maxMonth(_maxMonth(nowMonth, selectedMonth), earliestMonth);
    return monthOnly(
      month_math.addMonths(base, PlannerScreenController.monthOriginPage),
    );
  }

  DateTime _maxMonth(DateTime a, DateTime b) {
    final aMonth = monthOnly(a);
    final bMonth = monthOnly(b);
    return aMonth.isAfter(bMonth) ? aMonth : bMonth;
  }

  void _ensureSelectedMonthWithinRange(
    ExpenseStore store,
    DateTime earliestMonth,
  ) {
    if (!store.selectedMonth.isBefore(earliestMonth)) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      store.setSelectedMonth(earliestMonth);
    });
  }

  void _syncMonthPageIfNeeded(DateTime selectedMonth, int monthWindowSize) {
    if (_controller.pageController.hasClients) {
      _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
      return;
    }
    if (_didScheduleInitialMonthSync) return;
    _didScheduleInitialMonthSync = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _didScheduleInitialMonthSync = false;
      if (!mounted) return;
      _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
    });
  }

}
