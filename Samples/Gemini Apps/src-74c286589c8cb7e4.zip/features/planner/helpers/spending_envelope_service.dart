import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';

/// Service for spending envelope calculations.
///
/// Spending envelopes are PlannerItems with type [PaymentType.spendingEnvelope]
/// that track variable expenses against a target budget. Users log spending
/// via Quick Add, creating PaymentEntry records linked to the envelope.
class SpendingEnvelopeService {
  /// Calculates the period boundaries for a spending envelope.
  ///
  /// Returns a tuple of (periodStart, periodEnd) based on the envelope's
  /// dayOfMonth (reset day) and frequency.
  ///
  /// For monthly envelopes with dayOfMonth=1:
  /// - Period is 1st to last day of the reference month
  ///
  /// For monthly envelopes with dayOfMonth=15:
  /// - Period is 15th of one month to 14th of next month
  static (DateTime start, DateTime end) getEnvelopePeriodDates(
    PlannerItem envelope,
    DateTime referenceMonth,
  ) {
    final resetDay = envelope.dayOfMonth;
    final frequency = envelope.frequency ?? RecurrenceFrequency.monthly;

    switch (frequency) {
      case RecurrenceFrequency.weekly:
        // Find the most recent reset day (weekday matching resetDay mod 7)
        // For simplicity, treat weekly as starting from the 1st of month
        // and running in 7-day chunks
        final monthStart = DateTime.utc(referenceMonth.year, referenceMonth.month, 1);
        final monthEnd = DateTime.utc(referenceMonth.year, referenceMonth.month + 1, 0);
        return (monthStart, monthEnd);

      case RecurrenceFrequency.biweekly:
        // Similar to weekly, but 14-day chunks
        final monthStart = DateTime.utc(referenceMonth.year, referenceMonth.month, 1);
        final monthEnd = DateTime.utc(referenceMonth.year, referenceMonth.month + 1, 0);
        return (monthStart, monthEnd);

      case RecurrenceFrequency.monthly:
        if (resetDay == 1) {
          // Standard: 1st to last day of month
          final start = DateTime.utc(referenceMonth.year, referenceMonth.month, 1);
          final end = DateTime.utc(referenceMonth.year, referenceMonth.month + 1, 0);
          return (start, end);
        } else {
          // Custom reset day: e.g., 15th to 14th
          // Determine if we're before or after the reset day in the reference month
          final refDay = referenceMonth.day;
          
          if (refDay >= resetDay) {
            // Current period started this month on resetDay
            final start = DateTime.utc(referenceMonth.year, referenceMonth.month, resetDay);
            // Ends next month on resetDay - 1
            final nextMonth = DateTime.utc(referenceMonth.year, referenceMonth.month + 1, 1);
            final endDay = resetDay - 1;
            final maxEndDay = DateTime.utc(nextMonth.year, nextMonth.month + 1, 0).day;
            final end = DateTime.utc(nextMonth.year, nextMonth.month, endDay > maxEndDay ? maxEndDay : endDay);
            return (start, end);
          } else {
            // Current period started last month on resetDay
            final prevMonth = DateTime.utc(referenceMonth.year, referenceMonth.month - 1, 1);
            final maxPrevDay = DateTime.utc(prevMonth.year, prevMonth.month + 1, 0).day;
            final startDay = resetDay > maxPrevDay ? maxPrevDay : resetDay;
            final start = DateTime.utc(prevMonth.year, prevMonth.month, startDay);
            // Ends this month on resetDay - 1
            final endDay = resetDay - 1;
            final maxEndDay = DateTime.utc(referenceMonth.year, referenceMonth.month + 1, 0).day;
            final end = DateTime.utc(referenceMonth.year, referenceMonth.month, endDay > maxEndDay ? maxEndDay : endDay);
            return (start, end);
          }
        }

      case RecurrenceFrequency.quarterly:
        // 3-month periods starting from envelope's start month
        final startMonth = envelope.startDate;
        final monthsSinceStart = (referenceMonth.year - startMonth.year) * 12 +
            (referenceMonth.month - startMonth.month);
        final quarterIndex = monthsSinceStart ~/ 3;
        final quarterStartMonth = DateTime.utc(
          startMonth.year,
          startMonth.month + (quarterIndex * 3),
          1,
        );
        final quarterEndMonth = DateTime.utc(
          quarterStartMonth.year,
          quarterStartMonth.month + 3,
          0,
        );
        return (quarterStartMonth, quarterEndMonth);

      case RecurrenceFrequency.yearly:
        // Full year from start date anniversary
        final startMonth = envelope.startDate;
        final yearsSinceStart = referenceMonth.year - startMonth.year;
        final yearStart = DateTime.utc(
          startMonth.year + yearsSinceStart,
          startMonth.month,
          1,
        );
        final yearEnd = DateTime.utc(
          yearStart.year + 1,
          yearStart.month,
          0,
        );
        return (yearStart, yearEnd);
    }
  }

  /// Sums all PaymentEntry amounts linked to this envelope within the period.
  ///
  /// Returns the absolute value of spent amount (always positive).
  static int getSpentAmountForPeriod(
    PlannerItem envelope,
    List<PaymentEntry> allPayments,
    (DateTime start, DateTime end) period,
  ) {
    return allPayments
        .where((p) => p.plannerItemId == envelope.id)
        .where((p) => _isDateInPeriod(p.date, period))
        .fold(0, (sum, p) => sum + p.amountCents.abs());
  }

  /// Returns the remaining amount for the envelope period.
  ///
  /// Calculated as: target - spent (can be negative if overspent).
  static int getRemainingAmount(
    PlannerItem envelope,
    List<PaymentEntry> allPayments,
    (DateTime start, DateTime end) period,
  ) {
    final target = envelope.amountCents.abs();
    final spent = getSpentAmountForPeriod(envelope, allPayments, period);
    return target - spent;
  }

  /// Returns the spending progress as a ratio from 0.0 to 1.0+.
  ///
  /// Values > 1.0 indicate overspending.
  static double getProgress(
    PlannerItem envelope,
    List<PaymentEntry> allPayments,
    (DateTime start, DateTime end) period,
  ) {
    final target = envelope.amountCents.abs();
    if (target == 0) return 0.0;
    final spent = getSpentAmountForPeriod(envelope, allPayments, period);
    return spent / target;
  }

  /// Checks if a date falls within the given period (inclusive).
  static bool _isDateInPeriod(DateTime date, (DateTime start, DateTime end) period) {
    return DateMath.isInRangeInclusive(date, period.$1, period.$2);
  }
}
