import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';


List<PlannerItem> orderedPlannerItems(
  Iterable<PlannerItem> items,
  PlannerSortOrder order, {
  ViewPeriodMode viewMode = ViewPeriodMode.calendar,
  PeriodInfo? periodInfo,
}) {
  final sorted = items.toList(growable: false);
  sorted.sort((a, b) {
    final cmp = daySortValue(
      dayOfMonthValue(a),
      viewMode: viewMode,
      periodInfo: periodInfo,
    ).compareTo(
      daySortValue(
        dayOfMonthValue(b),
        viewMode: viewMode,
        periodInfo: periodInfo,
      ),
    );
    final ordered = order == PlannerSortOrder.chronological ? cmp : -cmp;
    if (ordered != 0) return ordered;
    return a.label.compareTo(b.label);
  });
  return sorted;
}

int dayOfMonthValue(PlannerItem item) => item.dayOfMonth;

int daySortValue(
  int day, {
  required ViewPeriodMode viewMode,
  PeriodInfo? periodInfo,
}) {
  if (viewMode != ViewPeriodMode.paycheck || periodInfo == null) {
    return day;
  }

  final startDay = periodInfo.start.day;
  final daysInStartMonth = DateTime.utc(
    periodInfo.start.year,
    periodInfo.start.month + 1,
    0,
  ).day;

  if (day >= startDay) {
    return day - startDay;
  }
  return (daysInStartMonth - startDay + 1) + day;
}
