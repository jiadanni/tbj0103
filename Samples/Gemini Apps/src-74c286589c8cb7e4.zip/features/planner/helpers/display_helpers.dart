import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';

// isPastMonth is now imported from planner_dates.dart

/// Holds display values for a payment (either scheduled or actual)
class DisplayValues {
  const DisplayValues({
    required this.date,
    required this.amountCents,
    required this.hasDateVariance,
    required this.hasAmountVariance,
    this.scheduledDate,
    this.scheduledAmountCents,
  });

  /// The date to display (actual if past month, scheduled otherwise)
  final DateTime date;

  /// The amount to display in cents (actual if past month, scheduled otherwise)
  final int amountCents;

  /// Whether the actual date differs from scheduled
  final bool hasDateVariance;

  /// Whether the actual amount differs from scheduled
  final bool hasAmountVariance;

  /// Original scheduled date (for variance display)
  final DateTime? scheduledDate;

  /// Original scheduled amount in cents (for variance display)
  final int? scheduledAmountCents;

  /// Returns the variance in days (positive if paid later, negative if earlier)
  int? getDateVarianceDays() {
    if (!hasDateVariance || scheduledDate == null) return null;
    return date.day - scheduledDate!.day;
  }

  /// Returns the variance in cents (positive if more paid, negative if less)
  int? getAmountVarianceCents() {
    if (!hasAmountVariance || scheduledAmountCents == null) return null;
    return amountCents - scheduledAmountCents!;
  }
}

/// Selects appropriate display values based on whether month is past/current
DisplayValues getDisplayValues({
  required PlannerItem item,
  required DateTime month,
  PaymentEntry? payment,
}) {
  final isPast = isPastMonth(month);

  // For past months with a recorded payment, show actuals
  if (isPast && payment != null) {
    return DisplayValues(
      date: payment.date,
      amountCents: payment.amountCents,
      hasDateVariance: payment.scheduledDate != null &&
                       payment.scheduledDate!.day != payment.date.day,
      hasAmountVariance: payment.scheduledAmountCents != null &&
                         payment.scheduledAmountCents != payment.amountCents,
      scheduledDate: payment.scheduledDate,
      scheduledAmountCents: payment.scheduledAmountCents,
    );
  }

  // For current/future months or items without payment, show scheduled
  final effectiveDay = effectiveDayOfMonth(item.dayOfMonth, month);
  return DisplayValues(
    date: DateTime.utc(month.year, month.month, effectiveDay),
    amountCents: item.amountCents,
    hasDateVariance: false,
    hasAmountVariance: false,
  );
}
