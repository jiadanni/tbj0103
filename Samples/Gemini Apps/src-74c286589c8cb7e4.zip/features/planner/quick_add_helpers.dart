import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';

void showQuickAddFlow(BuildContext context, ExpenseStore store) async {
  final quickItems = store.activePlannerItems.where((i) => i.isQuickAdd).toList();
  
  if (quickItems.isEmpty) {
    showDialog(
      context: context, 
      builder: (ctx) => AlertDialog(
        title: const Text('Quick Add'),
        content: const Text(
          'No Quick Add items found.\n\nEdit an existing planner item and check "Quick Add Capability" to enable quick adding for that item.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx), 
            child: const Text('OK'),
          ),
        ],
      ),
    );
    return;
  }

  PlannerItem? selected;
  if (quickItems.length == 1) {
    selected = quickItems.first;
  } else {
    selected = await showModalBottomSheet<PlannerItem>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => _QuickAddSelectorSheet(items: quickItems),
    );
  }

  if (selected != null && context.mounted) {
    showDialog(
      context: context, 
      builder: (ctx) => _QuickAddAmountDialog(item: selected!, store: store),
    );
  }
}

class _QuickAddSelectorSheet extends StatelessWidget {
  const _QuickAddSelectorSheet({required this.items});

  final List<PlannerItem> items;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Select Item',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Flexible(
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final item = items[index];
                return ListTile(
                  title: Text(item.label),
                  subtitle: item.company != null ? Text(item.company!) : null,
                  onTap: () => Navigator.pop(context, item),
                  leading: CircleAvatar(
                    backgroundColor: item.type.isIncomeType 
                        ? Colors.green.withOpacity(0.1) 
                        : Colors.red.withOpacity(0.1),
                    child: Icon(
                      item.type.isIncomeType ? Icons.arrow_upward : Icons.arrow_downward,
                      color: item.type.isIncomeType ? Colors.green : Colors.red,
                      size: 16,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _QuickAddAmountDialog extends StatefulWidget {
  const _QuickAddAmountDialog({required this.item, required this.store});

  final PlannerItem item;
  final ExpenseStore store;

  @override
  State<_QuickAddAmountDialog> createState() => _QuickAddAmountDialogState();
}

class _QuickAddAmountDialogState extends State<_QuickAddAmountDialog> {
  late final TextEditingController _amountController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // Pre-fill with item amount if it's non-zero, otherwise empty
    _amountController = TextEditingController();
    
    // Auto-focus
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;
    
    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return; // Invalid format
    
    final settings = AppSettingsScope.read(context);
    final roundedCents = roundUpToIncrement(
      rawAmountCents, 
      settings.roundingIncrement * 100,
    );
    
    // Apply sign from template item type
    final finalAmountCents = widget.item.type.isIncomeType 
        ? roundedCents 
        : -roundedCents; // Ensure expense is negative

    // Spending envelope: create PaymentEntry linked to envelope instead of new PlannerItem
    if (widget.item.type == PaymentType.spendingEnvelope) {
      final payment = PaymentEntry(
        id: newId(),
        label: widget.item.label,
        amountCents: finalAmountCents,
        date: dateOnly(DateTime.now()),
        type: PaymentType.spendingEnvelope,
        plannerItemId: widget.item.id,
        category: widget.item.category,
        company: widget.item.company,
        moneyPotId: widget.item.moneyPotId,
      );
      
      widget.store.upsertPayment(payment);
      settings.currentBalanceCents += payment.amountCents;
      
      if (mounted) {
        Navigator.pop(context);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Logged ${widget.item.label} expense')),
        );
      }
      return;
    }

    // Create new one-off item for other types
    final newItem = PlannerItem(
      id: newId(),
      label: widget.item.label,
      amountCents: finalAmountCents,
      dayOfMonth: DateTime.now().day,
      type: widget.item.type.isIncomeType ? PaymentType.oneOffIncome : PaymentType.oneOff,
      startDate: dateOnly(DateTime.now()),
      // Copy metadata
      category: widget.item.category,
      company: widget.item.company,
      moneyPotId: widget.item.moneyPotId,
      // Note: we don't copy isQuickAdd, as the new one-off doesn't need to be a template
    );
    
    widget.store.upsertPlannerItem(newItem);
    
    if (mounted) {
      Navigator.pop(context);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Added ${widget.item.label}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final isIncome = widget.item.type.isIncomeType;
    
    return AlertDialog(
      title: Text('Add ${widget.item.label}'),
      content: TextField(
        controller: _amountController,
        focusNode: _focusNode,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: 'Amount',
          prefixText: isIncome ? '+ ' : '- ',
          border: const OutlineInputBorder(),
        ),
        inputFormatters: [
          if (settings.showCents)
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
          else
            FilteringTextInputFormatter.digitsOnly,
          LengthLimitingTextInputFormatter(AppConstants.maxAmountLength),
        ],
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Add'),
        ),
      ],
    );
  }
}
