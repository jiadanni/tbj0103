/// Input validation constants and utilities.
///
/// Defines maximum lengths and bounds for user input to prevent
/// UI breakage, memory issues, and overflow errors.
library;

/// Maximum length for item labels (e.g., planner items, payment entries).
///
/// Prevents UI text overflow and database bloat.
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

/// Maximum length for item labels (e.g., planner items, payment entries).
///
/// Prevents UI text overflow and database bloat.
const int kMaxLabelLength = AppConstants.maxLabelLength;

/// Maximum length for notes fields.
///
/// Prevents memory exhaustion from extremely long text.
const int kMaxNotesLength = AppConstants.maxNotesLength;

/// Maximum amount in cents (equivalent to $99,999.99).
///
/// Prevents integer overflow and unrealistic values.
const int kMaxAmountCents = 9999999; // $99,999.99

/// Minimum amount in cents (equivalent to $0.01).
///
/// Negative amounts should use PaymentType.recurring with negative sign.
const int kMinAmountCents = 1;

/// Validates a label string.
///
/// Returns null if valid, or an error message if invalid.
String? validateLabel(String? label, String fieldName) {
  if (label == null || label.trim().isEmpty) {
    return '$fieldName is required';
  }
  if (label.length > kMaxLabelLength) {
    return '$fieldName must be $kMaxLabelLength characters or less';
  }
  return null;
}

/// Validates a notes string.
///
/// Returns null if valid, or an error message if invalid.
String? validateNotes(String? notes) {
  if (notes == null || notes.trim().isEmpty) {
    return null; // Notes are optional
  }
  if (notes.length > kMaxNotesLength) {
    return 'Notes must be $kMaxNotesLength characters or less';
  }
  return null;
}

/// Validates an amount in cents.
///
/// Returns null if valid, or an error message if invalid.
/// Note: This validates the absolute amount - sign is handled by PaymentType.
String? validateAmountCents(int? amountCents) {
  if (amountCents == null) {
    return 'Amount is required';
  }
  // Check for negative amounts explicitly (amountCents should be positive;
  // the sign is determined by PaymentType, not the amount value)
  if (amountCents < 0) {
    return 'Amount cannot be negative';
  }
  if (amountCents < kMinAmountCents) {
    return 'Amount must be at least \$0.01';
  }
  if (amountCents > kMaxAmountCents) {
    return 'Amount must be \$99,999.99 or less';
  }
  return null;
}
