/// A simple Least Recently Used (LRU) cache implementation using LinkedHashMap.
///
/// When the cache reaches [maxSize], the least recently accessed
/// entry is evicted to make room for new entries.
///
/// This implementation uses Dart's [LinkedHashMap] which maintains insertion
/// order and provides O(1) operations for get, put, and eviction.
class LruCache<K, V> {
  LruCache(this.maxSize) : assert(maxSize > 0, 'maxSize must be positive');

  final int maxSize;

  /// LinkedHashMap preserves insertion order (oldest first).
  /// We use it to track access order with O(1) operations.
  final Map<K, V> _cache = <K, V>{};

  /// Gets a value from the cache.
  ///
  /// Returns null if the key is not in the cache.
  /// Updates access order when key is found (O(1) operation).
  V? get(K key) {
    final value = _cache.remove(key);
    if (value != null) {
      // Re-insert to move to end (most recently used)
      _cache[key] = value;
    }
    return value;
  }

  /// Puts a value in the cache.
  ///
  /// If the cache is full, evicts the least recently used entry.
  /// All operations are O(1).
  void put(K key, V value) {
    // If key exists, remove it first to update access order
    if (_cache.containsKey(key)) {
      _cache.remove(key);
    } else if (_cache.length >= maxSize) {
      // Cache is full, evict LRU entry (first key in LinkedHashMap)
      final lruKey = _cache.keys.first;
      _cache.remove(lruKey);
    }

    // Add new entry at the end (most recently used position)
    _cache[key] = value;
  }

  /// Returns the current number of entries in the cache.
  int get length => _cache.length;

  /// Clears all entries from the cache.
  void clear() {
    _cache.clear();
  }

  /// Returns whether the cache contains a key.
  bool containsKey(K key) => _cache.containsKey(key);
}
