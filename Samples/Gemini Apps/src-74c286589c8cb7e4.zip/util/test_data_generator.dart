import 'dart:math';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum TestDatasetSize {
  minimal(10),
  standard(50),
  large(300),
  stress(1000);

  final int paymentCount;
  const TestDatasetSize(this.paymentCount);
}

class TestDataGenerator {
  static const _categories = [
    'Food', 'Rent', 'Utilities', 'Salary', 'Entertainment', 'Transport', 
    'Health', 'Insurance', 'Savings', 'Gifts', 'Debt', 'Gym'
  ];

  static const _companies = [
    'Albert Heijn', 'KPN', 'Vattenfall', 'HealthCity', 'NS', 'Amazon',
    'Netflix', 'Spotify', 'ING', 'T-Mobile', 'Shell', 'Local Gym'
  ];

  static final _random = Random(42); // Fixed seed for reproducible results

  static (List<PlannerItem>, List<PaymentEntry>) generate({
    required TestDatasetSize size,
    DateTime? endDate,
  }) {
    final plannerItems = <PlannerItem>[];
    final payments = <PaymentEntry>[];
    final now = DateTime.now();
    final end = endDate ?? DateTime.utc(now.year, now.month);
    
    // 1. Generate core recurring planner items (ensures 100% feature coverage)
    final coreItems = [
      _createRecurring('Salary', 450000, 25, PaymentType.recurringIncome, 'Work', 'Salary'),
      _createRecurring('Rent', -150000, 1, PaymentType.recurring, 'Landlord', 'Rent'),
      _createRecurring('Electricity', -8500, 28, PaymentType.recurring, 'Vattenfall', 'Utilities'),
      _createRecurring('Internet', -5500, 15, PaymentType.recurring, 'KPN', 'Utilities'),
      _createDebt('Student Loan', -50000, 28, 2000000),
      _createRecurring('Groceries Envelope', -40000, 1, PaymentType.spendingEnvelope, 'Multiple', 'Food'),
    ];
    plannerItems.addAll(coreItems);

    // 2. Generate random planner items to fill up
    final targetPlannerItems = (size.paymentCount / 10).clamp(15, 60).toInt();
    while (plannerItems.length < targetPlannerItems) {
      plannerItems.add(_generateRandomPlannerItem());
    }

    // 3. Generate individual payments across months
    // We'll generate payments for the last 12 months or until target count is reached
    var currentMonth = DateTime.utc(end.year, end.month - 11);
    var generatedPayments = 0;

    while (generatedPayments < size.paymentCount && !currentMonth.isAfter(end)) {
      // Generate payments from planner items for this month
      for (final item in plannerItems) {
        if (item.shouldAppearInMonth(currentMonth)) {
          payments.add(PaymentEntry(
            id: newId(),
            label: item.label,
            amountCents: item.amountCents + (item.type == PaymentType.oneOff ? 0 : _randomVar(item.amountCents)),
            date: DateTime.utc(currentMonth.year, currentMonth.month, item.dayOfMonth),
            type: item.type,
            plannerItemId: item.id,
            category: item.category,
            company: item.company,
          ));
          generatedPayments++;
        }
      }

      // Add some random one-off payments not linked to planner
      final oneOffsCount = _random.nextInt(5) + 2;
      for (var i = 0; i < oneOffsCount; i++) {
        final isIncome = _random.nextDouble() < 0.1;
        final amount = isIncome ? (_random.nextInt(5000) + 1000) : -(_random.nextInt(10000) + 500);
        payments.add(PaymentEntry(
          id: newId(),
          label: 'Random ${_categories[_random.nextInt(_categories.length)]}',
          amountCents: amount,
          date: DateTime.utc(currentMonth.year, currentMonth.month, _random.nextInt(28) + 1),
          type: isIncome ? PaymentType.oneOffIncome : PaymentType.oneOff,
          category: _categories[_random.nextInt(_categories.length)],
          company: _companies[_random.nextInt(_companies.length)],
        ));
        generatedPayments++;
      }

      currentMonth = DateTime.utc(currentMonth.year, currentMonth.month + 1);
    }

    return (plannerItems, payments);
  }

  static int _randomVar(int amount) {
    if (amount.abs() < 1000) return 0;
    final variation = (amount.abs() * 0.05).toInt();
    if (variation == 0) return 0;
    return _random.nextInt(variation * 2) - variation;
  }

  static PlannerItem _createRecurring(String label, int amount, int day, PaymentType type, String company, String category) {
    return PlannerItem(
      id: newId(),
      label: label,
      amountCents: amount,
      dayOfMonth: day,
      type: type,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      company: company,
      category: category,
    );
  }

  static PlannerItem _createDebt(String label, int amount, int day, int total) {
    return PlannerItem(
      id: newId(),
      label: label,
      amountCents: amount,
      dayOfMonth: day,
      type: PaymentType.debt,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      remainingBalanceCents: total,
      originalAmountCents: total,
      category: 'Debt',
    );
  }

  static PlannerItem _generateRandomPlannerItem() {
    final isIncome = _random.nextDouble() < 0.2;
    final category = _categories[_random.nextInt(_categories.length)];
    return PlannerItem(
      id: newId(),
      label: 'Regular $category',
      amountCents: isIncome ? (_random.nextInt(100000) + 10000) : -(_random.nextInt(50000) + 2000),
      dayOfMonth: _random.nextInt(28) + 1,
      type: isIncome ? PaymentType.recurringIncome : PaymentType.recurring,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      category: category,
      company: _companies[_random.nextInt(_companies.length)],
    );
  }
}
