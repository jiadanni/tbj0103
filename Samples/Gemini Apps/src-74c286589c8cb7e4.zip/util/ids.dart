import 'package:uuid/uuid.dart';

final _uuid = const Uuid();

String newId() => _uuid.v4();
