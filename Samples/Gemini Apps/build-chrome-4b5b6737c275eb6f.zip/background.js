(function () {
  'use strict';

  /**
   * Centralized Logging Utility
   * Provides consistent logging across the extension with verbose mode support
   *
   * @module logger
   */

  // ============================================================================
  // LOG LEVELS
  // ============================================================================

  /**
   * Log severity levels
   * @enum {string}
   * @readonly
   */
  const LogLevel = {
    ERROR: 'error',   // Critical errors that need immediate attention
    WARN: 'warn',     // Warnings about potential issues
    INFO: 'info',     // Important informational messages (always shown)
    DEBUG: 'debug',   // Detailed debugging information (verbose mode only)
    TRACE: 'trace'    // Very detailed trace information (verbose mode only)
  };

  // ============================================================================
  // LOGGER CLASS
  // ============================================================================

  class Logger {
    /**
     * Create a new logger instance with optional context.
     *
     * @param {string} [context='PandAid'] - Context name for this logger (appears in all log messages)
     */
    constructor(context = 'PandAid') {
      this.context = context;
      this.verboseEnabled = false;
      this.initialized = false;

      // Kick off async load without blocking construction
      this.loadVerbosePreference().catch((error) => {
        logger$w.warn('[Logger] Failed to load verbose preference', 'logger', error);
      });
    }

    /**
     * Load verbose logging preference from Chrome storage.
     * Called automatically during constructor initialization.
     *
     * @private
     * @async
     * @returns {Promise<void>}
     */
    async loadVerbosePreference() {
      if (this.initialized) return;
      this.initialized = true;

      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        return;
      }

      try {
        const result = await chrome.storage.local.get(['verboseLogging']);
        if (Object.prototype.hasOwnProperty.call(result, 'verboseLogging')) {
          this.verboseEnabled = !!result.verboseLogging;
        }
      } catch (error) {
        logger$w.warn('[Logger] Error reading verbose logging preference', 'logger', error);
      }
    }

    /**
     * Set verbose mode at runtime.
     * Useful for toggling detailed logging during debugging or testing.
     *
     * @param {boolean} enabled - Whether to enable verbose logging
     */
    setVerbose(enabled = false) {
      this.verboseEnabled = !!enabled;
    }

    /**
     * Check if verbose logging is currently enabled.
     *
     * @returns {boolean} True if verbose logging is enabled
     */
    isVerboseEnabled() {
      return this.verboseEnabled;
    }

    /**
     * Format log message with timestamp and context.
     * Internal helper method for consistent formatting across all log levels.
     *
     * @private
     * @param {string} level - Log level (from LogLevel enum)
     * @param {string} context - Additional context string
     * @param {string} message - The message to format
     * @returns {string} Formatted message with timestamp
     */
    formatMessage(level, context, message) {
      const timestamp = new Date().toISOString().substring(11, 23); // HH:MM:SS.mmm
      const contextLabel = context ? `${this.context}:${context}` : this.context;
      return `[${timestamp}] [${contextLabel}] [${level.toUpperCase()}] ${message}`;
    }

    /**
     * Log error message (always shown regardless of verbose mode).
     * Use for critical errors that need immediate attention.
     *
     * @param {string} message - The error message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data/error object to log
     */
    error(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.ERROR, context, message);
      if (data !== null) {
        console.error(formatted, data);
      } else {
        console.error(formatted);
      }
    }

    /**
     * Log warning message (always shown regardless of verbose mode).
     * Use for potential issues or unexpected conditions.
     *
     * @param {string} message - The warning message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    warn(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.WARN, context, message);
      if (data !== null) {
        console.warn(formatted, data);
      } else {
        console.warn(formatted);
      }
    }

    /**
     * Log info message (always shown regardless of verbose mode).
     * Use for important informational messages about normal operation.
     *
     * @param {string} message - The info message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    info(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.INFO, context, message);
      if (data !== null) {
        console.info(formatted, data);
      } else {
        console.info(formatted);
      }
    }

    /**
     * Log debug message (only shown if verbose logging is enabled).
     * Use for detailed debugging information during development/troubleshooting.
     *
     * @param {string} message - The debug message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    debug(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.DEBUG, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Log trace message (only shown if verbose logging is enabled).
     * Used for very detailed logging like function entry/exit, state changes, etc.
     *
     * @param {string} message - The trace message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    trace(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.TRACE, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Create a child logger with a specific context.
     * Child loggers inherit the parent's verbose mode setting.
     *
     * @param {string} childContext - The child context name (appended to parent context)
     * @returns {Logger} New logger instance with combined context
     */
    child(childContext) {
      const childLogger = new Logger(`${this.context}:${childContext}`);
      childLogger.setVerbose(this.verboseEnabled);
      childLogger.initialized = true; // Do not re-read storage; inherit setting
      return childLogger;
    }

    /**
     * Log a group of related messages together.
     * Groups are only shown if verbose logging is enabled.
     *
     * @param {string} groupName - Name/title of the log group
     * @param {Function} fn - Function containing logger calls to group
     */
    group(groupName, fn) {
      if (!this.verboseEnabled) return;

      console.group(`[${this.context}] ${groupName}`);
      try {
        fn();
      } finally {
        console.groupEnd();
      }
    }

    /**
     * Execute a function and log its execution time.
     * Timing output is only shown if verbose logging is enabled.
     *
     * @param {string} label - Label for the timer (shown in timing output)
     * @param {Function} fn - Async function to time (can also be sync)
     * @returns {Promise<*>} Result of the function
     */
    async time(label, fn) {
      const timerLabel = `[${this.context}] ${label}`;
      if (this.verboseEnabled) {
        console.time(timerLabel);
      }

      try {
        return await fn();
      } finally {
        if (this.verboseEnabled) {
          console.timeEnd(timerLabel);
        }
      }
    }
  }

  // ============================================================================
  // GLOBAL LOGGER INSTANCE
  // ============================================================================

  // Create default logger instance
  const defaultLogger = new Logger('PandAid');

  // Export factory function
  function createLogger(context = 'PandAid') {
    const newLogger = new Logger(context);
    newLogger.setVerbose(defaultLogger.isVerboseEnabled());
    return newLogger;
  }

  // Export default logger
  const logger$w = defaultLogger;

  // ============================================================================
  // STORAGE LISTENER
  // ============================================================================

  // Listen for changes to verbose logging preference
  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.verboseLogging) {
        const newValue = !!changes.verboseLogging.newValue;
        defaultLogger.setVerbose(newValue);
        logger$w.info(`[PandAid] Verbose logging ${newValue ? 'enabled' : 'disabled'}`, 'contextual', undefined);
      }
    });
  }

  // modules/config/constants.js
  //
  // Centralized configuration constants for timeouts, intervals, and limits.
  // Import from here instead of using magic numbers throughout the codebase.

  // =============================================================================
  // API TIMEOUTS
  // =============================================================================

  /** Default timeout for AI service requests (ms) */
  const AI_REQUEST_TIMEOUT_MS = 15000;

  /** Timeout for Atlassian API requests - allows for slower tenants (ms) */
  const ATLASSIAN_TIMEOUT_MS = 30000;

  /** Timeout for AI analysis orchestration in message handlers (ms) */
  const AI_ANALYSIS_TIMEOUT_MS = 10000;

  /** Timeout for JIRA ticket fetch in message handlers (ms) */
  const JIRA_TICKETS_TIMEOUT_MS = 5000;

  /** Timeout for knowledge base search in message handlers (ms) */
  const KNOWLEDGE_BASE_TIMEOUT_MS = 8000;

  /** Maximum retries for failed API requests */
  const MAX_API_RETRIES = 2;

  // =============================================================================
  // AUTH & SECURITY
  // =============================================================================

  /** Number of consecutive auth failures before invalidating token */
  const AUTH_FAILURE_THRESHOLD$1 = 5;

  /** Time window for counting auth failures (ms) - 10 minutes */
  const AUTH_FAILURE_WINDOW_MS$1 = 10 * 60 * 1000;

  // =============================================================================
  // CACHE
  // =============================================================================

  /** Default cache TTL (ms) - 5 minutes */
  const CACHE_TTL_MS = 5 * 60 * 1000;

  /** Maximum number of cached entries before eviction */
  const CACHE_MAX_ENTRIES = 100;

  /** Maximum bytes per cache entry */
  const CACHE_MAX_ENTRY_BYTES = 512 * 1024;

  /** Quota safety margin to avoid storage write failures */
  const CACHE_QUOTA_SAFETY_MARGIN = 0.9;

  /** Debounce delay for persisting cache changes (ms) */
  const CACHE_PERSIST_DEBOUNCE_MS = 750;

  /** Maximum age for auto-save data to be considered recent (ms) - 24 hours */
  const AUTO_SAVE_RECENT_THRESHOLD_MS = 24 * 60 * 60 * 1000;

  /** Service-specific rate limiter configuration */
  const RATE_LIMIT_CONFIG = {
    ai: {
      maxTokens: 5,
      refillRate: 1,
      refillIntervalMs: 1000,
      baseDelayMs: 2000,
      maxBackoffMs: 60000
    },
    atlassian: {
      maxTokens: 10,
      refillRate: 2,
      refillIntervalMs: 1000,
      baseDelayMs: 5000,
      maxBackoffMs: 120000
    },
    local: {
      maxTokens: 20,
      refillRate: 5,
      refillIntervalMs: 1000
    }
  };

  /**
   * User Notification Utility
   * Provides user-visible error messages and notifications
   */


  const logger$v = createLogger('UserNotifications');

  /**
   * Notification types
   */
  const NotificationType = {
    ERROR: 'error',
    WARNING: 'warning',
    INFO: 'info',
    SUCCESS: 'success'
  };

  /**
   * Notification severity levels
   */
  const NotificationSeverity = {
    CRITICAL: 'critical',  // System-breaking errors
    HIGH: 'high',          // Feature-breaking errors
    MEDIUM: 'medium',      // Degraded functionality
    LOW: 'low'             // Minor issues
  };

  /**
   * Shows a notification to the user
   * @param {string} message - User-friendly message
   * @param {Object} options - Notification options
   * @param {string} options.type - Notification type (error, warning, info, success)
   * @param {string} options.severity - Severity level
   * @param {string} options.title - Optional title
   * @param {number} options.duration - Duration in ms (0 for persistent)
   * @param {boolean} options.persist - Whether to keep notification visible
   * @param {Object} options.technicalDetails - Technical details for debugging (not shown to user)
   */
  function showNotification(message, options = {}) {
    const {
      type = NotificationType.ERROR,
      severity = NotificationSeverity.MEDIUM,
      title = null,
      duration = 5000,
      persist = false,
      technicalDetails = null
    } = options;

    const logDetails = technicalDetails ?? null;
    const logFn = type === NotificationType.ERROR
      ? logger$v.error
      : (type === NotificationType.WARNING ? logger$v.warn : logger$v.info);
    logFn(`[${type.toUpperCase()}] ${message}`, 'user-notifications', logDetails);

    // Send message to content script/popup
    const notificationData = {
      type: 'user_notification',
      notification: {
        message,
        type,
        severity,
        title: title || getDefaultTitle(type),
        timestamp: Date.now(),
        duration: persist ? 0 : duration
      }
    };

    // Try to send to active tab
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, notificationData).catch(err => {
            // Tab might not have content script, fallback to runtime message
            chrome.runtime.sendMessage(notificationData).catch(() => {
              // If both fail, at least we logged to console
            });
          });
        }
      });
    } catch (error) {
      // Extension context might not support tabs API
      try {
        chrome.runtime.sendMessage(notificationData).catch(() => { });
      } catch (e) {
        // Last resort - already logged to console via logFn call above
        logger$v.debug('Final fallback for notification sending failed:', 'user-notifications', e);
      }
    }

    // Return notification object for testing
    return notificationData.notification;
  }

  /**
   * Gets default title based on notification type
   */
  function getDefaultTitle(type) {
    const titles = {
      [NotificationType.ERROR]: 'Error',
      [NotificationType.WARNING]: 'Warning',
      [NotificationType.INFO]: 'Information',
      [NotificationType.SUCCESS]: 'Success'
    };
    return titles[type] || 'Notification';
  }

  /**
   * Shows an error notification with user-friendly message
   * @param {string} userMessage - User-friendly error message
   * @param {Error|Object} error - Error object or technical details
   * @param {Object} options - Additional options
   */
  function showError(userMessage, error = null, options = {}) {
    const severity = options.severity || NotificationSeverity.HIGH;

    const technicalDetails = error ? {
      message: error.message || error,
      stack: error.stack,
      name: error.name,
      ...(error.status && { status: error.status }),
      ...(error.endpoint && { endpoint: error.endpoint })
    } : null;

    return showNotification(userMessage, {
      type: NotificationType.ERROR,
      severity,
      persist: severity === NotificationSeverity.CRITICAL,
      technicalDetails,
      ...options
    });
  }

  /**
   * Shows a warning notification
   */
  function showWarning(message, options = {}) {
    return showNotification(message, {
      type: NotificationType.WARNING,
      severity: NotificationSeverity.MEDIUM,
      ...options
    });
  }

  /**
   * Shows an info notification
   */
  function showInfo(message, options = {}) {
    return showNotification(message, {
      type: NotificationType.INFO,
      severity: NotificationSeverity.LOW,
      ...options
    });
  }

  /**
   * Error message templates for common scenarios
   */
  const ErrorMessages = {
    // API Errors
    API_UNAVAILABLE: 'Unable to connect to the service. Please check your internet connection and try again.',
    API_TIMEOUT: 'The request took too long to complete. Please try again.',
    API_RATE_LIMIT: 'Too many requests. Please wait a moment and try again.',
    API_AUTH_FAILED: 'Authentication failed. Please check your credentials in settings.',
    API_SERVER_ERROR: 'The service is temporarily unavailable. Please try again later.',

    // AI Service Errors
    AI_GENERATION_FAILED: 'Failed to generate AI response. Please try again.',
    JIRA_SEARCH_FAILED: 'Failed to search Jira tickets. Please try again.',
    CONFLUENCE_SEARCH_FAILED: 'Failed to search Confluence pages. Please try again.',

    LOCAL_DB_SEARCH_FAILED: 'Failed to search local database.',

    // Generic Errors
    UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.',
    OPERATION_CANCELLED: 'Operation was cancelled.'};

  /**
   * Creates a user-friendly error message from an error object
   * @param {Error} error - Error object
   * @param {string} context - Context of the error (e.g., 'AI Service', 'Jira Search')
   * @returns {string} User-friendly message
   */
  function getUserFriendlyErrorMessage(error, context = '') {
    // Check for abort/cancellation
    if (error.name === 'AbortError') {
      return ErrorMessages.OPERATION_CANCELLED;
    }

    // Check for timeout
    if (error.message?.includes('timeout') || error.message?.includes('timed out')) {
      return ErrorMessages.API_TIMEOUT;
    }

    // Check for network errors
    if (error.message?.includes('fetch') || error.message?.includes('network')) {
      return ErrorMessages.API_UNAVAILABLE;
    }

    // Check HTTP status codes
    if (error.status) {
      switch (error.status) {
        case 401:
        case 403:
          return ErrorMessages.API_AUTH_FAILED;
        case 429:
          return ErrorMessages.API_RATE_LIMIT;
        case 500:
        case 502:
        case 503:
        case 504:
          return ErrorMessages.API_SERVER_ERROR;
      }
    }

    // Context-specific messages
    const contextLower = context.toLowerCase();
    if (contextLower.includes('jira')) {
      return ErrorMessages.JIRA_SEARCH_FAILED;
    }
    if (contextLower.includes('confluence')) {
      return ErrorMessages.CONFLUENCE_SEARCH_FAILED;
    }
    if (contextLower.includes('ai')) {
      return ErrorMessages.AI_GENERATION_FAILED;
    }
    if (contextLower.includes('local') || contextLower.includes('vector')) {
      return ErrorMessages.LOCAL_DB_SEARCH_FAILED;
    }

    // Generic fallback
    return context
      ? `${context}: ${ErrorMessages.UNKNOWN_ERROR}`
      : ErrorMessages.UNKNOWN_ERROR;
  }

  /**
   * Telemetry and Metrics Utility
   * Provides performance monitoring and error tracking for production debugging
   */


  const logger$u = createLogger('Telemetry');

  /**
   * Event types for categorization
   */
  const TelemetryEventType = {
    ERROR: 'error'};

  /**
   * Telemetry configuration
   */
  const config = {
    samplingRate: 1.0};

  /**
   * Records a telemetry event
   * @param {string} eventType - Type of event (from TelemetryEventType)
   * @param {string} eventName - Name of the event
   * @param {Object} data - Event data
   * @param {Object} metadata - Additional metadata
   */
  function recordEvent(eventType, eventName, data = {}, metadata = {}) {
    // Check if telemetry is enabled and sampling
    if (Math.random() > config.samplingRate) {
      return;
    }

    const event = {
      id: crypto.randomUUID(),
      data: sanitizeData(data),
      metadata: {
        ...metadata}
    };

    // Console logging if enabled
    {
      logger$u.info(`[Telemetry] ${eventType}:${eventName}`, 'telemetry', data);
    }

    return event.id;
  }

  /**
   * Sanitizes data to remove sensitive information
   * @param {Object} data - Data to sanitize
   * @returns {Object} Sanitized data
   */
  function sanitizeData(data) {
    if (!data || typeof data !== 'object') {
      return data;
    }

    const sanitized = {};
    const sensitiveKeys = ['token', 'password', 'apikey', 'secret', 'authorization', 'auth'];

    for (const [key, value] of Object.entries(data)) {
      const lowerKey = key.toLowerCase();

      // Check if key contains sensitive terms
      if (sensitiveKeys.some(term => lowerKey.includes(term))) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = sanitizeData(value);
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }

  /**
   * Records an error event
   * @param {Error|string} error - Error object or message
   * @param {string} context - Context where error occurred
   * @param {Object} additionalData - Additional error data
   */
  function recordError(error, context, additionalData = {}) {
    const errorData = {
      message: error.message || String(error),
      context,
      stack: error.stack,
      name: error.name,
      ...additionalData
    };

    recordEvent(TelemetryEventType.ERROR, context, errorData);
  }

  /**
   * Standardized Error Handling Utility
   * Provides consistent error handling across the extension
   *
   * @module error-handler
   */


  const logger$t = createLogger('ErrorHandler');

  /**
   * Error handling strategies
   * @enum {string}
   * @readonly
   */
  const ErrorStrategy = {
    /** Log and rethrow the error (fails fast, propagates to caller) */
    THROW: 'throw',
    /** Log and return null (graceful failure, no user notification) */
    RETURN_NULL: 'return_null',
    /** Log and return a fallback value (uses default behavior) */
    RETURN_FALLBACK: 'return_fallback',
    /** Log, notify user, and rethrow (visible failure, still propagates) */
    NOTIFY_AND_THROW: 'notify_and_throw',
    /** Log, notify user, and return null (visible failure, graceful handling) */
    NOTIFY_AND_RETURN_NULL: 'notify_and_return_null',
    /** Log, notify user, and return fallback (visible failure with fallback) */
    NOTIFY_AND_RETURN_FALLBACK: 'notify_and_return_fallback',
    /** Silent - no logging or notification (for expected/handled errors) */
    SILENT: 'silent'
  };

  /**
   * Standard error handler that provides consistent error handling across the extension.
   * Handles logging, telemetry, user notifications, and graceful failure modes
   * based on the selected strategy. Special handling for AbortError (cancellations).
   *
   * @param {Error} error - The error object to handle
   * @param {Object} [options={}] - Error handling configuration
   * @param {string} [options.strategy=ErrorStrategy.THROW] - Error handling strategy from ErrorStrategy enum
   * @param {string} [options.context='Unknown'] - Context where error occurred (e.g., 'JIRA Search', 'AI Service')
   * @param {string} [options.operation='unknown'] - Specific operation name (e.g., 'fetchTickets', 'makeApiRequest')
   * @param {*} [options.fallback=null] - Fallback value to return when using FALLBACK strategies
   * @param {string} [options.userMessage] - Custom user-friendly message (overrides default)
   * @param {boolean} [options.logToConsole=true] - Whether to log error details to console
   * @param {Object} [options.metadata={}] - Additional metadata to include in telemetry
   * @returns {*} Return value depends on strategy: throws, returns null, or returns fallback value
   * @throws {Error} Throws error if strategy is THROW or NOTIFY_AND_THROW
   * @example
   * try {
   *   await fetchData();
   * } catch (error) {
   *   handleError(error, {
   *     strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
   *     context: 'Data Fetch',
   *     operation: 'fetchData',
   *     metadata: { url: 'https://...' }
   *   });
   * }
   */
  function handleError(error, options = {}) {
    const {
      strategy = ErrorStrategy.THROW,
      context = 'Unknown',
      operation = 'unknown',
      fallback = null,
      userMessage = null,
      logToConsole = true,
      metadata = {}
    } = options;

    // Special handling for AbortError - these are intentional cancellations
    if (error.name === 'AbortError' || error.message?.includes('aborted')) {
      if (logToConsole) {
        logger$t.info(`[${context}] Operation was cancelled: ${operation}`, 'error-handler', undefined);
      }

      // For abort errors, always return null/fallback without notification
      if (strategy.includes('FALLBACK')) {
        return fallback;
      }
      return null;
    }

    // Log technical details to console for debugging
    if (logToConsole) {
      logger$t.error(`[${context}] Error in ${operation}:`, 'error-handler', {
        message: error.message,
        stack: error.stack,
        status: error.status,
        ...metadata
      });
    }

    // Record error in telemetry
    try {
      recordError(error, {
        context,
        operation,
        ...metadata
      });
    } catch (telemetryError) {
      // Don't let telemetry failures break error handling
      logger$t.warn('Failed to record error in telemetry:', 'error-handler', telemetryError);
    }

    // Show user notification if strategy includes NOTIFY
    if (strategy.includes('NOTIFY')) {
      try {
        const message = userMessage || getUserFriendlyErrorMessage(error, context);
        showError(message, error);
      } catch (notificationError) {
        // Don't let notification failures break error handling
        logger$t.warn('Failed to show error notification:', 'error-handler', notificationError);
      }
    }

    // Return or throw based on strategy
    switch (strategy) {
      case ErrorStrategy.THROW:
      case ErrorStrategy.NOTIFY_AND_THROW:
        throw error;

      case ErrorStrategy.RETURN_NULL:
      case ErrorStrategy.NOTIFY_AND_RETURN_NULL:
        return null;

      case ErrorStrategy.RETURN_FALLBACK:
      case ErrorStrategy.NOTIFY_AND_RETURN_FALLBACK:
        return fallback;

      case ErrorStrategy.SILENT:
        return fallback;

      default:
        throw error;
    }
  }

  /**
   * result.js
   *
   * Standardized Result pattern for operation outcomes.
   * Replaces the inconsistent mix of nulls, throws, and {success:false} objects.
   */

  class Result {
      constructor(ok, value, error) {
          this.ok = ok;
          this.value = value;
          this.error = error;
      }

      /**
       * Create a successful result
       * @param {any} value - The success return value
       * @returns {Result}
       */
      static success(value) {
          return new Result(true, value, null);
      }

      /**
       * Create a failure result
       * @param {Error|string} error - The error object or message
       * @returns {Result}
       */
      static failure(error) {
          const errObj = error instanceof Error ? error : new Error(String(error));
          return new Result(false, null, errObj);
      }

      /**
       * Unwrap the value or throw the error
       * @returns {any} The value if success
       * @throws {Error} The error if failure
       */
      unwrap() {
          if (this.ok) {
              return this.value;
          }
          throw this.error;
      }
  }

  /**
   * Crypto Utilities Module
   * Provides encryption/decryption for sensitive data at rest using Web Crypto API.
   *
   * Security model:
   * - Encryption key is generated once per extension install
   * - Key is stored in chrome.storage.session (memory-only, cleared on browser restart)
   * - Data encrypted with AES-GCM (authenticated encryption)
   * - Protects against: storage export, disk access, sync exposure
   * - Does NOT protect against: runtime inspection, DevTools access
   */


  const logger$s = createLogger('CryptoUtils');

  const ALGORITHM = 'AES-GCM';
  const KEY_LENGTH = 256;
  const IV_LENGTH = 12; // 96 bits for GCM
  const KEY_STORAGE_KEY = '_pandaid_session_key';
  const ENCRYPTED_PREFIX = 'enc:v1:'; // Versioned prefix to identify encrypted data

  // In-memory cache of the CryptoKey (avoids repeated storage lookups)
  let cachedKey = null;

  /**
   * Convert base64 string to Uint8Array
   * @param {string} base64
   * @returns {Uint8Array}
   */
  function base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    const len = binary.length;
    const buffer = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      buffer[i] = binary.charCodeAt(i);
    }
    return buffer;
  }

  /**
   * Generate a new encryption key
   * @returns {Promise<CryptoKey>}
   */
  async function generateKey() {
    return crypto.subtle.generateKey(
      { name: ALGORITHM, length: KEY_LENGTH },
      true, // extractable - needed to store in session
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Export CryptoKey to storable format (JWK)
   * @param {CryptoKey} key
   * @returns {Promise<JsonWebKey>}
   */
  async function exportKey(key) {
    return crypto.subtle.exportKey('jwk', key);
  }

  /**
   * Import CryptoKey from stored format (JWK)
   * @param {JsonWebKey} jwk
   * @returns {Promise<CryptoKey>}
   */
  async function importKey(jwk) {
    return crypto.subtle.importKey(
      'jwk',
      jwk,
      { name: ALGORITHM, length: KEY_LENGTH },
      false, // not extractable after import
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Get or create the session encryption key.
   * Key is stored in chrome.storage.session (memory-only).
   * @returns {Promise<CryptoKey>}
   */
  async function getOrCreateKey() {
    // Return cached key if available
    if (cachedKey) {
      return cachedKey;
    }

    // Require session storage; don't degrade to persistent storage
    if (!chrome.storage.session) {
      const error = new Error(
        'Session storage unavailable. ' +
        'Token encryption requires ephemeral key storage. ' +
        'Please update your browser or restart the extension.'
      );
      error.code = 'SESSION_STORAGE_UNAVAILABLE';
      throw error;
    }

    try {
      const result = await chrome.storage.session.get(KEY_STORAGE_KEY);

      if (result[KEY_STORAGE_KEY]) {
        // Import existing key
        cachedKey = await importKey(result[KEY_STORAGE_KEY]);
        return cachedKey;
      }
    } catch (e) {
      logger$s.error('[Crypto] Error reading session key:', 'crypto-utils', e);
      throw e;
    }

    // Generate new key
    const newKey = await generateKey();
    const exportedKey = await exportKey(newKey);

    // Store in session storage
    try {
      await chrome.storage.session.set({ [KEY_STORAGE_KEY]: exportedKey });
      logger$s.info('[Crypto] New session key generated and stored', 'crypto-utils', undefined);
    } catch (e) {
      logger$s.error('[Crypto] Failed to store session key:', 'crypto-utils', e);
      throw e;
    }

    cachedKey = newKey;
    return cachedKey;
  }

  /**
   * Decrypt an encrypted string value
   * @param {string} encrypted - The encrypted value (with prefix)
   * @returns {Promise<Result<string>>} - Result containing decrypted plaintext or error
   */
  async function decrypt(encrypted) {
    if (!encrypted || typeof encrypted !== 'string') {
      return Result.success(encrypted);
    }

    // Not encrypted - return as-is (handles migration from unencrypted storage)
    if (!encrypted.startsWith(ENCRYPTED_PREFIX)) {
      return Result.success(encrypted);
    }

    try {
      const key = await getOrCreateKey();
      const base64 = encrypted.slice(ENCRYPTED_PREFIX.length);
      const combined = base64ToArrayBuffer(base64);

      // Extract IV and ciphertext
      const iv = combined.slice(0, IV_LENGTH);
      const ciphertext = combined.slice(IV_LENGTH);

      const decrypted = await crypto.subtle.decrypt(
        { name: ALGORITHM, iv },
        key,
        ciphertext
      );

      const decoder = new TextDecoder();
      return Result.success(decoder.decode(decrypted));
    } catch (error) {
      // If the underlying Web Crypto API reports an OperationError or similar
      // it most likely means the session key is missing/rotated and the
      // ciphertext cannot be authenticated with the current key. Surface a
      // clearer, actionable error to callers so UI can prompt the user to
      // re-enter their token.
      const isOpError = error && (error.name === 'OperationError' || error.name === 'DataError' || (error.message && error.message.includes('OperationError')));

      if (isOpError) {
        logger$s.warn('[Crypto] Decryption failed: session key missing or mismatched', 'crypto-utils', error);
        const decryptError = new Error('Crypto decryption failed: session key missing or mismatched. Please re-enter your API token in settings.');
        decryptError.code = 'SESSION_KEY_MISMATCH';
        decryptError.cause = error;
        return Result.failure(decryptError);
      }

      logger$s.error('[Crypto] Decryption failed:', 'crypto-utils', error);
      // Generic decryption failure - preserve existing behavior
      const decryptError = new Error('Crypto decryption failed: ' + (error && error.message ? error.message : 'unknown'));
      decryptError.code = 'DECRYPT_FAILED';
      decryptError.cause = error;
      return Result.failure(decryptError);
    }
  }

  /**
   * Cache Manager Module
   * Handles caching of API responses with TTL (Time To Live)
   *
   * @module cache-manager
   */


  const logger$r = createLogger('CacheManager');

  const CACHE_TTL = CACHE_TTL_MS;
  const CACHE_STORAGE_KEY = 'extensionResponseCache';
  const MAX_CACHE_SIZE = CACHE_MAX_ENTRIES; // Maximum number of entries (LRU eviction)
  const MAX_ENTRY_BYTES = CACHE_MAX_ENTRY_BYTES; // 512KB limit per individual cache entry
  const QUOTA_SAFETY_MARGIN = CACHE_QUOTA_SAFETY_MARGIN; // Keep below quota to reduce write failures

  // In-memory cache (Map persists for service worker lifetime)
  const responseCache = new Map();
  const DEFAULT_PERSIST_DEBOUNCE_MS = CACHE_PERSIST_DEBOUNCE_MS;
  const MAX_PERSIST_WAIT_MS = 10000; // Force persist after 10s even if updates continue
  let persistTimerId = null;
  let maxWaitTimerId = null;
  let pendingPersistChain = Promise.resolve();

  // ============================================================================
  // HELPER FUNCTIONS
  // ============================================================================

  /**
   * Validate cache entry structure
   * @param {Object} entry - Cache entry to validate
   * @returns {boolean} Whether entry is valid
   */
  function isValidCacheEntry(entry) {
    return entry &&
      typeof entry === 'object' &&
      'data' in entry &&
      typeof entry.timestamp === 'number' &&
      isFinite(entry.timestamp);
  }

  /**
   * Estimate byte size of a value for quota management
   * @param {any} value - Value to estimate
   * @returns {number} Estimated byte size
   */
  function estimateBytes(value) {
    try {
      const json = JSON.stringify(value);
      // UTF-16 uses 2 bytes per character in JS strings, but JSON storage typically uses UTF-8
      return new Blob([json]).size;
    } catch (err) {
      // If JSON stringify fails, return a conservative estimate
      logger$r.debug('JSON.stringify failed in estimateBytes', 'cache-manager', err);
      return 0;
    }
  }

  /**
   * Get bytes in use for chrome.storage.local
   * @param {string|null} key - Specific key or null for total
   * @returns {Promise<number>} Bytes in use
   */
  async function getBytesInUse(key) {
    if (chrome?.storage?.local?.getBytesInUse) {
      return chrome.storage.local.getBytesInUse(key);
    }
    // Fallback: estimate from stored data
    const data = await chrome.storage.local.get(null);
    return estimateBytes(data);
  }

  /**
   * Trim cache to fit within a byte budget
   * @param {number} maxBytes - Maximum bytes to allow
   */
  function trimCacheToFitBytes(maxBytes) {
    let currentSize = 0;
    const entriesToDelete = [];

    // Calculate current cache size
    for (const [key, entry] of responseCache.entries()) {
      const entrySize = estimateBytes(entry);
      currentSize += entrySize;
    }

    if (currentSize <= maxBytes) return;

    // Evict oldest entries (Map maintains insertion order, oldest first)
    for (const [key, entry] of responseCache.entries()) {
      if (currentSize <= maxBytes) break;
      const entrySize = estimateBytes(entry);
      entriesToDelete.push(key);
      currentSize -= entrySize;
    }

    for (const key of entriesToDelete) {
      responseCache.delete(key);
    }

    if (entriesToDelete.length > 0) {
      logger$r.info(`Trimmed ${entriesToDelete.length} cache entries to fit quota`, 'cache-manager');
    }
  }

  /**
   * Persist cache to chrome.storage.local
   * @returns {Promise<void>}
   */
  async function persistCache() {
    try {
      // Convert Map to array of [key, entry] pairs for storage
      const cacheArray = Array.from(responseCache.entries());

      await chrome.storage.local.set({
        [CACHE_STORAGE_KEY]: cacheArray
      });

      logger$r.debug(`Persisted ${cacheArray.length} cache entries`, 'cache-manager');
    } catch (error) {
      logger$r.error('Failed to persist cache:', 'cache-manager', error);

      // If quota exceeded, try trimming and retrying once
      if (error?.message?.includes('QUOTA') || error?.name === 'QuotaExceededError') {
        logger$r.warn('Quota exceeded, trimming cache and retrying', 'cache-manager');
        trimCacheToMax();
        trimCacheToFitBytes((await getBytesInUse(null)) * QUOTA_SAFETY_MARGIN);

        const trimmedArray = Array.from(responseCache.entries());
        await chrome.storage.local.set({
          [CACHE_STORAGE_KEY]: trimmedArray
        });
      } else {
        throw error;
      }
    }
  }

  /**
   * Restore cache from chrome.storage.local
   * @returns {Promise<void>}
   */
  async function restoreCache() {
    try {
      const result = await chrome.storage.local.get(CACHE_STORAGE_KEY);
      const storedCache = result[CACHE_STORAGE_KEY];

      if (!storedCache || !Array.isArray(storedCache)) {
        logger$r.debug('No cached data found in storage', 'cache-manager');
        return;
      }

      const now = Date.now();
      let restored = 0;
      let expired = 0;

      for (const [key, entry] of storedCache) {
        if (!isValidCacheEntry(entry)) {
          continue;
        }

        // Check if entry has expired
        if ((now - entry.timestamp) >= CACHE_TTL) {
          expired++;
          continue;
        }

        responseCache.set(key, entry);
        restored++;
      }

      logger$r.info(`Restored ${restored} cache entries (${expired} expired, skipped)`, 'cache-manager');
    } catch (error) {
      logger$r.error('Failed to restore cache:', 'cache-manager', error);
      // Non-fatal: start with empty cache
    }
  }

  function enqueueScheduledPersist() {
    const runPersist = () => persistCache();

    pendingPersistChain = pendingPersistChain.then(runPersist, (error) => {
      logger$r.error('Previous persist operation failed:', 'cache-manager', error);
      return runPersist();
    });

    pendingPersistChain.catch(error => {
      logger$r.error('Scheduled cache persist failed:', 'cache-manager', error);
    });

    return pendingPersistChain;
  }

  /**
   * Debounce cache persistence to prevent overlapping writes.
   * includes a maxWait to prevent indefinite deferral during high activity.
   * @param {number} [debounceMs]
   * @returns {Promise<any>}
   */
  function scheduleCachePersist(debounceMs = DEFAULT_PERSIST_DEBOUNCE_MS) {
    // If no max wait timer is running, start one to guarantee execution
    if (!maxWaitTimerId) {
      maxWaitTimerId = setTimeout(() => {
        logger$r.debug('Cache persist max wait reached, flushing', 'cache-manager');
        flushScheduledCachePersist();
      }, MAX_PERSIST_WAIT_MS);
    }

    if (persistTimerId) {
      clearTimeout(persistTimerId);
    }
    persistTimerId = setTimeout(() => {
      flushScheduledCachePersist();
    }, debounceMs);
    return pendingPersistChain;
  }

  /**
   * Force any scheduled persist to run immediately.
   * @returns {Promise<any>}
   */
  function flushScheduledCachePersist() {
    if (persistTimerId) {
      clearTimeout(persistTimerId);
      persistTimerId = null;
    }
    if (maxWaitTimerId) {
      clearTimeout(maxWaitTimerId);
      maxWaitTimerId = null;
    }
    return enqueueScheduledPersist();
  }

  /**
   * Set a cache entry with proactive quota checking
   * @param {string} key - Cache key
   * @param {any} data - Data to cache
   * @returns {Promise<void>}
   */
  async function setCache(key, data) {
    if (typeof key !== 'string' || !key.trim()) return;

    const entry = {
      data,
      timestamp: Date.now()
    };

    const size = estimateBytes(entry);

    // 1. Hard limit on individual entry size
    if (size > MAX_ENTRY_BYTES) {
      logger$r.warn('Entry too large for cache', 'cache-manager', { key, size });
      return;
    }

    // 2. LRU Eviction by count
    responseCache.set(key, entry);
    trimCacheToMax();

    // 3. Proactive quota check
    try {
      const totalBytesInUse = await getBytesInUse(null);
      const currentQuota = Number.isFinite(chrome?.storage?.local?.QUOTA_BYTES)
        ? chrome.storage.local.QUOTA_BYTES
        : (5 * 1024 * 1024);

      if (totalBytesInUse > currentQuota * QUOTA_SAFETY_MARGIN) {
        logger$r.info('Cache approaching quota; performing emergency trim', 'cache-manager', {
          used: totalBytesInUse,
          quota: currentQuota
        });
        trimCacheToFitBytes(currentQuota * QUOTA_SAFETY_MARGIN);
      }
    } catch (e) {
      // Quota check errors are non-critical; allow cache operations to continue
      logger$r.debug('Quota check failed (non-critical)', 'checkQuotaAndTrim', e);
    }
  }

  /**
   * Trim cache down to MAX_CACHE_SIZE by evicting oldest entries (LRU-friendly).
   * @returns {boolean} whether eviction occurred
   */
  function trimCacheToMax() {
    let evicted = false;
    while (responseCache.size > MAX_CACHE_SIZE) {
      const firstKey = responseCache.keys().next().value;
      if (firstKey === undefined) break;
      responseCache.delete(firstKey);
      evicted = true;
    }
    return evicted;
  }

  /**
   * Email Helpers Module
   * Utilities for cleaning, filtering, and generating email content
   *
   * @module email-helpers
   */

  /**
   * Clean email content by removing signatures, salutations, and boilerplate.
   * Strips institutional headers, contact info, and legal disclaimers to extract
   * the main message body. Uses pattern matching to identify unwanted content.
   *
   * @param {string} emailText - Raw email text (may contain signatures and boilerplate)
   * @returns {string} Cleaned email content (main message body only)
   * @example
   * cleanEmailContent('Hi,\nPlease help.\nBest regards\nJohn')
   * // Returns: 'Hi,\nPlease help.'
   */
  function cleanEmailContent(emailText) {
    if (!emailText || typeof emailText !== 'string') {
      return '';
    }

    // Common salutation patterns that indicate end of relevant content
    const salutationPatterns = [
      /\b(best regards?|regards|sincerely|thank you|thanks|cheers|best)\b/i,
      /\b(kind regards|warm regards|many thanks|with appreciation)\b/i,
      /\b(looking forward|hope this helps|let me know)\b/i,
      /\b(please let me know|feel free to|don't hesitate)\b/i,
      /\b(have a (?:great|good|wonderful) day|have a (?:great|good|wonderful) (?:week|weekend))\b/i
    ];

    // Common signature indicators
    const signaturePatterns = [
      /^[-_=]+$/m, // Lines of dashes, underscores, or equals
      /\b(?:this (?:email|message) is (?:confidential|privileged))/i,
      /\b(?:confidentiality notice|legal disclaimer|privacy notice)\b/i,
      /\b(?:sent from my (?:iphone|ipad|android|mobile|phone))/i,
      /\b(?:virus|malware) free/i,
      /\b(?:scanned by|protected by|powered by)\b/i,
      /\b(?:unsubscribe|opt[- ]?out)\b/i,
      /\b(?:copyright|©|\(c\)) \d{4}/i,
      /\b(?:phone|tel|mobile|fax|email|e-mail):\s*[\+\d\(\)\-\.\s]+/i,
      /\b[\w\.-]+@[\w\.-]+\.\w+\b.*$/m, // Email addresses at end of lines
      /\bhttps?:\/\/[\w\.-]+/i, // URLs often in signatures
      /\b(?:www\.[\w\.-]+\.\w+)/i // Website addresses
    ];

    // Institution-specific patterns
    const institutionPatterns = [
      /\b(?:university|college|school|district|department) of \w+/i,
      /\b\w+ (?:university|college|school|district)\b/i,
      /\b(?:office of|department of) \w+/i,
      /\b(?:instructional|educational|academic|student|faculty) \w+/i,
      /\b(?:title ix|ferpa|hipaa|ada|section 508) \w*/i,
      /\b(?:equal opportunity|non[- ]?discrimination|accessibility)\b/i
    ];

    // Split into lines for analysis
    const lines = emailText.split('\n').map(line => line.trim());
    const cleanLines = [];
    let foundSalutation = false;
    let foundSignature = false;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Skip empty lines
      if (line.length === 0) {
        // Keep empty lines before salutation/signature
        if (!foundSalutation && !foundSignature) {
          cleanLines.push(line);
        }
        continue;
      }

      // Check for salutations
      if (!foundSalutation) {
        for (const pattern of salutationPatterns) {
          if (pattern.test(line)) {
            foundSalutation = true;
            break;
          }
        }
      }

      // Check for signature patterns
      if (!foundSignature) {
        for (const pattern of [...signaturePatterns, ...institutionPatterns]) {
          if (pattern.test(line)) {
            foundSignature = true;
            break;
          }
        }
      }

      // If we found a salutation or signature indicator, stop including content
      if (foundSalutation || foundSignature) {
        break;
      }

      // Check if line looks like contact info or institutional boilerplate
      const isBoilerplate =
        /^\s*[-_=]{3,}\s*$/.test(line) || // Separator lines
        /^[\s\*\-\+]{0,3}(?:phone|tel|mobile|fax|email|office|address)[\s:]/i.test(line) || // Contact info
        line.length > 100 && (/\b(?:confidential|disclaimer|copyright|privacy|legal)\b/i.test(line)) || // Long legal text
        /^\s*\w+\s+\w+\s*$/.test(line) && i > lines.length - 5; // Name-like pattern near end

      if (!isBoilerplate) {
        cleanLines.push(line);
      }
    }

    // Join back together and clean up
    let cleanedEmail = cleanLines.join('\n').trim();

    // Basic HTML sanitization: Strip tags for defense-in-depth if rendering in HTML context
    // This is a simple regex-based strip which is sufficient for plain text extraction
    cleanedEmail = cleanedEmail.replace(/<[^>]*>?/gm, '');

    // Remove common email artifacts
    cleanedEmail = cleanedEmail
      .replace(/^>+\s*/gm, '') // Remove quote markers
      .replace(/^From:\s*.*/gm, '') // Remove "From:" headers
      .replace(/^Sent:\s*.*/gm, '') // Remove "Sent:" headers
      .replace(/^To:\s*.*/gm, '') // Remove "To:" headers
      .replace(/^Subject:\s*.*/gm, '') // Remove "Subject:" headers
      .replace(/^\s*[-_=]{3,}\s*$/gm, '') // Remove separator lines
      .replace(/\n{3,}/g, '\n\n') // Collapse multiple line breaks
      .trim();

    return cleanedEmail;
  }

  /**
   * Filter imported email text - stops at original message divider.
   * Extracts only the new reply/forward content by detecting standard dividers
   * like "---- Original Message ----" or "On ... wrote:".
   *
   * @param {string} emailText - Email text to filter (may contain original message)
   * @returns {string} Filtered email text (only the new/reply content, trimmed)
   * @example
   * filterImportedEmailText('Your reply here\n---- Original Message ----\nOld stuff')
   * // Returns: 'Your reply here'
   */
  function filterImportedEmailText(emailText) {
    if (!emailText || typeof emailText !== 'string') {
      return '';
    }

    // Common original message divider patterns
    const originalMessagePatterns = [
      /^-+\s*Original Message\s*-+/im,
      /^=+\s*Original Message\s*=+/im,
      /^_{3,}\s*Original Message\s*_{3,}/im,
      /^-{10,}/im, // Just a line of dashes (10 or more)
      /^={10,}/im, // Just a line of equals (10 or more)
      /^_{10,}/im, // Just a line of underscores (10 or more)
      /^From:\s*.*\n.*Sent:/im, // Outlook-style forwarded message header
      /^On\s+.*wrote:/im, // Gmail-style quoted text
      /^\s*>.*wrote:/im // Another quoted text pattern
    ];

    let earliestMatch = null;
    let earliestIndex = emailText.length;

    // Find the earliest occurrence of any pattern
    for (const pattern of originalMessagePatterns) {
      const match = emailText.match(pattern);
      if (match && match.index < earliestIndex) {
        earliestIndex = match.index;
        earliestMatch = match;
      }
    }

    if (earliestMatch) {
      // Found a divider, return everything before it
      return emailText.substring(0, earliestIndex).trim();
    }

    // No divider found, return original text
    return emailText.trim();
  }

  /**
   * Generate email signature based on case data.
   * Creates a formatted signature line that includes case owner and product family
   * information. Falls back to generic salutation if data is not available.
   *
   * @param {Object} [caseData={}] - Case information for signature
   * @param {string} [caseData.caseOwner] - Name of the case owner (e.g., "John Smith")
   * @param {string} [caseData.productFamily] - Product family name (e.g., "Canvas LMS")
   * @returns {string} Formatted email signature with newlines ready for appending to email
   * @example
   * generateEmailSignature({ caseOwner: 'Jane Doe', productFamily: 'Canvas' })
   * // Returns: '\n\nKind regards,\nJane Doe\nCanvas Support'
   */
  function generateEmailSignature(caseData = {}) {
    const caseOwner = caseData.caseOwner;
    const productFamily = caseData.productFamily;

    // Check if case owner contains "queue" (case-insensitive)
    // If so, don't include it in the signature as the ticket hasn't been assigned yet
    const isQueueOwner = caseOwner && caseOwner.toLowerCase().includes('queue');

    // If no data can be extracted, just show "Kind regards"
    if ((!caseOwner || isQueueOwner) && !productFamily) {
      return `\n\nKind regards`;
    }

    // Exclude queue owners from signature - only show product support line
    if (isQueueOwner) {
      const product = productFamily || '{Product Family}';
      return `\n\nKind regards,\n${product} Support`;
    }

    const owner = caseOwner || '{Case Owner}';
    const product = productFamily || '{Product Family}';

    return `\n\nKind regards,\n${owner}\n${product} Support`;
  }

  /**
   * Context Menu Module
   * Handles right-click context menu for importing email text
   */


  const logger$q = createLogger('ContextMenu');

  // ============================================================================
  // DEBUG FLAGS
  // ============================================================================

  // Debug flags controlled by chrome.storage.local.pandaidDebug
  // Example to set from DevTools: chrome.storage.local.set({ pandaidDebug: { enabled: true, forceShowContextMenu: true, forceAllowClick: true, verboseOnShown: true } })
  // 'enabled' must be explicitly true for any force* flag to take effect. This prevents accidental global exposure.
  let pandaidDebug = { enabled: false, forceShowContextMenu: false, forceAllowClick: false, verboseOnShown: false };

  (async function loadPandaidDebug() {
    try {
      const data = await chrome.storage.local.get('pandaidDebug');
      if (data && data.pandaidDebug) {
        // Only copy known keys to avoid unexpected properties
        const stored = data.pandaidDebug || {};
        pandaidDebug.enabled = !!stored.enabled;
        pandaidDebug.forceShowContextMenu = !!stored.forceShowContextMenu;
        pandaidDebug.forceAllowClick = !!stored.forceAllowClick;
        pandaidDebug.verboseOnShown = !!stored.verboseOnShown;
        if (pandaidDebug.verboseOnShown) logger$q.info('PandAid: pandaidDebug loaded', 'context-menu', pandaidDebug);
        // If stored object is missing the enabled key, persist the normalized object so it's visible/editable
        if (typeof stored.enabled !== 'boolean') {
          try { await chrome.storage.local.set({ pandaidDebug }); } catch (e) { logger$q.debug('Error persisting pandaidDebug settings', 'context-menu', e); }
        }
      } else {
        // No stored flags found - persist defaults so the key is visible to the user in DevTools
        try {
          await chrome.storage.local.set({ pandaidDebug });
          if (pandaidDebug.verboseOnShown) logger$q.info('PandAid: pandaidDebug default created', 'context-menu', pandaidDebug);
        } catch (setErr) {
          logger$q.warn('PandAid: failed to persist default pandaidDebug', 'context-menu', setErr?.message || setErr);
        }
      }
    } catch (e) {
      logger$q.warn('PandAid: failed to load pandaidDebug flags', 'context-menu', e?.message || e);
    }
  })();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.pandaidDebug) {
      const nv = changes.pandaidDebug.newValue || {};
      // Normalize incoming values and avoid enabling force flags without explicit enabled:true
      pandaidDebug.enabled = !!nv.enabled;
      pandaidDebug.forceShowContextMenu = !!nv.forceShowContextMenu;
      pandaidDebug.forceAllowClick = !!nv.forceAllowClick;
      pandaidDebug.verboseOnShown = !!nv.verboseOnShown;
      logger$q.info('PandAid: pandaidDebug updated', 'context-menu', pandaidDebug);
    }
  });

  // ============================================================================
  // CONTEXT MENU SETUP
  // ============================================================================

  let contextMenuSetup = false;

  /**
   * Set up the context menu for importing email text
   */
  function setupContextMenu() {
    // Prevent multiple setups
    if (contextMenuSetup) {
      logger$q.info('PandAid: Context menu already set up, skipping', 'context-menu', undefined);
      return;
    }

    // Remove existing items and create a single-click menu entry
    if (!chrome.contextMenus) {
      logger$q.warn('contextMenus API not available in this environment; skipping context menu setup', 'context-menu', undefined);
      return;
    }

    chrome.contextMenus.removeAll(() => {
      if (chrome.runtime.lastError) {
        logger$q.warn('PandAid: removeAll error', 'context-menu', chrome.runtime.lastError);
      }

      const menuId = 'pandaidAddOrImport';
      const menuOptions = {
        id: menuId,
        title: 'Add to PandAid (for Chatter email)',
        contexts: ['all'] // Use 'all' for maximum compatibility
      };

      // Simple approach: just create the item
      chrome.contextMenus.create(menuOptions, () => {
        if (chrome.runtime.lastError) {
          const msg = chrome.runtime.lastError.message || '';
          if (msg.includes('duplicate id')) {
            logger$q.info('PandAid: context menu item already exists, continuing', 'context-menu', undefined);
          } else {
            logger$q.error('PandAid: contextMenus.create error', 'context-menu', chrome.runtime.lastError);
          }
        } else {
          logger$q.info('PandAid: contextMenus.create succeeded', 'context-menu', undefined);
        }
      });

      // Mark context menu as set up
      contextMenuSetup = true;
    });
  }

  // ============================================================================
  // CONTEXT MENU CLICK HANDLER
  // ============================================================================

  /**
   * Initialize context menu click listener
   */
  function initializeContextMenuListener() {
    // Handle context menu clicks
    if (chrome.contextMenus && chrome.contextMenus.onClicked && typeof chrome.contextMenus.onClicked.addListener === 'function') {
      chrome.contextMenus.onClicked.addListener(async (info, tab) => {
        if (info.menuItemId !== 'pandaidAddOrImport') return;

        let selectedText = (info.selectionText || '').trim();

        // Allow the context menu click to proceed everywhere per user request (no Chatter gating)

        // Fallback: get selection from any frame
        if (!selectedText) {
          try {
            const [{ result: selections }] = await chrome.scripting.executeScript({
              target: { tabId: tab.id, allFrames: true },
              function: () => {
                const sel = window.getSelection();
                return sel && sel.rangeCount ? sel.toString() : '';
              }
            });
            const firstNonEmpty = (Array.isArray(selections) ? selections : [selections]).find(x => (x.result || x).trim());
            selectedText = firstNonEmpty ? (firstNonEmpty.result || firstNonEmpty).trim() : '';
          } catch (err) { logger$q.debug('Selection retrieval via executeScript failed', 'context-menu', err); }
        }

        // Ensure content script is present
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
        } catch {
          try {
            await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ['content_script.js'] });
            await new Promise(r => setTimeout(r, 400));
          } catch (injectError) {
            logger$q.error('Failed to inject content script:', 'context-menu', injectError);
            if (chrome.notifications) ;
            return;
          }
        }

        if (selectedText) {
          // Add selected text
          try {
            await chrome.tabs.sendMessage(tab.id, { action: 'addTextAndEnsureSidebar', text: selectedText });
            if (chrome.notifications) {
              // chrome.notifications.create() removed to prevent unwanted Windows notifications
            }
          } catch (e) {
            logger$q.error('Failed to add text:', 'context-menu', e);
          }
          return;
        }

        // No selection: try to import the email body via the content script's robust extractor
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'triggerEmailImport' });
          logger$q.info('Sent triggerEmailImport message to tab', 'context-menu', undefined);
        } catch (error) {
          logger$q.error('Error triggering email import:', 'context-menu', error);
        }
      });
    } else {
      logger$q.warn('contextMenus.onClicked not available; context menu click handling disabled', 'context-menu', undefined);
    }
  }

  /**
   * Prompt Templates Module
   * Centralized storage for all AI prompt templates
   * 
   * @module prompts/prompt-templates
   */


  /**
   * System instructions for troubleshooting guidance
   */
  const GUIDANCE_INSTRUCTIONS = `Follow a structured troubleshooting and investigation approach for Impact customer support tickets. Prioritize configuration checks, visibility and context, data freshness, and permission checks. When possible include commands, checks, or tools such as Canvas plugin checks, Impact dashboard verification, Jarvis lookups, CloudWatch log hints, and database query suggestions. Provide concise, numbered, actionable steps.`;

  /**
   * Build a solution suggestion prompt based on case data and context
   * @param {Object} caseData - Case information
   * @param {string} context - Additional context (optional)
   * @returns {string} Formatted prompt
   */
  function buildSolutionPrompt(caseData = {}, context = "") {
    const guidanceSection = `GUIDANCE:\n---\n${GUIDANCE_INSTRUCTIONS}\n---\n\n`;

    if (context && context.trim().length > 0) {
      return `${guidanceSection}Using the CONTEXT below, produce 3-6 concise, numbered troubleshooting steps for a support agent to follow. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.\n\nCONTEXT:\n---\n${context}\n---\n\nCASE DETAILS:\n- Subject: ${caseData.subject || 'Not specified'}\n- Description: ${caseData.description ? cleanEmailContent(caseData.description) : 'Not specified'}`;
    }

    if (caseData.subject || caseData.description) {
      const cleanedDescription = caseData.description ? cleanEmailContent(caseData.description) : '';
      return `${guidanceSection}Based on the CASE DETAILS below, produce 3-6 concise, numbered troubleshooting steps for a support agent to follow. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.\n\nCASE DETAILS:\n- Subject: ${caseData.subject || 'Not specified'}\n- Description: ${cleanedDescription || 'Not specified'}\n- Product: ${caseData.productFamily || 'Not specified'}\n- Component: ${caseData.productComponent || 'Not specified'}`;
    }

    return `${guidanceSection}No case details are available. Produce 4-6 concise, numbered investigative troubleshooting steps an agent should follow to diagnose common issues. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.`;
  }

  /**
   * Build an improvement prompt for existing solutions
   * @param {string} currentSolution - The solution to improve
   * @param {Object} caseData - Case information for context
   * @returns {string} Formatted prompt
   */
  function buildImprovementPrompt(currentSolution, caseData = {}) {
    const contextPrefix = (caseData.subject || caseData.productFamily)
      ? `CONTEXT: Improving a support solution for Case "${caseData.subject || 'N/A'}" (Product: ${caseData.productFamily || 'N/A'}, Component: ${caseData.productComponent || 'N/A'}).\n\n`
      : '';

    return contextPrefix +
      'Please improve the following solution by making it more clear, comprehensive, and professional. ' +
      'Add specific steps where needed and ensure it follows customer service best practices:\n\n' +
      'Current Solution:\n' + currentSolution + '\n\n' +
      'Please provide an improved version that is:\n' +
      '1. More detailed and actionable\n' +
      '2. Professional in tone and matches the product terminology\n' +
      '3. Clear and easy to follow\n' +
      '4. Includes any relevant troubleshooting steps';
  }

  /**
   * Build a spellcheck/grammar check prompt
   * @param {string} text - Text to check
   * @param {Object} caseData - Case information for terminology context
   * @returns {string} Formatted prompt
   */
  function buildSpellCheckPrompt(text, caseData = {}) {
    const contextPrefix = (caseData.productFamily || caseData.productComponent)
      ? `CONTEXT: Checking text for a support case regarding ${caseData.productFamily || ''} ${caseData.productComponent || ''}.\n\n`
      : '';

    return contextPrefix +
      'Please check the following text for spelling and grammar errors and return the corrected version. ' +
      'Only fix actual errors - do not change the meaning, tone, or style of the text. ' +
      'Be careful not to "correct" industry or product-specific terminology related to the context provided.\n\n' +
      'Text to check:\n' + text + '\n\n' +
      'Please respond with only the corrected text, no additional comments or explanations.';
  }

  /**
   * Prompt Builders Module
   * Dynamic prompt construction utilities
   * 
   * @module prompts/prompt-builders
   */

  /**
   * Default AI parameter settings for different contexts
   */
  const DEFAULT_PARAMETERS = {
    caseSummary: {
      temperature: 0.3,
      topP: 0.8,
      topK: 40
    },
    improvement: {
      temperature: 0.3,
      topP: 0.8,
      topK: 40
    },
    spellcheck: {
      temperature: 0.1,
      topP: 0.95,
      topK: 40
    }
  };

  /**
   * Get AI parameters from settings or use defaults
   * @param {string} context - Context type (caseSummary, improvement, spellcheck)
   * @param {Object} advancedAiSettings - Advanced AI settings from storage
   * @returns {Object} AI parameters (temperature, topP, topK)
   */
  function getAiParameters(context, advancedAiSettings = {}) {
    const contextSettings = advancedAiSettings?.contextSettings?.[context];
    const defaults = DEFAULT_PARAMETERS[context] || DEFAULT_PARAMETERS.caseSummary;
    
    return {
      temperature: contextSettings?.temperature ?? defaults.temperature,
      topP: contextSettings?.topP ?? defaults.topP,
      topK: contextSettings?.topK ?? defaults.topK
    };
  }

  /**
   * Build GraphQL mutation for AI prompts
   * @param {string} operationName - Name of the mutation operation
   * @param {boolean} includeAdvancedParams - Whether to include advanced AI parameters
   * @returns {string} GraphQL mutation string
   */
  function buildPromptMutation(operationName, includeAdvancedParams = true) {
    if (includeAdvancedParams) {
      return `mutation ${operationName}($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) {
  answerPrompt(input: {
    model: $model
    prompt: $prompt
    temperature: $temperature
    topP: $topP
    topK: $topK
  })
}`;
    }
    
    return `mutation ${operationName}($model: String!, $prompt: String!) {
  answerPrompt(input: {
    model: $model
    prompt: $prompt
    temperature: 0.1
  })
}`;
  }

  /**
   * Build variables object for GraphQL mutation
   * @param {string} model - AI model identifier
   * @param {string} prompt - Prompt text
   * @param {Object} parameters - AI parameters (temperature, topP, topK)
   * @param {boolean} includeAdvancedParams - Whether to include advanced parameters
   * @returns {Object} Variables object for GraphQL
   */
  function buildMutationVariables(model, prompt, parameters = {}, includeAdvancedParams = true) {
    const variables = { model, prompt };
    
    if (includeAdvancedParams && parameters) {
      if (parameters.temperature !== undefined) variables.temperature = parameters.temperature;
      if (parameters.topP !== undefined) variables.topP = parameters.topP;
      if (parameters.topK !== undefined) variables.topK = parameters.topK;
    }
    
    return variables;
  }

  /**
   * HTML Sanitization Module
   * Provides sanitization helpers for PandAid extension
   */

  createLogger('Sanitization');

  /**
   * Input Validation Module
   * Provides validation helpers for PandAid extension
   */

  const logger$p = createLogger('Validation');

  /**
   * Validates Atlassian base URL
   * @param {string} input - The Company slug or Atlassian URL
   * @returns {{valid: boolean, error?: string, normalized?: string, slug?: string}} Validation result
   */
  function validateAtlassianUrl(input) {
      if (!input || typeof input !== 'string') {
          return { valid: false, error: 'Company slug or Atlassian URL is required' };
      }

      const trimmed = input.trim();

      if (trimmed.length === 0) {
          return { valid: false, error: 'Company slug or Atlassian URL cannot be empty' };
      }

      // Accept either a plain slug or an already-formed https://<slug>.atlassian.net URL
      const slugPattern = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
      let slugCandidate = trimmed;

      if (trimmed.includes('://')) {
          try {
              const parsed = new URL(trimmed);
              const host = (parsed.hostname || '').toLowerCase();
              if (!host.endsWith('.atlassian.net')) {
                  return {
                      valid: false,
                      error: 'Must be an Atlassian cloud domain (e.g., your-company.atlassian.net)'
                  };
              }
              slugCandidate = host.replace(/\.atlassian\.net$/, '');
          } catch (e) {
              logger$p.debug('Error parsing Atlassian URL candidate:', 'validation', e);
              return {
                  valid: false,
                  error: 'Enter a company slug (e.g., your-company) or full Atlassian URL (https://your-company.atlassian.net).'
              };
          }
      }

      if (!slugPattern.test(slugCandidate)) {
          return {
              valid: false,
              error: 'Company slug must be alphanumeric and may include hyphens (e.g., your-company)'
          };
      }

      const normalized = `https://${slugCandidate}.atlassian.net`;
      return { valid: true, normalized, slug: slugCandidate };
  }

  /**
   * Validates the AI Service API endpoint URL
   * @param {string} endpoint - The endpoint URL to validate
   * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
   */
  function validateAiEndpoint(endpoint) {
      if (!endpoint || typeof endpoint !== 'string') {
          return { valid: false, error: 'API endpoint is required' };
      }

      const trimmed = endpoint.trim().replace(/\/$/, '');

      try {
          const url = new URL(trimmed);

          // AI Service API endpoint must use HTTPS for security
          if (url.protocol !== 'https:') {
              return { valid: false, error: 'AI Service API endpoint must use HTTPS' };
          }

          // Tighten security: Prevent local/internal network addresses for the primary AI service
          const hostname = url.hostname.toLowerCase();

          // Check for private/local addresses (SSRF prevention)
          // Check for private/local addresses (SSRF prevention)
          const isLocal = hostname === 'localhost' ||
              hostname === '127.0.0.1' ||
              hostname.startsWith('192.168.') ||
              hostname.startsWith('10.') ||
              hostname.endsWith('.local') ||
              // IPv6 loopback, link-local, site-local, unique-local, and ipv4-mapped
              hostname === '::1' ||
              hostname === '[::1]' ||
              /^fe80:/i.test(hostname) ||   // Link-Local
              /^fec0:/i.test(hostname) ||   // Site-Local (deprecated)
              /^fc00:/i.test(hostname) ||   // Unique Local Address (ULA)
              /^fd00:/i.test(hostname) ||   // Unique Local Address (ULA)
              /^::ffff:/i.test(hostname);   // IPv4-mapped IPv6

          // Check full 172.16.0.0/12 private range (172.16.x.x - 172.31.x.x)
          // RegEx explanation: 172 . (16-19 | 20-29 | 30-31) . x . x
          const is172Private = /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname);

          if (isLocal || is172Private) {
              return {
                  valid: false,
                  error: 'AI Service endpoint cannot be a local or private network address for security reasons. Use a public HTTPS gateway.'
              };
          }

          return { valid: true, normalized: url.toString().replace(/\/$/, '') };
      } catch (error) {
          logger$p.debug('Error parsing AI endpoint URL:', 'validation', error);
          return { valid: false, error: 'Invalid URL format for API endpoint' };
      }
  }

  /**
   * Permissions and Configuration Module
   * Provides helper functions for managing API endpoints and permissions.
   */

  const logger$o = createLogger('Permissions');

  /**
   * Get API endpoint from configuration.
   * Requires endpoint to be configured via chrome.storage.
   * 
   * @returns {Promise<string>} The API endpoint URL
   * @throws {Error} If API endpoint is not configured
   */
  async function getApiEndpoint() {
      try {
          const { apiEndpoint } = await chrome.storage.local.get('apiEndpoint');

          if (!apiEndpoint) {
              throw new Error('API endpoint is not configured. Please configure it in the extension options.');
          }

          // Basic runtime validation
          const validation = validateAiEndpoint(apiEndpoint);
          if (!validation.valid) {
              throw new Error(`Configured API endpoint is invalid: ${validation.error}`);
          }

          return validation.normalized;
      } catch (error) {
          logger$o.error('Error retrieving API endpoint:', 'permissions', error);
          throw error;
      }
  }

  /**
   * Ensure the extension has host permission for a given URL (prompts user if needed).
   * @param {string} url - The full URL whose origin should be permitted
   * @param {boolean} [promptIfNeeded=false] - Whether to prompt the user if permission is missing
   * @returns {Promise<void>}
   */
  async function ensureHostPermissionForUrl(url, promptIfNeeded = false) {
      if (!url) {
          throw new Error('API endpoint is not configured');
      }
      const parsed = new URL(url);
      const originPattern = `${parsed.protocol}//${parsed.host}/*`;

      try {
          const hasPerm = await chrome.permissions.contains({ origins: [originPattern] });
          if (hasPerm) return;

          // If caller doesn't want us to prompt (e.g., running in a non-user-gesture
          // context like background/message handler), surface a clear error so the
          // caller or UI can request permission from a user gesture.
          if (!promptIfNeeded) {
              const err = new Error(`Missing host permission for ${originPattern}`);
              err.code = 'MISSING_HOST_PERMISSION';
              throw err;
          }

          // Attempt to request permissions. Note: this must be called during a
          // user gesture (e.g., in an options page click handler).
          try {
              const granted = await chrome.permissions.request({ origins: [originPattern] });
              if (!granted) {
                  const err = new Error(`Permission denied for ${originPattern}`);
                  err.code = 'PERMISSION_DENIED';
                  throw err;
              }
          } catch (requestErr) {
              logger$o.debug('Error requesting host permission:', 'permissions', requestErr);
              // Detect user-gesture-related failure and rethrow a specific error code
              const isUserGestureError = requestErr && (requestErr.message && requestErr.message.toLowerCase().includes('user gesture')) || (requestErr.name === 'InvalidStateError');
              if (isUserGestureError) {
                  const err = new Error('Permission request must be performed from a user gesture (UI).');
                  err.code = 'USER_GESTURE_REQUIRED';
                  err.cause = requestErr;
                  throw err;
              }
              throw requestErr;
          }
      } catch (err) {
          logger$o.error('Failed to ensure host permission for', 'permissions', originPattern, err);
          throw err;
      }
  }

  /**
   * Rate Limiter Utility
   * Implements token bucket algorithm to prevent overwhelming external services
   */


  const logger$n = createLogger('RateLimiter');

  class RateLimiter {
    constructor(options = {}) {
      this.maxTokens = options.maxTokens || 10; // Max requests in window
      this.refillRate = options.refillRate || 1; // Tokens added per interval
      this.refillInterval = options.refillInterval || 1000; // Interval in ms
      this.tokens = this.maxTokens;
      this.lastRefill = Date.now();
      this.queue = [];
      this.isProcessing = false;
    }

    /**
     * Refills tokens based on elapsed time since last refill
     */
    refill() {
      const now = Date.now();
      const elapsed = now - this.lastRefill;
      const tokensToAdd = Math.floor(elapsed / this.refillInterval) * this.refillRate;

      if (tokensToAdd > 0) {
        this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
        // Advance lastRefill by the amount of time accounted for by the tokens added
        this.lastRefill += tokensToAdd * (this.refillInterval / this.refillRate);
      }

      this.processQueue();
    }

    /**
     * Acquires a token to make a request
     * Supports cancellation via AbortSignal while waiting in the queue.
     * @returns {Promise<void>} Resolves when token is available
     */
    async acquire(signal = null) {
      this.refill();
      if (this.tokens > 0) {
        this.tokens--;
        return Promise.resolve();
      }

      // Queue the request
      return new Promise((resolve, reject) => {
        const entry = { resolve, reject, cleanup: null };
        this.queue.push(entry);

        if (!signal) return;

        // Handle already-aborted signals
        if (signal.aborted) {
          this.queue = this.queue.filter(item => item !== entry);
          reject(new DOMException('Request aborted while waiting for rate limit', 'AbortError'));
          return;
        }

        const abortHandler = () => {
          this.queue = this.queue.filter(item => item !== entry);
          reject(new DOMException('Request aborted while waiting for rate limit', 'AbortError'));
        };

        signal.addEventListener('abort', abortHandler, { once: true });
        entry.cleanup = () => signal.removeEventListener('abort', abortHandler);
      });
    }

    /**
     * Processes queued requests when tokens become available
     */
    processQueue() {
      if (this.isProcessing) return;
      this.isProcessing = true;

      while (this.queue.length > 0 && this.tokens > 0) {
        this.tokens--;
        const entry = this.queue.shift();
        entry?.cleanup?.();
        entry?.resolve?.();
      }

      this.isProcessing = false;
    }

    /**
     * Executes a function with rate limiting
     * @param {Function} fn - Function to execute
     * @param {AbortSignal} signal - Optional abort signal for cancellation
     * @returns {Promise<*>} Result of the function
     */
    async execute(fn, signal = null) {
      // Check if already aborted
      if (signal?.aborted) {
        throw new DOMException('Request aborted before execution', 'AbortError');
      }

      // Wait for token
      await this.acquire(signal);

      // Check again after waiting
      if (signal?.aborted) {
        // Return token since we didn't use it
        this.tokens = Math.min(this.maxTokens, this.tokens + 1);
        throw new DOMException('Request aborted while waiting for rate limit', 'AbortError');
      }

      // Execute function
      return fn();
    }

    /**
     * Cleans up the rate limiter
     */
    destroy() {
      this.tokens = 0;
      // Reject all queued requests
      this.queue.forEach(entry => {
        entry?.cleanup?.();
        entry?.resolve?.();
      });
      this.queue = [];
    }

    /**
     * Gets current state for debugging
     */
    getState() {
      return {
        tokens: this.tokens,
        queueLength: this.queue.length,
        maxTokens: this.maxTokens
      };
    }
  }

  /**
   * Rate limiter with exponential backoff for failed requests
   */
  class RateLimiterWithBackoff extends RateLimiter {
    constructor(options = {}) {
      super(options);
      this.backoffMultiplier = options.backoffMultiplier || 2;
      this.maxBackoff = options.maxBackoff || 30000; // 30 seconds max
      this.baseDelay = options.baseDelay || 1000; // 1 second base
      this.backoffState = new Map(); // Track backoff per endpoint
    }

    /**
     * Executes function with exponential backoff on failure
     * @param {Function} fn - Function to execute
     * @param {string} endpoint - Endpoint identifier for backoff tracking
     * @param {AbortSignal} signal - Optional abort signal
     * @returns {Promise<*>}
     */
    async executeWithBackoff(fn, endpoint = 'default', signal = null) {
      // Check for existing backoff
      const backoffEntry = this.backoffState.get(endpoint);
      if (backoffEntry && Date.now() < backoffEntry.until) {
        const waitTime = backoffEntry.until - Date.now();
        logger$n.warn(`Rate limiter: Endpoint ${endpoint} in backoff, waiting ${waitTime}ms`, 'rate-limiter', undefined);

        // Wait for backoff to expire or abort
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(resolve, waitTime);

          if (signal) {
            const abortHandler = () => {
              clearTimeout(timeout);
              reject(new DOMException('Request aborted during backoff', 'AbortError'));
            };
            signal.addEventListener('abort', abortHandler);

            // Clean up listener when promise settles
            const cleanup = () => signal.removeEventListener('abort', abortHandler);
            Promise.resolve().then(() => {
              setTimeout(cleanup, 0);
            });
          }
        });
      }

      try {
        const result = await this.execute(fn, signal);
        // Success - clear backoff
        this.backoffState.delete(endpoint);
        return result;
      } catch (error) {
        logger$n.debug('Execution failed in rate limiter', 'rate-limiter', error);
        // Check if it's a rate limit error (429) or server error (5xx)
        const shouldBackoff = error.status === 429 ||
          (error.status >= 500 && error.status < 600);

        if (shouldBackoff) {
          const currentAttempt = backoffEntry?.attempts || 0;
          const delay = Math.min(
            this.baseDelay * Math.pow(this.backoffMultiplier, currentAttempt),
            this.maxBackoff
          );

          this.backoffState.set(endpoint, {
            attempts: currentAttempt + 1,
            until: Date.now() + delay
          });

          logger$n.warn(`Rate limiter: Backing off endpoint ${endpoint} for ${delay}ms`, 'rate-limiter', undefined);
        }

        throw error;
      }
    }

    /**
     * Clears backoff state for an endpoint
     */
    clearBackoff(endpoint) {
      this.backoffState.delete(endpoint);
    }

    destroy() {
      super.destroy();
      this.backoffState.clear();
    }
  }

  // Create default rate limiters for different services
  const rateLimiters = {
    ai: new RateLimiterWithBackoff({
      maxTokens: RATE_LIMIT_CONFIG.ai.maxTokens,
      refillRate: RATE_LIMIT_CONFIG.ai.refillRate,
      refillInterval: RATE_LIMIT_CONFIG.ai.refillIntervalMs,
      baseDelay: RATE_LIMIT_CONFIG.ai.baseDelayMs,
      maxBackoff: RATE_LIMIT_CONFIG.ai.maxBackoffMs
    }),

    atlassian: new RateLimiterWithBackoff({
      maxTokens: RATE_LIMIT_CONFIG.atlassian.maxTokens,
      refillRate: RATE_LIMIT_CONFIG.atlassian.refillRate,
      refillInterval: RATE_LIMIT_CONFIG.atlassian.refillIntervalMs,
      baseDelay: RATE_LIMIT_CONFIG.atlassian.baseDelayMs,
      maxBackoff: RATE_LIMIT_CONFIG.atlassian.maxBackoffMs
    }),

    local: new RateLimiter({
      maxTokens: RATE_LIMIT_CONFIG.local.maxTokens,
      refillRate: RATE_LIMIT_CONFIG.local.refillRate,
      refillInterval: RATE_LIMIT_CONFIG.local.refillIntervalMs
    })
  };

  const cleanupRateLimiters = () => {
    Object.values(rateLimiters).forEach(limiter => limiter.destroy());
  };

  // Cleanup on unload/pagehide (content/background pages)
  if (typeof window !== 'undefined') {
    window.addEventListener('unload', cleanupRateLimiters);
    window.addEventListener('pagehide', cleanupRateLimiters);
  }

  // Cleanup on MV3 service worker suspend if available
  if (typeof chrome !== 'undefined' && chrome.runtime?.onSuspend) {
    chrome.runtime.onSuspend.addListener(cleanupRateLimiters);
  }

  /**
   * Synchronization Utilities
   * Provides primitives for managing concurrency and state consistency
   */

  /**
   * A simple async Mutex lock
   * Ensures restricted access to a resource
   */
  class Mutex {
    constructor() {
      this._queue = [];
      this._locked = false;
    }

    isLocked() {
      return this._locked;
    }

    /**
     * Acquire the lock.
     * If strictly one-at-a-time access is needed, await this method.
     * @returns {Promise<Function>} A release function to be called when done.
     */
    lock() {
      return new Promise((resolve) => {
        const release = () => {
          if (this._queue.length > 0) {
            const next = this._queue.shift();
            next();
          } else {
            this._locked = false;
          }
        };

        if (this._locked) {
          this._queue.push(() => resolve(release));
        } else {
          this._locked = true;
          resolve(release);
        }
      });
    }

    /**
     * Run a task while holding the lock
     * @param {Function} task - Async function to execute
     */
    async runExclusive(task) {
      const release = await this.lock();
      try {
        return await task();
      } finally {
        release();
      }
    }
  }

  /**
   * AI Client Module
   * Handles low-level AI API operations: authentication, transport, retries, and caching.
   * 
   * @module api/ai-client
   */


  const logger$m = createLogger('AiClient');
  const authStateMutex = new Mutex();

  // Token cache to avoid repeated decryption (cleared on token change)
  let cachedToken = null;
  let cachedTokenEncrypted = null;

  const REQUEST_TIMEOUT = AI_REQUEST_TIMEOUT_MS;
  const MAX_RETRIES = MAX_API_RETRIES;
  const AUTH_FAILURE_THRESHOLD = AUTH_FAILURE_THRESHOLD$1;
  const AUTH_FAILURE_WINDOW_MS = AUTH_FAILURE_WINDOW_MS$1;

  /**
   * Generate a simple hash of a token for tracking purposes
   * @param {string} token - Token to hash
   * @returns {Promise<string>} Hash of the token
   */
  async function hashToken(token) {
      if (!token) return '';
      const encoder = new TextEncoder();
      const data = encoder.encode(token);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }

  /**
   * Get the currently active AI model from settings
   * @returns {Promise<string>} Active AI model ID
   */
  async function getActiveAiModel() {
      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');

      if (!advancedAiSettings?.models) {
          throw new Error('No AI models configured. Please configure at least one model in the extension settings.');
      }

      const activeModelNum = advancedAiSettings.activeModel || 1;
      const modelKey = `model${activeModelNum}`;
      const activeModel = advancedAiSettings.models[modelKey];

      if (!activeModel || !activeModel.trim()) {
          throw new Error(`Active model (${modelKey}) is not configured. Please set up your AI model in the extension settings.`);
      }

      return activeModel.trim();
  }

  /**
   * Internal helper to get auth failure state (must be called within mutex)
   */
  async function getAuthFailureStateInternal(tokenHash) {
      const failureKey = `aiTokenFailures_${tokenHash}`;
      const stored = await chrome.storage.local.get(failureKey);
      return stored[failureKey] || { count: 0, firstFailureTime: null, lastFailureTime: null };
  }

  /**
   * Internal helper to set auth failure state (must be called within mutex)
   */
  async function setAuthFailureStateInternal(tokenHash, state) {
      const failureKey = `aiTokenFailures_${tokenHash}`;
      await chrome.storage.local.set({ [failureKey]: state });
  }

  /**
   * Track authentication failure and determine if token should be invalidated
   */
  async function shouldInvalidateToken(error, failedToken) {
      if (!failedToken) return false;

      return await authStateMutex.runExclusive(async () => {
          try {
              const currentData = await chrome.storage.local.get('aiServiceToken');
              const currentTokenEncrypted = currentData?.aiServiceToken;

              if (!currentTokenEncrypted) return false;

              let currentToken = null;
              if (cachedTokenEncrypted === currentTokenEncrypted && cachedToken) {
                  currentToken = cachedToken;
              } else {
                  try {
                      const result = await decrypt(currentTokenEncrypted);
                      if (!result.ok) throw result.error;
                      currentToken = result.value;
                      cachedTokenEncrypted = currentTokenEncrypted;
                      cachedToken = currentToken;
                  } catch (decryptError) {
                      logger$m.warn('Failed to decrypt stored AI token for auth tracking', 'ai-client', decryptError);
                      return false;
                  }
              }

              if (!currentToken || currentToken !== failedToken) {
                  return false;
              }

              const tokenHash = await hashToken(failedToken);
              const now = Date.now();

              const state = await getAuthFailureStateInternal(tokenHash);

              if (state.firstFailureTime && (now - state.firstFailureTime) > AUTH_FAILURE_WINDOW_MS) {
                  return false;
              }

              const updatedState = {
                  firstFailureTime: state.count === 0 ? now : state.firstFailureTime,
                  lastFailureTime: now,
                  count: state.count + 1
              };

              await setAuthFailureStateInternal(tokenHash, updatedState);

              if (updatedState.count >= AUTH_FAILURE_THRESHOLD) {
                  logger$m.error('Token invalidated after repeated authentication failures', 'ai-client', {
                      failureCount: updatedState.count,
                      threshold: AUTH_FAILURE_THRESHOLD
                  });
                  return true;
              }

              logger$m.warn(`Auth failure ${updatedState.count}/${AUTH_FAILURE_THRESHOLD} for token`, 'ai-client');
              return false;
          } catch (error) {
              logger$m.warn('Failed to check token invalidation status', 'ai-client', error);
              return false;
          }
      });
  }

  /**
   * Reset auth failure tracking
   */
  async function resetAuthFailure(token) {
      if (!token) return;

      return await authStateMutex.runExclusive(async () => {
          try {
              const tokenHash = await hashToken(token);
              // We can just remove it, but internal helper get check might be useful if we want to log
              // But removing is simpler. Let's strictly use internal set/get or direct remove?
              // "reset" usually means remove key or set count 0.
              const failureKey = `aiTokenFailures_${tokenHash}`;
              // Direct removal is fine, it's atomic enough (one OP), but being inside mutex ensures no race with increment.
              // Wait, chrome.storage.local.remove is async.
              // Let's use getAuthFailureStateInternal just to check if we should log.
              const state = await getAuthFailureStateInternal(tokenHash);

              if (state && state.count > 0) {
                  logger$m.info('Auth failure tracking reset after successful request', 'ai-client');
                  await chrome.storage.local.remove(failureKey);
              }
          } catch (error) {
              logger$m.warn('Failed to reset auth failure tracking', 'ai-client', error);
          }
      });
  }

  /**
   * Check whether AI is enabled and a token is available
   */
  async function hasValidAiServiceToken() {
      const { aiServiceToken, aiEnabled } = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
      const enabled = typeof aiEnabled === 'undefined' ? true : !!aiEnabled;
      return !!aiServiceToken && enabled;
  }

  /**
   * Get AI service authentication token from storage
   */
  async function getAuthToken() {
      try {
          const data = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
          const enabled = typeof data.aiEnabled === 'undefined' ? true : !!data.aiEnabled;
          if (!enabled) {
              throw new Error('AI disabled by user');
          }
          if (!data || !data.aiServiceToken) {
              throw new Error('No AI Service API token found');
          }

          if (cachedTokenEncrypted === data.aiServiceToken && cachedToken) {
              return cachedToken;
          }

          try {
              const result = await decrypt(data.aiServiceToken);
              if (!result.ok) throw result.error;
              const token = result.value;
              cachedTokenEncrypted = data.aiServiceToken;
              cachedToken = token;
              return token;
          } catch (decryptError) {
              const shouldReconfigure = decryptError.code === 'DECRYPT_FAILED' || decryptError.code === 'SESSION_KEY_MISMATCH';
              if (shouldReconfigure) {
                  logger$m.error('Token decryption failed; user should reconfigure', 'ai-client', decryptError);
                  throw new Error('Failed to decrypt AI Service API token. Please reconfigure your token in settings.');
              }
              throw decryptError;
          }
      } catch (error) {
          logger$m.error('Error retrieving AI Service API token:', 'ai-client', error);
          if (error.message.includes('decrypt')) {
              throw error;
          }
          throw new Error('Failed to retrieve AI Service API token. Please check your settings.');
      }
  }

  /**
   * Fetch with timeout and automatic retry
   */
  async function fetchWithTimeoutAndRetry(url, options, retries = MAX_RETRIES, timeout = REQUEST_TIMEOUT, externalSignal = null) {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), timeout);

      if (externalSignal) {
          if (externalSignal.aborted) {
              clearTimeout(id);
              throw new DOMException('Request cancelled by user', 'AbortError');
          }
          externalSignal.addEventListener('abort', () => {
              clearTimeout(id);
              controller.abort();
          }, { once: true });
      }

      try {
          const response = await fetch(url, {
              ...options,
              signal: controller.signal
          });
          clearTimeout(id);
          return response;
      } catch (error) {
          logger$m.debug('AI service request error', 'ai-client', error);
          clearTimeout(id);
          if (error.name === 'AbortError') {
              throw new DOMException('Request timed out. Please check your internet connection.', 'AbortError');
          }
          if (retries > 0) {
              logger$m.info(`Retrying request... (${retries} attempts left)`, 'ai-client', { error: error.message });
              return fetchWithTimeoutAndRetry(url, options, retries - 1, timeout, externalSignal);
          }
          logger$m.error('AI service request failed after retries', 'ai-client', error);
          throw error;
      }
  }

  /**
   * Extract operation name from GraphQL query
   */
  function getOperationName(query) {
      const match = query.match(/(query|mutation)\s+(\w+)/);
      return match ? match[2] : 'AnonymousOperation';
  }

  /**
   * Make a GraphQL API request to AI service
   */
  async function makeApiRequest(query, variables = {}, token = null, signal = null) {
      let authToken;
      try {
          authToken = token || await getAuthToken();

          // Check if this token is currently marked as "should invalidate" or has high failure count
          // to prevent thundering herd on a known-bad token.
          if (authToken) {
              const tokenHash = await hashToken(authToken);
              const failureKey = `aiTokenFailures_${tokenHash}`;

              const state = await authStateMutex.runExclusive(async () => {
                  return await getAuthFailureStateInternal(tokenHash);
              });

              if (state && state.count >= AUTH_FAILURE_THRESHOLD) {
                  const now = Date.now();
                  if (!state.firstFailureTime || (now - state.firstFailureTime) < AUTH_FAILURE_WINDOW_MS) {
                      logger$m.warn('Token is temporarily locked due to high failure rate, skipping request', 'ai-client');
                      return Result.failure(new Error('AI service is temporarily restricted due to repeated authentication failures. Please check your settings.'));
                  }
              }
          }
      } catch (error) {
          logger$m.error('Error in makeApiRequest preprocessing', 'ai-client', error);
          return Result.failure(error);
      }

      const apiEndpoint = await getApiEndpoint();
      await ensureHostPermissionForUrl(apiEndpoint, false);
      const cacheKey = JSON.stringify({ query, variables });
      const now = Date.now();

      const cached = responseCache.get(cacheKey);
      if (cached && (now - cached.timestamp) < CACHE_TTL) {
          return Result.success(cached.data);
      }

      try {
          const response = await rateLimiters.ai.executeWithBackoff(
              async () => {
                  return await fetchWithTimeoutAndRetry(apiEndpoint, {
                      method: 'POST',
                      headers: {
                          'Content-Type': 'application/json',
                          'X-Auth-Token': authToken,
                          'X-Request-Source': 'salesforce-extension',
                          'X-Request-ID': crypto.randomUUID()
                      },
                      body: JSON.stringify({
                          query,
                          variables,
                          operationName: getOperationName(query)
                      })
                  }, MAX_RETRIES, REQUEST_TIMEOUT, signal);
              },
              'ai-client',
              signal
          );

          if (!response.ok) {
              const errorText = await response.text();
              const error = new Error(`API request failed: ${errorText}`);
              error.status = response.status;
              error.endpoint = apiEndpoint;
              throw error;
          }

          const data = await response.json();

          if (data.errors) {
              const errorMessages = data.errors.map(err => err.message).join('; ');
              const error = new Error(`GraphQL Error: ${errorMessages}`);
              error.status = response.status;
              throw error;
          }

          await setCache(cacheKey, data);

          resetAuthFailure(authToken).catch(err => {
              logger$m.warn('Failed to reset auth failure tracking', 'ai-client', err);
          });

          scheduleCachePersist();

          return Result.success(data);
      } catch (error) {
          logger$m.error('API Request Error:', 'ai-client', {
              error: error.message,
              query: getOperationName(query),
              timestamp: new Date().toISOString()
          });

          const isAuthError = error.status === 401 || error.status === 403 ||
              error.message.includes('401') || error.message.includes('403');

          if (isAuthError) {
              const shouldInvalidate = await shouldInvalidateToken(error, authToken);
              if (shouldInvalidate) {
                  logger$m.error('Token invalidated after repeated authentication failures', 'ai-client');
                  responseCache.clear();
                  cachedToken = null;
                  cachedTokenEncrypted = null;
                  await chrome.storage.local.remove('aiServiceToken');

                  handleError(error, {
                      strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                      context: 'AI Client',
                      operation: 'makeApiRequest:auth',
                      userMessage: ErrorMessages.API_AUTH_FAILED
                  });

                  return Result.failure(new Error('Authentication failed repeatedly. Your AI Service API token has been cleared. Please update it in the extension settings.'));
              } else {
                  handleError(error, {
                      strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                      context: 'AI Client',
                      operation: 'makeApiRequest:auth',
                      userMessage: 'Authentication error. If this persists, please check your API token in settings.'
                  });

                  return Result.failure(new Error('Authentication failed. Please verify your AI Service API token is correct.'));
              }
          }

          if (error.name !== 'AbortError') {
              handleError(error, {
                  strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                  context: 'AI Client',
                  operation: `makeApiRequest:${getOperationName(query)}`
              });
          }

          return Result.failure(error);
      }
  }

  /**
   * Test AI service connection.
   * Used during setup and troubleshooting to verify API endpoint and token validity.
   * 
   * @param {string|null} [token=null] - Optional token for testing
   * @param {string|null} [testModel=null] - Optional specific model to test (overrides active model)
   * @returns {Promise<Result>} Standardized Result object with success status and model info
   */
  async function testConnection(token, testModel = null) {
      const apiEndpoint = await getApiEndpoint();
      await ensureHostPermissionForUrl(apiEndpoint, true);

      const model = testModel || await getActiveAiModel();
      const testMutation =
          'mutation TestConnection($model: String!, $prompt: String!) {' +
          '  answerPrompt(input: {' +
          '    model: $model' +
          '    prompt: $prompt' +
          '    temperature: 0.1' +
          '  })' +
          '}';

      const variables = {
          model: model,
          prompt: "Please respond with 'Connection successful' to test the API connection."
      };

      try {
          const startTime = performance.now();
          const result = await makeApiRequest(testMutation, variables, token);

          if (!result.ok) {
              return result;
          }

          const responseTime = Math.round(performance.now() - startTime);
          const updatedApiEndpoint = await getApiEndpoint();

          return Result.success({
              message: result.value.data.answerPrompt || 'Connection successful',
              responseTime: `${responseTime}ms`,
              serverTimestamp: new Date().toISOString(),
              endpoint: updatedApiEndpoint,
              testedModel: model
          });
      } catch (error) {
          logger$m.error('AI service connection test failed', 'testConnection', error);
          return Result.failure(error);
      }
  }

  /**
   * AI Service Module
   * Handles AI-powered features for Salesforce cases (Solution synthesis, improvement, spellcheck).
   * 
   * @module api/ai-service
   */


  const logger$l = createLogger('AiService');

  /**
   * Suggest a solution based on case data and context.
   * Analyzes case details and provided context (like search results) to synthesize a resolution.
   * 
   * @param {Object} [caseData={}] - Salesforce case information
   * @param {string} [context=""] - Additional context (e.g., related Jira/Confluence results)
   * @returns {Promise<Result>} Standardized Result object containing the suggested solution text on success
   */
  async function suggestSolution(caseData = {}, context = "") {
    if (!caseData || Object.keys(caseData).length === 0) {
      try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const activeTab = tabs[0];
        if (activeTab && activeTab.id) {
          const response = await chrome.tabs.sendMessage(activeTab.id, { action: 'extractCaseData' });
          if (response?.success && response.data) {
            caseData = response.data || {};
          }
        }
      } catch (e) {
        logger$l.warn('suggestSolution: extraction fallback failed', 'ai-service', e);
        try {
          showInfo('AI could not extract case details automatically; using default prompt. Results may be less specific.');
        } catch (notifyErr) {
          logger$l.warn('Failed to notify user about extraction failure', 'ai-service', notifyErr);
        }
      }
    }

    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const parameters = getAiParameters('caseSummary', advancedAiSettings);

    const prompt = buildSolutionPrompt(caseData, context);

    const mutation = buildPromptMutation('SuggestSolution', true);
    const variables = buildMutationVariables(model, prompt, parameters, true);

    try {
      const response = await makeApiRequest(mutation, variables);
      if (!response.ok) return response;
      return Result.success(response.value.data.answerPrompt);
    } catch (error) {
      logger$l.error('Error in suggestSolution:', 'ai-service', error);
      return Result.failure(error);
    }
  }

  /**
   * Improve an existing solution with AI.
   * Enhances clarity, tone, and technical accuracy while maintaining the core message.
   * 
   * @param {string} currentSolution - Current solution text to improve
   * @param {Object} [caseData={}] - Case information for signature and context
   * @returns {Promise<Result>} Standardized Result object containing the improved solution and signature on success
   */
  async function improveSolution(currentSolution, caseData = {}) {
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const parameters = getAiParameters('improvement', advancedAiSettings);

    const prompt = buildImprovementPrompt(currentSolution, caseData);

    const mutation = buildPromptMutation('ImproveSolution', true);
    const variables = buildMutationVariables(model, prompt, parameters, true);

    try {
      const response = await makeApiRequest(mutation, variables);
      if (!response.ok) return response;

      const improvedText = response.value.data.answerPrompt;

      const signature = generateEmailSignature(caseData);
      return Result.success(improvedText + signature);
    } catch (error) {
      logger$l.error('Error in improveSolution:', 'ai-service', error);
      return Result.failure(error);
    }
  }

  /**
   * Spellcheck and grammar check text using AI.
   * Focuses on professional support communication standards.
   * 
   * @param {string} text - Text to check and correct
   * @param {Object} [caseData={}] - Case information for signature and domain context
   * @returns {Promise<Result>} Standardized Result object containing the corrected text and signature on success
   */
  async function spellcheckText(text, caseData = {}) {
    const prompt = buildSpellCheckPrompt(text, caseData);

    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const parameters = getAiParameters('spellcheck', advancedAiSettings);

    const mutation = buildPromptMutation('SpellcheckText', true);
    const variables = buildMutationVariables(model, prompt, parameters, true);

    try {
      const response = await makeApiRequest(mutation, variables);
      if (!response.ok) return response;

      const correctedText = response.value.data.answerPrompt;

      const signature = generateEmailSignature(caseData);
      return Result.success(correctedText + signature);
    } catch (error) {
      logger$l.error('Error in spellcheckText:', 'ai-service', error);
      return Result.failure(error);
    }
  }

  /**
   * Centralized JSON Parsing Utility
   * Handles various JSON formats including markdown-wrapped responses and extraction
   * of JSON from mixed content. Provides multiple fallback strategies for robustness.
   *
   * @module json-parser
   */


  const logger$k = createLogger('JsonParser');

  /**
   * Parses JSON string with various fallback strategies.
   * Attempts direct parsing first, then tries markdown removal and extraction
   * to handle JSON embedded in markdown code blocks or mixed content.
   *
   * @param {string} jsonString - String to parse (may contain markdown or mixed content)
   * @param {Object} [options={}] - Configuration options
   * @param {*} [options.fallback=null] - Fallback value if parsing fails
   * @param {boolean} [options.throwOnError=false] - Whether to throw errors or return fallback
   * @param {boolean} [options.removeMarkdown=true] - Whether to remove markdown code blocks first
   * @returns {*} Parsed JSON object/array, fallback value, or throws error based on options
   */
  function parseJSON(jsonString, options = {}) {
    const {
      fallback = null,
      throwOnError = false,
      removeMarkdown = true
    } = options;

    if (typeof jsonString !== 'string' || jsonString.trim() === '') {
      if (throwOnError) {
        throw new Error('Invalid input: Expected non-empty string');
      }
      return fallback;
    }

    let cleaned = jsonString.trim();
    if (removeMarkdown) {
      cleaned = removeMarkdownCodeBlocks(cleaned);
    }

    // Attempt direct parse first
    try {
      const parsed = JSON.parse(cleaned);
      return {
        data: parsed,
        isValid: true,
        error: null
      };
    } catch (firstError) {
      logger$k.debug('Initial JSON.parse failed in parseJSON', 'json-parser', firstError);
      // Attempt to extract first JSON payload from mixed content
      const extracted = extractFirstJSON(cleaned);
      if (extracted) {
        try {
          const parsed = JSON.parse(extracted);
          return {
            data: parsed,
            isValid: true,
            error: null
          };
        } catch (secondError) {
          logger$k.debug('JSON extraction parsing also failed', 'json-parser', secondError);
          // Fall through to error handling
          if (throwOnError) {
            throw new Error(`JSON parsing failed after extraction: ${secondError.message}`);
          }
        }
      }

      if (throwOnError) {
        throw new Error(`JSON parsing failed: ${firstError.message}`);
      }

      logger$k.warn('JSON parsing failed, returning fallback', 'json-parser', {
        error: firstError.message,
        sample: jsonString.substring(0, 200)
      });

      return {
        data: fallback,
        isValid: false,
        error: firstError.message
      };
    }
  }

  /**
   * Removes markdown code blocks and backticks from string.
   * Handles common markdown patterns (```json, ```javascript, inline backticks) to clean
   * responses from AI models that wrap JSON in code blocks.
   *
   * @param {string} str - String to clean (may contain markdown formatting)
   * @returns {string} Cleaned string with markdown removed and trimmed
   */
  function removeMarkdownCodeBlocks(str) {
    if (!str) return '';

    let cleaned = str;
    cleaned = cleaned.replace(/```(?:json|javascript|js)?\s*/gi, '');
    cleaned = cleaned.replace(/```\s*/g, '');
    cleaned = cleaned.replace(/`/g, '');

    return cleaned.trim();
  }

  // ============================================================================
  // INTERNAL HELPERS
  // ============================================================================

  /**
   * Extract the first balanced JSON object or array from a string.
   * Walks the string to find matching braces/brackets while respecting string literals.
   *
   * @private
   * @param {string} str - String to search for JSON
   * @returns {string|null} Extracted JSON substring or null if none found
   */
  function extractFirstJSON(str) {
    if (!str) return null;

    const startIndex = str.search(/[\[{]/);
    if (startIndex === -1) return null;

    let depth = 0;
    let inString = false;
    let escapeNext = false;
    const startChar = str[startIndex];
    const endChar = startChar === '{' ? '}' : ']';

    for (let i = startIndex; i < str.length; i++) {
      const char = str[i];

      if (escapeNext) {
        escapeNext = false;
        continue;
      }

      if (char === '\\') {
        escapeNext = true;
        continue;
      }

      if (char === '"') {
        inString = !inString;
        continue;
      }

      if (inString) continue;

      if (char === startChar) {
        depth += 1;
      } else if (char === endChar) {
        depth -= 1;
        if (depth === 0) {
          return str.slice(startIndex, i + 1);
        }
      }
    }

    return null;
  }

  const logger$j = createLogger('KnowledgeBaseLabels');
  const DEFAULT_LABEL = 'Knowledge Base';

  async function getKnowledgeBaseLabels() {
    try {
      const { knowledgeBaseLabels } = await chrome.storage.local.get('knowledgeBaseLabels');
      const entryLabel = knowledgeBaseLabels?.entryLabel?.trim() || DEFAULT_LABEL;
      const sidebarLabel = knowledgeBaseLabels?.sidebarLabel?.trim() || entryLabel;
      return { entryLabel, sidebarLabel };
    } catch (e) {
      logger$j.warn('Failed to load knowledge base labels, using defaults', 'getKnowledgeBaseLabels', e);
      return { entryLabel: DEFAULT_LABEL, sidebarLabel: DEFAULT_LABEL };
    }
  }

  /**
   * AI Prompt Templates Module
   * Centralized templates for AI prompts used across different services.
   * 
   * @module config/ai-prompts
   */

  /**
   * Build JIRA relevance analysis prompt
   * @param {Object} caseData - Case context data
   * @param {Array} tickets - List of JIRA tickets to analyze
   * @param {number} minScore - Minimum relevance score threshold
   * @returns {string} The formatted prompt
   */
  function buildJiraAnalysisPrompt(caseData, tickets, minScore) {
      const ticketsList = tickets.map((ticket, index) =>
          `INDEX ${index}: [${ticket.key}] ${ticket.summary}\n` +
          `   Description: ${typeof ticket.description === 'string' ? ticket.description.substring(0, 200) + '...' : 'No description'}`
      ).join('\n\n');

      return `You are analyzing JIRA tickets for relevance to a Salesforce case. You must provide specific explanations that reference the actual ticket summaries and content.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}

Found JIRA Tickets (please reference by exact index):
${ticketsList}

CRITICAL INSTRUCTIONS:
1. Focus PRIMARILY on the case DESCRIPTION to understand the specific problem being reported
2. Analyze if the ticket addresses the same issue described in the case description
3. DO NOT mention the Product Family in your explanation - it's already used to filter the project
4. Your explanation MUST mention the ticket key and how it relates to the SPECIFIC problem from the description
5. Be STRICT with relevance scoring based on description match:
   - 80-100: Ticket addresses the exact same issue/feature as described in the case
   - 60-79: Ticket relates to same component but addresses a different specific issue
   - 40-59: Ticket shares keywords but addresses unrelated functionality
   - 0-39: Ticket is not meaningfully related despite keyword overlap
6. Only include tickets with relevance score >= ${minScore}
7. If NO tickets meet the ${minScore}+ threshold, return empty array: {"rankedTickets": []}
8. Avoid generic explanations - explain how the ticket addresses the specific problem described
9. Ensure your ticketIndex matches exactly with the INDEX numbers above
10. Return ONLY the top 5 most relevant tickets
11. Format as JSON: {"rankedTickets": [{"ticketIndex": 0, "relevanceScore": 95, "explanation": "Ticket [TICKET-KEY] addresses [SPECIFIC ISSUE] which matches the [SPECIFIC PROBLEM FROM DESCRIPTION]"}]}

EXAMPLE of a good explanation: "Ticket IMP-6397 addresses user group permission configuration issues, matching the missing user roles problem described in this case."

EXAMPLE of rejecting a poor match: If case description is about "user group roles in Reports" and ticket is about "Canvas role duplication", score this LOW (under ${minScore}) because they address completely different features (Reports vs Canvas).

Be very careful with ticketIndex - it must match the INDEX numbers listed above.`;
  }

  /**
   * Build Confluence relevance analysis prompt
   * @param {Object} caseData - Case context data
   * @param {Array} articles - List of Confluence articles to analyze
   * @param {number} minScore - Minimum relevance score threshold
   * @returns {string} The formatted prompt
   */
  function buildConfluenceAnalysisPrompt(caseData, articles, minScore) {
      const articlesList = articles.map((article, index) =>
          `INDEX ${index}: ${article.title}\n` +
          `   Space: ${article.space}\n` +
          `   Excerpt: ${article.excerpt ? article.excerpt.substring(0, 200) + '...' : 'No excerpt'}`
      ).join('\n\n');

      return `You are analyzing Confluence documentation articles for relevance to a Salesforce case. You must provide specific explanations that reference the actual article titles and content snippets.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}

Found Confluence Articles (please reference by exact index):
${articlesList}

CRITICAL INSTRUCTIONS:
1. Read each article title carefully and understand what SPECIFIC topic it covers
2. Analyze if the article has DIRECT semantic relevance to the case subject and description
3. Your explanation MUST mention the specific article title
4. Connect the article content specifically to the case details - identify shared concepts, features, or components
5. Be STRICT with relevance scoring:
   - 80-100: Article addresses the exact same feature/issue as the case
   - 60-79: Article relates to same component/area but different specific issue
   - 40-59: Article shares some keywords but covers unrelated functionality
   - 0-39: Article is not meaningfully related despite keyword overlap
6. Only include articles with relevance score >= ${minScore}
7. If NO articles meet the ${minScore}+ threshold, return empty array: {"rankedArticles": []}
8. Avoid generic explanations like "matches case context" - explain the SPECIFIC connection
9. Ensure your articleIndex matches exactly with the INDEX numbers above
10. Return ONLY the top 5 most relevant articles
11. Format as JSON: {"rankedArticles": [{"articleIndex": 0, "relevanceScore": 95, "explanation": "The article titled '[EXACT TITLE]' directly addresses [SPECIFIC SHARED FEATURE/COMPONENT] which is the core subject of this case."}]}

EXAMPLE of a good explanation: "The guide titled 'Canvas Integration Setup' directly relates to this case because it provides the authentication steps needed for the Canvas SSO error reported."

EXAMPLE of rejecting a poor match: If case is about "Report export errors" and article is about "Canvas role configuration", score this LOW (under ${minScore}) because they share product context but address completely different features (Reports vs Canvas).

Be very careful with articleIndex - it must match the INDEX numbers listed above.`;
  }

  /**
   * Build Knowledge Base relevance analysis prompt
   * @param {Object} caseData - Case context data
   * @param {Array} guides - List of knowledge base guides to analyze
   * @param {string} entryLabel - Label for KB entries (e.g., "Knowledge Base", "Help Center")
   * @param {number} limit - Maximum number of results to return
   * @returns {string} The formatted prompt
   */
  function buildKnowledgeBaseAnalysisPrompt(caseData, guides, entryLabel, limit) {
      const guidesList = guides.map((guide, index) => {
          const title = (guide.title || 'Untitled').replace(/^\?+/, '').trim();
          const preview = typeof guide.content === 'string'
              ? guide.content.substring(0, 150)
              : (typeof guide.snippet === 'string' ? guide.snippet.substring(0, 150) : 'No preview available');

          return `INDEX ${index}: ${title}\n` +
              `   Category: ${guide.category || 'N/A'}\n` +
              `   Section: ${guide.section || 'N/A'}\n` +
              `   Keywords: ${guide.keywords ? (Array.isArray(guide.keywords) ? guide.keywords.join(', ') : guide.keywords) : 'None'}\n` +
              `   Preview: ${preview}...`;
      }).join('\n\n');

      return `You are analyzing ${entryLabel} content for relevance to a Salesforce case. You must provide specific explanations that reference the actual article titles and content.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}
- Product Component: ${caseData.productComponent || 'N/A'}

Found ${entryLabel} articles (please reference by exact index):
${guidesList}

CRITICAL INSTRUCTIONS:
1. Read each guide title carefully and understand what SPECIFIC topic it covers
2. Analyze if the guide has DIRECT semantic relevance to the case subject and description
3. Your explanation MUST mention the specific guide title
4. Connect the guide content specifically to the case details
5. Be STRICT with relevance scoring:
   - 80-100: Guide addresses the exact same feature/issue as the case
   - 60-79: Guide relates to same component/area but different specific issue
   - 40-59: Guide shares some keywords but covers unrelated functionality
   - 0-39: Guide is not meaningfully related despite keyword overlap
6. Only include guides with relevance score >= 50
7. If NO guides meet the 50+ threshold, return empty array: {"rankedArticles": []}
8. Avoid generic explanations like "matches case context" - explain the SPECIFIC connection
9. Ensure your articleIndex matches exactly with the INDEX numbers above
10. Return ONLY the top ${limit} most relevant guides
11. Format as JSON: {"rankedArticles": [{"articleIndex": 0, "relevanceScore": 95, "explanation": "This ${entryLabel.toLowerCase()} article titled '[EXACT TITLE]' directly addresses [SPECIFIC SHARED FEATURE/COMPONENT]"}]}

Be very careful with articleIndex - it must match the INDEX numbers listed above.`;
  }

  /**
   * Build the GraphQL mutation for AI analysis
   * @param {string} operationName - Name of the mutation operation
   * @returns {string} The GraphQL mutation string
   */
  function buildAiAnalysisMutation(operationName) {
      return `mutation ${operationName}($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) { answerPrompt(input: { model: $model, prompt: $prompt, temperature: $temperature, topP: $topP, topK: $topK }) }`;
  }

  /**
   * Search Orchestrator Utility
   * Consolidates the logic for switching between AI-enhanced and traditional search.
   * Handles fallbacks, settings checks, and token validation in a unified way.
   * 
   * Supports AbortSignal propagation to properly cancel underlying fetch operations
   * when the orchestrator timeout fires or when cancelled externally.
   */


  const logger$i = createLogger('SearchOrchestrator');

  /** Default timeout for search operations (ms) */
  const SEARCH_TIMEOUT_MS = 20000;

  /**
   * Combines multiple AbortSignals into one.
   * Aborts when ANY of the provided signals abort.
   * 
   * @param {AbortSignal[]} signals - Array of signals to combine
   * @returns {AbortSignal} Combined signal
   */
  function combineAbortSignals(signals) {
      const validSignals = signals.filter(s => s instanceof AbortSignal);
      if (validSignals.length === 0) return null;
      if (validSignals.length === 1) return validSignals[0];

      // Use AbortSignal.any if available (modern browsers)
      if (typeof AbortSignal.any === 'function') {
          return AbortSignal.any(validSignals);
      }

      // Fallback for older browsers: create a new controller that aborts when any signal aborts
      const controller = new AbortController();
      for (const signal of validSignals) {
          if (signal.aborted) {
              controller.abort(signal.reason);
              break;
          }
          signal.addEventListener('abort', () => controller.abort(signal.reason), { once: true });
      }
      return controller.signal;
  }

  /**
   * Orchestrates a search operation with AI enhancement and fallback logic.
   * 
   * @param {Object} options - Orchestration options
   * @param {string} options.serviceName - Display name for logging (e.g., 'JIRA')
   * @param {string} options.settingKey - Key in aiEnhancementSettings (e.g., 'jira')
   * @param {Function} options.aiSearchFn - Function to perform AI-enhanced search (receives AbortSignal)
   * @param {Function} options.traditionalSearchFn - Function to perform traditional search (receives AbortSignal)
   * @param {Function} options.fallbackEnhancer - Function to add fallback explanations to traditional results
   * @param {Object} options.caseData - Case context
   * @param {boolean} options.isManualFetch - Whether this was a user-triggered fetch
   * @param {AbortSignal} [options.signal] - Optional external abort signal for cancellation
   * @returns {Promise<Result>} Standardized Result object
   */
  async function orchestratedSearch({
      serviceName,
      settingKey,
      aiSearchFn,
      traditionalSearchFn,
      fallbackEnhancer,
      caseData = {},
      isManualFetch = false,
      signal = null
  }) {
      // Create internal abort controller for timeout
      const timeoutController = new AbortController();

      // Combine external signal (if any) with our timeout signal
      const combinedSignal = signal
          ? combineAbortSignals([signal, timeoutController.signal])
          : timeoutController.signal;

      // Set up timeout to abort the search
      const timeoutId = setTimeout(() => {
          logger$i.warn(`${serviceName} search timed out after ${SEARCH_TIMEOUT_MS / 1000}s`, 'orchestrator');
          timeoutController.abort(new Error(`${serviceName} search timed out after ${SEARCH_TIMEOUT_MS / 1000}s`));
      }, SEARCH_TIMEOUT_MS);

      try {
          // Check if already aborted before starting
          if (combinedSignal?.aborted) {
              const error = new Error('Search aborted before starting');
              error.name = 'AbortError';
              return Result.failure(error);
          }

          // Helper to execute search functions and normalize results to Result object
          const executeSearch = async (fn) => {
              try {
                  // Pass the combined signal to the search function
                  const res = await fn(combinedSignal);
                  // If result is already a Result object, return it
                  if (res && typeof res.ok === 'boolean') {
                      return res;
                  }
                  // Otherwise wrap raw value in success
                  return Result.success(res);
              } catch (err) {
                  logger$i.error('Search internal execution error', 'orchestrator', err);
                  // Check if this was an abort
                  if (err.name === 'AbortError' || combinedSignal?.aborted) {
                      const abortError = new Error('Search was cancelled');
                      abortError.name = 'AbortError';
                      return Result.failure(abortError);
                  }
                  return Result.failure(err);
              }
          };

          // 1. Check AI enhancement settings
          const { aiEnhancementSettings } = await chrome.storage.local.get('aiEnhancementSettings');
          const userToggled = aiEnhancementSettings?.userToggled;
          const useAiEnhancement = (typeof userToggled?.[settingKey] === 'boolean')
              ? !!userToggled[settingKey]
              : (aiEnhancementSettings?.[settingKey] !== false);

          if (useAiEnhancement) {
              // 2. Check for AI Service token
              const hasToken = await hasValidAiServiceToken();
              if (!hasToken) {
                  logger$i.warn(`${serviceName} AI: No AI token configured; skipping AI enhancement.`, 'orchestrator', undefined);
                  const fallbackRes = await executeSearch(traditionalSearchFn);
                  if (!fallbackRes.ok) return fallbackRes;
                  return Result.success(fallbackEnhancer(fallbackRes.value, caseData));
              }

              // 3. Attempt AI Search
              logger$i.info(`${serviceName}: Attempting AI search...`, 'orchestrator', undefined);
              const aiRes = await executeSearch(aiSearchFn);

              if (aiRes.ok) {
                  logger$i.info(`${serviceName}: AI search successful.`, 'orchestrator', undefined);
                  return aiRes;
              }

              // 4. Failed AI Search - Fallback logic
              const aiError = aiRes.error;
              logger$i.error(`${serviceName} AI search failed, falling back:`, 'orchestrator', aiError);

              // Notify user about fallback if appropriate (but not for cancellations)
              if (aiError.name !== 'AbortError') {
                  if (isManualFetch || (aiError.status !== 401 && aiError.status !== 403)) {
                      showWarning(`AI-enhanced ${serviceName} search unavailable. Using traditional search instead.`);
                  }
              } else {
                  // If aborted, don't try fallback - just return the abort error
                  return aiRes;
              }

              // 5. Fallback to Traditional + Fallback Explanations
              const fallbackRes = await executeSearch(traditionalSearchFn);
              if (!fallbackRes.ok) return fallbackRes;
              return Result.success(fallbackEnhancer(fallbackRes.value, caseData));
          }

          // 6. Traditional Search Only (AI disabled)
          logger$i.info(`${serviceName}: Using traditional search (AI disabled)...`, 'orchestrator', undefined);
          return await executeSearch(traditionalSearchFn);
      } finally {
          // Always clear the timeout
          clearTimeout(timeoutId);
      }
  }

  /**
   * Community Service Module
   * Handles Knowledge Base (formerly Community Guides) and local vector database search
   */


  const logger$h = createLogger('CommunityService');

  // ============================================================================
  // LOCAL VECTOR DATABASE SEARCH
  // ============================================================================

  /**
   * Search local vector database for semantic search
   */
  async function searchLocalVectorDB(queryText) {
    // Read configured URL from storage (allowing user to override default)
    try {
      const { localSearchServerUrl, localSearchEnabled } = await chrome.storage.local.get(['localSearchServerUrl', 'localSearchEnabled']);

      if (!localSearchEnabled) {
        return Result.failure('Local vector search is disabled in settings');
      }

      if (!localSearchServerUrl || !localSearchServerUrl.trim()) {
        return Result.failure('Local vector search server URL is not configured');
      }

      const baseUrl = localSearchServerUrl.trim().replace(/\/$/, '');
      const searchUrl = `${baseUrl}/search`;

      const response = await rateLimiters.local.execute(async () => {
        return await fetch(searchUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ query: queryText })
        });
      });

      if (!response.ok) {
        const txt = await response.text().catch(() => response.statusText);
        throw new Error(`Local search server error: ${response.status} ${txt}`);
      }

      const data = await response.json();
      return Result.success(data.results || []);
    } catch (error) {
      logger$h.error('Error in searchLocalVectorDB:', 'community-service', error);
      return Result.failure(error);
    }
  }

  // ============================================================================
  // KNOWLEDGE BASE (formerly Community Guides)
  // ============================================================================

  // Knowledge Base Cache - stores loaded guides/articles
  // NOTE: For very large Knowledge Bases (>5MB), consider migrating from in-memory 
  // caching to IndexedDB to reduce memory footprint in the browser process.
  let COMMUNITY_GUIDES_CACHE = [];
  let loadPromise = null;
  let isLoading = false;

  if (chrome?.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.communityGuides || changes.communityGuidesFilename) {
        COMMUNITY_GUIDES_CACHE = [];
        loadPromise = null;
        isLoading = false;
      }
    });
  }

  /**
   * Load Knowledge Base articles from configurable JSON file
   */
  async function loadCommunityGuides() {
    if (COMMUNITY_GUIDES_CACHE.length > 0) return Result.success(COMMUNITY_GUIDES_CACHE);
    if (isLoading && loadPromise) return loadPromise;

    isLoading = true;
    loadPromise = (async () => {
      try {
        logger$h.debug('Starting Knowledge Base load...', 'community-service');
        const start = Date.now();

        // First, try to load from chrome.storage.local (uploaded via options)
        // Use a timeout for storage access just in case
        const storagePromise = chrome.storage.local.get('communityGuides');
        const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Storage access timeout')), 10000));

        const storageResult = await Promise.race([storagePromise, timeoutPromise]);
        const communityGuides = storageResult ? storageResult.communityGuides : null;

        if (communityGuides && Array.isArray(communityGuides) && communityGuides.length > 0) {
          COMMUNITY_GUIDES_CACHE = communityGuides;
          logger$h.info(`Loaded ${COMMUNITY_GUIDES_CACHE.length} entries from storage in ${Date.now() - start}ms`, 'community-service');
          return Result.success(COMMUNITY_GUIDES_CACHE);
        }

        // Fall back to packaged file
        const { communityGuidesFilename = 'community_guides.json' } =
          await chrome.storage.local.get({ communityGuidesFilename: 'community_guides.json' });

        logger$h.debug(`Fetching packaged file: ${communityGuidesFilename}`, 'community-service');
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), 10000);

        const response = await fetch(chrome.runtime.getURL(communityGuidesFilename), { signal: controller.signal })
          .finally(() => clearTimeout(id));

        if (!response.ok) {
          logger$h.warn('Knowledge base file not found', 'community-service');
          COMMUNITY_GUIDES_CACHE = [];
          return Result.success([]);
        }

        COMMUNITY_GUIDES_CACHE = await response.json();
        logger$h.info(`Loaded ${COMMUNITY_GUIDES_CACHE.length} entries from packaged file in ${Date.now() - start}ms`, 'community-service');
        return Result.success(COMMUNITY_GUIDES_CACHE);
      } catch (error) {
        logger$h.error('Failed to load KB entries:', 'community-service', error);
        return Result.success([]);
      } finally {
        isLoading = false;
        loadPromise = null;
      }
    })();

    return loadPromise;
  }

  /**
   * Generate a smart excerpt based on search terms
   */
  function generateExcerpt(title) {
    if (title.toLowerCase().includes('install')) {
      return 'Step-by-step guide for installing and setting up Impact in your learning management system.';
    } else if (title.toLowerCase().includes('message')) {
      return 'Learn how to create, customize, and manage Impact messages for effective user communication.';
    } else if (title.toLowerCase().includes('campaign')) {
      return 'Guide to creating and managing Impact campaigns to engage users and drive adoption.';
    } else if (title.toLowerCase().includes('report') || title.toLowerCase().includes('analytics')) {
      return 'Access insights and analytics to understand user behavior and tool adoption in Impact.';
    } else if (title.toLowerCase().includes('dashboard')) {
      return 'Navigate and use the Impact Dashboard to manage your instance and content.';
    } else if (title.toLowerCase().includes('permission') || title.toLowerCase().includes('user')) {
      return 'Manage user access, permissions, and team collaboration in Impact.';
    } else if (title.toLowerCase().includes('lti')) {
      return 'Integrate Impact with learning management systems using LTI connections.';
    } else {
      return 'Helpful Impact documentation to guide you through features and troubleshooting.';
    }
  }

  function buildTraditionalGuideExplanation(guide, caseData = {}) {
    const subject = (caseData.subject || '').trim();
    const product = (caseData.productFamily || caseData.productName || '').trim();
    const component = (caseData.productComponent || '').trim();
    const section = (guide.section || guide.category || '').trim();
    const keywords = (guide.keywords || []).slice(0, 3).filter(Boolean).join(', ');

    const focusParts = [];
    if (section) focusParts.push(`it covers ${section}`);
    if (keywords) focusParts.push(`keywords: ${keywords}`);
    if (!focusParts.length) focusParts.push(`the topic "${guide.title}"`);

    const caseParts = [];
    if (subject) caseParts.push(`case subject "${subject}"`);
    if (product) caseParts.push(`product ${product}`);
    if (component) caseParts.push(`component ${component}`);

    const caseText = caseParts.length ? `links to ${caseParts.join(' and ')}` : 'matches the case details provided';
    return `Guide "${guide.title}" is suggested because ${focusParts.join(' and ')} and ${caseText}.`;
  }

  function addCommunityAiFallbackDetails(guides, caseData) {
    // Use a sensible default relevance for fallback results rather than manufacturing a linear drop-off.
    // This explicitly marks them as having high traditional relevance but lacking AI confirmation.
    const DEFAULT_FALLBACK_RELEVANCE = 85;

    return guides.map((guide) => ({
      ...guide,
      aiRelevanceScore: DEFAULT_FALLBACK_RELEVANCE,
      aiExplanation: buildTraditionalGuideExplanation(guide, caseData),
      aiFallback: true
    }));
  }

  /**
   * Search knowledge base entries with optional AI enhancement
   * 
   * @param {Object} caseData - Case context
   * @param {number} limit - Maximum results to return
   * @param {boolean} isManualFetch - Whether this was user-triggered
   * @param {AbortSignal} [signal] - Optional abort signal for cancellation
   */
  async function searchCommunityGuides(caseData, limit = 10, isManualFetch = false, signal = null) {
    return orchestratedSearch({
      serviceName: 'Knowledge Base',
      settingKey: 'community',
      // Signal is passed by orchestrator to these functions
      aiSearchFn: (sig) => searchCommunityGuidesWithAI(caseData, limit, isManualFetch, sig),
      traditionalSearchFn: (sig) => searchCommunityGuidesTraditional(caseData, limit, isManualFetch),
      fallbackEnhancer: addCommunityAiFallbackDetails,
      caseData,
      isManualFetch,
      signal
    });
  }

  /**
   * AI-enhanced Knowledge Base search
   */
  async function searchCommunityGuidesWithAI(caseData, limit = 10, isManualFetch = false, signal = null) {
    let traditionalResults = [];
    try {
      // First get traditional results
      const traditionalRes = await searchCommunityGuidesTraditional(caseData, limit * 2, isManualFetch);
      if (!traditionalRes.ok) return traditionalRes;

      traditionalResults = traditionalRes.value || [];

      if (traditionalResults.length === 0) {
        logger$h.debug('No traditional results found to re-rank', 'community-service');
        return Result.success([]);
      }

      // Check for API token
      const hasToken = await hasValidAiServiceToken();
      if (!hasToken) {
        logger$h.warn('No AI token found for Knowledge Base re-ranking', 'community-service');
        return Result.success(addCommunityAiFallbackDetails(traditionalResults, caseData));
      }

      // Use AI to analyze and re-rank the results
      const { entryLabel } = await getKnowledgeBaseLabels();
      const aiAnalysisPrompt = buildKnowledgeBaseAnalysisPrompt(
        {
          ...caseData,
          description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
        },
        traditionalResults,
        entryLabel,
        limit
      );

      // Get advanced AI settings
      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
      const model = await getActiveAiModel();
      const temperature = advancedAiSettings?.contextSettings?.communityGuides?.temperature ?? 0.2;
      const topP = advancedAiSettings?.contextSettings?.communityGuides?.topP ?? 0.7;
      const topK = advancedAiSettings?.contextSettings?.communityGuides?.topK ?? 30;

      const aiMutation = buildAiAnalysisMutation('AnalyzeKnowledgeBaseRelevance');

      const variables = { model, prompt: aiAnalysisPrompt, temperature, topP, topK };

      const response = await makeApiRequest(aiMutation, variables, null, signal);
      if (!response.ok) {
        logger$h.warn('AI Knowledge Base analysis failed, falling back to traditional results', 'community-service', { error: response.error });
        return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
      }
      const aiResponse = response.value.data.answerPrompt;

      // Parse AI response
      const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

      if (!parseResult.isValid || !parseResult.data) {
        logger$h.warn('Could not parse AI response, using traditional fallback', 'community-service', { error: parseResult.error });
        return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
      }

      const aiAnalysis = parseResult.data;
      if (aiAnalysis.rankedTickets && !aiAnalysis.rankedArticles) {
        aiAnalysis.rankedArticles = aiAnalysis.rankedTickets;
      }

      if (!aiAnalysis.rankedArticles || !Array.isArray(aiAnalysis.rankedArticles)) {
        return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
      }

      // Get minimum relevance threshold
      const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
      const minCommunityScore = preloadSettings?.communityMinScore ?? 80;

      // Re-rank articles based on AI analysis
      const enhancedArticles = aiAnalysis.rankedArticles
        .filter(ranking => {
          const isValidIndex = ranking.articleIndex >= 0 && ranking.articleIndex < traditionalResults.length;
          return isValidIndex && ranking.relevanceScore >= minCommunityScore;
        })
        .sort((a, b) => b.relevanceScore - a.relevanceScore)
        .slice(0, limit)
        .map(ranking => {
          const originalArticle = traditionalResults[ranking.articleIndex];
          return {
            ...originalArticle,
            aiRelevanceScore: ranking.relevanceScore,
            aiExplanation: ranking.explanation || buildTraditionalGuideExplanation(originalArticle, caseData),
            aiFallback: !ranking.explanation
          };
        });

      return Result.success(enhancedArticles);
    } catch (error) {
      logger$h.error('Error in AI Knowledge Base analysis:', 'community-service', error);

      // Fallback: If AI fails but we have traditional results, return those with fallback explanations
      try {
        if (traditionalResults && traditionalResults.length > 0) {
          logger$h.info('Returning traditional Knowledge Base results with fallbacks after AI failure', 'community-service');
          return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
        }
      } catch (fallbackError) {
        logger$h.error('Failed to provide fallback results for Knowledge Base', 'community-service', fallbackError);
      }

      return Result.failure(error);
    }
  }

  /**
   * Traditional Knowledge Base search
   */
  async function searchCommunityGuidesTraditional(caseData, limit = 10, isManualFetch = false) {
    try {
      // Check preload settings
      const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
      const communityPreloadEnabled = preloadSettings
        ? (typeof preloadSettings.community !== 'undefined'
          ? preloadSettings.community !== false
          : preloadSettings.knowledgeBase !== false)
        : true;

      if (!isManualFetch && !communityPreloadEnabled) {
        return Result.success([]);
      }

      const guidesRes = await loadCommunityGuides();
      if (!guidesRes.ok) return guidesRes;

      const guides = guidesRes.value;

      // Optimize search terms extraction for large descriptions
      const subject = (caseData.subject || '').substring(0, 500);
      const description = caseData.description
        ? cleanEmailContent(caseData.description).substring(0, 2000)
        : '';

      const searchTerms = [
        subject,
        description,
        caseData.productName || '',
        caseData.errorMessage || '',
        caseData.category || ''
      ].filter(Boolean).join(' ').toLowerCase();

      const searchWords = searchTerms.split(/\s+/)
        .filter(word => word.length > 3) // Longer words for better precision
        .slice(0, 30); // Even tighter limit

      if (searchWords.length === 0) {
        logger$h.debug('No search terms found for Knowledge Base search', 'community-service');
      }

      const scoredGuides = guides.map(guide => {
        let relevanceScore = 0;
        const titleLower = (guide.title || '').toLowerCase();
        if (!titleLower) return { ...guide, relevanceScore: 0 };

        searchWords.forEach(word => {
          try {
            if (titleLower.includes(word)) relevanceScore += 10;
            if (guide.keywords && Array.isArray(guide.keywords)) {
              if (guide.keywords.some(k => k && typeof k === 'string' && k.toLowerCase().includes(word))) relevanceScore += 5;
            }
            if (guide.section && typeof guide.section === 'string' && guide.section.toLowerCase().includes(word)) relevanceScore += 3;
            if (guide.category && typeof guide.category === 'string' && guide.category.toLowerCase().includes(word)) relevanceScore += 3;
          } catch (e) {
            // Ignore scoring errors for individual fields to ensure overall ranking continues
            logger$h.debug('Field scoring error', 'community-service', { error: e.message, word, field: guide.title });
          }
        });

        // Special boosts
        if ((searchTerms.includes('error') || searchTerms.includes('problem')) &&
          guide.keywords?.some(k => ['setup', 'access', 'login'].includes(k.toLowerCase()))) {
          relevanceScore += 7;
        }

        // Tie-breaker
        let hash = 0;
        for (let i = 0; i < guide.title.length; i++) hash += guide.title.charCodeAt(i);
        const tieBreaker = (hash % 200) / 100;

        return {
          ...guide,
          relevanceScore: parseFloat((relevanceScore + tieBreaker).toFixed(2)),
          excerpt: generateExcerpt(guide.title),
          aiRelevanceScore: null,
          aiExplanation: null
        };
      });

      const sortedGuides = scoredGuides
        .sort((a, b) => b.relevanceScore - a.relevanceScore)
        .slice(0, limit);

      return Result.success(sortedGuides);
    } catch (error) {
      logger$h.error('Error in searchKnowledgeBase:', 'community-service', error);
      return Result.failure(error);
    }
  }

  /**
   * Auto-Save Module
   * Automatically saves draft solution text to prevent data loss
   */


  const logger$g = createLogger('AutoSave');
  const STORAGE_KEY = 'pandaid_draft_autosave';

  /**
   * Clean up stale auto-save data that exceeds the retention threshold.
   * Called during extension startup or periodically to prevent indefinite storage.
   * @returns {Promise<boolean>} Whether any cleanup was performed
   */
  async function cleanupStaleAutoSave() {
    try {
      const result = await chrome.storage.local.get([STORAGE_KEY]);
      const draft = result[STORAGE_KEY];

      if (!draft || !draft.timestamp) {
        return false;
      }

      const age = Date.now() - draft.timestamp;
      if (age > AUTO_SAVE_RECENT_THRESHOLD_MS) {
        await chrome.storage.local.remove([STORAGE_KEY]);
        logger$g.info(`[Auto-Save] Cleaned up stale draft (age: ${Math.floor(age / 3600000)} hours)`, 'auto-save', undefined);
        return true;
      }

      return false;
    } catch (error) {
      logger$g.warn('[Auto-Save] Cleanup error:', 'auto-save', error);
      return false;
    }
  }

  /**
   * Initialization Module
   * Handles service worker initialization, keep-alive, and lifecycle events
   */


  const logger$f = createLogger('Initialization');

  // ============================================================================
  // KEEP-ALIVE MANAGEMENT
  // ============================================================================

  // Service worker keep-alive configuration
  const KEEP_ALIVE_ALARM = 'serviceWorkerKeepAlive';
  const DEFAULT_KEEP_ALIVE_MINUTES = 7; // less aggressive than 10–20s heartbeat
  const MIN_KEEP_ALIVE_MINUTES = 5;
  const MAX_KEEP_ALIVE_MINUTES = 30;
  const CLEANUP_ALARM = 'cleanupCache';
  const CACHE_CLEANUP_INTERVAL_MINUTES = 3;

  async function resolveKeepAliveIntervalMinutes() {
    const { keepAliveIntervalMinutes } = await chrome.storage.local.get({ keepAliveIntervalMinutes: DEFAULT_KEEP_ALIVE_MINUTES });
    const numeric = Number(keepAliveIntervalMinutes);
    const clamped = Math.min(Math.max(isFinite(numeric) ? numeric : DEFAULT_KEEP_ALIVE_MINUTES, MIN_KEEP_ALIVE_MINUTES), MAX_KEEP_ALIVE_MINUTES);
    const jitter = 0.9 + Math.random() * 0.2; // +/-10% jitter to avoid synchronized wakeups
    return clamped * jitter;
  }

  /**
   * Initialize service worker keep-alive using chrome.alarms API
   * This is more efficient than setInterval and works even when service worker is suspended
   */
  async function initializeKeepAlive() {
    try {
      // Allow disabling keep-alive via chrome.storage.local flag for environments
      // where background wakeups are undesirable (e.g., low-power environments)
      const { disableKeepAlive } = await chrome.storage.local.get({ disableKeepAlive: false });
      if (disableKeepAlive) {
        await chrome.alarms.clear(KEEP_ALIVE_ALARM);
        logger$f.info('Keep-alive alarm disabled via storage flag', 'initialization', undefined);
        return;
      }

      // Clear any existing keep-alive alarm
      await chrome.alarms.clear(KEEP_ALIVE_ALARM);

      const interval = await resolveKeepAliveIntervalMinutes();

      // Create keep-alive alarm
      await chrome.alarms.create(KEEP_ALIVE_ALARM, {
        periodInMinutes: interval
      });

      logger$f.info(`Keep-alive alarm created (interval ~${Math.round(interval * 60)}s, jittered)`, 'initializeKeepAlive');
    } catch (error) {
      logger$f.error('Error initializing keep-alive:', 'initialization', error);
    }
  }

  /**
   * Handle keep-alive alarm
   * Performs a lightweight operation to prevent service worker suspension
   */
  function handleKeepAlive() {
    // Lightweight operation to keep service worker alive
    // Just check if we can access chrome APIs
    chrome.runtime.getPlatformInfo().catch(() => {
      logger$f.warn('Keep-alive check failed', 'initialization', undefined);
    });
  }

  // ============================================================================
  // SERVICE WORKER INITIALIZATION
  // ============================================================================

  /**
   * Initialize the service worker with all necessary components
   */
  async function initializeServiceWorker() {
    logger$f.info('Initializing service worker...', 'initialization', undefined);

    try {
      // Initialize keep-alive alarm (prevents service worker suspension)
      await initializeKeepAlive();

      // Restore cache from storage first
      await restoreCache();

      // Set up context menu
      await setupContextMenu();

      // Set up cache cleanup alarm if it doesn't exist
      const existingAlarms = await chrome.alarms.getAll();
      const hasCleanupAlarm = existingAlarms.some(alarm => alarm.name === CLEANUP_ALARM);

      if (!hasCleanupAlarm) {
        chrome.alarms.create(CLEANUP_ALARM, {
          delayInMinutes: CACHE_CLEANUP_INTERVAL_MINUTES,
          periodInMinutes: CACHE_CLEANUP_INTERVAL_MINUTES
        });
        logger$f.info(`Cache cleanup alarm created (interval ${CACHE_CLEANUP_INTERVAL_MINUTES}m)`, 'initializeServiceWorker');
      }

      // Load community guides (if file is configured)
      await loadCommunityGuides();

      // Clean up stale auto-save data (prevents indefinite storage retention)
      await cleanupStaleAutoSave();

      logger$f.info('Service worker initialized successfully', 'initialization', undefined);
    } catch (error) {
      logger$f.error('Error initializing service worker:', 'initialization', error);
    }
  }

  // ============================================================================
  // LIFECYCLE EVENT LISTENERS
  // ============================================================================

  // Track initialization state
  let isInitialized = false;

  /**
   * Handle extension installation or update
   */
  function initializeOnInstalledListener() {
    chrome.runtime.onInstalled.addListener((details) => {
      if (details.reason === 'update' || details.reason === 'install') {
        logger$f.info(`Extension ${details.reason}d. Clearing cache.`, 'initialization', undefined);
        responseCache.clear();

        // Initialize the service worker
        initializeServiceWorker();

        // Open options page on first install
        if (details.reason === 'install') {
          chrome.runtime.openOptionsPage();
        }
      }
    });
  }

  /**
   * Handle extension startup
   */
  function initializeOnStartupListener() {
    chrome.runtime.onStartup.addListener(() => {
      logger$f.info('Extension service worker starting up', 'initialization', undefined);
      initializeServiceWorker().then(() => {
        isInitialized = true;
      });
    });
  }

  /**
   * Handle service worker suspension
   */
  function initializeOnSuspendListener() {
    chrome.runtime.onSuspend.addListener(() => {
      logger$f.info('Extension service worker suspending', 'initialization', undefined);
      isInitialized = false; // Reset initialization flag
    });
  }

  /**
   * Handle alarms (cache cleanup and keep-alive)
   */
  function initializeAlarmsListener() {
    chrome.alarms.onAlarm.addListener(async (alarm) => {
      if (alarm.name === CLEANUP_ALARM) {
        const now = Date.now();
        let cleared = 0;

        for (const [key, { timestamp }] of responseCache.entries()) {
          if ((now - timestamp) > CACHE_TTL) {
            responseCache.delete(key);
            cleared++;
          }
        }

        const trimmed = trimCacheToMax();

        if (cleared > 0 || trimmed) {
          if (cleared > 0) {
            logger$f.info(`Cleared ${cleared} expired cache entries`, 'initialization', undefined);
          }
          if (trimmed) {
            logger$f.info('Cache trimmed to max size after cleanup', 'initialization', undefined);
          }
          // Persist the cleaned cache
          try {
            await persistCache();
          } catch (error) {
            logger$f.error('Cache persist failed after cleanup', 'initialization', error);
          }
        }

        // Also clean up stale auto-save data periodically
        try {
          await cleanupStaleAutoSave();
        } catch (error) {
          logger$f.error('Auto-save cleanup failed during periodic alarm', 'initialization', error);
        }
      } else if (alarm.name === KEEP_ALIVE_ALARM) {
        // Handle service worker keep-alive
        handleKeepAlive();
      }
    });
  }

  /**
   * Initialize all lifecycle event listeners
   */
  function initializeAllListeners() {
    initializeOnInstalledListener();
    initializeOnStartupListener();
    initializeOnSuspendListener();
    initializeAlarmsListener();
  }

  /**
   * Get initialization state
   */
  function getInitializationState() {
    return isInitialized;
  }

  /**
   * Set initialization state
   */
  function setInitializationState(state) {
    isInitialized = state;
  }

  /**
   * Request Queue Module
   * Implements rate limiting and request queuing for API calls
   *
   * @module request-queue
   */

  const MAX_CONCURRENT_REQUESTS = 5;
  const activeRequests = new Set();
  const requestQueue = [];

  // Track abort controllers for active requests to enable cancellation
  const activeAbortControllers = new Map();

  /**
   * Execute a function with rate limiting and request queuing.
   * Ensures no more than MAX_CONCURRENT_REQUESTS run simultaneously.
   * Queues additional requests and executes them as slots become available.
   * Supports AbortSignal for request cancellation.
   *
   * @param {Function} requestFn - Async function to execute (should return a Promise)
   * @param {string} [requestId=null] - Optional identifier for debugging and logging
   * @param {AbortSignal} [signal=null] - Optional abort signal for cancellation
   * @returns {Promise<any>} Promise resolving to the result of requestFn
   */
  async function queueRequest(requestFn, requestId = null, signal = null) {
    if (signal?.aborted) {
      throw new DOMException('Request aborted before queuing', 'AbortError');
    }

    if (activeRequests.size < MAX_CONCURRENT_REQUESTS) {
      return executeRequest(requestFn, requestId, signal);
    }

    return new Promise((resolve, reject) => {
      const queuedItem = { requestFn, requestId, resolve, reject, signal };
      requestQueue.push(queuedItem);

      if (signal) {
        signal.addEventListener('abort', () => {
          const index = requestQueue.indexOf(queuedItem);
          if (index > -1) {
            requestQueue.splice(index, 1);
            reject(new DOMException('Request aborted while queued', 'AbortError'));
          }
        }, { once: true });
      }
    });
  }

  // ============================================================================
  // INTERNAL HELPERS
  // ============================================================================

  /**
   * Execute a request and manage the queue.
   * Handles actual execution, timing, error tracking, and queue processing.
   * Respects AbortSignal for both internal and external cancellation requests.
   *
   * @private
   */
  async function executeRequest(requestFn, requestId, signal = null) {
    const tracker = { id: requestId || `req-${Date.now()}-${Math.random().toString(16).slice(2)}`, startTime: Date.now() };
    activeRequests.add(tracker);

    if (signal?.aborted) {
      activeRequests.delete(tracker);
      throw new DOMException('Request aborted before execution', 'AbortError');
    }

    const abortController = new AbortController();
    activeAbortControllers.set(tracker.id, abortController);

    if (signal) {
      signal.addEventListener('abort', () => {
        abortController.abort();
      }, { once: true });
    }

    try {
      return await requestFn(abortController.signal);
    } catch (error) {
      if (abortController.signal.aborted) {
        throw new DOMException('Request aborted during execution', 'AbortError');
      }
      throw error;
    } finally {
      activeRequests.delete(tracker);
      activeAbortControllers.delete(tracker.id);
      processQueue();
    }
  }

  /**
   * Process the next request in the queue.
   * Called automatically after each request completes to maintain
   * the MAX_CONCURRENT_REQUESTS limit while draining the queue.
   *
   * @private
   */
  function processQueue() {
    if (requestQueue.length === 0 || activeRequests.size >= MAX_CONCURRENT_REQUESTS) {
      return;
    }

    const next = requestQueue.shift();
    if (!next) return;

    if (next.signal?.aborted) {
      next.reject(new DOMException('Request was aborted while queued', 'AbortError'));
      processQueue();
      return;
    }

    // Create internal controller and link to external signal FIRST to prevent race
    const internalController = new AbortController();
    const onAbort = () => internalController.abort();

    if (next.signal) {
      next.signal.addEventListener('abort', onAbort, { once: true });
    }

    executeRequest(next.requestFn, next.requestId, internalController.signal)
      .then(result => {
        next.signal?.removeEventListener('abort', onAbort);
        next.resolve(result);
      })
      .catch(error => {
        next.signal?.removeEventListener('abort', onAbort);
        next.reject(error);
      });
  }

  /**
   * Promise utilities used throughout the extension.
   */

  const DEFAULT_TIMEOUT_MESSAGE = 'Operation timed out';

  /**
   * Wrap an async operation with a timeout. The operation can be a promise or a
   * function that returns a promise. Ensures the timeout timer is cleared when
   * the operation settles to avoid leaking timers.
   *
   * @param {Promise|Function} operation - Promise or function returning a promise
   * @param {number} ms - Timeout duration in milliseconds
   * @param {string} [errorMessage] - Custom error message for timeout
   * @returns {Promise<any>} Resolves/rejects with the underlying operation
   */
  function withTimeout(operation, ms, errorMessage = DEFAULT_TIMEOUT_MESSAGE) {
    const execute = typeof operation === 'function' ? operation : () => operation;

    if (!Number.isFinite(ms) || ms <= 0) {
      return Promise.resolve().then(() => execute());
    }

    let timeoutId = null;
    let settled = false;

    const startTimer = () => new Promise((_, reject) => {
      timeoutId = setTimeout(() => {
        if (settled) {
          return;
        }
        const error = new Error(errorMessage);
        error.name = 'TimeoutError';
        reject(error);
      }, ms);

      if (typeof timeoutId?.unref === 'function') {
        timeoutId.unref();
      }
    });

    const clearTimer = () => {
      settled = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    };

    return Promise.race([
      Promise.resolve().then(() => execute()),
      startTimer()
    ]).then((result) => {
      clearTimer();
      return result;
    }).catch((error) => {
      clearTimer();
      throw error;
    });
  }

  /**
   * Atlassian Explanations Module
   * Fallback explanation builders for JIRA and Confluence results
   * 
   * @module api/atlassian/shared/atlassian-explanations
   */

  /**
   * Build a simple, contextual explanation for a JIRA ticket when AI is unavailable
   * @param {Object} ticket - JIRA ticket data
   * @param {Object} caseData - Salesforce case data
   * @returns {string} Fallback explanation text
   */
  function buildFallbackJiraExplanation(ticket, caseData = {}) {
    const subject = (caseData.subject || '').trim();
    const component = (caseData.productComponent || '').trim();

    const topic = ticket.summary || 'this issue';
    const links = [];
    
    // Don't mention product family - it's already used as a filter for the project
    if (component) links.push(`the ${component} component`);
    if (subject) links.push(`the case subject "${subject}"`);

    const linkText = links.length ? ` and may be relevant to ${links.join(' and ')}` : '';
    return `Ticket ${ticket.key || ''} about "${topic}"${linkText}.`.trim();
  }

  /**
   * Add fallback explanations to JIRA tickets that don't have AI explanations
   * @param {Array} tickets - Array of JIRA tickets
   * @param {Object} caseData - Salesforce case data
   * @returns {Array} Tickets with explanations added
   */
  function addFallbackJiraExplanations(tickets, caseData = {}) {
    return (tickets || []).map(ticket => {
      const hasAiExplanation = !!ticket.aiExplanation;
      return {
        ...ticket,
        aiExplanation: ticket.aiExplanation || buildFallbackJiraExplanation(ticket, caseData),
        aiFallback: !hasAiExplanation // Only mark as fallback if AI explanation wasn't provided
      };
    });
  }

  /**
   * Build a simple, contextual explanation for a Confluence article when AI is unavailable
   * @param {Object} article - Confluence article data
   * @param {Object} caseData - Salesforce case data
   * @returns {string} Fallback explanation text
   */
  function buildFallbackConfluenceExplanation(article, caseData = {}) {
    const subject = (caseData.subject || '').trim();
    const productFamily = (caseData.productFamily || '').trim();
    const component = (caseData.productComponent || '').trim();

    const topic = article.title || 'this article';
    const links = [];
    
    if (productFamily) links.push(`${productFamily}`);
    if (component) links.push(`the ${component} component`);
    if (subject) links.push(`the case subject "${subject}"`);

    const linkText = links.length ? ` and may be relevant to ${links.join(' and ')}` : '';
    return `Article about "${topic}"${linkText}.`.trim();
  }

  /**
   * Add fallback explanations to Confluence articles that don't have AI explanations
   * @param {Array} articles - Array of Confluence articles
   * @param {Object} caseData - Salesforce case data
   * @returns {Array} Articles with explanations added
   */
  function addFallbackConfluenceExplanations(articles, caseData = {}) {
    return (articles || []).map(article => {
      const hasAiExplanation = !!article.aiExplanation;
      return {
        ...article,
        aiExplanation: article.aiExplanation || buildFallbackConfluenceExplanation(article, caseData),
        aiFallback: !hasAiExplanation // Only mark as fallback if AI explanation wasn't provided
      };
    });
  }

  /**
   * Text Utilities Module
   * Utilities for text processing and search term extraction
   *
   * @module text-utils
   */

  /**
   * Extract meaningful search terms from text.
   * Mirrors the Atlassian service implementation so callers stay consistent.
   * Prioritizes error codes, technical terms, and abbreviation expansions.
   *
   * @param {string} text - The text to extract terms from (can contain error codes, technical terms)
   * @param {number} [maxTerms=5] - Maximum number of terms to extract (limits result size)
   * @returns {string[]} Array of extracted search terms (prioritized by relevance)
   * @example
   * extractSearchTerms('Got error 500 and API timeout') 
   * // Returns: ['error 500', 'API timeout', ...]
   */
  function extractSearchTerms(text, maxTerms = 5) {
    if (!text) return [];

    const terms = [];
    const processedTerms = new Set(); // Avoid duplicates

    // 1. Extract error codes and IDs first (highest priority)
    const errorPatterns = [
      /\b[A-Z]{2,4}-?\d{3,6}\b/g, // JIRA-style IDs: ABC-1234
      /\berror\s+\d+\b/gi, // Error codes: error 500
      /\b\d{3,4}\s+error\b/gi, // HTTP errors: 404 error
      /\b[A-Z]{3,8}_[A-Z_]+\b/g, // Constants: API_ERROR_CODE
    ];

    errorPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          const lower = match.toLowerCase();
          if (!processedTerms.has(lower)) {
            terms.push(match);
            processedTerms.add(lower);
          }
        });
      }
    });

    // 2. Expand common abbreviations
    const abbreviations = {
      lti: 'Learning Tools Interoperability',
      sso: 'Single Sign On',
      api: 'Application Programming Interface',
      ui: 'User Interface',
      url: 'Uniform Resource Locator',
      saml: 'Security Assertion Markup Language',
      oauth: 'Open Authorization',
      lms: 'Learning Management System',
      csv: 'Comma Separated Values',
      json: 'JavaScript Object Notation',
      xml: 'eXtensible Markup Language'
    };

    // 3. Clean and tokenize the text
    const cleanText = text
      .replace(/[^\w\s-]/g, ' ') // Remove special chars except hyphens
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();

    const words = cleanText.split(' ');

    // 4. Extract technical terms and meaningful words
    for (const word of words) {
      if (terms.length >= maxTerms) break;

      const lowerWord = word.toLowerCase();

      // Skip if already processed or too short
      if (processedTerms.has(lowerWord) || word.length < 3) continue;

      // Skip common words
      if (isCommonWord(word)) continue;

      // Add abbreviation expansions
      if (abbreviations[lowerWord]) {
        const expansion = abbreviations[lowerWord];
        terms.push(expansion);
        processedTerms.add(lowerWord);
        processedTerms.add(expansion.toLowerCase());
      }

      // Add the original word with simple stemming
      const stemmed = applyStemming(word);
      if (!processedTerms.has(stemmed.toLowerCase())) {
        terms.push(stemmed);
        processedTerms.add(stemmed.toLowerCase());
      }
    }

    // 5. Extract meaningful phrases (technical combinations)
    for (let i = 0; i < words.length - 1 && terms.length < maxTerms; i++) {
      const phrase = words.slice(i, i + 2).join(' ');
      const lowerPhrase = phrase.toLowerCase();

      if (!processedTerms.has(lowerPhrase) &&
          !isCommonWord(words[i]) &&
          isTechnicalPhrase(phrase)) {
        terms.push(phrase);
        processedTerms.add(lowerPhrase);
      }
    }

    // Remove duplicates and limit to max terms
    return terms.slice(0, maxTerms);
  }

  /**
   * Check if a word is a common word that should be filtered out.
   * Common words are ignored during term extraction to improve relevance.
   *
   * @private
   * @param {string} word - The word to check against common word list
   * @returns {boolean} True if the word is a common English word that should be filtered
   */
  function isCommonWord(word) {
    const commonWords = [
      'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
      'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
      'will', 'would', 'could', 'should', 'may', 'might', 'can', 'must',
      'this', 'that', 'these', 'those', 'a', 'an', 'some', 'any', 'all',
      'not', 'no', 'yes', 'so', 'if', 'then', 'when', 'where', 'why', 'how',
      'get', 'got', 'getting', 'use', 'using', 'used', 'make', 'making', 'made'
    ];
    return commonWords.includes(word.toLowerCase());
  }

  /**
   * Apply simple stemming rules to normalize words.
   * Removes common suffixes (ing, ed, er, etc.) to improve term matching.
   *
   * @private
   * @param {string} word - The word to stem (will be lowercased internally)
   * @returns {string} The stemmed word with suffixes removed
   * @example
   * applyStemming('running') // Returns: 'run'
   * applyStemming('connection') // Returns: 'connect'
   */
  function applyStemming(word) {
    const lowerWord = word.toLowerCase();

    // Common suffixes to remove for better matching
    const stemmingRules = [
      { suffix: 'ing', replacement: '' },
      { suffix: 'ed', replacement: '' },
      { suffix: 'er', replacement: '' },
      { suffix: 'est', replacement: '' },
      { suffix: 'ly', replacement: '' },
      { suffix: 'ion', replacement: '' },
      { suffix: 'tion', replacement: '' },
      { suffix: 'ness', replacement: '' },
      { suffix: 'ment', replacement: '' },
      { suffix: 's', replacement: '' }, // Simple plurals
    ];

    for (const rule of stemmingRules) {
      if (lowerWord.endsWith(rule.suffix) &&
          lowerWord.length > rule.suffix.length + 2) { // Keep reasonable word length
        return word.slice(0, -(rule.suffix.length)) + rule.replacement;
      }
    }

    return word;
  }

  /**
   * Determine if a phrase contains technical indicators relevant to integration issues.
   * Checks for domain-specific keywords related to errors, APIs, databases, etc.
   *
   * @private
   * @param {string} phrase - The phrase to analyze for technical content
   * @returns {boolean} True if the phrase contains technical indicators
   */
  function isTechnicalPhrase(phrase) {
    const technicalIndicators = [
      'error', 'issue', 'problem', 'bug', 'fail', 'crash', 'timeout',
      'login', 'authentication', 'authorization', 'permission', 'access',
      'api', 'endpoint', 'request', 'response', 'server', 'client',
      'database', 'query', 'connection', 'sync', 'integration',
      'payment', 'billing', 'transaction', 'account', 'user',
      'course', 'assignment', 'grade', 'gradebook', 'canvas',
      'lti', 'tool', 'app', 'plugin', 'extension'
    ];

    return technicalIndicators.some(indicator =>
      phrase.toLowerCase().includes(indicator)
    );
  }

  /**
   * Atlassian Configuration Module
   * Centralized configuration for JIRA and Confluence integration
   * 
   * @module api/atlassian/shared/atlassian-config
   */


  const logger$e = createLogger('AtlassianConfig');

  /**
   * JIRA label mappings for common technical terms
   * Maps search terms to their variations in JIRA labels
   */
  const JIRA_LABEL_MAPPINGS = {
    // Technical terms
    'api': ['api', 'API', 'rest-api', 'api-issue'],
    'lti': ['lti', 'LTI', 'lti-tool', 'learning-tools'],
    'sso': ['sso', 'SSO', 'single-sign-on', 'authentication'],
    'oauth': ['oauth', 'OAuth', 'oauth2', 'authentication'],
    'saml': ['saml', 'SAML', 'saml2', 'authentication'],

    // Product areas
    'payment': ['payment', 'payments', 'billing', 'financial'],
    'grade': ['grade', 'grades', 'gradebook', 'grading'],
    'assignment': ['assignment', 'assignments', 'coursework'],
    'course': ['course', 'courses', 'curriculum'],
    'user': ['user', 'users', 'account', 'profile'],

    // Issue types
    'error': ['error', 'errors', 'bug', 'issue'],
    'crash': ['crash', 'crashes', 'failure', 'down'],
    'timeout': ['timeout', 'timeouts', 'slow', 'performance'],
    'login': ['login', 'signin', 'auth', 'access'],

    // Technical components
    'database': ['database', 'db', 'sql', 'data'],
    'server': ['server', 'backend', 'api', 'service'],
    'client': ['client', 'frontend', 'ui', 'browser'],
    'sync': ['sync', 'synchronization', 'integration', 'import'],
  };

  /**
   * Default Product Family to JIRA Project Key mappings.
   * @note These are fallback values. User overrides in storage are preferred.
   */
  const DEFAULT_JIRA_PROJECT_MAPPINGS = {
    'canvas': 'CNVS',
    'mastery': 'MCE',
    'credentials': 'MCE',
    'impact': 'IMP',
    'elevate': 'EAX',
    'learn platform': 'LRN',
  };

  /**
   * Default Product Family to Confluence Space mappings.
   * @note These are fallback values. User overrides in storage are preferred.
   */
  const DEFAULT_CONFLUENCE_SPACE_MAPPINGS = {
    'canvas': ['CANVAS3'],
    'mastery': ['AS', 'MASTERY'],
    'mastery connect': ['AS', 'MASTERY'],
    'credentials': ['AS', 'MASTERY'],
    'impact': ['IS', 'IP'],
    'elevate': ['COMP'],
    'learn platform': ['CS', 'LEARNPLATFORM', 'LP', 'LPE'],
    'learnplatform': ['CS', 'LEARNPLATFORM', 'LP', 'LPE'],
  };

  /**
   * Default Component-specific Confluence space mappings
   */
  const DEFAULT_CONFLUENCE_COMPONENT_MAPPINGS = {
    'mastery': ['AS'],
    'credential': ['AS'],
    'impact': ['IS'],
    'learn': ['CS'],
    'platform': ['CS'],
  };

  /**
   * Generate label variations for JIRA label matching
   * @param {string} term - Search term
   * @returns {string[]} Array of label variations
   */
  function generateLabelVariations(term) {
    const variations = new Set();
    const lowerTerm = term.toLowerCase();

    // Add the original term
    variations.add(term);
    variations.add(lowerTerm);

    // Add mapped variations
    if (JIRA_LABEL_MAPPINGS[lowerTerm]) {
      JIRA_LABEL_MAPPINGS[lowerTerm].forEach(variation => variations.add(variation));
    }

    // Add common formatting variations
    variations.add(lowerTerm.replace(/\s+/g, '-')); // Space to hyphen: "api error" -> "api-error"
    variations.add(lowerTerm.replace(/\s+/g, '_')); // Space to underscore: "api error" -> "api_error"

    return Array.from(variations);
  }

  /**
   * Map Salesforce Product Family to JIRA Project Key
   * @param {string} productFamily - Product family name
   * @param {string} fallbackProjectKey - Fallback project key if no mapping found
   * @returns {Promise<string|null>} JIRA project key
   */
  async function getJiraProjectFromProductFamily(productFamily, fallbackProjectKey = null) {
    if (!productFamily) {
      return fallbackProjectKey;
    }

    const productLower = productFamily.toLowerCase();

    try {
      const { jiraProjectMappingsOverride } = await chrome.storage.local.get('jiraProjectMappingsOverride');
      // Prioritize overrides over defaults
      const mappings = { ...DEFAULT_JIRA_PROJECT_MAPPINGS, ...jiraProjectMappingsOverride };

      // Check for exact matches
      if (mappings[productLower]) {
        return mappings[productLower];
      }

      // Check for partial matches
      for (const [product, projectId] of Object.entries(mappings)) {
        if (productLower.includes(product) || product.includes(productLower)) {
          return projectId;
        }
      }
    } catch (err) {
      logger$e.warn('Failed to load JIRA project mapping overrides', 'atlassian-config', err);
    }

    return fallbackProjectKey;
  }

  /**
   * Map product family to appropriate Confluence spaces
   * @param {string} productFamily - Product family name
   * @param {string} productComponent - Product component name (optional)
   * @returns {Promise<string[]>} Array of Confluence space IDs
   */
  async function getConfluenceSpacesFromProductFamily(productFamily, productComponent = null) {
    if (!productFamily) {
      return [];
    }

    const productLower = productFamily.toLowerCase();

    try {
      const { confluenceSpaceMappingsOverride, confluenceComponentMappingsOverride } =
        await chrome.storage.local.get(['confluenceSpaceMappingsOverride', 'confluenceComponentMappingsOverride']);

      // Prioritize overrides over defaults
      const spaceMappings = { ...DEFAULT_CONFLUENCE_SPACE_MAPPINGS, ...confluenceSpaceMappingsOverride };
      const componentMappings = { ...DEFAULT_CONFLUENCE_COMPONENT_MAPPINGS, ...confluenceComponentMappingsOverride };

      // Check for exact matches first
      if (spaceMappings[productLower]) {
        return spaceMappings[productLower];
      }

      // Check for partial matches
      for (const [product, spaceIds] of Object.entries(spaceMappings)) {
        if (productLower.includes(product) || product.includes(productLower)) {
          return spaceIds;
        }
      }

      // If we have a product component, try to map that as well
      if (productComponent) {
        const componentLower = productComponent.toLowerCase();

        for (const [component, spaceIds] of Object.entries(componentMappings)) {
          if (componentLower.includes(component)) {
            return spaceIds;
          }
        }
      }
    } catch (err) {
      logger$e.warn('Failed to load Confluence space mapping overrides', 'atlassian-config', err);
    }

    return []; // Return empty array to search all spaces
  }

  /**
   * JIRA Query Builder Module
   * Constructs JQL (JIRA Query Language) queries for ticket searches
   * 
   * @module api/atlassian/jira/jira-query-builder
   */


  /**
   * Build JQL query for JIRA ticket search
   * @param {string[]} searchTerms - Search terms extracted from case
   * @param {string|null} projectKey - JIRA project key to filter by
   * @returns {string} JQL query string
   */
  function buildJQLQuery(searchTerms, projectKey = null) {
    if (!searchTerms || searchTerms.length === 0) {
      // Even with no search terms, still filter by project if provided
      let baseJql = 'statusCategory IN ("To Do", "In Progress") AND type = Bug ORDER BY priority DESC, created DESC';
      if (projectKey) {
        baseJql = `project = "${escapeJQLString(projectKey)}" AND ${baseJql}`;
      }
      return baseJql;
    }

    // Build text search part - search in summary, description, comments, and labels
    const textSearches = searchTerms.map(term => {
      // Escape quotes in the term
      const escapedTerm = escapeJQLString(term);

      // For phrases (containing spaces), use exact phrase matching in text fields
      if (term.includes(' ')) {
        return `text ~ "${escapedTerm}"`;
      } else {
        // For single words, search in multiple fields including labels
        // Labels field uses exact matching, so we search both the term and common variations
        const labelVariations = generateLabelVariations(term);
        const labelSearches = labelVariations.map(variation => `labels = "${variation}"`).join(' OR ');

        return `(summary ~ "${escapedTerm}" OR description ~ "${escapedTerm}" OR comment ~ "${escapedTerm}" OR ${labelSearches})`;
      }
    });

    let jql = textSearches.join(' OR ');

    // Add project filter if specified - use exact project match for better filtering
    if (projectKey) {
      jql = `project = "${escapeJQLString(projectKey)}" AND (${jql})`;
    }

    // Add status filter - exclude Done items
    jql = `(${jql}) AND statusCategory IN ("To Do", "In Progress")`;

    // Add issue type filter - focus on Bugs only
    jql += ' AND type = Bug';

    // Exclude accessibility items
    jql += ' AND reporter != "712020:6b388ed8-8951-43c0-8ab4-73f5352c72a8" AND reporter != "Jira LevelAccess Service Account" AND reporter != "557058:f58131cb-b67d-43c7-b30d-6b58d40bd077"';

    // Only check customer facing tickets
    jql += ' AND "Customer Facing[Dropdown]"="Yes"';

    // Order by priority and recency
    jql += ' ORDER BY priority DESC, created DESC';

    return jql;
  }

  /**
   * Escape special characters in JQL query strings.
   * Standard JQL escaping: double-up backslashes first, then escape double quotes.
   * 
   * @param {string} text - Text to escape
   * @returns {string} Escaped text
   */
  function escapeJQLString(text) {
    if (!text) return '';
    return text
      .replace(/\\/g, '\\\\') // Escape backslashes first
      .replace(/"/g, '\\"');  // Then escape double quotes
  }

  /**
   * Network Utilities Module
   * Shared networking helpers including timeout-wrapped fetch.
   * 
   * @module utils/network-utils
   */


  const logger$d = createLogger('NetworkUtils');

  /**
   * Fetch with timeout helper.
   * Wraps the standard fetch API with a timeout to prevent hanging requests.
   * 
   * @param {string} url - The URL to fetch
   * @param {Object} [options={}] - Fetch options
   * @param {number} [timeout=30000] - Timeout in milliseconds (default: 30s)
   * @returns {Promise<Response>} The fetch response
   * @throws {Error} Throws AbortError on timeout or other fetch errors
   */
  async function fetchWithTimeout$1(url, options = {}, timeout = 30000) {
      const controller = new AbortController();

      // If the caller provided a signal, we need to respect it
      if (options.signal) {
          if (options.signal.aborted) {
              throw new DOMException('The operation was aborted.', 'AbortError');
          }
          options.signal.addEventListener('abort', () => controller.abort());
      }

      const id = setTimeout(() => controller.abort(), timeout);

      try {
          const fetchOptions = { ...options, signal: controller.signal };
          const resp = await fetch(url, fetchOptions);
          clearTimeout(id);
          return resp;
      } catch (err) {
          clearTimeout(id);
          if (err.name === 'AbortError') {
              // Differentiate between caller abort and timeout abort if possible, 
              // but generally timeout is the main reason we abort internally.
              // If we could check options.signal.aborted, we'd know if it was external.
              if (options.signal?.aborted) {
                  logger$d.debug('Request aborted by caller', 'fetchWithTimeout', { url });
                  throw err; // Re-throw original AbortError
              }

              logger$d.debug('Request timed out', 'fetchWithTimeout', { url, timeout });
              const abortErr = new Error('Request timed out');
              abortErr.name = 'AbortError';
              throw abortErr;
          }
          logger$d.warn('Fetch failed', 'fetchWithTimeout', { url, error: err.message });
          throw err;
      }
  }

  /**
   * JIRA Client Module
   * Handles JIRA API interactions and ticket retrieval.
   * Supports both traditional REST API searching and AI-enhanced searching.
   * 
   * @module api/atlassian/jira/jira-client
   */



  const logger$c = createLogger('JiraClient');


  /**
   * Traditional JIRA ticket search using JIRA REST API.
   * 
   * @param {string} caseId - Salesforce Case ID
   * @param {Object} [caseData={}] - Full case data object for context extraction
   * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
   * @returns {Promise<Result>} Standardized Result object containing an array of JIRA tickets on success
   */
  async function getJiraTicketsTraditional(caseId, caseData = {}, isManualFetch = false) {
    try {
      // First check if we have a JIRA token and base URL
      const { atlassianToken: encryptedToken, atlassianBaseUrl, atlassianEmail, jiraProjectKey, preloadSettings } = await chrome.storage.local.get(['atlassianToken', 'atlassianBaseUrl', 'atlassianEmail', 'jiraProjectKey', 'preloadSettings']);

      // Only check preload settings for automatic preload, not manual fetch
      if (!isManualFetch && preloadSettings?.jira === false) {
        return Result.success([]);
      }

      // If no JIRA token is configured, throw an error
      if (!encryptedToken) {
        return Result.failure(new Error('JIRA token not configured'));
      }

      // Decrypt the token
      const decryptResult = await decrypt(encryptedToken);
      if (!decryptResult.ok) {
        return Result.failure(decryptResult.error);
      }
      const atlassianToken = decryptResult.value;

      // Require Atlassian base URL to be configured
      if (!atlassianBaseUrl) {
        return Result.failure(new Error('Atlassian base URL not configured'));
      }

      // URL should already be normalized in settings, ensure no trailing slash
      const baseUrl = atlassianBaseUrl.replace(/\/$/, '');
      let searchTerms = [];
      let projectKey = null;

      // Use passed case data if available, otherwise try to extract from page
      let result = caseData;

      if (!result || Object.keys(result).length === 0) {
        // Fallback: try to extract from page if no case data passed
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
          try {
            const response = await chrome.tabs.sendMessage(tabs[0].id, { action: 'extractCaseData' });
            if (response && response.success) {
              result = response.data || {};
            } else {
              result = {};
            }
          } catch (scriptError) {
            logger$c.warn('Could not extract case data for JIRA search', 'jiraClient', scriptError);
            // Expected: May fail on non-case pages or during DOM mutations
            result = {};
          }
        }
      }

      if (result) {
        // Process subject into multiple search terms
        if (result.subject) {
          const subjectTerms = extractSearchTerms(result.subject);
          searchTerms.push(...subjectTerms);
        }

        // Add product component as a search term
        if (result.productComponent) {
          const componentTerms = extractSearchTerms(result.productComponent);
          searchTerms.push(...componentTerms);
        }

        // Add product component action as a search term
        if (result.productComponentAction) {
          const actionTerms = extractSearchTerms(result.productComponentAction);
          searchTerms.push(...actionTerms);
        }

        // Extract key terms from description
        if (result.description) {
          const cleanedDescription = cleanEmailContent(result.description);
          if (cleanedDescription) {
            const descriptionTerms = extractSearchTerms(cleanedDescription, 5);
            searchTerms.push(...descriptionTerms);
          }
        }

        // Determine project from product family dynamically
        if (result.productFamily || result.product) {
          const productFamily = result.productFamily || result.product;
          projectKey = await getJiraProjectFromProductFamily(productFamily, jiraProjectKey);
        } else if (jiraProjectKey) {
          projectKey = jiraProjectKey;
        }
      }

      // Fallback search terms
      if (searchTerms.length === 0) {
        searchTerms = ['payment', 'issue', 'problem', 'error'];
      }

      searchTerms = [...new Set(searchTerms)].filter(term =>
        term.length > 2 && !['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'].includes(term.toLowerCase())
      );

      if (!searchTerms.length) {
        logger$c.info('No search terms available for JIRA search, returning empty results', 'jira-client');
        return Result.success([]);
      }

      const jql = buildJQLQuery(searchTerms, projectKey);
      const apiUrl = `${baseUrl}/rest/api/3/search/jql`;

      const authHeaders = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      };

      if (atlassianEmail && atlassianToken) {
        authHeaders['Authorization'] = `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`;
      } else {
        return Result.failure(new Error('Atlassian email and token are required for Basic Authentication.'));
      }

      const response = await rateLimiters.atlassian.executeWithBackoff(
        async () => {
          return await fetchWithTimeout$1(apiUrl, {
            method: 'POST',
            headers: authHeaders,
            body: JSON.stringify({
              jql: jql,
              maxResults: 10,
              fields: ['summary', 'status', 'priority', 'assignee', 'created', 'updated', 'issuetype', 'project', 'description']
            })
          });
        },
        `jira-search-${baseUrl}`
      );

      if (!response.ok) {
        const errorText = await response.text();
        const error = new Error(`JIRA API request failed: ${errorText}`);
        error.status = response.status;
        error.endpoint = apiUrl;
        throw error;
      }

      const data = await response.json();
      const issues = data.issues || [];

      const tickets = issues.map(issue => ({
        id: issue.id,
        key: issue.key,
        summary: issue.fields.summary,
        description: issue.fields.description,
        status: issue.fields.status?.name || 'Unknown',
        priority: issue.fields.priority?.name || 'Unassigned',
        url: `${baseUrl}/browse/${issue.key}`,
        created: issue.fields.created,
        updated: issue.fields.updated,
        assignee: issue.fields.assignee?.displayName || 'Unassigned',
        avatarUrl: issue.fields.assignee?.avatarUrls?.['48x48']
      }));

      return Result.success(tickets);
    } catch (error) {
      logger$c.error('Error fetching JIRA tickets', 'jiraClient', error);
      return Result.failure(error);
    }
  }

  /**
   * AI-enhanced JIRA ticket search with relevance scoring.
   * 
   * @param {string} caseId - Salesforce Case ID
   * @param {Object} [caseData={}] - Full case data object for prompt context
   * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
   * @returns {Promise<Result>} Standardized Result object containing an array of AI-ranked JIRA tickets on success
   */
  async function getJiraTicketsWithAI(caseId, caseData = {}, isManualFetch = false) {
    let traditionalResults = [];
    try {
      logger$c.debug('Starting AI enhancement function...', 'jiraClient');

      // First get traditional results
      const traditionalRes = await getJiraTicketsTraditional(caseId, caseData, isManualFetch);
      if (!traditionalRes.ok) return traditionalRes;

      traditionalResults = traditionalRes.value;

      if (traditionalResults.length === 0) {
        return Result.success([]);
      }

      // Check for API token
      const { aiServiceToken: encryptedAiToken } = await chrome.storage.local.get('aiServiceToken');
      if (!encryptedAiToken) {
        logger$c.warn('No AI token found. Returning traditional results with fallback explanations.', 'jiraClient');
        return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
      }

      // Get minimum relevance threshold
      const { preloadSettings: preloadSettingsForPrompt } = await chrome.storage.local.get('preloadSettings');
      const minJiraScoreForPrompt = preloadSettingsForPrompt?.jiraMinScore ?? 80;

      // Use AI to analyze and re-rank
      const aiAnalysisPrompt = buildJiraAnalysisPrompt(
        {
          ...caseData,
          description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
        },
        traditionalResults,
        minJiraScoreForPrompt
      );

      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
      const model = await getActiveAiModel();
      const temperature = advancedAiSettings?.contextSettings?.jira?.temperature ?? 0.25;
      const topP = advancedAiSettings?.contextSettings?.jira?.topP ?? 0.85;
      const topK = advancedAiSettings?.contextSettings?.jira?.topK ?? 35;

      const aiMutation = buildAiAnalysisMutation('AnalyzeJiraRelevance');

      const variables = {
        model: model,
        prompt: aiAnalysisPrompt,
        temperature,
        topP,
        topK
      };

      logger$c.debug('Making Jira AI re-ranking request...', 'jiraClient');
      const response = await makeApiRequest(aiMutation, variables);
      if (!response.ok) {
        logger$c.warn('AI analysis failed, falling back to traditional results', 'jiraClient', { error: response.error });
        return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
      }
      const aiResponse = response.value.data.answerPrompt;

      const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

      if (!parseResult.isValid || !parseResult.data) {
        logger$c.warn('Could not parse AI response, using fallbacks', 'jiraClient', { error: parseResult.error });
        return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
      }

      const aiAnalysis = parseResult.data;

      if (!aiAnalysis.rankedTickets || !Array.isArray(aiAnalysis.rankedTickets)) {
        // Compatibility check
        if (aiAnalysis.rankedArticles && Array.isArray(aiAnalysis.rankedArticles)) {
          aiAnalysis.rankedTickets = aiAnalysis.rankedArticles.map(article => ({
            ticketIndex: article.articleIndex,
            relevanceScore: article.relevanceScore,
            explanation: article.explanation
          }));
        } else {
          return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
        }
      }

      const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
      const minJiraScore = preloadSettings?.jiraMinScore ?? 80;

      const enhancedTickets = aiAnalysis.rankedTickets
        .filter(ranking => {
          const isValidIndex = ranking.ticketIndex >= 0 && ranking.ticketIndex < traditionalResults.length;
          return isValidIndex && ranking.relevanceScore >= minJiraScore;
        })
        .sort((a, b) => b.relevanceScore - a.relevanceScore)
        .slice(0, 5)
        .map(ranking => {
          const originalTicket = traditionalResults[ranking.ticketIndex];
          return {
            ...originalTicket,
            aiRelevanceScore: ranking.relevanceScore,
            aiExplanation: ranking.explanation || buildFallbackJiraExplanation(originalTicket, caseData),
            aiFallback: !ranking.explanation
          };
        });

      return Result.success(enhancedTickets);
    } catch (error) {
      logger$c.error('Error in AI analysis', 'jiraClient', error);

      // Fallback: If AI fails but we have traditional results, return those with fallback explanations
      // instead of failing the entire request.
      try {
        // Re-fetch traditional results if they weren't captured (though they should be in the outer scope)
        // but the safest way is to ensure traditionalResults is available.
        // Since we need traditionalResults, let's make sure it's scoped correctly.
        if (typeof traditionalResults !== 'undefined' && traditionalResults && traditionalResults.length > 0) {
          logger$c.info('Returning traditional Jira results with fallbacks after AI failure', 'jiraClient');
          return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
        }
      } catch (fallbackError) {
        logger$c.error('Failed to provide fallback results', 'jiraClient', fallbackError);
      }

      return Result.failure(error);
    }
  }

  /**
   * Confluence Query Builder Module
   * Constructs CQL (Confluence Query Language) queries for page searches
   * 
   * @module api/atlassian/confluence/confluence-query-builder
   */


  const logger$b = createLogger('ConfluenceQueryBuilder');

  /**
   * Build Confluence CQL (Confluence Query Language) query
   * @param {string[]} searchTerms - Search terms extracted from case
   * @param {Object} caseData - Salesforce case data
   * @param {string[]} targetSpaces - Confluence space IDs to search in
   * @returns {string} CQL query string
   */
  function buildConfluenceCQLQuery(searchTerms, caseData = {}, targetSpaces = []) {
    const query = [];

    // Build a prioritized term list: description -> subject -> component -> action -> caller-provided
    const prioritizedTerms = [];
    const seen = new Set();
    const addTerms = (terms = []) => {
      terms.forEach(term => {
        const clean = (term || '').trim();
        if (!clean || clean.length < 3) return;
        const key = clean.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        prioritizedTerms.push(clean);
      });
    };

    // Description often contains the specific symptom; allow more terms here
    if (caseData.description) {
      addTerms(extractSearchTerms(cleanEmailContent(caseData.description), 8));
    }
    if (caseData.subject) {
      addTerms(extractSearchTerms(caseData.subject, 6));
    }
    if (caseData.productComponent) {
      addTerms(extractSearchTerms(caseData.productComponent, 4));
    }
    if (caseData.productComponentAction) {
      addTerms(extractSearchTerms(caseData.productComponentAction, 3));
    }
    addTerms(searchTerms || []);

    // Text search across title and content - include up to 6 distinct terms for better recall
    if (prioritizedTerms.length > 0) {
      const textSearch = prioritizedTerms
        .slice(0, 6)
        .map(term => 'text ~ "' + escapeCQLString(term) + '"')
        .join(' OR ');

      if (textSearch) {
        query.push('(' + textSearch + ')');
      }
    }

    // Focus on pages (not comments, attachments, etc.)
    query.push('type = page');

    // Add space filtering if target spaces are specified
    if (targetSpaces && targetSpaces.length > 0) {
      logger$b.info('Confluence CQL: Adding space filter for spaces:', 'confluence-query-builder', targetSpaces);
      // Use simple space key filtering
      const spaceFilter = targetSpaces
        .map(spaceKey => `space.key = "${escapeCQLString(spaceKey)}"`)
        .join(' OR ');
      query.push('(' + spaceFilter + ')');
      logger$b.info('Confluence CQL: Space filter:', 'confluence-query-builder', spaceFilter);
    } else {
      logger$b.info('Confluence CQL: No space filter applied - searching all spaces', 'confluence-query-builder', undefined);
    }

    // Build the final CQL query
    let cql = query.join(' AND ');

    // If no search terms, use a broader query
    if (prioritizedTerms.length === 0) {
      cql = 'type = page';
      if (targetSpaces && targetSpaces.length > 0) {
        const spaceFilter = targetSpaces
          .map(spaceKey => `space.key = "${escapeCQLString(spaceKey)}"`)
          .join(' OR ');
        cql += ' AND (' + spaceFilter + ')';
        logger$b.info('Confluence CQL: No search terms, using space filter only:', 'confluence-query-builder', spaceFilter);
      }
    }

    // Order by relevance and last modified
    cql += ' ORDER BY lastModified DESC';

    return cql;
  }

  /**
   * Escape special characters in CQL query strings.
   * Standard JQL/CQL escaping: double-up backslashes first, then escape double quotes.
   * 
   * @param {string} text - Text to escape
   * @returns {string} Escaped text
   */
  function escapeCQLString(text) {
    if (!text) return '';
    return text
      .replace(/\\/g, '\\\\') // Escape backslashes first
      .replace(/"/g, '\\"');  // Then escape double quotes
  }

  /**
   * Confluence Client Module
   * Handles Confluence API interactions and article retrieval.
   * Provides both traditional CQL-based searching and AI-enhanced searching.
   * 
   * @module api/atlassian/confluence/confluence-client
   */



  const logger$a = createLogger('ConfluenceClient');


  /**
   * Traditional Confluence articles search using Confluence REST API.
   * 
   * @param {Object} [caseData={}] - Full case data object for context extraction
   * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
   * @returns {Promise<Result>} Standardized Result object containing an array of Confluence pages on success
   */
  async function getConfluencePagesTraditional(caseData = {}, isManualFetch = false) {
    try {
      // First check if we have a JIRA token and base URL (Confluence uses same credentials)
      const { atlassianToken: encryptedToken, atlassianBaseUrl, atlassianEmail, preloadSettings } = await chrome.storage.local.get(['atlassianToken', 'atlassianBaseUrl', 'atlassianEmail', 'preloadSettings']);

      // Only check preload settings for automatic preload, not manual fetch
      if (!isManualFetch && preloadSettings?.confluence === false) {
        return Result.success([]);
      }

      // If no Atlassian token is configured, return failure
      if (!encryptedToken) {
        return Result.failure(new Error('Atlassian token not configured'));
      }

      // Decrypt the token
      const decryptResult = await decrypt(encryptedToken);
      if (!decryptResult.ok) {
        return Result.failure(decryptResult.error);
      }
      const atlassianToken = decryptResult.value;

      // Require Atlassian base URL to be configured
      if (!atlassianBaseUrl) {
        return Result.failure(new Error('Atlassian base URL not configured'));
      }

      // URL should already be normalized in settings, ensure no trailing slash
      const baseUrl = atlassianBaseUrl.replace(/\/$/, '');
      const result = caseData || {};
      let searchTerms = [];

      if (result) {
        // Process subject into multiple search terms
        if (result.subject) {
          const subjectTerms = extractSearchTerms(result.subject);
          searchTerms.push(...subjectTerms);
        }

        // Add product as a search term
        if (result.product) {
          const productTerms = extractSearchTerms(result.product);
          searchTerms.push(...productTerms);
        }

        // Add product component as a search term
        if (result.productComponent) {
          const componentTerms = extractSearchTerms(result.productComponent);
          searchTerms.push(...componentTerms);
        }

        // Extract key terms from description
        if (result.description) {
          const cleanedDescription = cleanEmailContent(result.description);
          if (cleanedDescription) {
            const descriptionTerms = extractSearchTerms(cleanedDescription, 5);
            searchTerms.push(...descriptionTerms);
          }
        }
      }

      // Fallback search terms
      if (searchTerms.length === 0) {
        searchTerms = ['documentation', 'guide', 'how-to', 'setup'];
      }

      // Remove duplicates and filter out common words
      searchTerms = [...new Set(searchTerms)].filter(term =>
        term.length > 2 && !['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'].includes(term.toLowerCase())
      );

      // Determine target spaces
      let targetSpaces = [];
      if (result.productFamily || result.product) {
        const productFamily = result.productFamily || result.product;
        targetSpaces = await getConfluenceSpacesFromProductFamily(productFamily, result.productComponent);
      }

      // Build queries
      const cqlQuery = buildConfluenceCQLQuery(searchTerms, result, targetSpaces);

      // Harden fallback: Ensure searchTerms[0] is not undefined
      if (!searchTerms.length) {
        logger$a.info('No search terms available for Confluence search, returning empty results', 'confluence-client');
        return Result.success([]);
      }

      const fallbackTerm = searchTerms[0];
      const fallbackQuery = `type=page AND text ~ "${fallbackTerm}" ORDER BY lastmodified DESC`;

      const searchUrl = `${baseUrl}/wiki/rest/api/search?cql=${encodeURIComponent(cqlQuery)}&limit=10&expand=content.space,content.version`;

      let response;
      const authHeader = `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`;

      if (!atlassianEmail || !atlassianToken) {
        return Result.failure(new Error('Atlassian email and token are required for Basic Authentication.'));
      }

      // Attempt primary search
      try {
        response = await rateLimiters.atlassian.executeWithBackoff(
          async () => {
            return await fetchWithTimeout$1(searchUrl, {
              method: 'GET',
              headers: {
                'Accept': 'application/json',
                'Authorization': authHeader,
                'Content-Type': 'application/json'
              }
            }, 20000);
          },
          `confluence-search-${baseUrl}`
        );
      } catch (fetchError) {
        logger$a.warn('Confluence primary search fetch failed', 'confluence-client', fetchError);
        // Will attempt fallback below
      }

      // Attempt fallback search if primary failed
      if (!response || !response.ok) {
        logger$a.warn('Confluence: primary search failing, trying fallback...', 'confluence-client');
        try {
          const fallbackUrl = `${baseUrl}/wiki/rest/api/search?cql=${encodeURIComponent(fallbackQuery)}&limit=5&expand=content.space,content.version`;
          response = await rateLimiters.atlassian.executeWithBackoff(
            async () => {
              return await fetchWithTimeout$1(fallbackUrl, {
                method: 'GET',
                headers: {
                  'Accept': 'application/json',
                  'Authorization': authHeader,
                  'Content-Type': 'application/json'
                }
              }, 20000);
            },
            `confluence-fallback-${baseUrl}`
          );
        } catch (fallbackError) {
          logger$a.error('Confluence fallback search failed', 'confluence-client', fallbackError);
        }
      }

      if (!response || !response.ok) {
        const error = new Error(`Confluence API request failed with status: ${response ? response.status : 'unknown'}`);
        if (response) error.status = response.status;
        return Result.failure(error);
      }

      const data = await response.json();
      const confluenceResults = data.results || [];

      const pages = confluenceResults.map(item => {
        const content = item.content || item;
        return {
          id: content.id,
          title: content.title,
          url: baseUrl + '/wiki' + (content._links ? (content._links.webui || content._links.tinyui || '') : ''),
          space: content.space?.name || 'Unknown Space',
          spaceKey: content.space?.key || 'Unknown',
          lastModified: content.version?.when || item.lastModified,
          lastModifiedBy: content.version?.by?.displayName || 'Unknown',
          excerpt: item.excerpt || content.excerpt || '',
          type: content.type || 'page',
          aiRelevanceScore: null,
          aiExplanation: null
        };
      });

      return Result.success(pages);
    } catch (error) {
      logger$a.error('Error in getConfluencePagesTraditional', 'confluence-client', error);
      return Result.failure(error);
    }
  }

  /**
   * AI-enhanced Confluence page search with relevance scoring.
   * 
   * @param {Object} [caseData={}] - Full case data object for prompt context
   * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
   * @returns {Promise<Result>} Standardized Result object containing an array of AI-ranked Confluence pages on success
   */
  async function getConfluencePagesWithAI(caseData = {}, isManualFetch = false) {
    let traditionalResults = [];
    try {
      logger$a.debug('Starting Confluence AI enhancement...', 'confluence-client');

      const traditionalRes = await getConfluencePagesTraditional(caseData, isManualFetch);
      if (!traditionalRes.ok) return traditionalRes;

      traditionalResults = traditionalRes.value;

      if (traditionalResults.length === 0) {
        return Result.success([]);
      }

      // Check for API token
      const { aiServiceToken: encryptedAiToken } = await chrome.storage.local.get('aiServiceToken');
      if (!encryptedAiToken) {
        logger$a.warn('No AI token found for Confluence re-ranking', 'confluence-client');
        return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
      }

      const { preloadSettings: preloadSettingsForPrompt } = await chrome.storage.local.get('preloadSettings');
      const minConfluenceScoreForPrompt = preloadSettingsForPrompt?.confluenceMinScore ?? 75;

      // Use AI to re-rank the results
      const aiAnalysisPrompt = buildConfluenceAnalysisPrompt(
        {
          ...caseData,
          description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
        },
        traditionalResults,
        minConfluenceScoreForPrompt
      );

      // Get advanced AI settings
      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
      const model = await getActiveAiModel();
      const temperature = advancedAiSettings?.contextSettings?.confluence?.temperature ?? 0.4;
      const topP = advancedAiSettings?.contextSettings?.confluence?.topP ?? 0.9;
      const topK = advancedAiSettings?.contextSettings?.confluence?.topK ?? 50;

      const aiMutation = buildAiAnalysisMutation('AnalyzeConfluenceRelevance');

      const variables = { model, prompt: aiAnalysisPrompt, temperature, topP, topK };

      logger$a.debug('Making Confluence AI re-ranking request...', 'confluence-client');
      const response = await makeApiRequest(aiMutation, variables);
      if (!response.ok) {
        logger$a.warn('AI Confluence analysis failed, falling back to traditional results', 'confluence-client', { error: response.error });
        return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
      }
      const aiResponse = response.value.data.answerPrompt;

      const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

      if (!parseResult.isValid || !parseResult.data) {
        logger$a.warn('Could not parse Confluence AI response, using fallbacks', 'confluence-client', { error: parseResult.error });
        return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
      }

      const aiAnalysis = parseResult.data;

      if (!aiAnalysis.rankedArticles || !Array.isArray(aiAnalysis.rankedArticles)) {
        return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
      }

      const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
      const minConfluenceScore = preloadSettings?.confluenceMinScore ?? 75;

      const enhancedArticles = aiAnalysis.rankedArticles
        .filter(ranking => {
          const isValidIndex = ranking.articleIndex >= 0 && ranking.articleIndex < traditionalResults.length;
          return isValidIndex && ranking.relevanceScore >= minConfluenceScore;
        })
        .sort((a, b) => b.relevanceScore - a.relevanceScore)
        .slice(0, 5)
        .map(ranking => {
          const originalArticle = traditionalResults[ranking.articleIndex];
          return {
            ...originalArticle,
            aiRelevanceScore: ranking.relevanceScore,
            aiExplanation: ranking.explanation || buildFallbackConfluenceExplanation(originalArticle, caseData),
            aiFallback: !ranking.explanation
          };
        });

      return Result.success(enhancedArticles);
    } catch (error) {
      logger$a.error('Error in AI Confluence analysis', 'confluence-client', error);

      // Fallback: If AI fails but we have traditional results, return those with fallback explanations
      try {
        if (traditionalResults && traditionalResults.length > 0) {
          logger$a.info('Returning traditional Confluence results with fallbacks after AI failure', 'confluence-client');
          return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
        }
      } catch (fallbackError) {
        logger$a.error('Failed to provide fallback results for Confluence', 'confluence-client', fallbackError);
      }

      return Result.failure(error);
    }
  }

  /**
   * Atlassian Service Module
   * Orchestrates JIRA and Confluence API interactions
   */


  const logger$9 = createLogger('AtlassianService');

  async function fetchWithTimeout(url, options = {}, timeout = ATLASSIAN_TIMEOUT_MS) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const resp = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(id);
      return resp;
    } catch (err) {
      clearTimeout(id);
      if (err.name === 'AbortError') {
        logger$9.debug('Atlassian request timed out', 'fetchWithTimeout', err);
        const abortErr = new Error('Request timed out');
        abortErr.name = 'AbortError';
        throw abortErr;
      }
      logger$9.warn('Atlassian fetch failed', 'fetchWithTimeout', err);
      throw err;
    }
  }

  /**
   * Test connection to Atlassian (JIRA/Confluence)
   */
  async function testAtlassianConnection(atlassianToken, atlassianBaseUrl, atlassianEmail) {
    if (!atlassianToken) {
      const error = new Error('Atlassian token is required');
      error.details = { timestamp: new Date().toISOString() };
      return Result.failure(error);
    }

    if (!atlassianBaseUrl) {
      const error = new Error('Atlassian base URL is required');
      error.details = { timestamp: new Date().toISOString() };
      return Result.failure(error);
    }

    if (!atlassianEmail) {
      const error = new Error('Atlassian email is required for Basic Authentication');
      error.details = { timestamp: new Date().toISOString() };
      return Result.failure(error);
    }

    // URL should already be normalized from settings, but validate for safety
    const baseUrlValidation = validateAtlassianUrl(atlassianBaseUrl);
    if (!baseUrlValidation.valid) {
      const error = new Error(baseUrlValidation.error || 'Invalid Atlassian URL');
      error.details = { timestamp: new Date().toISOString() };
      return Result.failure(error);
    }
    const normalizedBaseUrl = baseUrlValidation.normalized;
    const testUrl = `${normalizedBaseUrl}/rest/api/3/myself`;
    let lastError = null;

    const authMethod = { type: 'Basic', header: `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`, description: 'Basic auth (API token as password)' };

    try {
      const startTime = performance.now();
      const response = await rateLimiters.atlassian.executeWithBackoff(
        async () => {
          return await fetchWithTimeout(testUrl, {
            method: 'GET',
            headers: {
              'Authorization': authMethod.header,
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            }
          }, ATLASSIAN_TIMEOUT_MS);
        },
        `atlassian-test-${atlassianBaseUrl}-${authMethod.type}`
      );

      if (response.ok) {
        const responseTime = Math.round(performance.now() - startTime);
        const userData = await response.json();

        return Result.success({
          user: userData.displayName || userData.name || 'Unknown User',
          email: userData.emailAddress || 'Not available',
          status: 'Connected',
          authMethod: authMethod.type,
          responseTime: `${responseTime}ms`,
          instance: atlassianBaseUrl,
          timestamp: new Date().toISOString()
        });
      } else {
        lastError = new Error(`HTTP ${response.status}: ${response.statusText} (${authMethod.type} auth)`);
        lastError.status = response.status;
      }
    } catch (error) {
      logger$9.warn('Atlassian connection attempt failed', 'testAtlassianConnection', error);
      lastError = error;
    }

    if (lastError) {
      if (lastError.status === 401 || lastError.status === 403) {
        handleError(lastError, {
          strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
          context: 'Atlassian Connection Test',
          operation: 'testAtlassianConnection',
          userMessage: ErrorMessages.API_AUTH_FAILED
        });
      } else if (lastError.name !== 'AbortError') {
        handleError(lastError, {
          strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
          context: 'Atlassian Connection Test',
          operation: 'testAtlassianConnection'
        });
      }
    }

    return Result.failure(
      lastError || new Error('Failed to connect to Atlassian')
    );
  }

  /**
   * Search for related Jira tickets using direct JIRA REST API
   * Orchestrates between AI-enhanced and traditional search
   * 
   * @param {string} caseId - Salesforce Case ID
   * @param {Object} caseData - Case context
   * @param {boolean} isManualFetch - Whether this was user-triggered
   * @param {AbortSignal} [signal] - Optional abort signal for cancellation
   */
  async function getJiraTickets(caseId, caseData = {}, isManualFetch = false, signal = null) {
    return orchestratedSearch({
      serviceName: 'JIRA',
      settingKey: 'jira',
      // Signal is passed by orchestrator to these functions
      aiSearchFn: (sig) => getJiraTicketsWithAI(caseId, caseData, isManualFetch),
      traditionalSearchFn: (sig) => getJiraTicketsTraditional(caseId, caseData, isManualFetch),
      fallbackEnhancer: addFallbackJiraExplanations,
      caseData,
      isManualFetch,
      signal
    });
  }

  /**
   * Get Confluence pages related to case
   * Orchestrates between AI-enhanced and traditional search
   * 
   * @param {Object} caseData - Case context
   * @param {boolean} isManualFetch - Whether this was user-triggered
   * @param {AbortSignal} [signal] - Optional abort signal for cancellation
   */
  async function getConfluencePages(caseData = {}, isManualFetch = false, signal = null) {
    return orchestratedSearch({
      serviceName: 'Confluence',
      settingKey: 'confluence',
      // Signal is passed by orchestrator to these functions
      aiSearchFn: (sig) => getConfluencePagesWithAI(caseData, isManualFetch),
      traditionalSearchFn: (sig) => getConfluencePagesTraditional(caseData, isManualFetch),
      fallbackEnhancer: addFallbackConfluenceExplanations,
      caseData,
      isManualFetch,
      signal
    });
  }

  /**
   * AI Related Message Handlers
   */

  const logger$8 = createLogger('AiHandlers');

  /**
   * Handle standardized Promise settlement for orchestrator
   */
  function handleSettledPromise(result, context) {
      if (result.status === 'fulfilled') {
          return result.value;
      } else {
          const error = result.reason;
          const message = error instanceof Error ? error.message : String(error || 'Unknown error');
          logger$8.error('Promise settlement failed', context, error);
          return {
              error: {
                  message: message,
                  type: error?.constructor?.name || 'Unknown',
                  stack: error?.stack,
                  details: {
                      context,
                      timestamp: new Date().toISOString()
                  }
              },
              status: 'failed'
          };
      }
  }

  /**
   * Get AI analysis for the case (Helper)
   */
  async function getAIAnalysis(caseData) {
      // Get advanced AI settings
      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');

      const model = await getActiveAiModel();
      const temperature = advancedAiSettings?.contextSettings?.caseSummary?.temperature ?? 0.7;
      const topP = advancedAiSettings?.contextSettings?.caseSummary?.topP ?? 0.95;
      const topK = advancedAiSettings?.contextSettings?.caseSummary?.topK ?? 40;

      // Create a detailed prompt for case analysis
      const prompt = 'Analyze this Salesforce support case and provide a structured response:\n\n' +
          'Case ID: ' + (caseData.caseId || 'N/A') + '\n' +
          'Subject: ' + (caseData.subject || 'N/A') + '\n' +
          'Product: ' + (caseData.productFamily || 'N/A') + '\n' +
          'Component: ' + (caseData.productComponent || 'N/A') + '\n' +
          'Description: ' + (caseData.description ? cleanEmailContent(caseData.description) : 'N/A') + '\n' +
          'Please provide:\n' +
          '1. A brief summary of the issue\n' +
          '2. 2-3 suggested solutions\n' +
          '3. A confidence score (0-1) for your analysis\n' +
          '4. Whether knowledge base search would be helpful (true/false)\n' +
          '5. Key terms related to this case\n\n' +
          'Format your response as JSON with these fields:\n' +
          '- summary: string\n' +
          '- suggestedSolutions: array of strings\n' +
          '- confidenceScore: number (0-1)\n' +
          '- suggestKnowledgeBase: boolean\n' +
          '- relatedTerms: array of strings';

      const mutation =
          'mutation AnalyzeCase($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) {' +
          '  answerPrompt(input: {' +
          '    model: $model' +
          '    prompt: $prompt' +
          '    temperature: $temperature' +
          '    topP: $topP' +
          '    topK: $topK' +
          '  })' +
          '}';

      const variables = {
          model: model,
          prompt: prompt,
          temperature: temperature,
          topP: topP,
          topK: topK
      };

      const response = await makeApiRequest(mutation, variables);

      // Parse the AI response and structure it
      const aiResponse = response.data.answerPrompt;

      // Parse response using centralized JSON parser with fallback
      const parseResult = parseJSON(aiResponse, {
          fallback: {
              summary: aiResponse.substring(0, 200) + '...',
              suggestedSolutions: [aiResponse],
              confidenceScore: 0.0,  // Indicate low confidence for fallback
              suggestKnowledgeBase: true,
              relatedTerms: []
          },
          removeMarkdown: true
      });

      // Check if parsing was successful or we're using a fallback
      if (!parseResult.isValid) {
          logger$8.warn('AI response invalid JSON, using fallback', 'ai-handlers', {
              error: parseResult.error,
              sample: aiResponse.substring(0, 100)
          });
          try {
              showInfo('AI returned unstructured text; parsed content may be approximate.');
          } catch (e) {
              logger$8.debug('Failed to show notification', 'ai-handlers', e);
          }
      }

      const parsedResponse = parseResult.data;

      return {
          summary: parsedResponse.summary ?? 'No summary provided',
          suggestedSolutions: parsedResponse.suggestedSolutions ?? ['No solutions suggested'],
          confidenceScore: parsedResponse.confidenceScore ?? 0.5,
          suggestKnowledgeBase: parsedResponse.suggestKnowledgeBase ?? true,
          relatedTerms: parsedResponse.relatedTerms ?? []
      };
  }

  /**
   * Main function to analyze case data with enhanced error handling
   * All API calls are queued to prevent overwhelming external services
   */
  async function analyzeCase(caseData) {
      try {
          if (!caseData || !caseData.caseId) {
              throw new Error('Invalid case data: Missing caseId');
          }

          // Run API calls in parallel with timeout and rate limiting
          const [aiAnalysis, jiraTickets] = await Promise.allSettled([
              queueRequest(() => withTimeout(() => getAIAnalysis(caseData), AI_ANALYSIS_TIMEOUT_MS, 'AI Analysis timed out'), 'ai-analysis'),
              queueRequest(() => withTimeout(() => getJiraTickets(caseData.caseId), JIRA_TICKETS_TIMEOUT_MS, 'Jira tickets fetch timed out'), 'jira-tickets')
          ]);

          // Handle settled promises
          const results = {
              aiAnalysis: handleSettledPromise(aiAnalysis, 'AI Analysis'),
              jiraTickets: handleSettledPromise(jiraTickets, 'Jira Tickets')
          };

          // Only fetch knowledge base if AI analysis was successful and suggests it
          if (results.aiAnalysis?.suggestKnowledgeBase) {
              try {
                  results.knowledgeBase = await queueRequest(
                      () => withTimeout(
                          async () => {
                              const res = await searchCommunityGuides(caseData);
                              // Unwrap Result object
                              if (res && typeof res.ok === 'boolean') {
                                  if (res.ok) return res.value;
                                  throw res.error;
                              }
                              return res; // Fallback for legacy behavior
                          },
                          KNOWLEDGE_BASE_TIMEOUT_MS,
                          'Knowledge base search timed out'
                      ),
                      'kb-search'
                  );
              } catch (error) {
                  logger$8.error('Knowledge base search failed', 'analyzeHandler', error);
                  handleError(error, {
                      strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                      context: 'Knowledge Base',
                      operation: 'searchCommunityGuides',
                      userMessage: 'Unable to fetch knowledge base articles. Please try again.'
                  });
                  results.knowledgeBase = {
                      error: error.message,
                      status: 'failed'
                  };
              }
          }

          return Result.success(results);
      } catch (error) {
          logger$8.error('Error in analyzeCase', 'analyzeHandler', {
              error: error.message,
              stack: error.stack,
              caseId: caseData?.caseId,
              timestamp: new Date().toISOString()
          });
          handleError(error, {
              strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
              context: 'Case Analysis',
              operation: 'analyzeCase',
              userMessage: 'Case analysis failed. Please check your connection and try again.'
          });
          return Result.failure(error);
      }
  }

  async function handleAnalyzeCaseRequest(request) {
      return await analyzeCase(request?.data);
  }

  async function handleImproveSolutionRequest(request) {
      return await improveSolution(request.currentSolution, request.caseData);
  }

  async function handleSpellcheckRequest(request) {
      return await spellcheckText(request.text, request.caseData);
  }

  /**
   * Atlassian (JIRA/Confluence) Message Handlers
   */

  const logger$7 = createLogger('AtlassianHandlers');

  async function handleTestAtlassianConnectionRequest(request) {
      logger$7.debug('Received Atlassian connection test request', 'connectionHandler', { host: request.atlassianBaseUrl });
      return await testAtlassianConnection(request.atlassianToken, request.atlassianBaseUrl, request.atlassianEmail);
  }

  /**
   * Handles requests for FETCH_JIRA_TICKETS.
   */
  async function handleGetJiraTicketsRequest(request) {
      logger$7.debug('Received JIRA work items request', 'jiraHandler', request);
      if (!request.caseData || typeof request.caseData !== 'object') {
          throw new Error('Invalid case data provided for JIRA search');
      }

      const isManualFetch = Boolean(request.isManualFetch);
      const result = await getJiraTickets(request.caseId || '', request.caseData, isManualFetch);

      if (result.ok) {
          logger$7.debug('JIRA response prepared', 'jiraHandler', { count: result.value.length });
          result.value.forEach((ticket, index) => {
              logger$7.debug(`JIRA ${ticket.key}`, 'jiraHandler', { index, aiScore: ticket.aiRelevanceScore, hasExplanation: !!ticket.aiExplanation });
          });
      } else {
          logger$7.error('JIRA ticket search failed', 'jiraHandler', result.error);
      }

      return result;
  }

  /**
   * Handles requests for FETCH_CONFLUENCE_PAGES.
   */
  async function handleGetConfluencePagesRequest(request) {
      logger$7.debug('Received Confluence pages request', 'confluenceHandler', request);
      if (!request.caseData || typeof request.caseData !== 'object') {
          throw new Error('Invalid case data provided for Confluence search');
      }

      const isManualFetch = Boolean(request.isManualFetch);
      const result = await getConfluencePages(request.caseData, isManualFetch);

      if (!result.ok) {
          logger$7.error('Confluence page search failed', 'confluenceHandler', result.error);
          return result;
      }

      const pages = result.value.map(a => {
          const score = (typeof a.aiRelevanceScore === 'number') ? a.aiRelevanceScore : (typeof a.score === 'number' ? a.score : null);
          const explanation = a.aiExplanation || a.explanation || null;
          return {
              id: a.id || a.pageId || null,
              title: a.title || a.name || 'Untitled',
              url: a.url || a.link || a._links?.base || '#',
              excerpt: a.excerpt || (a.content && String(a.content).substring(0, 400)) || '',
              source: 'Confluence',
              aiRelevanceScore: score,
              aiExplanation: explanation,
              aiFallback: !!a.aiFallback
          };
      });

      return Result.success(pages);
  }

  /**
   * Authentication and Connection Message Handlers
   */

  const logger$6 = createLogger('AuthHandlers');

  async function handleTestConnectionRequest(request) {
      try {
          const result = await testConnection(request.token, request.testModel);
          return result; // testConnection already returns a Result
      } catch (err) {
          // Surface clearer error for permission-related failures that require a user gesture
          if (err && (err.code === 'USER_GESTURE_REQUIRED' || err.code === 'MISSING_HOST_PERMISSION' || (err.message && err.message.toLowerCase().includes('user gesture')))) {
              logger$6.warn('Permission request required from UI for testConnection', 'testConnection', err);
              return Result.failure(new Error('Permission to access the configured AI endpoint is required. Please open extension options and re-run the test from the options page.'));
          }
          return Result.failure(err);
      }
  }

  /**
   * Community/Knowledge Base Message Handlers
   */

  const logger$5 = createLogger('CommunityHandlers');

  /**
   * Handles requests for FETCH_COMMUNITY_GUIDES.
   */
  async function handleGetCommunityGuidesRequest(request) {
      logger$5.debug('Received Knowledge Base request', 'knowledgeBaseHandler', request);
      const labels = await getKnowledgeBaseLabels();
      const isManualFetch = Boolean(request.isManualFetch);
      const result = await searchCommunityGuides(request.caseData || {}, 3, isManualFetch);

      if (!result.ok) {
          logger$5.error('Community guides search failed', 'knowledgeBaseHandler', result.error);
          return result;
      }

      const items = Array.isArray(result.value) ? result.value : [];
      const guidesResp = items.map(guide => ({
          id: guide.id || guide.articleId || null,
          title: (guide.title || guide.name || 'Untitled').replace(/^\?+/, '').trim(),
          url: guide.url || guide.link || '#',
          excerpt: guide.aiExplanation || guide.explanation || guide.excerpt || (guide.content && typeof guide.content === 'string' ? guide.content.substring(0, 400) : '') || '',
          source: guide.category || labels.entryLabel,
          aiRelevanceScore: guide.aiRelevanceScore || guide.score || null,
          aiExplanation: guide.aiExplanation || guide.explanation || null,
          aiFallback: !!guide.aiFallback
      }));

      return Result.success(guidesResp);
  }

  async function handleExplainCommunityGuideRequest(request) {
      logger$5.debug('Received explainCommunityGuide request', 'explainCommunityHandler');
      if (!request.caseData || typeof request.caseData !== 'object') {
          throw new Error('Invalid case data provided');
      }

      if (!request.article || typeof request.article !== 'object') {
          throw new Error('Invalid article data provided');
      }

      const kbLabels = await getKnowledgeBaseLabels();
      const caseData = request.caseData;
      const article = request.article;

      const prompt = `Given the following case context:
Subject: ${caseData.subject || 'N/A'}
Description: ${caseData.description ? cleanEmailContent(caseData.description) : 'N/A'}

And this ${kbLabels.entryLabel} article:
Title: ${article.title || 'Untitled'}
Excerpt: ${article.excerpt || article.content || ''}

Provide a concise (1-2 sentence) explanation of why this article is relevant to the case.`;

      const aiMutation = 'mutation ExplainCommunityGuide($model: String!, $prompt: String!, $temperature: Float) { answerPrompt(input: { model: $model, prompt: $prompt, temperature: $temperature }) }';
      const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
      const model = await getActiveAiModel();
      const temperature = advancedAiSettings?.contextSettings?.communityGuides?.temperature ?? 0.2;

      const variables = { model, prompt, temperature };
      const response = await makeApiRequest(aiMutation, variables);
      const aiText = response?.data?.answerPrompt || null;
      const cleaned = aiText ? removeMarkdownCodeBlocks(String(aiText).trim()) : null;
      return Result.success({ explanation: cleaned });
  }

  const logger$4 = createLogger('ChromeAsync');

  function getLastError() {
    const lastError = chrome?.runtime?.lastError;
    if (!lastError) return null;
    const message = typeof lastError.message === 'string' ? lastError.message : String(lastError);
    return new Error(message);
  }

  function isThenable(value) {
    return value && (typeof value === 'object' || typeof value === 'function') && typeof value.then === 'function';
  }

  async function callChromeApi(fn, args, { expectsCallback = true } = {}) {
    return await new Promise((resolve, reject) => {
      let settled = false;
      const settle = (error, value) => {
        if (settled) return;
        settled = true;
        if (error) reject(error);
        else resolve(value);
      };

      const callback = (...callbackArgs) => {
        const err = getLastError();
        if (err) {
          settle(err);
          return;
        }
        if (callbackArgs.length <= 1) {
          settle(null, callbackArgs[0]);
        } else {
          settle(null, callbackArgs);
        }
      };

      const attempt = (withCallback) => {
        try {
          const result = withCallback ? fn(...args, callback) : fn(...args);
          if (isThenable(result)) {
            result.then(
              (value) => settle(null, value),
              (error) => settle(error)
            );
          } else if (!withCallback || !expectsCallback) {
            settle(null, result);
          }
          return true;
        } catch (error) {
          if (withCallback) return false;
          logger$4.debug('API invocation error', 'chrome-async', error);
          settle(error);
          return true;
        }
      };

      if (expectsCallback) {
        const ok = attempt(true);
        if (!ok) {
          attempt(false);
        }
      } else {
        attempt(false);
      }
    });
  }

  async function tabsQuery(queryInfo) {
    if (!chrome?.tabs?.query) {
      throw new Error('chrome.tabs.query is not available');
    }
    return await callChromeApi(chrome.tabs.query.bind(chrome.tabs), [queryInfo]);
  }

  async function storageLocalRemove(keys) {
    if (!chrome?.storage?.local?.remove) {
      throw new Error('chrome.storage.local.remove is not available');
    }
    return await callChromeApi(chrome.storage.local.remove.bind(chrome.storage.local), [keys]);
  }

  async function scriptingExecuteScript(options) {
    if (!chrome?.scripting?.executeScript) {
      throw new Error('chrome.scripting.executeScript is not available');
    }
    return await callChromeApi(chrome.scripting.executeScript.bind(chrome.scripting), [options]);
  }

  /**
   * System and Browser Integration Message Handlers
   */

  const logger$3 = createLogger('SystemHandlers');

  /**
   * Clear cache with optional pattern matching
   */
  function clearCache(pattern = null) {
      if (!pattern) {
          const count = responseCache.size;
          responseCache.clear();
          return count;
      }

      // Clear only entries matching the pattern
      let cleared = 0;
      for (const [key] of responseCache.entries()) {
          if (key.includes(pattern)) {
              responseCache.delete(key);
              cleared++;
          }
      }
      return cleared;
  }

  async function handleOpenOptionsPageRequest() {
      try {
          if (chrome?.runtime?.openOptionsPage) {
              await chrome.runtime.openOptionsPage();
          }
      } catch (err) {
          logger$3.warn('Failed to open options page directly', 'openOptionsHandler', err);
      }
      return Result.success({ opened: true });
  }

  function handleShowNotificationRequest() {
      if (chrome.notifications) ;
      return Result.success({ notified: true });
  }

  async function handleClearCacheRequest(request) {
      const cleared = clearCache(request.pattern);
      await storageLocalRemove(CACHE_STORAGE_KEY);
      logger$3.debug('Cleared persisted cache storage key', 'clearCacheHandler');
      return Result.success({
          cleared,
          timestamp: new Date().toISOString()
      });
  }

  async function handleImportEmailTextRequest() {
      const tabs = await tabsQuery({ active: true, currentWindow: true });
      const activeTab = tabs[0];

      if (!activeTab || !activeTab.id) {
          return Result.failure(new Error('No active tab found'));
      }

      const executionResults = await scriptingExecuteScript({
          target: { tabId: activeTab.id, allFrames: true },
          function: () => {
              const emailSelectors = [
                  'body[aria-label="Email Body"][role="textbox"][contenteditable="true"]',
                  '[contenteditable="true"][role="textbox"]',
                  '.cke_editable',
                  '.slds-rich-text-area__content',
                  '.forceChatterRichTextEditor [contenteditable="true"]',
                  '.cxSharedChatterRichTextEditor [contenteditable="true"]',
                  'div[contenteditable="true"]'
              ];

              for (const selector of emailSelectors) {
                  const emailBody = document.querySelector(selector);
                  if (emailBody && emailBody.innerText && emailBody.innerText.trim()) {
                      return {
                          ok: true,
                          text: emailBody.innerText.trim(),
                          selector: selector,
                          frameUrl: window.location.href
                      };
                  }
              }

              if (window.parent !== window) {
                  return {
                      ok: false,
                      error: 'Checked iframe: ' + window.location.href + ' - No email content found',
                      frameUrl: window.location.href
                  };
              }

              return {
                  ok: false,
                  error: 'Email body element not found in any frame',
                  frameUrl: window.location.href
              };
          }
      });

      const successfulResult = (executionResults || []).find(entry => entry?.result?.ok);

      if (successfulResult?.result?.text) {
          const filteredText = filterImportedEmailText(successfulResult.result.text);
          return Result.success({ text: filteredText });
      }

      const errors = (executionResults || [])
          .map(entry => entry?.result?.error)
          .filter(Boolean)
          .join('; ');

      return Result.failure(new Error(errors ? `Email content not found: ${errors}` : 'Email content not found'));
  }

  /**
   * Suggest Solution handler helpers
   */


  function formatKeywordResults(results, kbLabel, prefix = '') {
    const solutionText = `${prefix}${results.map(r => `- ${r.title || r.name || r.source || 'Untitled'}`).join('\n')}`;
    const sources = results.map(r => ({
      title: r.title || r.name || 'Untitled',
      snippet: r.excerpt || (r.content && r.content.substring(0, 200)) || '',
      url: r.url || r.link || '#',
      source: r.category || r.section || kbLabel,
      aiRelevanceScore: r.aiRelevanceScore
    }));
    return { solutionText, sources };
  }

  function buildVectorSources(results) {
    return results.map(r => ({
      title: (r.metadata && (r.metadata.source_page_title || r.metadata.source_file)) || r.title || 'Untitled',
      snippet: r.chunk_text || r.excerpt || '',
      url: r.metadata && r.metadata.source_url ? r.metadata.source_url : (r.url || '#'),
      source: r.metadata && (r.metadata.source || r.metadata.source_page_title) || 'Local DB',
      page: r.metadata?.page_number,
      aiRelevanceScore: r.relevance || r.score
    }));
  }

  const SEARCH_MODE_HANDLERS = {
    async keyword({ caseData, kbLabels }) {
      const res = await searchCommunityGuides(caseData);
      const results = (res && res.ok) ? res.value : [];
      const { solutionText, sources } = formatKeywordResults(
        results,
        kbLabels.entryLabel,
        'Matching Knowledge Base Articles:\n\n'
      );
      return { solution: solutionText, sources };
    },
    async vector({ caseData, queryText, localSearchEnabled, localSearchServerUrl, kbLabels }) {
      const hasLocal = !!localSearchEnabled && !!(localSearchServerUrl && localSearchServerUrl.trim());
      if (!hasLocal) {
        const res = await searchCommunityGuides(caseData);
        const results = (res && res.ok) ? res.value : [];
        const { solutionText, sources } = formatKeywordResults(
          results,
          kbLabels.entryLabel,
          'Local vector search is disabled; falling back to keyword search.\n\n'
        );
        return { solution: solutionText, sources };
      }

      const vres = await searchLocalVectorDB(queryText);
      const results = vres.ok ? vres.value : [];
      const solution = "Relevant documentation found via vector search:\n\n" + results.map(r => {
        const title = (r.metadata && (r.metadata.source_page_title || r.metadata.source_file)) || r.title || 'Untitled';
        return `- ${title}${r.metadata?.page_number ? ` (Page: ${r.metadata.page_number})` : ''}`;
      }).join('\n');
      return { solution, sources: buildVectorSources(results) };
    },
    async generative({ caseData, queryText, localSearchEnabled, localSearchServerUrl, kbLabels }) {
      const hasLocal = !!localSearchEnabled && !!(localSearchServerUrl && localSearchServerUrl.trim());
      if (!hasLocal) {
        const res = await searchCommunityGuides(caseData);
        const results = (res && res.ok) ? res.value : [];
        const { solutionText, sources } = formatKeywordResults(
          results,
          kbLabels.entryLabel,
          'Searching Knowledge Base...\n\n'
        );
        return { solution: solutionText, sources };
      }

      const vres = await searchLocalVectorDB(queryText);
      const contextResults = vres.ok ? vres.value : [];
      const context = contextResults.map(r => r.chunk_text || r.content || r.excerpt || '').join('\n\n---\n\n');
      const res = await suggestSolution(caseData, context);
      const solution = (res && res.ok) ? res.value : (res.error?.message || 'Failed to generate guidance.');
      return { solution, sources: buildVectorSources(contextResults) };
    }
  };

  async function handleSuggestSolutionRequest(request) {
    const { searchSettings = { mode: 'keyword' }, localSearchEnabled, localSearchServerUrl } = await chrome.storage.local.get({
      searchSettings: { mode: 'keyword' },
      localSearchEnabled: false,
      localSearchServerUrl: ''
    });

    const kbLabels = await getKnowledgeBaseLabels();
    const caseData = request.data || {};
    const providedContext = request.context || "";
    const queryText = `${caseData.subject || ''} ${caseData.description || ''}`.trim();

    if (providedContext) {
      const res = await suggestSolution(caseData, providedContext);
      const solution = (res && res.ok) ? res.value : (typeof res === 'string' ? res : 'Failed to synthesize guidance.');
      return Result.success({ solution, sources: [] });
    }

    const handler = SEARCH_MODE_HANDLERS[searchSettings.mode] || SEARCH_MODE_HANDLERS.keyword;
    const result = await handler({
      caseData,
      queryText,
      localSearchEnabled,
      localSearchServerUrl,
      kbLabels
    });

    return Result.success(result);
  }

  /**
   * Message Handler Registry
   * Aggregates all specific handler modules into a centralized routing map.
   */

  const MESSAGE_HANDLERS = {
      // AI Handlers
      analyzeCase: handleAnalyzeCaseRequest,
      improveSolution: handleImproveSolutionRequest,
      spellcheck: handleSpellcheckRequest,
      suggestSolution: handleSuggestSolutionRequest,

      // Atlassian Handlers
      getRelatedJiraTickets: handleGetJiraTicketsRequest,
      getRelatedConfluencePages: handleGetConfluencePagesRequest,
      testAtlassianConnection: handleTestAtlassianConnectionRequest,
      testConfluenceConnection: handleTestAtlassianConnectionRequest,
      testJiraConnection: handleTestAtlassianConnectionRequest,

      // Community Handlers
      getRelatedCommunityGuides: handleGetCommunityGuidesRequest,
      explainCommunityGuide: handleExplainCommunityGuideRequest,

      // Auth Handlers
      testConnection: handleTestConnectionRequest,

      // System Handlers
      openOptionsPage: handleOpenOptionsPageRequest,
      showNotification: handleShowNotificationRequest,
      clearCache: handleClearCacheRequest,
      importEmailText: handleImportEmailTextRequest
  };

  /**
   * Message Handlers Module
   * Handles all chrome.runtime.onMessage communications via a registry pattern.
   */


  const logger$2 = createLogger('MessageHandlers');

  /**
   * Safe sendResponse wrapper to catch exceptions and log
   * @param {Function} sendResponseFn
   * @param {Object} payload
   */
  function safeSendResponse(sendResponseFn, payload) {
    try {
      logger$2.debug('Sending response', 'safeSendResponse', payload && (payload.ok ? 'success' : 'error'));
      sendResponseFn(payload);
    } catch (err) {
      logger$2.error('Failed to send response', 'safeSendResponse', { error: err, payload });
      try {
        chrome.runtime.lastError && logger$2.warn('LastError present', 'safeSendResponse', chrome.runtime.lastError.message);
      } catch (e) {
        logger$2.debug('Error checking lastError', 'safeSendResponse', e);
      }
    }
  }

  /**
   * Standardized error response builder
   */
  function buildErrorResponse(error, context = 'Unknown') {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logger$2.error('Error occurred', context, error);

    return {
      ok: false,
      error: errorMessage,
      context: context,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Normalizes an operation result into a standardized response object.
   */
  function normalizeResponse(result) {
    // Handle Result objects
    if (result && typeof result.ok === 'boolean') {
      if (result.ok) {
        return { ok: true, data: result.value };
      } else {
        const errorMsg = result.error instanceof Error ? result.error.message : String(result.error || 'Unknown error');
        const payload = { ok: false, error: errorMsg };
        if (result.error && typeof result.error === 'object' && result.error.details) {
          payload.details = result.error.details;
        }
        return payload;
      }
    }

    // Handle already standardized responses
    if (result && typeof result === 'object' && Object.prototype.hasOwnProperty.call(result, 'ok')) {
      return result;
    }

    // Handle legacy success-based responses
    if (result && typeof result === 'object' && Object.prototype.hasOwnProperty.call(result, 'success')) {
      return {
        ok: result.success,
        data: result.data,
        error: result.error,
        ...result
      };
    }

    // Handle raw data responses
    return {
      ok: true,
      data: result
    };
  }

  async function ensureServiceWorkerReady() {
    if (getInitializationState()) {
      return;
    }

    logger$2.warn('Service worker was not initialized. Attempting reinitialization...');
    try {
      await initializeServiceWorker();
      setInitializationState(true);
    } catch (error) {
      logger$2.error('Failed to reinitialize service worker', 'ensureServiceWorkerReady', error);
      throw error;
    }
  }

  /**
   * Initialize the main message listener
   */
  function initializeMessageListener() {
    logger$2.info('Registering message listener', 'messageHandlers');

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      const action = request?.action;
      const handler = action && MESSAGE_HANDLERS[action];

      if (!handler) {
        safeSendResponse(sendResponse, buildErrorResponse(new Error(`Unknown action: ${action}`), 'MessageRouter'));
        return false;
      }

      logger$2.debug('Message received', 'messageListener', { action, from: sender?.tab?.id || 'extension' });



      (async () => {
        await ensureServiceWorkerReady();
        // Enforce a global timeout on all message handlers to prevent hangs
        return await withTimeout(
          () => handler(request, sender),
          60000,
          `Message handler timed out for action: ${action}`
        );
      })()
        .then(result => {
          safeSendResponse(sendResponse, normalizeResponse(result));
        })
        .catch(error => {
          safeSendResponse(sendResponse, buildErrorResponse(error, action));
        });

      return true;
    });
  }

  // Bootstrap for background service worker initialization

  const logger$1 = createLogger('Bootstrap');

  function startBackground() {
    logger$1.info('BACKGROUND: Starting synchronous initialization...', 'bootstrap', undefined);

    // Initialize all event listeners FIRST (synchronous)
    initializeAllListeners();
    logger$1.info('BACKGROUND: Lifecycle listeners initialized', 'bootstrap', undefined);

    // Initialize message listener IMMEDIATELY (synchronous, critical)
    initializeMessageListener();
    logger$1.info('BACKGROUND: Message listener initialized', 'bootstrap', undefined);

    // Initialize context menu listener
    initializeContextMenuListener();
    logger$1.info('BACKGROUND: Context menu listener initialized', 'bootstrap', undefined);

    // Run async initialization in background (non-blocking)
    if (chrome.runtime && chrome.runtime.id) {
      logger$1.info('BACKGROUND: chrome.runtime.id present, starting async init', 'bootstrap', undefined);
      initializeServiceWorker().then(() => {
        setInitializationState(true);
        logger$1.info('BACKGROUND: Async initialization complete', 'bootstrap', undefined);
      }).catch(error => {
        logger$1.error('BACKGROUND: Async initialization failed:', 'bootstrap', error);
      });
    } else {
      logger$1.warn('BACKGROUND: chrome.runtime.id NOT available', 'bootstrap', undefined);
    }
  }

  /**
   * Background Service Worker
   * Main entry point for the PandAid extension
   * Now modularized - most functionality has been extracted to dedicated modules
   */


  const logger = createLogger('Background');

  logger.info(`Service worker script loaded at ${new Date().toISOString()}`, 'background');

  // Run background bootstrap
  startBackground();

})();
