(function () {
  'use strict';

  /**
   * Centralized Logging Utility
   * Provides consistent logging across the extension with verbose mode support
   *
   * @module logger
   */

  // ============================================================================
  // LOG LEVELS
  // ============================================================================

  /**
   * Log severity levels
   * @enum {string}
   * @readonly
   */
  const LogLevel = {
    ERROR: 'error',   // Critical errors that need immediate attention
    WARN: 'warn',     // Warnings about potential issues
    INFO: 'info',     // Important informational messages (always shown)
    DEBUG: 'debug',   // Detailed debugging information (verbose mode only)
    TRACE: 'trace'    // Very detailed trace information (verbose mode only)
  };

  // ============================================================================
  // LOGGER CLASS
  // ============================================================================

  class Logger {
    /**
     * Create a new logger instance with optional context.
     *
     * @param {string} [context='PandAid'] - Context name for this logger (appears in all log messages)
     */
    constructor(context = 'PandAid') {
      this.context = context;
      this.verboseEnabled = false;
      this.initialized = false;

      // Kick off async load without blocking construction
      this.loadVerbosePreference().catch((error) => {
        logger$b.warn('[Logger] Failed to load verbose preference', 'logger', error);
      });
    }

    /**
     * Load verbose logging preference from Chrome storage.
     * Called automatically during constructor initialization.
     *
     * @private
     * @async
     * @returns {Promise<void>}
     */
    async loadVerbosePreference() {
      if (this.initialized) return;
      this.initialized = true;

      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        return;
      }

      try {
        const result = await chrome.storage.local.get(['verboseLogging']);
        if (Object.prototype.hasOwnProperty.call(result, 'verboseLogging')) {
          this.verboseEnabled = !!result.verboseLogging;
        }
      } catch (error) {
        logger$b.warn('[Logger] Error reading verbose logging preference', 'logger', error);
      }
    }

    /**
     * Set verbose mode at runtime.
     * Useful for toggling detailed logging during debugging or testing.
     *
     * @param {boolean} enabled - Whether to enable verbose logging
     */
    setVerbose(enabled = false) {
      this.verboseEnabled = !!enabled;
    }

    /**
     * Check if verbose logging is currently enabled.
     *
     * @returns {boolean} True if verbose logging is enabled
     */
    isVerboseEnabled() {
      return this.verboseEnabled;
    }

    /**
     * Format log message with timestamp and context.
     * Internal helper method for consistent formatting across all log levels.
     *
     * @private
     * @param {string} level - Log level (from LogLevel enum)
     * @param {string} context - Additional context string
     * @param {string} message - The message to format
     * @returns {string} Formatted message with timestamp
     */
    formatMessage(level, context, message) {
      const timestamp = new Date().toISOString().substring(11, 23); // HH:MM:SS.mmm
      const contextLabel = context ? `${this.context}:${context}` : this.context;
      return `[${timestamp}] [${contextLabel}] [${level.toUpperCase()}] ${message}`;
    }

    /**
     * Log error message (always shown regardless of verbose mode).
     * Use for critical errors that need immediate attention.
     *
     * @param {string} message - The error message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data/error object to log
     */
    error(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.ERROR, context, message);
      if (data !== null) {
        console.error(formatted, data);
      } else {
        console.error(formatted);
      }
    }

    /**
     * Log warning message (always shown regardless of verbose mode).
     * Use for potential issues or unexpected conditions.
     *
     * @param {string} message - The warning message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    warn(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.WARN, context, message);
      if (data !== null) {
        console.warn(formatted, data);
      } else {
        console.warn(formatted);
      }
    }

    /**
     * Log info message (always shown regardless of verbose mode).
     * Use for important informational messages about normal operation.
     *
     * @param {string} message - The info message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    info(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.INFO, context, message);
      if (data !== null) {
        console.info(formatted, data);
      } else {
        console.info(formatted);
      }
    }

    /**
     * Log debug message (only shown if verbose logging is enabled).
     * Use for detailed debugging information during development/troubleshooting.
     *
     * @param {string} message - The debug message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    debug(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.DEBUG, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Log trace message (only shown if verbose logging is enabled).
     * Used for very detailed logging like function entry/exit, state changes, etc.
     *
     * @param {string} message - The trace message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    trace(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.TRACE, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Create a child logger with a specific context.
     * Child loggers inherit the parent's verbose mode setting.
     *
     * @param {string} childContext - The child context name (appended to parent context)
     * @returns {Logger} New logger instance with combined context
     */
    child(childContext) {
      const childLogger = new Logger(`${this.context}:${childContext}`);
      childLogger.setVerbose(this.verboseEnabled);
      childLogger.initialized = true; // Do not re-read storage; inherit setting
      return childLogger;
    }

    /**
     * Log a group of related messages together.
     * Groups are only shown if verbose logging is enabled.
     *
     * @param {string} groupName - Name/title of the log group
     * @param {Function} fn - Function containing logger calls to group
     */
    group(groupName, fn) {
      if (!this.verboseEnabled) return;

      console.group(`[${this.context}] ${groupName}`);
      try {
        fn();
      } finally {
        console.groupEnd();
      }
    }

    /**
     * Execute a function and log its execution time.
     * Timing output is only shown if verbose logging is enabled.
     *
     * @param {string} label - Label for the timer (shown in timing output)
     * @param {Function} fn - Async function to time (can also be sync)
     * @returns {Promise<*>} Result of the function
     */
    async time(label, fn) {
      const timerLabel = `[${this.context}] ${label}`;
      if (this.verboseEnabled) {
        console.time(timerLabel);
      }

      try {
        return await fn();
      } finally {
        if (this.verboseEnabled) {
          console.timeEnd(timerLabel);
        }
      }
    }
  }

  // ============================================================================
  // GLOBAL LOGGER INSTANCE
  // ============================================================================

  // Create default logger instance
  const defaultLogger = new Logger('PandAid');

  // Export factory function
  function createLogger(context = 'PandAid') {
    const newLogger = new Logger(context);
    newLogger.setVerbose(defaultLogger.isVerboseEnabled());
    return newLogger;
  }

  // Export default logger
  const logger$b = defaultLogger;

  // ============================================================================
  // STORAGE LISTENER
  // ============================================================================

  // Listen for changes to verbose logging preference
  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.verboseLogging) {
        const newValue = !!changes.verboseLogging.newValue;
        defaultLogger.setVerbose(newValue);
        logger$b.info(`[PandAid] Verbose logging ${newValue ? 'enabled' : 'disabled'}`, 'contextual', undefined);
      }
    });
  }

  // modules/options/ui-helpers.js
  //
  // UI helper utilities for status messaging and inline errors.

  const logger$a = createLogger('OptionsUI');

  function showSectionStatus(element, message, type = 'info') {
    if (!element) return;
    element.textContent = message;
    element.className = `status ${type}`;
    element.style.display = 'block';
    if (type !== 'error') {
      setTimeout(() => {
        try {
          element.style.display = 'none';
        } catch (e) {
          logger$a.debug('Error hiding status element (likely removed)', 'ui-helpers', e);
        }
      }, 5000);
    }
  }

  function showStatus(statusElement, message, type = 'info') {
    showSectionStatus(statusElement, message, type);
  }

  function showAtlassianUrlInputError(atlassianBaseUrlInput, message) {
    if (!atlassianBaseUrlInput) return;
    let err = document.getElementById('atlassian-base-url-error');
    if (!err) {
      err = document.createElement('p');
      err.id = 'atlassian-base-url-error';
      err.className = 'input-error';
      err.style.color = '#b22222';
      err.style.fontSize = '12px';
      err.style.margin = '6px 0 0 0';
      if (atlassianBaseUrlInput.parentNode) atlassianBaseUrlInput.parentNode.appendChild(err);
    }
    err.textContent = message;
    err.style.display = 'block';
  }


  function hideAtlassianUrlInputError() {
    const err = document.getElementById('atlassian-base-url-error');
    if (err) err.style.display = 'none';
  }

  /**
   * UI Controller
   * Manages UI interactions, tab switching, and status updates.
   */

  class UiController {
      constructor(elements) {
          this.elements = elements;
          this.statusElement = elements.statusElement;
      }

      showStatus(message, type = 'info') {
          showStatus(this.statusElement, message, type);
      }

      showSectionStatus(element, message, type = 'info') {
          showSectionStatus(element, message, type);
      }

      showAtlassianError(message) {
          showAtlassianUrlInputError(this.elements.atlassianBaseUrlInput, message);
      }

      hideAtlassianError() {
          hideAtlassianUrlInputError();
      }

      setupTabs() {
          const { tabContainer, tabButtons, tabContents } = this.elements;
          if (!tabContainer) return;

          tabContainer.addEventListener('click', (e) => {
              const button = e.target.closest('.tab-button');
              if (!button) return;

              // Deactivate all
              tabButtons.forEach(b => b.classList.remove('active'));
              tabContents.forEach(c => c.classList.remove('active'));

              // Activate clicked
              button.classList.add('active');
              const tabId = button.dataset.tab;
              const content = document.getElementById(tabId);
              if (content) {
                  content.classList.add('active');
                  // If switching to advanced settings, refresh sliders layout if needed
                  if (tabId === 'advanced-settings') {
                      window.dispatchEvent(new Event('resize'));
                  }
              }
          });
      }
  }

  const DEFAULTS = {
    summary: { temp: 30, topP: 80, topK: 40 },
    community: { temp: 20, topP: 70, topK: 30 },
    jira: { temp: 25, topP: 85, topK: 35 },
    confluence: { temp: 40, topP: 90, topK: 50 }
  };

  function setContextDefaults(sliderSet, defaults) {
    const temp = defaults?.temp ?? 30;
    const topP = defaults?.topP ?? 80;
    const topK = defaults?.topK ?? 40;
    const { tempSlider, tempValue, topPSlider, topPValue, topKSlider, topKValue } = sliderSet || {};

    if (tempSlider && tempValue) {
      tempSlider.value = temp;
      tempValue.textContent = (temp / 100).toFixed(2);
    }
    if (topPSlider && topPValue) {
      topPSlider.value = topP;
      topPValue.textContent = (topP / 100).toFixed(2);
    }
    if (topKSlider && topKValue) {
      topKSlider.value = topK;
      topKValue.textContent = String(topK);
    }
  }

  function initializeDefaultContextSettings(sliders) {
    if (!sliders) return;
    setContextDefaults(sliders.summary, DEFAULTS.summary);
    setContextDefaults(sliders.community, DEFAULTS.community);
    setContextDefaults(sliders.jira, DEFAULTS.jira);
    setContextDefaults(sliders.confluence, DEFAULTS.confluence);
  }

  function setupSlider(slider, valueElement, isDecimal = true) {
    if (!slider || !valueElement) return;
    slider.addEventListener('input', () => {
      if (isDecimal) {
        const value = (slider.value / 100).toFixed(2);
        valueElement.textContent = value;
      } else {
        valueElement.textContent = slider.value;
      }
    });
  }

  function setupAllSliders(sliders) {
    if (!sliders) return;
    setupSlider(sliders.summary?.tempSlider, sliders.summary?.tempValue, true);
    setupSlider(sliders.summary?.topPSlider, sliders.summary?.topPValue, true);
    setupSlider(sliders.summary?.topKSlider, sliders.summary?.topKValue, false);

    setupSlider(sliders.community?.tempSlider, sliders.community?.tempValue, true);
    setupSlider(sliders.community?.topPSlider, sliders.community?.topPValue, true);
    setupSlider(sliders.community?.topKSlider, sliders.community?.topKValue, false);

    setupSlider(sliders.jira?.tempSlider, sliders.jira?.tempValue, true);
    setupSlider(sliders.jira?.topPSlider, sliders.jira?.topPValue, true);
    setupSlider(sliders.jira?.topKSlider, sliders.jira?.topKValue, false);

    setupSlider(sliders.confluence?.tempSlider, sliders.confluence?.tempValue, true);
    setupSlider(sliders.confluence?.topPSlider, sliders.confluence?.topPValue, true);
    setupSlider(sliders.confluence?.topKSlider, sliders.confluence?.topKValue, false);
  }

  function switchContextTab(tabId, deps) {
    const { contextSettings, contextTabs, aiJiraToggle, atlassianTokenInput, createContextWarning } = deps || {};
    if (!contextSettings || !contextTabs) return;

    contextSettings.forEach(panel => {
      panel.style.display = 'none';
    });
    contextTabs.forEach(tab => {
      tab.classList.remove('active');
    });

    const selectedPanel = document.getElementById(`settings-${tabId}`);
    if (selectedPanel) {
      selectedPanel.style.display = 'block';
      if (tabId === 'jira' && aiJiraToggle) {
        const jiraAiEnabled = aiJiraToggle.checked;
        const hasAtlassianToken = atlassianTokenInput && atlassianTokenInput.value.trim().length > 0;

        if (!jiraAiEnabled || !hasAtlassianToken) {
          selectedPanel.classList.add('context-disabled');
          const warningMessage = selectedPanel.querySelector('.context-warning');
          if (!warningMessage && typeof createContextWarning === 'function') {
            const warning = createContextWarning(
              !jiraAiEnabled
                ? '<strong>Note:</strong> JIRA AI enhancement is currently disabled. These settings will only take effect when JIRA AI is enabled.'
                : '<strong>Note:</strong> JIRA AI requires a valid JIRA token to function. Please add a token in the Atlassian Integration section.'
            );
            selectedPanel.insertBefore(warning, selectedPanel.firstChild);
          }
        } else {
          selectedPanel.classList.remove('context-disabled');
          const warningMessage = selectedPanel.querySelector('.context-warning');
          if (warningMessage) warningMessage.remove();
        }
      }
    }

    const activeTab = document.getElementById(`tab-${tabId}`);
    if (activeTab) activeTab.classList.add('active');
  }

  /**
   * AI Settings Controller
   * Manages AI model configuration, sliders, and context settings.
   */

  class AiSettingsController {
      constructor(elements, dependencies) {
          this.elements = elements;
          this.dependencies = dependencies;
          this.sliderGroups = elements.sliderGroups;
      }

      initialize() {
          this.setupContextTabs();
          this.setupSliders();
          this.setupModelControls();
      }

      setupContextTabs() {
          const { contextTabs, aiContextDeps } = this.elements;

          // Explicitly attach the event listener to each tab
          contextTabs.forEach(tab => {
              tab.addEventListener('click', () => {
                  const tabId = tab.dataset.tab;
                  switchContextTab(tabId, aiContextDeps);
              });
          });
      }

      setupSliders() {
          const { sliderGroups } = this.elements;
          setupAllSliders(sliderGroups);
      }

      setupModelControls() {
          const { modelControls } = this.elements;
          modelControls.forEach(({ input }) => {
              input.addEventListener('input', () => this.enforceModelRadioAvailability());
          });
          this.enforceModelRadioAvailability(); // Initial check
      }

      enforceModelRadioAvailability() {
          const { modelControls } = this.elements;
          let firstEligibleRadio = null;

          modelControls.forEach(({ input, radio }) => {
              const hasValue = Boolean(input.value.trim());
              radio.disabled = !hasValue;

              if (!hasValue && radio.checked) {
                  radio.checked = false;
              }

              if (hasValue && !firstEligibleRadio) {
                  firstEligibleRadio = radio;
              }
          });

          const anyRadioChecked = modelControls.some(({ radio }) => radio.checked);

          // Auto-select first available if none checked
          if (!anyRadioChecked && firstEligibleRadio) {
              firstEligibleRadio.checked = true;
              this.animateRadioSelection(firstEligibleRadio);
          }
      }

      animateRadioSelection(radio) {
          const label = radio.closest('label') || radio.parentElement;
          if (!label) return;

          label.classList.add('auto-selected-highlight');
          label.style.transition = 'background-color 0.3s ease';
          label.style.backgroundColor = '#e3f2fd'; // Light blue highlight

          setTimeout(() => {
              label.style.backgroundColor = '';
              label.classList.remove('auto-selected-highlight');
          }, 1500);
      }
  }

  /**
   * result.js
   *
   * Standardized Result pattern for operation outcomes.
   * Replaces the inconsistent mix of nulls, throws, and {success:false} objects.
   */

  class Result {
      constructor(ok, value, error) {
          this.ok = ok;
          this.value = value;
          this.error = error;
      }

      /**
       * Create a successful result
       * @param {any} value - The success return value
       * @returns {Result}
       */
      static success(value) {
          return new Result(true, value, null);
      }

      /**
       * Create a failure result
       * @param {Error|string} error - The error object or message
       * @returns {Result}
       */
      static failure(error) {
          const errObj = error instanceof Error ? error : new Error(String(error));
          return new Result(false, null, errObj);
      }

      /**
       * Unwrap the value or throw the error
       * @returns {any} The value if success
       * @throws {Error} The error if failure
       */
      unwrap() {
          if (this.ok) {
              return this.value;
          }
          throw this.error;
      }
  }

  /**
   * Crypto Utilities Module
   * Provides encryption/decryption for sensitive data at rest using Web Crypto API.
   *
   * Security model:
   * - Encryption key is generated once per extension install
   * - Key is stored in chrome.storage.session (memory-only, cleared on browser restart)
   * - Data encrypted with AES-GCM (authenticated encryption)
   * - Protects against: storage export, disk access, sync exposure
   * - Does NOT protect against: runtime inspection, DevTools access
   */


  const logger$9 = createLogger('CryptoUtils');

  const ALGORITHM = 'AES-GCM';
  const KEY_LENGTH = 256;
  const IV_LENGTH = 12; // 96 bits for GCM
  const KEY_STORAGE_KEY = '_pandaid_session_key';
  const ENCRYPTED_PREFIX = 'enc:v1:'; // Versioned prefix to identify encrypted data

  // In-memory cache of the CryptoKey (avoids repeated storage lookups)
  let cachedKey = null;

  /**
   * Convert Uint8Array to base64 string using proper binary handling
   * @param {Uint8Array} buffer
   * @returns {string}
   */
  function arrayBufferToBase64(buffer) {
    let binary = '';
    const len = buffer.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(buffer[i]);
    }
    return btoa(binary);
  }

  /**
   * Convert base64 string to Uint8Array
   * @param {string} base64
   * @returns {Uint8Array}
   */
  function base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    const len = binary.length;
    const buffer = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      buffer[i] = binary.charCodeAt(i);
    }
    return buffer;
  }

  /**
   * Generate a new encryption key
   * @returns {Promise<CryptoKey>}
   */
  async function generateKey() {
    return crypto.subtle.generateKey(
      { name: ALGORITHM, length: KEY_LENGTH },
      true, // extractable - needed to store in session
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Export CryptoKey to storable format (JWK)
   * @param {CryptoKey} key
   * @returns {Promise<JsonWebKey>}
   */
  async function exportKey(key) {
    return crypto.subtle.exportKey('jwk', key);
  }

  /**
   * Import CryptoKey from stored format (JWK)
   * @param {JsonWebKey} jwk
   * @returns {Promise<CryptoKey>}
   */
  async function importKey(jwk) {
    return crypto.subtle.importKey(
      'jwk',
      jwk,
      { name: ALGORITHM, length: KEY_LENGTH },
      false, // not extractable after import
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Get or create the session encryption key.
   * Key is stored in chrome.storage.session (memory-only).
   * @returns {Promise<CryptoKey>}
   */
  async function getOrCreateKey() {
    // Return cached key if available
    if (cachedKey) {
      return cachedKey;
    }

    // Require session storage; don't degrade to persistent storage
    if (!chrome.storage.session) {
      const error = new Error(
        'Session storage unavailable. ' +
        'Token encryption requires ephemeral key storage. ' +
        'Please update your browser or restart the extension.'
      );
      error.code = 'SESSION_STORAGE_UNAVAILABLE';
      throw error;
    }

    try {
      const result = await chrome.storage.session.get(KEY_STORAGE_KEY);

      if (result[KEY_STORAGE_KEY]) {
        // Import existing key
        cachedKey = await importKey(result[KEY_STORAGE_KEY]);
        return cachedKey;
      }
    } catch (e) {
      logger$9.error('[Crypto] Error reading session key:', 'crypto-utils', e);
      throw e;
    }

    // Generate new key
    const newKey = await generateKey();
    const exportedKey = await exportKey(newKey);

    // Store in session storage
    try {
      await chrome.storage.session.set({ [KEY_STORAGE_KEY]: exportedKey });
      logger$9.info('[Crypto] New session key generated and stored', 'crypto-utils', undefined);
    } catch (e) {
      logger$9.error('[Crypto] Failed to store session key:', 'crypto-utils', e);
      throw e;
    }

    cachedKey = newKey;
    return cachedKey;
  }

  /**
   * Encrypt a string value
   * @param {string} plaintext - The value to encrypt
   * @returns {Promise<Result<string>>} - Result containing encrypted value or error
   */
  async function encrypt(plaintext) {
    if (!plaintext || typeof plaintext !== 'string') {
      return Result.success(plaintext);
    }

    // Don't double-encrypt
    if (plaintext.startsWith(ENCRYPTED_PREFIX)) {
      return Result.success(plaintext);
    }

    try {
      const key = await getOrCreateKey();
      const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));
      const encoder = new TextEncoder();
      const data = encoder.encode(plaintext);

      const ciphertext = await crypto.subtle.encrypt(
        { name: ALGORITHM, iv },
        key,
        data
      );

      // Combine IV + ciphertext and encode as base64
      const combined = new Uint8Array(iv.length + ciphertext.byteLength);
      combined.set(iv);
      combined.set(new Uint8Array(ciphertext), iv.length);

      // Convert Uint8Array to base64 using proper binary handling
      const base64 = arrayBufferToBase64(combined);
      return Result.success(ENCRYPTED_PREFIX + base64);
    } catch (error) {
      logger$9.error('[Crypto] Encryption failed - operation aborted to prevent data leak:', 'crypto-utils', error);
      return Result.failure(error);
    }
  }

  /**
   * Decrypt an encrypted string value
   * @param {string} encrypted - The encrypted value (with prefix)
   * @returns {Promise<Result<string>>} - Result containing decrypted plaintext or error
   */
  async function decrypt(encrypted) {
    if (!encrypted || typeof encrypted !== 'string') {
      return Result.success(encrypted);
    }

    // Not encrypted - return as-is (handles migration from unencrypted storage)
    if (!encrypted.startsWith(ENCRYPTED_PREFIX)) {
      return Result.success(encrypted);
    }

    try {
      const key = await getOrCreateKey();
      const base64 = encrypted.slice(ENCRYPTED_PREFIX.length);
      const combined = base64ToArrayBuffer(base64);

      // Extract IV and ciphertext
      const iv = combined.slice(0, IV_LENGTH);
      const ciphertext = combined.slice(IV_LENGTH);

      const decrypted = await crypto.subtle.decrypt(
        { name: ALGORITHM, iv },
        key,
        ciphertext
      );

      const decoder = new TextDecoder();
      return Result.success(decoder.decode(decrypted));
    } catch (error) {
      // If the underlying Web Crypto API reports an OperationError or similar
      // it most likely means the session key is missing/rotated and the
      // ciphertext cannot be authenticated with the current key. Surface a
      // clearer, actionable error to callers so UI can prompt the user to
      // re-enter their token.
      const isOpError = error && (error.name === 'OperationError' || error.name === 'DataError' || (error.message && error.message.includes('OperationError')));

      if (isOpError) {
        logger$9.warn('[Crypto] Decryption failed: session key missing or mismatched', 'crypto-utils', error);
        const decryptError = new Error('Crypto decryption failed: session key missing or mismatched. Please re-enter your API token in settings.');
        decryptError.code = 'SESSION_KEY_MISMATCH';
        decryptError.cause = error;
        return Result.failure(decryptError);
      }

      logger$9.error('[Crypto] Decryption failed:', 'crypto-utils', error);
      // Generic decryption failure - preserve existing behavior
      const decryptError = new Error('Crypto decryption failed: ' + (error && error.message ? error.message : 'unknown'));
      decryptError.code = 'DECRYPT_FAILED';
      decryptError.cause = error;
      return Result.failure(decryptError);
    }
  }

  const logger$8 = createLogger('ConnectionTesting');

  function createConnectionTesting({
    elements,
    messaging,
    permissions,
    helpers
  }) {
    const {
      aiServiceTokenInput,
      aiModel1Input: _aiModel1Input,
      aiModel2Input: _aiModel2Input,
      aiModel3Input: _aiModel3Input,
      activeModel1Radio: _activeModel1Radio,
      activeModel2Radio: _activeModel2Radio,
      activeModel3Radio: _activeModel3Radio,
      testAiButton,
      testAiResultElement,
      testAtlassianButton,
      testAtlassianResultElement,
      atlassianTokenInput,
      atlassianBaseUrlInput,
      atlassianEmailInput,
      verboseLoggingToggle,
      localSearchUrlInput,
      checkLocalServerButton,
      localServerStatusElement
    } = elements;

    const { sendMessageWithTimeout } = messaging;
    const { requestHostPermission, checkHostPermission, buildOriginFromUrl } = permissions;
    const { showSectionStatus } = helpers;

    function showAiPermissionMessage(message) {
      if (!testAiResultElement) return;
      testAiResultElement.textContent = message;
      testAiResultElement.className = 'status error';
      testAiResultElement.style.display = 'block';
    }

    async function ensureAiEndpointPermission() {
      try {
        const { apiEndpoint } = await chrome.storage.local.get('apiEndpoint');
        if (!apiEndpoint) {
          showAiPermissionMessage('✗ Please configure an AI Service API endpoint before testing the connection.');
          return false;
        }

        const origin = buildOriginFromUrl(apiEndpoint);
        if (!origin) {
          showAiPermissionMessage('✗ The configured AI endpoint is invalid. Please update the endpoint and try again.');
          return false;
        }

        const hasPerm = await checkHostPermission(origin);
        if (hasPerm) return true;

        const granted = await requestHostPermission(origin);
        if (!granted) {
          showAiPermissionMessage('✗ Permission to access the AI endpoint was denied. Please allow the request and try again.');
          return false;
        }

        return true;
      } catch (err) {
        logger$8.warn('AI endpoint permission check/request failed during connection test', 'connection-testing', err);
        showAiPermissionMessage('✗ Unable to request permission for the AI endpoint. Please re-open this page, allow the prompt, and try again.');
        return false;
      }
    }

    async function checkLocalServer() {
      if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
        showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
        return;
      }

      const rawInput = localSearchUrlInput.value.trim();
      const baseUrl = rawInput.replace(/\/$/, '');
      const origin = buildOriginFromUrl(rawInput);

      if (!origin) {
        showSectionStatus(localServerStatusElement, 'Local Search URL is invalid. Please include host and optional port (e.g., http://localhost:5002).', 'error');
        return;
      }

      try {
        const hasPerm = await checkHostPermission(origin);
        if (!hasPerm) {
          const granted = await requestHostPermission(origin);
          if (!granted) {
            showSectionStatus(localServerStatusElement, 'Permission to access the Local Search Server was not granted. Click "Request Permission" or allow when prompted.', 'error');
            return;
          }
        }
      } catch (err) {
        logger$8.warn('Permission check/request failed:', 'connection-testing', err);
      }

      const testUrl = baseUrl + '/search';

      if (checkLocalServerButton) {
        checkLocalServerButton.disabled = true;
        setLoadingState(checkLocalServerButton, 'Checking...');
      }
      if (localServerStatusElement) localServerStatusElement.style.display = 'none';

      try {
        const response = await fetch(testUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: 'health-check' })
        });

        if (!response.ok) {
          const txt = await response.text();
          showSectionStatus(localServerStatusElement, `Server responded ${response.status}: ${txt}`, 'error');
        } else {
          const data = await response.json().catch(() => null);
          const details = data && data.info ? ` - ${JSON.stringify(data.info)}` : '';
          showSectionStatus(localServerStatusElement, `Local search server reachable${details}`, 'success');
        }
      } catch (error) {
        logger$8.debug('Local search server check error', 'connection-testing', error);
        showSectionStatus(localServerStatusElement, `Failed to reach server: ${error.message}`, 'error');
      } finally {
        if (checkLocalServerButton) {
          checkLocalServerButton.disabled = false;
          checkLocalServerButton.textContent = 'Check Local Server';
        }
        if (localServerStatusElement) localServerStatusElement.style.display = 'block';
      }
    }

    async function testAiConnection() {
      let aiServiceToken = '';

      const isSavedToken = aiServiceTokenInput?.getAttribute('data-is-saved') === 'true';

      if (isSavedToken) {
        try {
          const { aiServiceToken: encryptedToken } = await chrome.storage.local.get('aiServiceToken');
          if (encryptedToken) {
            const result = await decrypt(encryptedToken);
            if (result.ok) {
              aiServiceToken = result.value;
            } else {
              const deErr = result.error;
              // If decryption failed due to session key mismatch, clear the "saved" flag
              // so the UI prompts the user to re-enter the token, surface a helpful message,
              // and return early rather than rethrowing (which produced duplicate logs).
              if (deErr && deErr.code === 'SESSION_KEY_MISMATCH') {
                logger$8.warn('Saved AI token could not be decrypted - clearing saved flag', 'connection-testing', deErr);
                // Remove saved token and mark input as not-saved to force re-entry
                try {
                  await chrome.storage.local.remove('aiServiceToken');
                } catch (e) {
                  logger$8.warn('Failed to remove corrupted saved AI token:', 'connection-testing', e);
                }
                if (aiServiceTokenInput) {
                  aiServiceTokenInput.removeAttribute('data-is-saved');
                  aiServiceTokenInput.value = '';
                }

                // Show a clear UI message and exit the flow so the user re-enters token
                if (testAiResultElement) {
                  testAiResultElement.textContent = '✗ Saved API token could not be decrypted (session key lost). Please re-enter your AI Service API token and save it again.';
                  testAiResultElement.className = 'status error';
                  testAiResultElement.style.display = 'block';
                }

                return; // stop further processing
              }

              // Other decryption errors - let outer catch handle/log them
              throw deErr;
            }
          }
        } catch (e) {
          logger$8.error('Failed to decrypt saved AI token:', 'connection-testing', e);
        }
      } else {
        aiServiceToken = aiServiceTokenInput ? aiServiceTokenInput.value.trim() : '';
      }

      if (!aiServiceToken) {
        testAiResultElement.textContent = 'Please enter an AI Service API token first';
        testAiResultElement.className = 'status error';
        testAiResultElement.style.display = 'block';
        return;
      }

      const permissionReady = await ensureAiEndpointPermission();
      if (!permissionReady) return;

      const activeModelRadio = document.querySelector('input[name="active-model"]:checked');
      const activeModelNum = activeModelRadio ? activeModelRadio.value : '1';
      const modelInput = document.getElementById(`ai-model-${activeModelNum}`);
      const activeModel = modelInput ? modelInput.value.trim() : '';

      if (testAiButton) {
        testAiButton.disabled = true;
        setLoadingState(testAiButton, 'Testing AI Service & Model...');
      }
      if (testAiResultElement) testAiResultElement.style.display = 'none';

      document.querySelectorAll('.model-option').forEach(el => {
        el.style.borderColor = '#e0e0e0';
      });

      try {
        const response = await sendMessageWithTimeout({
          action: 'testConnection',
          token: aiServiceToken,
          testModel: activeModel || undefined
        }, 15000);

        if (response.ok) {
          testAiResultElement.textContent = `✓ AI Service connection successful! Response time: ${response.data.responseTime}${activeModel ? `\n✓ Model "${activeModel}" is supported` : ''}`;
          testAiResultElement.className = 'status success';

          const activeModelOption = document.getElementById(`model-option-${activeModelNum}`);
          if (activeModelOption) {
            activeModelOption.style.borderColor = '#28a745';
          }
        } else {
          const errorMsg = response.error || 'Unknown error';
          testAiResultElement.textContent = `✗ AI Service connection failed: ${errorMsg}`;
          testAiResultElement.className = 'status error';

          if (errorMsg.includes('not supported') && activeModel) {
            testAiResultElement.textContent = `✗ Model "${activeModel}" is not supported by the AI service.\n\nPlease choose a different model or check with your administrator for supported models.`;
            const activeModelOption = document.getElementById(`model-option-${activeModelNum}`);
            if (activeModelOption) {
              activeModelOption.style.borderColor = '#dc3545';
            }
          }
        }
      } catch (error) {
        logger$8.error('Error testing AI connection:', 'connection-testing', error);
        if (error && error.code === 'SESSION_KEY_MISMATCH') {
          testAiResultElement.textContent = '✗ Saved API token could not be decrypted (session key lost). Please re-enter your AI Service API token and save it again.';
        } else {
          testAiResultElement.textContent = `✗ Error: ${error.message || 'Failed to connect to the AI service'}`;
        }
        testAiResultElement.className = 'status error';
      } finally {
        if (testAiResultElement) testAiResultElement.style.display = 'block';
        if (testAiButton) {
          testAiButton.disabled = false;
          testAiButton.textContent = 'Test AI Connection & Validate Model';
        }
      }
    }

    async function testAtlassianConnection() {
      let atlassianToken = '';
      const atlassianBaseUrl = atlassianBaseUrlInput ? atlassianBaseUrlInput.value.trim() : '';
      const atlassianEmail = atlassianEmailInput ? atlassianEmailInput.value.trim() : '';

      const isSavedToken = atlassianTokenInput?.getAttribute('data-is-saved') === 'true';

      if (isSavedToken) {
        try {
          const { atlassianToken: encryptedToken } = await chrome.storage.local.get('atlassianToken');
          if (encryptedToken) {
            const result = await decrypt(encryptedToken);
            if (result.ok) {
              atlassianToken = result.value;
            } else {
              const deErr = result.error;
              if (deErr && deErr.code === 'SESSION_KEY_MISMATCH') {
                logger$8.warn('Saved Atlassian token could not be decrypted - clearing saved flag', 'connection-testing', deErr);
                try {
                  await chrome.storage.local.remove('atlassianToken');
                } catch (e) {
                  logger$8.warn('Failed to remove corrupted saved Atlassian token:', 'connection-testing', e);
                }
                if (atlassianTokenInput) {
                  atlassianTokenInput.removeAttribute('data-is-saved');
                  atlassianTokenInput.value = '';
                }

                if (testAtlassianResultElement) {
                  testAtlassianResultElement.textContent = '✗ Saved Atlassian token could not be decrypted (session key lost). Please re-enter your Atlassian API token and save it again.';
                  testAtlassianResultElement.className = 'status error';
                  testAtlassianResultElement.style.display = 'block';
                }

                return;
              }

              throw deErr;
            }
          }
        } catch (e) {
          logger$8.error('Failed to decrypt saved Atlassian token:', 'connection-testing', e);
        }
      } else {
        atlassianToken = atlassianTokenInput ? atlassianTokenInput.value.trim() : '';
      }

      if (!atlassianToken) {
        testAtlassianResultElement.textContent = 'Please enter an Atlassian API token first';
        testAtlassianResultElement.className = 'status error';
        testAtlassianResultElement.style.display = 'block';
        return;
      }

      if (!atlassianBaseUrl) {
        testAtlassianResultElement.textContent = 'Please enter an Atlassian base URL first';
        testAtlassianResultElement.className = 'status error';
        testAtlassianResultElement.style.display = 'block';
        return;
      }

      if (!atlassianEmail) {
        testAtlassianResultElement.textContent = 'Please enter your Atlassian email address first';
        testAtlassianResultElement.className = 'status error';
        testAtlassianResultElement.style.display = 'block';
        return;
      }

      if (testAtlassianButton) {
        testAtlassianButton.disabled = true;
        setLoadingState(testAtlassianButton, 'Testing Atlassian Connection...');
      }
      if (testAtlassianResultElement) testAtlassianResultElement.style.display = 'none';

      try {
        const response = await sendMessageWithTimeout({
          action: 'testAtlassianConnection',
          atlassianToken,
          atlassianBaseUrl,
          atlassianEmail
        }, 45000);

        if (response.ok) {
          const details = response.data || {};
          testAtlassianResultElement.textContent = `Atlassian connection successful! Connected as: ${details.user} (${details.responseTime})`;
          testAtlassianResultElement.className = 'status success';
        } else {
          const baseMsg = response.error || 'Unknown error';
          let detailsMsg = '';
          if (response && response.details) {
            const code = response.details.statusCode;
            const body = response.details.responseBody;
            if (code) detailsMsg += ` Status: ${code}.`;
            if (body && verboseLoggingToggle && verboseLoggingToggle.checked) {
              detailsMsg += ` Response: ${body}`;
            } else if (body) {
              detailsMsg += ' (enable Verbose Logging to see response body)';
            }
          }

          testAtlassianResultElement.textContent = `Atlassian connection failed: ${baseMsg}${detailsMsg}`;
          testAtlassianResultElement.className = 'status error';
        }
      } catch (error) {
        logger$8.error('Error testing Atlassian connection:', 'connection-testing', error);
        testAtlassianResultElement.textContent = `Error: ${error.message || 'Failed to connect to Atlassian services'}`;
        testAtlassianResultElement.className = 'status error';
      } finally {
        if (testAtlassianResultElement) testAtlassianResultElement.style.display = 'block';
        if (testAtlassianButton) {
          testAtlassianButton.disabled = false;
          testAtlassianButton.textContent = 'Test Atlassian Connection';
        }
      }
    }

    return {
      checkLocalServer,
      testAiConnection,
      testAtlassianConnection
    };
  }

  function setLoadingState(button, text) {
    if (!button) return;
    button.replaceChildren();
    const spinner = document.createElement('span');
    spinner.className = 'loading';
    button.appendChild(spinner);
    button.appendChild(document.createTextNode(` ${text}`));
  }

  // modules/config/constants.js
  //
  // Centralized configuration constants for timeouts, intervals, and limits.
  // Import from here instead of using magic numbers throughout the codebase.


  /** Placeholder string displayed for saved tokens in the UI */
  const TOKEN_PLACEHOLDER = '••••••••••••••••';

  /** Timeout for message responses from the options page (ms) */
  const OPTIONS_MESSAGE_RESPONSE_TIMEOUT_MS = 45000;

  const logger$7 = createLogger('OptionsMessaging');

  // Wrapper for chrome.runtime.sendMessage with a timeout fallback
  function sendMessageWithTimeout(message, timeout = OPTIONS_MESSAGE_RESPONSE_TIMEOUT_MS) {
    return new Promise((resolve, reject) => {
      let done = false;
      const timer = setTimeout(() => {
        if (!done) {
          done = true;
          reject(new Error('No response from background (timeout)'));
        }
      }, timeout);

      try {
        chrome.runtime.sendMessage(message, (resp) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          const lastErr = chrome.runtime.lastError;
          if (lastErr) return reject(lastErr);
          resolve(resp);
        });
      } catch (err) {
        if (!done) {
          done = true;
          clearTimeout(timer);
          logger$7.warn('Message send failed', 'options-messaging', err);
          reject(err);
        }
      }
    });
  }

  // Helpers to request and check host permissions
  function requestHostPermission(origin) {
    return new Promise((resolve) => {
      if (!chrome.permissions) return resolve(false);
      chrome.permissions.request({ origins: [origin] }, (granted) => {
        resolve(!!granted);
      });
    });
  }

  function checkHostPermission(origin) {
    return new Promise((resolve) => {
      if (!chrome.permissions) return resolve(false);
      chrome.permissions.contains({ origins: [origin] }, (granted) => {
        resolve(!!granted);
      });
    });
  }

  function removeHostPermission(origin) {
    return new Promise((resolve) => {
      if (!chrome.permissions || !chrome.permissions.remove) return resolve(false);
      chrome.permissions.remove({ origins: [origin] }, (removed) => {
        resolve(!!removed);
      });
    });
  }

  /**
   * HTML Sanitization Module
   * Provides sanitization helpers for PandAid extension
   */

  createLogger('Sanitization');

  /**
   * Input Validation Module
   * Provides validation helpers for PandAid extension
   */

  const logger$6 = createLogger('Validation');

  /**
   * Validates an API token (basic format check)
   * @param {string} token - The API token to validate
   * @returns {{valid: boolean, error?: string}} Validation result
   */
  function validateApiToken(token) {
      if (!token || typeof token !== 'string') {
          return { valid: false, error: 'API token is required' };
      }

      const trimmed = token.trim();

      if (trimmed.length === 0) {
          return { valid: false, error: 'API token cannot be empty' };
      }

      if (trimmed.length < 10) {
          return { valid: false, error: 'API token appears too short (minimum 10 characters)' };
      }

      // Check for obviously invalid tokens
      if (trimmed === 'your-token-here' || trimmed === 'placeholder' || trimmed === 'xxx') {
          return { valid: false, error: 'Please enter a valid API token' };
      }

      return { valid: true };
  }

  /**
   * Validates Atlassian base URL
   * @param {string} input - The Company slug or Atlassian URL
   * @returns {{valid: boolean, error?: string, normalized?: string, slug?: string}} Validation result
   */
  function validateAtlassianUrl(input) {
      if (!input || typeof input !== 'string') {
          return { valid: false, error: 'Company slug or Atlassian URL is required' };
      }

      const trimmed = input.trim();

      if (trimmed.length === 0) {
          return { valid: false, error: 'Company slug or Atlassian URL cannot be empty' };
      }

      // Accept either a plain slug or an already-formed https://<slug>.atlassian.net URL
      const slugPattern = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
      let slugCandidate = trimmed;

      if (trimmed.includes('://')) {
          try {
              const parsed = new URL(trimmed);
              const host = (parsed.hostname || '').toLowerCase();
              if (!host.endsWith('.atlassian.net')) {
                  return {
                      valid: false,
                      error: 'Must be an Atlassian cloud domain (e.g., your-company.atlassian.net)'
                  };
              }
              slugCandidate = host.replace(/\.atlassian\.net$/, '');
          } catch (e) {
              logger$6.debug('Error parsing Atlassian URL candidate:', 'validation', e);
              return {
                  valid: false,
                  error: 'Enter a company slug (e.g., your-company) or full Atlassian URL (https://your-company.atlassian.net).'
              };
          }
      }

      if (!slugPattern.test(slugCandidate)) {
          return {
              valid: false,
              error: 'Company slug must be alphanumeric and may include hyphens (e.g., your-company)'
          };
      }

      const normalized = `https://${slugCandidate}.atlassian.net`;
      return { valid: true, normalized, slug: slugCandidate };
  }

  /**
   * Validates local search server URL
   * Only allows localhost or 127.0.0.1 for security (prevents SSRF attacks)
   * @param {string} url - The local search server URL
   * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
   */
  function validateLocalServerUrl(url) {
      if (!url || typeof url !== 'string') {
          return { valid: false, error: 'Local server URL is required' };
      }

      const trimmed = url.trim();

      if (trimmed.length === 0) {
          return { valid: false, error: 'Local server URL cannot be empty' };
      }

      // Security: Only allow localhost or 127.0.0.1 to prevent SSRF attacks
      const localPattern = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?\/?$/;

      if (!localPattern.test(trimmed)) {
          return {
              valid: false,
              error: 'URL must be localhost or 127.0.0.1 (e.g., http://127.0.0.1:5002). Remote servers are not allowed for security reasons.'
          };
      }

      // Normalize URL (remove trailing slash)
      const normalized = trimmed.replace(/\/$/, '');

      return { valid: true, normalized };
  }

  /**
   * Validates JIRA project key format
   * @param {string} key - The JIRA project key
   * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
   */
  function validateJiraProjectKey(key) {
      if (!key || typeof key !== 'string') {
          // Project key is optional
          return { valid: true, normalized: '' };
      }

      const trimmed = key.trim();

      if (trimmed.length === 0) {
          return { valid: true, normalized: '' };
      }

      // Convert to uppercase first
      const upper = trimmed.toUpperCase();

      // JIRA project keys must be uppercase letters only, 2-10 characters
      const jiraKeyPattern = /^[A-Z]{2,10}$/;

      if (!jiraKeyPattern.test(upper)) {
          return {
              valid: false,
              error: 'Project key must be 2-10 uppercase letters (e.g., IMP, PROJ)'
          };
      }

      return { valid: true, normalized: upper };
  }

  /**
   * Permissions and Configuration Module
   * Provides helper functions for managing API endpoints and permissions.
   */

  createLogger('Permissions');

  const logger$5 = createLogger('OptionsUtils');

  // Utility helpers used by the options page
  function buildOriginFromUrl(url) {
    try {
      // Allow users to enter scheme-less hosts like "127.0.0.1:5002" or "localhost:5002"
      let candidate = (url || '').trim();
      if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(candidate)) {
        candidate = 'http://' + candidate;
      }
      const parsed = new URL(candidate);
      const origin = `${parsed.protocol}//${parsed.hostname}${parsed.port ? `:${parsed.port}` : ''}/`;
      return origin;
    } catch (e) {
      logger$5.debug('Failed to build origin from URL:', 'options/utils', { url, error: e });
      return undefined;
    }
  }

  /**
   * Connection Controller
   * Manages connection testing for AI and Atlassian services.
   */

  class ConnectionController {
      constructor(elements, uiController) {
          this.elements = elements;
          this.uiController = uiController;

          // Initialize the helper
          const { checkLocalServer, testAiConnection, testAtlassianConnection } = createConnectionTesting({
              elements: elements,
              messaging: { sendMessageWithTimeout },
              permissions: { requestHostPermission, checkHostPermission, buildOriginFromUrl },
              helpers: { showSectionStatus }
          });

          this.checkLocalServer = checkLocalServer;
          this.testAiConnection = testAiConnection;
          this.testAtlassianConnection = testAtlassianConnection;

          this.attachListeners();
      }

      attachListeners() {
          const { testAiButton, testAtlassianButton, checkLocalServerButton } = this.elements;

          if (testAiButton) {
              testAiButton.addEventListener('click', this.testAiConnection);
          }

          if (testAtlassianButton) {
              testAtlassianButton.addEventListener('click', this.testAtlassianConnection);
          }

          if (checkLocalServerButton) {
              checkLocalServerButton.addEventListener('click', () => {
                  // This needs context binding if method uses `this`
                  this.checkLocalServer();
              });
          }
      }
  }

  function setupDataManagement({
      elements: {
          clearCacheButton,
          clearAllDataButton,
          // Fields to reset on Clear All
          aiServiceTokenInput,
          atlassianTokenInput,
          atlassianBaseUrlInput,
          atlassianEmailInput
      },
      helpers: {
          showStatus: showStatus$1 = showStatus,
          logger
      }
  }) {
      if (clearCacheButton) {
          clearCacheButton.addEventListener('click', () => handleClearCache(clearCacheButton, showStatus$1, logger));
      }

      if (clearAllDataButton) {
          clearAllDataButton.addEventListener('click', () => handleClearAllData({
              button: clearAllDataButton,
              showStatus: showStatus$1,
              logger,
              fields: {
                  aiServiceTokenInput,
                  atlassianTokenInput,
                  atlassianBaseUrlInput,
                  atlassianEmailInput
              }
          }));
      }
  }

  const removeLocalKeys = (keys) => new Promise((resolve, reject) => {
      chrome.storage.local.remove(keys, () => {
          const storageErr = chrome.runtime.lastError;
          if (storageErr) {
              reject(storageErr);
          } else {
              resolve();
          }
      });
  });

  async function handleClearCache(button, showStatus, logger) {
      // Confirmation step
      const confirmed = window.confirm('Are you sure you want to clear the extension cache? This will remove persisted search caches and request the background to clear in-memory caches. This action cannot be undone.');
      if (!confirmed) return;

      const keysToRemove = [
          'extensionResponseCache',
          'searchCache',
          'lastSearchResults',
          'localSearchCache'
      ];

      // Update UI immediately
      button.disabled = true;
      const originalText = button.textContent;
      button.textContent = 'Clearing...';

      try {
          await removeLocalKeys(keysToRemove);
          showStatus('Cache cleared successfully', 'success');
      } catch (storageErr) {
          logger?.error('Error clearing storage keys:', 'data-management', storageErr);
          showStatus(`Failed to clear cache: ${storageErr.message || storageErr}`, 'error');
      }

      // Tell background to clear any in-memory caches
      try {
          const resp = await sendMessageWithTimeout({ action: 'clearCache' }, 5000);
          logger?.info('Background clearCache response:', 'data-management', resp);
      } catch (err) {
          logger?.warn('Background did not acknowledge clearCache (or timed out):', 'data-management', err && err.message ? err.message : err);
      } finally {
          button.disabled = false;
          button.textContent = originalText;
      }
  }

  async function handleClearAllData({
      button,
      showStatus,
      logger,
      fields
  }) {
      // Double confirmation for destructive action
      const firstConfirm = window.confirm(
          'WARNING: This will permanently delete ALL extension data including:\n\n' +
          '• AI API keys\n' +
          '• Atlassian credentials\n' +
          '• Knowledge base entries\n' +
          '• All cached data\n' +
          '• All settings and preferences\n\n' +
          'You will need to reconfigure the extension from scratch.\n\n' +
          'Are you sure you want to continue?'
      );
      if (!firstConfirm) return;

      const secondConfirm = window.confirm(
          'FINAL CONFIRMATION\n\n' +
          'Type "yes" in your mind and click OK to permanently delete all data.\n' +
          'Click Cancel to abort.'
      );
      if (!secondConfirm) return;

      button.disabled = true;
      const originalText = button.textContent;
      button.textContent = 'Clearing...';

      try {
          // Clear all chrome.storage.local data
          await new Promise((resolve, reject) => {
              chrome.storage.local.clear(() => {
                  if (chrome.runtime.lastError) {
                      reject(chrome.runtime.lastError);
                  } else {
                      resolve();
                  }
              });
          });

          // Tell background to clear in-memory caches
          try {
              await sendMessageWithTimeout({ action: 'clearCache' }, 5000);
          } catch (err) {
              logger?.warn('Background clearCache notification failed:', 'data-management', err);
          }

          showStatus('All data cleared successfully. Please reconfigure the extension.', 'success');

          // Reset form fields to empty state
          if (fields.aiServiceTokenInput) {
              fields.aiServiceTokenInput.value = '';
              fields.aiServiceTokenInput.removeAttribute('data-is-saved');
          }
          if (fields.atlassianTokenInput) {
              fields.atlassianTokenInput.value = '';
              fields.atlassianTokenInput.removeAttribute('data-is-saved');
          }
          if (fields.atlassianBaseUrlInput) fields.atlassianBaseUrlInput.value = '';
          if (fields.atlassianEmailInput) fields.atlassianEmailInput.value = '';

          // Reload the page to reset all UI state
          setTimeout(() => {
              window.location.reload();
          }, 1500);

      } catch (error) {
          logger?.error('Error clearing all data:', 'data-management', error);
          showStatus(`Failed to clear data: ${error.message || error}`, 'error');
          button.disabled = false;
          button.textContent = originalText;
      }
  }

  const logger$4 = createLogger('DependencyManager');

  // Dependency warnings and toggle coordination for the options page.

  function createDependencyManager({ elements, helpers }) {
    const {
      aiGlobalEnable,
      aiJiraToggle,
      aiConfluenceToggle,
      aiCommunityToggle,
      showJiraExplanationsToggle,
      showConfluenceExplanationsToggle,
      showCommunityExplanationsToggle,
      aiFilterToggle,
      communityAiFilterToggle,
      advancedAiToggle,
      aiScoreSettings,
      communityAiScoreSettings,
      testAtlassianButton,
      testAiButton,
      aiServiceTokenInput,
      atlassianTokenInput,
      confluencePreloadToggle,
      jiraPreloadToggle: _jiraPreloadToggle,
      communityMinScoreSlider,
      aiModel1Input,
      aiModel2Input,
      aiModel3Input,
      apiEndpointInput
    } = elements;

    const { setAiMasterAvailability, showStatus, switchContext } = helpers;

    const dependencyWarnings = {};

    function createWarningElement() {
      const warningEl = document.createElement('p');
      warningEl.className = 'dependency-warning';
      warningEl.style.color = '#1a1b1b';
      warningEl.style.fontSize = '13px';
      warningEl.style.marginTop = '8px';
      warningEl.style.padding = '8px 12px';
      warningEl.style.backgroundColor = '#f5f5f5';
      warningEl.style.borderLeft = '3px solid #1a1b1b';
      warningEl.style.borderRadius = '0 4px 4px 0';
      warningEl.style.lineHeight = '1.4';
      warningEl.style.display = 'none';
      return warningEl;
    }

    function createContextWarning(message) {
      const warning = document.createElement('div');
      warning.className = 'context-warning';
      warning.innerHTML = message;
      warning.style.padding = '10px 12px';
      warning.style.marginBottom = '15px';
      warning.style.backgroundColor = '#f5f5f5';
      warning.style.borderLeft = '3px solid #1a1b1b';
      warning.style.borderRadius = '0 4px 4px 0';
      warning.style.fontSize = '13px';
      warning.style.lineHeight = '1.4';
      return warning;
    }

    function showDependencyWarning(toggleElement, message) {
      if (!toggleElement) return;

      const toggleId = typeof toggleElement === 'string' ? toggleElement : (toggleElement.id || 'unknown-toggle');

      if (!dependencyWarnings[toggleId]) {
        const warningEl = createWarningElement();
        try {
          if (toggleElement && typeof toggleElement.closest === 'function') {
            const parentLabel = toggleElement.closest('.toggle-switch');
            if (parentLabel && parentLabel.parentNode) {
              parentLabel.parentNode.insertBefore(warningEl, parentLabel.nextSibling);
            } else {
              document.body.appendChild(warningEl);
            }
          } else {
            document.body.appendChild(warningEl);
          }
        } catch (e) {
          logger$4.debug('Error inserting dependency warning:', 'dependency-manager', e);
          document.body.appendChild(warningEl);
        }

        dependencyWarnings[toggleId] = warningEl;
      }

      dependencyWarnings[toggleId].textContent = message;
      dependencyWarnings[toggleId].style.display = 'block';
    }

    function hideDependencyWarning(toggleId) {
      const id = typeof toggleId === 'string' ? toggleId : (toggleId && toggleId.id ? toggleId.id : null);
      if (!id) return;
      if (dependencyWarnings[id]) {
        dependencyWarnings[id].style.display = 'none';
      }
    }

    function manageDependencies() {
      if (aiGlobalEnable && !aiGlobalEnable.checked) {
        setAiMasterAvailability(false);
        return;
      }

      if (aiJiraToggle && aiJiraToggle.checked && atlassianTokenInput) {
        if (!atlassianTokenInput.value.trim()) {
          showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
        } else {
          hideDependencyWarning('ai-jira-toggle');
        }
      } else {
        hideDependencyWarning('ai-jira-toggle');
      }

      if (aiConfluenceToggle && aiConfluenceToggle.checked && atlassianTokenInput) {
        if (!atlassianTokenInput.value.trim()) {
          showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
        } else {
          hideDependencyWarning('ai-confluence-toggle');
        }
      } else {
        hideDependencyWarning('ai-confluence-toggle');
      }

      if (confluencePreloadToggle && confluencePreloadToggle.checked && atlassianTokenInput) {
        if (!atlassianTokenInput.value.trim()) {
          showDependencyWarning(confluencePreloadToggle, 'Confluence preload requires a JIRA API token (used for Confluence too).');
        } else {
          hideDependencyWarning('confluence-preload-toggle');
        }
      } else {
        hideDependencyWarning('confluence-preload-toggle');
      }

      if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked) {
        if (!aiJiraToggle.checked) {
          showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
        } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
          showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
        } else {
          hideDependencyWarning('show-jira-explanations-toggle');
        }
      } else {
        hideDependencyWarning('show-jira-explanations-toggle');
      }

      if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked) {
        if (!aiConfluenceToggle.checked) {
          showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
        } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
          showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
        } else {
          hideDependencyWarning('show-confluence-explanations-toggle');
        }
      } else {
        hideDependencyWarning('show-confluence-explanations-toggle');
      }

      if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked) {
        if (!aiCommunityToggle.checked) {
          showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
        } else {
          hideDependencyWarning('show-community-explanations-toggle');
        }
      } else {
        hideDependencyWarning('show-community-explanations-toggle');
      }

      // Knowledge Base AI enhancement dependencies
      if (aiCommunityToggle) {
        // Check both AI token and community guides availability
        chrome.storage.local.get(['communityGuides'], (result) => {
          const hasGuides = result.communityGuides && result.communityGuides.length > 0;
          const hasAiToken = aiServiceTokenInput && aiServiceTokenInput.value.trim();

          // Disable the toggle if either requirement is not met
          if (!hasAiToken || !hasGuides) {
            aiCommunityToggle.disabled = true;
            aiCommunityToggle.style.opacity = '0.5';
            aiCommunityToggle.style.cursor = 'not-allowed';

            // Also disable related elements
            if (showCommunityExplanationsToggle) {
              showCommunityExplanationsToggle.disabled = true;
              showCommunityExplanationsToggle.style.opacity = '0.5';
              showCommunityExplanationsToggle.style.cursor = 'not-allowed';
            }
            if (communityAiScoreSettings) {
              communityAiScoreSettings.style.opacity = '0.5';
              communityAiScoreSettings.style.pointerEvents = 'none';
            }
            if (communityMinScoreSlider) {
              communityMinScoreSlider.disabled = true;
            }

            // Show appropriate warning
            if (aiCommunityToggle.checked) {
              if (!hasAiToken && !hasGuides) {
                showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires both an AI Service token and uploaded Knowledge Base JSON data.');
              } else if (!hasAiToken) {
                showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires an AI Service token.');
              } else if (!hasGuides) {
                showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires Knowledge Base JSON data to be uploaded.');
              }
            }
          } else {
            aiCommunityToggle.disabled = false;
            aiCommunityToggle.style.opacity = '1';
            aiCommunityToggle.style.cursor = 'pointer';

            if (showCommunityExplanationsToggle) {
              showCommunityExplanationsToggle.disabled = false;
              showCommunityExplanationsToggle.style.opacity = '1';
              showCommunityExplanationsToggle.style.cursor = 'pointer';
            }
            if (communityAiScoreSettings) {
              communityAiScoreSettings.style.opacity = '1';
              communityAiScoreSettings.style.pointerEvents = 'auto';
            }
            if (communityMinScoreSlider) {
              communityMinScoreSlider.disabled = false;
            }

            hideDependencyWarning('ai-community-toggle');
          }
        });
      }

      if (advancedAiToggle && advancedAiToggle.checked && aiServiceTokenInput) {
        if (!aiServiceTokenInput.value.trim()) {
          showDependencyWarning(advancedAiToggle, 'Advanced AI settings require an AI Service API token.');
        } else {
          hideDependencyWarning('advanced-ai-toggle');
        }
      } else {
        hideDependencyWarning('advanced-ai-toggle');
      }

      if (testAtlassianButton && atlassianTokenInput) {
        testAtlassianButton.disabled = !atlassianTokenInput.value.trim();
      }

      if (testAiButton && aiServiceTokenInput) {
        const hasToken = aiServiceTokenInput.value.trim();
        const hasEndpoint = apiEndpointInput && apiEndpointInput.value.trim();
        const hasAtLeastOneModel = (aiModel1Input && aiModel1Input.value.trim()) ||
          (aiModel2Input && aiModel2Input.value.trim()) ||
          (aiModel3Input && aiModel3Input.value.trim());

        const isConfigured = hasToken && hasEndpoint && hasAtLeastOneModel;
        testAiButton.disabled = !isConfigured;

        // Visual feedback
        if (!isConfigured) {
          testAiButton.style.opacity = '0.5';
          testAiButton.style.cursor = 'not-allowed';
        } else {
          testAiButton.style.opacity = '1';
          testAiButton.style.cursor = 'pointer';
        }
      }
    }

    function setupDependencyListeners() {
      if (advancedAiToggle) {
        advancedAiToggle.addEventListener('change', () => {
          if (helpers.advancedAiSettings) {
            helpers.advancedAiSettings.style.display = advancedAiToggle.checked ? 'block' : 'none';
          }
          manageDependencies();
        });
      }

      if (aiJiraToggle) {
        aiJiraToggle.addEventListener('change', () => {
          if (!aiJiraToggle.checked) {
            const anyAtlassianAiEnabled =
              (aiJiraToggle && aiJiraToggle.checked) ||
              (aiConfluenceToggle && aiConfluenceToggle.checked);

            if (!anyAtlassianAiEnabled && aiFilterToggle && aiFilterToggle.checked) {
              aiFilterToggle.checked = false;
              if (aiScoreSettings) aiScoreSettings.style.display = 'none';
              showStatus('Atlassian AI filtering disabled because no Atlassian AI enhancement is enabled.', 'info');
            }

            if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked) {
              showJiraExplanationsToggle.checked = false;
              showStatus('JIRA explanations disabled because AI JIRA enhancement is disabled.', 'info');
            }
          }

          if (aiJiraToggle.checked && atlassianTokenInput && !atlassianTokenInput.value.trim()) {
            showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
            aiJiraToggle.checked = false;
            showStatus('JIRA API token is required for AI JIRA enhancement', 'error');
          } else {
            hideDependencyWarning('ai-jira-toggle');
          }

          if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked && !aiJiraToggle.checked) {
            showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
          } else {
            hideDependencyWarning('show-jira-explanations-toggle');
          }

          const jiraPanel = document.getElementById('settings-jira');
          if (jiraPanel && jiraPanel.style.display === 'block' && switchContext) {
            switchContext('jira');
          }

          manageDependencies();
        });
      }

      if (aiConfluenceToggle) {
        aiConfluenceToggle.addEventListener('change', () => {
          if (!aiConfluenceToggle.checked) {
            const anyAtlassianAiEnabled =
              (aiJiraToggle && aiJiraToggle.checked) ||
              (aiConfluenceToggle && aiConfluenceToggle.checked);

            if (!anyAtlassianAiEnabled && aiFilterToggle && aiFilterToggle.checked) {
              aiFilterToggle.checked = false;
              if (aiScoreSettings) aiScoreSettings.style.display = 'none';
              showStatus('Atlassian AI filtering disabled because no Atlassian AI enhancement is enabled.', 'info');
            }

            if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked) {
              showConfluenceExplanationsToggle.checked = false;
              showStatus('Confluence explanations disabled because AI Confluence enhancement is disabled.', 'info');
            }
          }

          if (aiConfluenceToggle.checked && atlassianTokenInput && !atlassianTokenInput.value.trim()) {
            showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
            aiConfluenceToggle.checked = false;
            showStatus('JIRA API token is required for AI Confluence enhancement', 'error');
          } else {
            hideDependencyWarning('ai-confluence-toggle');
          }

          if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked && !aiConfluenceToggle.checked) {
            showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
          } else {
            hideDependencyWarning('show-confluence-explanations-toggle');
          }

          const confluencePanel = document.getElementById('settings-confluence');
          if (confluencePanel && confluencePanel.style.display === 'block' && switchContext) {
            switchContext('confluence');
          }

          manageDependencies();
        });
      }

      if (aiCommunityToggle) {
        aiCommunityToggle.addEventListener('change', () => {
          if (!aiCommunityToggle.checked) {
            if (communityAiFilterToggle && communityAiFilterToggle.checked) {
              communityAiFilterToggle.checked = false;
              if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
              showStatus('Community AI filtering disabled because Community AI enhancement is disabled.', 'info');
            }

            if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked) {
              showCommunityExplanationsToggle.checked = false;
              showStatus('Community Guide explanations disabled because AI Community enhancement is disabled.', 'info');
            }
          }

          if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked && !aiCommunityToggle.checked) {
            showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
          } else {
            hideDependencyWarning('show-community-explanations-toggle');
          }

          const communityPanel = document.getElementById('settings-community-guides');
          if (communityPanel && communityPanel.style.display === 'block' && switchContext) {
            switchContext('community-guides');
          }

          manageDependencies();
        });
      }

      if (showJiraExplanationsToggle) {
        showJiraExplanationsToggle.addEventListener('change', () => {
          if (showJiraExplanationsToggle.checked) {
            if (!aiJiraToggle.checked) {
              showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
              showJiraExplanationsToggle.checked = false;
              showStatus('JIRA explanations require AI JIRA enhancement to be enabled', 'error');
            } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
              showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
              showJiraExplanationsToggle.checked = false;
              showStatus('JIRA API token is required for JIRA explanations', 'error');
            } else {
              hideDependencyWarning('show-jira-explanations-toggle');
            }
          } else {
            hideDependencyWarning('show-jira-explanations-toggle');
          }
        });
      }

      if (showConfluenceExplanationsToggle) {
        showConfluenceExplanationsToggle.addEventListener('change', () => {
          if (showConfluenceExplanationsToggle.checked) {
            if (!aiConfluenceToggle.checked) {
              showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
              showConfluenceExplanationsToggle.checked = false;
              showStatus('Confluence explanations require AI Confluence enhancement to be enabled', 'error');
            } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
              showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
              showConfluenceExplanationsToggle.checked = false;
              showStatus('JIRA API token is required for Confluence explanations', 'error');
            } else {
              hideDependencyWarning('show-confluence-explanations-toggle');
            }
          } else {
            hideDependencyWarning('show-confluence-explanations-toggle');
          }
        });
      }

      if (showCommunityExplanationsToggle) {
        showCommunityExplanationsToggle.addEventListener('change', () => {
          if (showCommunityExplanationsToggle.checked) {
            if (!aiCommunityToggle.checked) {
              showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
            } else {
              hideDependencyWarning('show-community-explanations-toggle');
            }
          } else {
            hideDependencyWarning('show-community-explanations-toggle');
          }
        });
      }

      if (aiServiceTokenInput) {
        aiServiceTokenInput.addEventListener('input', function () {
          if (advancedAiToggle && advancedAiToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(advancedAiToggle, 'Advanced AI settings require an AI Service API token.');
            } else {
              hideDependencyWarning('advanced-ai-toggle');
            }
          }
          manageDependencies();
        });
      }

      if (apiEndpointInput) {
        apiEndpointInput.addEventListener('input', () => {
          manageDependencies();
        });
      }

      if (aiModel1Input) {
        aiModel1Input.addEventListener('input', () => {
          manageDependencies();
        });
      }

      if (aiModel2Input) {
        aiModel2Input.addEventListener('input', () => {
          manageDependencies();
        });
      }

      if (aiModel3Input) {
        aiModel3Input.addEventListener('input', () => {
          manageDependencies();
        });
      }

      if (atlassianTokenInput) {
        atlassianTokenInput.addEventListener('input', function () {
          if (aiJiraToggle && aiJiraToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
            } else {
              hideDependencyWarning('ai-jira-toggle');
            }
          }

          if (aiConfluenceToggle && aiConfluenceToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
            } else {
              hideDependencyWarning('ai-confluence-toggle');
            }
          }

          if (confluencePreloadToggle && confluencePreloadToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(confluencePreloadToggle, 'Confluence preload requires a JIRA API token (used for Confluence too).');
            } else {
              hideDependencyWarning('confluence-preload-toggle');
            }
          }

          if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked && aiJiraToggle && aiJiraToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
            } else {
              hideDependencyWarning('show-jira-explanations-toggle');
            }
          }

          if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked && aiConfluenceToggle && aiConfluenceToggle.checked) {
            if (!this.value.trim()) {
              showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
            } else {
              hideDependencyWarning('show-confluence-explanations-toggle');
            }
          }

          if (testAtlassianButton) {
            testAtlassianButton.disabled = !this.value.trim();
          }
        });
      }

      if (aiGlobalEnable) {
        aiGlobalEnable.addEventListener('change', () => {
          if (helpers.aiTestSection) {
            helpers.aiTestSection.style.display = aiGlobalEnable.checked ? 'block' : 'none';
          }
          setAiMasterAvailability(!!aiGlobalEnable.checked);
          if (!aiGlobalEnable.checked) {
            showStatus('Global AI is disabled; AI-dependent toggles are unavailable until enabled.', 'info');
          }
        });
      }
    }

    return {
      createContextWarning,
      manageDependencies,
      setupDependencyListeners,
      showDependencyWarning,
      hideDependencyWarning
    };
  }

  /**
   * Helper utilities for settings persistence.
   */


  function buildSettingsToSave({ elements, values }) {
    const {
      jiraPreloadToggle,
      confluencePreloadToggle,
      communityPreloadToggle,
      jiraMinScoreSlider,
      communityMinScoreSlider,
      confluenceMinScoreSlider,
      showJiraExplanationsToggle,
      showConfluenceExplanationsToggle,
      showCommunityExplanationsToggle,
      aiJiraToggle,
      aiConfluenceToggle,
      aiCommunityToggle,
      aiModel1Input,
      aiModel2Input,
      aiModel3Input,
      activeModel1Radio,
      activeModel2Radio,
      activeModel3Radio,
      summaryTempSlider,
      summaryTopPSlider,
      summaryTopKSlider,
      communityTempSlider,
      communityTopPSlider,
      communityTopKSlider,
      jiraTempSlider,
      jiraTopPSlider,
      jiraTopKSlider,
      confluenceTempSlider,
      confluenceTopPSlider,
      confluenceTopKSlider,
      verboseLoggingToggle,
      localSearchUrlInput,
      localSearchEnableToggle,
      knowledgeBaseEntryLabelInput,
      knowledgeBaseSidebarLabelInput,
      sidebarJiraToggle,
      sidebarConfluenceToggle,
      sidebarCommunityToggle,
      sidebarWidthSlider,
      buttonLabelInput,
      sidebarLabelInput
    } = elements;

    const {
      apiEndpoint,
      aiEnabled,
      atlassianBaseUrl,
      atlassianEmail,
      jiraProjectKey,
      disableTokenEncryption
    } = values;

    return {
      apiEndpoint: apiEndpoint || null,
      aiEnabled,
      atlassianBaseUrl: atlassianBaseUrl || null,
      atlassianEmail: atlassianEmail || null,
      jiraProjectKey: jiraProjectKey || null,
      disableTokenEncryption: !!disableTokenEncryption,
      preloadSettings: {
        jira: jiraPreloadToggle.checked,
        confluence: confluencePreloadToggle.checked,
        community: communityPreloadToggle.checked,
        knowledgeBase: communityPreloadToggle.checked,
        enableAiFilter: true,
        enableAtlassianAiFilter: true,
        enableCommunityAiFilter: true,
        jiraMinScore: parseInt(jiraMinScoreSlider.value),
        communityMinScore: parseInt(communityMinScoreSlider.value),
        confluenceMinScore: parseInt(confluenceMinScoreSlider.value)
      },
      aiEnhancementSettings: {
        jira: aiJiraToggle.checked,
        confluence: aiConfluenceToggle.checked,
        community: aiCommunityToggle.checked,
        showExplanations: {
          jira: showJiraExplanationsToggle.checked,
          confluence: showConfluenceExplanationsToggle.checked,
          community: showCommunityExplanationsToggle.checked
        },
        userToggled: {
          jira: !!aiJiraToggle && aiJiraToggle.checked,
          confluence: !!aiConfluenceToggle && aiConfluenceToggle.checked,
          community: !!aiCommunityToggle && aiCommunityToggle.checked
        }
      },
      advancedAiSettings: {
        models: {
          model1: aiModel1Input ? aiModel1Input.value.trim() : '',
          model2: aiModel2Input ? aiModel2Input.value.trim() : '',
          model3: aiModel3Input ? aiModel3Input.value.trim() : ''
        },
        activeModel: activeModel1Radio?.checked ? 1 : (activeModel2Radio?.checked ? 2 : (activeModel3Radio?.checked ? 3 : 1)),
        contextSettings: {
          caseSummary: {
            temperature: parseFloat((summaryTempSlider.value / 100).toFixed(2)),
            topP: parseFloat((summaryTopPSlider.value / 100).toFixed(2)),
            topK: parseInt(summaryTopKSlider.value)
          },
          communityGuides: {
            temperature: parseFloat((communityTempSlider.value / 100).toFixed(2)),
            topP: parseFloat((communityTopPSlider.value / 100).toFixed(2)),
            topK: parseInt(communityTopKSlider.value)
          },
          jira: {
            temperature: parseFloat((jiraTempSlider.value / 100).toFixed(2)),
            topP: parseFloat((jiraTopPSlider.value / 100).toFixed(2)),
            topK: parseInt(jiraTopKSlider.value)
          },
          confluence: {
            temperature: parseFloat((confluenceTempSlider.value / 100).toFixed(2)),
            topP: parseFloat((confluenceTopPSlider.value / 100).toFixed(2)),
            topK: parseInt(confluenceTopKSlider.value)
          }
        }
      },
      verboseLogging: verboseLoggingToggle && verboseLoggingToggle.checked,
      localSearchServerUrl: localSearchUrlInput && localSearchUrlInput.value ? localSearchUrlInput.value.trim() : undefined,
      localSearchEnabled: localSearchEnableToggle && localSearchEnableToggle.checked,
      knowledgeBaseLabels: {
        entryLabel: (knowledgeBaseEntryLabelInput && knowledgeBaseEntryLabelInput.value.trim()) || 'Knowledge Base',
        sidebarLabel: (knowledgeBaseSidebarLabelInput && knowledgeBaseSidebarLabelInput.value.trim()) ||
          (knowledgeBaseEntryLabelInput && knowledgeBaseEntryLabelInput.value.trim()) ||
          'Knowledge Base'
      },
      sidebarSections: {
        jira: sidebarJiraToggle ? sidebarJiraToggle.checked : true,
        confluence: sidebarConfluenceToggle ? sidebarConfluenceToggle.checked : true,
        community: sidebarCommunityToggle ? sidebarCommunityToggle.checked : true
      },
      sidebarWidth: sidebarWidthSlider ? parseInt(sidebarWidthSlider.value) : 500,
      buttonLabel: (buttonLabelInput && buttonLabelInput.value.trim()) || 'PandAid',
      sidebarLabel: (sidebarLabelInput && sidebarLabelInput.value.trim()) || 'PandAid Case Assistant'
    };
  }

  function applyLoadedSettings({
    data,
    elements,
    helpers,
    aiHelpers,
    logger
  }) {
    const {
      apiEndpointInput,
      aiServiceTokenInput,
      aiGlobalEnable,
      atlassianTokenInput,
      atlassianBaseUrlInput,
      atlassianEmailInput,
      jiraProjectKeyInput,
      knowledgeBaseEntryLabelInput,
      knowledgeBaseSidebarLabelInput,
      disableTokenEncryptionToggle,
      showJiraExplanationsToggle,
      showConfluenceExplanationsToggle,
      showCommunityExplanationsToggle,
      aiJiraToggle,
      aiConfluenceToggle,
      aiCommunityToggle,
      atlassianAiScoreSettings,
      communityAiScoreSettings,
      jiraPreloadToggle,
      confluencePreloadToggle,
      communityPreloadToggle,
      jiraMinScoreSlider,
      communityMinScoreSlider,
      confluenceMinScoreSlider,
      jiraScoreValue,
      communityScoreValue,
      confluenceScoreValue,
      sidebarJiraToggle,
      sidebarConfluenceToggle,
      sidebarCommunityToggle,
      aiModel1Input,
      aiModel2Input,
      aiModel3Input,
      activeModel1Radio,
      activeModel2Radio,
      activeModel3Radio,
      summaryTempSlider,
      summaryTopPSlider,
      summaryTopKSlider,
      summaryTempValue,
      summaryTopPValue,
      summaryTopKValue,
      communityTempSlider,
      communityTopPSlider,
      communityTopKSlider,
      communityTempValue,
      communityTopPValue,
      communityTopKValue,
      jiraTempSlider,
      jiraTopPSlider,
      jiraTopKSlider,
      jiraTempValue,
      jiraTopPValue,
      jiraTopKValue,
      confluenceTempSlider,
      confluenceTopPSlider,
      confluenceTopKSlider,
      confluenceTempValue,
      confluenceTopPValue,
      confluenceTopKValue,
      testAiResultElement: _testAiResultElement,
      aiTestSection,
      localSearchUrlInput,
      localSearchEnableToggle,
      checkLocalServerButton,
      verboseLoggingToggle,
      searchModeAiVector,
      searchModeKeyword,
      searchModeKeywordVector,
      sidebarWidthSlider,
      sidebarWidthValue,
      toggleAiTokenButton,
      toggleAtlassianTokenButton,
      aiFilterToggle,
      communityAiFilterToggle,
      advancedAiSettings,
      buttonLabelInput,
      sidebarLabelInput
    } = elements;

    const {
      updateToggleVisibility,
      updateToggleIcon,
      setAiMasterAvailability,
      applyKnowledgeBaseLabels,
      initializeDefaultContextSettings
    } = helpers;

    const { sliderGroups } = aiHelpers;

    if (data.apiEndpoint) apiEndpointInput.value = data.apiEndpoint;

    if (data.aiServiceToken) {
      aiServiceTokenInput.value = TOKEN_PLACEHOLDER;
      aiServiceTokenInput.type = 'password';
      updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
      aiServiceTokenInput.setAttribute('data-is-saved', 'true');
      updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, true);
    } else {
      updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
      updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
    }

    if (aiGlobalEnable) {
      try {
        aiGlobalEnable.checked = (typeof data.aiEnabled === 'boolean') ? data.aiEnabled : true;
      } catch (e) {
        logger.debug('Error setting aiGlobalEnable:', 'settings-persistence-helpers', e);
        aiGlobalEnable.checked = true;
      }
    }

    if (aiTestSection && aiGlobalEnable) {
      aiTestSection.style.display = aiGlobalEnable.checked ? 'block' : 'none';
    }
    setAiMasterAvailability(!!(aiGlobalEnable && aiGlobalEnable.checked));

    if (data.atlassianToken) {
      atlassianTokenInput.value = TOKEN_PLACEHOLDER;
      atlassianTokenInput.type = 'password';
      updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);
      atlassianTokenInput.setAttribute('data-is-saved', 'true');
      updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, true);
    } else {
      updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
      updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);

      if (jiraPreloadToggle) jiraPreloadToggle.checked = false;
      if (confluencePreloadToggle) confluencePreloadToggle.checked = false;
      if (aiJiraToggle) aiJiraToggle.checked = false;
      if (aiConfluenceToggle) aiConfluenceToggle.checked = false;
      if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = false;
      if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = false;
    }

    const deriveAtlassianSlug = (baseUrl) => {
      try {
        const u = new URL(baseUrl);
        const host = u.hostname || '';
        if (host.endsWith('.atlassian.net')) {
          return host.replace(/\.atlassian\.net$/i, '');
        }
      } catch (e) {
        logger.debug('Error deriving Atlassian slug:', 'settings-persistence-helpers', { error: e, baseUrl });
      }
      return baseUrl || '';
    };

    if (atlassianBaseUrlInput) {
      atlassianBaseUrlInput.value = data.atlassianBaseUrl ? deriveAtlassianSlug(data.atlassianBaseUrl) : '';
    }
    if (data.atlassianEmail) atlassianEmailInput.value = data.atlassianEmail;
    if (disableTokenEncryptionToggle) {
      disableTokenEncryptionToggle.checked = !!data.disableTokenEncryption;
    }

    if (data.localSearchServerUrl && localSearchUrlInput) {
      localSearchUrlInput.value = data.localSearchServerUrl;
    }

    if (typeof data.localSearchEnabled === 'boolean') {
      if (localSearchEnableToggle) localSearchEnableToggle.checked = data.localSearchEnabled;
    } else if (localSearchEnableToggle) {
      localSearchEnableToggle.checked = false;
    }

    const knowledgeBaseLabels = {
      entryLabel: data.knowledgeBaseLabels?.entryLabel || 'Knowledge Base',
      sidebarLabel: data.knowledgeBaseLabels?.sidebarLabel || data.knowledgeBaseLabels?.entryLabel || 'Knowledge Base'
    };
    if (knowledgeBaseEntryLabelInput) knowledgeBaseEntryLabelInput.value = knowledgeBaseLabels.entryLabel;
    if (knowledgeBaseSidebarLabelInput) knowledgeBaseSidebarLabelInput.value = knowledgeBaseLabels.sidebarLabel;
    if (applyKnowledgeBaseLabels) applyKnowledgeBaseLabels(knowledgeBaseLabels);

    if (checkLocalServerButton && localSearchEnableToggle) {
      checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
    }

    try {
      chrome.storage.local.get({ searchSettings: { mode: 'keyword' } }, (ss) => {
        try {
          const mode = (ss && ss.searchSettings && ss.searchSettings.mode) ? ss.searchSettings.mode : 'keyword';
          if (mode === 'generative') {
            if (searchModeAiVector) searchModeAiVector.checked = true;
          } else if (mode === 'vector') {
            if (searchModeKeywordVector) searchModeKeywordVector.checked = true;
          } else {
            if (searchModeKeyword) searchModeKeyword.checked = true;
          }
        } catch (innerErr) {
          logger.warn('Error applying searchSettings.mode:', 'settings-persistence', innerErr);
          if (searchModeKeyword) searchModeKeyword.checked = true;
        }
      });
    } catch (err) {
      logger.warn('Error loading searchSettings.mode:', 'settings-persistence', err);
      if (searchModeKeyword) searchModeKeyword.checked = true;
    }

    if (data.jiraProjectKey) jiraProjectKeyInput.value = data.jiraProjectKey;

    if (data.preloadSettings) {
      const hasAtlassianToken = data.atlassianToken && data.atlassianToken.trim().length > 0;
      const preload = data.preloadSettings || {};

      if (jiraPreloadToggle) {
        jiraPreloadToggle.checked = hasAtlassianToken ? preload.jira !== false : false;
      }

      if (confluencePreloadToggle) {
        confluencePreloadToggle.checked = hasAtlassianToken ? preload.confluence !== false : false;
      }

      const communityPreloadSetting = (typeof preload.community !== 'undefined')
        ? preload.community !== false
        : preload.knowledgeBase !== false;
      if (communityPreloadToggle) communityPreloadToggle.checked = communityPreloadSetting;

      if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'block';
      if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'block';

      if (jiraMinScoreSlider) {
        jiraMinScoreSlider.value = preload.jiraMinScore || 50;
        if (jiraScoreValue) jiraScoreValue.textContent = `${jiraMinScoreSlider.value}%`;
      }

      if (communityMinScoreSlider) {
        communityMinScoreSlider.value = preload.communityMinScore || 50;
        if (communityScoreValue) communityScoreValue.textContent = `${communityMinScoreSlider.value}%`;
      }

      if (confluenceMinScoreSlider) {
        confluenceMinScoreSlider.value = preload.confluenceMinScore || 50;
        if (confluenceScoreValue) confluenceScoreValue.textContent = `${confluenceMinScoreSlider.value}%`;
      }
    } else {
      if (jiraPreloadToggle) jiraPreloadToggle.checked = false;
      if (confluencePreloadToggle) confluencePreloadToggle.checked = false;
      if (communityPreloadToggle) communityPreloadToggle.checked = false;
      if (aiFilterToggle) aiFilterToggle.checked = false;
      if (communityAiFilterToggle) communityAiFilterToggle.checked = false;
      if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'none';
      if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
    }

    if (typeof data.verboseLogging === 'boolean') {
      if (verboseLoggingToggle) verboseLoggingToggle.checked = data.verboseLogging;
    } else if (verboseLoggingToggle) {
      verboseLoggingToggle.checked = false;
    }

    if (data.aiEnhancementSettings) {
      const hasAtlassianToken = data.atlassianToken && data.atlassianToken.trim().length > 0;

      if (aiJiraToggle) {
        aiJiraToggle.checked = hasAtlassianToken ? data.aiEnhancementSettings.jira !== false : false;
      }

      if (aiConfluenceToggle) {
        aiConfluenceToggle.checked = hasAtlassianToken ? data.aiEnhancementSettings.confluence !== false : false;
      }

      if (aiCommunityToggle) {
        aiCommunityToggle.checked = data.aiEnhancementSettings.community !== false;
      }

      if (data.aiEnhancementSettings.showExplanations && typeof data.aiEnhancementSettings.showExplanations === 'object') {
        const hasToken = data.atlassianToken && data.atlassianToken.trim().length > 0;

        if (showJiraExplanationsToggle) {
          showJiraExplanationsToggle.checked = hasToken && aiJiraToggle && aiJiraToggle.checked
            ? data.aiEnhancementSettings.showExplanations.jira !== false
            : false;
        }

        if (showConfluenceExplanationsToggle) {
          showConfluenceExplanationsToggle.checked = hasToken && aiConfluenceToggle && aiConfluenceToggle.checked
            ? data.aiEnhancementSettings.showExplanations.confluence !== false
            : false;
        }

        if (showCommunityExplanationsToggle) {
          showCommunityExplanationsToggle.checked = aiCommunityToggle && aiCommunityToggle.checked
            ? data.aiEnhancementSettings.showExplanations.community !== false
            : false;
        }
      } else {
        const showExplanations = data.aiEnhancementSettings.showExplanations === true;
        const hasToken = data.atlassianToken && data.atlassianToken.trim().length > 0;
        if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = showExplanations && hasToken && aiJiraToggle && aiJiraToggle.checked;
        if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = showExplanations && hasToken && aiConfluenceToggle && aiConfluenceToggle.checked;
        if (showCommunityExplanationsToggle) showCommunityExplanationsToggle.checked = showExplanations && aiCommunityToggle && aiCommunityToggle.checked;
      }
    } else {
      if (aiJiraToggle) aiJiraToggle.checked = false;
      if (aiConfluenceToggle) aiConfluenceToggle.checked = false;
      if (aiCommunityToggle) aiCommunityToggle.checked = false;
      if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = false;
      if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = false;
      if (showCommunityExplanationsToggle) showCommunityExplanationsToggle.checked = false;
      setAiMasterAvailability(!!aiGlobalEnable && aiGlobalEnable.checked);
    }

    const sidebarSections = data.sidebarSections || {};
    if (sidebarJiraToggle) sidebarJiraToggle.checked = sidebarSections.jira !== false;
    if (sidebarConfluenceToggle) sidebarConfluenceToggle.checked = sidebarSections.confluence !== false;
    if (sidebarCommunityToggle) sidebarCommunityToggle.checked = sidebarSections.community !== false;

    if (data.advancedAiSettings) {
      if (advancedAiSettings) advancedAiSettings.style.display = 'block';

      if (data.advancedAiSettings.models) {
        if (aiModel1Input) {
          aiModel1Input.value = data.advancedAiSettings.models.model1 || 'anthropic.claude-3-sonnet-20240229-v1:0';
        }
        if (aiModel2Input) {
          aiModel2Input.value = data.advancedAiSettings.models.model2 || '';
        }
        if (aiModel3Input) {
          aiModel3Input.value = data.advancedAiSettings.models.model3 || '';
        }

        const activeModelNum = data.advancedAiSettings.activeModel || 1;
        if (activeModelNum === 1 && activeModel1Radio) {
          activeModel1Radio.checked = true;
        } else if (activeModelNum === 2 && activeModel2Radio) {
          activeModel2Radio.checked = true;
        } else if (activeModelNum === 3 && activeModel3Radio) {
          activeModel3Radio.checked = true;
        }
      } else {
        const legacyModel = data.advancedAiSettings.model || 'anthropic.claude-3-sonnet-20240229-v1:0';
        if (aiModel1Input) aiModel1Input.value = legacyModel;
        if (activeModel1Radio) activeModel1Radio.checked = true;
      }

      if (data.advancedAiSettings.contextSettings) {
        const contexts = data.advancedAiSettings.contextSettings;

        if (contexts.caseSummary) {
          if (summaryTempSlider) {
            const temp = contexts.caseSummary.temperature || 0.3;
            summaryTempSlider.value = Math.round(temp * 100);
            if (summaryTempValue) summaryTempValue.textContent = temp.toFixed(2);
          }

          if (summaryTopPSlider) {
            const topP = contexts.caseSummary.topP || 0.8;
            summaryTopPSlider.value = Math.round(topP * 100);
            if (summaryTopPValue) summaryTopPValue.textContent = topP.toFixed(2);
          }

          if (summaryTopKSlider) {
            const topK = contexts.caseSummary.topK || 40;
            summaryTopKSlider.value = topK;
            if (summaryTopKValue) summaryTopKValue.textContent = topK;
          }
        }

        if (contexts.communityGuides) {
          if (communityTempSlider) {
            const temp = contexts.communityGuides.temperature || 0.2;
            communityTempSlider.value = Math.round(temp * 100);
            if (communityTempValue) communityTempValue.textContent = temp.toFixed(2);
          }

          if (communityTopPSlider) {
            const topP = contexts.communityGuides.topP || 0.7;
            communityTopPSlider.value = Math.round(topP * 100);
            if (communityTopPValue) communityTopPValue.textContent = topP.toFixed(2);
          }

          if (communityTopKSlider) {
            const topK = contexts.communityGuides.topK || 30;
            communityTopKSlider.value = topK;
            if (communityTopKValue) communityTopKValue.textContent = topK;
          }
        }

        if (contexts.jira) {
          if (jiraTempSlider) {
            const temp = contexts.jira.temperature || 0.25;
            jiraTempSlider.value = Math.round(temp * 100);
            if (jiraTempValue) jiraTempValue.textContent = temp.toFixed(2);
          }

          if (jiraTopPSlider) {
            const topP = contexts.jira.topP || 0.85;
            jiraTopPSlider.value = Math.round(topP * 100);
            if (jiraTopPValue) jiraTopPValue.textContent = topP.toFixed(2);
          }

          if (jiraTopKSlider) {
            const topK = contexts.jira.topK || 35;
            jiraTopKSlider.value = topK;
            if (jiraTopKValue) jiraTopKValue.textContent = topK;
          }
        }

        if (contexts.confluence) {
          if (confluenceTempSlider) {
            const temp = contexts.confluence.temperature || 0.4;
            confluenceTempSlider.value = Math.round(temp * 100);
            if (confluenceTempValue) confluenceTempValue.textContent = temp.toFixed(2);
          }

          if (confluenceTopPSlider) {
            const topP = contexts.confluence.topP || 0.9;
            confluenceTopPSlider.value = Math.round(topP * 100);
            if (confluenceTopPValue) confluenceTopPValue.textContent = topP.toFixed(2);
          }

          if (confluenceTopKSlider) {
            const topK = contexts.confluence.topK || 50;
            confluenceTopKSlider.value = topK;
            if (confluenceTopKValue) confluenceTopKValue.textContent = topK;
          }
        }
      } else {
        initializeDefaultContextSettings(sliderGroups);
      }
    } else {
      if (advancedAiSettings) {
        advancedAiSettings.style.display = 'block';
      }
      initializeDefaultContextSettings(sliderGroups);
    }

    if (sidebarWidthSlider && sidebarWidthValue) {
      const width = data.sidebarWidth || 500;
      sidebarWidthSlider.value = width;
      sidebarWidthValue.textContent = width + 'px';
    }

    if (buttonLabelInput) {
      buttonLabelInput.value = data.buttonLabel || 'PandAid';
    }

    if (sidebarLabelInput) {
      sidebarLabelInput.value = data.sidebarLabel || 'PandAid Case Assistant';
    }
  }

  // Persistence helpers for the options page.


  const logger$3 = createLogger('SettingsPersistence');

  function createSettingsPersistence({
    elements,
    helpers,
    validation,
    permissions,
    aiHelpers
  }) {
    const {
      apiEndpointInput,
      aiServiceTokenInput,
      aiGlobalEnable,
      atlassianTokenInput,
      atlassianBaseUrlInput,
      atlassianEmailInput,
      jiraProjectKeyInput,
      knowledgeBaseEntryLabelInput: _knowledgeBaseEntryLabelInput,
      knowledgeBaseSidebarLabelInput: _knowledgeBaseSidebarLabelInput,
      showJiraExplanationsToggle,
      showConfluenceExplanationsToggle,
      showCommunityExplanationsToggle: _showCommunityExplanationsToggle,
      aiJiraToggle,
      aiConfluenceToggle,
      aiCommunityToggle,
      atlassianAiFilterToggle: _atlassianAiFilterToggle,
      communityAiFilterToggle,
      jiraPreloadToggle,
      confluencePreloadToggle,
      communityPreloadToggle,
      atlassianAiScoreSettings,
      jiraMinScoreSlider: _jiraMinScoreSlider,
      communityMinScoreSlider: _communityMinScoreSlider,
      confluenceMinScoreSlider: _confluenceMinScoreSlider,
      jiraScoreValue: _jiraScoreValue,
      communityScoreValue: _communityScoreValue,
      confluenceScoreValue: _confluenceScoreValue,
      sidebarJiraToggle,
      sidebarConfluenceToggle,
      sidebarCommunityToggle,
      aiModel1Input: _aiModel1Input,
      aiModel2Input: _aiModel2Input,
      aiModel3Input: _aiModel3Input,
      activeModel1Radio: _activeModel1Radio,
      activeModel2Radio: _activeModel2Radio,
      activeModel3Radio: _activeModel3Radio,
      summaryTempSlider: _summaryTempSlider,
      summaryTopPSlider: _summaryTopPSlider,
      summaryTopKSlider: _summaryTopKSlider,
      summaryTempValue: _summaryTempValue,
      summaryTopPValue: _summaryTopPValue,
      summaryTopKValue: _summaryTopKValue,
      communityTempSlider: _communityTempSlider,
      communityTopPSlider: _communityTopPSlider,
      communityTopKSlider: _communityTopKSlider,
      communityTempValue: _communityTempValue,
      communityTopPValue: _communityTopPValue,
      communityTopKValue: _communityTopKValue,
      jiraTempSlider: _jiraTempSlider,
      jiraTopPSlider: _jiraTopPSlider,
      jiraTopKSlider: _jiraTopKSlider,
      jiraTempValue: _jiraTempValue,
      jiraTopPValue: _jiraTopPValue,
      jiraTopKValue: _jiraTopKValue,
      confluenceTempSlider: _confluenceTempSlider,
      confluenceTopPSlider: _confluenceTopPSlider,
      confluenceTopKSlider: _confluenceTopKSlider,
      confluenceTempValue: _confluenceTempValue,
      confluenceTopPValue: _confluenceTopPValue,
      confluenceTopKValue: _confluenceTopKValue,
      statusElement: _statusElement,
      testAiResultElement,
      aiTestSection: _aiTestSection,
      localSearchUrlInput,
      localSearchEnableToggle,
      checkLocalServerButton: _checkLocalServerButton,
      localServerStatusElement,
      verboseLoggingToggle: _verboseLoggingToggle,
      searchModeAiVector,
      searchModeKeyword,
      searchModeKeywordVector,
      sidebarWidthSlider: _sidebarWidthSlider,
      sidebarWidthValue: _sidebarWidthValue,
      toggleAiTokenButton,
      toggleAtlassianTokenButton,
      disableTokenEncryptionToggle,
      communityAiScoreSettings,
      aiFilterToggle,
      advancedAiToggle,
      buttonLabelInput: _buttonLabelInput,
      sidebarLabelInput: _sidebarLabelInput
    } = elements;

    const {
      showStatus,
      showAtlassianUrlInputError,
      hideAtlassianUrlInputError,
      setAiMasterAvailability,
      updateToggleVisibility,
      updateToggleIcon,
      advancedAiSettings,
      applyKnowledgeBaseLabels
    } = helpers;

    const {
      validateApiToken,
      validateAtlassianUrl,
      validateLocalServerUrl,
      validateJiraProjectKey
    } = validation;

    const {
      buildOriginFromUrl,
      requestHostPermission,
      removeHostPermission
    } = permissions;

    const {
      initializeDefaultContextSettings} = aiHelpers;

    async function saveOptions() {
      const apiEndpoint = apiEndpointInput.value.trim();
      const aiEnabled = !!aiGlobalEnable && aiGlobalEnable.checked;
      const atlassianBaseUrlRaw = atlassianBaseUrlInput.value.trim();
      const atlassianEmail = atlassianEmailInput.value.trim();
      const jiraProjectKeyRaw = jiraProjectKeyInput.value.trim();

      // Handle tokens - only use new value if user modified it (not a placeholder)
      const aiTokenIsSaved = aiServiceTokenInput.getAttribute('data-is-saved') === 'true';
      const atlassianTokenIsSaved = atlassianTokenInput.getAttribute('data-is-saved') === 'true';

      // Get raw input values
      const aiServiceTokenRaw = aiServiceTokenInput.value.trim();
      const atlassianTokenRaw = atlassianTokenInput.value.trim();

      // If token is saved and user hasn't changed it (placeholder shown), use null to skip update
      // If token is new or modified, use the new value
      const aiServiceToken = aiTokenIsSaved && aiServiceTokenRaw === TOKEN_PLACEHOLDER ? null : aiServiceTokenRaw;
      const atlassianToken = atlassianTokenIsSaved && atlassianTokenRaw === TOKEN_PLACEHOLDER ? null : atlassianTokenRaw;
      const hasAiToken = aiServiceToken !== null ? Boolean(aiServiceToken) : aiTokenIsSaved;
      const hasAtlassianToken = atlassianToken !== null ? Boolean(atlassianToken) : atlassianTokenIsSaved;
      const disableTokenEncryption = disableTokenEncryptionToggle?.checked === true;

      // Check if any AI-dependent features are enabled
      const aiDependentFeaturesEnabled =
        aiJiraToggle.checked ||
        aiConfluenceToggle.checked ||
        aiCommunityToggle.checked ||
        (searchModeAiVector && searchModeAiVector.checked);

      // If AI-dependent features are enabled but AI is not fully configured, disable them and warn user
      if (aiDependentFeaturesEnabled && (!aiEnabled || !apiEndpoint || !hasAiToken)) {
        // Auto-disable AI features if credentials are missing
        if (aiJiraToggle.checked) aiJiraToggle.checked = false;
        if (aiConfluenceToggle.checked) aiConfluenceToggle.checked = false;
        if (aiCommunityToggle.checked) aiCommunityToggle.checked = false;
        if (searchModeAiVector && searchModeAiVector.checked) {
          if (searchModeKeyword) searchModeKeyword.checked = true;
        }

        showStatus('AI-enhanced features were disabled because AI is not fully configured. Your other settings were saved.', 'info');
      }

      if (aiEnabled && apiEndpoint) {
        try {
          const url = new URL(apiEndpoint);
          if (!url.protocol.startsWith('http')) {
            showStatus('API Endpoint must use HTTP or HTTPS protocol', 'error');
            return;
          }
        } catch (error) {
          logger$3.debug('API Endpoint validation error:', 'settings-persistence', error);
          showStatus('API Endpoint must be a valid URL (e.g., https://api.example.com/graphql)', 'error');
          return;
        }
      }

      const result = await chrome.storage.local.get('apiEndpoint');
      const oldApiEndpoint = result?.apiEndpoint;
      if (oldApiEndpoint && (oldApiEndpoint !== apiEndpoint || !aiEnabled)) {
        const oldOrigin = buildOriginFromUrl(oldApiEndpoint);
        if (oldOrigin) {
          try {
            await removeHostPermission(oldOrigin);
            logger$3.info(`Removed permission for old API endpoint: ${oldOrigin}`, 'settings-persistence', undefined);
          } catch (error) {
            logger$3.warn('Failed to remove old API endpoint permission:', 'settings-persistence', error);
          }
        }
      }

      // Request permission for AI endpoint when it is configured and token is present
      if (aiEnabled && apiEndpoint && hasAiToken) {
        const origin = buildOriginFromUrl(apiEndpoint);
        if (!origin) {
          showStatus('Configured AI endpoint is invalid. Please correct it before saving.', 'error');
          return;
        }
        try {
          const granted = await requestHostPermission(origin);
          if (!granted) {
            showStatus(`Permission to access ${origin} was denied. AI features will not work without this permission.`, 'error');
            return;
          }
        } catch (error) {
          logger$3.error('Error requesting AI endpoint permission:', 'settings-persistence', error);
          showStatus('Failed to request permission for AI endpoint. Please try again.', 'error');
          return;
        }
      }

      // Only validate AI token format if one is provided
      if (aiEnabled && aiServiceToken) {
        const tokenValidation = validateApiToken(aiServiceToken);
        if (!tokenValidation.valid) {
          showStatus(tokenValidation.error, 'error');
          return;
        }
      }

      // Require a valid Atlassian URL when any Atlassian credentials or toggles are enabled
      const atlassianFeaturesEnabled =
        hasAtlassianToken ||
        atlassianEmail ||
        aiJiraToggle.checked || aiConfluenceToggle.checked ||
        jiraPreloadToggle.checked || confluencePreloadToggle.checked ||
        showJiraExplanationsToggle.checked || showConfluenceExplanationsToggle.checked;

      let atlassianBaseUrl = null;
      if (atlassianFeaturesEnabled && !atlassianBaseUrlRaw) {
        const error = 'Please enter your company slug (e.g., your-company) or full Atlassian URL (https://your-company.atlassian.net).';
        showStatus(error, 'error');
        showAtlassianUrlInputError(atlassianBaseUrlInput, error);
        return;
      }

      if (atlassianBaseUrlRaw) {
        const urlValidation = validateAtlassianUrl(atlassianBaseUrlRaw);
        if (!urlValidation.valid) {
          showStatus(urlValidation.error, 'error');
          showAtlassianUrlInputError(atlassianBaseUrlInput, urlValidation.error);
          return;
        }
        atlassianBaseUrl = urlValidation.normalized;
        hideAtlassianUrlInputError();
      }

      let jiraProjectKey = null;
      if (jiraProjectKeyRaw) {
        const keyValidation = validateJiraProjectKey(jiraProjectKeyRaw);
        if (!keyValidation.valid) {
          showStatus(keyValidation.error, 'error');
          return;
        }
        jiraProjectKey = keyValidation.normalized;
      }

      if (!hasAtlassianToken) {
        const atlassianFeaturesEnabled =
          aiJiraToggle.checked || aiConfluenceToggle.checked ||
          jiraPreloadToggle.checked || confluencePreloadToggle.checked ||
          showJiraExplanationsToggle.checked || showConfluenceExplanationsToggle.checked;

        if (atlassianFeaturesEnabled) {
          aiJiraToggle.checked = false;
          aiConfluenceToggle.checked = false;
          jiraPreloadToggle.checked = false;
          confluencePreloadToggle.checked = false;
          showJiraExplanationsToggle.checked = false;
          showConfluenceExplanationsToggle.checked = false;
          showStatus('No JIRA API token detected. Atlassian AI and preload options were disabled and the rest of your settings were saved.', 'info');
        }
      }

      if (localSearchEnableToggle && localSearchEnableToggle.checked && localSearchUrlInput && localSearchUrlInput.value.trim()) {
        const localUrlValidation = validateLocalServerUrl(localSearchUrlInput.value.trim());
        if (!localUrlValidation.valid) {
          showStatus(localUrlValidation.error, 'error');
          return;
        }
      }

      try {
        // Request permission for local search server if enabled and configured
        const isLocalSearchEnabled = localSearchEnableToggle?.checked === true;
        const localSearchUrl = localSearchUrlInput?.value.trim();
        const hasLocalSearchUrl = Boolean(localSearchUrl);

        if (isLocalSearchEnabled && hasLocalSearchUrl) {
          const origin = buildOriginFromUrl(localSearchUrl);
          if (origin) {
            const granted = await requestHostPermission(origin);
            if (!granted) {
              showStatus('Permission to access the configured Local Search Server was denied. Local search will remain disabled.', 'error');
              if (localSearchEnableToggle) localSearchEnableToggle.checked = false;
            }
          }
        }

        // Build the settings object - only include tokens if they were changed
        const settingsToSave = buildSettingsToSave({
          elements,
          values: {
            apiEndpoint,
            aiEnabled,
            atlassianBaseUrl,
            atlassianEmail,
            jiraProjectKey,
            disableTokenEncryption
          }
        });

        // Only update tokens if user provided new values (not placeholder)
        if (aiServiceToken !== null) {
          if (disableTokenEncryption) {
            settingsToSave.aiServiceToken = aiServiceToken;
          } else {
            const encResult = await encrypt(aiServiceToken);
            if (!encResult.ok) throw encResult.error;
            settingsToSave.aiServiceToken = encResult.value;
          }
        }
        if (atlassianToken !== null) {
          if (disableTokenEncryption) {
            settingsToSave.atlassianToken = atlassianToken;
          } else {
            const encResult = await encrypt(atlassianToken);
            if (!encResult.ok) throw encResult.error;
            settingsToSave.atlassianToken = encResult.value;
          }
        }

        await chrome.storage.local.set(settingsToSave);

        try {
          const mode = searchModeAiVector && searchModeAiVector.checked ? 'generative' : (searchModeKeyword && searchModeKeyword.checked ? 'keyword' : (searchModeKeywordVector && searchModeKeywordVector.checked ? 'vector' : 'keyword'));
          const current = await chrome.storage.local.get({ searchSettings: { mode: 'keyword' } });
          const newSettings = { ...(current.searchSettings || {}), mode };
          await chrome.storage.local.set({ searchSettings: newSettings });
        } catch (err) {
          logger$3.warn('Failed to persist searchSettings.mode:', 'settings-persistence', err);
        }

        showStatus('All settings saved successfully!', 'success');
        if (testAiResultElement) testAiResultElement.style.display = 'none';
        if (localServerStatusElement) localServerStatusElement.style.display = 'none';
      } catch (error) {
        logger$3.error('Error saving options:', 'settings-persistence', error);
        showStatus('Failed to save settings. Please try again.', 'error');
      }
    }

    function loadOptions() {
      return new Promise((resolve) => {
        chrome.storage.local.get([
          'apiEndpoint',
          'aiServiceToken',
          'aiEnabled',
          'atlassianToken',
          'atlassianBaseUrl',
          'atlassianEmail',
          'jiraProjectKey',
          'preloadSettings',
          'aiEnhancementSettings',
          'advancedAiSettings',
          'localSearchServerUrl',
          'localSearchEnabled',
          'sidebarWidth',
          'sidebarSections',
          'knowledgeBaseLabels',
          'buttonLabel',
          'sidebarLabel',
          'disableTokenEncryption'
        ], (data) => {
          try {
            applyLoadedSettings({
              data,
              elements,
              helpers: {
                updateToggleVisibility,
                updateToggleIcon,
                setAiMasterAvailability,
                applyKnowledgeBaseLabels,
                initializeDefaultContextSettings
              },
              aiHelpers,
              logger: logger$3
            });

            resolve();
          } catch (error) {
            logger$3.error('Error loading options:', 'settings-persistence', error);

            // Provide user feedback about the error
            let userMessage = 'Failed to load some settings. Default values have been applied.';
            if (error.code === 'SESSION_KEY_MISMATCH') {
              userMessage = 'Unable to decrypt saved tokens. Please re-enter your API credentials.';
            } else if (error.message) {
              userMessage = `Error loading settings: ${error.message}. Default values have been applied.`;
            }
            showStatus(userMessage, 'error');

            // Apply safe defaults
            if (jiraPreloadToggle) jiraPreloadToggle.checked = true;
            if (communityPreloadToggle) communityPreloadToggle.checked = true;
            if (aiFilterToggle) aiFilterToggle.checked = false;
            if (communityAiFilterToggle) communityAiFilterToggle.checked = false;
            if (advancedAiToggle) advancedAiToggle.checked = false;
            if (sidebarJiraToggle) sidebarJiraToggle.checked = true;
            if (sidebarConfluenceToggle) sidebarConfluenceToggle.checked = true;
            if (sidebarCommunityToggle) sidebarCommunityToggle.checked = true;

            if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'none';
            if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
            if (advancedAiSettings) advancedAiSettings.style.display = 'none';

            updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
            updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
            updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
            updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);

            resolve();
          }
        });
      });
    }

    return {
      saveOptions,
      loadOptions
    };
  }

  const logger$2 = createLogger('CommunityGuides');

  function createCommunityGuidesHandlers({
    elements
  }) {
    const {
      communityGuidesUploadInput: _communityGuidesUploadInput,
      communityGuidesInfo,
      communityGuidesError,
      exportCommunityGuidesButton,
      clearCommunityGuidesButton
    } = elements;

    async function handleCommunityGuidesUpload(event) {
      const file = event.target.files[0];
      if (!file) return;

      if (communityGuidesInfo) communityGuidesInfo.style.display = 'none';
      if (communityGuidesError) communityGuidesError.style.display = 'none';

      try {
        const text = await file.text();
        const guides = JSON.parse(text);

        if (!Array.isArray(guides)) {
          throw new Error('JSON must be an array of guide objects');
        }

        const requiredFields = ['id', 'title', 'url'];
        for (let i = 0; i < guides.length; i++) {
          const guide = guides[i];
          for (const field of requiredFields) {
            if (!guide[field]) {
              throw new Error(`Guide at index ${i} is missing required field: ${field}`);
            }
          }
        }

        await chrome.storage.local.set({ communityGuides: guides });

        if (communityGuidesInfo) {
          communityGuidesInfo.textContent = `Successfully uploaded ${guides.length} knowledge base entries`;
          communityGuidesInfo.style.display = 'block';
        }

        // Update button states after successful upload
        await displayCurrentDataStatus();
      } catch (error) {
        logger$2.debug('Community guides upload error', 'community-guides', error);
        if (communityGuidesError) {
          communityGuidesError.textContent = `Error: ${error.message}`;
          communityGuidesError.style.display = 'block';
        }
        logger$2.error('Failed to upload community guides:', 'community-guides', error);
      }

      event.target.value = '';
    }

    async function displayCurrentDataStatus() {
      try {
        const { communityGuides } = await chrome.storage.local.get('communityGuides');
        const hasGuides = communityGuides && communityGuides.length > 0;

        if (hasGuides) {
          if (communityGuidesInfo) {
            communityGuidesInfo.textContent = `Current data: ${communityGuides.length} knowledge base entries loaded`;
            communityGuidesInfo.style.display = 'block';
          }
        } else {
          if (communityGuidesInfo) {
            communityGuidesInfo.style.display = 'none';
          }
        }

        // Update button states based on whether guides are loaded
        if (exportCommunityGuidesButton) {
          exportCommunityGuidesButton.disabled = !hasGuides;
          if (!hasGuides) {
            exportCommunityGuidesButton.style.opacity = '0.5';
            exportCommunityGuidesButton.style.cursor = 'not-allowed';
          } else {
            exportCommunityGuidesButton.style.opacity = '1';
            exportCommunityGuidesButton.style.cursor = 'pointer';
          }
        }

        if (clearCommunityGuidesButton) {
          clearCommunityGuidesButton.disabled = !hasGuides;
          if (!hasGuides) {
            clearCommunityGuidesButton.style.opacity = '0.5';
            clearCommunityGuidesButton.style.cursor = 'not-allowed';
          } else {
            clearCommunityGuidesButton.style.opacity = '1';
            clearCommunityGuidesButton.style.cursor = 'pointer';
          }
        }

        // Trigger dependency check callback if registered
        if (typeof displayCurrentDataStatus.dependencyCallback === 'function') {
          displayCurrentDataStatus.dependencyCallback();
        }
      } catch (error) {
        logger$2.error('Failed to check community guides status:', 'community-guides', error);
      }
    }

    async function exportCommunityGuides() {
      try {
        const { communityGuides } = await chrome.storage.local.get('communityGuides');

        if (!communityGuides || communityGuides.length === 0) {
          if (communityGuidesError) {
            communityGuidesError.textContent = 'No knowledge base entries to export. Upload a file first.';
            communityGuidesError.style.display = 'block';
          }
          return;
        }

        const json = JSON.stringify(communityGuides, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = 'community_guides.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        if (communityGuidesInfo) {
          communityGuidesInfo.textContent = `Exported ${communityGuides.length} knowledge base entries`;
          communityGuidesInfo.style.display = 'block';
        }
      } catch (error) {
        logger$2.debug('Community guides export error', 'community-guides', error);
        if (communityGuidesError) {
          communityGuidesError.textContent = `Export failed: ${error.message}`;
          communityGuidesError.style.display = 'block';
        }
        logger$2.error('Failed to export community guides:', 'community-guides', error);
      }
    }

    async function clearCommunityGuides() {
      const confirmed = window.confirm('Are you sure you want to clear all knowledge base entries? This action cannot be undone.');
      if (!confirmed) return;

      try {
        await chrome.storage.local.remove('communityGuides');

        if (communityGuidesInfo) {
          communityGuidesInfo.textContent = 'Knowledge base entries cleared successfully';
          communityGuidesInfo.style.display = 'block';
        }
        if (communityGuidesError) communityGuidesError.style.display = 'none';

        // Update button states after clearing
        await displayCurrentDataStatus();
      } catch (error) {
        logger$2.debug('Community guides clear error', 'community-guides', error);
        if (communityGuidesError) {
          communityGuidesError.textContent = `Clear failed: ${error.message}`;
          communityGuidesError.style.display = 'block';
        }
        logger$2.error('Failed to clear community guides:', 'community-guides', error);
      }
    }

    return {
      handleCommunityGuidesUpload,
      exportCommunityGuides,
      clearCommunityGuides,
      displayCurrentDataStatus,
      setDependencyCallback: (callback) => {
        // Store callback to trigger after status updates
        displayCurrentDataStatus.dependencyCallback = callback;
      }
    };
  }

  const logger$1 = createLogger('LocalSearch');

  function setupLocalSearchControls({
    elements,
    helpers,
    permissions,
    checkLocalServer
  }) {
    const {
      localSearchUrlInput,
      requestLocalPermissionButton,
      checkLocalPermissionButton,
      listGrantedOriginsButton,
      revokeLocalOriginsButton,
      localSearchEnableToggle,
      checkLocalServerButton,
      localServerStatusElement,
      permissionModalBackdrop,
      permissionModalOrigin,
      permissionAccept,
      permissionDecline
    } = elements;

    const { showSectionStatus, showStatus } = helpers;
    const { buildOriginFromUrl, requestHostPermission, checkHostPermission } = permissions;

    if (checkLocalServerButton && checkLocalServer) {
      checkLocalServerButton.addEventListener('click', checkLocalServer);
    }

    if (requestLocalPermissionButton) {
      requestLocalPermissionButton.addEventListener('click', async () => {
        if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
          showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
          return;
        }
        const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
        if (!origin) {
          showSectionStatus(localServerStatusElement, 'Invalid Local Search Server URL', 'error');
          return;
        }

        showSectionStatus(localServerStatusElement, `Requesting permission for ${origin}...`, 'info');
        const granted = await requestHostPermission(origin);
        if (granted) {
          showSectionStatus(localServerStatusElement, `Permission granted for ${origin}`, 'success');
          if (localSearchEnableToggle) localSearchEnableToggle.checked = true;
          if (checkLocalServerButton) checkLocalServerButton.disabled = false;
          try { chrome.storage.local.set({ localSearchEnabled: true }); } catch (e) { logger$1.debug('Error setting localSearchEnabled (granted)', 'local-search', e); }
        } else {
          showSectionStatus(localServerStatusElement, `Permission denied for ${origin}`, 'error');
        }
      });
    }

    if (checkLocalPermissionButton) {
      checkLocalPermissionButton.addEventListener('click', async () => {
        if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
          showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
          return;
        }
        const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
        if (!origin) {
          showSectionStatus(localServerStatusElement, 'Invalid Local Search Server URL', 'error');
          return;
        }
        const has = await checkHostPermission(origin);
        showSectionStatus(localServerStatusElement, has ? `Permission is present for ${origin}` : `No permission for ${origin}`, has ? 'success' : 'error');
      });
    }

    if (listGrantedOriginsButton) {
      listGrantedOriginsButton.addEventListener('click', async () => {
        if (!chrome.permissions || !chrome.permissions.getAll) {
          showSectionStatus(localServerStatusElement, 'Permissions API not available in this context', 'error');
          return;
        }
        chrome.permissions.getAll((perms) => {
          const origins = perms.origins || [];
          if (origins.length === 0) {
            showSectionStatus(localServerStatusElement, 'No origins currently granted to this extension', 'info');
          } else {
            showSectionStatus(localServerStatusElement, `Granted origins:\n${origins.join('\n')}`, 'info');
          }
        });
      });
    }

    if (revokeLocalOriginsButton) {
      revokeLocalOriginsButton.addEventListener('click', async () => {
        if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
          showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
          return;
        }
        try {
          const u = new URL(localSearchUrlInput.value.trim());
          const portPart = u.port ? `:${u.port}` : '';
          const origin1 = `${u.protocol}//127.0.0.1${portPart}/*`;
          const origin2 = `${u.protocol}//localhost${portPart}/*`;

          const removalResults = [];
          if (chrome.permissions && chrome.permissions.remove) {
            await new Promise((resolve) => {
              chrome.permissions.remove({ origins: [origin1] }, (removed) => {
                removalResults.push({ origin: origin1, removed });
                chrome.permissions.remove({ origins: [origin2] }, (removed2) => {
                  removalResults.push({ origin: origin2, removed: removed2 });
                  resolve();
                });
              });
            });

            const msgs = removalResults.map(r => `${r.origin}: ${r.removed ? 'revoked' : 'not present'}`);
            showSectionStatus(localServerStatusElement, `Revoke results:\n${msgs.join('\n')}`, 'info');
            if (localSearchEnableToggle) localSearchEnableToggle.checked = false;
            if (checkLocalServerButton) checkLocalServerButton.disabled = true;
            try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger$1.debug('Error setting localSearchEnabled (revoke)', 'local-search', e); }
          } else {
            showSectionStatus(localServerStatusElement, 'Permissions API remove not available', 'error');
          }
        } catch (err) {
          logger$1.debug('Error in origin revocation:', 'local-search', err);
          showSectionStatus(localServerStatusElement, `Invalid URL: ${err.message}`, 'error');
        }
      });
    }

    if (localSearchEnableToggle) {
      function showPermissionModal(origin) {
        if (!permissionModalBackdrop) return;
        if (permissionModalOrigin) permissionModalOrigin.textContent = origin || '';
        permissionModalBackdrop.style.display = 'flex';
      }

      function hidePermissionModal() {
        if (!permissionModalBackdrop) return;
        permissionModalBackdrop.style.display = 'none';
      }

      localSearchEnableToggle.addEventListener('change', () => {
        if (localSearchEnableToggle.checked && localSearchUrlInput && localSearchUrlInput.value.trim()) {
          const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
          if (!origin) {
            showStatus('Invalid Local Search Server URL', 'error');
            localSearchEnableToggle.checked = false;
            if (checkLocalServerButton) checkLocalServerButton.disabled = true;
            return;
          }

          showPermissionModal(origin);

          const acceptHandler = async () => {
            hidePermissionModal();
            const granted = await requestHostPermission(origin);
            if (!granted) {
              showStatus('Permission to access the configured Local Search Server was denied. Local search remains disabled.', 'error');
              localSearchEnableToggle.checked = false;
              if (checkLocalServerButton) checkLocalServerButton.disabled = true;
              try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger$1.debug('Error setting localSearchEnabled', 'local-search', e); }
              return;
            }
            if (checkLocalServerButton) checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
            showStatus('Local vector search enabled.', 'success');
            try { chrome.storage.local.set({ localSearchEnabled: true }); } catch (e) { logger$1.debug('Error setting localSearchEnabled', 'local-search', e); }
            permissionAccept.removeEventListener('click', acceptHandler);
            permissionDecline.removeEventListener('click', declineHandler);
          };

          const declineHandler = () => {
            hidePermissionModal();
            localSearchEnableToggle.checked = false;
            if (checkLocalServerButton) checkLocalServerButton.disabled = true;
            showStatus('Local search permission request cancelled.', 'info');
            try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger$1.debug('Error setting localSearchEnabled (cancel)', 'local-search', e); }
            permissionAccept.removeEventListener('click', acceptHandler);
            permissionDecline.removeEventListener('click', declineHandler);
          };

          permissionAccept.addEventListener('click', acceptHandler);
          permissionDecline.addEventListener('click', declineHandler);
        } else {
          if (checkLocalServerButton) checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
          showStatus(localSearchEnableToggle.checked ? 'Local vector search enabled.' : 'Local vector search disabled. Test button is unavailable.', 'info');
          try { chrome.storage.local.set({ localSearchEnabled: !!localSearchEnableToggle.checked }); } catch (e) { logger$1.debug('Error setting localSearchEnabled', 'local-search', e); }
        }
      });
    }
  }

  // Token field helpers and event wiring for the options page.

  function toggleTokenVisibility(inputElement, buttonElement) {
    const type = inputElement.type === 'password' ? 'text' : 'password';
    inputElement.type = type;
    updateToggleIcon(inputElement, buttonElement);
  }

  function updateToggleIcon(inputElement, buttonElement) {
    if (!inputElement || !buttonElement) return;
    const isPassword = inputElement.type === 'password';
    buttonElement.textContent = isPassword ? 'Show' : 'Hide';
    buttonElement.title = isPassword ? 'Token is hidden (click to show)' : 'Token is visible (click to hide)';
  }

  function handleTokenPaste(inputElement, buttonElement) {
    if (!inputElement || !buttonElement) return;

    setTimeout(() => {
      if (inputElement.value.trim()) {
        // Keep input as password type after paste - don't auto-reveal
        buttonElement.style.display = 'flex';
        inputElement.removeAttribute('data-is-saved');
      }
    }, 10);
  }

  function updateToggleVisibility(inputElement, buttonElement, isTokenSaved = false) {
    if (!inputElement || !buttonElement) return;
    buttonElement.style.display = isTokenSaved && inputElement.value.trim() ? 'none' : 'flex';
  }

  function toggleTokenVisibilitySecure(inputElement, buttonElement, isTokenSaved = false, sectionStatusElement = null, showStatus = () => {}) {
    if (!inputElement || !buttonElement) return;

    if (isTokenSaved && inputElement.type === 'password') {
      const message = 'For security reasons, saved tokens cannot be viewed. Clear the field to enter a new token.';
      if (sectionStatusElement) {
        sectionStatusElement.textContent = message;
        sectionStatusElement.className = 'status info';
        sectionStatusElement.style.display = 'block';
        setTimeout(() => {
          sectionStatusElement.style.display = 'none';
        }, 5000);
      } else {
        showStatus(message, 'info');
      }
      return;
    }

    toggleTokenVisibility(inputElement, buttonElement);
  }

  function attachTokenFieldHandlers({
    aiServiceTokenInput,
    toggleAiTokenButton,
    atlassianTokenInput,
    toggleAtlassianTokenButton,
    statusElement,
    showStatus
  }) {
    if (toggleAiTokenButton && aiServiceTokenInput) {
      toggleAiTokenButton.addEventListener('click', () => {
        const isTokenSaved = aiServiceTokenInput.getAttribute('data-is-saved') === 'true';
        toggleTokenVisibilitySecure(aiServiceTokenInput, toggleAiTokenButton, isTokenSaved, statusElement, showStatus);
      });
    }

    if (toggleAtlassianTokenButton && atlassianTokenInput) {
      toggleAtlassianTokenButton.addEventListener('click', () => {
        const isTokenSaved = atlassianTokenInput.getAttribute('data-is-saved') === 'true';
        toggleTokenVisibilitySecure(atlassianTokenInput, toggleAtlassianTokenButton, isTokenSaved, statusElement, showStatus);
      });
    }

    if (aiServiceTokenInput) {
      aiServiceTokenInput.addEventListener('paste', () => {
        handleTokenPaste(aiServiceTokenInput, toggleAiTokenButton);
        aiServiceTokenInput.removeAttribute('data-is-saved');
      });

      aiServiceTokenInput.addEventListener('input', () => {
        if (aiServiceTokenInput.getAttribute('data-is-saved') === 'true') {
          aiServiceTokenInput.value = '';
          aiServiceTokenInput.removeAttribute('data-is-saved');
          updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
          aiServiceTokenInput.type = 'text';
          updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
          if (toggleAiTokenButton) toggleAiTokenButton.style.display = 'flex';
          setTimeout(() => aiServiceTokenInput.focus(), 0);
        }
        if (aiServiceTokenInput.value.trim() && toggleAiTokenButton) {
          toggleAiTokenButton.style.display = 'flex';
        }
      });

      aiServiceTokenInput.addEventListener('focus', () => {
        if (!aiServiceTokenInput.getAttribute('data-is-saved') && toggleAiTokenButton) {
          toggleAiTokenButton.style.display = 'flex';
        }
      });
    }

    if (atlassianTokenInput) {
      atlassianTokenInput.addEventListener('paste', () => {
        handleTokenPaste(atlassianTokenInput, toggleAtlassianTokenButton);
        atlassianTokenInput.removeAttribute('data-is-saved');
      });

      atlassianTokenInput.addEventListener('input', () => {
        if (atlassianTokenInput.getAttribute('data-is-saved') === 'true') {
          atlassianTokenInput.value = '';
          atlassianTokenInput.removeAttribute('data-is-saved');
          updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
          atlassianTokenInput.type = 'text';
          updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);
          if (toggleAtlassianTokenButton) toggleAtlassianTokenButton.style.display = 'flex';
          setTimeout(() => atlassianTokenInput.focus(), 0);
        }
        if (atlassianTokenInput.value.trim() && toggleAtlassianTokenButton) {
          toggleAtlassianTokenButton.style.display = 'flex';
        }
      });

      atlassianTokenInput.addEventListener('focus', () => {
        if (!atlassianTokenInput.getAttribute('data-is-saved') && toggleAtlassianTokenButton) {
          toggleAtlassianTokenButton.style.display = 'flex';
        }
      });
    }
  }

  /**
   * Options Page Main Controller
   * Orchestrates specialized controllers for UI, AI settings, and Connections.
   */

  const logger = createLogger('Options');

  document.addEventListener('DOMContentLoaded', async () => {
    try {
      // --- 1. Element Selection ---
      const elements = {
        // UI Core
        statusElement: document.getElementById('status'),
        tabContainer: document.querySelector('.tab-container'),
        tabButtons: document.querySelectorAll('.tab-button'),
        tabContents: document.querySelectorAll('.tab-content'),

        // Credentials
        apiEndpointInput: document.getElementById('api-endpoint'),
        aiServiceTokenInput: document.getElementById('api-token'),
        toggleAiTokenButton: document.getElementById('toggle-ai-token'),
        atlassianTokenInput: document.getElementById('atlassian-token'),
        toggleAtlassianTokenButton: document.getElementById('toggle-atlassian-token'),
        disableTokenEncryptionToggle: document.getElementById('disable-token-encryption-toggle'),

        // Atlassian General
        atlassianBaseUrlInput: document.getElementById('atlassian-base-url'),
        atlassianEmailInput: document.getElementById('atlassian-email'),
        jiraProjectKeyInput: document.getElementById('jira-project-key'),

        // AI General
        aiGlobalEnable: document.getElementById('ai-global-enable'),
        advancedAiToggle: document.getElementById('advanced-ai-toggle'),
        advancedAiSettings: document.getElementById('advanced-ai-settings'),

        // AI Models
        aiModel1Input: document.getElementById('ai-model-1'),
        aiModel2Input: document.getElementById('ai-model-2'),
        aiModel3Input: document.getElementById('ai-model-3'),
        activeModel1Radio: document.getElementById('active-model-1'),
        activeModel2Radio: document.getElementById('active-model-2'),
        activeModel3Radio: document.getElementById('active-model-3'),

        // Testing Controls
        testAiButton: document.getElementById('test-ai-connection'),
        testAiResultElement: document.getElementById('test-ai-result'),
        testAtlassianButton: document.getElementById('test-jira-connection'),
        testAtlassianResultElement: document.getElementById('test-jira-result'),
        verboseLoggingToggle: document.getElementById('verbose-logging-toggle'),

        // Feature Toggles
        aiJiraToggle: document.getElementById('ai-jira-toggle'),
        aiConfluenceToggle: document.getElementById('ai-confluence-toggle'),
        aiCommunityToggle: document.getElementById('ai-community-toggle'),
        showJiraExplanationsToggle: document.getElementById('show-jira-explanations-toggle'),
        showConfluenceExplanationsToggle: document.getElementById('show-confluence-explanations-toggle'),
        showCommunityExplanationsToggle: document.getElementById('show-community-explanations-toggle'),
        aiFilterToggle: document.getElementById('atlassian-ai-filter-toggle'), // Aliased for simpler use
        atlassianAiFilterToggle: document.getElementById('atlassian-ai-filter-toggle'),
        communityAiFilterToggle: document.getElementById('community-ai-filter-toggle'),
        jiraPreloadToggle: document.getElementById('jira-preload-toggle'),
        confluencePreloadToggle: document.getElementById('confluence-preload-toggle'),
        communityPreloadToggle: document.getElementById('community-preload-toggle'),

        // Score Settings
        atlassianAiScoreSettings: document.getElementById('atlassian-ai-score-settings'),
        communityAiScoreSettings: document.getElementById('community-ai-score-settings'),

        // Sliders
        jiraMinScoreSlider: document.getElementById('jira-min-score'),
        communityMinScoreSlider: document.getElementById('community-min-score'),
        confluenceMinScoreSlider: document.getElementById('confluence-min-score'),
        jiraScoreValue: document.getElementById('jira-score-value'),
        communityScoreValue: document.getElementById('community-score-value'),
        confluenceScoreValue: document.getElementById('confluence-score-value'),
        sidebarWidthSlider: document.getElementById('sidebar-width'),
        sidebarWidthValue: document.getElementById('sidebar-width-value'),

        // Sidebar Toggles
        sidebarJiraToggle: document.getElementById('sidebar-jira-toggle'),
        sidebarConfluenceToggle: document.getElementById('sidebar-confluence-toggle'),
        sidebarCommunityToggle: document.getElementById('sidebar-community-toggle'),

        // Knowledge Base Labels
        knowledgeBaseEntryLabelInput: document.getElementById('knowledge-base-entry-label'),
        knowledgeBaseSidebarLabelInput: document.getElementById('knowledge-base-sidebar-label'),

        // Community Guides
        communityGuidesUploadInput: document.getElementById('community-guides-upload'),
        exportCommunityGuidesButton: document.getElementById('export-community-guides'),
        clearCommunityGuidesButton: document.getElementById('clear-community-guides'),
        communityGuidesInfo: document.getElementById('community-guides-info'),
        communityGuidesError: document.getElementById('community-guides-error'),

        // Local Search
        localSearchUrlInput: document.getElementById('local-search-url'),
        localSearchEnableToggle: document.getElementById('local-search-enable'),
        checkLocalServerButton: document.getElementById('check-local-server'),
        localServerStatusElement: document.getElementById('local-server-status'),
        requestLocalPermissionButton: document.getElementById('request-local-permission'),
        checkLocalPermissionButton: document.getElementById('check-local-permission'),
        listGrantedOriginsButton: document.getElementById('list-granted-origins'),
        revokeLocalOriginsButton: document.getElementById('revoke-local-origins'),
        permissionModalBackdrop: document.getElementById('permission-modal-backdrop'),
        permissionModalOrigin: document.getElementById('permission-modal-origin'),
        permissionAccept: document.getElementById('permission-accept'),
        permissionDecline: document.getElementById('permission-decline'),

        // Search Mode
        searchModeAiVector: document.getElementById('search-mode-ai-vector'),
        searchModeKeyword: document.getElementById('search-mode-keyword'),
        searchModeKeywordVector: document.getElementById('search-mode-keyword-vector'),

        // Context UI
        contextTabs: document.querySelectorAll('.context-tab'),
        contextSettings: document.querySelectorAll('.context-settings'),

        // Action Buttons
        saveButtons: document.querySelectorAll('.save-button')
      };

      // Derived Groups
      elements.modelControls = [
        { input: elements.aiModel1Input, radio: elements.activeModel1Radio },
        { input: elements.aiModel2Input, radio: elements.activeModel2Radio },
        { input: elements.aiModel3Input, radio: elements.activeModel3Radio }
      ].filter(c => c.input && c.radio);

      // AI Sliders Groups (Verbose but cleaner than previous monolithic object)
      elements.sliderGroups = {
        summary: {
          tempSlider: document.getElementById('summary-temperature'),
          tempValue: document.getElementById('summary-temperature-value'),
          topPSlider: document.getElementById('summary-top-p'),
          topPValue: document.getElementById('summary-top-p-value'),
          topKSlider: document.getElementById('summary-top-k'),
          topKValue: document.getElementById('summary-top-k-value')
        },
        community: {
          tempSlider: document.getElementById('community-temperature'),
          tempValue: document.getElementById('community-temperature-value'),
          topPSlider: document.getElementById('community-top-p'),
          topPValue: document.getElementById('community-top-p-value'),
          topKSlider: document.getElementById('community-top-k'),
          topKValue: document.getElementById('community-top-k-value')
        },
        jira: {
          tempSlider: document.getElementById('jira-temperature'),
          tempValue: document.getElementById('jira-temperature-value'),
          topPSlider: document.getElementById('jira-top-p'),
          topPValue: document.getElementById('jira-top-p-value'),
          topKSlider: document.getElementById('jira-top-k'),
          topKValue: document.getElementById('jira-top-k-value')
        },
        confluence: {
          tempSlider: document.getElementById('confluence-temperature'),
          tempValue: document.getElementById('confluence-temperature-value'),
          topPSlider: document.getElementById('confluence-top-p'),
          topPValue: document.getElementById('confluence-top-p-value'),
          topKSlider: document.getElementById('confluence-top-k'),
          topKValue: document.getElementById('confluence-top-k-value')
        }
      };

      // --- 2. Initialize Controllers ---
      const uiController = new UiController(elements);
      uiController.setupTabs();

      const connectionController = new ConnectionController(elements, uiController);

      // Dependency Manager
      const dependencyManager = createDependencyManager({
        elements: {
          ...elements,
          aiScoreSettings: elements.atlassianAiScoreSettings // aliased
        },
        helpers: {
          setAiMasterAvailability: (isEnabled) => {
            // Update opacity/disabled state logic here or in UI controller
            // For now, implementing simple version here to pass to dep manager
            [
              elements.aiServiceTokenInput,
              elements.testAiButton,
              elements.aiJiraToggle,
              elements.aiConfluenceToggle,
              elements.aiCommunityToggle,
              elements.aiModel1Input
            ].forEach(el => { if (el) el.disabled = !isEnabled; });

            if (elements.advancedAiSettings) elements.advancedAiSettings.style.opacity = isEnabled ? '1' : '0.5';
          },
          showStatus: uiController.showStatus.bind(uiController),
          // switchContext: delegated later
          advancedAiSettings: elements.advancedAiSettings,
          aiTestSection: document.getElementById('ai-test-section')
        }
      });

      const { createContextWarning, manageDependencies } = dependencyManager;

      // AI Dependencies context object
      const aiContextDeps = {
        contextTabs: elements.contextTabs,
        contextSettings: elements.contextSettings,
        aiJiraToggle: elements.aiJiraToggle,
        atlassianTokenInput: elements.atlassianTokenInput,
        createContextWarning
      };

      const aiSettingsController = new AiSettingsController({
        ...elements,
        aiContextDeps
      }, {});

      aiSettingsController.initialize();

      // --- 3. Feature Setups ---

      // Community Guides
      const communityGuidesHandlers = createCommunityGuidesHandlers({
        elements: elements
      });

      // Re-check dependencies when data changes
      communityGuidesHandlers.setDependencyCallback(() => {
        if (manageDependencies) manageDependencies();
      });

      if (elements.communityGuidesUploadInput) {
        elements.communityGuidesUploadInput.addEventListener('change', communityGuidesHandlers.handleCommunityGuidesUpload);
      }
      if (elements.exportCommunityGuidesButton) {
        elements.exportCommunityGuidesButton.addEventListener('click', communityGuidesHandlers.exportCommunityGuides);
      }
      if (elements.clearCommunityGuidesButton) {
        elements.clearCommunityGuidesButton.addEventListener('click', communityGuidesHandlers.clearCommunityGuides);
      }

      // Local Search Controls
      setupLocalSearchControls({
        elements,
        helpers: {
          showSectionStatus: uiController.showSectionStatus.bind(uiController),
          showStatus: uiController.showStatus.bind(uiController)
        },
        permissions: { buildOriginFromUrl, requestHostPermission, checkHostPermission },
        checkLocalServer: connectionController.checkLocalServer
      });

      // Settings Persistence
      const { saveOptions, loadOptions } = createSettingsPersistence({
        elements: {
          ...elements,
          // Aliased for persistence module expectations
          aiFilterToggle: elements.atlassianAiFilterToggle,
          // Flatten slider groups for persistence module
          summaryTempSlider: elements.sliderGroups.summary.tempSlider,
          summaryTopPSlider: elements.sliderGroups.summary.topPSlider,
          summaryTopKSlider: elements.sliderGroups.summary.topKSlider,
          communityTempSlider: elements.sliderGroups.community.tempSlider,
          communityTopPSlider: elements.sliderGroups.community.topPSlider,
          communityTopKSlider: elements.sliderGroups.community.topKSlider,
          jiraTempSlider: elements.sliderGroups.jira.tempSlider,
          jiraTopPSlider: elements.sliderGroups.jira.topPSlider,
          jiraTopKSlider: elements.sliderGroups.jira.topKSlider,
          confluenceTempSlider: elements.sliderGroups.confluence.tempSlider,
          confluenceTopPSlider: elements.sliderGroups.confluence.topPSlider,
          confluenceTopKSlider: elements.sliderGroups.confluence.topKSlider
        },
        helpers: {
          showStatus: uiController.showStatus.bind(uiController),
          showAtlassianUrlInputError: uiController.showAtlassianError.bind(uiController),
          hideAtlassianUrlInputError: uiController.hideAtlassianError.bind(uiController),
          setAiMasterAvailability: (isEnabled) => {
            // Update opacity/disabled state logic here or in UI controller
            // For now, implementing simple version here to pass to persistence module
            [
              elements.aiServiceTokenInput,
              elements.testAiButton,
              elements.aiJiraToggle,
              elements.aiConfluenceToggle,
              elements.aiCommunityToggle,
              elements.aiModel1Input
            ].forEach(el => { if (el) el.disabled = !isEnabled; });

            if (elements.advancedAiSettings) elements.advancedAiSettings.style.opacity = isEnabled ? '1' : '0.5';
          },
          updateToggleVisibility,
          updateToggleIcon,
          advancedAiSettings: elements.advancedAiSettings,
          applyKnowledgeBaseLabels: ({ entryLabel, sidebarLabel }) => {
            // Simple label updater
            const entry = entryLabel?.trim() || 'Knowledge Base';
            const sidebar = sidebarLabel?.trim() || entry;
            document.querySelectorAll('[data-kb-label]').forEach(el => {
              el.textContent = el.getAttribute('data-kb-label') === 'sidebar' ? sidebar : entry;
            });
          }
        },
        validation: {
          validateApiToken,
          validateAtlassianUrl,
          validateLocalServerUrl,
          validateJiraProjectKey
        },
        permissions: {
          buildOriginFromUrl,
          requestHostPermission,
          removeHostPermission
        },
        aiHelpers: {
          initializeDefaultContextSettings,
          sliderGroups: elements.sliderGroups
        }
      });

      // Data Management
      setupDataManagement({
        elements: {
          clearCacheButton: document.getElementById('clear-cache'),
          clearAllDataButton: document.getElementById('clear-all-data'),
          aiServiceTokenInput: elements.aiServiceTokenInput,
          atlassianTokenInput: elements.atlassianTokenInput,
          atlassianBaseUrlInput: elements.atlassianBaseUrlInput,
          atlassianEmailInput: elements.atlassianEmailInput
        },
        helpers: { showStatus: uiController.showStatus.bind(uiController), logger }
      });

      // Auth Field Handlers
      attachTokenFieldHandlers({
        aiServiceTokenInput: elements.aiServiceTokenInput,
        toggleAiTokenButton: elements.toggleAiTokenButton,
        atlassianTokenInput: elements.atlassianTokenInput,
        toggleAtlassianTokenButton: elements.toggleAtlassianTokenButton,
        statusElement: elements.statusElement,
        showStatus: uiController.showStatus.bind(uiController)
      });

      // --- 4. Global Event Listeners & Init ---

      elements.saveButtons.forEach(btn => btn.addEventListener('click', saveOptions));

      const handleEnterKey = (e, callback) => {
        if (e.key === 'Enter') callback();
      };
      elements.aiServiceTokenInput.addEventListener('keydown', (e) => handleEnterKey(e, saveOptions));
      elements.atlassianTokenInput.addEventListener('keydown', (e) => handleEnterKey(e, saveOptions));

      // Mirror sliders (simple manual binding or use helper if preferred)
      const mirrors = {
        'jira-min-score': 'jira-score-value',
        'community-min-score': 'community-score-value',
        'confluence-min-score': 'confluence-score-value',
        'sidebar-width': 'sidebar-width-value'
      };
      Object.entries(mirrors).forEach(([id, valId]) => {
        const slider = document.getElementById(id);
        const display = document.getElementById(valId);
        if (slider && display) {
          slider.addEventListener('input', () => display.textContent = slider.value);
          display.textContent = slider.value;
        }
      });

      // Initial Load
      await loadOptions();
      // Re-enforce radio logic after load
      aiSettingsController.enforceModelRadioAvailability();

    } catch (error) {
      logger.error('Failed to initialize options page', 'Options', error);
    }
  });

})();
