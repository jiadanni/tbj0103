(function () {
  'use strict';

  /**
   * Promise utilities used throughout the extension.
   */

  const DEFAULT_TIMEOUT_MESSAGE = 'Operation timed out';

  /**
   * Wrap an async operation with a timeout. The operation can be a promise or a
   * function that returns a promise. Ensures the timeout timer is cleared when
   * the operation settles to avoid leaking timers.
   *
   * @param {Promise|Function} operation - Promise or function returning a promise
   * @param {number} ms - Timeout duration in milliseconds
   * @param {string} [errorMessage] - Custom error message for timeout
   * @returns {Promise<any>} Resolves/rejects with the underlying operation
   */
  function withTimeout(operation, ms, errorMessage = DEFAULT_TIMEOUT_MESSAGE) {
    const execute = typeof operation === 'function' ? operation : () => operation;

    if (!Number.isFinite(ms) || ms <= 0) {
      return Promise.resolve().then(() => execute());
    }

    let timeoutId = null;
    let settled = false;

    const startTimer = () => new Promise((_, reject) => {
      timeoutId = setTimeout(() => {
        if (settled) {
          return;
        }
        const error = new Error(errorMessage);
        error.name = 'TimeoutError';
        reject(error);
      }, ms);

      if (typeof timeoutId?.unref === 'function') {
        timeoutId.unref();
      }
    });

    const clearTimer = () => {
      settled = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    };

    return Promise.race([
      Promise.resolve().then(() => execute()),
      startTimer()
    ]).then((result) => {
      clearTimer();
      return result;
    }).catch((error) => {
      clearTimer();
      throw error;
    });
  }

  /**
   * Helper specifically for wrapping dynamic imports with a timeout.
   * @param {string} url - Module URL to import
   * @param {number} timeoutMs - Timeout duration
   * @param {string} [label] - Label for error messages
   * @returns {Promise<any>} Resolves with the imported module
   */
  function importWithTimeout(url, timeoutMs, label = url) {
    const contextLabel = label || url;
    const message = `Dynamic import timed out after ${timeoutMs}ms: ${contextLabel}`;
    return withTimeout(() => import(url), timeoutMs, message);
  }

  /**
   * Centralized Logging Utility
   * Provides consistent logging across the extension with verbose mode support
   *
   * @module logger
   */

  // ============================================================================
  // LOG LEVELS
  // ============================================================================

  /**
   * Log severity levels
   * @enum {string}
   * @readonly
   */
  const LogLevel = {
    ERROR: 'error',   // Critical errors that need immediate attention
    WARN: 'warn',     // Warnings about potential issues
    INFO: 'info',     // Important informational messages (always shown)
    DEBUG: 'debug',   // Detailed debugging information (verbose mode only)
    TRACE: 'trace'    // Very detailed trace information (verbose mode only)
  };

  // ============================================================================
  // LOGGER CLASS
  // ============================================================================

  class Logger {
    /**
     * Create a new logger instance with optional context.
     *
     * @param {string} [context='PandAid'] - Context name for this logger (appears in all log messages)
     */
    constructor(context = 'PandAid') {
      this.context = context;
      this.verboseEnabled = false;
      this.initialized = false;

      // Kick off async load without blocking construction
      this.loadVerbosePreference().catch((error) => {
        logger$1.warn('[Logger] Failed to load verbose preference', 'logger', error);
      });
    }

    /**
     * Load verbose logging preference from Chrome storage.
     * Called automatically during constructor initialization.
     *
     * @private
     * @async
     * @returns {Promise<void>}
     */
    async loadVerbosePreference() {
      if (this.initialized) return;
      this.initialized = true;

      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        return;
      }

      try {
        const result = await chrome.storage.local.get(['verboseLogging']);
        if (Object.prototype.hasOwnProperty.call(result, 'verboseLogging')) {
          this.verboseEnabled = !!result.verboseLogging;
        }
      } catch (error) {
        logger$1.warn('[Logger] Error reading verbose logging preference', 'logger', error);
      }
    }

    /**
     * Set verbose mode at runtime.
     * Useful for toggling detailed logging during debugging or testing.
     *
     * @param {boolean} enabled - Whether to enable verbose logging
     */
    setVerbose(enabled = false) {
      this.verboseEnabled = !!enabled;
    }

    /**
     * Check if verbose logging is currently enabled.
     *
     * @returns {boolean} True if verbose logging is enabled
     */
    isVerboseEnabled() {
      return this.verboseEnabled;
    }

    /**
     * Format log message with timestamp and context.
     * Internal helper method for consistent formatting across all log levels.
     *
     * @private
     * @param {string} level - Log level (from LogLevel enum)
     * @param {string} context - Additional context string
     * @param {string} message - The message to format
     * @returns {string} Formatted message with timestamp
     */
    formatMessage(level, context, message) {
      const timestamp = new Date().toISOString().substring(11, 23); // HH:MM:SS.mmm
      const contextLabel = context ? `${this.context}:${context}` : this.context;
      return `[${timestamp}] [${contextLabel}] [${level.toUpperCase()}] ${message}`;
    }

    /**
     * Log error message (always shown regardless of verbose mode).
     * Use for critical errors that need immediate attention.
     *
     * @param {string} message - The error message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data/error object to log
     */
    error(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.ERROR, context, message);
      if (data !== null) {
        console.error(formatted, data);
      } else {
        console.error(formatted);
      }
    }

    /**
     * Log warning message (always shown regardless of verbose mode).
     * Use for potential issues or unexpected conditions.
     *
     * @param {string} message - The warning message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    warn(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.WARN, context, message);
      if (data !== null) {
        console.warn(formatted, data);
      } else {
        console.warn(formatted);
      }
    }

    /**
     * Log info message (always shown regardless of verbose mode).
     * Use for important informational messages about normal operation.
     *
     * @param {string} message - The info message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    info(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.INFO, context, message);
      if (data !== null) {
        console.info(formatted, data);
      } else {
        console.info(formatted);
      }
    }

    /**
     * Log debug message (only shown if verbose logging is enabled).
     * Use for detailed debugging information during development/troubleshooting.
     *
     * @param {string} message - The debug message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    debug(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.DEBUG, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Log trace message (only shown if verbose logging is enabled).
     * Used for very detailed logging like function entry/exit, state changes, etc.
     *
     * @param {string} message - The trace message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    trace(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.TRACE, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Create a child logger with a specific context.
     * Child loggers inherit the parent's verbose mode setting.
     *
     * @param {string} childContext - The child context name (appended to parent context)
     * @returns {Logger} New logger instance with combined context
     */
    child(childContext) {
      const childLogger = new Logger(`${this.context}:${childContext}`);
      childLogger.setVerbose(this.verboseEnabled);
      childLogger.initialized = true; // Do not re-read storage; inherit setting
      return childLogger;
    }

    /**
     * Log a group of related messages together.
     * Groups are only shown if verbose logging is enabled.
     *
     * @param {string} groupName - Name/title of the log group
     * @param {Function} fn - Function containing logger calls to group
     */
    group(groupName, fn) {
      if (!this.verboseEnabled) return;

      console.group(`[${this.context}] ${groupName}`);
      try {
        fn();
      } finally {
        console.groupEnd();
      }
    }

    /**
     * Execute a function and log its execution time.
     * Timing output is only shown if verbose logging is enabled.
     *
     * @param {string} label - Label for the timer (shown in timing output)
     * @param {Function} fn - Async function to time (can also be sync)
     * @returns {Promise<*>} Result of the function
     */
    async time(label, fn) {
      const timerLabel = `[${this.context}] ${label}`;
      if (this.verboseEnabled) {
        console.time(timerLabel);
      }

      try {
        return await fn();
      } finally {
        if (this.verboseEnabled) {
          console.timeEnd(timerLabel);
        }
      }
    }
  }

  // ============================================================================
  // GLOBAL LOGGER INSTANCE
  // ============================================================================

  // Create default logger instance
  const defaultLogger = new Logger('PandAid');

  // Export factory function
  function createLogger(context = 'PandAid') {
    const newLogger = new Logger(context);
    newLogger.setVerbose(defaultLogger.isVerboseEnabled());
    return newLogger;
  }

  // Export default logger
  const logger$1 = defaultLogger;

  // ============================================================================
  // STORAGE LISTENER
  // ============================================================================

  // Listen for changes to verbose logging preference
  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.verboseLogging) {
        const newValue = !!changes.verboseLogging.newValue;
        defaultLogger.setVerbose(newValue);
        logger$1.info(`[PandAid] Verbose logging ${newValue ? 'enabled' : 'disabled'}`, 'contextual', undefined);
      }
    });
  }

  // modules/config/constants.js
  //
  // Centralized configuration constants for timeouts, intervals, and limits.
  // Import from here instead of using magic numbers throughout the codebase.


  /** Timeout for dynamic module imports (ms) */
  const DYNAMIC_IMPORT_TIMEOUT_MS = 10000;

  const logger = createLogger('Content_script');

  // Bootstrapper for PandAid content script
  (async () => {

    const debugMod = await importWithTimeout(chrome.runtime.getURL('modules/content/debug-utils.js'), DYNAMIC_IMPORT_TIMEOUT_MS, 'debug-utils');
    debugMod.setupDebugAPI();

    const msgMod = await importWithTimeout(chrome.runtime.getURL('modules/content/message-router.js'), DYNAMIC_IMPORT_TIMEOUT_MS, 'message-router');
    const spaMod = await importWithTimeout(chrome.runtime.getURL('modules/content/spa-watcher.js'), DYNAMIC_IMPORT_TIMEOUT_MS, 'spa-watcher');
    const resilienceMod = await importWithTimeout(chrome.runtime.getURL('modules/content/resilience-observer.js'), DYNAMIC_IMPORT_TIMEOUT_MS, 'resilience-observer');
    const initMod = await importWithTimeout(chrome.runtime.getURL('modules/content/initialization.js'), DYNAMIC_IMPORT_TIMEOUT_MS, 'initialization');

    msgMod.setupMessageHandlers();
    spaMod.setupSPAWatcher();
    resilienceMod.setupResilienceObservers();
    initMod.initializeAssistant();
  })().catch((error) => {
    logger.error('[PandAid ContentScript] Bootstrap failed:', 'content_script', error);
  });

})();
