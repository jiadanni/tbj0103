/**
 * Security Utilities Module
 * Provides sanitization, validation, and security helpers for PandAid extension
 * 
 * REFACTORED: This file now acts as a barrel/facade for modules in src/modules/security/
 * to maintain backward compatibility.
 *
 * @module security-utils
 */

// Re-export everything from specialized modules
export * from './modules/security/sanitization.js';
export * from './modules/security/validation.js';
export * from './modules/security/permissions.js';
export * from './modules/security/rate-limiter.js';
