/**
 * Standardized Error Handling Utility
 * Provides consistent error handling across the extension
 *
 * @module error-handler
 */

import { showError, getUserFriendlyErrorMessage } from './user-notifications.js';
import { recordError } from './telemetry.js';
import { createLogger } from './logger.js';

const logger = createLogger('ErrorHandler');

/**
 * Error handling strategies
 * @enum {string}
 * @readonly
 */
export const ErrorStrategy = {
  /** Log and rethrow the error (fails fast, propagates to caller) */
  THROW: 'throw',
  /** Log and return null (graceful failure, no user notification) */
  RETURN_NULL: 'return_null',
  /** Log and return a fallback value (uses default behavior) */
  RETURN_FALLBACK: 'return_fallback',
  /** Log, notify user, and rethrow (visible failure, still propagates) */
  NOTIFY_AND_THROW: 'notify_and_throw',
  /** Log, notify user, and return null (visible failure, graceful handling) */
  NOTIFY_AND_RETURN_NULL: 'notify_and_return_null',
  /** Log, notify user, and return fallback (visible failure with fallback) */
  NOTIFY_AND_RETURN_FALLBACK: 'notify_and_return_fallback',
  /** Silent - no logging or notification (for expected/handled errors) */
  SILENT: 'silent'
};

/**
 * Standard error handler that provides consistent error handling across the extension.
 * Handles logging, telemetry, user notifications, and graceful failure modes
 * based on the selected strategy. Special handling for AbortError (cancellations).
 *
 * @param {Error} error - The error object to handle
 * @param {Object} [options={}] - Error handling configuration
 * @param {string} [options.strategy=ErrorStrategy.THROW] - Error handling strategy from ErrorStrategy enum
 * @param {string} [options.context='Unknown'] - Context where error occurred (e.g., 'JIRA Search', 'AI Service')
 * @param {string} [options.operation='unknown'] - Specific operation name (e.g., 'fetchTickets', 'makeApiRequest')
 * @param {*} [options.fallback=null] - Fallback value to return when using FALLBACK strategies
 * @param {string} [options.userMessage] - Custom user-friendly message (overrides default)
 * @param {boolean} [options.logToConsole=true] - Whether to log error details to console
 * @param {Object} [options.metadata={}] - Additional metadata to include in telemetry
 * @returns {*} Return value depends on strategy: throws, returns null, or returns fallback value
 * @throws {Error} Throws error if strategy is THROW or NOTIFY_AND_THROW
 * @example
 * try {
 *   await fetchData();
 * } catch (error) {
 *   handleError(error, {
 *     strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
 *     context: 'Data Fetch',
 *     operation: 'fetchData',
 *     metadata: { url: 'https://...' }
 *   });
 * }
 */
export function handleError(error, options = {}) {
  const {
    strategy = ErrorStrategy.THROW,
    context = 'Unknown',
    operation = 'unknown',
    fallback = null,
    userMessage = null,
    logToConsole = true,
    metadata = {}
  } = options;

  // Special handling for AbortError - these are intentional cancellations
  if (error.name === 'AbortError' || error.message?.includes('aborted')) {
    if (logToConsole) {
      logger.info(`[${context}] Operation was cancelled: ${operation}`, 'error-handler', undefined);
    }

    // For abort errors, always return null/fallback without notification
    if (strategy.includes('FALLBACK')) {
      return fallback;
    }
    return null;
  }

  // Log technical details to console for debugging
  if (logToConsole) {
    logger.error(`[${context}] Error in ${operation}:`, 'error-handler', {
      message: error.message,
      stack: error.stack,
      status: error.status,
      ...metadata
    });
  }

  // Record error in telemetry
  try {
    recordError(error, {
      context,
      operation,
      ...metadata
    });
  } catch (telemetryError) {
    // Don't let telemetry failures break error handling
    logger.warn('Failed to record error in telemetry:', 'error-handler', telemetryError);
  }

  // Show user notification if strategy includes NOTIFY
  if (strategy.includes('NOTIFY')) {
    try {
      const message = userMessage || getUserFriendlyErrorMessage(error, context);
      showError(message, error);
    } catch (notificationError) {
      // Don't let notification failures break error handling
      logger.warn('Failed to show error notification:', 'error-handler', notificationError);
    }
  }

  // Return or throw based on strategy
  switch (strategy) {
    case ErrorStrategy.THROW:
    case ErrorStrategy.NOTIFY_AND_THROW:
      throw error;

    case ErrorStrategy.RETURN_NULL:
    case ErrorStrategy.NOTIFY_AND_RETURN_NULL:
      return null;

    case ErrorStrategy.RETURN_FALLBACK:
    case ErrorStrategy.NOTIFY_AND_RETURN_FALLBACK:
      return fallback;

    case ErrorStrategy.SILENT:
      return fallback;

    default:
      throw error;
  }
}

/**
 * Wraps an async function with standardized error handling
 *
 * @param {Function} fn - The async function to wrap
 * @param {Object} errorOptions - Error handling options (see handleError)
 * @returns {Function} Wrapped function with error handling
 *
 * @example
 * const safeFetch = withErrorHandling(
 *   async () => fetch('https://api.example.com/data'),
 *   {
 *     strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
 *     context: 'API Fetch',
 *     operation: 'fetchData'
 *   }
 * );
 */
export function withErrorHandling(fn, errorOptions = {}) {
  return async function(...args) {
    try {
      return await fn(...args);
    } catch (error) {
      return handleError(error, errorOptions);
    }
  };
}

/**
 * Validates required parameters and throws appropriate error if missing
 *
 * @param {Object} params - Parameters object to validate
 * @param {string[]} required - Array of required parameter names
 * @param {string} context - Context for error message
 * @param {Object} options - Validation options
 * @param {boolean} options.allowEmpty - Whether to allow empty strings as valid values
 * @throws {Error} If required parameters are missing
 */
export function validateRequiredParams(params, required, context, options = {}) {
  const { allowEmpty = false } = options;

  const missing = required.filter(key => {
    const value = params[key];
    const isEmpty = value === null || value === undefined || value === '';
    return isEmpty && !allowEmpty;
  });

  if (missing.length > 0) {
    throw new Error(`${context}: Missing required parameters: ${missing.join(', ')}`);
  }
}

/**
 * Creates a timeout error
 * @param {string} operation - The operation that timed out
 * @param {number} timeout - Timeout value in ms
 * @returns {Error} Timeout error
 */
export function createTimeoutError(operation, timeout) {
  const error = new Error(`${operation} timed out after ${timeout}ms`);
  error.name = 'TimeoutError';
  error.timeout = timeout;
  return error;
}

/**
 * Creates an authentication error
 * @param {string} service - The service that failed authentication
 * @returns {Error} Authentication error
 */
export function createAuthError(service) {
  const error = new Error(`Authentication failed for ${service}`);
  error.name = 'AuthenticationError';
  error.status = 401;
  return error;
}

/**
 * Creates a validation error
 * @param {string} field - The field that failed validation
 * @param {string} message - Validation error message
 * @returns {Error} Validation error
 */
export function createValidationError(field, message) {
  const error = new Error(`Validation failed for ${field}: ${message}`);
  error.name = 'ValidationError';
  error.field = field;
  return error;
}

/**
 * Checks if error is retryable (network errors, timeouts, 5xx errors)
 * @param {Error} error - The error to check
 * @returns {boolean} True if error is retryable
 */
export function isRetryableError(error) {
  // Network errors
  if (error.name === 'TypeError' && error.message.includes('fetch')) {
    return true;
  }

  // Timeout errors
  if (error.name === 'TimeoutError' || error.name === 'AbortError') {
    return true;
  }

  // 5xx server errors
  if (error.status >= 500 && error.status < 600) {
    return true;
  }

  // 429 Too Many Requests
  if (error.status === 429) {
    return true;
  }

  return false;
}
