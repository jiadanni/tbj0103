/**
 * Rate Limiter Module
 */

/**
 * Simple rate limiter for API calls
 */
export class RateLimiter {
    constructor(maxCalls = 10, windowMs = 1000) {
        this.maxCalls = maxCalls;
        this.windowMs = windowMs;
        this.calls = [];
    }

    /**
     * Check if a call can be made within rate limits
     * @returns {boolean} True if call is allowed
     */
    canMakeCall() {
        const now = Date.now();
        // Remove calls outside the window
        this.calls = this.calls.filter(timestamp => now - timestamp < this.windowMs);

        if (this.calls.length >= this.maxCalls) {
            return false;
        }

        this.calls.push(now);
        return true;
    }

    /**
     * Get time until next call is allowed (in ms)
     * @returns {number} Milliseconds until next call allowed, or 0 if allowed now
     */
    timeUntilNextCall() {
        const now = Date.now();
        this.calls = this.calls.filter(timestamp => now - timestamp < this.windowMs);

        if (this.calls.length < this.maxCalls) {
            return 0;
        }

        const oldestCall = Math.min(...this.calls);
        return (oldestCall + this.windowMs) - now;
    }
}
