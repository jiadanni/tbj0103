/**
 * Input Validation Module
 * Provides validation helpers for PandAid extension
 */
import { createLogger } from '../utils/logger.js';

const logger = createLogger('Validation');

/**
 * Validates an API token (basic format check)
 * @param {string} token - The API token to validate
 * @returns {{valid: boolean, error?: string}} Validation result
 */
export function validateApiToken(token) {
    if (!token || typeof token !== 'string') {
        return { valid: false, error: 'API token is required' };
    }

    const trimmed = token.trim();

    if (trimmed.length === 0) {
        return { valid: false, error: 'API token cannot be empty' };
    }

    if (trimmed.length < 10) {
        return { valid: false, error: 'API token appears too short (minimum 10 characters)' };
    }

    // Check for obviously invalid tokens
    if (trimmed === 'your-token-here' || trimmed === 'placeholder' || trimmed === 'xxx') {
        return { valid: false, error: 'Please enter a valid API token' };
    }

    return { valid: true };
}

/**
 * Validates Atlassian base URL
 * @param {string} input - The Company slug or Atlassian URL
 * @returns {{valid: boolean, error?: string, normalized?: string, slug?: string}} Validation result
 */
export function validateAtlassianUrl(input) {
    if (!input || typeof input !== 'string') {
        return { valid: false, error: 'Company slug or Atlassian URL is required' };
    }

    const trimmed = input.trim();

    if (trimmed.length === 0) {
        return { valid: false, error: 'Company slug or Atlassian URL cannot be empty' };
    }

    // Accept either a plain slug or an already-formed https://<slug>.atlassian.net URL
    const slugPattern = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
    let slugCandidate = trimmed;

    if (trimmed.includes('://')) {
        try {
            const parsed = new URL(trimmed);
            const host = (parsed.hostname || '').toLowerCase();
            if (!host.endsWith('.atlassian.net')) {
                return {
                    valid: false,
                    error: 'Must be an Atlassian cloud domain (e.g., your-company.atlassian.net)'
                };
            }
            slugCandidate = host.replace(/\.atlassian\.net$/, '');
        } catch (e) {
            logger.debug('Error parsing Atlassian URL candidate:', 'validation', e);
            return {
                valid: false,
                error: 'Enter a company slug (e.g., your-company) or full Atlassian URL (https://your-company.atlassian.net).'
            };
        }
    }

    if (!slugPattern.test(slugCandidate)) {
        return {
            valid: false,
            error: 'Company slug must be alphanumeric and may include hyphens (e.g., your-company)'
        };
    }

    const normalized = `https://${slugCandidate}.atlassian.net`;
    return { valid: true, normalized, slug: slugCandidate };
}

/**
 * Validates local search server URL
 * Only allows localhost or 127.0.0.1 for security (prevents SSRF attacks)
 * @param {string} url - The local search server URL
 * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
 */
export function validateLocalServerUrl(url) {
    if (!url || typeof url !== 'string') {
        return { valid: false, error: 'Local server URL is required' };
    }

    const trimmed = url.trim();

    if (trimmed.length === 0) {
        return { valid: false, error: 'Local server URL cannot be empty' };
    }

    // Security: Only allow localhost or 127.0.0.1 to prevent SSRF attacks
    const localPattern = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?\/?$/;

    if (!localPattern.test(trimmed)) {
        return {
            valid: false,
            error: 'URL must be localhost or 127.0.0.1 (e.g., http://127.0.0.1:5002). Remote servers are not allowed for security reasons.'
        };
    }

    // Normalize URL (remove trailing slash)
    const normalized = trimmed.replace(/\/$/, '');

    return { valid: true, normalized };
}

/**
 * Validates JIRA project key format
 * @param {string} key - The JIRA project key
 * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
 */
export function validateJiraProjectKey(key) {
    if (!key || typeof key !== 'string') {
        // Project key is optional
        return { valid: true, normalized: '' };
    }

    const trimmed = key.trim();

    if (trimmed.length === 0) {
        return { valid: true, normalized: '' };
    }

    // Convert to uppercase first
    const upper = trimmed.toUpperCase();

    // JIRA project keys must be uppercase letters only, 2-10 characters
    const jiraKeyPattern = /^[A-Z]{2,10}$/;

    if (!jiraKeyPattern.test(upper)) {
        return {
            valid: false,
            error: 'Project key must be 2-10 uppercase letters (e.g., IMP, PROJ)'
        };
    }

    return { valid: true, normalized: upper };
}

/**
 * Validates the AI Service API endpoint URL
 * @param {string} endpoint - The endpoint URL to validate
 * @returns {{valid: boolean, error?: string, normalized?: string}} Validation result
 */
export function validateAiEndpoint(endpoint) {
    if (!endpoint || typeof endpoint !== 'string') {
        return { valid: false, error: 'API endpoint is required' };
    }

    const trimmed = endpoint.trim().replace(/\/$/, '');

    try {
        const url = new URL(trimmed);

        // AI Service API endpoint must use HTTPS for security
        if (url.protocol !== 'https:') {
            return { valid: false, error: 'AI Service API endpoint must use HTTPS' };
        }

        // Tighten security: Prevent local/internal network addresses for the primary AI service
        const hostname = url.hostname.toLowerCase();

        // Check for private/local addresses (SSRF prevention)
        // Check for private/local addresses (SSRF prevention)
        const isLocal = hostname === 'localhost' ||
            hostname === '127.0.0.1' ||
            hostname.startsWith('192.168.') ||
            hostname.startsWith('10.') ||
            hostname.endsWith('.local') ||
            // IPv6 loopback, link-local, site-local, unique-local, and ipv4-mapped
            hostname === '::1' ||
            hostname === '[::1]' ||
            /^fe80:/i.test(hostname) ||   // Link-Local
            /^fec0:/i.test(hostname) ||   // Site-Local (deprecated)
            /^fc00:/i.test(hostname) ||   // Unique Local Address (ULA)
            /^fd00:/i.test(hostname) ||   // Unique Local Address (ULA)
            /^::ffff:/i.test(hostname);   // IPv4-mapped IPv6

        // Check full 172.16.0.0/12 private range (172.16.x.x - 172.31.x.x)
        // RegEx explanation: 172 . (16-19 | 20-29 | 30-31) . x . x
        const is172Private = /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname);

        if (isLocal || is172Private) {
            return {
                valid: false,
                error: 'AI Service endpoint cannot be a local or private network address for security reasons. Use a public HTTPS gateway.'
            };
        }

        return { valid: true, normalized: url.toString().replace(/\/$/, '') };
    } catch (error) {
        logger.debug('Error parsing AI endpoint URL:', 'validation', error);
        return { valid: false, error: 'Invalid URL format for API endpoint' };
    }
}

/**
 * Validates and sanitizes a URL to prevent injection attacks
 * @param {string} url - The URL to validate
 * @param {string[]} allowedProtocols - Allowed protocols (default: ['https:', 'http:'])
 * @returns {{valid: boolean, error?: string, sanitized?: string}} Validation result
 */
export function sanitizeUrl(url, allowedProtocols = ['https:', 'http:']) {
    if (!url || typeof url !== 'string') {
        return { valid: false, error: 'URL is required' };
    }

    try {
        const parsed = new URL(url);

        if (!allowedProtocols.includes(parsed.protocol)) {
            return {
                valid: false,
                error: `Protocol must be one of: ${allowedProtocols.join(', ')}`
            };
        }

        // Prevent javascript: and data: URLs
        if (parsed.protocol === 'javascript:' || parsed.protocol === 'data:') {
            return { valid: false, error: 'Invalid URL protocol' };
        }

        return { valid: true, sanitized: parsed.href };
    } catch (error) {
        logger.debug('Error parsing URL for sanitization:', 'validation', error);
        return { valid: false, error: 'Invalid URL format' };
    }
}

/**
 * Validates AI relevance score (0-100)
 * @param {number} score - The score to validate
 * @returns {{valid: boolean, error?: string, normalized?: number}} Validation result
 */
export function validateScore(score) {
    if (score === null || score === undefined) {
        return { valid: false, error: 'Score is required' };
    }

    const num = Number(score);

    if (isNaN(num)) {
        return { valid: false, error: 'Score must be a number' };
    }

    if (num < 0 || num > 100) {
        return { valid: false, error: 'Score must be between 0 and 100' };
    }

    return { valid: true, normalized: Math.round(num) };
}
