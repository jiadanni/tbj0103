/**
 * Permissions and Configuration Module
 * Provides helper functions for managing API endpoints and permissions.
 */
import { createLogger } from '../utils/logger.js';
import { validateAiEndpoint } from './validation.js';

const logger = createLogger('Permissions');

/**
 * Get API endpoint from configuration.
 * Requires endpoint to be configured via chrome.storage.
 * 
 * @returns {Promise<string>} The API endpoint URL
 * @throws {Error} If API endpoint is not configured
 */
export async function getApiEndpoint() {
    try {
        const { apiEndpoint } = await chrome.storage.local.get('apiEndpoint');

        if (!apiEndpoint) {
            throw new Error('API endpoint is not configured. Please configure it in the extension options.');
        }

        // Basic runtime validation
        const validation = validateAiEndpoint(apiEndpoint);
        if (!validation.valid) {
            throw new Error(`Configured API endpoint is invalid: ${validation.error}`);
        }

        return validation.normalized;
    } catch (error) {
        logger.error('Error retrieving API endpoint:', 'permissions', error);
        throw error;
    }
}

/**
 * Persists a new API endpoint after validation.
 * 
 * @param {string} endpoint - The raw endpoint URL from user input
 * @throws {Error} If validation fails or storage write fails
 */
export async function setApiEndpoint(endpoint) {
    const validation = validateAiEndpoint(endpoint);

    if (!validation.valid) {
        throw new Error(validation.error);
    }

    try {
        await chrome.storage.local.set({ apiEndpoint: validation.normalized });
        logger.info('AI API endpoint successfully updated:', 'permissions', validation.normalized);
    } catch (error) {
        logger.error('Error setting API endpoint:', 'permissions', error);
        throw new Error('Failed to save API endpoint to storage');
    }
}

/**
 * Ensure the extension has host permission for a given URL (prompts user if needed).
 * @param {string} url - The full URL whose origin should be permitted
 * @param {boolean} [promptIfNeeded=false] - Whether to prompt the user if permission is missing
 * @returns {Promise<void>}
 */
export async function ensureHostPermissionForUrl(url, promptIfNeeded = false) {
    if (!url) {
        throw new Error('API endpoint is not configured');
    }
    const parsed = new URL(url);
    const originPattern = `${parsed.protocol}//${parsed.host}/*`;

    try {
        const hasPerm = await chrome.permissions.contains({ origins: [originPattern] });
        if (hasPerm) return;

        // If caller doesn't want us to prompt (e.g., running in a non-user-gesture
        // context like background/message handler), surface a clear error so the
        // caller or UI can request permission from a user gesture.
        if (!promptIfNeeded) {
            const err = new Error(`Missing host permission for ${originPattern}`);
            err.code = 'MISSING_HOST_PERMISSION';
            throw err;
        }

        // Attempt to request permissions. Note: this must be called during a
        // user gesture (e.g., in an options page click handler).
        try {
            const granted = await chrome.permissions.request({ origins: [originPattern] });
            if (!granted) {
                const err = new Error(`Permission denied for ${originPattern}`);
                err.code = 'PERMISSION_DENIED';
                throw err;
            }
        } catch (requestErr) {
            logger.debug('Error requesting host permission:', 'permissions', requestErr);
            // Detect user-gesture-related failure and rethrow a specific error code
            const isUserGestureError = requestErr && (requestErr.message && requestErr.message.toLowerCase().includes('user gesture')) || (requestErr.name === 'InvalidStateError');
            if (isUserGestureError) {
                const err = new Error('Permission request must be performed from a user gesture (UI).');
                err.code = 'USER_GESTURE_REQUIRED';
                err.cause = requestErr;
                throw err;
            }
            throw requestErr;
        }
    } catch (err) {
        logger.error('Failed to ensure host permission for', 'permissions', originPattern, err);
        throw err;
    }
}
