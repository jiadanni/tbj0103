// modules/content/case-extractor.js
//
// Extract case data from the Salesforce page.

import { isVerbose } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('CaseExtractor');

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function escapeRegExp(value) {
  const str = (typeof value === 'string' ? value : String(value || '')).slice(0, 200);
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export async function getCaseData(assistant) {
  const maxAttempts = 3;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const caseData = {
      caseId: assistant?.sidebar?.getFieldValueByLabel('Case Number') || window.location.pathname.split('/').pop(),
      subject: assistant?.sidebar?.getFieldValueByLabel('Subject'),
      description: assistant?.sidebar?.getFieldValueByLabel('Description'),
      status: assistant?.sidebar?.getFieldValueByLabel('Status'),
      priority: assistant?.sidebar?.getFieldValueByLabel('Priority'),
      type: assistant?.sidebar?.getFieldValueByLabel('Type'),
      origin: assistant?.sidebar?.getFieldValueByLabel('Origin'),
      productFamily: assistant?.sidebar?.getFieldValueByLabel('Product Family'),
      productComponent: (() => {
        const affected = assistant?.sidebar?.getFieldValueByLabel('Product Component Affected');
        if (affected !== undefined) return affected;
        const section = assistant?.sidebar?.getFieldValueByLabel('Product Component Section');
        if (section !== undefined) return section;
        return undefined;
      })(),
      contact: {
        name: assistant?.sidebar?.getFieldValueByLabel('Contact Name'),
        email: assistant?.sidebar?.getFieldValueByLabel('Contact Email'),
        phone: assistant?.sidebar?.getFieldValueByLabel('Contact Phone')
      }
    };

    if (caseData.description) {
      const iframe = document.querySelector('.slds-rich-text-area iframe');
      if (iframe) {
        const iframeUrl = iframe.getAttribute('src');
        const iframeOrigin = iframeUrl ? new URL(iframeUrl, window.location.href).origin : window.location.origin;
        const sameOrigin = iframeOrigin === window.location.origin;

        if (!sameOrigin) {
          if (isVerbose()) logger.warn('Skipping iframe description extraction: cross-origin iframe detected', 'case-extractor', undefined);
        } else {
          try {
            caseData.description = iframe.contentDocument?.body?.innerText || caseData.description;
          } catch (e) {
            logger.error('Could not access iframe content:', 'case-extractor', e);
          }
        }
      }
    }

    const hasValidSubject = caseData.subject &&
      !caseData.subject.includes('to change without notice') &&
      caseData.subject.trim().length > 0;

    if (hasValidSubject || attempt === maxAttempts) {
      if (isVerbose()) logger.info('Case data extracted:', 'case-extractor', caseData);
      return caseData;
    }

    if (isVerbose()) logger.info(`Case data not ready, attempt ${attempt}/${maxAttempts}, retrying in 500ms...`, 'contextual', undefined);
    await delay(500);
  }

  return null;
}

function findValueForLabel(labelElement, originalLabel) {
  try {
    const formElement = labelElement.closest(
      '.slds-form-element, .forceDetailPanelDesktopLayoutItem, [data-aura-class*="forceDetailPanelDesktopLayoutItem"]'
    );
    if (formElement) {
      if (originalLabel.toLowerCase().includes('owner') || originalLabel.toLowerCase().includes('assigned')) {
        const userSpans = formElement.querySelectorAll('.slds-form-element__control > span, .slds-form-element__control > div > span');
        for (const span of userSpans) {
          const value = span.textContent?.trim();
          if (value && value !== originalLabel && value.split(' ').length >= 2 && value.length > 3 && value.length < 50) {
            if (!value.match(/\b(open|edit|view|preview|click|select|choose|more|less)\b/i)) return value;
          }
        }
      }
      const lightningTexts = formElement.querySelectorAll('lightning-formatted-text, [data-aura-class*="lightning-formatted-text"]');
      for (const lt of lightningTexts) {
        const value = lt.textContent?.trim();
        if (value && value !== originalLabel && value.length > 0 && !value.includes('to change without notice')) return value;
      }
      const controlAreas = formElement.querySelectorAll('.slds-form-element__control, .forceOutputText, [data-aura-class*="forceOutputText"]');
      for (const control of controlAreas) {
        const value = control.textContent?.trim();
        if (value && value !== originalLabel && value.length > 0 && value.length < 200 && !value.includes('to change without notice')) {
          if (!originalLabel.toLowerCase().includes('owner') && !originalLabel.toLowerCase().includes('assigned')) return value;
        }
      }
    }
    return '';
  } catch (error) {
    logger.error('Error finding value for label:', 'case-extractor', originalLabel, error);
    return '';
  }
}

function getFieldValueByLabel(label) {
  try {
    const lightningSelectors = [
      '.test-id__field-label',
      'span.test-id__field-label',
      '[data-target-selection-name*="field"]',
      '.slds-form-element__label',
      '.forceInputLabel',
      '[data-aura-class*="forceInputLabel"]',
      '.field-label',
      '[class*="field-label"]'
    ];
    for (const selector of lightningSelectors) {
      const labels = document.querySelectorAll(selector);
      for (const labelElement of labels) {
        const labelText = labelElement.textContent?.trim();
        if (labelText && labelText.toLowerCase() === label.toLowerCase()) {
          const value = findValueForLabel(labelElement, label);
          if (value !== null) return value;
        }
      }
    }
    const allSpans = document.querySelectorAll('span');
    for (const span of allSpans) {
      const spanText = span.textContent?.trim();
      if (spanText && spanText.toLowerCase() === label.toLowerCase()) {
        const value = findValueForLabel(span, label);
        if (value !== null) return value;
      }
    }
    const textPattern = new RegExp(`${escapeRegExp(label)}\\s*:?\\s*([^\\n\\r]+)`, 'i');
    const bodyText = document.body.textContent || '';
    const match = bodyText.match(textPattern);
    if (match && match[1]) {
      const potentialValue = match[1].trim();
      if (potentialValue.toLowerCase() !== label.toLowerCase() && potentialValue.length >= 0 && potentialValue.length < 200) return potentialValue;
    }
    return undefined;
  } catch (error) {
    logger.error('Error getting field value for label:', 'case-extractor', label, error);
    return undefined;
  }
}

export async function extractCaseDataFromDom() {
  const caseId = window.location.pathname.split('/').pop();
  const subject = document.querySelector('[data-target-selection-name*="Subject"] lightning-formatted-text')?.textContent?.trim()
    || getFieldValueByLabel('Subject');
  const description = document.querySelector('[data-target-selection-name*="Description"] lightning-formatted-text')?.textContent?.trim()
    || getFieldValueByLabel('Description');
  const productFamily = document.querySelector('[data-target-selection-name*="Product_Family"] lightning-formatted-text')?.textContent?.trim()
    || getFieldValueByLabel('Product Family')
    || getFieldValueByLabel('Product');
  const productComponent = document.querySelector('[data-target-selection-name*="Product_Component"] lightning-formatted-text')?.textContent?.trim()
    || getFieldValueByLabel('Product Component')
    || getFieldValueByLabel('Product Component Affected')
    || getFieldValueByLabel('Product Component Section');

  return {
    caseId: caseId || null,
    subject: subject || null,
    description: description || null,
    productFamily: productFamily || null,
    productComponent: productComponent || null
  };
}

export const __testOnly__ = {
  getFieldValueByLabel,
  findValueForLabel,
  escapeRegExp
};
