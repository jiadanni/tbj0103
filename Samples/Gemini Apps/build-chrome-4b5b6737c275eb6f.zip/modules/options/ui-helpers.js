// modules/options/ui-helpers.js
//
// UI helper utilities for status messaging and inline errors.

import { createLogger } from '../utils/logger.js';
const logger = createLogger('OptionsUI');

export function showSectionStatus(element, message, type = 'info') {
  if (!element) return;
  element.textContent = message;
  element.className = `status ${type}`;
  element.style.display = 'block';
  if (type !== 'error') {
    setTimeout(() => {
      try {
        element.style.display = 'none';
      } catch (e) {
        logger.debug('Error hiding status element (likely removed)', 'ui-helpers', e);
      }
    }, 5000);
  }
}

export function showStatus(statusElement, message, type = 'info') {
  showSectionStatus(statusElement, message, type);
}

export function showAtlassianUrlInputError(atlassianBaseUrlInput, message) {
  if (!atlassianBaseUrlInput) return;
  let err = document.getElementById('atlassian-base-url-error');
  if (!err) {
    err = document.createElement('p');
    err.id = 'atlassian-base-url-error';
    err.className = 'input-error';
    err.style.color = '#b22222';
    err.style.fontSize = '12px';
    err.style.margin = '6px 0 0 0';
    if (atlassianBaseUrlInput.parentNode) atlassianBaseUrlInput.parentNode.appendChild(err);
  }
  err.textContent = message;
  err.style.display = 'block';
}


export function hideAtlassianUrlInputError() {
  const err = document.getElementById('atlassian-base-url-error');
  if (err) err.style.display = 'none';
}

export function setupSliderMirrors(config = {}) {
  Object.entries(config).forEach(([id, outputId]) => {
    const slider = document.getElementById(id);
    const output = document.getElementById(outputId);
    if (slider && output) {
      slider.addEventListener('input', () => {
        output.textContent = id === 'sidebar-width' ? `${slider.value}px` : `${slider.value}%`;
      });
    }
  });
}
