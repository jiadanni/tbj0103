// Helpers to request and check host permissions
export function requestHostPermission(origin) {
  return new Promise((resolve) => {
    if (!chrome.permissions) return resolve(false);
    chrome.permissions.request({ origins: [origin] }, (granted) => {
      resolve(!!granted);
    });
  });
}

export function checkHostPermission(origin) {
  return new Promise((resolve) => {
    if (!chrome.permissions) return resolve(false);
    chrome.permissions.contains({ origins: [origin] }, (granted) => {
      resolve(!!granted);
    });
  });
}

export function removeHostPermission(origin) {
  return new Promise((resolve) => {
    if (!chrome.permissions || !chrome.permissions.remove) return resolve(false);
    chrome.permissions.remove({ origins: [origin] }, (removed) => {
      resolve(!!removed);
    });
  });
}
