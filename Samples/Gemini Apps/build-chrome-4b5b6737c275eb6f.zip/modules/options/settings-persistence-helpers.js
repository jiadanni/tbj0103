/**
 * Helper utilities for settings persistence.
 */

import { TOKEN_PLACEHOLDER } from '../config/constants.js';

export function buildSettingsToSave({ elements, values }) {
  const {
    jiraPreloadToggle,
    confluencePreloadToggle,
    communityPreloadToggle,
    jiraMinScoreSlider,
    communityMinScoreSlider,
    confluenceMinScoreSlider,
    showJiraExplanationsToggle,
    showConfluenceExplanationsToggle,
    showCommunityExplanationsToggle,
    aiJiraToggle,
    aiConfluenceToggle,
    aiCommunityToggle,
    aiModel1Input,
    aiModel2Input,
    aiModel3Input,
    activeModel1Radio,
    activeModel2Radio,
    activeModel3Radio,
    summaryTempSlider,
    summaryTopPSlider,
    summaryTopKSlider,
    communityTempSlider,
    communityTopPSlider,
    communityTopKSlider,
    jiraTempSlider,
    jiraTopPSlider,
    jiraTopKSlider,
    confluenceTempSlider,
    confluenceTopPSlider,
    confluenceTopKSlider,
    verboseLoggingToggle,
    localSearchUrlInput,
    localSearchEnableToggle,
    knowledgeBaseEntryLabelInput,
    knowledgeBaseSidebarLabelInput,
    sidebarJiraToggle,
    sidebarConfluenceToggle,
    sidebarCommunityToggle,
    sidebarWidthSlider,
    buttonLabelInput,
    sidebarLabelInput
  } = elements;

  const {
    apiEndpoint,
    aiEnabled,
    atlassianBaseUrl,
    atlassianEmail,
    jiraProjectKey,
    disableTokenEncryption
  } = values;

  return {
    apiEndpoint: apiEndpoint || null,
    aiEnabled,
    atlassianBaseUrl: atlassianBaseUrl || null,
    atlassianEmail: atlassianEmail || null,
    jiraProjectKey: jiraProjectKey || null,
    disableTokenEncryption: !!disableTokenEncryption,
    preloadSettings: {
      jira: jiraPreloadToggle.checked,
      confluence: confluencePreloadToggle.checked,
      community: communityPreloadToggle.checked,
      knowledgeBase: communityPreloadToggle.checked,
      enableAiFilter: true,
      enableAtlassianAiFilter: true,
      enableCommunityAiFilter: true,
      jiraMinScore: parseInt(jiraMinScoreSlider.value),
      communityMinScore: parseInt(communityMinScoreSlider.value),
      confluenceMinScore: parseInt(confluenceMinScoreSlider.value)
    },
    aiEnhancementSettings: {
      jira: aiJiraToggle.checked,
      confluence: aiConfluenceToggle.checked,
      community: aiCommunityToggle.checked,
      showExplanations: {
        jira: showJiraExplanationsToggle.checked,
        confluence: showConfluenceExplanationsToggle.checked,
        community: showCommunityExplanationsToggle.checked
      },
      userToggled: {
        jira: !!aiJiraToggle && aiJiraToggle.checked,
        confluence: !!aiConfluenceToggle && aiConfluenceToggle.checked,
        community: !!aiCommunityToggle && aiCommunityToggle.checked
      }
    },
    advancedAiSettings: {
      models: {
        model1: aiModel1Input ? aiModel1Input.value.trim() : '',
        model2: aiModel2Input ? aiModel2Input.value.trim() : '',
        model3: aiModel3Input ? aiModel3Input.value.trim() : ''
      },
      activeModel: activeModel1Radio?.checked ? 1 : (activeModel2Radio?.checked ? 2 : (activeModel3Radio?.checked ? 3 : 1)),
      contextSettings: {
        caseSummary: {
          temperature: parseFloat((summaryTempSlider.value / 100).toFixed(2)),
          topP: parseFloat((summaryTopPSlider.value / 100).toFixed(2)),
          topK: parseInt(summaryTopKSlider.value)
        },
        communityGuides: {
          temperature: parseFloat((communityTempSlider.value / 100).toFixed(2)),
          topP: parseFloat((communityTopPSlider.value / 100).toFixed(2)),
          topK: parseInt(communityTopKSlider.value)
        },
        jira: {
          temperature: parseFloat((jiraTempSlider.value / 100).toFixed(2)),
          topP: parseFloat((jiraTopPSlider.value / 100).toFixed(2)),
          topK: parseInt(jiraTopKSlider.value)
        },
        confluence: {
          temperature: parseFloat((confluenceTempSlider.value / 100).toFixed(2)),
          topP: parseFloat((confluenceTopPSlider.value / 100).toFixed(2)),
          topK: parseInt(confluenceTopKSlider.value)
        }
      }
    },
    verboseLogging: verboseLoggingToggle && verboseLoggingToggle.checked,
    localSearchServerUrl: localSearchUrlInput && localSearchUrlInput.value ? localSearchUrlInput.value.trim() : undefined,
    localSearchEnabled: localSearchEnableToggle && localSearchEnableToggle.checked,
    knowledgeBaseLabels: {
      entryLabel: (knowledgeBaseEntryLabelInput && knowledgeBaseEntryLabelInput.value.trim()) || 'Knowledge Base',
      sidebarLabel: (knowledgeBaseSidebarLabelInput && knowledgeBaseSidebarLabelInput.value.trim()) ||
        (knowledgeBaseEntryLabelInput && knowledgeBaseEntryLabelInput.value.trim()) ||
        'Knowledge Base'
    },
    sidebarSections: {
      jira: sidebarJiraToggle ? sidebarJiraToggle.checked : true,
      confluence: sidebarConfluenceToggle ? sidebarConfluenceToggle.checked : true,
      community: sidebarCommunityToggle ? sidebarCommunityToggle.checked : true
    },
    sidebarWidth: sidebarWidthSlider ? parseInt(sidebarWidthSlider.value) : 500,
    buttonLabel: (buttonLabelInput && buttonLabelInput.value.trim()) || 'PandAid',
    sidebarLabel: (sidebarLabelInput && sidebarLabelInput.value.trim()) || 'PandAid Case Assistant'
  };
}

export function applyLoadedSettings({
  data,
  elements,
  helpers,
  aiHelpers,
  logger
}) {
  const {
    apiEndpointInput,
    aiServiceTokenInput,
    aiGlobalEnable,
    atlassianTokenInput,
    atlassianBaseUrlInput,
    atlassianEmailInput,
    jiraProjectKeyInput,
    knowledgeBaseEntryLabelInput,
    knowledgeBaseSidebarLabelInput,
    disableTokenEncryptionToggle,
    showJiraExplanationsToggle,
    showConfluenceExplanationsToggle,
    showCommunityExplanationsToggle,
    aiJiraToggle,
    aiConfluenceToggle,
    aiCommunityToggle,
    atlassianAiScoreSettings,
    communityAiScoreSettings,
    jiraPreloadToggle,
    confluencePreloadToggle,
    communityPreloadToggle,
    jiraMinScoreSlider,
    communityMinScoreSlider,
    confluenceMinScoreSlider,
    jiraScoreValue,
    communityScoreValue,
    confluenceScoreValue,
    sidebarJiraToggle,
    sidebarConfluenceToggle,
    sidebarCommunityToggle,
    aiModel1Input,
    aiModel2Input,
    aiModel3Input,
    activeModel1Radio,
    activeModel2Radio,
    activeModel3Radio,
    summaryTempSlider,
    summaryTopPSlider,
    summaryTopKSlider,
    summaryTempValue,
    summaryTopPValue,
    summaryTopKValue,
    communityTempSlider,
    communityTopPSlider,
    communityTopKSlider,
    communityTempValue,
    communityTopPValue,
    communityTopKValue,
    jiraTempSlider,
    jiraTopPSlider,
    jiraTopKSlider,
    jiraTempValue,
    jiraTopPValue,
    jiraTopKValue,
    confluenceTempSlider,
    confluenceTopPSlider,
    confluenceTopKSlider,
    confluenceTempValue,
    confluenceTopPValue,
    confluenceTopKValue,
    testAiResultElement: _testAiResultElement,
    aiTestSection,
    localSearchUrlInput,
    localSearchEnableToggle,
    checkLocalServerButton,
    verboseLoggingToggle,
    searchModeAiVector,
    searchModeKeyword,
    searchModeKeywordVector,
    sidebarWidthSlider,
    sidebarWidthValue,
    toggleAiTokenButton,
    toggleAtlassianTokenButton,
    aiFilterToggle,
    communityAiFilterToggle,
    advancedAiSettings,
    buttonLabelInput,
    sidebarLabelInput
  } = elements;

  const {
    updateToggleVisibility,
    updateToggleIcon,
    setAiMasterAvailability,
    applyKnowledgeBaseLabels,
    initializeDefaultContextSettings
  } = helpers;

  const { sliderGroups } = aiHelpers;

  if (data.apiEndpoint) apiEndpointInput.value = data.apiEndpoint;

  if (data.aiServiceToken) {
    aiServiceTokenInput.value = TOKEN_PLACEHOLDER;
    aiServiceTokenInput.type = 'password';
    updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
    aiServiceTokenInput.setAttribute('data-is-saved', 'true');
    updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, true);
  } else {
    updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
    updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
  }

  if (aiGlobalEnable) {
    try {
      aiGlobalEnable.checked = (typeof data.aiEnabled === 'boolean') ? data.aiEnabled : true;
    } catch (e) {
      logger.debug('Error setting aiGlobalEnable:', 'settings-persistence-helpers', e);
      aiGlobalEnable.checked = true;
    }
  }

  if (aiTestSection && aiGlobalEnable) {
    aiTestSection.style.display = aiGlobalEnable.checked ? 'block' : 'none';
  }
  setAiMasterAvailability(!!(aiGlobalEnable && aiGlobalEnable.checked));

  if (data.atlassianToken) {
    atlassianTokenInput.value = TOKEN_PLACEHOLDER;
    atlassianTokenInput.type = 'password';
    updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);
    atlassianTokenInput.setAttribute('data-is-saved', 'true');
    updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, true);
  } else {
    updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
    updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);

    if (jiraPreloadToggle) jiraPreloadToggle.checked = false;
    if (confluencePreloadToggle) confluencePreloadToggle.checked = false;
    if (aiJiraToggle) aiJiraToggle.checked = false;
    if (aiConfluenceToggle) aiConfluenceToggle.checked = false;
    if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = false;
    if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = false;
  }

  const deriveAtlassianSlug = (baseUrl) => {
    try {
      const u = new URL(baseUrl);
      const host = u.hostname || '';
      if (host.endsWith('.atlassian.net')) {
        return host.replace(/\.atlassian\.net$/i, '');
      }
    } catch (e) {
      logger.debug('Error deriving Atlassian slug:', 'settings-persistence-helpers', { error: e, baseUrl });
    }
    return baseUrl || '';
  };

  if (atlassianBaseUrlInput) {
    atlassianBaseUrlInput.value = data.atlassianBaseUrl ? deriveAtlassianSlug(data.atlassianBaseUrl) : '';
  }
  if (data.atlassianEmail) atlassianEmailInput.value = data.atlassianEmail;
  if (disableTokenEncryptionToggle) {
    disableTokenEncryptionToggle.checked = !!data.disableTokenEncryption;
  }

  if (data.localSearchServerUrl && localSearchUrlInput) {
    localSearchUrlInput.value = data.localSearchServerUrl;
  }

  if (typeof data.localSearchEnabled === 'boolean') {
    if (localSearchEnableToggle) localSearchEnableToggle.checked = data.localSearchEnabled;
  } else if (localSearchEnableToggle) {
    localSearchEnableToggle.checked = false;
  }

  const knowledgeBaseLabels = {
    entryLabel: data.knowledgeBaseLabels?.entryLabel || 'Knowledge Base',
    sidebarLabel: data.knowledgeBaseLabels?.sidebarLabel || data.knowledgeBaseLabels?.entryLabel || 'Knowledge Base'
  };
  if (knowledgeBaseEntryLabelInput) knowledgeBaseEntryLabelInput.value = knowledgeBaseLabels.entryLabel;
  if (knowledgeBaseSidebarLabelInput) knowledgeBaseSidebarLabelInput.value = knowledgeBaseLabels.sidebarLabel;
  if (applyKnowledgeBaseLabels) applyKnowledgeBaseLabels(knowledgeBaseLabels);

  if (checkLocalServerButton && localSearchEnableToggle) {
    checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
  }

  try {
    chrome.storage.local.get({ searchSettings: { mode: 'keyword' } }, (ss) => {
      try {
        const mode = (ss && ss.searchSettings && ss.searchSettings.mode) ? ss.searchSettings.mode : 'keyword';
        if (mode === 'generative') {
          if (searchModeAiVector) searchModeAiVector.checked = true;
        } else if (mode === 'vector') {
          if (searchModeKeywordVector) searchModeKeywordVector.checked = true;
        } else {
          if (searchModeKeyword) searchModeKeyword.checked = true;
        }
      } catch (innerErr) {
        logger.warn('Error applying searchSettings.mode:', 'settings-persistence', innerErr);
        if (searchModeKeyword) searchModeKeyword.checked = true;
      }
    });
  } catch (err) {
    logger.warn('Error loading searchSettings.mode:', 'settings-persistence', err);
    if (searchModeKeyword) searchModeKeyword.checked = true;
  }

  if (data.jiraProjectKey) jiraProjectKeyInput.value = data.jiraProjectKey;

  if (data.preloadSettings) {
    const hasAtlassianToken = data.atlassianToken && data.atlassianToken.trim().length > 0;
    const preload = data.preloadSettings || {};

    if (jiraPreloadToggle) {
      jiraPreloadToggle.checked = hasAtlassianToken ? preload.jira !== false : false;
    }

    if (confluencePreloadToggle) {
      confluencePreloadToggle.checked = hasAtlassianToken ? preload.confluence !== false : false;
    }

    const communityPreloadSetting = (typeof preload.community !== 'undefined')
      ? preload.community !== false
      : preload.knowledgeBase !== false;
    if (communityPreloadToggle) communityPreloadToggle.checked = communityPreloadSetting;

    if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'block';
    if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'block';

    if (jiraMinScoreSlider) {
      jiraMinScoreSlider.value = preload.jiraMinScore || 50;
      if (jiraScoreValue) jiraScoreValue.textContent = `${jiraMinScoreSlider.value}%`;
    }

    if (communityMinScoreSlider) {
      communityMinScoreSlider.value = preload.communityMinScore || 50;
      if (communityScoreValue) communityScoreValue.textContent = `${communityMinScoreSlider.value}%`;
    }

    if (confluenceMinScoreSlider) {
      confluenceMinScoreSlider.value = preload.confluenceMinScore || 50;
      if (confluenceScoreValue) confluenceScoreValue.textContent = `${confluenceMinScoreSlider.value}%`;
    }
  } else {
    if (jiraPreloadToggle) jiraPreloadToggle.checked = false;
    if (confluencePreloadToggle) confluencePreloadToggle.checked = false;
    if (communityPreloadToggle) communityPreloadToggle.checked = false;
    if (aiFilterToggle) aiFilterToggle.checked = false;
    if (communityAiFilterToggle) communityAiFilterToggle.checked = false;
    if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'none';
    if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
  }

  if (typeof data.verboseLogging === 'boolean') {
    if (verboseLoggingToggle) verboseLoggingToggle.checked = data.verboseLogging;
  } else if (verboseLoggingToggle) {
    verboseLoggingToggle.checked = false;
  }

  if (data.aiEnhancementSettings) {
    const hasAtlassianToken = data.atlassianToken && data.atlassianToken.trim().length > 0;

    if (aiJiraToggle) {
      aiJiraToggle.checked = hasAtlassianToken ? data.aiEnhancementSettings.jira !== false : false;
    }

    if (aiConfluenceToggle) {
      aiConfluenceToggle.checked = hasAtlassianToken ? data.aiEnhancementSettings.confluence !== false : false;
    }

    if (aiCommunityToggle) {
      aiCommunityToggle.checked = data.aiEnhancementSettings.community !== false;
    }

    if (data.aiEnhancementSettings.showExplanations && typeof data.aiEnhancementSettings.showExplanations === 'object') {
      const hasToken = data.atlassianToken && data.atlassianToken.trim().length > 0;

      if (showJiraExplanationsToggle) {
        showJiraExplanationsToggle.checked = hasToken && aiJiraToggle && aiJiraToggle.checked
          ? data.aiEnhancementSettings.showExplanations.jira !== false
          : false;
      }

      if (showConfluenceExplanationsToggle) {
        showConfluenceExplanationsToggle.checked = hasToken && aiConfluenceToggle && aiConfluenceToggle.checked
          ? data.aiEnhancementSettings.showExplanations.confluence !== false
          : false;
      }

      if (showCommunityExplanationsToggle) {
        showCommunityExplanationsToggle.checked = aiCommunityToggle && aiCommunityToggle.checked
          ? data.aiEnhancementSettings.showExplanations.community !== false
          : false;
      }
    } else {
      const showExplanations = data.aiEnhancementSettings.showExplanations === true;
      const hasToken = data.atlassianToken && data.atlassianToken.trim().length > 0;
      if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = showExplanations && hasToken && aiJiraToggle && aiJiraToggle.checked;
      if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = showExplanations && hasToken && aiConfluenceToggle && aiConfluenceToggle.checked;
      if (showCommunityExplanationsToggle) showCommunityExplanationsToggle.checked = showExplanations && aiCommunityToggle && aiCommunityToggle.checked;
    }
  } else {
    if (aiJiraToggle) aiJiraToggle.checked = false;
    if (aiConfluenceToggle) aiConfluenceToggle.checked = false;
    if (aiCommunityToggle) aiCommunityToggle.checked = false;
    if (showJiraExplanationsToggle) showJiraExplanationsToggle.checked = false;
    if (showConfluenceExplanationsToggle) showConfluenceExplanationsToggle.checked = false;
    if (showCommunityExplanationsToggle) showCommunityExplanationsToggle.checked = false;
    setAiMasterAvailability(!!aiGlobalEnable && aiGlobalEnable.checked);
  }

  const sidebarSections = data.sidebarSections || {};
  if (sidebarJiraToggle) sidebarJiraToggle.checked = sidebarSections.jira !== false;
  if (sidebarConfluenceToggle) sidebarConfluenceToggle.checked = sidebarSections.confluence !== false;
  if (sidebarCommunityToggle) sidebarCommunityToggle.checked = sidebarSections.community !== false;

  if (data.advancedAiSettings) {
    if (advancedAiSettings) advancedAiSettings.style.display = 'block';

    if (data.advancedAiSettings.models) {
      if (aiModel1Input) {
        aiModel1Input.value = data.advancedAiSettings.models.model1 || 'anthropic.claude-3-sonnet-20240229-v1:0';
      }
      if (aiModel2Input) {
        aiModel2Input.value = data.advancedAiSettings.models.model2 || '';
      }
      if (aiModel3Input) {
        aiModel3Input.value = data.advancedAiSettings.models.model3 || '';
      }

      const activeModelNum = data.advancedAiSettings.activeModel || 1;
      if (activeModelNum === 1 && activeModel1Radio) {
        activeModel1Radio.checked = true;
      } else if (activeModelNum === 2 && activeModel2Radio) {
        activeModel2Radio.checked = true;
      } else if (activeModelNum === 3 && activeModel3Radio) {
        activeModel3Radio.checked = true;
      }
    } else {
      const legacyModel = data.advancedAiSettings.model || 'anthropic.claude-3-sonnet-20240229-v1:0';
      if (aiModel1Input) aiModel1Input.value = legacyModel;
      if (activeModel1Radio) activeModel1Radio.checked = true;
    }

    if (data.advancedAiSettings.contextSettings) {
      const contexts = data.advancedAiSettings.contextSettings;

      if (contexts.caseSummary) {
        if (summaryTempSlider) {
          const temp = contexts.caseSummary.temperature || 0.3;
          summaryTempSlider.value = Math.round(temp * 100);
          if (summaryTempValue) summaryTempValue.textContent = temp.toFixed(2);
        }

        if (summaryTopPSlider) {
          const topP = contexts.caseSummary.topP || 0.8;
          summaryTopPSlider.value = Math.round(topP * 100);
          if (summaryTopPValue) summaryTopPValue.textContent = topP.toFixed(2);
        }

        if (summaryTopKSlider) {
          const topK = contexts.caseSummary.topK || 40;
          summaryTopKSlider.value = topK;
          if (summaryTopKValue) summaryTopKValue.textContent = topK;
        }
      }

      if (contexts.communityGuides) {
        if (communityTempSlider) {
          const temp = contexts.communityGuides.temperature || 0.2;
          communityTempSlider.value = Math.round(temp * 100);
          if (communityTempValue) communityTempValue.textContent = temp.toFixed(2);
        }

        if (communityTopPSlider) {
          const topP = contexts.communityGuides.topP || 0.7;
          communityTopPSlider.value = Math.round(topP * 100);
          if (communityTopPValue) communityTopPValue.textContent = topP.toFixed(2);
        }

        if (communityTopKSlider) {
          const topK = contexts.communityGuides.topK || 30;
          communityTopKSlider.value = topK;
          if (communityTopKValue) communityTopKValue.textContent = topK;
        }
      }

      if (contexts.jira) {
        if (jiraTempSlider) {
          const temp = contexts.jira.temperature || 0.25;
          jiraTempSlider.value = Math.round(temp * 100);
          if (jiraTempValue) jiraTempValue.textContent = temp.toFixed(2);
        }

        if (jiraTopPSlider) {
          const topP = contexts.jira.topP || 0.85;
          jiraTopPSlider.value = Math.round(topP * 100);
          if (jiraTopPValue) jiraTopPValue.textContent = topP.toFixed(2);
        }

        if (jiraTopKSlider) {
          const topK = contexts.jira.topK || 35;
          jiraTopKSlider.value = topK;
          if (jiraTopKValue) jiraTopKValue.textContent = topK;
        }
      }

      if (contexts.confluence) {
        if (confluenceTempSlider) {
          const temp = contexts.confluence.temperature || 0.4;
          confluenceTempSlider.value = Math.round(temp * 100);
          if (confluenceTempValue) confluenceTempValue.textContent = temp.toFixed(2);
        }

        if (confluenceTopPSlider) {
          const topP = contexts.confluence.topP || 0.9;
          confluenceTopPSlider.value = Math.round(topP * 100);
          if (confluenceTopPValue) confluenceTopPValue.textContent = topP.toFixed(2);
        }

        if (confluenceTopKSlider) {
          const topK = contexts.confluence.topK || 50;
          confluenceTopKSlider.value = topK;
          if (confluenceTopKValue) confluenceTopKValue.textContent = topK;
        }
      }
    } else {
      initializeDefaultContextSettings(sliderGroups);
    }
  } else {
    if (advancedAiSettings) {
      advancedAiSettings.style.display = 'block';
    }
    initializeDefaultContextSettings(sliderGroups);
  }

  if (sidebarWidthSlider && sidebarWidthValue) {
    const width = data.sidebarWidth || 500;
    sidebarWidthSlider.value = width;
    sidebarWidthValue.textContent = width + 'px';
  }

  if (buttonLabelInput) {
    buttonLabelInput.value = data.buttonLabel || 'PandAid';
  }

  if (sidebarLabelInput) {
    sidebarLabelInput.value = data.sidebarLabel || 'PandAid Case Assistant';
  }
}
