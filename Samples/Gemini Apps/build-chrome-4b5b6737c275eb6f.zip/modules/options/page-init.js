// modules/options/page-init.js

import { createLogger } from '../utils/logger.js';

const logger = createLogger('PageInit');
//
// Encapsulates options page UI wiring so the main script can stay focused on
// data flow and storage logic.

export function initializeOptionsPage({
  elements,
  handlers,
  validators
}) {
  const {
    contextTabs = [],
    sliderGroups,
    atlassianBaseUrlInput,
    testAtlassianButton,
    saveButtons = [],
    atlassianTokenInput,
    jiraPreloadToggle,
    confluencePreloadToggle,
    verboseLoggingToggle,
    tabContainer,
    tabButtons = [],
    tabContents = [],
    activeModelRadios = [],
    modelOptions = []
  } = elements || {};

  const {
    switchContext,
    setupAllSliders,
    loadOptions,
    manageDependencies,
    showStatus,
    showDependencyWarning: _showDependencyWarning,
    hideDependencyWarning,
    displayCurrentDataStatus
  } = handlers || {};

  const {
    normalizeAndValidateAtlassianBaseUrl,
    showAtlassianUrlError,
    hideAtlassianUrlInputError
  } = validators || {};

  const highlightActiveModel = () => {
    modelOptions.forEach(option => {
      option.style.borderColor = '#e0e0e0';
    });

    const activeRadio = activeModelRadios.find(radio => radio && radio.checked && radio.closest('.model-option'));
    if (activeRadio) {
      const container = activeRadio.closest('.model-option');
      container.style.borderColor = '#4a90e2';
    }
  };

  const wireModelRadios = () => {
    activeModelRadios.forEach(radio => {
      if (radio) {
        radio.addEventListener('change', highlightActiveModel);
      }
    });
    highlightActiveModel();
  };

  const injectSharedStyles = () => {
    const style = document.createElement('style');
    style.textContent = `
      .context-disabled .form-group input[type="range"],
      .context-disabled .form-group button {
        opacity: 0.7;
      }
      
      .context-disabled h4,
      .context-disabled p,
      .context-disabled .help-text {
        opacity: 0.8;
      }
      
      .context-warning {
        animation: fadeIn 0.3s ease;
      }
      
      .dependency-indicator {
        position: relative;
        top: -1px;
      }
      
      .dependency-warning {
        color: #1a1b1b;
        font-size: 12px;
        margin-top: 8px;
        padding: 8px 12px;
        background-color: #f5f5f5;
        border-left: 3px solid #1a1b1b;
        border-radius: 0 4px 4px 0;
        animation: fadeIn 0.3s ease;
        line-height: 1.4;
      }
      
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-3px); }
        to { opacity: 1; transform: translateY(0); }
      }
    `;
    document.head.appendChild(style);
  };

  const wireContextTabs = () => {
    contextTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const contextId = tab.id.replace('tab-', '');
        if (switchContext) {
          switchContext(contextId);
        }
      });
    });
  };

  const wireSliders = () => {
    if (setupAllSliders && sliderGroups) {
      setupAllSliders(sliderGroups);
    }
  };

  const applyDefaultContext = () => {
    if (switchContext) {
      switchContext('case-summary');
    }
  };

  const wireAtlassianValidation = () => {
    if (!atlassianBaseUrlInput || !normalizeAndValidateAtlassianBaseUrl) return;

    const validateAndToggle = () => {
      const raw = atlassianBaseUrlInput.value.trim();
      if (!raw) {
        hideAtlassianUrlInputError?.();
        if (testAtlassianButton) testAtlassianButton.disabled = !atlassianTokenInput?.value.trim();
        saveButtons.forEach(btn => btn.disabled = false);
        return;
      }

      const ok = normalizeAndValidateAtlassianBaseUrl(raw);
      if (!ok) {
        showAtlassianUrlError?.('Enter your company slug (e.g., your-company) or the full Atlassian URL (https://your-company.atlassian.net).');
        if (testAtlassianButton) testAtlassianButton.disabled = true;
        saveButtons.forEach(btn => btn.disabled = true);
      } else {
        hideAtlassianUrlInputError?.();
        if (testAtlassianButton) testAtlassianButton.disabled = !atlassianTokenInput?.value.trim();
        saveButtons.forEach(btn => btn.disabled = false);
      }
    };

    atlassianBaseUrlInput.addEventListener('input', validateAndToggle);
    setTimeout(validateAndToggle, 0);
  };

  const wirePreloadGuards = () => {
    if (jiraPreloadToggle) {
      jiraPreloadToggle.addEventListener('change', () => {
        if (jiraPreloadToggle.checked && atlassianTokenInput && !atlassianTokenInput.value.trim()) {
          showStatus?.('JIRA API token is required for JIRA preload functionality', 'error');
          jiraPreloadToggle.checked = false;
        }
      });
    }

    if (confluencePreloadToggle) {
      confluencePreloadToggle.addEventListener('change', () => {
        const missingToken = !atlassianTokenInput?.value.trim();
        if (confluencePreloadToggle.checked && missingToken) {
          showStatus?.('JIRA API token is required for Confluence preload functionality', 'error');
          confluencePreloadToggle.checked = false;
        }
        hideDependencyWarning?.('confluence-preload-toggle');
      });
    }
  };

  const wireVerboseLogging = () => {
    if (!verboseLoggingToggle) return;
    verboseLoggingToggle.addEventListener('change', () => {
      const message = verboseLoggingToggle.checked
        ? 'Verbose logging enabled (will be persisted on Save).'
        : 'Verbose logging disabled (will be persisted on Save).';
      showStatus?.(message, 'info');
    });
  };

  const wireTabs = () => {
    if (!tabContainer) return;
    tabContainer.addEventListener('click', (e) => {
      const clicked = e.target.closest('.tab-button');
      if (!clicked) return;

      tabButtons.forEach(tab => tab.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));

      clicked.classList.add('active');
      const tabId = clicked.dataset.tab;
      const activeContent = document.getElementById(tabId);
      if (activeContent) {
        activeContent.classList.add('active');
      }
    });
  };

  const init = () => {
    wireModelRadios();
    injectSharedStyles();
    wireContextTabs();
    wireSliders();
    applyDefaultContext();
    wireAtlassianValidation();
    wirePreloadGuards();
    wireVerboseLogging();
    wireTabs();

    if (loadOptions) {
      loadOptions().then(() => {
        manageDependencies?.();
        // Display knowledge base data status after options are loaded
        if (displayCurrentDataStatus) {
          displayCurrentDataStatus();
        }
      }).catch(error => {
        logger.error('Error loading options:', 'page-init', error);
        // Show error to user in options page
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = 'position: fixed; top: 20px; left: 50%; transform: translateX(-50%); background: #f44336; color: white; padding: 15px 25px; border-radius: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); z-index: 10000;';
        errorDiv.textContent = 'Failed to load options. Please refresh the page.';
        document.body.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
      });
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
}
