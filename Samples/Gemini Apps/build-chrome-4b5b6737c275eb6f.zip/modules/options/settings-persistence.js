// Persistence helpers for the options page.

import { encrypt } from '../security/crypto-utils.js';
import { createLogger } from '../utils/logger.js';
import { applyLoadedSettings, buildSettingsToSave } from './settings-persistence-helpers.js';
import { TOKEN_PLACEHOLDER } from '../config/constants.js';

const logger = createLogger('SettingsPersistence');

export function createSettingsPersistence({
  elements,
  helpers,
  validation,
  permissions,
  aiHelpers
}) {
  const {
    apiEndpointInput,
    aiServiceTokenInput,
    aiGlobalEnable,
    atlassianTokenInput,
    atlassianBaseUrlInput,
    atlassianEmailInput,
    jiraProjectKeyInput,
    knowledgeBaseEntryLabelInput: _knowledgeBaseEntryLabelInput,
    knowledgeBaseSidebarLabelInput: _knowledgeBaseSidebarLabelInput,
    showJiraExplanationsToggle,
    showConfluenceExplanationsToggle,
    showCommunityExplanationsToggle: _showCommunityExplanationsToggle,
    aiJiraToggle,
    aiConfluenceToggle,
    aiCommunityToggle,
    atlassianAiFilterToggle: _atlassianAiFilterToggle,
    communityAiFilterToggle,
    jiraPreloadToggle,
    confluencePreloadToggle,
    communityPreloadToggle,
    atlassianAiScoreSettings,
    jiraMinScoreSlider: _jiraMinScoreSlider,
    communityMinScoreSlider: _communityMinScoreSlider,
    confluenceMinScoreSlider: _confluenceMinScoreSlider,
    jiraScoreValue: _jiraScoreValue,
    communityScoreValue: _communityScoreValue,
    confluenceScoreValue: _confluenceScoreValue,
    sidebarJiraToggle,
    sidebarConfluenceToggle,
    sidebarCommunityToggle,
    aiModel1Input: _aiModel1Input,
    aiModel2Input: _aiModel2Input,
    aiModel3Input: _aiModel3Input,
    activeModel1Radio: _activeModel1Radio,
    activeModel2Radio: _activeModel2Radio,
    activeModel3Radio: _activeModel3Radio,
    summaryTempSlider: _summaryTempSlider,
    summaryTopPSlider: _summaryTopPSlider,
    summaryTopKSlider: _summaryTopKSlider,
    summaryTempValue: _summaryTempValue,
    summaryTopPValue: _summaryTopPValue,
    summaryTopKValue: _summaryTopKValue,
    communityTempSlider: _communityTempSlider,
    communityTopPSlider: _communityTopPSlider,
    communityTopKSlider: _communityTopKSlider,
    communityTempValue: _communityTempValue,
    communityTopPValue: _communityTopPValue,
    communityTopKValue: _communityTopKValue,
    jiraTempSlider: _jiraTempSlider,
    jiraTopPSlider: _jiraTopPSlider,
    jiraTopKSlider: _jiraTopKSlider,
    jiraTempValue: _jiraTempValue,
    jiraTopPValue: _jiraTopPValue,
    jiraTopKValue: _jiraTopKValue,
    confluenceTempSlider: _confluenceTempSlider,
    confluenceTopPSlider: _confluenceTopPSlider,
    confluenceTopKSlider: _confluenceTopKSlider,
    confluenceTempValue: _confluenceTempValue,
    confluenceTopPValue: _confluenceTopPValue,
    confluenceTopKValue: _confluenceTopKValue,
    statusElement: _statusElement,
    testAiResultElement,
    aiTestSection: _aiTestSection,
    localSearchUrlInput,
    localSearchEnableToggle,
    checkLocalServerButton: _checkLocalServerButton,
    localServerStatusElement,
    verboseLoggingToggle: _verboseLoggingToggle,
    searchModeAiVector,
    searchModeKeyword,
    searchModeKeywordVector,
    sidebarWidthSlider: _sidebarWidthSlider,
    sidebarWidthValue: _sidebarWidthValue,
    toggleAiTokenButton,
    toggleAtlassianTokenButton,
    disableTokenEncryptionToggle,
    communityAiScoreSettings,
    aiFilterToggle,
    advancedAiToggle,
    buttonLabelInput: _buttonLabelInput,
    sidebarLabelInput: _sidebarLabelInput
  } = elements;

  const {
    showStatus,
    showAtlassianUrlInputError,
    hideAtlassianUrlInputError,
    setAiMasterAvailability,
    updateToggleVisibility,
    updateToggleIcon,
    advancedAiSettings,
    applyKnowledgeBaseLabels
  } = helpers;

  const {
    validateApiToken,
    validateAtlassianUrl,
    validateLocalServerUrl,
    validateJiraProjectKey
  } = validation;

  const {
    buildOriginFromUrl,
    requestHostPermission,
    removeHostPermission
  } = permissions;

  const {
    initializeDefaultContextSettings,
    sliderGroups: _sliderGroups
  } = aiHelpers;

  async function saveOptions() {
    const apiEndpoint = apiEndpointInput.value.trim();
    const aiEnabled = !!aiGlobalEnable && aiGlobalEnable.checked;
    const atlassianBaseUrlRaw = atlassianBaseUrlInput.value.trim();
    const atlassianEmail = atlassianEmailInput.value.trim();
    const jiraProjectKeyRaw = jiraProjectKeyInput.value.trim();

    // Handle tokens - only use new value if user modified it (not a placeholder)
    const aiTokenIsSaved = aiServiceTokenInput.getAttribute('data-is-saved') === 'true';
    const atlassianTokenIsSaved = atlassianTokenInput.getAttribute('data-is-saved') === 'true';

    // Get raw input values
    const aiServiceTokenRaw = aiServiceTokenInput.value.trim();
    const atlassianTokenRaw = atlassianTokenInput.value.trim();

    // If token is saved and user hasn't changed it (placeholder shown), use null to skip update
    // If token is new or modified, use the new value
    const aiServiceToken = aiTokenIsSaved && aiServiceTokenRaw === TOKEN_PLACEHOLDER ? null : aiServiceTokenRaw;
    const atlassianToken = atlassianTokenIsSaved && atlassianTokenRaw === TOKEN_PLACEHOLDER ? null : atlassianTokenRaw;
    const hasAiToken = aiServiceToken !== null ? Boolean(aiServiceToken) : aiTokenIsSaved;
    const hasAtlassianToken = atlassianToken !== null ? Boolean(atlassianToken) : atlassianTokenIsSaved;
    const disableTokenEncryption = disableTokenEncryptionToggle?.checked === true;

    // Check if any AI-dependent features are enabled
    const aiDependentFeaturesEnabled =
      aiJiraToggle.checked ||
      aiConfluenceToggle.checked ||
      aiCommunityToggle.checked ||
      (searchModeAiVector && searchModeAiVector.checked);

    // If AI-dependent features are enabled but AI is not fully configured, disable them and warn user
    if (aiDependentFeaturesEnabled && (!aiEnabled || !apiEndpoint || !hasAiToken)) {
      // Auto-disable AI features if credentials are missing
      if (aiJiraToggle.checked) aiJiraToggle.checked = false;
      if (aiConfluenceToggle.checked) aiConfluenceToggle.checked = false;
      if (aiCommunityToggle.checked) aiCommunityToggle.checked = false;
      if (searchModeAiVector && searchModeAiVector.checked) {
        if (searchModeKeyword) searchModeKeyword.checked = true;
      }

      showStatus('AI-enhanced features were disabled because AI is not fully configured. Your other settings were saved.', 'info');
    }

    if (aiEnabled && apiEndpoint) {
      try {
        const url = new URL(apiEndpoint);
        if (!url.protocol.startsWith('http')) {
          showStatus('API Endpoint must use HTTP or HTTPS protocol', 'error');
          return;
        }
      } catch (error) {
        logger.debug('API Endpoint validation error:', 'settings-persistence', error);
        showStatus('API Endpoint must be a valid URL (e.g., https://api.example.com/graphql)', 'error');
        return;
      }
    }

    const result = await chrome.storage.local.get('apiEndpoint');
    const oldApiEndpoint = result?.apiEndpoint;
    if (oldApiEndpoint && (oldApiEndpoint !== apiEndpoint || !aiEnabled)) {
      const oldOrigin = buildOriginFromUrl(oldApiEndpoint);
      if (oldOrigin) {
        try {
          await removeHostPermission(oldOrigin);
          logger.info(`Removed permission for old API endpoint: ${oldOrigin}`, 'settings-persistence', undefined);
        } catch (error) {
          logger.warn('Failed to remove old API endpoint permission:', 'settings-persistence', error);
        }
      }
    }

    // Request permission for AI endpoint when it is configured and token is present
    if (aiEnabled && apiEndpoint && hasAiToken) {
      const origin = buildOriginFromUrl(apiEndpoint);
      if (!origin) {
        showStatus('Configured AI endpoint is invalid. Please correct it before saving.', 'error');
        return;
      }
      try {
        const granted = await requestHostPermission(origin);
        if (!granted) {
          showStatus(`Permission to access ${origin} was denied. AI features will not work without this permission.`, 'error');
          return;
        }
      } catch (error) {
        logger.error('Error requesting AI endpoint permission:', 'settings-persistence', error);
        showStatus('Failed to request permission for AI endpoint. Please try again.', 'error');
        return;
      }
    }

    // Only validate AI token format if one is provided
    if (aiEnabled && aiServiceToken) {
      const tokenValidation = validateApiToken(aiServiceToken);
      if (!tokenValidation.valid) {
        showStatus(tokenValidation.error, 'error');
        return;
      }
    }

    // Require a valid Atlassian URL when any Atlassian credentials or toggles are enabled
    const atlassianFeaturesEnabled =
      hasAtlassianToken ||
      atlassianEmail ||
      aiJiraToggle.checked || aiConfluenceToggle.checked ||
      jiraPreloadToggle.checked || confluencePreloadToggle.checked ||
      showJiraExplanationsToggle.checked || showConfluenceExplanationsToggle.checked;

    let atlassianBaseUrl = null;
    if (atlassianFeaturesEnabled && !atlassianBaseUrlRaw) {
      const error = 'Please enter your company slug (e.g., your-company) or full Atlassian URL (https://your-company.atlassian.net).';
      showStatus(error, 'error');
      showAtlassianUrlInputError(atlassianBaseUrlInput, error);
      return;
    }

    if (atlassianBaseUrlRaw) {
      const urlValidation = validateAtlassianUrl(atlassianBaseUrlRaw);
      if (!urlValidation.valid) {
        showStatus(urlValidation.error, 'error');
        showAtlassianUrlInputError(atlassianBaseUrlInput, urlValidation.error);
        return;
      }
      atlassianBaseUrl = urlValidation.normalized;
      hideAtlassianUrlInputError();
    }

    let jiraProjectKey = null;
    if (jiraProjectKeyRaw) {
      const keyValidation = validateJiraProjectKey(jiraProjectKeyRaw);
      if (!keyValidation.valid) {
        showStatus(keyValidation.error, 'error');
        return;
      }
      jiraProjectKey = keyValidation.normalized;
    }

    if (!hasAtlassianToken) {
      const atlassianFeaturesEnabled =
        aiJiraToggle.checked || aiConfluenceToggle.checked ||
        jiraPreloadToggle.checked || confluencePreloadToggle.checked ||
        showJiraExplanationsToggle.checked || showConfluenceExplanationsToggle.checked;

      if (atlassianFeaturesEnabled) {
        aiJiraToggle.checked = false;
        aiConfluenceToggle.checked = false;
        jiraPreloadToggle.checked = false;
        confluencePreloadToggle.checked = false;
        showJiraExplanationsToggle.checked = false;
        showConfluenceExplanationsToggle.checked = false;
        showStatus('No JIRA API token detected. Atlassian AI and preload options were disabled and the rest of your settings were saved.', 'info');
      }
    }

    if (localSearchEnableToggle && localSearchEnableToggle.checked && localSearchUrlInput && localSearchUrlInput.value.trim()) {
      const localUrlValidation = validateLocalServerUrl(localSearchUrlInput.value.trim());
      if (!localUrlValidation.valid) {
        showStatus(localUrlValidation.error, 'error');
        return;
      }
    }

    try {
      // Request permission for local search server if enabled and configured
      const isLocalSearchEnabled = localSearchEnableToggle?.checked === true;
      const localSearchUrl = localSearchUrlInput?.value.trim();
      const hasLocalSearchUrl = Boolean(localSearchUrl);

      if (isLocalSearchEnabled && hasLocalSearchUrl) {
        const origin = buildOriginFromUrl(localSearchUrl);
        if (origin) {
          const granted = await requestHostPermission(origin);
          if (!granted) {
            showStatus('Permission to access the configured Local Search Server was denied. Local search will remain disabled.', 'error');
            if (localSearchEnableToggle) localSearchEnableToggle.checked = false;
          }
        }
      }

      // Build the settings object - only include tokens if they were changed
      const settingsToSave = buildSettingsToSave({
        elements,
        values: {
          apiEndpoint,
          aiEnabled,
          atlassianBaseUrl,
          atlassianEmail,
          jiraProjectKey,
          disableTokenEncryption
        }
      });

      // Only update tokens if user provided new values (not placeholder)
      if (aiServiceToken !== null) {
        if (disableTokenEncryption) {
          settingsToSave.aiServiceToken = aiServiceToken;
        } else {
          const encResult = await encrypt(aiServiceToken);
          if (!encResult.ok) throw encResult.error;
          settingsToSave.aiServiceToken = encResult.value;
        }
      }
      if (atlassianToken !== null) {
        if (disableTokenEncryption) {
          settingsToSave.atlassianToken = atlassianToken;
        } else {
          const encResult = await encrypt(atlassianToken);
          if (!encResult.ok) throw encResult.error;
          settingsToSave.atlassianToken = encResult.value;
        }
      }

      await chrome.storage.local.set(settingsToSave);

      try {
        const mode = searchModeAiVector && searchModeAiVector.checked ? 'generative' : (searchModeKeyword && searchModeKeyword.checked ? 'keyword' : (searchModeKeywordVector && searchModeKeywordVector.checked ? 'vector' : 'keyword'));
        const current = await chrome.storage.local.get({ searchSettings: { mode: 'keyword' } });
        const newSettings = { ...(current.searchSettings || {}), mode };
        await chrome.storage.local.set({ searchSettings: newSettings });
      } catch (err) {
        logger.warn('Failed to persist searchSettings.mode:', 'settings-persistence', err);
      }

      showStatus('All settings saved successfully!', 'success');
      if (testAiResultElement) testAiResultElement.style.display = 'none';
      if (localServerStatusElement) localServerStatusElement.style.display = 'none';
    } catch (error) {
      logger.error('Error saving options:', 'settings-persistence', error);
      showStatus('Failed to save settings. Please try again.', 'error');
    }
  }

  function loadOptions() {
    return new Promise((resolve) => {
      chrome.storage.local.get([
        'apiEndpoint',
        'aiServiceToken',
        'aiEnabled',
        'atlassianToken',
        'atlassianBaseUrl',
        'atlassianEmail',
        'jiraProjectKey',
        'preloadSettings',
        'aiEnhancementSettings',
        'advancedAiSettings',
        'localSearchServerUrl',
        'localSearchEnabled',
        'sidebarWidth',
        'sidebarSections',
        'knowledgeBaseLabels',
        'buttonLabel',
        'sidebarLabel',
        'disableTokenEncryption'
      ], (data) => {
        try {
          applyLoadedSettings({
            data,
            elements,
            helpers: {
              updateToggleVisibility,
              updateToggleIcon,
              setAiMasterAvailability,
              applyKnowledgeBaseLabels,
              initializeDefaultContextSettings
            },
            aiHelpers,
            logger
          });

          resolve();
        } catch (error) {
          logger.error('Error loading options:', 'settings-persistence', error);

          // Provide user feedback about the error
          let userMessage = 'Failed to load some settings. Default values have been applied.';
          if (error.code === 'SESSION_KEY_MISMATCH') {
            userMessage = 'Unable to decrypt saved tokens. Please re-enter your API credentials.';
          } else if (error.message) {
            userMessage = `Error loading settings: ${error.message}. Default values have been applied.`;
          }
          showStatus(userMessage, 'error');

          // Apply safe defaults
          if (jiraPreloadToggle) jiraPreloadToggle.checked = true;
          if (communityPreloadToggle) communityPreloadToggle.checked = true;
          if (aiFilterToggle) aiFilterToggle.checked = false;
          if (communityAiFilterToggle) communityAiFilterToggle.checked = false;
          if (advancedAiToggle) advancedAiToggle.checked = false;
          if (sidebarJiraToggle) sidebarJiraToggle.checked = true;
          if (sidebarConfluenceToggle) sidebarConfluenceToggle.checked = true;
          if (sidebarCommunityToggle) sidebarCommunityToggle.checked = true;

          if (atlassianAiScoreSettings) atlassianAiScoreSettings.style.display = 'none';
          if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
          if (advancedAiSettings) advancedAiSettings.style.display = 'none';

          updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
          updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
          updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
          updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);

          resolve();
        }
      });
    });
  }

  return {
    saveOptions,
    loadOptions
  };
}
