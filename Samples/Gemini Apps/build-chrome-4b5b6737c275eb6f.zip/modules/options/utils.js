import { createLogger } from '../utils/logger.js';

const logger = createLogger('OptionsUtils');

import { validateAtlassianUrl } from '../../security-utils.js';

// Utility helpers used by the options page
export function buildOriginFromUrl(url) {
  try {
    // Allow users to enter scheme-less hosts like "127.0.0.1:5002" or "localhost:5002"
    let candidate = (url || '').trim();
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(candidate)) {
      candidate = 'http://' + candidate;
    }
    const parsed = new URL(candidate);
    const origin = `${parsed.protocol}//${parsed.hostname}${parsed.port ? `:${parsed.port}` : ''}/`;
    return origin;
  } catch (e) {
    logger.debug('Failed to build origin from URL:', 'options/utils', { url, error: e });
    return undefined;
  }
}

/**
 * Normalize and validate Atlassian base URL.
 * Delegates to the centralized security-utils.js validation function.
 * @param {string} input - Raw user input (slug or full URL)
 * @returns {string|null} - Normalized URL if valid, null otherwise
 */
export function normalizeAndValidateAtlassianBaseUrl(input) {
  if (!input) return null;

  const result = validateAtlassianUrl(input);
  return result.valid ? result.normalized : null;
}
