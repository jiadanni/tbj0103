/**
 * result.js
 *
 * Standardized Result pattern for operation outcomes.
 * Replaces the inconsistent mix of nulls, throws, and {success:false} objects.
 */

export class Result {
    constructor(ok, value, error) {
        this.ok = ok;
        this.value = value;
        this.error = error;
    }

    /**
     * Create a successful result
     * @param {any} value - The success return value
     * @returns {Result}
     */
    static success(value) {
        return new Result(true, value, null);
    }

    /**
     * Create a failure result
     * @param {Error|string} error - The error object or message
     * @returns {Result}
     */
    static failure(error) {
        const errObj = error instanceof Error ? error : new Error(String(error));
        return new Result(false, null, errObj);
    }

    /**
     * Unwrap the value or throw the error
     * @returns {any} The value if success
     * @throws {Error} The error if failure
     */
    unwrap() {
        if (this.ok) {
            return this.value;
        }
        throw this.error;
    }
}
