import { createLogger } from '../utils/logger.js';

const logger = createLogger('CommunityGuides');

export function createCommunityGuidesHandlers({
  elements
}) {
  const {
    communityGuidesUploadInput: _communityGuidesUploadInput,
    communityGuidesInfo,
    communityGuidesError,
    exportCommunityGuidesButton,
    clearCommunityGuidesButton
  } = elements;

  async function handleCommunityGuidesUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (communityGuidesInfo) communityGuidesInfo.style.display = 'none';
    if (communityGuidesError) communityGuidesError.style.display = 'none';

    try {
      const text = await file.text();
      const guides = JSON.parse(text);

      if (!Array.isArray(guides)) {
        throw new Error('JSON must be an array of guide objects');
      }

      const requiredFields = ['id', 'title', 'url'];
      for (let i = 0; i < guides.length; i++) {
        const guide = guides[i];
        for (const field of requiredFields) {
          if (!guide[field]) {
            throw new Error(`Guide at index ${i} is missing required field: ${field}`);
          }
        }
      }

      await chrome.storage.local.set({ communityGuides: guides });

      if (communityGuidesInfo) {
        communityGuidesInfo.textContent = `Successfully uploaded ${guides.length} knowledge base entries`;
        communityGuidesInfo.style.display = 'block';
      }

      // Update button states after successful upload
      await displayCurrentDataStatus();
    } catch (error) {
      logger.debug('Community guides upload error', 'community-guides', error);
      if (communityGuidesError) {
        communityGuidesError.textContent = `Error: ${error.message}`;
        communityGuidesError.style.display = 'block';
      }
      logger.error('Failed to upload community guides:', 'community-guides', error);
    }

    event.target.value = '';
  }

  async function displayCurrentDataStatus() {
    try {
      const { communityGuides } = await chrome.storage.local.get('communityGuides');
      const hasGuides = communityGuides && communityGuides.length > 0;

      if (hasGuides) {
        if (communityGuidesInfo) {
          communityGuidesInfo.textContent = `Current data: ${communityGuides.length} knowledge base entries loaded`;
          communityGuidesInfo.style.display = 'block';
        }
      } else {
        if (communityGuidesInfo) {
          communityGuidesInfo.style.display = 'none';
        }
      }

      // Update button states based on whether guides are loaded
      if (exportCommunityGuidesButton) {
        exportCommunityGuidesButton.disabled = !hasGuides;
        if (!hasGuides) {
          exportCommunityGuidesButton.style.opacity = '0.5';
          exportCommunityGuidesButton.style.cursor = 'not-allowed';
        } else {
          exportCommunityGuidesButton.style.opacity = '1';
          exportCommunityGuidesButton.style.cursor = 'pointer';
        }
      }

      if (clearCommunityGuidesButton) {
        clearCommunityGuidesButton.disabled = !hasGuides;
        if (!hasGuides) {
          clearCommunityGuidesButton.style.opacity = '0.5';
          clearCommunityGuidesButton.style.cursor = 'not-allowed';
        } else {
          clearCommunityGuidesButton.style.opacity = '1';
          clearCommunityGuidesButton.style.cursor = 'pointer';
        }
      }

      // Trigger dependency check callback if registered
      if (typeof displayCurrentDataStatus.dependencyCallback === 'function') {
        displayCurrentDataStatus.dependencyCallback();
      }
    } catch (error) {
      logger.error('Failed to check community guides status:', 'community-guides', error);
    }
  }

  async function exportCommunityGuides() {
    try {
      const { communityGuides } = await chrome.storage.local.get('communityGuides');

      if (!communityGuides || communityGuides.length === 0) {
        if (communityGuidesError) {
          communityGuidesError.textContent = 'No knowledge base entries to export. Upload a file first.';
          communityGuidesError.style.display = 'block';
        }
        return;
      }

      const json = JSON.stringify(communityGuides, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = 'community_guides.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      if (communityGuidesInfo) {
        communityGuidesInfo.textContent = `Exported ${communityGuides.length} knowledge base entries`;
        communityGuidesInfo.style.display = 'block';
      }
    } catch (error) {
      logger.debug('Community guides export error', 'community-guides', error);
      if (communityGuidesError) {
        communityGuidesError.textContent = `Export failed: ${error.message}`;
        communityGuidesError.style.display = 'block';
      }
      logger.error('Failed to export community guides:', 'community-guides', error);
    }
  }

  async function clearCommunityGuides() {
    const confirmed = window.confirm('Are you sure you want to clear all knowledge base entries? This action cannot be undone.');
    if (!confirmed) return;

    try {
      await chrome.storage.local.remove('communityGuides');

      if (communityGuidesInfo) {
        communityGuidesInfo.textContent = 'Knowledge base entries cleared successfully';
        communityGuidesInfo.style.display = 'block';
      }
      if (communityGuidesError) communityGuidesError.style.display = 'none';

      // Update button states after clearing
      await displayCurrentDataStatus();
    } catch (error) {
      logger.debug('Community guides clear error', 'community-guides', error);
      if (communityGuidesError) {
        communityGuidesError.textContent = `Clear failed: ${error.message}`;
        communityGuidesError.style.display = 'block';
      }
      logger.error('Failed to clear community guides:', 'community-guides', error);
    }
  }

  return {
    handleCommunityGuidesUpload,
    exportCommunityGuides,
    clearCommunityGuides,
    displayCurrentDataStatus,
    setDependencyCallback: (callback) => {
      // Store callback to trigger after status updates
      displayCurrentDataStatus.dependencyCallback = callback;
    }
  };
}
