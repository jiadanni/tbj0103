/**
 * Atlassian Explanations Module
 * Fallback explanation builders for JIRA and Confluence results
 * 
 * @module api/atlassian/shared/atlassian-explanations
 */

/**
 * Build a simple, contextual explanation for a JIRA ticket when AI is unavailable
 * @param {Object} ticket - JIRA ticket data
 * @param {Object} caseData - Salesforce case data
 * @returns {string} Fallback explanation text
 */
export function buildFallbackJiraExplanation(ticket, caseData = {}) {
  const subject = (caseData.subject || '').trim();
  const component = (caseData.productComponent || '').trim();

  const topic = ticket.summary || 'this issue';
  const links = [];
  
  // Don't mention product family - it's already used as a filter for the project
  if (component) links.push(`the ${component} component`);
  if (subject) links.push(`the case subject "${subject}"`);

  const linkText = links.length ? ` and may be relevant to ${links.join(' and ')}` : '';
  return `Ticket ${ticket.key || ''} about "${topic}"${linkText}.`.trim();
}

/**
 * Add fallback explanations to JIRA tickets that don't have AI explanations
 * @param {Array} tickets - Array of JIRA tickets
 * @param {Object} caseData - Salesforce case data
 * @returns {Array} Tickets with explanations added
 */
export function addFallbackJiraExplanations(tickets, caseData = {}) {
  return (tickets || []).map(ticket => {
    const hasAiExplanation = !!ticket.aiExplanation;
    return {
      ...ticket,
      aiExplanation: ticket.aiExplanation || buildFallbackJiraExplanation(ticket, caseData),
      aiFallback: !hasAiExplanation // Only mark as fallback if AI explanation wasn't provided
    };
  });
}

/**
 * Build a simple, contextual explanation for a Confluence article when AI is unavailable
 * @param {Object} article - Confluence article data
 * @param {Object} caseData - Salesforce case data
 * @returns {string} Fallback explanation text
 */
export function buildFallbackConfluenceExplanation(article, caseData = {}) {
  const subject = (caseData.subject || '').trim();
  const productFamily = (caseData.productFamily || '').trim();
  const component = (caseData.productComponent || '').trim();

  const topic = article.title || 'this article';
  const links = [];
  
  if (productFamily) links.push(`${productFamily}`);
  if (component) links.push(`the ${component} component`);
  if (subject) links.push(`the case subject "${subject}"`);

  const linkText = links.length ? ` and may be relevant to ${links.join(' and ')}` : '';
  return `Article about "${topic}"${linkText}.`.trim();
}

/**
 * Add fallback explanations to Confluence articles that don't have AI explanations
 * @param {Array} articles - Array of Confluence articles
 * @param {Object} caseData - Salesforce case data
 * @returns {Array} Articles with explanations added
 */
export function addFallbackConfluenceExplanations(articles, caseData = {}) {
  return (articles || []).map(article => {
    const hasAiExplanation = !!article.aiExplanation;
    return {
      ...article,
      aiExplanation: article.aiExplanation || buildFallbackConfluenceExplanation(article, caseData),
      aiFallback: !hasAiExplanation // Only mark as fallback if AI explanation wasn't provided
    };
  });
}
