/**
 * JIRA Client Module
 * Handles JIRA API interactions and ticket retrieval.
 * Supports both traditional REST API searching and AI-enhanced searching.
 * 
 * @module api/atlassian/jira/jira-client
 */

import { cleanEmailContent } from '../../../utils/email-helpers.js';
import { makeApiRequest, getActiveAiModel } from '../../ai-service.js';
import { rateLimiters } from '../../../utils/rate-limiter.js';
import { parseJSON } from '../../../utils/json-parser.js';
import { extractSearchTerms } from '../../../utils/text-utils.js';
import { getJiraProjectFromProductFamily } from '../shared/atlassian-config.js';
import { buildFallbackJiraExplanation, addFallbackJiraExplanations } from '../shared/atlassian-explanations.js';
import { buildJQLQuery } from './jira-query-builder.js';
import { decrypt } from '../../../security/crypto-utils.js';
import { createLogger } from '../../../utils/logger.js';


const logger = createLogger('JiraClient');

import { fetchWithTimeout } from '../../../utils/network-utils.js';
import { Result } from '../../../utils/result.js';
import { buildJiraAnalysisPrompt, buildAiAnalysisMutation } from '../../../config/ai-prompts.js';


/**
 * Traditional JIRA ticket search using JIRA REST API.
 * 
 * @param {string} caseId - Salesforce Case ID
 * @param {Object} [caseData={}] - Full case data object for context extraction
 * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
 * @returns {Promise<Result>} Standardized Result object containing an array of JIRA tickets on success
 */
export async function getJiraTicketsTraditional(caseId, caseData = {}, isManualFetch = false) {
  try {
    // First check if we have a JIRA token and base URL
    const { atlassianToken: encryptedToken, atlassianBaseUrl, atlassianEmail, jiraProjectKey, preloadSettings } = await chrome.storage.local.get(['atlassianToken', 'atlassianBaseUrl', 'atlassianEmail', 'jiraProjectKey', 'preloadSettings']);

    // Only check preload settings for automatic preload, not manual fetch
    if (!isManualFetch && preloadSettings?.jira === false) {
      return Result.success([]);
    }

    // If no JIRA token is configured, throw an error
    if (!encryptedToken) {
      return Result.failure(new Error('JIRA token not configured'));
    }

    // Decrypt the token
    const decryptResult = await decrypt(encryptedToken);
    if (!decryptResult.ok) {
      return Result.failure(decryptResult.error);
    }
    const atlassianToken = decryptResult.value;

    // Require Atlassian base URL to be configured
    if (!atlassianBaseUrl) {
      return Result.failure(new Error('Atlassian base URL not configured'));
    }

    // URL should already be normalized in settings, ensure no trailing slash
    const baseUrl = atlassianBaseUrl.replace(/\/$/, '');
    let searchTerms = [];
    let projectKey = null;

    // Use passed case data if available, otherwise try to extract from page
    let result = caseData;

    if (!result || Object.keys(result).length === 0) {
      // Fallback: try to extract from page if no case data passed
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        try {
          const response = await chrome.tabs.sendMessage(tabs[0].id, { action: 'extractCaseData' });
          if (response && response.success) {
            result = response.data || {};
          } else {
            result = {};
          }
        } catch (scriptError) {
          logger.warn('Could not extract case data for JIRA search', 'jiraClient', scriptError);
          // Expected: May fail on non-case pages or during DOM mutations
          result = {};
        }
      }
    }

    if (result) {
      // Process subject into multiple search terms
      if (result.subject) {
        const subjectTerms = extractSearchTerms(result.subject);
        searchTerms.push(...subjectTerms);
      }

      // Add product component as a search term
      if (result.productComponent) {
        const componentTerms = extractSearchTerms(result.productComponent);
        searchTerms.push(...componentTerms);
      }

      // Add product component action as a search term
      if (result.productComponentAction) {
        const actionTerms = extractSearchTerms(result.productComponentAction);
        searchTerms.push(...actionTerms);
      }

      // Extract key terms from description
      if (result.description) {
        const cleanedDescription = cleanEmailContent(result.description);
        if (cleanedDescription) {
          const descriptionTerms = extractSearchTerms(cleanedDescription, 5);
          searchTerms.push(...descriptionTerms);
        }
      }

      // Determine project from product family dynamically
      if (result.productFamily || result.product) {
        const productFamily = result.productFamily || result.product;
        projectKey = await getJiraProjectFromProductFamily(productFamily, jiraProjectKey);
      } else if (jiraProjectKey) {
        projectKey = jiraProjectKey;
      }
    }

    // Fallback search terms
    if (searchTerms.length === 0) {
      searchTerms = ['payment', 'issue', 'problem', 'error'];
    }

    searchTerms = [...new Set(searchTerms)].filter(term =>
      term.length > 2 && !['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'].includes(term.toLowerCase())
    );

    if (!searchTerms.length) {
      logger.info('No search terms available for JIRA search, returning empty results', 'jira-client');
      return Result.success([]);
    }

    const jql = buildJQLQuery(searchTerms, projectKey);
    const apiUrl = `${baseUrl}/rest/api/3/search/jql`;

    const authHeaders = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    if (atlassianEmail && atlassianToken) {
      authHeaders['Authorization'] = `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`;
    } else {
      return Result.failure(new Error('Atlassian email and token are required for Basic Authentication.'));
    }

    const response = await rateLimiters.atlassian.executeWithBackoff(
      async () => {
        return await fetchWithTimeout(apiUrl, {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            jql: jql,
            maxResults: 10,
            fields: ['summary', 'status', 'priority', 'assignee', 'created', 'updated', 'issuetype', 'project', 'description']
          })
        });
      },
      `jira-search-${baseUrl}`
    );

    if (!response.ok) {
      const errorText = await response.text();
      const error = new Error(`JIRA API request failed: ${errorText}`);
      error.status = response.status;
      error.endpoint = apiUrl;
      throw error;
    }

    const data = await response.json();
    const issues = data.issues || [];

    const tickets = issues.map(issue => ({
      id: issue.id,
      key: issue.key,
      summary: issue.fields.summary,
      description: issue.fields.description,
      status: issue.fields.status?.name || 'Unknown',
      priority: issue.fields.priority?.name || 'Unassigned',
      url: `${baseUrl}/browse/${issue.key}`,
      created: issue.fields.created,
      updated: issue.fields.updated,
      assignee: issue.fields.assignee?.displayName || 'Unassigned',
      avatarUrl: issue.fields.assignee?.avatarUrls?.['48x48']
    }));

    return Result.success(tickets);
  } catch (error) {
    logger.error('Error fetching JIRA tickets', 'jiraClient', error);
    return Result.failure(error);
  }
}

/**
 * AI-enhanced JIRA ticket search with relevance scoring.
 * 
 * @param {string} caseId - Salesforce Case ID
 * @param {Object} [caseData={}] - Full case data object for prompt context
 * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
 * @returns {Promise<Result>} Standardized Result object containing an array of AI-ranked JIRA tickets on success
 */
export async function getJiraTicketsWithAI(caseId, caseData = {}, isManualFetch = false) {
  let traditionalResults = [];
  try {
    logger.debug('Starting AI enhancement function...', 'jiraClient');

    // First get traditional results
    const traditionalRes = await getJiraTicketsTraditional(caseId, caseData, isManualFetch);
    if (!traditionalRes.ok) return traditionalRes;

    traditionalResults = traditionalRes.value;

    if (traditionalResults.length === 0) {
      return Result.success([]);
    }

    // Check for API token
    const { aiServiceToken: encryptedAiToken } = await chrome.storage.local.get('aiServiceToken');
    if (!encryptedAiToken) {
      logger.warn('No AI token found. Returning traditional results with fallback explanations.', 'jiraClient');
      return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
    }

    // Get minimum relevance threshold
    const { preloadSettings: preloadSettingsForPrompt } = await chrome.storage.local.get('preloadSettings');
    const minJiraScoreForPrompt = preloadSettingsForPrompt?.jiraMinScore ?? 80;

    // Use AI to analyze and re-rank
    const aiAnalysisPrompt = buildJiraAnalysisPrompt(
      {
        ...caseData,
        description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
      },
      traditionalResults,
      minJiraScoreForPrompt
    );

    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const temperature = advancedAiSettings?.contextSettings?.jira?.temperature ?? 0.25;
    const topP = advancedAiSettings?.contextSettings?.jira?.topP ?? 0.85;
    const topK = advancedAiSettings?.contextSettings?.jira?.topK ?? 35;

    const aiMutation = buildAiAnalysisMutation('AnalyzeJiraRelevance');

    const variables = {
      model: model,
      prompt: aiAnalysisPrompt,
      temperature,
      topP,
      topK
    };

    logger.debug('Making Jira AI re-ranking request...', 'jiraClient');
    const response = await makeApiRequest(aiMutation, variables);
    if (!response.ok) {
      logger.warn('AI analysis failed, falling back to traditional results', 'jiraClient', { error: response.error });
      return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
    }
    const aiResponse = response.value.data.answerPrompt;

    const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

    if (!parseResult.isValid || !parseResult.data) {
      logger.warn('Could not parse AI response, using fallbacks', 'jiraClient', { error: parseResult.error });
      return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
    }

    const aiAnalysis = parseResult.data;

    if (!aiAnalysis.rankedTickets || !Array.isArray(aiAnalysis.rankedTickets)) {
      // Compatibility check
      if (aiAnalysis.rankedArticles && Array.isArray(aiAnalysis.rankedArticles)) {
        aiAnalysis.rankedTickets = aiAnalysis.rankedArticles.map(article => ({
          ticketIndex: article.articleIndex,
          relevanceScore: article.relevanceScore,
          explanation: article.explanation
        }));
      } else {
        return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
      }
    }

    const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
    const minJiraScore = preloadSettings?.jiraMinScore ?? 80;

    const enhancedTickets = aiAnalysis.rankedTickets
      .filter(ranking => {
        const isValidIndex = ranking.ticketIndex >= 0 && ranking.ticketIndex < traditionalResults.length;
        return isValidIndex && ranking.relevanceScore >= minJiraScore;
      })
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, 5)
      .map(ranking => {
        const originalTicket = traditionalResults[ranking.ticketIndex];
        return {
          ...originalTicket,
          aiRelevanceScore: ranking.relevanceScore,
          aiExplanation: ranking.explanation || buildFallbackJiraExplanation(originalTicket, caseData),
          aiFallback: !ranking.explanation
        };
      });

    return Result.success(enhancedTickets);
  } catch (error) {
    logger.error('Error in AI analysis', 'jiraClient', error);

    // Fallback: If AI fails but we have traditional results, return those with fallback explanations
    // instead of failing the entire request.
    try {
      // Re-fetch traditional results if they weren't captured (though they should be in the outer scope)
      // but the safest way is to ensure traditionalResults is available.
      // Since we need traditionalResults, let's make sure it's scoped correctly.
      if (typeof traditionalResults !== 'undefined' && traditionalResults && traditionalResults.length > 0) {
        logger.info('Returning traditional Jira results with fallbacks after AI failure', 'jiraClient');
        return Result.success(addFallbackJiraExplanations(traditionalResults, caseData));
      }
    } catch (fallbackError) {
      logger.error('Failed to provide fallback results', 'jiraClient', fallbackError);
    }

    return Result.failure(error);
  }
}
