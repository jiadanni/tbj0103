/**
 * Confluence Client Module
 * Handles Confluence API interactions and article retrieval.
 * Provides both traditional CQL-based searching and AI-enhanced searching.
 * 
 * @module api/atlassian/confluence/confluence-client
 */

import { cleanEmailContent } from '../../../utils/email-helpers.js';
import { makeApiRequest, getActiveAiModel } from '../../ai-service.js';
import { rateLimiters } from '../../../utils/rate-limiter.js';
import { parseJSON } from '../../../utils/json-parser.js';
import { extractSearchTerms } from '../../../utils/text-utils.js';
import { getConfluenceSpacesFromProductFamily } from '../shared/atlassian-config.js';
import { buildFallbackConfluenceExplanation, addFallbackConfluenceExplanations } from '../shared/atlassian-explanations.js';
import { buildConfluenceCQLQuery } from './confluence-query-builder.js';
import { decrypt } from '../../../security/crypto-utils.js';
import { createLogger } from '../../../utils/logger.js';


const logger = createLogger('ConfluenceClient');

import { fetchWithTimeout } from '../../../utils/network-utils.js';
import { Result } from '../../../utils/result.js';
import { buildConfluenceAnalysisPrompt, buildAiAnalysisMutation } from '../../../config/ai-prompts.js';


/**
 * Traditional Confluence articles search using Confluence REST API.
 * 
 * @param {Object} [caseData={}] - Full case data object for context extraction
 * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
 * @returns {Promise<Result>} Standardized Result object containing an array of Confluence pages on success
 */
export async function getConfluencePagesTraditional(caseData = {}, isManualFetch = false) {
  try {
    // First check if we have a JIRA token and base URL (Confluence uses same credentials)
    const { atlassianToken: encryptedToken, atlassianBaseUrl, atlassianEmail, preloadSettings } = await chrome.storage.local.get(['atlassianToken', 'atlassianBaseUrl', 'atlassianEmail', 'preloadSettings']);

    // Only check preload settings for automatic preload, not manual fetch
    if (!isManualFetch && preloadSettings?.confluence === false) {
      return Result.success([]);
    }

    // If no Atlassian token is configured, return failure
    if (!encryptedToken) {
      return Result.failure(new Error('Atlassian token not configured'));
    }

    // Decrypt the token
    const decryptResult = await decrypt(encryptedToken);
    if (!decryptResult.ok) {
      return Result.failure(decryptResult.error);
    }
    const atlassianToken = decryptResult.value;

    // Require Atlassian base URL to be configured
    if (!atlassianBaseUrl) {
      return Result.failure(new Error('Atlassian base URL not configured'));
    }

    // URL should already be normalized in settings, ensure no trailing slash
    const baseUrl = atlassianBaseUrl.replace(/\/$/, '');
    const result = caseData || {};
    let searchTerms = [];

    if (result) {
      // Process subject into multiple search terms
      if (result.subject) {
        const subjectTerms = extractSearchTerms(result.subject);
        searchTerms.push(...subjectTerms);
      }

      // Add product as a search term
      if (result.product) {
        const productTerms = extractSearchTerms(result.product);
        searchTerms.push(...productTerms);
      }

      // Add product component as a search term
      if (result.productComponent) {
        const componentTerms = extractSearchTerms(result.productComponent);
        searchTerms.push(...componentTerms);
      }

      // Extract key terms from description
      if (result.description) {
        const cleanedDescription = cleanEmailContent(result.description);
        if (cleanedDescription) {
          const descriptionTerms = extractSearchTerms(cleanedDescription, 5);
          searchTerms.push(...descriptionTerms);
        }
      }
    }

    // Fallback search terms
    if (searchTerms.length === 0) {
      searchTerms = ['documentation', 'guide', 'how-to', 'setup'];
    }

    // Remove duplicates and filter out common words
    searchTerms = [...new Set(searchTerms)].filter(term =>
      term.length > 2 && !['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'].includes(term.toLowerCase())
    );

    // Determine target spaces
    let targetSpaces = [];
    if (result.productFamily || result.product) {
      const productFamily = result.productFamily || result.product;
      targetSpaces = await getConfluenceSpacesFromProductFamily(productFamily, result.productComponent);
    }

    // Build queries
    const cqlQuery = buildConfluenceCQLQuery(searchTerms, result, targetSpaces);

    // Harden fallback: Ensure searchTerms[0] is not undefined
    if (!searchTerms.length) {
      logger.info('No search terms available for Confluence search, returning empty results', 'confluence-client');
      return Result.success([]);
    }

    const fallbackTerm = searchTerms[0];
    const fallbackQuery = `type=page AND text ~ "${fallbackTerm}" ORDER BY lastmodified DESC`;

    const searchUrl = `${baseUrl}/wiki/rest/api/search?cql=${encodeURIComponent(cqlQuery)}&limit=10&expand=content.space,content.version`;

    let response;
    const authHeader = `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`;

    if (!atlassianEmail || !atlassianToken) {
      return Result.failure(new Error('Atlassian email and token are required for Basic Authentication.'));
    }

    // Attempt primary search
    try {
      response = await rateLimiters.atlassian.executeWithBackoff(
        async () => {
          return await fetchWithTimeout(searchUrl, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
              'Authorization': authHeader,
              'Content-Type': 'application/json'
            }
          }, 20000);
        },
        `confluence-search-${baseUrl}`
      );
    } catch (fetchError) {
      logger.warn('Confluence primary search fetch failed', 'confluence-client', fetchError);
      // Will attempt fallback below
    }

    // Attempt fallback search if primary failed
    if (!response || !response.ok) {
      logger.warn('Confluence: primary search failing, trying fallback...', 'confluence-client');
      try {
        const fallbackUrl = `${baseUrl}/wiki/rest/api/search?cql=${encodeURIComponent(fallbackQuery)}&limit=5&expand=content.space,content.version`;
        response = await rateLimiters.atlassian.executeWithBackoff(
          async () => {
            return await fetchWithTimeout(fallbackUrl, {
              method: 'GET',
              headers: {
                'Accept': 'application/json',
                'Authorization': authHeader,
                'Content-Type': 'application/json'
              }
            }, 20000);
          },
          `confluence-fallback-${baseUrl}`
        );
      } catch (fallbackError) {
        logger.error('Confluence fallback search failed', 'confluence-client', fallbackError);
      }
    }

    if (!response || !response.ok) {
      const error = new Error(`Confluence API request failed with status: ${response ? response.status : 'unknown'}`);
      if (response) error.status = response.status;
      return Result.failure(error);
    }

    const data = await response.json();
    const confluenceResults = data.results || [];

    const pages = confluenceResults.map(item => {
      const content = item.content || item;
      return {
        id: content.id,
        title: content.title,
        url: baseUrl + '/wiki' + (content._links ? (content._links.webui || content._links.tinyui || '') : ''),
        space: content.space?.name || 'Unknown Space',
        spaceKey: content.space?.key || 'Unknown',
        lastModified: content.version?.when || item.lastModified,
        lastModifiedBy: content.version?.by?.displayName || 'Unknown',
        excerpt: item.excerpt || content.excerpt || '',
        type: content.type || 'page',
        aiRelevanceScore: null,
        aiExplanation: null
      };
    });

    return Result.success(pages);
  } catch (error) {
    logger.error('Error in getConfluencePagesTraditional', 'confluence-client', error);
    return Result.failure(error);
  }
}

/**
 * AI-enhanced Confluence page search with relevance scoring.
 * 
 * @param {Object} [caseData={}] - Full case data object for prompt context
 * @param {boolean} [isManualFetch=false] - Whether this search was manually triggered by the user
 * @returns {Promise<Result>} Standardized Result object containing an array of AI-ranked Confluence pages on success
 */
export async function getConfluencePagesWithAI(caseData = {}, isManualFetch = false) {
  let traditionalResults = [];
  try {
    logger.debug('Starting Confluence AI enhancement...', 'confluence-client');

    const traditionalRes = await getConfluencePagesTraditional(caseData, isManualFetch);
    if (!traditionalRes.ok) return traditionalRes;

    traditionalResults = traditionalRes.value;

    if (traditionalResults.length === 0) {
      return Result.success([]);
    }

    // Check for API token
    const { aiServiceToken: encryptedAiToken } = await chrome.storage.local.get('aiServiceToken');
    if (!encryptedAiToken) {
      logger.warn('No AI token found for Confluence re-ranking', 'confluence-client');
      return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
    }

    const { preloadSettings: preloadSettingsForPrompt } = await chrome.storage.local.get('preloadSettings');
    const minConfluenceScoreForPrompt = preloadSettingsForPrompt?.confluenceMinScore ?? 75;

    // Use AI to re-rank the results
    const aiAnalysisPrompt = buildConfluenceAnalysisPrompt(
      {
        ...caseData,
        description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
      },
      traditionalResults,
      minConfluenceScoreForPrompt
    );

    // Get advanced AI settings
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const temperature = advancedAiSettings?.contextSettings?.confluence?.temperature ?? 0.4;
    const topP = advancedAiSettings?.contextSettings?.confluence?.topP ?? 0.9;
    const topK = advancedAiSettings?.contextSettings?.confluence?.topK ?? 50;

    const aiMutation = buildAiAnalysisMutation('AnalyzeConfluenceRelevance');

    const variables = { model, prompt: aiAnalysisPrompt, temperature, topP, topK };

    logger.debug('Making Confluence AI re-ranking request...', 'confluence-client');
    const response = await makeApiRequest(aiMutation, variables);
    if (!response.ok) {
      logger.warn('AI Confluence analysis failed, falling back to traditional results', 'confluence-client', { error: response.error });
      return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
    }
    const aiResponse = response.value.data.answerPrompt;

    const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

    if (!parseResult.isValid || !parseResult.data) {
      logger.warn('Could not parse Confluence AI response, using fallbacks', 'confluence-client', { error: parseResult.error });
      return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
    }

    const aiAnalysis = parseResult.data;

    if (!aiAnalysis.rankedArticles || !Array.isArray(aiAnalysis.rankedArticles)) {
      return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
    }

    const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
    const minConfluenceScore = preloadSettings?.confluenceMinScore ?? 75;

    const enhancedArticles = aiAnalysis.rankedArticles
      .filter(ranking => {
        const isValidIndex = ranking.articleIndex >= 0 && ranking.articleIndex < traditionalResults.length;
        return isValidIndex && ranking.relevanceScore >= minConfluenceScore;
      })
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, 5)
      .map(ranking => {
        const originalArticle = traditionalResults[ranking.articleIndex];
        return {
          ...originalArticle,
          aiRelevanceScore: ranking.relevanceScore,
          aiExplanation: ranking.explanation || buildFallbackConfluenceExplanation(originalArticle, caseData),
          aiFallback: !ranking.explanation
        };
      });

    return Result.success(enhancedArticles);
  } catch (error) {
    logger.error('Error in AI Confluence analysis', 'confluence-client', error);

    // Fallback: If AI fails but we have traditional results, return those with fallback explanations
    try {
      if (traditionalResults && traditionalResults.length > 0) {
        logger.info('Returning traditional Confluence results with fallbacks after AI failure', 'confluence-client');
        return Result.success(addFallbackConfluenceExplanations(traditionalResults, caseData));
      }
    } catch (fallbackError) {
      logger.error('Failed to provide fallback results for Confluence', 'confluence-client', fallbackError);
    }

    return Result.failure(error);
  }
}
