/**
 * Confluence Query Builder Module
 * Constructs CQL (Confluence Query Language) queries for page searches
 * 
 * @module api/atlassian/confluence/confluence-query-builder
 */

import { extractSearchTerms } from '../../../utils/text-utils.js';
import { cleanEmailContent } from '../../../utils/email-helpers.js';
import { createLogger } from '../../../utils/logger.js';

const logger = createLogger('ConfluenceQueryBuilder');

/**
 * Build Confluence CQL (Confluence Query Language) query
 * @param {string[]} searchTerms - Search terms extracted from case
 * @param {Object} caseData - Salesforce case data
 * @param {string[]} targetSpaces - Confluence space IDs to search in
 * @returns {string} CQL query string
 */
export function buildConfluenceCQLQuery(searchTerms, caseData = {}, targetSpaces = []) {
  const query = [];

  // Build a prioritized term list: description -> subject -> component -> action -> caller-provided
  const prioritizedTerms = [];
  const seen = new Set();
  const addTerms = (terms = []) => {
    terms.forEach(term => {
      const clean = (term || '').trim();
      if (!clean || clean.length < 3) return;
      const key = clean.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      prioritizedTerms.push(clean);
    });
  };

  // Description often contains the specific symptom; allow more terms here
  if (caseData.description) {
    addTerms(extractSearchTerms(cleanEmailContent(caseData.description), 8));
  }
  if (caseData.subject) {
    addTerms(extractSearchTerms(caseData.subject, 6));
  }
  if (caseData.productComponent) {
    addTerms(extractSearchTerms(caseData.productComponent, 4));
  }
  if (caseData.productComponentAction) {
    addTerms(extractSearchTerms(caseData.productComponentAction, 3));
  }
  addTerms(searchTerms || []);

  // Text search across title and content - include up to 6 distinct terms for better recall
  if (prioritizedTerms.length > 0) {
    const textSearch = prioritizedTerms
      .slice(0, 6)
      .map(term => 'text ~ "' + escapeCQLString(term) + '"')
      .join(' OR ');

    if (textSearch) {
      query.push('(' + textSearch + ')');
    }
  }

  // Focus on pages (not comments, attachments, etc.)
  query.push('type = page');

  // Add space filtering if target spaces are specified
  if (targetSpaces && targetSpaces.length > 0) {
    logger.info('Confluence CQL: Adding space filter for spaces:', 'confluence-query-builder', targetSpaces);
    // Use simple space key filtering
    const spaceFilter = targetSpaces
      .map(spaceKey => `space.key = "${escapeCQLString(spaceKey)}"`)
      .join(' OR ');
    query.push('(' + spaceFilter + ')');
    logger.info('Confluence CQL: Space filter:', 'confluence-query-builder', spaceFilter);
  } else {
    logger.info('Confluence CQL: No space filter applied - searching all spaces', 'confluence-query-builder', undefined);
  }

  // Build the final CQL query
  let cql = query.join(' AND ');

  // If no search terms, use a broader query
  if (prioritizedTerms.length === 0) {
    cql = 'type = page';
    if (targetSpaces && targetSpaces.length > 0) {
      const spaceFilter = targetSpaces
        .map(spaceKey => `space.key = "${escapeCQLString(spaceKey)}"`)
        .join(' OR ');
      cql += ' AND (' + spaceFilter + ')';
      logger.info('Confluence CQL: No search terms, using space filter only:', 'confluence-query-builder', spaceFilter);
    }
  }

  // Order by relevance and last modified
  cql += ' ORDER BY lastModified DESC';

  return cql;
}

/**
 * Build a simple CQL query for a specific space
 * @param {string} spaceKey - Confluence space key
 * @param {number} _limit - Maximum number of results (handled by API caller)
 * @returns {string} CQL query string
 */
export function buildSimpleCQLQuery(spaceKey, _limit = 10) {
  let cql = 'type = page';
  if (spaceKey) {
    cql += ` AND space.key = "${escapeCQLString(spaceKey)}"`;
  }
  cql += ' ORDER BY lastModified DESC';
  return cql;
}

/**
 * Escape special characters in CQL query strings.
 * Standard JQL/CQL escaping: double-up backslashes first, then escape double quotes.
 * 
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
export function escapeCQLString(text) {
  if (!text) return '';
  return text
    .replace(/\\/g, '\\\\') // Escape backslashes first
    .replace(/"/g, '\\"');  // Then escape double quotes
}
