/**
 * Community Service Module
 * Handles Knowledge Base (formerly Community Guides) and local vector database search
 */

// Import dependencies
import { cleanEmailContent } from '../utils/email-helpers.js';
import { getActiveAiModel, hasValidAiServiceToken } from './ai-service.js';
import { makeApiRequest } from './ai-client.js';
import { rateLimiters } from '../utils/rate-limiter.js';
import { parseJSON } from '../utils/json-parser.js';
import { getKnowledgeBaseLabels } from '../utils/knowledge-base-labels.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';
import { buildKnowledgeBaseAnalysisPrompt, buildAiAnalysisMutation } from '../config/ai-prompts.js';

const logger = createLogger('CommunityService');

// ============================================================================
// LOCAL VECTOR DATABASE SEARCH
// ============================================================================

/**
 * Search local vector database for semantic search
 */
export async function searchLocalVectorDB(queryText) {
  // Read configured URL from storage (allowing user to override default)
  try {
    const { localSearchServerUrl, localSearchEnabled } = await chrome.storage.local.get(['localSearchServerUrl', 'localSearchEnabled']);

    if (!localSearchEnabled) {
      return Result.failure('Local vector search is disabled in settings');
    }

    if (!localSearchServerUrl || !localSearchServerUrl.trim()) {
      return Result.failure('Local vector search server URL is not configured');
    }

    const baseUrl = localSearchServerUrl.trim().replace(/\/$/, '');
    const searchUrl = `${baseUrl}/search`;

    const response = await rateLimiters.local.execute(async () => {
      return await fetch(searchUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query: queryText })
      });
    });

    if (!response.ok) {
      const txt = await response.text().catch(() => response.statusText);
      throw new Error(`Local search server error: ${response.status} ${txt}`);
    }

    const data = await response.json();
    return Result.success(data.results || []);
  } catch (error) {
    logger.error('Error in searchLocalVectorDB:', 'community-service', error);
    return Result.failure(error);
  }
}

// ============================================================================
// KNOWLEDGE BASE (formerly Community Guides)
// ============================================================================

// Knowledge Base Cache - stores loaded guides/articles
// NOTE: For very large Knowledge Bases (>5MB), consider migrating from in-memory 
// caching to IndexedDB to reduce memory footprint in the browser process.
let COMMUNITY_GUIDES_CACHE = [];
let loadPromise = null;
let isLoading = false;

if (chrome?.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.communityGuides || changes.communityGuidesFilename) {
      COMMUNITY_GUIDES_CACHE = [];
      loadPromise = null;
      isLoading = false;
    }
  });
}

/**
 * Load Knowledge Base articles from configurable JSON file
 */
export async function loadCommunityGuides() {
  if (COMMUNITY_GUIDES_CACHE.length > 0) return Result.success(COMMUNITY_GUIDES_CACHE);
  if (isLoading && loadPromise) return loadPromise;

  isLoading = true;
  loadPromise = (async () => {
    try {
      logger.debug('Starting Knowledge Base load...', 'community-service');
      const start = Date.now();

      // First, try to load from chrome.storage.local (uploaded via options)
      // Use a timeout for storage access just in case
      const storagePromise = chrome.storage.local.get('communityGuides');
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Storage access timeout')), 10000));

      const storageResult = await Promise.race([storagePromise, timeoutPromise]);
      const communityGuides = storageResult ? storageResult.communityGuides : null;

      if (communityGuides && Array.isArray(communityGuides) && communityGuides.length > 0) {
        COMMUNITY_GUIDES_CACHE = communityGuides;
        logger.info(`Loaded ${COMMUNITY_GUIDES_CACHE.length} entries from storage in ${Date.now() - start}ms`, 'community-service');
        return Result.success(COMMUNITY_GUIDES_CACHE);
      }

      // Fall back to packaged file
      const { communityGuidesFilename = 'community_guides.json' } =
        await chrome.storage.local.get({ communityGuidesFilename: 'community_guides.json' });

      logger.debug(`Fetching packaged file: ${communityGuidesFilename}`, 'community-service');
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(chrome.runtime.getURL(communityGuidesFilename), { signal: controller.signal })
        .finally(() => clearTimeout(id));

      if (!response.ok) {
        logger.warn('Knowledge base file not found', 'community-service');
        COMMUNITY_GUIDES_CACHE = [];
        return Result.success([]);
      }

      COMMUNITY_GUIDES_CACHE = await response.json();
      logger.info(`Loaded ${COMMUNITY_GUIDES_CACHE.length} entries from packaged file in ${Date.now() - start}ms`, 'community-service');
      return Result.success(COMMUNITY_GUIDES_CACHE);
    } catch (error) {
      logger.error('Failed to load KB entries:', 'community-service', error);
      return Result.success([]);
    } finally {
      isLoading = false;
      loadPromise = null;
    }
  })();

  return loadPromise;
}

/**
 * Legacy function name for backwards compatibility
 * @deprecated Use loadCommunityGuides() instead
 */
export async function loadImpactCommunityGuides() {
  return loadCommunityGuides();
}

/**
 * Generate a smart excerpt based on search terms
 */
function generateExcerpt(title) {
  if (title.toLowerCase().includes('install')) {
    return 'Step-by-step guide for installing and setting up Impact in your learning management system.';
  } else if (title.toLowerCase().includes('message')) {
    return 'Learn how to create, customize, and manage Impact messages for effective user communication.';
  } else if (title.toLowerCase().includes('campaign')) {
    return 'Guide to creating and managing Impact campaigns to engage users and drive adoption.';
  } else if (title.toLowerCase().includes('report') || title.toLowerCase().includes('analytics')) {
    return 'Access insights and analytics to understand user behavior and tool adoption in Impact.';
  } else if (title.toLowerCase().includes('dashboard')) {
    return 'Navigate and use the Impact Dashboard to manage your instance and content.';
  } else if (title.toLowerCase().includes('permission') || title.toLowerCase().includes('user')) {
    return 'Manage user access, permissions, and team collaboration in Impact.';
  } else if (title.toLowerCase().includes('lti')) {
    return 'Integrate Impact with learning management systems using LTI connections.';
  } else {
    return 'Helpful Impact documentation to guide you through features and troubleshooting.';
  }
}

function buildTraditionalGuideExplanation(guide, caseData = {}) {
  const subject = (caseData.subject || '').trim();
  const product = (caseData.productFamily || caseData.productName || '').trim();
  const component = (caseData.productComponent || '').trim();
  const section = (guide.section || guide.category || '').trim();
  const keywords = (guide.keywords || []).slice(0, 3).filter(Boolean).join(', ');

  const focusParts = [];
  if (section) focusParts.push(`it covers ${section}`);
  if (keywords) focusParts.push(`keywords: ${keywords}`);
  if (!focusParts.length) focusParts.push(`the topic "${guide.title}"`);

  const caseParts = [];
  if (subject) caseParts.push(`case subject "${subject}"`);
  if (product) caseParts.push(`product ${product}`);
  if (component) caseParts.push(`component ${component}`);

  const caseText = caseParts.length ? `links to ${caseParts.join(' and ')}` : 'matches the case details provided';
  return `Guide "${guide.title}" is suggested because ${focusParts.join(' and ')} and ${caseText}.`;
}

function addCommunityAiFallbackDetails(guides, caseData) {
  // Use a sensible default relevance for fallback results rather than manufacturing a linear drop-off.
  // This explicitly marks them as having high traditional relevance but lacking AI confirmation.
  const DEFAULT_FALLBACK_RELEVANCE = 85;

  return guides.map((guide) => ({
    ...guide,
    aiRelevanceScore: DEFAULT_FALLBACK_RELEVANCE,
    aiExplanation: buildTraditionalGuideExplanation(guide, caseData),
    aiFallback: true
  }));
}

import { orchestratedSearch } from '../utils/search-orchestrator.js';

/**
 * Search knowledge base entries with optional AI enhancement
 * 
 * @param {Object} caseData - Case context
 * @param {number} limit - Maximum results to return
 * @param {boolean} isManualFetch - Whether this was user-triggered
 * @param {AbortSignal} [signal] - Optional abort signal for cancellation
 */
export async function searchCommunityGuides(caseData, limit = 10, isManualFetch = false, signal = null) {
  return orchestratedSearch({
    serviceName: 'Knowledge Base',
    settingKey: 'community',
    // Signal is passed by orchestrator to these functions
    aiSearchFn: (sig) => searchCommunityGuidesWithAI(caseData, limit, isManualFetch, sig),
    traditionalSearchFn: (sig) => searchCommunityGuidesTraditional(caseData, limit, isManualFetch, sig),
    fallbackEnhancer: addCommunityAiFallbackDetails,
    caseData,
    isManualFetch,
    signal
  });
}

/**
 * AI-enhanced Knowledge Base search
 */
async function searchCommunityGuidesWithAI(caseData, limit = 10, isManualFetch = false, signal = null) {
  let traditionalResults = [];
  try {
    // First get traditional results
    const traditionalRes = await searchCommunityGuidesTraditional(caseData, limit * 2, isManualFetch);
    if (!traditionalRes.ok) return traditionalRes;

    traditionalResults = traditionalRes.value || [];

    if (traditionalResults.length === 0) {
      logger.debug('No traditional results found to re-rank', 'community-service');
      return Result.success([]);
    }

    // Check for API token
    const hasToken = await hasValidAiServiceToken();
    if (!hasToken) {
      logger.warn('No AI token found for Knowledge Base re-ranking', 'community-service');
      return Result.success(addCommunityAiFallbackDetails(traditionalResults, caseData));
    }

    // Use AI to analyze and re-rank the results
    const { entryLabel } = await getKnowledgeBaseLabels();
    const aiAnalysisPrompt = buildKnowledgeBaseAnalysisPrompt(
      {
        ...caseData,
        description: caseData.description ? cleanEmailContent(caseData.description) : 'N/A'
      },
      traditionalResults,
      entryLabel,
      limit
    );

    // Get advanced AI settings
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const temperature = advancedAiSettings?.contextSettings?.communityGuides?.temperature ?? 0.2;
    const topP = advancedAiSettings?.contextSettings?.communityGuides?.topP ?? 0.7;
    const topK = advancedAiSettings?.contextSettings?.communityGuides?.topK ?? 30;

    const aiMutation = buildAiAnalysisMutation('AnalyzeKnowledgeBaseRelevance');

    const variables = { model, prompt: aiAnalysisPrompt, temperature, topP, topK };

    const response = await makeApiRequest(aiMutation, variables, null, signal);
    if (!response.ok) {
      logger.warn('AI Knowledge Base analysis failed, falling back to traditional results', 'community-service', { error: response.error });
      return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
    }
    const aiResponse = response.value.data.answerPrompt;

    // Parse AI response
    const parseResult = parseJSON(aiResponse, { fallback: null, removeMarkdown: true });

    if (!parseResult.isValid || !parseResult.data) {
      logger.warn('Could not parse AI response, using traditional fallback', 'community-service', { error: parseResult.error });
      return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
    }

    const aiAnalysis = parseResult.data;
    if (aiAnalysis.rankedTickets && !aiAnalysis.rankedArticles) {
      aiAnalysis.rankedArticles = aiAnalysis.rankedTickets;
    }

    if (!aiAnalysis.rankedArticles || !Array.isArray(aiAnalysis.rankedArticles)) {
      return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
    }

    // Get minimum relevance threshold
    const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
    const minCommunityScore = preloadSettings?.communityMinScore ?? 80;

    // Re-rank articles based on AI analysis
    const enhancedArticles = aiAnalysis.rankedArticles
      .filter(ranking => {
        const isValidIndex = ranking.articleIndex >= 0 && ranking.articleIndex < traditionalResults.length;
        return isValidIndex && ranking.relevanceScore >= minCommunityScore;
      })
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit)
      .map(ranking => {
        const originalArticle = traditionalResults[ranking.articleIndex];
        return {
          ...originalArticle,
          aiRelevanceScore: ranking.relevanceScore,
          aiExplanation: ranking.explanation || buildTraditionalGuideExplanation(originalArticle, caseData),
          aiFallback: !ranking.explanation
        };
      });

    return Result.success(enhancedArticles);
  } catch (error) {
    logger.error('Error in AI Knowledge Base analysis:', 'community-service', error);

    // Fallback: If AI fails but we have traditional results, return those with fallback explanations
    try {
      if (traditionalResults && traditionalResults.length > 0) {
        logger.info('Returning traditional Knowledge Base results with fallbacks after AI failure', 'community-service');
        return Result.success(addCommunityAiFallbackDetails(traditionalResults.slice(0, limit), caseData));
      }
    } catch (fallbackError) {
      logger.error('Failed to provide fallback results for Knowledge Base', 'community-service', fallbackError);
    }

    return Result.failure(error);
  }
}

/**
 * Traditional Knowledge Base search
 */
async function searchCommunityGuidesTraditional(caseData, limit = 10, isManualFetch = false) {
  try {
    // Check preload settings
    const { preloadSettings } = await chrome.storage.local.get('preloadSettings');
    const communityPreloadEnabled = preloadSettings
      ? (typeof preloadSettings.community !== 'undefined'
        ? preloadSettings.community !== false
        : preloadSettings.knowledgeBase !== false)
      : true;

    if (!isManualFetch && !communityPreloadEnabled) {
      return Result.success([]);
    }

    const guidesRes = await loadCommunityGuides();
    if (!guidesRes.ok) return guidesRes;

    const guides = guidesRes.value;

    // Optimize search terms extraction for large descriptions
    const subject = (caseData.subject || '').substring(0, 500);
    const description = caseData.description
      ? cleanEmailContent(caseData.description).substring(0, 2000)
      : '';

    const searchTerms = [
      subject,
      description,
      caseData.productName || '',
      caseData.errorMessage || '',
      caseData.category || ''
    ].filter(Boolean).join(' ').toLowerCase();

    const searchWords = searchTerms.split(/\s+/)
      .filter(word => word.length > 3) // Longer words for better precision
      .slice(0, 30); // Even tighter limit

    if (searchWords.length === 0) {
      logger.debug('No search terms found for Knowledge Base search', 'community-service');
    }

    const scoredGuides = guides.map(guide => {
      let relevanceScore = 0;
      const titleLower = (guide.title || '').toLowerCase();
      if (!titleLower) return { ...guide, relevanceScore: 0 };

      searchWords.forEach(word => {
        try {
          if (titleLower.includes(word)) relevanceScore += 10;
          if (guide.keywords && Array.isArray(guide.keywords)) {
            if (guide.keywords.some(k => k && typeof k === 'string' && k.toLowerCase().includes(word))) relevanceScore += 5;
          }
          if (guide.section && typeof guide.section === 'string' && guide.section.toLowerCase().includes(word)) relevanceScore += 3;
          if (guide.category && typeof guide.category === 'string' && guide.category.toLowerCase().includes(word)) relevanceScore += 3;
        } catch (e) {
          // Ignore scoring errors for individual fields to ensure overall ranking continues
          logger.debug('Field scoring error', 'community-service', { error: e.message, word, field: guide.title });
        }
      });

      // Special boosts
      if ((searchTerms.includes('error') || searchTerms.includes('problem')) &&
        guide.keywords?.some(k => ['setup', 'access', 'login'].includes(k.toLowerCase()))) {
        relevanceScore += 7;
      }

      // Tie-breaker
      let hash = 0;
      for (let i = 0; i < guide.title.length; i++) hash += guide.title.charCodeAt(i);
      const tieBreaker = (hash % 200) / 100;

      return {
        ...guide,
        relevanceScore: parseFloat((relevanceScore + tieBreaker).toFixed(2)),
        excerpt: generateExcerpt(guide.title),
        aiRelevanceScore: null,
        aiExplanation: null
      };
    });

    const sortedGuides = scoredGuides
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit);

    return Result.success(sortedGuides);
  } catch (error) {
    logger.error('Error in searchKnowledgeBase:', 'community-service', error);
    return Result.failure(error);
  }
}
