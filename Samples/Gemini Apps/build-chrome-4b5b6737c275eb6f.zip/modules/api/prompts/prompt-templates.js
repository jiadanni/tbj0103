/**
 * Prompt Templates Module
 * Centralized storage for all AI prompt templates
 * 
 * @module prompts/prompt-templates
 */

import { cleanEmailContent } from '../../utils/email-helpers.js';

/**
 * System instructions for troubleshooting guidance
 */
export const GUIDANCE_INSTRUCTIONS = `Follow a structured troubleshooting and investigation approach for Impact customer support tickets. Prioritize configuration checks, visibility and context, data freshness, and permission checks. When possible include commands, checks, or tools such as Canvas plugin checks, Impact dashboard verification, Jarvis lookups, CloudWatch log hints, and database query suggestions. Provide concise, numbered, actionable steps.`;

/**
 * Build a solution suggestion prompt based on case data and context
 * @param {Object} caseData - Case information
 * @param {string} context - Additional context (optional)
 * @returns {string} Formatted prompt
 */
export function buildSolutionPrompt(caseData = {}, context = "") {
  const guidanceSection = `GUIDANCE:\n---\n${GUIDANCE_INSTRUCTIONS}\n---\n\n`;

  if (context && context.trim().length > 0) {
    return `${guidanceSection}Using the CONTEXT below, produce 3-6 concise, numbered troubleshooting steps for a support agent to follow. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.\n\nCONTEXT:\n---\n${context}\n---\n\nCASE DETAILS:\n- Subject: ${caseData.subject || 'Not specified'}\n- Description: ${caseData.description ? cleanEmailContent(caseData.description) : 'Not specified'}`;
  }

  if (caseData.subject || caseData.description) {
    const cleanedDescription = caseData.description ? cleanEmailContent(caseData.description) : '';
    return `${guidanceSection}Based on the CASE DETAILS below, produce 3-6 concise, numbered troubleshooting steps for a support agent to follow. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.\n\nCASE DETAILS:\n- Subject: ${caseData.subject || 'Not specified'}\n- Description: ${cleanedDescription || 'Not specified'}\n- Product: ${caseData.productFamily || 'Not specified'}\n- Component: ${caseData.productComponent || 'Not specified'}`;
  }

  return `${guidanceSection}No case details are available. Produce 4-6 concise, numbered investigative troubleshooting steps an agent should follow to diagnose common issues. Do NOT include any preamble, explanation, or customer-facing language — return only numbered steps (1., 2., 3., ...). Use imperative, agent-facing instructions.`;
}

/**
 * Build an improvement prompt for existing solutions
 * @param {string} currentSolution - The solution to improve
 * @param {Object} caseData - Case information for context
 * @returns {string} Formatted prompt
 */
export function buildImprovementPrompt(currentSolution, caseData = {}) {
  const contextPrefix = (caseData.subject || caseData.productFamily)
    ? `CONTEXT: Improving a support solution for Case "${caseData.subject || 'N/A'}" (Product: ${caseData.productFamily || 'N/A'}, Component: ${caseData.productComponent || 'N/A'}).\n\n`
    : '';

  return contextPrefix +
    'Please improve the following solution by making it more clear, comprehensive, and professional. ' +
    'Add specific steps where needed and ensure it follows customer service best practices:\n\n' +
    'Current Solution:\n' + currentSolution + '\n\n' +
    'Please provide an improved version that is:\n' +
    '1. More detailed and actionable\n' +
    '2. Professional in tone and matches the product terminology\n' +
    '3. Clear and easy to follow\n' +
    '4. Includes any relevant troubleshooting steps';
}

/**
 * Build a spellcheck/grammar check prompt
 * @param {string} text - Text to check
 * @param {Object} caseData - Case information for terminology context
 * @returns {string} Formatted prompt
 */
export function buildSpellCheckPrompt(text, caseData = {}) {
  const contextPrefix = (caseData.productFamily || caseData.productComponent)
    ? `CONTEXT: Checking text for a support case regarding ${caseData.productFamily || ''} ${caseData.productComponent || ''}.\n\n`
    : '';

  return contextPrefix +
    'Please check the following text for spelling and grammar errors and return the corrected version. ' +
    'Only fix actual errors - do not change the meaning, tone, or style of the text. ' +
    'Be careful not to "correct" industry or product-specific terminology related to the context provided.\n\n' +
    'Text to check:\n' + text + '\n\n' +
    'Please respond with only the corrected text, no additional comments or explanations.';
}

/**
 * Prompt templates collection for easy access
 */
export const PROMPTS = {
  SOLUTION_SUGGESTION: buildSolutionPrompt,
  SOLUTION_IMPROVEMENT: buildImprovementPrompt,
  SPELL_CHECK: buildSpellCheckPrompt,
};
