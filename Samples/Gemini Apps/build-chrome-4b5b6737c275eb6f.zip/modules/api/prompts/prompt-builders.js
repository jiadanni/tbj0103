/**
 * Prompt Builders Module
 * Dynamic prompt construction utilities
 * 
 * @module prompts/prompt-builders
 */

/**
 * Default AI parameter settings for different contexts
 */
export const DEFAULT_PARAMETERS = {
  caseSummary: {
    temperature: 0.3,
    topP: 0.8,
    topK: 40
  },
  improvement: {
    temperature: 0.3,
    topP: 0.8,
    topK: 40
  },
  spellcheck: {
    temperature: 0.1,
    topP: 0.95,
    topK: 40
  }
};

/**
 * Get AI parameters from settings or use defaults
 * @param {string} context - Context type (caseSummary, improvement, spellcheck)
 * @param {Object} advancedAiSettings - Advanced AI settings from storage
 * @returns {Object} AI parameters (temperature, topP, topK)
 */
export function getAiParameters(context, advancedAiSettings = {}) {
  const contextSettings = advancedAiSettings?.contextSettings?.[context];
  const defaults = DEFAULT_PARAMETERS[context] || DEFAULT_PARAMETERS.caseSummary;
  
  return {
    temperature: contextSettings?.temperature ?? defaults.temperature,
    topP: contextSettings?.topP ?? defaults.topP,
    topK: contextSettings?.topK ?? defaults.topK
  };
}

/**
 * Build GraphQL mutation for AI prompts
 * @param {string} operationName - Name of the mutation operation
 * @param {boolean} includeAdvancedParams - Whether to include advanced AI parameters
 * @returns {string} GraphQL mutation string
 */
export function buildPromptMutation(operationName, includeAdvancedParams = true) {
  if (includeAdvancedParams) {
    return `mutation ${operationName}($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) {
  answerPrompt(input: {
    model: $model
    prompt: $prompt
    temperature: $temperature
    topP: $topP
    topK: $topK
  })
}`;
  }
  
  return `mutation ${operationName}($model: String!, $prompt: String!) {
  answerPrompt(input: {
    model: $model
    prompt: $prompt
    temperature: 0.1
  })
}`;
}

/**
 * Build variables object for GraphQL mutation
 * @param {string} model - AI model identifier
 * @param {string} prompt - Prompt text
 * @param {Object} parameters - AI parameters (temperature, topP, topK)
 * @param {boolean} includeAdvancedParams - Whether to include advanced parameters
 * @returns {Object} Variables object for GraphQL
 */
export function buildMutationVariables(model, prompt, parameters = {}, includeAdvancedParams = true) {
  const variables = { model, prompt };
  
  if (includeAdvancedParams && parameters) {
    if (parameters.temperature !== undefined) variables.temperature = parameters.temperature;
    if (parameters.topP !== undefined) variables.topP = parameters.topP;
    if (parameters.topK !== undefined) variables.topK = parameters.topK;
  }
  
  return variables;
}
