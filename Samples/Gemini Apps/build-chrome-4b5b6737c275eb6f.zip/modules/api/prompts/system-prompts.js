/**
 * System Prompts Module
 * System-level context and instructions for different AI models
 * 
 * @module prompts/system-prompts
 */

/**
 * Default system context for case analysis
 */
export const CASE_ANALYSIS_SYSTEM_PROMPT = `You are an expert customer support analyst specializing in technical troubleshooting. Your role is to help support agents diagnose and resolve customer issues efficiently.`;

/**
 * Default system context for content improvement
 */
export const CONTENT_IMPROVEMENT_SYSTEM_PROMPT = `You are a professional content editor specializing in customer service communications. Your role is to refine and improve support documentation.`;

/**
 * Default system context for grammar/spellcheck
 */
export const GRAMMAR_CHECK_SYSTEM_PROMPT = `You are a precise grammar and spelling checker. Only fix errors - do not change meaning, tone, or style.`;

/**
 * Get system prompt based on operation type
 * @param {string} operationType - Type of operation (caseSummary, improvement, spellcheck)
 * @returns {string} System prompt
 */
export function getSystemPrompt(operationType) {
  switch (operationType) {
    case 'caseSummary':
    case 'solution':
      return CASE_ANALYSIS_SYSTEM_PROMPT;
    case 'improvement':
      return CONTENT_IMPROVEMENT_SYSTEM_PROMPT;
    case 'spellcheck':
    case 'grammar':
      return GRAMMAR_CHECK_SYSTEM_PROMPT;
    default:
      return CASE_ANALYSIS_SYSTEM_PROMPT;
  }
}
