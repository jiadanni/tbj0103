/**
 * Request Queue Module
 * Implements rate limiting and request queuing for API calls
 *
 * @module request-queue
 */

const MAX_CONCURRENT_REQUESTS = 5;
const activeRequests = new Set();
const requestQueue = [];

// Track abort controllers for active requests to enable cancellation
const activeAbortControllers = new Map();

/**
 * Execute a function with rate limiting and request queuing.
 * Ensures no more than MAX_CONCURRENT_REQUESTS run simultaneously.
 * Queues additional requests and executes them as slots become available.
 * Supports AbortSignal for request cancellation.
 *
 * @param {Function} requestFn - Async function to execute (should return a Promise)
 * @param {string} [requestId=null] - Optional identifier for debugging and logging
 * @param {AbortSignal} [signal=null] - Optional abort signal for cancellation
 * @returns {Promise<any>} Promise resolving to the result of requestFn
 */
export async function queueRequest(requestFn, requestId = null, signal = null) {
  if (signal?.aborted) {
    throw new DOMException('Request aborted before queuing', 'AbortError');
  }

  if (activeRequests.size < MAX_CONCURRENT_REQUESTS) {
    return executeRequest(requestFn, requestId, signal);
  }

  return new Promise((resolve, reject) => {
    const queuedItem = { requestFn, requestId, resolve, reject, signal };
    requestQueue.push(queuedItem);

    if (signal) {
      signal.addEventListener('abort', () => {
        const index = requestQueue.indexOf(queuedItem);
        if (index > -1) {
          requestQueue.splice(index, 1);
          reject(new DOMException('Request aborted while queued', 'AbortError'));
        }
      }, { once: true });
    }
  });
}

/**
 * Get current queue status and metrics.
 * Useful for monitoring and debugging request queue performance.
 *
 * @returns {Object} Queue status information
 */
export function getQueueStatus() {
  return {
    activeRequests: activeRequests.size,
    queuedRequests: requestQueue.length,
    maxConcurrent: MAX_CONCURRENT_REQUESTS
  };
}

/**
 * Clear all queued requests and optionally cancel active ones.
 * Useful for cleanup when navigating away or changing context.
 *
 * @param {boolean} [cancelActive=false] - If true, aborts all active requests
 * @returns {Object} Counts of cleared requests
 */
export function clearQueue(cancelActive = false) {
  const queuedCount = requestQueue.length;
  requestQueue.length = 0;

  let activeCount = 0;
  if (cancelActive) {
    for (const [id, controller] of activeAbortControllers.entries()) {
      controller.abort();
      activeAbortControllers.delete(id);
      activeCount += 1;
    }
  }

  return { queued: queuedCount, active: activeCount };
}

// ============================================================================
// INTERNAL HELPERS
// ============================================================================

/**
 * Execute a request and manage the queue.
 * Handles actual execution, timing, error tracking, and queue processing.
 * Respects AbortSignal for both internal and external cancellation requests.
 *
 * @private
 */
async function executeRequest(requestFn, requestId, signal = null) {
  const tracker = { id: requestId || `req-${Date.now()}-${Math.random().toString(16).slice(2)}`, startTime: Date.now() };
  activeRequests.add(tracker);

  if (signal?.aborted) {
    activeRequests.delete(tracker);
    throw new DOMException('Request aborted before execution', 'AbortError');
  }

  const abortController = new AbortController();
  activeAbortControllers.set(tracker.id, abortController);

  if (signal) {
    signal.addEventListener('abort', () => {
      abortController.abort();
    }, { once: true });
  }

  try {
    return await requestFn(abortController.signal);
  } catch (error) {
    if (abortController.signal.aborted) {
      throw new DOMException('Request aborted during execution', 'AbortError');
    }
    throw error;
  } finally {
    activeRequests.delete(tracker);
    activeAbortControllers.delete(tracker.id);
    processQueue();
  }
}

/**
 * Process the next request in the queue.
 * Called automatically after each request completes to maintain
 * the MAX_CONCURRENT_REQUESTS limit while draining the queue.
 *
 * @private
 */
function processQueue() {
  if (requestQueue.length === 0 || activeRequests.size >= MAX_CONCURRENT_REQUESTS) {
    return;
  }

  const next = requestQueue.shift();
  if (!next) return;

  if (next.signal?.aborted) {
    next.reject(new DOMException('Request was aborted while queued', 'AbortError'));
    processQueue();
    return;
  }

  // Create internal controller and link to external signal FIRST to prevent race
  const internalController = new AbortController();
  const onAbort = () => internalController.abort();

  if (next.signal) {
    next.signal.addEventListener('abort', onAbort, { once: true });
  }

  executeRequest(next.requestFn, next.requestId, internalController.signal)
    .then(result => {
      next.signal?.removeEventListener('abort', onAbort);
      next.resolve(result);
    })
    .catch(error => {
      next.signal?.removeEventListener('abort', onAbort);
      next.reject(error);
    });
}
