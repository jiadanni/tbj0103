/**
 * Context Menu Module
 * Handles right-click context menu for importing email text
 */

// Import dependencies
import { filterImportedEmailText } from '../utils/email-helpers.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('ContextMenu');

// ============================================================================
// DIAGNOSTIC HELPERS
// ============================================================================

/**
 * Small diagnostic helper - logs messages
 */
function _pandaidDiagnostic(msg) {
  try {
    logger.info('PandAid-DIAG:', 'context-menu', msg);
    if (chrome && chrome.notifications) {
      // chrome.notifications.create() removed to prevent unwanted Windows notifications
    }
  } catch (e) {
    logger.info('PandAid-DIAG fallback:', 'context-menu', msg);
  }
}

// ============================================================================
// DEBUG FLAGS
// ============================================================================

// Debug flags controlled by chrome.storage.local.pandaidDebug
// Example to set from DevTools: chrome.storage.local.set({ pandaidDebug: { enabled: true, forceShowContextMenu: true, forceAllowClick: true, verboseOnShown: true } })
// 'enabled' must be explicitly true for any force* flag to take effect. This prevents accidental global exposure.
let pandaidDebug = { enabled: false, forceShowContextMenu: false, forceAllowClick: false, verboseOnShown: false };

(async function loadPandaidDebug() {
  try {
    const data = await chrome.storage.local.get('pandaidDebug');
    if (data && data.pandaidDebug) {
      // Only copy known keys to avoid unexpected properties
      const stored = data.pandaidDebug || {};
      pandaidDebug.enabled = !!stored.enabled;
      pandaidDebug.forceShowContextMenu = !!stored.forceShowContextMenu;
      pandaidDebug.forceAllowClick = !!stored.forceAllowClick;
      pandaidDebug.verboseOnShown = !!stored.verboseOnShown;
      if (pandaidDebug.verboseOnShown) logger.info('PandAid: pandaidDebug loaded', 'context-menu', pandaidDebug);
      // If stored object is missing the enabled key, persist the normalized object so it's visible/editable
      if (typeof stored.enabled !== 'boolean') {
        try { await chrome.storage.local.set({ pandaidDebug }); } catch (e) { logger.debug('Error persisting pandaidDebug settings', 'context-menu', e); }
      }
    } else {
      // No stored flags found - persist defaults so the key is visible to the user in DevTools
      try {
        await chrome.storage.local.set({ pandaidDebug });
        if (pandaidDebug.verboseOnShown) logger.info('PandAid: pandaidDebug default created', 'context-menu', pandaidDebug);
      } catch (setErr) {
        logger.warn('PandAid: failed to persist default pandaidDebug', 'context-menu', setErr?.message || setErr);
      }
    }
  } catch (e) {
    logger.warn('PandAid: failed to load pandaidDebug flags', 'context-menu', e?.message || e);
  }
})();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.pandaidDebug) {
    const nv = changes.pandaidDebug.newValue || {};
    // Normalize incoming values and avoid enabling force flags without explicit enabled:true
    pandaidDebug.enabled = !!nv.enabled;
    pandaidDebug.forceShowContextMenu = !!nv.forceShowContextMenu;
    pandaidDebug.forceAllowClick = !!nv.forceAllowClick;
    pandaidDebug.verboseOnShown = !!nv.verboseOnShown;
    logger.info('PandAid: pandaidDebug updated', 'context-menu', pandaidDebug);
  }
});

// ============================================================================
// CONTEXT MENU SETUP
// ============================================================================

let contextMenuSetup = false;

/**
 * Set up the context menu for importing email text
 */
export function setupContextMenu() {
  // Prevent multiple setups
  if (contextMenuSetup) {
    logger.info('PandAid: Context menu already set up, skipping', 'context-menu', undefined);
    return;
  }

  // Remove existing items and create a single-click menu entry
  if (!chrome.contextMenus) {
    logger.warn('contextMenus API not available in this environment; skipping context menu setup', 'context-menu', undefined);
    return;
  }

  chrome.contextMenus.removeAll(() => {
    if (chrome.runtime.lastError) {
      logger.warn('PandAid: removeAll error', 'context-menu', chrome.runtime.lastError);
    }

    const menuId = 'pandaidAddOrImport';
    const menuOptions = {
      id: menuId,
      title: 'Add to PandAid (for Chatter email)',
      contexts: ['all'] // Use 'all' for maximum compatibility
    };

    // Simple approach: just create the item
    chrome.contextMenus.create(menuOptions, () => {
      if (chrome.runtime.lastError) {
        const msg = chrome.runtime.lastError.message || '';
        if (msg.includes('duplicate id')) {
          logger.info('PandAid: context menu item already exists, continuing', 'context-menu', undefined);
        } else {
          logger.error('PandAid: contextMenus.create error', 'context-menu', chrome.runtime.lastError);
        }
      } else {
        logger.info('PandAid: contextMenus.create succeeded', 'context-menu', undefined);
      }
    });

    // Mark context menu as set up
    contextMenuSetup = true;
  });
}

// ============================================================================
// CONTEXT MENU CLICK HANDLER
// ============================================================================

/**
 * Initialize context menu click listener
 */
export function initializeContextMenuListener() {
  // Handle context menu clicks
  if (chrome.contextMenus && chrome.contextMenus.onClicked && typeof chrome.contextMenus.onClicked.addListener === 'function') {
    chrome.contextMenus.onClicked.addListener(async (info, tab) => {
      if (info.menuItemId !== 'pandaidAddOrImport') return;

      let selectedText = (info.selectionText || '').trim();

      // Allow the context menu click to proceed everywhere per user request (no Chatter gating)

      // Fallback: get selection from any frame
      if (!selectedText) {
        try {
          const [{ result: selections }] = await chrome.scripting.executeScript({
            target: { tabId: tab.id, allFrames: true },
            function: () => {
              const sel = window.getSelection();
              return sel && sel.rangeCount ? sel.toString() : '';
            }
          });
          const firstNonEmpty = (Array.isArray(selections) ? selections : [selections]).find(x => (x.result || x).trim());
          selectedText = firstNonEmpty ? (firstNonEmpty.result || firstNonEmpty).trim() : '';
        } catch (err) { logger.debug('Selection retrieval via executeScript failed', 'context-menu', err); }
      }

      // Ensure content script is present
      try {
        await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
      } catch {
        try {
          await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ['content_script.js'] });
          await new Promise(r => setTimeout(r, 400));
        } catch (injectError) {
          logger.error('Failed to inject content script:', 'context-menu', injectError);
          if (chrome.notifications) {
            // chrome.notifications.create() removed to prevent unwanted Windows notifications
          }
          return;
        }
      }

      if (selectedText) {
        // Add selected text
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'addTextAndEnsureSidebar', text: selectedText });
          if (chrome.notifications) {
            // chrome.notifications.create() removed to prevent unwanted Windows notifications
          }
        } catch (e) {
          logger.error('Failed to add text:', 'context-menu', e);
        }
        return;
      }

      // No selection: try to import the email body via the content script's robust extractor
      try {
        await chrome.tabs.sendMessage(tab.id, { action: 'triggerEmailImport' });
        logger.info('Sent triggerEmailImport message to tab', 'context-menu', undefined);
      } catch (error) {
        logger.error('Error triggering email import:', 'context-menu', error);
      }
    });
  } else {
    logger.warn('contextMenus.onClicked not available; context menu click handling disabled', 'context-menu', undefined);
  }
}
