// modules/content/assistant.js
//
// PandaAidCaseAssistant class plus instance helpers.

import { injectStyles } from './styles.js';
import { createPandAidButton, adjustButtonPosition, updateButtonVisibility, showLoading, showExtensionInvalidState } from './button-manager.js';
import { getCaseData } from './case-extractor.js';
import { isVerbose } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('Assistant');

export class PandaAidCaseAssistant {
  constructor() {
    this.sidebar = null;
    this.pandAidButton = null;
    this.isAnalyzing = false;
    this.buttonClickTimeout = null;
    // Don't call initialize here - it's async now
  }

  async initialize() {
    logger.info('PandaAid initializing...', 'assistant', undefined);
    await injectStyles();
    await this.createpandAidButton();
    await this.createSidebar();
    this.setupEventListeners();

    setTimeout(() => {
      this.adjustButtonPosition();
      this.updateButtonVisibility();
      logger.info('PandaAid initialization complete. Button visible:', 'assistant', this.pandAidButton && this.pandAidButton.style.display !== 'none');
    }, 100);
  }

  async createpandAidButton() {
    this.pandAidButton = await createPandAidButton(this);
  }

  adjustButtonPosition() {
    adjustButtonPosition(this);
  }

  async createSidebar() {
    // Wait for SalesforceSidebar to be available from sidebar.js
    const maxWait = 5000; // 5 seconds max
    const startTime = Date.now();

    while (!window.SalesforceSidebar && (Date.now() - startTime) < maxWait) {
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    if (!window.SalesforceSidebar) {
      logger.error('SalesforceSidebar not available after waiting', 'assistant', undefined);
      return;
    }

    if (this.sidebar && typeof this.sidebar.cleanup === 'function') {
      this.sidebar.cleanup();
    }
    this.sidebar = new window.SalesforceSidebar();
    logger.info('Sidebar instance created', 'assistant', undefined);
  }

  setupEventListeners() {
    if (!this.pandAidButton) return;
    this.pandAidButton.addEventListener('click', (e) => {
      logger.info('PandAid button clicked!', 'assistant', e);
      e.preventDefault();
      e.stopPropagation();
      if (this.buttonClickTimeout) {
        logger.info('Click ignored due to debounce', 'assistant', undefined);
        return;
      }
      this.buttonClickTimeout = setTimeout(() => {
        this.buttonClickTimeout = null;
      }, 300);
      this.addTextToPandAid();
    });

    window.addEventListener('sidebarToggle', (e) => {
      if (isVerbose()) logger.info('[ContentScript] sidebarToggle received:', 'assistant', e && e.detail);
      if (e.detail && typeof e.detail.isVisible === 'boolean') {
        if (this.sidebar) {
          this.sidebar.isVisible = e.detail.isVisible;
        }
        this.updateButtonVisibility();
      }
    });
  }

  addTextToPandAid() {
    logger.info('addTextToPandAid called', 'assistant', undefined);
    if (!this.sidebar) {
      logger.error('Sidebar not initialized', 'assistant', undefined);
      return;
    }
    try {
      if (!this.sidebar.isVisible) {
        logger.info('Opening sidebar...', 'assistant', undefined);
        this.sidebar.toggle(true);
      }
      const originalChildren = Array.from(this.pandAidButton.childNodes).map(node => node.cloneNode(true));
      this.pandAidButton.replaceChildren(
        (() => {
          const img = document.createElement('img');
          img.src = chrome.runtime.getURL('images/pandaid-icon.png');
          img.alt = 'PandAid';
          img.width = 24;
          img.height = 24;
          return img;
        })(),
        (() => {
          const span = document.createElement('span');
          span.textContent = 'Opened';
          return span;
        })()
      );
      this.pandAidButton.style.background = '#007bff';
      setTimeout(() => {
        this.pandAidButton.replaceChildren(...originalChildren.map(node => node.cloneNode(true)));
        this.pandAidButton.style.background = ''; // Clear inline style to let CSS take over
      }, 1000);
      setTimeout(() => {
        this.updateButtonVisibility();
      }, 100);
    } catch (error) {
      logger.error('Error opening PandAid:', 'assistant', error);
    }
  }

  updateButtonVisibility() {
    updateButtonVisibility(this);
  }

  showLoading(isLoading) {
    showLoading(this, isLoading);
  }

  isExtensionContextValid() {
    try {
      return !!(chrome?.runtime?.id);
    } catch (error) {
      logger.debug('Extension context check failed (likely invalidated)', 'assistant', error);
      return false;
    }
  }

  async analyzeCase() {
    if (!this.isExtensionContextValid()) {
      this.sidebar.showError('Extension was reloaded. Please refresh the page to continue using PandAid.');
      this.showLoading(false);
      return;
    }
    if (this.isAnalyzing) {
      return;
    }
    try {
      this.showLoading(true);
      const caseData = await this.getCaseData();
      let response;
      try {
        if (typeof chrome.runtime.sendMessage === 'function') {
          response = await new Promise((resolve, reject) => {
            let done = false;
            const timer = setTimeout(() => {
              if (!done) {
                done = true;
                reject(new Error('No response from background (timeout)'));
              }
            }, 20000);
            try {
              chrome.runtime.sendMessage({ action: 'analyzeCase', data: caseData }, (resp) => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                const lastErr = chrome.runtime.lastError;
                if (lastErr) return reject(lastErr);
                resolve(resp);
              });
            } catch (err) {
              if (!done) {
                done = true;
                clearTimeout(timer);
                logger.debug('Message send failed in block', 'assistant', err);
                reject(err);
              }
            }
          });
        } else {
          throw new Error('Messaging to background is unavailable in this context');
        }
      } catch (error) {
        logger.debug('Analysis message send failed', 'assistant', error);
        if (error.message.includes('Extension context invalidated') || error.message.includes('receiving end does not exist')) {
          throw new Error('Extension was reloaded. Please refresh the page to continue using PandAid.');
        }
        throw error;
      }
      if (response?.error) {
        throw new Error(response.error);
      }
      if (response?.data) {
        this.sidebar.updateContent(response.data);
      }
    } catch (error) {
      logger.error('Error analyzing case:', 'assistant', error);
      if (error.message.includes('Extension context invalidated') || error.message.includes('receiving end does not exist') || error.message.includes('Extension was reloaded')) {
        this.showExtensionInvalidState();
      }
      this.sidebar.showError(error.message || 'An error occurred while analyzing the case');
      if (!this.sidebar.isVisible) {
        this.sidebar.toggle(true);
        setTimeout(() => this.updateButtonVisibility(), 100);
      }
    } finally {
      this.showLoading(false);
    }
  }

  showExtensionInvalidState() {
    showExtensionInvalidState(this);
  }

  addTextToActiveTextBox(selectedText) {
    if (isVerbose()) logger.debug('Adding text:', 'assistant', selectedText.substring(0, 50) + '...');
    if (!this.sidebar) {
      this.insertIntoAnyTextarea(selectedText);
      return;
    }
    if (!this.sidebar.isVisible) {
      this.sidebar.toggle(true);
      setTimeout(() => this.insertText(selectedText), 500);
    } else {
      this.insertText(selectedText);
    }
  }

  insertText(selectedText) {
    const sidebarEl = document.querySelector('#sf-case-assistant-sidebar');
    const targets = [
      document.activeElement?.tagName === 'TEXTAREA' ? document.activeElement : null,
      sidebarEl?.querySelector('#original-text-input'),
      sidebarEl?.querySelector('#improved-text-input'),
      sidebarEl?.querySelector('textarea:not([readonly])'),
      document.querySelector('textarea:not([readonly])')
    ].filter(Boolean);

    const target = targets[0];
    if (target) {
      const pos = target.selectionStart || target.value.length;
      const separator = target.value && !target.value.endsWith('\n') ? '\n' : '';
      target.value = target.value.slice(0, pos) + separator + selectedText + target.value.slice(pos);
      target.focus();
      target.setSelectionRange(pos + separator.length + selectedText.length, pos + separator.length + selectedText.length);
      target.dispatchEvent(new Event('input', { bubbles: true }));
      if (isVerbose()) logger.info('Text inserted successfully', 'assistant', undefined);
    } else {
      logger.error('No suitable textarea found', 'assistant', undefined);
    }
  }

  insertIntoAnyTextarea(selectedText) {
    if (this.sidebar) {
      // If sidebar exists, use it!
      const originalInput = document.querySelector('#sf-case-assistant-sidebar #original-text-input');
      if (originalInput) {
        this.insertText(selectedText);
        return;
      }
    }
    // Fallback
    const textarea = document.querySelector('textarea:not([readonly])');
    if (textarea) this.insertText(selectedText);
    else logger.error('No textarea found', 'assistant', undefined);
  }

  getCaseData() {
    return getCaseData(this);
  }
}

export let assistantInstance = null;

export function ensureAssistantInstance() {
  if (!assistantInstance) {
    assistantInstance = new PandaAidCaseAssistant();
    // Initialize async but don't block
    assistantInstance.initialize().catch((error) => {
      logger.error('Failed to initialize assistant:', 'assistant', error);
    });
  }
  try { window.assistantInstance = assistantInstance; } catch (e) { logger.debug('Failed to set window global', 'assistant', e); }
  return assistantInstance;
}

export function setAssistantInstance(instance) {
  assistantInstance = instance;
  try { window.assistantInstance = assistantInstance; } catch (e) { logger.debug('Failed to set window global', 'assistant', e); }
}
