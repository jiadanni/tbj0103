/**
 * Strategy for extracting text from Salesforce Chatter publishers.
 */
import { InputStrategy } from './input-strategy.js';
import { Result } from '../../utils/result.js';
import { createLogger } from '../../utils/logger.js';
import { isElementInSidebar, isTextEntryElement, isSubjectFieldElement, isElementVisible } from './shadow-dom-utils.js';
import { extractTextFromElement } from './selection-extractor.js';

const logger = createLogger('ChatterExtractor');

export class ChatterExtractor extends InputStrategy {
    constructor(sidebar) {
        super();
        this.sidebar = sidebar;
    }

    async canHandle() {
        try {
            const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
            const response = await fetch(configUrl);
            const config = await response.json();
            const detectionSelectors = config.chatter.detectionSelectors || [];
            if (detectionSelectors.length > 0) {
                return !!document.querySelector(detectionSelectors.join(', '));
            }
        } catch (e) {
            logger.debug('Failed to load detection selectors, using fallback', 'chatter-extractor');
        }
        // Optimistically check for chatter publisher elements
        return !!document.querySelector('.forceChatterPublisher, .slds-publisher, [class*="chatter"]');
    }

    async execute() {
        return await this.getOperatorInputText(this.sidebar);
    }

    async getOperatorInputText(sidebar) {
        try {
            logger.info('=== Chatter Text Detection Debug ===', 'chatter-extractor', undefined);

            // Method 1: Check currently focused element first (but exclude sidebar elements)
            const focusedElement = document.activeElement;

            if (focusedElement && !isElementInSidebar(sidebar, focusedElement)) {
                if (!isTextEntryElement(focusedElement)) {
                    // not text entry
                } else if (isSubjectFieldElement(focusedElement)) {
                    // subject field
                } else {
                    const focusedText = extractTextFromElement(focusedElement);
                    if (focusedText) {
                        return Result.success(focusedText);
                    }
                }
            }

            // Method 2: Comprehensive selector search with multiple extraction methods
            let selectors = [];
            try {
                // We'll use a safer approach for loading config in a strategy
                const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
                const response = await fetch(configUrl);
                const config = await response.json();
                selectors = config.chatter.publisherSelectors || [];
                logger.debug('Loaded chatter selectors from config', 'chatter-extractor');
            } catch (configError) {
                logger.warn('Failed to load chatter selectors from config, using fallbacks', 'chatter-extractor', configError);
                selectors = [
                    '.ql-editor',
                    '.forceChatterPublisher .ql-editor',
                    '.slds-publisher .ql-editor',
                    '.publisherContainer .ql-editor',
                    '[data-aura-class*="forceChatterPublisher"] .ql-editor',
                    '.forceChatterCommentPublisher .ql-editor',
                    '[data-aura-class*="CommentPublisher"] .ql-editor',
                    '[contenteditable="true"]',
                    '.forceChatterPublisher [contenteditable="true"]',
                    '.slds-publisher [contenteditable="true"]',
                    '.publisherContainer [contenteditable="true"]',
                    'textarea',
                    'input[type="text"]',
                    '.forceChatterPublisher textarea',
                    '.slds-publisher textarea',
                    '.cke_editable',
                    '.mce-content-body',
                    '[role="textbox"]',
                    '[class*="chatter"] .ql-editor',
                    '[class*="publisher"] .ql-editor',
                    '[class*="composer"] .ql-editor',
                    '[class*="editor"]',
                    'lightning-input-rich-text [contenteditable]',
                    'lightning-textarea textarea',
                    '[data-target-selection-name*="chatter"] .ql-editor',
                    '[data-aura-class*="chatter"] .ql-editor'
                ];
            }

            const foundElements = [];

            // Search with each selector and collect all potential elements
            for (const selector of selectors) {
                try {
                    const elements = document.querySelectorAll(selector);
                    for (const element of elements) {
                        // Skip sidebar elements
                        if (isElementInSidebar(sidebar, element)) continue;
                        if (!isTextEntryElement(element)) continue;
                        // Skip Subject field elements - we want Chatter text, not case subject
                        if (isSubjectFieldElement(element)) {
                            continue;
                        }

                        const text = extractTextFromElement(element);
                        if (text) {
                            foundElements.push({
                                element: element,
                                text: text,
                                selector: selector,
                                isFocused: element === focusedElement,
                                isVisible: isElementVisible(element),
                                length: text.length
                            });
                        }
                    }
                } catch (e) {
                    logger.warn('Selector failed:', 'chatter-extractor', selector, e.message);
                }
            }

            if (foundElements.length === 0) {
                return Result.success(null);
            }

            // Priority sorting: focused > visible > longest text
            foundElements.sort((a, b) => {
                if (a.isFocused && !b.isFocused) return -1;
                if (!a.isFocused && b.isFocused) return 1;
                if (a.isVisible && !b.isVisible) return -1;
                if (!a.isVisible && b.isVisible) return 1;
                return b.length - a.length; // Longest text first
            });

            const selectedItem = foundElements[0];
            logger.debug('✓ Selected text:', 'chatter-extractor', selectedItem.text.substring(0, 50) + '...');

            return Result.success(selectedItem.text);

        } catch (error) {
            logger.error('Error getting operator input text:', 'chatter-extractor', error);
            return Result.failure(error);
        }
    }
}
