import { OPTIONS_MESSAGE_RESPONSE_TIMEOUT_MS } from '../config/constants.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('OptionsMessaging');

// Wrapper for chrome.runtime.sendMessage with a timeout fallback
export function sendMessageWithTimeout(message, timeout = OPTIONS_MESSAGE_RESPONSE_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) {
        done = true;
        reject(new Error('No response from background (timeout)'));
      }
    }, timeout);

    try {
      chrome.runtime.sendMessage(message, (resp) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        const lastErr = chrome.runtime.lastError;
        if (lastErr) return reject(lastErr);
        resolve(resp);
      });
    } catch (err) {
      if (!done) {
        done = true;
        clearTimeout(timer);
        logger.warn('Message send failed', 'options-messaging', err);
        reject(err);
      }
    }
  });
}
