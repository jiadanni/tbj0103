/**
 * Promise utilities used throughout the extension.
 */

const DEFAULT_TIMEOUT_MESSAGE = 'Operation timed out';

/**
 * Wrap an async operation with a timeout. The operation can be a promise or a
 * function that returns a promise. Ensures the timeout timer is cleared when
 * the operation settles to avoid leaking timers.
 *
 * @param {Promise|Function} operation - Promise or function returning a promise
 * @param {number} ms - Timeout duration in milliseconds
 * @param {string} [errorMessage] - Custom error message for timeout
 * @returns {Promise<any>} Resolves/rejects with the underlying operation
 */
export function withTimeout(operation, ms, errorMessage = DEFAULT_TIMEOUT_MESSAGE) {
  const execute = typeof operation === 'function' ? operation : () => operation;

  if (!Number.isFinite(ms) || ms <= 0) {
    return Promise.resolve().then(() => execute());
  }

  let timeoutId = null;
  let settled = false;

  const startTimer = () => new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      if (settled) {
        return;
      }
      const error = new Error(errorMessage);
      error.name = 'TimeoutError';
      reject(error);
    }, ms);

    if (typeof timeoutId?.unref === 'function') {
      timeoutId.unref();
    }
  });

  const clearTimer = () => {
    settled = true;
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  };

  return Promise.race([
    Promise.resolve().then(() => execute()),
    startTimer()
  ]).then((result) => {
    clearTimer();
    return result;
  }).catch((error) => {
    clearTimer();
    throw error;
  });
}

/**
 * Helper specifically for wrapping dynamic imports with a timeout.
 * @param {string} url - Module URL to import
 * @param {number} timeoutMs - Timeout duration
 * @param {string} [label] - Label for error messages
 * @returns {Promise<any>} Resolves with the imported module
 */
export function importWithTimeout(url, timeoutMs, label = url) {
  const contextLabel = label || url;
  const message = `Dynamic import timed out after ${timeoutMs}ms: ${contextLabel}`;
  return withTimeout(() => import(url), timeoutMs, message);
}
