/**
 * Community/Knowledge Base Message Handlers
 */
import { searchCommunityGuides } from '../api/community-service.js';
import { getKnowledgeBaseLabels } from '../utils/knowledge-base-labels.js';
import { Result } from '../utils/result.js';
import { createLogger } from '../utils/logger.js';
import { cleanEmailContent } from '../utils/email-helpers.js';
import { removeMarkdownCodeBlocks } from '../utils/json-parser.js';
import { makeApiRequest, getActiveAiModel } from '../api/ai-service.js';

const logger = createLogger('CommunityHandlers');

/**
 * Handles requests for FETCH_COMMUNITY_GUIDES.
 */
export async function handleGetCommunityGuidesRequest(request) {
    logger.debug('Received Knowledge Base request', 'knowledgeBaseHandler', request);
    const labels = await getKnowledgeBaseLabels();
    const isManualFetch = Boolean(request.isManualFetch);
    const result = await searchCommunityGuides(request.caseData || {}, 3, isManualFetch);

    if (!result.ok) {
        logger.error('Community guides search failed', 'knowledgeBaseHandler', result.error);
        return result;
    }

    const items = Array.isArray(result.value) ? result.value : [];
    const guidesResp = items.map(guide => ({
        id: guide.id || guide.articleId || null,
        title: (guide.title || guide.name || 'Untitled').replace(/^\?+/, '').trim(),
        url: guide.url || guide.link || '#',
        excerpt: guide.aiExplanation || guide.explanation || guide.excerpt || (guide.content && typeof guide.content === 'string' ? guide.content.substring(0, 400) : '') || '',
        source: guide.category || labels.entryLabel,
        aiRelevanceScore: guide.aiRelevanceScore || guide.score || null,
        aiExplanation: guide.aiExplanation || guide.explanation || null,
        aiFallback: !!guide.aiFallback
    }));

    return Result.success(guidesResp);
}

export async function handleExplainCommunityGuideRequest(request) {
    logger.debug('Received explainCommunityGuide request', 'explainCommunityHandler');
    if (!request.caseData || typeof request.caseData !== 'object') {
        throw new Error('Invalid case data provided');
    }

    if (!request.article || typeof request.article !== 'object') {
        throw new Error('Invalid article data provided');
    }

    const kbLabels = await getKnowledgeBaseLabels();
    const caseData = request.caseData;
    const article = request.article;

    const prompt = `Given the following case context:
Subject: ${caseData.subject || 'N/A'}
Description: ${caseData.description ? cleanEmailContent(caseData.description) : 'N/A'}

And this ${kbLabels.entryLabel} article:
Title: ${article.title || 'Untitled'}
Excerpt: ${article.excerpt || article.content || ''}

Provide a concise (1-2 sentence) explanation of why this article is relevant to the case.`;

    const aiMutation = 'mutation ExplainCommunityGuide($model: String!, $prompt: String!, $temperature: Float) { answerPrompt(input: { model: $model, prompt: $prompt, temperature: $temperature }) }';
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
    const model = await getActiveAiModel();
    const temperature = advancedAiSettings?.contextSettings?.communityGuides?.temperature ?? 0.2;

    const variables = { model, prompt, temperature };
    const response = await makeApiRequest(aiMutation, variables);
    const aiText = response?.data?.answerPrompt || null;
    const cleaned = aiText ? removeMarkdownCodeBlocks(String(aiText).trim()) : null;
    return Result.success({ explanation: cleaned });
}
