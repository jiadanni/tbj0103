/**
 * Text Utilities Module
 * Utilities for text processing and search term extraction
 *
 * @module text-utils
 */

/**
 * Extract meaningful search terms from text.
 * Mirrors the Atlassian service implementation so callers stay consistent.
 * Prioritizes error codes, technical terms, and abbreviation expansions.
 *
 * @param {string} text - The text to extract terms from (can contain error codes, technical terms)
 * @param {number} [maxTerms=5] - Maximum number of terms to extract (limits result size)
 * @returns {string[]} Array of extracted search terms (prioritized by relevance)
 * @example
 * extractSearchTerms('Got error 500 and API timeout') 
 * // Returns: ['error 500', 'API timeout', ...]
 */
export function extractSearchTerms(text, maxTerms = 5) {
  if (!text) return [];

  const terms = [];
  const processedTerms = new Set(); // Avoid duplicates

  // 1. Extract error codes and IDs first (highest priority)
  const errorPatterns = [
    /\b[A-Z]{2,4}-?\d{3,6}\b/g, // JIRA-style IDs: ABC-1234
    /\berror\s+\d+\b/gi, // Error codes: error 500
    /\b\d{3,4}\s+error\b/gi, // HTTP errors: 404 error
    /\b[A-Z]{3,8}_[A-Z_]+\b/g, // Constants: API_ERROR_CODE
  ];

  errorPatterns.forEach(pattern => {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(match => {
        const lower = match.toLowerCase();
        if (!processedTerms.has(lower)) {
          terms.push(match);
          processedTerms.add(lower);
        }
      });
    }
  });

  // 2. Expand common abbreviations
  const abbreviations = {
    lti: 'Learning Tools Interoperability',
    sso: 'Single Sign On',
    api: 'Application Programming Interface',
    ui: 'User Interface',
    url: 'Uniform Resource Locator',
    saml: 'Security Assertion Markup Language',
    oauth: 'Open Authorization',
    lms: 'Learning Management System',
    csv: 'Comma Separated Values',
    json: 'JavaScript Object Notation',
    xml: 'eXtensible Markup Language'
  };

  // 3. Clean and tokenize the text
  const cleanText = text
    .replace(/[^\w\s-]/g, ' ') // Remove special chars except hyphens
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim();

  const words = cleanText.split(' ');

  // 4. Extract technical terms and meaningful words
  for (const word of words) {
    if (terms.length >= maxTerms) break;

    const lowerWord = word.toLowerCase();

    // Skip if already processed or too short
    if (processedTerms.has(lowerWord) || word.length < 3) continue;

    // Skip common words
    if (isCommonWord(word)) continue;

    // Add abbreviation expansions
    if (abbreviations[lowerWord]) {
      const expansion = abbreviations[lowerWord];
      terms.push(expansion);
      processedTerms.add(lowerWord);
      processedTerms.add(expansion.toLowerCase());
    }

    // Add the original word with simple stemming
    const stemmed = applyStemming(word);
    if (!processedTerms.has(stemmed.toLowerCase())) {
      terms.push(stemmed);
      processedTerms.add(stemmed.toLowerCase());
    }
  }

  // 5. Extract meaningful phrases (technical combinations)
  for (let i = 0; i < words.length - 1 && terms.length < maxTerms; i++) {
    const phrase = words.slice(i, i + 2).join(' ');
    const lowerPhrase = phrase.toLowerCase();

    if (!processedTerms.has(lowerPhrase) &&
        !isCommonWord(words[i]) &&
        isTechnicalPhrase(phrase)) {
      terms.push(phrase);
      processedTerms.add(lowerPhrase);
    }
  }

  // Remove duplicates and limit to max terms
  return terms.slice(0, maxTerms);
}

/**
 * Check if a word is a common word that should be filtered out.
 * Common words are ignored during term extraction to improve relevance.
 *
 * @private
 * @param {string} word - The word to check against common word list
 * @returns {boolean} True if the word is a common English word that should be filtered
 */
function isCommonWord(word) {
  const commonWords = [
    'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
    'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
    'will', 'would', 'could', 'should', 'may', 'might', 'can', 'must',
    'this', 'that', 'these', 'those', 'a', 'an', 'some', 'any', 'all',
    'not', 'no', 'yes', 'so', 'if', 'then', 'when', 'where', 'why', 'how',
    'get', 'got', 'getting', 'use', 'using', 'used', 'make', 'making', 'made'
  ];
  return commonWords.includes(word.toLowerCase());
}

/**
 * Apply simple stemming rules to normalize words.
 * Removes common suffixes (ing, ed, er, etc.) to improve term matching.
 *
 * @private
 * @param {string} word - The word to stem (will be lowercased internally)
 * @returns {string} The stemmed word with suffixes removed
 * @example
 * applyStemming('running') // Returns: 'run'
 * applyStemming('connection') // Returns: 'connect'
 */
function applyStemming(word) {
  const lowerWord = word.toLowerCase();

  // Common suffixes to remove for better matching
  const stemmingRules = [
    { suffix: 'ing', replacement: '' },
    { suffix: 'ed', replacement: '' },
    { suffix: 'er', replacement: '' },
    { suffix: 'est', replacement: '' },
    { suffix: 'ly', replacement: '' },
    { suffix: 'ion', replacement: '' },
    { suffix: 'tion', replacement: '' },
    { suffix: 'ness', replacement: '' },
    { suffix: 'ment', replacement: '' },
    { suffix: 's', replacement: '' }, // Simple plurals
  ];

  for (const rule of stemmingRules) {
    if (lowerWord.endsWith(rule.suffix) &&
        lowerWord.length > rule.suffix.length + 2) { // Keep reasonable word length
      return word.slice(0, -(rule.suffix.length)) + rule.replacement;
    }
  }

  return word;
}

/**
 * Determine if a phrase contains technical indicators relevant to integration issues.
 * Checks for domain-specific keywords related to errors, APIs, databases, etc.
 *
 * @private
 * @param {string} phrase - The phrase to analyze for technical content
 * @returns {boolean} True if the phrase contains technical indicators
 */
function isTechnicalPhrase(phrase) {
  const technicalIndicators = [
    'error', 'issue', 'problem', 'bug', 'fail', 'crash', 'timeout',
    'login', 'authentication', 'authorization', 'permission', 'access',
    'api', 'endpoint', 'request', 'response', 'server', 'client',
    'database', 'query', 'connection', 'sync', 'integration',
    'payment', 'billing', 'transaction', 'account', 'user',
    'course', 'assignment', 'grade', 'gradebook', 'canvas',
    'lti', 'tool', 'app', 'plugin', 'extension'
  ];

  return technicalIndicators.some(indicator =>
    phrase.toLowerCase().includes(indicator)
  );
}
