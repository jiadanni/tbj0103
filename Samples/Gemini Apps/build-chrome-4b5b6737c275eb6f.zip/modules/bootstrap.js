// Bootstrap for background service worker initialization
import { initializeServiceWorker, initializeAllListeners, setInitializationState } from './initialization.js';
import { initializeContextMenuListener } from '../../modules/ui/context-menu.js';
import { initializeMessageListener } from '../../modules/handlers/message-handlers.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('Bootstrap');

export function startBackground() {
  logger.info('BACKGROUND: Starting synchronous initialization...', 'bootstrap', undefined);

  // Initialize all event listeners FIRST (synchronous)
  initializeAllListeners();
  logger.info('BACKGROUND: Lifecycle listeners initialized', 'bootstrap', undefined);

  // Initialize message listener IMMEDIATELY (synchronous, critical)
  initializeMessageListener();
  logger.info('BACKGROUND: Message listener initialized', 'bootstrap', undefined);

  // Initialize context menu listener
  initializeContextMenuListener();
  logger.info('BACKGROUND: Context menu listener initialized', 'bootstrap', undefined);

  // Run async initialization in background (non-blocking)
  if (chrome.runtime && chrome.runtime.id) {
    logger.info('BACKGROUND: chrome.runtime.id present, starting async init', 'bootstrap', undefined);
    initializeServiceWorker().then(() => {
      setInitializationState(true);
      logger.info('BACKGROUND: Async initialization complete', 'bootstrap', undefined);
    }).catch(error => {
      logger.error('BACKGROUND: Async initialization failed:', 'bootstrap', error);
    });
  } else {
    logger.warn('BACKGROUND: chrome.runtime.id NOT available', 'bootstrap', undefined);
  }
}
