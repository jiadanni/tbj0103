/**
 * AI Settings Controller
 * Manages AI model configuration, sliders, and context settings.
 */
import {
    // initializeDefaultContextSettings removed
    setupAllSliders,
    switchContextTab
} from '../ai-settings.js';

export class AiSettingsController {
    constructor(elements, dependencies) {
        this.elements = elements;
        this.dependencies = dependencies;
        this.sliderGroups = elements.sliderGroups;
    }

    initialize() {
        this.setupContextTabs();
        this.setupSliders();
        this.setupModelControls();
    }

    setupContextTabs() {
        const { contextTabs, aiContextDeps } = this.elements;

        // Explicitly attach the event listener to each tab
        contextTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.dataset.tab;
                switchContextTab(tabId, aiContextDeps);
            });
        });
    }

    setupSliders() {
        const { sliderGroups } = this.elements;
        setupAllSliders(sliderGroups);
    }

    setupModelControls() {
        const { modelControls } = this.elements;
        modelControls.forEach(({ input }) => {
            input.addEventListener('input', () => this.enforceModelRadioAvailability());
        });
        this.enforceModelRadioAvailability(); // Initial check
    }

    enforceModelRadioAvailability() {
        const { modelControls } = this.elements;
        let firstEligibleRadio = null;

        modelControls.forEach(({ input, radio }) => {
            const hasValue = Boolean(input.value.trim());
            radio.disabled = !hasValue;

            if (!hasValue && radio.checked) {
                radio.checked = false;
            }

            if (hasValue && !firstEligibleRadio) {
                firstEligibleRadio = radio;
            }
        });

        const anyRadioChecked = modelControls.some(({ radio }) => radio.checked);

        // Auto-select first available if none checked
        if (!anyRadioChecked && firstEligibleRadio) {
            firstEligibleRadio.checked = true;
            this.animateRadioSelection(firstEligibleRadio);
        }
    }

    animateRadioSelection(radio) {
        const label = radio.closest('label') || radio.parentElement;
        if (!label) return;

        label.classList.add('auto-selected-highlight');
        label.style.transition = 'background-color 0.3s ease';
        label.style.backgroundColor = '#e3f2fd'; // Light blue highlight

        setTimeout(() => {
            label.style.backgroundColor = '';
            label.classList.remove('auto-selected-highlight');
        }, 1500);
    }
}
