/**
 * Cache Manager Module
 * Handles caching of API responses with TTL (Time To Live)
 *
 * @module cache-manager
 */

// Cache configuration
import {
  CACHE_TTL_MS,
  CACHE_MAX_ENTRIES,
  CACHE_MAX_ENTRY_BYTES,
  CACHE_QUOTA_SAFETY_MARGIN,
  CACHE_PERSIST_DEBOUNCE_MS,
  CACHE_PERSIST_RETRY_DELAY_MS
} from '../config/constants.js';
import { handleError, ErrorStrategy } from '../utils/error-handler.js';
import { decrypt, encrypt, isEncrypted } from '../security/crypto-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('CacheManager');

export const CACHE_TTL = CACHE_TTL_MS;
export const CACHE_STORAGE_KEY = 'extensionResponseCache';
const ENCRYPTED_CACHE_MARKER = 'pandaid-encrypted-cache-v1';
export const MAX_CACHE_SIZE = CACHE_MAX_ENTRIES; // Maximum number of entries (LRU eviction)
export const MAX_ENTRY_BYTES = CACHE_MAX_ENTRY_BYTES; // 512KB limit per individual cache entry
const QUOTA_SAFETY_MARGIN = CACHE_QUOTA_SAFETY_MARGIN; // Keep below quota to reduce write failures
const PERSIST_RETRY_DELAY_MS = CACHE_PERSIST_RETRY_DELAY_MS;

// In-memory cache (Map persists for service worker lifetime)
export const responseCache = new Map();
const DEFAULT_PERSIST_DEBOUNCE_MS = CACHE_PERSIST_DEBOUNCE_MS;
const MAX_PERSIST_WAIT_MS = 10000; // Force persist after 10s even if updates continue
let persistTimerId = null;
let maxWaitTimerId = null;
let pendingPersistChain = Promise.resolve();

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Validate cache entry structure
 * @param {Object} entry - Cache entry to validate
 * @returns {boolean} Whether entry is valid
 */
function isValidCacheEntry(entry) {
  return entry &&
    typeof entry === 'object' &&
    'data' in entry &&
    typeof entry.timestamp === 'number' &&
    isFinite(entry.timestamp);
}

/**
 * Estimate byte size of a value for quota management
 * @param {any} value - Value to estimate
 * @returns {number} Estimated byte size
 */
function estimateBytes(value) {
  try {
    const json = JSON.stringify(value);
    // UTF-16 uses 2 bytes per character in JS strings, but JSON storage typically uses UTF-8
    return new Blob([json]).size;
  } catch (err) {
    // If JSON stringify fails, return a conservative estimate
    logger.debug('JSON.stringify failed in estimateBytes', 'cache-manager', err);
    return 0;
  }
}

/**
 * Get bytes in use for chrome.storage.local
 * @param {string|null} key - Specific key or null for total
 * @returns {Promise<number>} Bytes in use
 */
async function getBytesInUse(key) {
  if (chrome?.storage?.local?.getBytesInUse) {
    return chrome.storage.local.getBytesInUse(key);
  }
  // Fallback: estimate from stored data
  const data = await chrome.storage.local.get(null);
  return estimateBytes(data);
}

/**
 * Trim cache to fit within a byte budget
 * @param {number} maxBytes - Maximum bytes to allow
 */
function trimCacheToFitBytes(maxBytes) {
  let currentSize = 0;
  const entriesToDelete = [];

  // Calculate current cache size
  for (const [key, entry] of responseCache.entries()) {
    const entrySize = estimateBytes(entry);
    currentSize += entrySize;
  }

  if (currentSize <= maxBytes) return;

  // Evict oldest entries (Map maintains insertion order, oldest first)
  for (const [key, entry] of responseCache.entries()) {
    if (currentSize <= maxBytes) break;
    const entrySize = estimateBytes(entry);
    entriesToDelete.push(key);
    currentSize -= entrySize;
  }

  for (const key of entriesToDelete) {
    responseCache.delete(key);
  }

  if (entriesToDelete.length > 0) {
    logger.info(`Trimmed ${entriesToDelete.length} cache entries to fit quota`, 'cache-manager');
  }
}

/**
 * Persist cache to chrome.storage.local
 * @returns {Promise<void>}
 */
export async function persistCache() {
  try {
    // Convert Map to array of [key, entry] pairs for storage
    const cacheArray = Array.from(responseCache.entries());

    await chrome.storage.local.set({
      [CACHE_STORAGE_KEY]: cacheArray
    });

    logger.debug(`Persisted ${cacheArray.length} cache entries`, 'cache-manager');
  } catch (error) {
    logger.error('Failed to persist cache:', 'cache-manager', error);

    // If quota exceeded, try trimming and retrying once
    if (error?.message?.includes('QUOTA') || error?.name === 'QuotaExceededError') {
      logger.warn('Quota exceeded, trimming cache and retrying', 'cache-manager');
      trimCacheToMax();
      trimCacheToFitBytes((await getBytesInUse(null)) * QUOTA_SAFETY_MARGIN);

      const trimmedArray = Array.from(responseCache.entries());
      await chrome.storage.local.set({
        [CACHE_STORAGE_KEY]: trimmedArray
      });
    } else {
      throw error;
    }
  }
}

/**
 * Restore cache from chrome.storage.local
 * @returns {Promise<void>}
 */
export async function restoreCache() {
  try {
    const result = await chrome.storage.local.get(CACHE_STORAGE_KEY);
    const storedCache = result[CACHE_STORAGE_KEY];

    if (!storedCache || !Array.isArray(storedCache)) {
      logger.debug('No cached data found in storage', 'cache-manager');
      return;
    }

    const now = Date.now();
    let restored = 0;
    let expired = 0;

    for (const [key, entry] of storedCache) {
      if (!isValidCacheEntry(entry)) {
        continue;
      }

      // Check if entry has expired
      if ((now - entry.timestamp) >= CACHE_TTL) {
        expired++;
        continue;
      }

      responseCache.set(key, entry);
      restored++;
    }

    logger.info(`Restored ${restored} cache entries (${expired} expired, skipped)`, 'cache-manager');
  } catch (error) {
    logger.error('Failed to restore cache:', 'cache-manager', error);
    // Non-fatal: start with empty cache
  }
}

function enqueueScheduledPersist() {
  const runPersist = () => persistCache();

  pendingPersistChain = pendingPersistChain.then(runPersist, (error) => {
    logger.error('Previous persist operation failed:', 'cache-manager', error);
    return runPersist();
  });

  pendingPersistChain.catch(error => {
    logger.error('Scheduled cache persist failed:', 'cache-manager', error);
  });

  return pendingPersistChain;
}

/**
 * Debounce cache persistence to prevent overlapping writes.
 * includes a maxWait to prevent indefinite deferral during high activity.
 * @param {number} [debounceMs]
 * @returns {Promise<any>}
 */
export function scheduleCachePersist(debounceMs = DEFAULT_PERSIST_DEBOUNCE_MS) {
  // If no max wait timer is running, start one to guarantee execution
  if (!maxWaitTimerId) {
    maxWaitTimerId = setTimeout(() => {
      logger.debug('Cache persist max wait reached, flushing', 'cache-manager');
      flushScheduledCachePersist();
    }, MAX_PERSIST_WAIT_MS);
  }

  if (persistTimerId) {
    clearTimeout(persistTimerId);
  }
  persistTimerId = setTimeout(() => {
    flushScheduledCachePersist();
  }, debounceMs);
  return pendingPersistChain;
}

/**
 * Force any scheduled persist to run immediately.
 * @returns {Promise<any>}
 */
export function flushScheduledCachePersist() {
  if (persistTimerId) {
    clearTimeout(persistTimerId);
    persistTimerId = null;
  }
  if (maxWaitTimerId) {
    clearTimeout(maxWaitTimerId);
    maxWaitTimerId = null;
  }
  return enqueueScheduledPersist();
}

/**
 * Clear all cached entries
 * @returns {void}
 */
export function clearCache() {
  responseCache.clear();
  logger.info('Cache cleared', 'cache-manager', undefined);
}

/**
 * Get a cached value by key
 * Moves accessed entry to end of Map for LRU tracking
 * @param {string} key - Cache key
 * @returns {any|null} Cached value or null if not found/expired
 */
export function getCached(key) {
  const cached = responseCache.get(key);
  if (!cached) return null;
  if (!isValidCacheEntry(cached)) {
    responseCache.delete(key);
    return null;
  }

  const now = Date.now();
  if ((now - cached.timestamp) >= CACHE_TTL) {
    // Expired
    responseCache.delete(key);
    return null;
  }

  // Move to end of Map for LRU (most recently used)
  responseCache.delete(key);
  responseCache.set(key, cached);

  return cached.data;
}

/**
 * Set a cache entry with proactive quota checking
 * @param {string} key - Cache key
 * @param {any} data - Data to cache
 * @returns {Promise<void>}
 */
export async function setCache(key, data) {
  if (typeof key !== 'string' || !key.trim()) return;

  const entry = {
    data,
    timestamp: Date.now()
  };

  const size = estimateBytes(entry);

  // 1. Hard limit on individual entry size
  if (size > MAX_ENTRY_BYTES) {
    logger.warn('Entry too large for cache', 'cache-manager', { key, size });
    return;
  }

  // 2. LRU Eviction by count
  responseCache.set(key, entry);
  trimCacheToMax();

  // 3. Proactive quota check
  try {
    const totalBytesInUse = await getBytesInUse(null);
    const currentQuota = Number.isFinite(chrome?.storage?.local?.QUOTA_BYTES)
      ? chrome.storage.local.QUOTA_BYTES
      : (5 * 1024 * 1024);

    if (totalBytesInUse > currentQuota * QUOTA_SAFETY_MARGIN) {
      logger.info('Cache approaching quota; performing emergency trim', 'cache-manager', {
        used: totalBytesInUse,
        quota: currentQuota
      });
      trimCacheToFitBytes(currentQuota * QUOTA_SAFETY_MARGIN);
    }
  } catch (e) {
    // Quota check errors are non-critical; allow cache operations to continue
    logger.debug('Quota check failed (non-critical)', 'checkQuotaAndTrim', e);
  }
}

/**
 * Clean up expired cache entries
 * Called periodically by chrome.alarms
 * @returns {number} Number of entries cleared
 */
export function cleanupExpiredEntries() {
  const now = Date.now();
  let cleared = 0;

  for (const [key, { timestamp }] of responseCache.entries()) {
    if ((now - timestamp) > CACHE_TTL) {
      responseCache.delete(key);
      cleared++;
    }
  }

  if (trimCacheToMax()) {
    cleared = Math.max(cleared, 0); // ensure non-negative
  }

  return cleared;
}

/**
 * Trim cache down to MAX_CACHE_SIZE by evicting oldest entries (LRU-friendly).
 * @returns {boolean} whether eviction occurred
 */
export function trimCacheToMax() {
  let evicted = false;
  while (responseCache.size > MAX_CACHE_SIZE) {
    const firstKey = responseCache.keys().next().value;
    if (firstKey === undefined) break;
    responseCache.delete(firstKey);
    evicted = true;
  }
  return evicted;
}
