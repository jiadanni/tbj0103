const DEFAULTS = {
  summary: { temp: 30, topP: 80, topK: 40 },
  community: { temp: 20, topP: 70, topK: 30 },
  jira: { temp: 25, topP: 85, topK: 35 },
  confluence: { temp: 40, topP: 90, topK: 50 }
};

export function setContextDefaults(sliderSet, defaults) {
  const temp = defaults?.temp ?? 30;
  const topP = defaults?.topP ?? 80;
  const topK = defaults?.topK ?? 40;
  const { tempSlider, tempValue, topPSlider, topPValue, topKSlider, topKValue } = sliderSet || {};

  if (tempSlider && tempValue) {
    tempSlider.value = temp;
    tempValue.textContent = (temp / 100).toFixed(2);
  }
  if (topPSlider && topPValue) {
    topPSlider.value = topP;
    topPValue.textContent = (topP / 100).toFixed(2);
  }
  if (topKSlider && topKValue) {
    topKSlider.value = topK;
    topKValue.textContent = String(topK);
  }
}

export function initializeDefaultContextSettings(sliders) {
  if (!sliders) return;
  setContextDefaults(sliders.summary, DEFAULTS.summary);
  setContextDefaults(sliders.community, DEFAULTS.community);
  setContextDefaults(sliders.jira, DEFAULTS.jira);
  setContextDefaults(sliders.confluence, DEFAULTS.confluence);
}

export function setupSlider(slider, valueElement, isDecimal = true) {
  if (!slider || !valueElement) return;
  slider.addEventListener('input', () => {
    if (isDecimal) {
      const value = (slider.value / 100).toFixed(2);
      valueElement.textContent = value;
    } else {
      valueElement.textContent = slider.value;
    }
  });
}

export function setupAllSliders(sliders) {
  if (!sliders) return;
  setupSlider(sliders.summary?.tempSlider, sliders.summary?.tempValue, true);
  setupSlider(sliders.summary?.topPSlider, sliders.summary?.topPValue, true);
  setupSlider(sliders.summary?.topKSlider, sliders.summary?.topKValue, false);

  setupSlider(sliders.community?.tempSlider, sliders.community?.tempValue, true);
  setupSlider(sliders.community?.topPSlider, sliders.community?.topPValue, true);
  setupSlider(sliders.community?.topKSlider, sliders.community?.topKValue, false);

  setupSlider(sliders.jira?.tempSlider, sliders.jira?.tempValue, true);
  setupSlider(sliders.jira?.topPSlider, sliders.jira?.topPValue, true);
  setupSlider(sliders.jira?.topKSlider, sliders.jira?.topKValue, false);

  setupSlider(sliders.confluence?.tempSlider, sliders.confluence?.tempValue, true);
  setupSlider(sliders.confluence?.topPSlider, sliders.confluence?.topPValue, true);
  setupSlider(sliders.confluence?.topKSlider, sliders.confluence?.topKValue, false);
}

export function switchContextTab(tabId, deps) {
  const { contextSettings, contextTabs, aiJiraToggle, atlassianTokenInput, createContextWarning } = deps || {};
  if (!contextSettings || !contextTabs) return;

  contextSettings.forEach(panel => {
    panel.style.display = 'none';
  });
  contextTabs.forEach(tab => {
    tab.classList.remove('active');
  });

  const selectedPanel = document.getElementById(`settings-${tabId}`);
  if (selectedPanel) {
    selectedPanel.style.display = 'block';
    if (tabId === 'jira' && aiJiraToggle) {
      const jiraAiEnabled = aiJiraToggle.checked;
      const hasAtlassianToken = atlassianTokenInput && atlassianTokenInput.value.trim().length > 0;

      if (!jiraAiEnabled || !hasAtlassianToken) {
        selectedPanel.classList.add('context-disabled');
        const warningMessage = selectedPanel.querySelector('.context-warning');
        if (!warningMessage && typeof createContextWarning === 'function') {
          const warning = createContextWarning(
            !jiraAiEnabled
              ? '<strong>Note:</strong> JIRA AI enhancement is currently disabled. These settings will only take effect when JIRA AI is enabled.'
              : '<strong>Note:</strong> JIRA AI requires a valid JIRA token to function. Please add a token in the Atlassian Integration section.'
          );
          selectedPanel.insertBefore(warning, selectedPanel.firstChild);
        }
      } else {
        selectedPanel.classList.remove('context-disabled');
        const warningMessage = selectedPanel.querySelector('.context-warning');
        if (warningMessage) warningMessage.remove();
      }
    }
  }

  const activeTab = document.getElementById(`tab-${tabId}`);
  if (activeTab) activeTab.classList.add('active');
}
