// modules/content/button-manager.js
//
// Create and manage the main PandAid button.

import { isVerbose } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('ButtonManager');

export async function createPandAidButton(assistant) {
  document.querySelectorAll('.sf-pandaid-button').forEach(btn => btn.remove());

  // Load custom button label from settings
  let buttonLabel = 'PandAid';
  try {
    const settings = await chrome.storage.local.get(['buttonLabel']);
    if (settings.buttonLabel && settings.buttonLabel.trim()) {
      buttonLabel = settings.buttonLabel.trim();
    }
  } catch (e) {
    logger.warn('Failed to load button label from storage, using default', 'button-manager', e);
  }

  const button = document.createElement('button');
  button.className = 'sf-pandaid-button';
  button.id = 'pandaid-main-button';
  button.setAttribute('aria-label', `Open ${buttonLabel}`);
  const icon = document.createElement('img');
  icon.src = chrome.runtime.getURL('images/pandaid-icon.png');
  icon.alt = buttonLabel;
  icon.width = 24;
  icon.height = 24;
  const label = document.createElement('span');
  label.textContent = buttonLabel;
  button.append(icon, label);

  button.tabIndex = 0;

  document.body.appendChild(button);
  if (isVerbose()) logger.info('Button created and added to DOM:', 'button-manager', { buttonLabel });

  installButtonObserver(assistant);
  return button;
}

function installButtonObserver(assistant) {
  try {
    if (window._pandaid_button_observer_installed) return;
    const observer = new MutationObserver(() => {
      try {
        const exists = document.getElementById('pandaid-main-button');
        if (!exists && assistant) {
          setTimeout(() => {
            try {
              assistant.createpandAidButton();
              assistant.adjustButtonPosition();
              assistant.updateButtonVisibility();
            } catch (e) {
              logger.error('Error recreating PandAid button from observer:', 'button-manager', e);
            }
          }, 200);
        }
      } catch (e) {
        logger.warn('Button observer mutation handler error', 'button-manager', e);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    window._pandaid_button_observer_installed = true;
    window._pandaid_button_observer = observer;
  } catch (e) {
    logger.warn('Failed to install PandAid button observer:', 'button-manager', e);
  }
}

export function adjustButtonPosition(assistant) {
  const button = assistant?.pandAidButton;
  if (!button) return;

  const buttonRect = button.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  const minRight = 10;
  const minBottom = 10;
  const maxRight = Math.max(minRight, Math.min(20, viewportWidth - buttonRect.width - 10));
  const maxBottom = Math.max(minBottom, Math.min(20, viewportHeight - buttonRect.height - 10));

  button.style.right = `${Math.min(20, maxRight)}px`;
  button.style.bottom = `${Math.min(20, maxBottom)}px`;

  if (isVerbose()) logger.info('Adjusting button position.', 'button-manager', undefined);
}

export function updateButtonVisibility(assistant) {
  const button = assistant?.pandAidButton;
  if (!button) return;

  const sidebar = assistant?.sidebar;
  
  // If sidebar isn't ready yet, show the button by default
  if (!sidebar) {
    button.style.display = 'flex';
    button.style.visibility = 'visible';
    if (isVerbose()) {
      logger.info('Button visibility updated (no sidebar yet):', 'button-manager', {
        buttonDisplay: button.style.display
      });
    }
    return;
  }

  // Only hide button if sidebar is actually visible (has the visible class on host)
  const sidebarHost = document.getElementById('sf-pandaid-sidebar-host');
  const sidebarActuallyVisible = sidebarHost && sidebarHost.classList.contains('visible');

  const shouldShow = !sidebar.isVisible || !sidebarActuallyVisible;
  button.style.display = shouldShow ? 'flex' : 'none';
  button.style.visibility = shouldShow ? 'visible' : 'hidden';

  if (isVerbose()) {
    logger.info('Button visibility updated:', 'button-manager', {
      shouldShow,
      sidebarIsVisible: sidebar.isVisible,
      sidebarActuallyVisible,
      buttonDisplay: button.style.display
    });
  }
}

export function showLoading(assistant, isLoading) {
  assistant.isAnalyzing = isLoading;
  const button = assistant?.pandAidButton;
  if (!button) return;
  const spinner = button.querySelector('.sf-loading-spinner') || document.createElement('div');
  if (isLoading) {
    spinner.className = 'sf-loading-spinner';
    button.appendChild(spinner);
    button.disabled = true;
    if (!assistant.sidebar.isVisible) {
      assistant.sidebar.updateContent({ solution: '', sources: [] });
      assistant.sidebar.toggle(true);
      setTimeout(() => updateButtonVisibility(assistant), 100);
    }
  } else {
    spinner.remove();
    button.disabled = false;
  }
}

export function showExtensionInvalidState(assistant) {
  const button = assistant?.pandAidButton;
  const sidebar = assistant?.sidebar;
  if (!button) return;
  if (sidebar && sidebar.isVisible) {
    button.style.display = 'none';
    button.style.visibility = 'hidden';
    return;
  }

  button.classList.add('sf-invalid-state');
  button.replaceChildren();
  const reloadSpan = document.createElement('span');
  reloadSpan.textContent = 'RELOAD';
  const refreshSpan = document.createElement('span');
  refreshSpan.textContent = 'Refresh Page';
  button.append(reloadSpan, refreshSpan);
  button.title = 'Extension was reloaded. Click to refresh the page.';
  button.style.display = 'flex';
  button.style.visibility = 'visible';
  button.onclick = () => window.location.reload();
}
