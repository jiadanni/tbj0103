/**
 * User Notification Utility
 * Provides user-visible error messages and notifications
 */

import { createLogger } from './logger.js';

const logger = createLogger('UserNotifications');

/**
 * Notification types
 */
export const NotificationType = {
  ERROR: 'error',
  WARNING: 'warning',
  INFO: 'info',
  SUCCESS: 'success'
};

/**
 * Notification severity levels
 */
export const NotificationSeverity = {
  CRITICAL: 'critical',  // System-breaking errors
  HIGH: 'high',          // Feature-breaking errors
  MEDIUM: 'medium',      // Degraded functionality
  LOW: 'low'             // Minor issues
};

/**
 * Shows a notification to the user
 * @param {string} message - User-friendly message
 * @param {Object} options - Notification options
 * @param {string} options.type - Notification type (error, warning, info, success)
 * @param {string} options.severity - Severity level
 * @param {string} options.title - Optional title
 * @param {number} options.duration - Duration in ms (0 for persistent)
 * @param {boolean} options.persist - Whether to keep notification visible
 * @param {Object} options.technicalDetails - Technical details for debugging (not shown to user)
 */
export function showNotification(message, options = {}) {
  const {
    type = NotificationType.ERROR,
    severity = NotificationSeverity.MEDIUM,
    title = null,
    duration = 5000,
    persist = false,
    technicalDetails = null
  } = options;

  const logDetails = technicalDetails ?? null;
  const logFn = type === NotificationType.ERROR
    ? logger.error
    : (type === NotificationType.WARNING ? logger.warn : logger.info);
  logFn(`[${type.toUpperCase()}] ${message}`, 'user-notifications', logDetails);

  // Send message to content script/popup
  const notificationData = {
    type: 'user_notification',
    notification: {
      message,
      type,
      severity,
      title: title || getDefaultTitle(type),
      timestamp: Date.now(),
      duration: persist ? 0 : duration
    }
  };

  // Try to send to active tab
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, notificationData).catch(err => {
          // Tab might not have content script, fallback to runtime message
          chrome.runtime.sendMessage(notificationData).catch(() => {
            // If both fail, at least we logged to console
          });
        });
      }
    });
  } catch (error) {
    // Extension context might not support tabs API
    try {
      chrome.runtime.sendMessage(notificationData).catch(() => { });
    } catch (e) {
      // Last resort - already logged to console via logFn call above
      logger.debug('Final fallback for notification sending failed:', 'user-notifications', e);
    }
  }

  // Return notification object for testing
  return notificationData.notification;
}

/**
 * Gets default title based on notification type
 */
function getDefaultTitle(type) {
  const titles = {
    [NotificationType.ERROR]: 'Error',
    [NotificationType.WARNING]: 'Warning',
    [NotificationType.INFO]: 'Information',
    [NotificationType.SUCCESS]: 'Success'
  };
  return titles[type] || 'Notification';
}

/**
 * Shows an error notification with user-friendly message
 * @param {string} userMessage - User-friendly error message
 * @param {Error|Object} error - Error object or technical details
 * @param {Object} options - Additional options
 */
export function showError(userMessage, error = null, options = {}) {
  const severity = options.severity || NotificationSeverity.HIGH;

  const technicalDetails = error ? {
    message: error.message || error,
    stack: error.stack,
    name: error.name,
    ...(error.status && { status: error.status }),
    ...(error.endpoint && { endpoint: error.endpoint })
  } : null;

  return showNotification(userMessage, {
    type: NotificationType.ERROR,
    severity,
    persist: severity === NotificationSeverity.CRITICAL,
    technicalDetails,
    ...options
  });
}

/**
 * Shows a warning notification
 */
export function showWarning(message, options = {}) {
  return showNotification(message, {
    type: NotificationType.WARNING,
    severity: NotificationSeverity.MEDIUM,
    ...options
  });
}

/**
 * Shows an info notification
 */
export function showInfo(message, options = {}) {
  return showNotification(message, {
    type: NotificationType.INFO,
    severity: NotificationSeverity.LOW,
    ...options
  });
}

/**
 * Shows a success notification
 */
export function showSuccess(message, options = {}) {
  return showNotification(message, {
    type: NotificationType.SUCCESS,
    severity: NotificationSeverity.LOW,
    duration: 3000,
    ...options
  });
}

/**
 * Error message templates for common scenarios
 */
export const ErrorMessages = {
  // API Errors
  API_UNAVAILABLE: 'Unable to connect to the service. Please check your internet connection and try again.',
  API_TIMEOUT: 'The request took too long to complete. Please try again.',
  API_RATE_LIMIT: 'Too many requests. Please wait a moment and try again.',
  API_AUTH_FAILED: 'Authentication failed. Please check your credentials in settings.',
  API_SERVER_ERROR: 'The service is temporarily unavailable. Please try again later.',

  // AI Service Errors
  AI_GENERATION_FAILED: 'Failed to generate AI response. Please try again.',
  AI_INVALID_RESPONSE: 'Received an invalid response from AI service.',
  AI_QUOTA_EXCEEDED: 'AI service quota exceeded. Please try again later.',

  // Atlassian Errors
  JIRA_CONNECTION_FAILED: 'Failed to connect to Jira. Please check your Atlassian settings.',
  JIRA_SEARCH_FAILED: 'Failed to search Jira tickets. Please try again.',
  CONFLUENCE_CONNECTION_FAILED: 'Failed to connect to Confluence. Please check your Atlassian settings.',
  CONFLUENCE_SEARCH_FAILED: 'Failed to search Confluence pages. Please try again.',

  // Local Service Errors
  LOCAL_DB_UNAVAILABLE: 'Local database service is not running. Please start the service.',
  LOCAL_DB_SEARCH_FAILED: 'Failed to search local database.',

  // Data Errors
  INVALID_DATA: 'The data provided is invalid or incomplete.',
  PARSING_FAILED: 'Failed to process the response. Please try again.',

  // Generic Errors
  UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.',
  OPERATION_CANCELLED: 'Operation was cancelled.',
  PERMISSION_DENIED: 'Permission denied. Please check your settings.'
};

/**
 * Creates a user-friendly error message from an error object
 * @param {Error} error - Error object
 * @param {string} context - Context of the error (e.g., 'AI Service', 'Jira Search')
 * @returns {string} User-friendly message
 */
export function getUserFriendlyErrorMessage(error, context = '') {
  // Check for abort/cancellation
  if (error.name === 'AbortError') {
    return ErrorMessages.OPERATION_CANCELLED;
  }

  // Check for timeout
  if (error.message?.includes('timeout') || error.message?.includes('timed out')) {
    return ErrorMessages.API_TIMEOUT;
  }

  // Check for network errors
  if (error.message?.includes('fetch') || error.message?.includes('network')) {
    return ErrorMessages.API_UNAVAILABLE;
  }

  // Check HTTP status codes
  if (error.status) {
    switch (error.status) {
      case 401:
      case 403:
        return ErrorMessages.API_AUTH_FAILED;
      case 429:
        return ErrorMessages.API_RATE_LIMIT;
      case 500:
      case 502:
      case 503:
      case 504:
        return ErrorMessages.API_SERVER_ERROR;
      default:
        break;
    }
  }

  // Context-specific messages
  const contextLower = context.toLowerCase();
  if (contextLower.includes('jira')) {
    return ErrorMessages.JIRA_SEARCH_FAILED;
  }
  if (contextLower.includes('confluence')) {
    return ErrorMessages.CONFLUENCE_SEARCH_FAILED;
  }
  if (contextLower.includes('ai')) {
    return ErrorMessages.AI_GENERATION_FAILED;
  }
  if (contextLower.includes('local') || contextLower.includes('vector')) {
    return ErrorMessages.LOCAL_DB_SEARCH_FAILED;
  }

  // Generic fallback
  return context
    ? `${context}: ${ErrorMessages.UNKNOWN_ERROR}`
    : ErrorMessages.UNKNOWN_ERROR;
}

/**
 * Wraps an async function with error handling and user notifications
 * @param {Function} fn - Async function to wrap
 * @param {string} context - Context for error messages
 * @param {Object} options - Options for error handling
 * @returns {Function} Wrapped function
 */
export function withErrorNotification(fn, context, options = {}) {
  return async function (...args) {
    try {
      return await fn(...args);
    } catch (error) {
      const userMessage = options.customMessage ||
        getUserFriendlyErrorMessage(error, context);

      showError(userMessage, error, {
        severity: options.severity || NotificationSeverity.HIGH,
        title: options.title
      });

      // Re-throw if specified
      if (options.rethrow) {
        throw error;
      }

      return options.fallback || null;
    }
  };
}
