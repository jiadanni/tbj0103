import { sendMessageWithTimeout } from './messaging.js';
import { showStatus as defaultShowStatus } from './ui-helpers.js';

export function setupDataManagement({
    elements: {
        clearCacheButton,
        clearAllDataButton,
        // Fields to reset on Clear All
        aiServiceTokenInput,
        atlassianTokenInput,
        atlassianBaseUrlInput,
        atlassianEmailInput
    },
    helpers: {
        showStatus = defaultShowStatus,
        logger
    }
}) {
    if (clearCacheButton) {
        clearCacheButton.addEventListener('click', () => handleClearCache(clearCacheButton, showStatus, logger));
    }

    if (clearAllDataButton) {
        clearAllDataButton.addEventListener('click', () => handleClearAllData({
            button: clearAllDataButton,
            showStatus,
            logger,
            fields: {
                aiServiceTokenInput,
                atlassianTokenInput,
                atlassianBaseUrlInput,
                atlassianEmailInput
            }
        }));
    }
}

const removeLocalKeys = (keys) => new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
        const storageErr = chrome.runtime.lastError;
        if (storageErr) {
            reject(storageErr);
        } else {
            resolve();
        }
    });
});

async function handleClearCache(button, showStatus, logger) {
    // Confirmation step
    const confirmed = window.confirm('Are you sure you want to clear the extension cache? This will remove persisted search caches and request the background to clear in-memory caches. This action cannot be undone.');
    if (!confirmed) return;

    const keysToRemove = [
        'extensionResponseCache',
        'searchCache',
        'lastSearchResults',
        'localSearchCache'
    ];

    // Update UI immediately
    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = 'Clearing...';

    try {
        await removeLocalKeys(keysToRemove);
        showStatus('Cache cleared successfully', 'success');
    } catch (storageErr) {
        logger?.error('Error clearing storage keys:', 'data-management', storageErr);
        showStatus(`Failed to clear cache: ${storageErr.message || storageErr}`, 'error');
    }

    // Tell background to clear any in-memory caches
    try {
        const resp = await sendMessageWithTimeout({ action: 'clearCache' }, 5000);
        logger?.info('Background clearCache response:', 'data-management', resp);
    } catch (err) {
        logger?.warn('Background did not acknowledge clearCache (or timed out):', 'data-management', err && err.message ? err.message : err);
    } finally {
        button.disabled = false;
        button.textContent = originalText;
    }
}

async function handleClearAllData({
    button,
    showStatus,
    logger,
    fields
}) {
    // Double confirmation for destructive action
    const firstConfirm = window.confirm(
        'WARNING: This will permanently delete ALL extension data including:\n\n' +
        '• AI API keys\n' +
        '• Atlassian credentials\n' +
        '• Knowledge base entries\n' +
        '• All cached data\n' +
        '• All settings and preferences\n\n' +
        'You will need to reconfigure the extension from scratch.\n\n' +
        'Are you sure you want to continue?'
    );
    if (!firstConfirm) return;

    const secondConfirm = window.confirm(
        'FINAL CONFIRMATION\n\n' +
        'Type "yes" in your mind and click OK to permanently delete all data.\n' +
        'Click Cancel to abort.'
    );
    if (!secondConfirm) return;

    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = 'Clearing...';

    try {
        // Clear all chrome.storage.local data
        await new Promise((resolve, reject) => {
            chrome.storage.local.clear(() => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        });

        // Tell background to clear in-memory caches
        try {
            await sendMessageWithTimeout({ action: 'clearCache' }, 5000);
        } catch (err) {
            logger?.warn('Background clearCache notification failed:', 'data-management', err);
        }

        showStatus('All data cleared successfully. Please reconfigure the extension.', 'success');

        // Reset form fields to empty state
        if (fields.aiServiceTokenInput) {
            fields.aiServiceTokenInput.value = '';
            fields.aiServiceTokenInput.removeAttribute('data-is-saved');
        }
        if (fields.atlassianTokenInput) {
            fields.atlassianTokenInput.value = '';
            fields.atlassianTokenInput.removeAttribute('data-is-saved');
        }
        if (fields.atlassianBaseUrlInput) fields.atlassianBaseUrlInput.value = '';
        if (fields.atlassianEmailInput) fields.atlassianEmailInput.value = '';

        // Reload the page to reset all UI state
        setTimeout(() => {
            window.location.reload();
        }, 1500);

    } catch (error) {
        logger?.error('Error clearing all data:', 'data-management', error);
        showStatus(`Failed to clear data: ${error.message || error}`, 'error');
        button.disabled = false;
        button.textContent = originalText;
    }
}
