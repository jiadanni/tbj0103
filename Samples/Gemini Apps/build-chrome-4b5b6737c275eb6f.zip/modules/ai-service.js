/**
 * AI Service Module
 * Handles AI-powered features for Salesforce cases (Solution synthesis, improvement, spellcheck).
 * 
 * @module api/ai-service
 */

import { generateEmailSignature } from '../utils/email-helpers.js';
import { showInfo } from '../utils/user-notifications.js';
import { buildSolutionPrompt, buildImprovementPrompt, buildSpellCheckPrompt } from './prompts/prompt-templates.js';
import { getAiParameters, buildPromptMutation, buildMutationVariables } from './prompts/prompt-builders.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';

// Import core AI client functionality
import {
  makeApiRequest,
  getActiveAiModel,
  testConnection,
  hasValidAiServiceToken
} from './ai-client.js';

const logger = createLogger('AiService');

// Re-export core connectivity functions for backwards compatibility
export { testConnection, hasValidAiServiceToken, getActiveAiModel, makeApiRequest };

/**
 * Suggest a solution based on case data and context.
 * Analyzes case details and provided context (like search results) to synthesize a resolution.
 * 
 * @param {Object} [caseData={}] - Salesforce case information
 * @param {string} [context=""] - Additional context (e.g., related Jira/Confluence results)
 * @returns {Promise<Result>} Standardized Result object containing the suggested solution text on success
 */
export async function suggestSolution(caseData = {}, context = "") {
  if (!caseData || Object.keys(caseData).length === 0) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs[0];
      if (activeTab && activeTab.id) {
        const response = await chrome.tabs.sendMessage(activeTab.id, { action: 'extractCaseData' });
        if (response?.success && response.data) {
          caseData = response.data || {};
        }
      }
    } catch (e) {
      logger.warn('suggestSolution: extraction fallback failed', 'ai-service', e);
      try {
        showInfo('AI could not extract case details automatically; using default prompt. Results may be less specific.');
      } catch (notifyErr) {
        logger.warn('Failed to notify user about extraction failure', 'ai-service', notifyErr);
      }
    }
  }

  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('caseSummary', advancedAiSettings);

  const prompt = buildSolutionPrompt(caseData, context);

  const mutation = buildPromptMutation('SuggestSolution', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;
    return Result.success(response.value.data.answerPrompt);
  } catch (error) {
    logger.error('Error in suggestSolution:', 'ai-service', error);
    return Result.failure(error);
  }
}

/**
 * Improve an existing solution with AI.
 * Enhances clarity, tone, and technical accuracy while maintaining the core message.
 * 
 * @param {string} currentSolution - Current solution text to improve
 * @param {Object} [caseData={}] - Case information for signature and context
 * @returns {Promise<Result>} Standardized Result object containing the improved solution and signature on success
 */
export async function improveSolution(currentSolution, caseData = {}) {
  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('improvement', advancedAiSettings);

  const prompt = buildImprovementPrompt(currentSolution, caseData);

  const mutation = buildPromptMutation('ImproveSolution', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;

    const improvedText = response.value.data.answerPrompt;

    const signature = generateEmailSignature(caseData);
    return Result.success(improvedText + signature);
  } catch (error) {
    logger.error('Error in improveSolution:', 'ai-service', error);
    return Result.failure(error);
  }
}

/**
 * Spellcheck and grammar check text using AI.
 * Focuses on professional support communication standards.
 * 
 * @param {string} text - Text to check and correct
 * @param {Object} [caseData={}] - Case information for signature and domain context
 * @returns {Promise<Result>} Standardized Result object containing the corrected text and signature on success
 */
export async function spellcheckText(text, caseData = {}) {
  const prompt = buildSpellCheckPrompt(text, caseData);

  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('spellcheck', advancedAiSettings);

  const mutation = buildPromptMutation('SpellcheckText', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;

    const correctedText = response.value.data.answerPrompt;

    const signature = generateEmailSignature(caseData);
    return Result.success(correctedText + signature);
  } catch (error) {
    logger.error('Error in spellcheckText:', 'ai-service', error);
    return Result.failure(error);
  }
}
