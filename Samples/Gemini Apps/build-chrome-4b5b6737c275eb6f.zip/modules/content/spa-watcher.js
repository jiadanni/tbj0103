// modules/content/spa-watcher.js
//
// Watch SPA navigation to restore the PandAid UI.

import { assistantInstance } from './assistant.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('SpaWatcher');

export function setupSPAWatcher() {
  try {
    const dispatchLocationChange = () => window.dispatchEvent(new Event('locationchange'));
    const _push = history.pushState;
    const _replace = history.replaceState;
    history.pushState = function () {
      const ret = _push.apply(this, arguments);
      window._pandaid_last_location_change = Date.now();
      dispatchLocationChange();
      return ret;
    };
    history.replaceState = function () {
      const ret = _replace.apply(this, arguments);
      window._pandaid_last_location_change = Date.now();
      dispatchLocationChange();
      return ret;
    };
    window.addEventListener('popstate', dispatchLocationChange);

    let debounceTimer = null;
    window.addEventListener('locationchange', () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        debounceTimer = null;
        try {
          if (!assistantInstance) return;
          assistantInstance.createpandAidButton();
          assistantInstance.adjustButtonPosition();
          assistantInstance.updateButtonVisibility();
          if (assistantInstance.sidebar && assistantInstance.sidebar.sidebar && assistantInstance.sidebar.isVisible) {
            if (!document.body.contains(assistantInstance.sidebar.sidebar)) {
              document.body.appendChild(assistantInstance.sidebar.sidebar);
            }
            assistantInstance.sidebar.sidebar.style.display = 'flex';
            assistantInstance.sidebar.sidebar.classList.add('visible');
            assistantInstance.sidebar.isVisible = true;
            try { assistantInstance.sidebar.loadCaseDetailsEnhanced(); } catch (e) { logger.warn('Ignored error in loadCaseDetailsEnhanced', 'spa-watcher', e); }
            try { assistantInstance.sidebar.notifyButtonVisibilityChange(); } catch (e) { logger.warn('Ignored error in notifyButtonVisibilityChange', 'spa-watcher', e); }
          }
        } catch (e) {
          logger.error('PandAid locationchange handler error:', 'spa-watcher', e);
        }
      }, 500);
    });
  } catch (e) {
    logger.error('Failed to setup SPA navigation watcher', 'spa-watcher', e);
  }
}
