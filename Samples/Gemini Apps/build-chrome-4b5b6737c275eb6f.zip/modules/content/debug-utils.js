// modules/content/debug-utils.js
//
// Debug helpers and verbose logging flag management.

import { createLogger } from '../utils/logger.js';

const logger = createLogger('ContentDebug');

export let VERBOSE_LOGGING = false;

export function isVerbose() {
  return !!VERBOSE_LOGGING;
}

export function setVerboseLogging(value) {
  VERBOSE_LOGGING = !!value;
}

export function loadVerbosePreference() {
  try {
    chrome.storage.local.get(['verboseLogging'], (res) => {
      if (res && typeof res.verboseLogging === 'boolean') {
        VERBOSE_LOGGING = res.verboseLogging;
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.verboseLogging) {
        VERBOSE_LOGGING = changes.verboseLogging.newValue;
        logger.info(`[PandAid ContentScript] Verbose logging ${VERBOSE_LOGGING ? 'enabled' : 'disabled'}`, 'debug-utils', undefined);
      }
    });
  } catch (error) {
    logger.warn('[PandAid] Error loading verbose preference', 'debug-utils', error);
  }
}

export function logIgnoredError(context, error) {
  if (!isVerbose()) return;
  logger.warn(`[PandAid] Ignored error in ${context}:`, 'debug-utils', error);
}

export function setupDebugAPI() {
  loadVerbosePreference();
  setupFrameDebugHelpers();
}

function setupFrameDebugHelpers() {
  // Lightweight early debug helper
  try {
    if (typeof window.getPandaAidDebugInfo !== 'function') {
      window.getPandaAidDebugInfo = function () {
        try {
          return {
            presentInThisFrame: !!(window.SalesforceSidebar || window.assistantInstance || window.pandaIdInitialized),
            isTopWindow: window.top === window,
            frameElementClass: window.frameElement ? window.frameElement.className : null,
            frameElementTitle: window.frameElement ? window.frameElement.title : null,
            url: window.location.href,
            timestamp: Date.now()
          };
        } catch (e) {
          logger.warn('getPandaAidDebugInfo error', 'debug-utils', e);
          return { error: String(e) };
        }
      };
    }
  } catch (e) {
    logger.warn('setupFrameDebugHelpers partial error 1', 'debug-utils', e);
  }

  // Non-colliding debug API
  try {
    if (typeof window.__pandaid_debug !== 'object') {
      const computeInfo = function () {
        try {
          return {
            presentInThisFrame: !!(window.SalesforceSidebar || window.assistantInstance || window.pandaIdInitialized),
            isTopWindow: window.top === window,
            frameElementClass: window.frameElement ? window.frameElement.className : null,
            frameElementTitle: window.frameElement ? window.frameElement.title : null,
            url: window.location.href,
            timestamp: Date.now()
          };
        } catch (e) {
          logger.warn('computeInfo error', 'debug-utils', e);
          return { error: String(e) };
        }
      };

      const api = {
        info: function () { return computeInfo(); },
        mark: function (timeoutMs) { try { return (window._pandaid_markFrame || function () { return false; })(timeoutMs); } catch (e) { logger.warn('__pandaid_debug.mark error', 'debug-utils', e); return false; } },
        createdAt: Date.now()
      };

      try {
        Object.defineProperty(window, '__pandaid_debug', {
          value: api,
          writable: false,
          configurable: false,
          enumerable: false
        });
        try { logger.debug('[PandAid] __pandaid_debug initialized:', 'debug-utils', window.__pandaid_debug.info()); } catch (e) { logger.warn('__pandaid_debug init log error', 'debug-utils', e); }
      } catch (e) {
        logger.warn('setupFrameDebugHelpers partial error 1', 'debug-utils', e);
        window.__pandaid_debug = api;
      }
    }
  } catch (e) {
    logger.warn('setupFrameDebugHelpers partial error 2', 'debug-utils', e);
  }

  // Visual frame marker
  try {
    window._pandaid_markFrame = function (timeoutMs = 5000) {
      try {
        const id = 'pandaid-frame-marker';
        const prev = document.getElementById(id);
        if (prev && prev.parentNode) prev.parentNode.removeChild(prev);

        const div = document.createElement('div');
        div.id = id;
        div.style.position = 'fixed';
        div.style.zIndex = 2147483647;
        div.style.right = '8px';
        div.style.bottom = '8px';
        div.style.background = 'rgba(0,0,0,0.72)';
        div.style.color = 'white';
        div.style.padding = '6px 8px';
        div.style.borderRadius = '6px';
        div.style.fontSize = '12px';
        div.style.fontFamily = 'Arial, sans-serif';
        div.style.boxShadow = '0 2px 8px rgba(0,0,0,0.4)';
        div.style.pointerEvents = 'none';

        const info = window.getPandaAidDebugInfo ? window.getPandaAidDebugInfo() : { presentInThisFrame: false };
        const lines = [];
        lines.push(info.isTopWindow ? 'Top frame' : 'Iframe');
        if (info.frameElementClass) lines.push(`frame.class=${info.frameElementClass}`);
        if (info.frameElementTitle) lines.push(`frame.title=${info.frameElementTitle}`);
        lines.push((info.url || '').replace(/^https?:\/\//, '').slice(0, 80));

        div.textContent = lines.join(' • ');
        document.body.appendChild(div);

        setTimeout(() => {
          try { div.style.transition = 'opacity 300ms'; div.style.opacity = '0'; } catch (e) { logger.warn('markFrame fade error', 'debug-utils', e); }
        }, Math.max(2000, timeoutMs - 400));

        setTimeout(() => {
          try { if (div && div.parentNode) div.parentNode.removeChild(div); } catch (e) { logger.warn('markFrame remove error', 'debug-utils', e); }
        }, timeoutMs);

        return true;
      } catch (e) {
        logger.warn('markFrame error', 'debug-utils', e);
        return false;
      }
    };
  } catch (e) {
    logger.warn('setupFrameDebugHelpers partial error 3', 'debug-utils', e);
  }
}

export function showToastNotification(message, type = 'info', duration = 5000) {
  const toast = document.createElement('div');
  toast.className = `pandaid-toast pandaid-toast-${type}`;

  const colors = {
    error: '#f44336',
    success: '#4caf50',
    info: '#2196f3',
    warning: '#ff9800'
  };

  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${colors[type] || colors.info};
    color: white;
    padding: 16px 24px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    max-width: 400px;
    animation: slideIn 0.3s ease-out;
  `;

  toast.textContent = message;
  document.body.appendChild(toast);

  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(400px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);

  setTimeout(() => {
    toast.style.transition = 'opacity 0.3s ease-out';
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}
