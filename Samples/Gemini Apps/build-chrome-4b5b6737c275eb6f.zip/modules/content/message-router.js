// modules/content/message-router.js
//
// Message handling between frames and background.

import { ensureAssistantInstance, assistantInstance as sharedAssistant, setAssistantInstance } from './assistant.js';
import { extractCaseDataFromDom } from './case-extractor.js';
import { isVerbose } from './debug-utils.js';
import { showToastNotification } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';
import { getFrameOrigin, getMessageNonce, isTrustedOrigin } from '../utils/message-auth.js';

const logger = createLogger('MessageRouter');

const MESSAGE_TOGGLE_DEBOUNCE_MS = 500;
let lastMessageToggleAt = 0;

function resolveFallbackOrigin() {
  try {
    if (window.top?.location?.origin && window.top.location.origin !== 'null') {
      return window.top.location.origin;
    }
  } catch (e) {
    logger.debug('Top frame access check failed', 'message-router', e);
  }

  if (document.referrer) {
    try {
      const refOrigin = new URL(document.referrer).origin;
      if (refOrigin && refOrigin !== 'null') return refOrigin;
    } catch (e) {
      logger.debug('Referrer origin check failed', 'message-router', e);
    }
  }

  const origin = window.location?.origin;
  return origin && origin !== 'null' ? origin : null;
}

export function setupMessageHandlers() {
  setupIframeMessageListener();
  setupRuntimeMessageListener();
}

function setupIframeMessageListener() {
  window.addEventListener('message', (event) => {
    void handleIframeMessage(event);
  });
}

async function handleIframeMessage(event) {
  let data;
  try {
    data = event.data;
    if (!data || typeof data !== 'object') {
      return;
    }
  } catch (e) {
    logger.warn('iframeMessageListener:parse error', 'message-router', e);
    return;
  }

  // Only log messages with a recognized action to reduce noise
  const recognizedActions = ['requestEmailContent', 'emailContentResponse', 'openPandAidTray'];
  if (isVerbose() && data.action && recognizedActions.includes(data.action)) {
    logger.info('[ContentScript] message event received:', 'message-router', data.action, event.origin);
  }

  const fallbackOrigin = resolveFallbackOrigin();
  if (!isTrustedOrigin(event.origin, fallbackOrigin)) {
    if (isVerbose()) {
      logger.warn('[ContentScript] Ignoring message from untrusted origin:', 'message-router', event.origin);
    }
    return;
  }

  const expectedNonce = await getMessageNonce();
  if (!data.nonce || data.nonce !== expectedNonce) {
    return;
  }

  // Handle email content request (runs in all frames, including CKEditor iframes)
  if (data.action === 'requestEmailContent' && data.requestId) {
    handleEmailContentRequest(event);
    return;
  }

  if (data.source === 'emailFrame' && data.action === 'openPandAidTray') {
    if (isVerbose()) logger.info('Email frame message received:', 'message-router', data.action);
    ensureAssistant(() => {
      const now = Date.now();
      if (now - lastMessageToggleAt < MESSAGE_TOGGLE_DEBOUNCE_MS) {
        if (isVerbose()) logger.info('Message toggle ignored due to debounce', 'message-router', undefined);
        return;
      }
      lastMessageToggleAt = now;
      try { window._pandaid_last_message_toggle = now; } catch (e) { logger.warn('iframeMessageListener:markToggle error', 'message-router', e); }


      if (sharedAssistant.sidebar && !sharedAssistant.sidebar.isVisible) {
        sharedAssistant.sidebar.toggle(true);
      }
      if (data.text) {
        setTimeout(() => {
          sharedAssistant.addTextToActiveTextBox(data.text);
        }, 600);
      }
    });
  }
}

/**
 * Handle email content request from parent/sidebar.
 * This runs in all frames and responds with editable content if available.
 */
function handleEmailContentRequest(event) {
  const data = event.data || {};
  const requestId = data.requestId;
  const nonce = data.nonce;
  const fallbackOrigin = resolveFallbackOrigin();
  const targetOrigin = event.origin && event.origin !== 'null' ? event.origin : fallbackOrigin;

  logger.debug(`[EmailContentRequest] Received in frame: ${window.location.href.substring(0, 80)}`, 'message-router');

  if (!targetOrigin) {
    logger.debug('[EmailContentRequest] No target origin, skipping', 'message-router');
    return;
  }

  // Check if this frame has editable content (CKEditor body, contenteditable, textarea)
  const isEditableFrame = document.body?.isContentEditable ||
    document.body?.classList?.contains('cke_editable') ||
    document.body?.getAttribute('aria-label')?.toLowerCase().includes('email');

  logger.debug(`[EmailContentRequest] isEditableFrame=${isEditableFrame}, body classes: ${document.body?.className}`, 'message-router');

  let textToSend = null;

  // Priority 1: Check if body itself is editable (CKEditor iframe) - this is the most reliable
  if (isEditableFrame) {
    const selectedText = window.getSelection()?.toString()?.trim();
    const bodyText = document.body?.innerText?.trim();
    textToSend = selectedText || bodyText;
    logger.debug('[MessageRouter] Frame is editable, body text length:', 'message-router', textToSend?.length || 0);
  }

  // Priority 2: Look for CKEditor editable body specifically (more specific selector first)
  if (!textToSend) {
    const ckeEditables = document.querySelectorAll(
      'body.cke_editable, ' +
      '.cke_editable[contenteditable="true"], ' +
      '[role="textbox"][aria-multiline="true"][aria-label*="Email" i], ' +
      '[role="textbox"][aria-multiline="true"][aria-label*="Body" i]'
    );
    for (const el of ckeEditables) {
      const text = el.innerText?.trim();
      // Require substantial content (more than just toolbar text)
      if (text && text.length > 20) {
        textToSend = text;
        logger.debug('[MessageRouter] Found CKEditor editable text:', 'message-router', text.substring(0, 50));
        break;
      }
    }
  }

  // Priority 3: Look for other editable elements, but filter out toolbar-like content
  if (!textToSend) {
    const editableElements = document.querySelectorAll(
      '[contenteditable="true"], ' +
      '[role="textbox"][aria-multiline="true"]'
    );
    for (const el of editableElements) {
      // Skip toolbar elements and small containers
      if (el.closest('.cke_toolbar, .cke_top, .toolbar, [role="toolbar"]')) continue;
      // Skip elements that are likely dropdowns or buttons
      if (el.closest('[role="listbox"], [role="menu"], [role="combobox"]')) continue;

      const text = el.innerText?.trim();
      // Require more substantial content to avoid toolbar text like "Font Size Format"
      if (text && text.length > 30 && !text.match(/^(Font|Size|Format|Bold|Italic|Underline|\s)+$/i)) {
        textToSend = text;
        logger.debug('[MessageRouter] Found editable element text:', 'message-router', text.substring(0, 50));
        break;
      }
    }
  }

  // Priority 3: Check visible textareas
  if (!textToSend) {
    const textareas = document.querySelectorAll('textarea:not([readonly])');
    for (const ta of textareas) {
      if (ta.value && ta.value.trim().length > 10) {
        textToSend = ta.value.trim();
        if (isVerbose()) logger.debug('[MessageRouter] Found textarea text:', 'message-router', textToSend.substring(0, 50));
        break;
      }
    }
  }

  // Clean the text - remove original message thread
  if (textToSend) {
    const originalMessageMarkers = [
      '--------------- Original Message ---------------',
      '-----Original Message-----'
    ];
    for (const marker of originalMessageMarkers) {
      const index = textToSend.indexOf(marker);
      if (index !== -1) {
        textToSend = textToSend.substring(0, index).trim();
        break;
      }
    }
  }

  // Send response if we have content
  if (textToSend && textToSend.length > 5) {
    if (isVerbose()) logger.debug('[MessageRouter] Sending email content response:', 'message-router', textToSend.substring(0, 50) + '...');

    // Send to parent frame with specific origin
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        action: 'emailContentResponse',
        requestId: requestId,
        text: textToSend,
        source: 'contentFrame',
        nonce
      }, targetOrigin);
    }

    // Also send to top window in case of deeply nested iframes
    try {
      if (window.top && window.top !== window && window.top !== window.parent) {
        window.top.postMessage({
          action: 'emailContentResponse',
          requestId: requestId,
          text: textToSend,
          source: 'contentFrame',
          nonce
        }, targetOrigin);
      }
    } catch (e) {
      logger.warn('Cross-origin access blocked (top)', 'message-router', e);
    }
  }

  // Forward request to any nested iframes (for VF frames containing CKEditor)
  if (data.broadcast || window !== window.top) {
    const nestedIframes = document.querySelectorAll('iframe');
    for (const iframe of nestedIframes) {
      try {
        if (iframe.contentWindow) {
          const frameOriginRes = getFrameOrigin(iframe, fallbackOrigin);
          const frameOrigin = frameOriginRes.ok ? frameOriginRes.value : null;
          if (!isTrustedOrigin(frameOrigin, fallbackOrigin)) continue;
          const targetOrigin = frameOrigin && frameOrigin !== 'null' ? frameOrigin : fallbackOrigin;
          if (!targetOrigin) continue;
          iframe.contentWindow.postMessage({
            action: 'requestEmailContent',
            requestId: requestId,
            nonce
          }, targetOrigin);
        }
      } catch (e) {
        logger.warn('Cross-origin access blocked (iframe)', 'message-router', e);
      }
    }
  }
}

function setupRuntimeMessageListener() {
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action === 'showNotification') {
      try {
        showToastNotification(request.message, request.type, request.duration);
        sendResponse({ ok: true });
      } catch (error) {
        logger.error('Error showing notification:', 'message-router', error);
        sendResponse({ ok: false, error: error.message });
      }
      return;
    }

    if (request.action === 'ping') {
      sendResponse({ ok: true });
      return;
    }

    if (request.action === 'extractCaseData') {
      if (window.top !== window) {
        sendResponse({ ok: false, error: 'Case data extraction only runs in the top frame.' });
        return;
      }

      (async () => {
        const data = await extractCaseDataFromDom();
        return { ok: true, data };
      })()
        .then((resp) => sendResponse(resp))
        .catch((error) => {
          logger.debug('Error in extractCaseData message handler', 'message-router', error);
          sendResponse({ ok: false, error: error?.message || String(error) });
        });
      return true;
    }

    if (window.top !== window) {
      return;
    }

    const ensureAssistantCallback = (cb) => {
      if (sharedAssistant) {
        cb();
        return;
      }
      window.pandaIdInitialized = true;
      setAssistantInstance(ensureAssistantInstance());
      setTimeout(cb, 400);
    };

    if (request.action === 'addTextAndEnsureSidebar') {
      ensureAssistantCallback(() => {
        try {
          if (!sharedAssistant.sidebar.isVisible) {
            sharedAssistant.sidebar.toggle(true);
          }
          const text = (request.text || '').toString();
          if (text) {
            const original = document.querySelector('#sf-case-assistant-sidebar #original-text-input');
            if (original) {
              const prefix = original.value && !original.value.endsWith('\n') ? '\n' : '';
              original.value = original.value + prefix + text;
              original.focus();
              original.dispatchEvent(new Event('input', { bubbles: true }));
            } else {
              sharedAssistant.addTextToActiveTextBox(text);
            }
          }
          sendResponse({ ok: true });
        } catch (e) {
          logger.warn('Error in addTextAndEnsureSidebar', 'message-router', e);
          sendResponse({ ok: false, error: e.message });
        }
      });
      return true;
    }

    if (request.action === 'importTextToSidebar') {
      ensureAssistantCallback(() => {
        try {
          if (sharedAssistant.sidebar && !sharedAssistant.sidebar.isVisible) {
            sharedAssistant.sidebar.toggle(true);
          }
          const text = (request.text || '').toString();
          const original = document.querySelector('#sf-case-assistant-sidebar #original-text-input');
          if (original) {
            const separator = original.value ? '\n\n' : '';
            original.value = original.value + separator + (text || '');
            original.focus();
            original.dispatchEvent(new Event('input', { bubbles: true }));
          } else if (text) {
            sharedAssistant.addTextToActiveTextBox(text);
          }
          sendResponse({ ok: true });
        } catch (e) {
          logger.warn('Error in importTextToSidebar', 'message-router', e);
          sendResponse({ ok: false, error: e.message });
        }
      });
      return true;
    }
    if (request.action === 'triggerEmailImport') {
      ensureAssistantCallback(() => {
        try {
          if (sharedAssistant && sharedAssistant.sidebar) {
            // Force sidebar open if needed and show loading
            if (!sharedAssistant.sidebar.isVisible) {
              sharedAssistant.sidebar.toggle(true);
            }

            // Wait briefly for the sidebar DOM to be fully rendered if it was just opened
            setTimeout(() => {
              if (sharedAssistant.sidebar) {
                sharedAssistant.sidebar.handleImportText()
                  .then((result) => {
                    if (result && !result.ok) {
                      sendResponse({ ok: false, error: result.error.message });
                    } else {
                      sendResponse({ ok: true });
                    }
                  })
                  .catch(err => {
                    logger.debug('Error in handleImportText via triggerEmailImport', 'message-router', err);
                    sendResponse({ ok: false, error: err.message });
                  });
              }
            }, 500);
          } else {
            sendResponse({ ok: false, error: 'Sidebar not available' });
          }
        } catch (e) {
          logger.warn('Error in triggerEmailImport', 'message-router', e);
          sendResponse({ ok: false, error: e.message });
        }
      });
      return true;
    }
  });
}

function ensureAssistant(cb) {
  if (sharedAssistant) {
    cb();
    return;
  }
  if (!window.pandaIdInitialized) {
    window.pandaIdInitialized = true;
    setAssistantInstance(ensureAssistantInstance());
    setTimeout(cb, 500);
  }
}
