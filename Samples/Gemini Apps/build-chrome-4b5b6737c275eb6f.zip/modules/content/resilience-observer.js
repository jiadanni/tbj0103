// modules/content/resilience-observer.js
//
// Observers to keep the sidebar alive across DOM changes and case transitions.

import { assistantInstance } from './assistant.js';
import { isVerbose } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('ResilienceObserver');

export function setupResilienceObservers() {
  setupSidebarResilienceObserver();
  setupCaseChangeWatcher();
  setupUnloadCleanup();
}

function setupSidebarResilienceObserver() {
  try {
    if (window._pandaid_sidebar_observer_installed) return;
    const obs = new MutationObserver(() => {
      try {
        if (!assistantInstance || !assistantInstance.sidebar) return;

        // With shadow DOM, check the host element instead
        const sidebarHost = document.getElementById('sf-pandaid-sidebar-host');

        if (assistantInstance.sidebar && assistantInstance.sidebar.isVisible) {
          try {
            // If host doesn't exist, try to recreate the sidebar
            if (!sidebarHost) {
              if (isVerbose()) logger.info('[ContentScript] Sidebar host missing; attempting to create via createSidebar()', 'resilience-observer', undefined);
              try {
                assistantInstance.createSidebar();
              } catch (e) {
                logger.warn('assistantInstance.createSidebar error', 'resilience-observer', e);
              }
              return;
            }

            // Check if host is in DOM and has visible class
            const inDom = document.body.contains(sidebarHost);
            const hasVisibleClass = sidebarHost.classList.contains('visible');
            const displayed = sidebarHost.style.display !== 'none';

            if (!inDom || !hasVisibleClass || !displayed) {
              if (isVerbose()) logger.info('[ContentScript] Restoring sidebar because host was removed/hidden while marked visible', 'resilience-observer', undefined);
              try {
                if (!inDom) {
                  document.body.appendChild(sidebarHost);
                }
                sidebarHost.style.display = 'flex';
                sidebarHost.classList.add('visible');
                assistantInstance.sidebar.isVisible = true;
                try { assistantInstance.sidebar.loadCaseDetailsEnhanced(); } catch (e) { logger.warn('sidebar.loadCaseDetailsEnhanced error', 'resilience-observer', e); }
                window._pandaid_last_restore = { time: Date.now(), reason: 'removed-or-hidden' };
              } catch (e) {
                logger.error('Failed to restore sidebar:', 'resilience-observer', e);
              }
            }
          } catch (e) {
            logger.warn('resilienceObserver:iteration error', 'resilience-observer', e);
          }
        }
      } catch (e) {
        logger.warn('resilienceObserver:callback error', 'resilience-observer', e);
      }
    });
    obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
    window._pandaid_sidebar_observer_installed = true;
    window._pandaid_sidebar_observer = obs;
  } catch (e) {
    logger.warn('Failed to install sidebar resilience observer:', 'resilience-observer', e);
  }
}

function setupCaseChangeWatcher() {
  try {
    if (window._pandaid_case_watcher_installed) return;
    window._pandaid_case_watcher_installed = true;
    const POLL_MS = 800;
    let lastSignature = null;
    window.addEventListener('sidebarToggle', (e) => {
      try {
        if (e && e.detail && e.detail.isVisible === false) {
          lastSignature = null;
        }
      } catch (err) { logger.warn('caseChangeWatcher:sidebarToggle error', 'resilience-observer', err); }
    });

    setInterval(() => {
      try {
        if (!assistantInstance || !assistantInstance.sidebar) return;
        if (!assistantInstance.sidebar.isVisible) return;
        const sidebarObj = assistantInstance.sidebar;
        if (!sidebarObj.getCaseDataFromPage) return;
        let caseData;
        try {
          caseData = sidebarObj.getCaseDataFromPage();
        } catch (e) {
          logger.warn('caseChangeWatcher:getCaseDataFromPage error', 'resilience-observer', e);
          return;
        }

        const sigParts = [
          caseData?.caseId || caseData?.caseNumber || '',
          caseData?.subject || '',
          caseData?.productFamily || '',
          caseData?.productComponent || ''
        ];
        const sig = sigParts.join('||');
        if (lastSignature === null) {
          lastSignature = sig;
        } else if (sig !== lastSignature) {
          lastSignature = sig;
          if (isVerbose()) logger.info('[ContentScript] Detected case change, refreshing sidebar case details', 'resilience-observer', sigParts);
          try {
            if (sidebarObj && typeof sidebarObj.loadCaseDetailsEnhanced === 'function') {
              sidebarObj.loadCaseDetailsEnhanced();
            }
          } catch (e) {
            logger.warn('Error refreshing case details after detected change:', 'resilience-observer', e);
          }
        }
      } catch (e) {
        logger.warn('Polling error in caseChangeWatcher', 'resilience-observer', e);
      }
    }, POLL_MS);
  } catch (e) {
    logger.warn('Failed to install case change watcher:', 'resilience-observer', e);
  }
}

function setupUnloadCleanup() {
  window.addEventListener('beforeunload', () => {
    if (assistantInstance && assistantInstance.sidebar && typeof assistantInstance.sidebar.cleanup === 'function') {
      assistantInstance.sidebar.cleanup();
    }
  });
}
