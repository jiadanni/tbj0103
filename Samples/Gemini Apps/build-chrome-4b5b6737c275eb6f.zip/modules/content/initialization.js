// modules/content/initialization.js
//
// Detect Salesforce UI and bootstrap the assistant.

import { ensureAssistantInstance } from './assistant.js';
import { isVerbose } from './debug-utils.js';
import { createLogger } from '../utils/logger.js';
import { getFrameOrigin, getMessageNonce, isTrustedOrigin } from '../utils/message-auth.js';

const logger = createLogger('Initialization');

function isCaseRecordPage() {
  const path = window.location?.pathname || '';
  if (path.includes('/lightning/r/Case/')) return true;
  return /^\/500[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?/.test(path);
}

function isEmailFrameContext() {
  if (window.parent === window) return false;
  const frameEl = window.frameElement;
  const frameClass = frameEl?.className || '';
  const frameTitle = frameEl?.title || '';
  const frameName = frameEl?.name || '';

  const hasEmailHints = frameClass.includes('cke_wysiwyg_frame') ||
    frameTitle === 'Email Body' ||
    frameTitle === 'CK Editor Container' ||
    frameName.includes('vfFrameId');

  if (hasEmailHints) return true;

  if (window.location?.href?.includes('about:blank')) {
    const ariaLabel = document.body?.getAttribute?.('aria-label') || '';
    return document.body?.isContentEditable ||
      document.body?.classList?.contains('cke_editable') ||
      ariaLabel.toLowerCase().includes('email');
  }

  return false;
}

function resolveFallbackOrigin() {
  if (document.referrer) {
    try {
      const refOrigin = new URL(document.referrer).origin;
      if (refOrigin && refOrigin !== 'null') return refOrigin;
    } catch (e) {
      logger.warn('Referrer check error', 'initialization', e);
    }
  }

  const origin = window.location?.origin;
  return origin && origin !== 'null' ? origin : null;
}

function resolveTrustedOrigin() {
  const fallbackOrigin = resolveFallbackOrigin();
  if (fallbackOrigin && isTrustedOrigin(fallbackOrigin)) {
    return fallbackOrigin;
  }
  return null;
}

function isSalesforceUiPresent() {
  try {
    const selectors = [
      '.oneContent',
      '[data-aura-class="oneContent"]',
      '.slds-template__container',
      '.flexipageBase',
      '.appName.slds-context-bar__primary',
      '[data-aura-class*="forceBreadCrumb"]',
      '#oneHeader'
    ];
    const match = selectors.find(sel => document.querySelector(sel));
    if (match && isVerbose()) logger.info(`PandAid: Salesforce UI detected via selector "${match}"`, 'contextual', undefined);
    return !!match;
  } catch (e) {
    logger.warn('isSalesforceUiPresent error', 'initialization', e);
    return false;
  }
}

export function initializeAssistant(maxAttempts = 20, interval = 1000) {
  let attempts = 0;
  let initInProgress = false;
  let initCompleted = false;
  if (window.parent !== window) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        if (isEmailFrameContext()) {
          void 0; // setupEmailFrameButton removed
        }
      }, { once: true });
    } else if (isEmailFrameContext()) {
      void 0; // setupEmailFrameButton removed
    }
    return;
  }

  function tryInit() {
    if (!isCaseRecordPage()) {
      initInProgress = false;
      return;
    }
    if (isSalesforceUiPresent()) {
      initCompleted = true;
      initInProgress = false;
      logger.info('PandaAid: Salesforce UI detected. Initializing assistant.', 'initialization', undefined);

      const isEmailFrame = window.parent !== window &&
        (window.frameElement &&
          (window.frameElement.className.includes('cke_wysiwyg_frame') ||
            window.frameElement.title === 'Email Body' ||
            window.frameElement.title === 'CK Editor Container' ||
            window.frameElement.name.includes('vfFrameId') ||
            window.location.href.includes('about:blank')));

      if (isEmailFrame) {
        // setupEmailFrameButton(); removed
        return;
      }

      if (window.top === window) {
        const isEmailComposePage = document.querySelector('div[data-aura-class*="email"]') ||
          document.querySelector('.emailComposer') ||
          document.querySelector('[title*="Email"]') ||
          document.querySelector('iframe[title*="Email"]');

        if (!window.pandaIdInitialized) {
          window.pandaIdInitialized = true;
          logger.info('Initializing main PandAid assistant', 'initialization', undefined);
          const instance = ensureAssistantInstance();
          if (isEmailComposePage && instance.pandAidButton) {
            logger.info('Email compose page detected - keeping main PandAid button visible', 'initialization', undefined);
            setTimeout(() => instance.updateButtonVisibility(), 100);
          }
        }
      } else {
        try {
          if (window.top && window.top !== window) {
            if (!window.top.pandaIdInitialized) {
              window.top.pandaIdInitialized = true;
              logger.info('Initializing main PandAid assistant in top window from iframe', 'initialization', undefined);
              window.top.assistantInstance = ensureAssistantInstance();
              setTimeout(() => {
                try {
                  if (window.top.assistantInstance && window.top.assistantInstance.adjustButtonPosition) {
                    window.top.assistantInstance.adjustButtonPosition();
                    window.top.assistantInstance.updateButtonVisibility();
                  }
                } catch (ignore) { logger.warn('Cross-origin top frame access failed', 'initialization', ignore); }
              }, 200);
            }
          }
        } catch (e) {
          logger.warn('PandAid: running inside cross-origin iframe, skipping top init', 'initialization', e);
        }
      }
    } else {
      attempts++;
      if (attempts < maxAttempts) {
        logger.info(`PandaAid: Salesforce UI not ready. Retrying in ${interval}ms... (Attempt ${attempts}/${maxAttempts})`, 'contextual', undefined);
        setTimeout(tryInit, interval);
      } else {
        logger.error('PandaAid: Initialization failed. Salesforce UI not detected after multiple attempts.', 'initialization', undefined);
        initInProgress = false;
      }
    }
  }

  const startInit = () => {
    if (initCompleted || initInProgress) return;
    initInProgress = true;
    attempts = 0;
    tryInit();
  };

  window.addEventListener('locationchange', () => {
    if (initCompleted || initInProgress) return;
    if (isCaseRecordPage()) {
      startInit();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (!isCaseRecordPage()) {
        if (isVerbose()) {
          logger.info('PandAid: Not on Case record page. Waiting for navigation.', 'initialization', undefined);
        }
        return;
      }
      startInit();
    }, { once: true });
  } else if (isCaseRecordPage()) {
    startInit();
  } else if (isVerbose()) {
    logger.info('PandAid: Not on Case record page. Waiting for navigation.', 'initialization', undefined);
  }
}

// function setupEmailFrameButton removed as per user request

