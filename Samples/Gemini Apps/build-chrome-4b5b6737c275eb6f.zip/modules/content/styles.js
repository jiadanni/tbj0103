// modules/content/styles.js
//
// Style injection helpers for the content script UI.

export function injectStyles() {
  return new Promise((resolve) => {
    // Remove any existing button styles to prevent conflicts
    const existingButtonStyles = document.getElementById('sf-pandaid-button-styles');
    if (existingButtonStyles) {
      existingButtonStyles.remove();
    }

    // Load button.css from the extension
    const link = document.createElement('link');
    link.id = 'sf-pandaid-button-styles';
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('button.css');

    // Wait for stylesheet to load before resolving
    link.onload = () => resolve();
    link.onerror = () => resolve(); // Resolve even on error to prevent blocking

    document.head.appendChild(link);

    // Fallback timeout in case onload doesn't fire
    setTimeout(resolve, 500);
  });
}
