/**
 * Crypto Utilities Module
 * Provides encryption/decryption for sensitive data at rest using Web Crypto API.
 *
 * Security model:
 * - Encryption key is generated once per extension install
 * - Key is stored in chrome.storage.session (memory-only, cleared on browser restart)
 * - Data encrypted with AES-GCM (authenticated encryption)
 * - Protects against: storage export, disk access, sync exposure
 * - Does NOT protect against: runtime inspection, DevTools access
 */

import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';

const logger = createLogger('CryptoUtils');

const ALGORITHM = 'AES-GCM';
const KEY_LENGTH = 256;
const IV_LENGTH = 12; // 96 bits for GCM
const KEY_STORAGE_KEY = '_pandaid_session_key';
const ENCRYPTED_PREFIX = 'enc:v1:'; // Versioned prefix to identify encrypted data

// In-memory cache of the CryptoKey (avoids repeated storage lookups)
let cachedKey = null;

/**
 * Convert Uint8Array to base64 string using proper binary handling
 * @param {Uint8Array} buffer
 * @returns {string}
 */
function arrayBufferToBase64(buffer) {
  let binary = '';
  const len = buffer.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(buffer[i]);
  }
  return btoa(binary);
}

/**
 * Convert base64 string to Uint8Array
 * @param {string} base64
 * @returns {Uint8Array}
 */
function base64ToArrayBuffer(base64) {
  const binary = atob(base64);
  const len = binary.length;
  const buffer = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    buffer[i] = binary.charCodeAt(i);
  }
  return buffer;
}

/**
 * Generate a new encryption key
 * @returns {Promise<CryptoKey>}
 */
async function generateKey() {
  return crypto.subtle.generateKey(
    { name: ALGORITHM, length: KEY_LENGTH },
    true, // extractable - needed to store in session
    ['encrypt', 'decrypt']
  );
}

/**
 * Export CryptoKey to storable format (JWK)
 * @param {CryptoKey} key
 * @returns {Promise<JsonWebKey>}
 */
async function exportKey(key) {
  return crypto.subtle.exportKey('jwk', key);
}

/**
 * Import CryptoKey from stored format (JWK)
 * @param {JsonWebKey} jwk
 * @returns {Promise<CryptoKey>}
 */
async function importKey(jwk) {
  return crypto.subtle.importKey(
    'jwk',
    jwk,
    { name: ALGORITHM, length: KEY_LENGTH },
    false, // not extractable after import
    ['encrypt', 'decrypt']
  );
}

/**
 * Get or create the session encryption key.
 * Key is stored in chrome.storage.session (memory-only).
 * @returns {Promise<CryptoKey>}
 */
async function getOrCreateKey() {
  // Return cached key if available
  if (cachedKey) {
    return cachedKey;
  }

  // Require session storage; don't degrade to persistent storage
  if (!chrome.storage.session) {
    const error = new Error(
      'Session storage unavailable. ' +
      'Token encryption requires ephemeral key storage. ' +
      'Please update your browser or restart the extension.'
    );
    error.code = 'SESSION_STORAGE_UNAVAILABLE';
    throw error;
  }

  try {
    const result = await chrome.storage.session.get(KEY_STORAGE_KEY);

    if (result[KEY_STORAGE_KEY]) {
      // Import existing key
      cachedKey = await importKey(result[KEY_STORAGE_KEY]);
      return cachedKey;
    }
  } catch (e) {
    logger.error('[Crypto] Error reading session key:', 'crypto-utils', e);
    throw e;
  }

  // Generate new key
  const newKey = await generateKey();
  const exportedKey = await exportKey(newKey);

  // Store in session storage
  try {
    await chrome.storage.session.set({ [KEY_STORAGE_KEY]: exportedKey });
    logger.info('[Crypto] New session key generated and stored', 'crypto-utils', undefined);
  } catch (e) {
    logger.error('[Crypto] Failed to store session key:', 'crypto-utils', e);
    throw e;
  }

  cachedKey = newKey;
  return cachedKey;
}

/**
 * Encrypt a string value
 * @param {string} plaintext - The value to encrypt
 * @returns {Promise<Result<string>>} - Result containing encrypted value or error
 */
export async function encrypt(plaintext) {
  if (!plaintext || typeof plaintext !== 'string') {
    return Result.success(plaintext);
  }

  // Don't double-encrypt
  if (plaintext.startsWith(ENCRYPTED_PREFIX)) {
    return Result.success(plaintext);
  }

  try {
    const key = await getOrCreateKey();
    const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);

    const ciphertext = await crypto.subtle.encrypt(
      { name: ALGORITHM, iv },
      key,
      data
    );

    // Combine IV + ciphertext and encode as base64
    const combined = new Uint8Array(iv.length + ciphertext.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(ciphertext), iv.length);

    // Convert Uint8Array to base64 using proper binary handling
    const base64 = arrayBufferToBase64(combined);
    return Result.success(ENCRYPTED_PREFIX + base64);
  } catch (error) {
    logger.error('[Crypto] Encryption failed - operation aborted to prevent data leak:', 'crypto-utils', error);
    return Result.failure(error);
  }
}

/**
 * Decrypt an encrypted string value
 * @param {string} encrypted - The encrypted value (with prefix)
 * @returns {Promise<Result<string>>} - Result containing decrypted plaintext or error
 */
export async function decrypt(encrypted) {
  if (!encrypted || typeof encrypted !== 'string') {
    return Result.success(encrypted);
  }

  // Not encrypted - return as-is (handles migration from unencrypted storage)
  if (!encrypted.startsWith(ENCRYPTED_PREFIX)) {
    return Result.success(encrypted);
  }

  try {
    const key = await getOrCreateKey();
    const base64 = encrypted.slice(ENCRYPTED_PREFIX.length);
    const combined = base64ToArrayBuffer(base64);

    // Extract IV and ciphertext
    const iv = combined.slice(0, IV_LENGTH);
    const ciphertext = combined.slice(IV_LENGTH);

    const decrypted = await crypto.subtle.decrypt(
      { name: ALGORITHM, iv },
      key,
      ciphertext
    );

    const decoder = new TextDecoder();
    return Result.success(decoder.decode(decrypted));
  } catch (error) {
    // If the underlying Web Crypto API reports an OperationError or similar
    // it most likely means the session key is missing/rotated and the
    // ciphertext cannot be authenticated with the current key. Surface a
    // clearer, actionable error to callers so UI can prompt the user to
    // re-enter their token.
    const isOpError = error && (error.name === 'OperationError' || error.name === 'DataError' || (error.message && error.message.includes('OperationError')));

    if (isOpError) {
      logger.warn('[Crypto] Decryption failed: session key missing or mismatched', 'crypto-utils', error);
      const decryptError = new Error('Crypto decryption failed: session key missing or mismatched. Please re-enter your API token in settings.');
      decryptError.code = 'SESSION_KEY_MISMATCH';
      decryptError.cause = error;
      return Result.failure(decryptError);
    }

    logger.error('[Crypto] Decryption failed:', 'crypto-utils', error);
    // Generic decryption failure - preserve existing behavior
    const decryptError = new Error('Crypto decryption failed: ' + (error && error.message ? error.message : 'unknown'));
    decryptError.code = 'DECRYPT_FAILED';
    decryptError.cause = error;
    return Result.failure(decryptError);
  }
}

/**
 * Check if a value is encrypted
 * @param {string} value
 * @returns {boolean}
 */
export function isEncrypted(value) {
  return typeof value === 'string' && value.startsWith(ENCRYPTED_PREFIX);
}

/**
 * Clear the cached key (for testing or key rotation)
 */
export function clearCachedKey() {
  cachedKey = null;
}
