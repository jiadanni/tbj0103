/**
 * Atlassian (JIRA/Confluence) Message Handlers
 */
import { testAtlassianConnection, getJiraTickets, getConfluencePages } from '../api/atlassian-service.js';
import { Result } from '../utils/result.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('AtlassianHandlers');

export async function handleTestAtlassianConnectionRequest(request) {
    logger.debug('Received Atlassian connection test request', 'connectionHandler', { host: request.atlassianBaseUrl });
    return await testAtlassianConnection(request.atlassianToken, request.atlassianBaseUrl, request.atlassianEmail);
}

/**
 * Handles requests for FETCH_JIRA_TICKETS.
 */
export async function handleGetJiraTicketsRequest(request) {
    logger.debug('Received JIRA work items request', 'jiraHandler', request);
    if (!request.caseData || typeof request.caseData !== 'object') {
        throw new Error('Invalid case data provided for JIRA search');
    }

    const isManualFetch = Boolean(request.isManualFetch);
    const result = await getJiraTickets(request.caseId || '', request.caseData, isManualFetch);

    if (result.ok) {
        logger.debug('JIRA response prepared', 'jiraHandler', { count: result.value.length });
        result.value.forEach((ticket, index) => {
            logger.debug(`JIRA ${ticket.key}`, 'jiraHandler', { index, aiScore: ticket.aiRelevanceScore, hasExplanation: !!ticket.aiExplanation });
        });
    } else {
        logger.error('JIRA ticket search failed', 'jiraHandler', result.error);
    }

    return result;
}

/**
 * Handles requests for FETCH_CONFLUENCE_PAGES.
 */
export async function handleGetConfluencePagesRequest(request) {
    logger.debug('Received Confluence pages request', 'confluenceHandler', request);
    if (!request.caseData || typeof request.caseData !== 'object') {
        throw new Error('Invalid case data provided for Confluence search');
    }

    const isManualFetch = Boolean(request.isManualFetch);
    const result = await getConfluencePages(request.caseData, isManualFetch);

    if (!result.ok) {
        logger.error('Confluence page search failed', 'confluenceHandler', result.error);
        return result;
    }

    const pages = result.value.map(a => {
        const score = (typeof a.aiRelevanceScore === 'number') ? a.aiRelevanceScore : (typeof a.score === 'number' ? a.score : null);
        const explanation = a.aiExplanation || a.explanation || null;
        return {
            id: a.id || a.pageId || null,
            title: a.title || a.name || 'Untitled',
            url: a.url || a.link || a._links?.base || '#',
            excerpt: a.excerpt || (a.content && String(a.content).substring(0, 400)) || '',
            source: 'Confluence',
            aiRelevanceScore: score,
            aiExplanation: explanation,
            aiFallback: !!a.aiFallback
        };
    });

    return Result.success(pages);
}
