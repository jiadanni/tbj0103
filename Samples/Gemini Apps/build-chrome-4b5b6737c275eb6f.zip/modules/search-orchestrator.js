/**
 * Search Orchestrator Utility
 * Consolidates the logic for switching between AI-enhanced and traditional search.
 * Handles fallbacks, settings checks, and token validation in a unified way.
 * 
 * Supports AbortSignal propagation to properly cancel underlying fetch operations
 * when the orchestrator timeout fires or when cancelled externally.
 */

import { hasValidAiServiceToken } from '../api/ai-service.js';
import { createLogger } from './logger.js';
import { Result } from './result.js';
import { showWarning } from './user-notifications.js';

const logger = createLogger('SearchOrchestrator');

/** Default timeout for search operations (ms) */
const SEARCH_TIMEOUT_MS = 20000;

/**
 * Combines multiple AbortSignals into one.
 * Aborts when ANY of the provided signals abort.
 * 
 * @param {AbortSignal[]} signals - Array of signals to combine
 * @returns {AbortSignal} Combined signal
 */
function combineAbortSignals(signals) {
    const validSignals = signals.filter(s => s instanceof AbortSignal);
    if (validSignals.length === 0) return null;
    if (validSignals.length === 1) return validSignals[0];

    // Use AbortSignal.any if available (modern browsers)
    if (typeof AbortSignal.any === 'function') {
        return AbortSignal.any(validSignals);
    }

    // Fallback for older browsers: create a new controller that aborts when any signal aborts
    const controller = new AbortController();
    for (const signal of validSignals) {
        if (signal.aborted) {
            controller.abort(signal.reason);
            break;
        }
        signal.addEventListener('abort', () => controller.abort(signal.reason), { once: true });
    }
    return controller.signal;
}

/**
 * Orchestrates a search operation with AI enhancement and fallback logic.
 * 
 * @param {Object} options - Orchestration options
 * @param {string} options.serviceName - Display name for logging (e.g., 'JIRA')
 * @param {string} options.settingKey - Key in aiEnhancementSettings (e.g., 'jira')
 * @param {Function} options.aiSearchFn - Function to perform AI-enhanced search (receives AbortSignal)
 * @param {Function} options.traditionalSearchFn - Function to perform traditional search (receives AbortSignal)
 * @param {Function} options.fallbackEnhancer - Function to add fallback explanations to traditional results
 * @param {Object} options.caseData - Case context
 * @param {boolean} options.isManualFetch - Whether this was a user-triggered fetch
 * @param {AbortSignal} [options.signal] - Optional external abort signal for cancellation
 * @returns {Promise<Result>} Standardized Result object
 */
export async function orchestratedSearch({
    serviceName,
    settingKey,
    aiSearchFn,
    traditionalSearchFn,
    fallbackEnhancer,
    caseData = {},
    isManualFetch = false,
    signal = null
}) {
    // Create internal abort controller for timeout
    const timeoutController = new AbortController();

    // Combine external signal (if any) with our timeout signal
    const combinedSignal = signal
        ? combineAbortSignals([signal, timeoutController.signal])
        : timeoutController.signal;

    // Set up timeout to abort the search
    const timeoutId = setTimeout(() => {
        logger.warn(`${serviceName} search timed out after ${SEARCH_TIMEOUT_MS / 1000}s`, 'orchestrator');
        timeoutController.abort(new Error(`${serviceName} search timed out after ${SEARCH_TIMEOUT_MS / 1000}s`));
    }, SEARCH_TIMEOUT_MS);

    try {
        // Check if already aborted before starting
        if (combinedSignal?.aborted) {
            const error = new Error('Search aborted before starting');
            error.name = 'AbortError';
            return Result.failure(error);
        }

        // Helper to execute search functions and normalize results to Result object
        const executeSearch = async (fn) => {
            try {
                // Pass the combined signal to the search function
                const res = await fn(combinedSignal);
                // If result is already a Result object, return it
                if (res && typeof res.ok === 'boolean') {
                    return res;
                }
                // Otherwise wrap raw value in success
                return Result.success(res);
            } catch (err) {
                logger.error('Search internal execution error', 'orchestrator', err);
                // Check if this was an abort
                if (err.name === 'AbortError' || combinedSignal?.aborted) {
                    const abortError = new Error('Search was cancelled');
                    abortError.name = 'AbortError';
                    return Result.failure(abortError);
                }
                return Result.failure(err);
            }
        };

        // 1. Check AI enhancement settings
        const { aiEnhancementSettings } = await chrome.storage.local.get('aiEnhancementSettings');
        const userToggled = aiEnhancementSettings?.userToggled;
        const useAiEnhancement = (typeof userToggled?.[settingKey] === 'boolean')
            ? !!userToggled[settingKey]
            : (aiEnhancementSettings?.[settingKey] !== false);

        if (useAiEnhancement) {
            // 2. Check for AI Service token
            const hasToken = await hasValidAiServiceToken();
            if (!hasToken) {
                logger.warn(`${serviceName} AI: No AI token configured; skipping AI enhancement.`, 'orchestrator', undefined);
                const fallbackRes = await executeSearch(traditionalSearchFn);
                if (!fallbackRes.ok) return fallbackRes;
                return Result.success(fallbackEnhancer(fallbackRes.value, caseData));
            }

            // 3. Attempt AI Search
            logger.info(`${serviceName}: Attempting AI search...`, 'orchestrator', undefined);
            const aiRes = await executeSearch(aiSearchFn);

            if (aiRes.ok) {
                logger.info(`${serviceName}: AI search successful.`, 'orchestrator', undefined);
                return aiRes;
            }

            // 4. Failed AI Search - Fallback logic
            const aiError = aiRes.error;
            logger.error(`${serviceName} AI search failed, falling back:`, 'orchestrator', aiError);

            // Notify user about fallback if appropriate (but not for cancellations)
            if (aiError.name !== 'AbortError') {
                if (isManualFetch || (aiError.status !== 401 && aiError.status !== 403)) {
                    showWarning(`AI-enhanced ${serviceName} search unavailable. Using traditional search instead.`);
                }
            } else {
                // If aborted, don't try fallback - just return the abort error
                return aiRes;
            }

            // 5. Fallback to Traditional + Fallback Explanations
            const fallbackRes = await executeSearch(traditionalSearchFn);
            if (!fallbackRes.ok) return fallbackRes;
            return Result.success(fallbackEnhancer(fallbackRes.value, caseData));
        }

        // 6. Traditional Search Only (AI disabled)
        logger.info(`${serviceName}: Using traditional search (AI disabled)...`, 'orchestrator', undefined);
        return await executeSearch(traditionalSearchFn);
    } finally {
        // Always clear the timeout
        clearTimeout(timeoutId);
    }
}
