/**
 * Centralized Logging Utility
 * Provides consistent logging across the extension with verbose mode support
 *
 * @module logger
 */

// ============================================================================
// LOG LEVELS
// ============================================================================

/**
 * Log severity levels
 * @enum {string}
 * @readonly
 */
export const LogLevel = {
  ERROR: 'error',   // Critical errors that need immediate attention
  WARN: 'warn',     // Warnings about potential issues
  INFO: 'info',     // Important informational messages (always shown)
  DEBUG: 'debug',   // Detailed debugging information (verbose mode only)
  TRACE: 'trace'    // Very detailed trace information (verbose mode only)
};

// ============================================================================
// LOGGER CLASS
// ============================================================================

class Logger {
  /**
   * Create a new logger instance with optional context.
   *
   * @param {string} [context='PandAid'] - Context name for this logger (appears in all log messages)
   */
  constructor(context = 'PandAid') {
    this.context = context;
    this.verboseEnabled = false;
    this.initialized = false;

    // Kick off async load without blocking construction
    this.loadVerbosePreference().catch((error) => {
      logger.warn('[Logger] Failed to load verbose preference', 'logger', error);
    });
  }

  /**
   * Load verbose logging preference from Chrome storage.
   * Called automatically during constructor initialization.
   *
   * @private
   * @async
   * @returns {Promise<void>}
   */
  async loadVerbosePreference() {
    if (this.initialized) return;
    this.initialized = true;

    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      return;
    }

    try {
      const result = await chrome.storage.local.get(['verboseLogging']);
      if (Object.prototype.hasOwnProperty.call(result, 'verboseLogging')) {
        this.verboseEnabled = !!result.verboseLogging;
      }
    } catch (error) {
      logger.warn('[Logger] Error reading verbose logging preference', 'logger', error);
    }
  }

  /**
   * Set verbose mode at runtime.
   * Useful for toggling detailed logging during debugging or testing.
   *
   * @param {boolean} enabled - Whether to enable verbose logging
   */
  setVerbose(enabled = false) {
    this.verboseEnabled = !!enabled;
  }

  /**
   * Check if verbose logging is currently enabled.
   *
   * @returns {boolean} True if verbose logging is enabled
   */
  isVerboseEnabled() {
    return this.verboseEnabled;
  }

  /**
   * Format log message with timestamp and context.
   * Internal helper method for consistent formatting across all log levels.
   *
   * @private
   * @param {string} level - Log level (from LogLevel enum)
   * @param {string} context - Additional context string
   * @param {string} message - The message to format
   * @returns {string} Formatted message with timestamp
   */
  formatMessage(level, context, message) {
    const timestamp = new Date().toISOString().substring(11, 23); // HH:MM:SS.mmm
    const contextLabel = context ? `${this.context}:${context}` : this.context;
    return `[${timestamp}] [${contextLabel}] [${level.toUpperCase()}] ${message}`;
  }

  /**
   * Log error message (always shown regardless of verbose mode).
   * Use for critical errors that need immediate attention.
   *
   * @param {string} message - The error message to log
   * @param {string} [context=''] - Optional context (e.g., function name, module)
   * @param {*} [data=null] - Optional associated data/error object to log
   */
  error(message, context = '', data = null) {
    const formatted = this.formatMessage(LogLevel.ERROR, context, message);
    if (data !== null) {
      console.error(formatted, data);
    } else {
      console.error(formatted);
    }
  }

  /**
   * Log warning message (always shown regardless of verbose mode).
   * Use for potential issues or unexpected conditions.
   *
   * @param {string} message - The warning message to log
   * @param {string} [context=''] - Optional context (e.g., function name, module)
   * @param {*} [data=null] - Optional associated data to log
   */
  warn(message, context = '', data = null) {
    const formatted = this.formatMessage(LogLevel.WARN, context, message);
    if (data !== null) {
      console.warn(formatted, data);
    } else {
      console.warn(formatted);
    }
  }

  /**
   * Log info message (always shown regardless of verbose mode).
   * Use for important informational messages about normal operation.
   *
   * @param {string} message - The info message to log
   * @param {string} [context=''] - Optional context (e.g., function name, module)
   * @param {*} [data=null] - Optional associated data to log
   */
  info(message, context = '', data = null) {
    const formatted = this.formatMessage(LogLevel.INFO, context, message);
    if (data !== null) {
      console.info(formatted, data);
    } else {
      console.info(formatted);
    }
  }

  /**
   * Log debug message (only shown if verbose logging is enabled).
   * Use for detailed debugging information during development/troubleshooting.
   *
   * @param {string} message - The debug message to log
   * @param {string} [context=''] - Optional context (e.g., function name, module)
   * @param {*} [data=null] - Optional associated data to log
   */
  debug(message, context = '', data = null) {
    if (!this.verboseEnabled) return;

    const formatted = this.formatMessage(LogLevel.DEBUG, context, message);
    if (data !== null) {
      console.debug(formatted, data);
    } else {
      console.debug(formatted);
    }
  }

  /**
   * Log trace message (only shown if verbose logging is enabled).
   * Used for very detailed logging like function entry/exit, state changes, etc.
   *
   * @param {string} message - The trace message to log
   * @param {string} [context=''] - Optional context (e.g., function name, module)
   * @param {*} [data=null] - Optional associated data to log
   */
  trace(message, context = '', data = null) {
    if (!this.verboseEnabled) return;

    const formatted = this.formatMessage(LogLevel.TRACE, context, message);
    if (data !== null) {
      console.debug(formatted, data);
    } else {
      console.debug(formatted);
    }
  }

  /**
   * Create a child logger with a specific context.
   * Child loggers inherit the parent's verbose mode setting.
   *
   * @param {string} childContext - The child context name (appended to parent context)
   * @returns {Logger} New logger instance with combined context
   */
  child(childContext) {
    const childLogger = new Logger(`${this.context}:${childContext}`);
    childLogger.setVerbose(this.verboseEnabled);
    childLogger.initialized = true; // Do not re-read storage; inherit setting
    return childLogger;
  }

  /**
   * Log a group of related messages together.
   * Groups are only shown if verbose logging is enabled.
   *
   * @param {string} groupName - Name/title of the log group
   * @param {Function} fn - Function containing logger calls to group
   */
  group(groupName, fn) {
    if (!this.verboseEnabled) return;

    console.group(`[${this.context}] ${groupName}`);
    try {
      fn();
    } finally {
      console.groupEnd();
    }
  }

  /**
   * Execute a function and log its execution time.
   * Timing output is only shown if verbose logging is enabled.
   *
   * @param {string} label - Label for the timer (shown in timing output)
   * @param {Function} fn - Async function to time (can also be sync)
   * @returns {Promise<*>} Result of the function
   */
  async time(label, fn) {
    const timerLabel = `[${this.context}] ${label}`;
    if (this.verboseEnabled) {
      console.time(timerLabel);
    }

    try {
      return await fn();
    } finally {
      if (this.verboseEnabled) {
        console.timeEnd(timerLabel);
      }
    }
  }
}

// ============================================================================
// GLOBAL LOGGER INSTANCE
// ============================================================================

// Create default logger instance
const defaultLogger = new Logger('PandAid');

// Export factory function
export function createLogger(context = 'PandAid') {
  const newLogger = new Logger(context);
  newLogger.setVerbose(defaultLogger.isVerboseEnabled());
  return newLogger;
}

// Export default logger
export const logger = defaultLogger;

// Export convenience methods from default logger
export const error = (...args) => defaultLogger.error(...args);
export const warn = (...args) => defaultLogger.warn(...args);
export const info = (...args) => defaultLogger.info(...args);
export const debug = (...args) => defaultLogger.debug(...args);
export const trace = (...args) => defaultLogger.trace(...args);

// ============================================================================
// STORAGE LISTENER
// ============================================================================

// Listen for changes to verbose logging preference
if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.verboseLogging) {
      const newValue = !!changes.verboseLogging.newValue;
      defaultLogger.setVerbose(newValue);
      logger.info(`[PandAid] Verbose logging ${newValue ? 'enabled' : 'disabled'}`, 'contextual', undefined);
    }
  });
}
