/**
 * Sidebar Lifecycle Controller
 * Handles initialization, module loading, and cleanup for the sidebar.
 */
import { createLogger } from '../../utils/logger.js';
import { importWithTimeout } from '../../utils/promise-utils.js';
import { DYNAMIC_IMPORT_TIMEOUT_MS } from '../../config/constants.js';

const logger = createLogger('SidebarLifecycleController');

export class SidebarLifecycleController {
    constructor(sidebar) {
        this.sidebar = sidebar;
    }

    async initialize() {
        await this.sidebar.uiLoader.createSidebar(this.sidebar);
        this.sidebar.utils.applyKnowledgeBaseLabelsToSidebar(this.sidebar);
        this.sidebar.utils.loadKnowledgeBaseLabels(this.sidebar);

        try {
            const res = await chrome.storage.local.get(['verboseLogging']);
            if (res && typeof res.verboseLogging === 'boolean') {
                this.sidebar.verboseLogging = res.verboseLogging;
            }
        } catch (e) {
            logger.debug('Error loading verboseLogging preference', 'sidebar', e);
        }

        this.sidebar.eventModule.setupEventListeners(this.sidebar);
        this.sidebar.setupStorageListener();
        await this.sidebar.updateAiAvailability();
        await this.initializeNewFeatures();
    }

    async initializeNewFeatures() {
        if (!this.sidebar.sidebar) return;
        try {
            const initializerModule = await this.safeLoadModule('modules/sidebar/feature-initializer.js', 'feature-initializer');
            if (initializerModule) {
                const result = await initializerModule.initializeFeatures(this.sidebar);
                this.sidebar.featureModules = result.featureModules || {};
            }
        } catch (error) {
            logger.error('[Sidebar] Feature initialization failed:', 'sidebar', error);
        }
    }

    async safeLoadModule(relativePath, key) {
        try {
            return await importWithTimeout(chrome.runtime.getURL(relativePath), DYNAMIC_IMPORT_TIMEOUT_MS, key);
        } catch (error) {
            logger.error(`[Sidebar] Failed to load module ${key}:`, 'sidebar', error);
            return null;
        }
    }

    cleanup() {
        if (this.sidebar.featureModules?.autoSave?.clearAutoSave) {
            this.sidebar.featureModules.autoSave.clearAutoSave();
        }
        if (this.sidebar.sidebar?.parentNode) {
            this.sidebar.sidebar.parentNode.removeChild(this.sidebar.sidebar);
        }
        this.sidebar.sidebar = null;
        this.sidebar.isVisible = false;
    }
}
