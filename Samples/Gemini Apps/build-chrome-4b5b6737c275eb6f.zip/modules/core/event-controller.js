/**
 * Sidebar Event Controller
 * Handles event listener setup and storage change handling for the sidebar.
 */
import { createLogger } from '../../utils/logger.js';

const logger = createLogger('SidebarEventController');

export class SidebarEventController {
    constructor(sidebar) {
        this.sidebar = sidebar;
    }

    setupEventListeners() {
        this.sidebar.eventModule.setupEventListeners(this.sidebar);
    }

    setupStorageListener() {
        this.sidebar.boundHandlers.storageChange = (changes, areaName) => {
            if (areaName !== 'local') return;
            if (changes.preloadSettings || changes.sidebarSections) this.sidebar.loadPreloadSettings();
            if (changes.sidebarWidth) this.sidebar.applySidebarWidth();
            if (changes.aiEnabled || changes.aiServiceToken || changes.apiEndpoint) this.sidebar.updateAiAvailability();
            if (changes.knowledgeBaseLabels) this.sidebar.utils.loadKnowledgeBaseLabels(this.sidebar);
        };
        chrome.storage.onChanged.addListener(this.sidebar.boundHandlers.storageChange);
    }

    cleanup() {
        if (this.sidebar.eventHandlers) {
            Object.values(this.sidebar.eventHandlers).forEach(({ element, type, handler }) => {
                element?.removeEventListener?.(type, handler);
            });
        }
        if (chrome.storage?.onChanged && this.sidebar.boundHandlers?.storageChange) {
            chrome.storage.onChanged.removeListener(this.sidebar.boundHandlers.storageChange);
        }
    }
}
