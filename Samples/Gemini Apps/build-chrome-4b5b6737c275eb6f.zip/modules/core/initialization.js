/**
 * Initialization Module
 * Handles service worker initialization, keep-alive, and lifecycle events
 */

// Import dependencies
import { CACHE_TTL, responseCache, restoreCache, persistCache, trimCacheToMax } from '../cache/cache-manager.js';
import { setupContextMenu } from '../ui/context-menu.js';
import { loadCommunityGuides } from '../api/community-service.js';
import { cleanupStaleAutoSave } from '../sidebar/features/auto-save.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('Initialization');

// ============================================================================
// KEEP-ALIVE MANAGEMENT
// ============================================================================

// Service worker keep-alive configuration
const KEEP_ALIVE_ALARM = 'serviceWorkerKeepAlive';
const DEFAULT_KEEP_ALIVE_MINUTES = 7; // less aggressive than 10–20s heartbeat
const MIN_KEEP_ALIVE_MINUTES = 5;
const MAX_KEEP_ALIVE_MINUTES = 30;
const CLEANUP_ALARM = 'cleanupCache';
const CACHE_CLEANUP_INTERVAL_MINUTES = 3;

async function resolveKeepAliveIntervalMinutes() {
  const { keepAliveIntervalMinutes } = await chrome.storage.local.get({ keepAliveIntervalMinutes: DEFAULT_KEEP_ALIVE_MINUTES });
  const numeric = Number(keepAliveIntervalMinutes);
  const clamped = Math.min(Math.max(isFinite(numeric) ? numeric : DEFAULT_KEEP_ALIVE_MINUTES, MIN_KEEP_ALIVE_MINUTES), MAX_KEEP_ALIVE_MINUTES);
  const jitter = 0.9 + Math.random() * 0.2; // +/-10% jitter to avoid synchronized wakeups
  return clamped * jitter;
}

/**
 * Initialize service worker keep-alive using chrome.alarms API
 * This is more efficient than setInterval and works even when service worker is suspended
 */
export async function initializeKeepAlive() {
  try {
    // Allow disabling keep-alive via chrome.storage.local flag for environments
    // where background wakeups are undesirable (e.g., low-power environments)
    const { disableKeepAlive } = await chrome.storage.local.get({ disableKeepAlive: false });
    if (disableKeepAlive) {
      await chrome.alarms.clear(KEEP_ALIVE_ALARM);
      logger.info('Keep-alive alarm disabled via storage flag', 'initialization', undefined);
      return;
    }

    // Clear any existing keep-alive alarm
    await chrome.alarms.clear(KEEP_ALIVE_ALARM);

    const interval = await resolveKeepAliveIntervalMinutes();

    // Create keep-alive alarm
    await chrome.alarms.create(KEEP_ALIVE_ALARM, {
      periodInMinutes: interval
    });

    logger.info(`Keep-alive alarm created (interval ~${Math.round(interval * 60)}s, jittered)`, 'initializeKeepAlive');
  } catch (error) {
    logger.error('Error initializing keep-alive:', 'initialization', error);
  }
}

/**
 * Handle keep-alive alarm
 * Performs a lightweight operation to prevent service worker suspension
 */
export function handleKeepAlive() {
  // Lightweight operation to keep service worker alive
  // Just check if we can access chrome APIs
  chrome.runtime.getPlatformInfo().catch(() => {
    logger.warn('Keep-alive check failed', 'initialization', undefined);
  });
}

// ============================================================================
// SERVICE WORKER INITIALIZATION
// ============================================================================

/**
 * Initialize the service worker with all necessary components
 */
export async function initializeServiceWorker() {
  logger.info('Initializing service worker...', 'initialization', undefined);

  try {
    // Initialize keep-alive alarm (prevents service worker suspension)
    await initializeKeepAlive();

    // Restore cache from storage first
    await restoreCache();

    // Set up context menu
    await setupContextMenu();

    // Set up cache cleanup alarm if it doesn't exist
    const existingAlarms = await chrome.alarms.getAll();
    const hasCleanupAlarm = existingAlarms.some(alarm => alarm.name === CLEANUP_ALARM);

    if (!hasCleanupAlarm) {
      chrome.alarms.create(CLEANUP_ALARM, {
        delayInMinutes: CACHE_CLEANUP_INTERVAL_MINUTES,
        periodInMinutes: CACHE_CLEANUP_INTERVAL_MINUTES
      });
      logger.info(`Cache cleanup alarm created (interval ${CACHE_CLEANUP_INTERVAL_MINUTES}m)`, 'initializeServiceWorker');
    }

    // Load community guides (if file is configured)
    await loadCommunityGuides();

    // Clean up stale auto-save data (prevents indefinite storage retention)
    await cleanupStaleAutoSave();

    logger.info('Service worker initialized successfully', 'initialization', undefined);
  } catch (error) {
    logger.error('Error initializing service worker:', 'initialization', error);
  }
}

// ============================================================================
// LIFECYCLE EVENT LISTENERS
// ============================================================================

// Track initialization state
let isInitialized = false;

/**
 * Handle extension installation or update
 */
export function initializeOnInstalledListener() {
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'update' || details.reason === 'install') {
      logger.info(`Extension ${details.reason}d. Clearing cache.`, 'initialization', undefined);
      responseCache.clear();

      // Initialize the service worker
      initializeServiceWorker();

      // Open options page on first install
      if (details.reason === 'install') {
        chrome.runtime.openOptionsPage();
      }
    }
  });
}

/**
 * Handle extension startup
 */
export function initializeOnStartupListener() {
  chrome.runtime.onStartup.addListener(() => {
    logger.info('Extension service worker starting up', 'initialization', undefined);
    initializeServiceWorker().then(() => {
      isInitialized = true;
    });
  });
}

/**
 * Handle service worker suspension
 */
export function initializeOnSuspendListener() {
  chrome.runtime.onSuspend.addListener(() => {
    logger.info('Extension service worker suspending', 'initialization', undefined);
    isInitialized = false; // Reset initialization flag
  });
}

/**
 * Handle alarms (cache cleanup and keep-alive)
 */
export function initializeAlarmsListener() {
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === CLEANUP_ALARM) {
      const now = Date.now();
      let cleared = 0;

      for (const [key, { timestamp }] of responseCache.entries()) {
        if ((now - timestamp) > CACHE_TTL) {
          responseCache.delete(key);
          cleared++;
        }
      }

      const trimmed = trimCacheToMax();

      if (cleared > 0 || trimmed) {
        if (cleared > 0) {
          logger.info(`Cleared ${cleared} expired cache entries`, 'initialization', undefined);
        }
        if (trimmed) {
          logger.info('Cache trimmed to max size after cleanup', 'initialization', undefined);
        }
        // Persist the cleaned cache
        try {
          await persistCache();
        } catch (error) {
          logger.error('Cache persist failed after cleanup', 'initialization', error);
        }
      }

      // Also clean up stale auto-save data periodically
      try {
        await cleanupStaleAutoSave();
      } catch (error) {
        logger.error('Auto-save cleanup failed during periodic alarm', 'initialization', error);
      }
    } else if (alarm.name === KEEP_ALIVE_ALARM) {
      // Handle service worker keep-alive
      handleKeepAlive();
    }
  });
}

/**
 * Initialize all lifecycle event listeners
 */
export function initializeAllListeners() {
  initializeOnInstalledListener();
  initializeOnStartupListener();
  initializeOnSuspendListener();
  initializeAlarmsListener();
}

/**
 * Get initialization state
 */
export function getInitializationState() {
  return isInitialized;
}

/**
 * Set initialization state
 */
export function setInitializationState(state) {
  isInitialized = state;
}
