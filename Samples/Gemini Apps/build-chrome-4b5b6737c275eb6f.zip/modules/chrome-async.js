import { createLogger } from './logger.js';
const logger = createLogger('ChromeAsync');

function getLastError() {
  const lastError = chrome?.runtime?.lastError;
  if (!lastError) return null;
  const message = typeof lastError.message === 'string' ? lastError.message : String(lastError);
  return new Error(message);
}

function isThenable(value) {
  return value && (typeof value === 'object' || typeof value === 'function') && typeof value.then === 'function';
}

async function callChromeApi(fn, args, { expectsCallback = true } = {}) {
  return await new Promise((resolve, reject) => {
    let settled = false;
    const settle = (error, value) => {
      if (settled) return;
      settled = true;
      if (error) reject(error);
      else resolve(value);
    };

    const callback = (...callbackArgs) => {
      const err = getLastError();
      if (err) {
        settle(err);
        return;
      }
      if (callbackArgs.length <= 1) {
        settle(null, callbackArgs[0]);
      } else {
        settle(null, callbackArgs);
      }
    };

    const attempt = (withCallback) => {
      try {
        const result = withCallback ? fn(...args, callback) : fn(...args);
        if (isThenable(result)) {
          result.then(
            (value) => settle(null, value),
            (error) => settle(error)
          );
        } else if (!withCallback || !expectsCallback) {
          settle(null, result);
        }
        return true;
      } catch (error) {
        if (withCallback) return false;
        logger.debug('API invocation error', 'chrome-async', error);
        settle(error);
        return true;
      }
    };

    if (expectsCallback) {
      const ok = attempt(true);
      if (!ok) {
        attempt(false);
      }
    } else {
      attempt(false);
    }
  });
}

export async function tabsQuery(queryInfo) {
  if (!chrome?.tabs?.query) {
    throw new Error('chrome.tabs.query is not available');
  }
  return await callChromeApi(chrome.tabs.query.bind(chrome.tabs), [queryInfo]);
}

export async function storageLocalRemove(keys) {
  if (!chrome?.storage?.local?.remove) {
    throw new Error('chrome.storage.local.remove is not available');
  }
  return await callChromeApi(chrome.storage.local.remove.bind(chrome.storage.local), [keys]);
}

export async function scriptingExecuteScript(options) {
  if (!chrome?.scripting?.executeScript) {
    throw new Error('chrome.scripting.executeScript is not available');
  }
  return await callChromeApi(chrome.scripting.executeScript.bind(chrome.scripting), [options]);
}

