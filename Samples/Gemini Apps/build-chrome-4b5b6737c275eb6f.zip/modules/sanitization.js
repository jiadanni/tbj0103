/**
 * HTML Sanitization Module
 * Provides sanitization helpers for PandAid extension
 */
import { createLogger } from '../utils/logger.js';

const logger = createLogger('Sanitization');

/**
 * Escapes HTML special characters to prevent XSS attacks
 * @param {string} unsafe - The unsafe string that may contain HTML
 * @returns {string} The HTML-escaped string
 */
export function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') {
        return unsafe || '';
    }
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/**
 * Safely sets innerHTML after escaping HTML
 * @param {HTMLElement} element - The DOM element
 * @param {string} html - The HTML content to set (will be escaped)
 */
export function safeSetInnerHTML(element, html) {
    if (!element) {
        logger.warn('safeSetInnerHTML: element is null or undefined', 'sanitization', undefined);
        return;
    }
    element.innerHTML = escapeHtml(html);
}

/**
 * Dangerous HTML patterns that indicate potential XSS attacks
 */
const DANGEROUS_HTML_PATTERNS = [
    /<script\b[^>]*>[\s\S]*?<\/script>/gi,           // Script tags
    /\bon\w+\s*=/gi,                                   // Event handlers (onclick, onerror, etc.)
    /javascript\s*:/gi,                                // javascript: URLs
    /data\s*:\s*text\/html/gi,                         // data:text/html URLs
    /<iframe\b[^>]*>/gi,                               // iframes (can load malicious content)
    /<object\b[^>]*>/gi,                               // object tags
    /<embed\b[^>]*>/gi,                                // embed tags
    /<form\b[^>]*action\s*=/gi,                        // forms with action (phishing risk)
    /<meta\b[^>]*http-equiv/gi,                        // meta refresh/redirect
    /<link\b[^>]*rel\s*=\s*["']?import/gi,             // HTML imports
    /<base\b[^>]*>/gi,                                 // base tag (can redirect all URLs)
    /expression\s*\(/gi,                               // CSS expressions (IE)
    /url\s*\(\s*["']?\s*javascript:/gi,                // CSS javascript URLs
];

/**
 * Allowed HTML tags for trusted content (whitelist approach)
 */
const ALLOWED_TAGS = new Set([
    'div', 'span', 'p', 'br', 'hr',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'ul', 'ol', 'li', 'dl', 'dt', 'dd',
    'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption',
    'a', 'img', 'strong', 'em', 'b', 'i', 'u', 's', 'mark',
    'code', 'pre', 'blockquote', 'cite',
    'abbr', 'time', 'kbd', 'var', 'samp',
    'sup', 'sub', 'small',
    'label', 'input', 'button', 'select', 'option', 'textarea',
    'details', 'summary', 'figure', 'figcaption',
    'header', 'footer', 'nav', 'main', 'section', 'article', 'aside',
    'template', 'svg', 'path', 'use' // SVG icons support
]);

/**
 * Allowed attributes for trusted content
 */
const ALLOWED_ATTRIBUTES = new Set([
    'id', 'class', 'style', 'title', 'alt', 'src', 'href',
    'target', 'rel', 'type', 'value', 'placeholder', 'name',
    'disabled', 'readonly', 'checked', 'selected', 'required',
    'min', 'max', 'step', 'pattern', 'maxlength', 'minlength',
    'rows', 'cols', 'width', 'height', 'colspan', 'rowspan',
    'role', 'aria-label', 'aria-labelledby', 'aria-describedby',
    'aria-hidden', 'aria-expanded', 'aria-controls', 'aria-live',
    'tabindex', 'for', 'autocomplete',
    // SVG attributes
    'd', 'viewbox', 'fill', 'stroke', 'stroke-width', 'xmlns'
]);

/**
 * Validates that HTML content does not contain dangerous patterns
 * @param {string} html - The HTML string to validate
 * @returns {{safe: boolean, violations: string[]}} Validation result
 */
export function validateHtmlSafety(html) {
    if (typeof html !== 'string') {
        return { safe: false, violations: ['Input is not a string'] };
    }

    const violations = [];

    // Check for dangerous patterns
    for (const pattern of DANGEROUS_HTML_PATTERNS) {
        // Reset lastIndex for global patterns
        pattern.lastIndex = 0;
        if (pattern.test(html)) {
            violations.push(`Dangerous pattern detected: ${pattern.source.substring(0, 50)}`);
        }
    }

    return {
        safe: violations.length === 0,
        violations
    };
}

/**
 * Sanitizes HTML by removing dangerous elements and attributes
 * Uses a DOM parser for accurate HTML handling
 * @param {string} html - The HTML string to sanitize
 * @returns {string} Sanitized HTML string
 */
export function sanitizeHtml(html) {
    if (typeof html !== 'string') {
        return '';
    }

    // Parse HTML using DOMParser (safe - doesn't execute scripts)
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Walk the DOM and remove dangerous elements/attributes
    const walker = doc.createTreeWalker(
        doc.body,
        NodeFilter.SHOW_ELEMENT,
        null,
        false
    );

    const nodesToRemove = [];

    while (walker.nextNode()) {
        const node = walker.currentNode;
        const tagName = node.tagName.toLowerCase();

        // Remove disallowed tags entirely
        if (!ALLOWED_TAGS.has(tagName)) {
            nodesToRemove.push(node);
            continue;
        }

        // Remove disallowed attributes
        const attrs = Array.from(node.attributes);
        for (const attr of attrs) {
            const attrName = attr.name.toLowerCase();

            // Allow data-* attributes
            if (attrName.startsWith('data-')) {
                continue;
            }

            // Remove event handlers and disallowed attributes
            if (attrName.startsWith('on') || !ALLOWED_ATTRIBUTES.has(attrName)) {
                node.removeAttribute(attr.name);
                continue;
            }

            // Validate href/src attributes
            if (attrName === 'href' || attrName === 'src') {
                const value = attr.value.toLowerCase().trim();
                if (value.startsWith('javascript:') || value.startsWith('data:text/html')) {
                    node.removeAttribute(attr.name);
                }
            }
        }
    }

    // Remove dangerous nodes
    for (const node of nodesToRemove) {
        node.parentNode?.removeChild(node);
    }

    return doc.body.innerHTML;
}

/**
 * Safely sets innerHTML with pre-sanitized HTML
 * Performs runtime validation to prevent XSS attacks
 *
 * @param {HTMLElement} element - The DOM element
 * @param {string} trustedHtml - Pre-sanitized HTML content
 * @param {Object} [options={}] - Configuration options
 * @param {boolean} [options.skipValidation=false] - Skip validation (use ONLY for extension-bundled HTML)
 * @param {boolean} [options.sanitize=false] - Sanitize HTML before setting (slower but safer)
 * @param {string} [options.source='unknown'] - Source identifier for logging
 * @returns {boolean} True if HTML was set successfully, false if blocked
 */
export function setTrustedHTML(element, trustedHtml, options = {}) {
    if (!element) {
        logger.warn('setTrustedHTML: element is null or undefined', 'sanitization', undefined);
        return false;
    }

    const { skipValidation = false, sanitize = false, source = 'unknown' } = options;

    // For extension-bundled HTML loaded via chrome.runtime.getURL, skip validation
    if (skipValidation) {
        element.innerHTML = trustedHtml;
        return true;
    }

    // Validate HTML safety
    const validation = validateHtmlSafety(trustedHtml);

    if (!validation.safe) {
        logger.error(`setTrustedHTML: Blocked unsafe HTML from source "${source}":`, 'sanitization', validation.violations);

        // If sanitize option is enabled, clean the HTML and use it
        if (sanitize) {
            const sanitized = sanitizeHtml(trustedHtml);
            logger.warn(`setTrustedHTML: Using sanitized HTML from source "${source}"`, 'sanitization', undefined);
            element.innerHTML = sanitized;
            return true;
        }

        // Otherwise, set escaped version to show content safely
        element.innerHTML = escapeHtml(trustedHtml);
        return false;
    }

    // HTML passed validation
    element.innerHTML = trustedHtml;
    return true;
}
