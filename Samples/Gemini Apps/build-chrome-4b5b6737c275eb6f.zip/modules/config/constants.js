// modules/config/constants.js
//
// Centralized configuration constants for timeouts, intervals, and limits.
// Import from here instead of using magic numbers throughout the codebase.

// =============================================================================
// API TIMEOUTS
// =============================================================================

/** Default timeout for AI service requests (ms) */
export const AI_REQUEST_TIMEOUT_MS = 15000;

/** Timeout for Atlassian API requests - allows for slower tenants (ms) */
export const ATLASSIAN_TIMEOUT_MS = 30000;

/** Timeout for AI analysis orchestration in message handlers (ms) */
export const AI_ANALYSIS_TIMEOUT_MS = 10000;

/** Timeout for JIRA ticket fetch in message handlers (ms) */
export const JIRA_TICKETS_TIMEOUT_MS = 5000;

/** Timeout for knowledge base search in message handlers (ms) */
export const KNOWLEDGE_BASE_TIMEOUT_MS = 8000;

/** Maximum retries for failed API requests */
export const MAX_API_RETRIES = 2;

// =============================================================================
// AUTH & SECURITY
// =============================================================================

/** Number of consecutive auth failures before invalidating token */
export const AUTH_FAILURE_THRESHOLD = 5;

/** Time window for counting auth failures (ms) - 10 minutes */
export const AUTH_FAILURE_WINDOW_MS = 10 * 60 * 1000;

/** Placeholder string displayed for saved tokens in the UI */
export const TOKEN_PLACEHOLDER = '••••••••••••••••';

// =============================================================================
// CACHE
// =============================================================================

/** Default cache TTL (ms) - 5 minutes */
export const CACHE_TTL_MS = 5 * 60 * 1000;

/** Maximum number of cached entries before eviction */
export const CACHE_MAX_ENTRIES = 100;

/** Maximum bytes per cache entry */
export const CACHE_MAX_ENTRY_BYTES = 512 * 1024;

/** Quota safety margin to avoid storage write failures */
export const CACHE_QUOTA_SAFETY_MARGIN = 0.9;

/** Debounce delay for persisting cache changes (ms) */
export const CACHE_PERSIST_DEBOUNCE_MS = 750;

/** Delay before retrying cache persistence (ms) */
export const CACHE_PERSIST_RETRY_DELAY_MS = 75;

/** Cache cleanup interval (minutes) */
export const CACHE_CLEANUP_INTERVAL_MINUTES = 3;

/** Maximum age for auto-save data to be considered recent (ms) - 24 hours */
export const AUTO_SAVE_RECENT_THRESHOLD_MS = 24 * 60 * 60 * 1000;

// =============================================================================
// AUTO-SAVE & INTERVALS
// =============================================================================

/** Auto-save interval (ms) - 30 seconds */
export const AUTO_SAVE_INTERVAL_MS = 30000;

/** Debounce delay for user input before auto-save (ms) */
export const INPUT_DEBOUNCE_MS = 500;

/** Filter input debounce delay (ms) */
export const FILTER_DEBOUNCE_MS = 300;

// =============================================================================
// UI TIMING
// =============================================================================

/** Toast notification display duration (ms) */
export const TOAST_DURATION_MS = 3000;

/** Copy feedback duration (ms) */
export const COPY_FEEDBACK_MS = 1000;

/** Placeholder reset delay (ms) */
export const PLACEHOLDER_RESET_MS = 3000;

/** Badge fade-in animation delay (ms) */
export const BADGE_FADE_DELAY_MS = 20;

/** Button visibility update delay (ms) */
export const BUTTON_VISIBILITY_DELAY_MS = 100;

/** Loading indicator removal delay (ms) */
export const LOADING_REMOVE_DELAY_MS = 3000;

/** Error message auto-dismiss delay (ms) */
export const ERROR_DISMISS_DELAY_MS = 5000;

// =============================================================================
// CONTENT SCRIPT TIMING
// =============================================================================

/** Delay before SPA navigation handler fires (ms) */
export const SPA_NAVIGATION_DELAY_MS = 500;

/** Message toggle debounce (ms) */
export const MESSAGE_TOGGLE_DEBOUNCE_MS = 500;

/** DOM polling interval for resilience observer (ms) */
export const DOM_POLL_INTERVAL_MS = 800;

/** Context menu action delay (ms) */
export const CONTEXT_MENU_DELAY_MS = 400;

/** Text insertion delay after button click (ms) */
export const TEXT_INSERT_DELAY_MS = 500;

/** Case details load delay (ms) */
export const CASE_DETAILS_LOAD_DELAY_MS = 1500;

// =============================================================================
// RETRY & POLLING
// =============================================================================

/** Base retry delay for exponential backoff (ms) */
export const BASE_RETRY_DELAY_MS = 1000;

/** Maximum retry delay cap (ms) */
export const MAX_RETRY_DELAY_MS = 30000;

/** Polling interval for waiting operations (ms) */
export const POLL_INTERVAL_MS = 100;

// =============================================================================
// RATE LIMITING
// =============================================================================

/** Default rate limiter bucket size */
export const RATE_LIMIT_BUCKET_SIZE = 10;

/** Default rate limiter refill rate (tokens per interval) */
export const RATE_LIMIT_REFILL_RATE = 1;

/** Default rate limiter refill interval (ms) */
export const RATE_LIMIT_REFILL_INTERVAL_MS = 1000;

/** Service-specific rate limiter configuration */
export const RATE_LIMIT_CONFIG = {
  ai: {
    maxTokens: 5,
    refillRate: 1,
    refillIntervalMs: 1000,
    baseDelayMs: 2000,
    maxBackoffMs: 60000
  },
  atlassian: {
    maxTokens: 10,
    refillRate: 2,
    refillIntervalMs: 1000,
    baseDelayMs: 5000,
    maxBackoffMs: 120000
  },
  local: {
    maxTokens: 20,
    refillRate: 5,
    refillIntervalMs: 1000
  }
};

// =============================================================================
// MESSAGE TIMEOUTS
// =============================================================================

/** Default timeout for chrome.runtime message responses (ms) */
export const MESSAGE_RESPONSE_TIMEOUT_MS = 35000;

/** Quick message timeout for simple operations (ms) */
export const QUICK_MESSAGE_TIMEOUT_MS = 5000;

/** Timeout for message responses from the options page (ms) */
export const OPTIONS_MESSAGE_RESPONSE_TIMEOUT_MS = 45000;

/** Timeout for dynamic module imports (ms) */
export const DYNAMIC_IMPORT_TIMEOUT_MS = 10000;

// =============================================================================
// LIMITS
// =============================================================================

/** Maximum snippet length before truncation */
export const MAX_SNIPPET_LENGTH = 300;

/** Maximum results to display per section */
export const MAX_RESULTS_PER_SECTION = 10;
