/**
 * Connection Controller
 * Manages connection testing for AI and Atlassian services.
 */
import { createConnectionTesting } from '../connection-testing.js';
import { sendMessageWithTimeout } from '../messaging.js';
import { requestHostPermission, checkHostPermission } from '../permissions.js';
import { buildOriginFromUrl } from '../utils.js';
import { showSectionStatus } from '../ui-helpers.js';

export class ConnectionController {
    constructor(elements, uiController) {
        this.elements = elements;
        this.uiController = uiController;

        // Initialize the helper
        const { checkLocalServer, testAiConnection, testAtlassianConnection } = createConnectionTesting({
            elements: elements,
            messaging: { sendMessageWithTimeout },
            permissions: { requestHostPermission, checkHostPermission, buildOriginFromUrl },
            helpers: { showSectionStatus }
        });

        this.checkLocalServer = checkLocalServer;
        this.testAiConnection = testAiConnection;
        this.testAtlassianConnection = testAtlassianConnection;

        this.attachListeners();
    }

    attachListeners() {
        const { testAiButton, testAtlassianButton, checkLocalServerButton } = this.elements;

        if (testAiButton) {
            testAiButton.addEventListener('click', this.testAiConnection);
        }

        if (testAtlassianButton) {
            testAtlassianButton.addEventListener('click', this.testAtlassianConnection);
        }

        if (checkLocalServerButton) {
            checkLocalServerButton.addEventListener('click', () => {
                // This needs context binding if method uses `this`
                this.checkLocalServer();
            });
        }
    }
}
