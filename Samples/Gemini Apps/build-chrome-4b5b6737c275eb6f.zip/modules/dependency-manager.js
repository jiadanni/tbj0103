import { createLogger } from '../utils/logger.js';

const logger = createLogger('DependencyManager');

// Dependency warnings and toggle coordination for the options page.

export function createDependencyManager({ elements, helpers }) {
  const {
    aiGlobalEnable,
    aiJiraToggle,
    aiConfluenceToggle,
    aiCommunityToggle,
    showJiraExplanationsToggle,
    showConfluenceExplanationsToggle,
    showCommunityExplanationsToggle,
    aiFilterToggle,
    communityAiFilterToggle,
    advancedAiToggle,
    aiScoreSettings,
    communityAiScoreSettings,
    testAtlassianButton,
    testAiButton,
    aiServiceTokenInput,
    atlassianTokenInput,
    confluencePreloadToggle,
    jiraPreloadToggle: _jiraPreloadToggle,
    communityMinScoreSlider,
    aiModel1Input,
    aiModel2Input,
    aiModel3Input,
    apiEndpointInput
  } = elements;

  const { setAiMasterAvailability, showStatus, switchContext } = helpers;

  const dependencyWarnings = {};

  function createWarningElement() {
    const warningEl = document.createElement('p');
    warningEl.className = 'dependency-warning';
    warningEl.style.color = '#1a1b1b';
    warningEl.style.fontSize = '13px';
    warningEl.style.marginTop = '8px';
    warningEl.style.padding = '8px 12px';
    warningEl.style.backgroundColor = '#f5f5f5';
    warningEl.style.borderLeft = '3px solid #1a1b1b';
    warningEl.style.borderRadius = '0 4px 4px 0';
    warningEl.style.lineHeight = '1.4';
    warningEl.style.display = 'none';
    return warningEl;
  }

  function createContextWarning(message) {
    const warning = document.createElement('div');
    warning.className = 'context-warning';
    warning.innerHTML = message;
    warning.style.padding = '10px 12px';
    warning.style.marginBottom = '15px';
    warning.style.backgroundColor = '#f5f5f5';
    warning.style.borderLeft = '3px solid #1a1b1b';
    warning.style.borderRadius = '0 4px 4px 0';
    warning.style.fontSize = '13px';
    warning.style.lineHeight = '1.4';
    return warning;
  }

  function showDependencyWarning(toggleElement, message) {
    if (!toggleElement) return;

    const toggleId = typeof toggleElement === 'string' ? toggleElement : (toggleElement.id || 'unknown-toggle');

    if (!dependencyWarnings[toggleId]) {
      const warningEl = createWarningElement();
      try {
        if (toggleElement && typeof toggleElement.closest === 'function') {
          const parentLabel = toggleElement.closest('.toggle-switch');
          if (parentLabel && parentLabel.parentNode) {
            parentLabel.parentNode.insertBefore(warningEl, parentLabel.nextSibling);
          } else {
            document.body.appendChild(warningEl);
          }
        } else {
          document.body.appendChild(warningEl);
        }
      } catch (e) {
        logger.debug('Error inserting dependency warning:', 'dependency-manager', e);
        document.body.appendChild(warningEl);
      }

      dependencyWarnings[toggleId] = warningEl;
    }

    dependencyWarnings[toggleId].textContent = message;
    dependencyWarnings[toggleId].style.display = 'block';
  }

  function hideDependencyWarning(toggleId) {
    const id = typeof toggleId === 'string' ? toggleId : (toggleId && toggleId.id ? toggleId.id : null);
    if (!id) return;
    if (dependencyWarnings[id]) {
      dependencyWarnings[id].style.display = 'none';
    }
  }

  function manageDependencies() {
    if (aiGlobalEnable && !aiGlobalEnable.checked) {
      setAiMasterAvailability(false);
      return;
    }

    if (aiJiraToggle && aiJiraToggle.checked && atlassianTokenInput) {
      if (!atlassianTokenInput.value.trim()) {
        showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
      } else {
        hideDependencyWarning('ai-jira-toggle');
      }
    } else {
      hideDependencyWarning('ai-jira-toggle');
    }

    if (aiConfluenceToggle && aiConfluenceToggle.checked && atlassianTokenInput) {
      if (!atlassianTokenInput.value.trim()) {
        showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
      } else {
        hideDependencyWarning('ai-confluence-toggle');
      }
    } else {
      hideDependencyWarning('ai-confluence-toggle');
    }

    if (confluencePreloadToggle && confluencePreloadToggle.checked && atlassianTokenInput) {
      if (!atlassianTokenInput.value.trim()) {
        showDependencyWarning(confluencePreloadToggle, 'Confluence preload requires a JIRA API token (used for Confluence too).');
      } else {
        hideDependencyWarning('confluence-preload-toggle');
      }
    } else {
      hideDependencyWarning('confluence-preload-toggle');
    }

    if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked) {
      if (!aiJiraToggle.checked) {
        showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
      } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
        showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
      } else {
        hideDependencyWarning('show-jira-explanations-toggle');
      }
    } else {
      hideDependencyWarning('show-jira-explanations-toggle');
    }

    if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked) {
      if (!aiConfluenceToggle.checked) {
        showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
      } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
        showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
      } else {
        hideDependencyWarning('show-confluence-explanations-toggle');
      }
    } else {
      hideDependencyWarning('show-confluence-explanations-toggle');
    }

    if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked) {
      if (!aiCommunityToggle.checked) {
        showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
      } else {
        hideDependencyWarning('show-community-explanations-toggle');
      }
    } else {
      hideDependencyWarning('show-community-explanations-toggle');
    }

    // Knowledge Base AI enhancement dependencies
    if (aiCommunityToggle) {
      // Check both AI token and community guides availability
      chrome.storage.local.get(['communityGuides'], (result) => {
        const hasGuides = result.communityGuides && result.communityGuides.length > 0;
        const hasAiToken = aiServiceTokenInput && aiServiceTokenInput.value.trim();

        // Disable the toggle if either requirement is not met
        if (!hasAiToken || !hasGuides) {
          aiCommunityToggle.disabled = true;
          aiCommunityToggle.style.opacity = '0.5';
          aiCommunityToggle.style.cursor = 'not-allowed';

          // Also disable related elements
          if (showCommunityExplanationsToggle) {
            showCommunityExplanationsToggle.disabled = true;
            showCommunityExplanationsToggle.style.opacity = '0.5';
            showCommunityExplanationsToggle.style.cursor = 'not-allowed';
          }
          if (communityAiScoreSettings) {
            communityAiScoreSettings.style.opacity = '0.5';
            communityAiScoreSettings.style.pointerEvents = 'none';
          }
          if (communityMinScoreSlider) {
            communityMinScoreSlider.disabled = true;
          }

          // Show appropriate warning
          if (aiCommunityToggle.checked) {
            if (!hasAiToken && !hasGuides) {
              showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires both an AI Service token and uploaded Knowledge Base JSON data.');
            } else if (!hasAiToken) {
              showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires an AI Service token.');
            } else if (!hasGuides) {
              showDependencyWarning(aiCommunityToggle, 'Knowledge Base AI enhancement requires Knowledge Base JSON data to be uploaded.');
            }
          }
        } else {
          aiCommunityToggle.disabled = false;
          aiCommunityToggle.style.opacity = '1';
          aiCommunityToggle.style.cursor = 'pointer';

          if (showCommunityExplanationsToggle) {
            showCommunityExplanationsToggle.disabled = false;
            showCommunityExplanationsToggle.style.opacity = '1';
            showCommunityExplanationsToggle.style.cursor = 'pointer';
          }
          if (communityAiScoreSettings) {
            communityAiScoreSettings.style.opacity = '1';
            communityAiScoreSettings.style.pointerEvents = 'auto';
          }
          if (communityMinScoreSlider) {
            communityMinScoreSlider.disabled = false;
          }

          hideDependencyWarning('ai-community-toggle');
        }
      });
    }

    if (advancedAiToggle && advancedAiToggle.checked && aiServiceTokenInput) {
      if (!aiServiceTokenInput.value.trim()) {
        showDependencyWarning(advancedAiToggle, 'Advanced AI settings require an AI Service API token.');
      } else {
        hideDependencyWarning('advanced-ai-toggle');
      }
    } else {
      hideDependencyWarning('advanced-ai-toggle');
    }

    if (testAtlassianButton && atlassianTokenInput) {
      testAtlassianButton.disabled = !atlassianTokenInput.value.trim();
    }

    if (testAiButton && aiServiceTokenInput) {
      const hasToken = aiServiceTokenInput.value.trim();
      const hasEndpoint = apiEndpointInput && apiEndpointInput.value.trim();
      const hasAtLeastOneModel = (aiModel1Input && aiModel1Input.value.trim()) ||
        (aiModel2Input && aiModel2Input.value.trim()) ||
        (aiModel3Input && aiModel3Input.value.trim());

      const isConfigured = hasToken && hasEndpoint && hasAtLeastOneModel;
      testAiButton.disabled = !isConfigured;

      // Visual feedback
      if (!isConfigured) {
        testAiButton.style.opacity = '0.5';
        testAiButton.style.cursor = 'not-allowed';
      } else {
        testAiButton.style.opacity = '1';
        testAiButton.style.cursor = 'pointer';
      }
    }
  }

  function setupDependencyListeners() {
    if (advancedAiToggle) {
      advancedAiToggle.addEventListener('change', () => {
        if (helpers.advancedAiSettings) {
          helpers.advancedAiSettings.style.display = advancedAiToggle.checked ? 'block' : 'none';
        }
        manageDependencies();
      });
    }

    if (aiJiraToggle) {
      aiJiraToggle.addEventListener('change', () => {
        if (!aiJiraToggle.checked) {
          const anyAtlassianAiEnabled =
            (aiJiraToggle && aiJiraToggle.checked) ||
            (aiConfluenceToggle && aiConfluenceToggle.checked);

          if (!anyAtlassianAiEnabled && aiFilterToggle && aiFilterToggle.checked) {
            aiFilterToggle.checked = false;
            if (aiScoreSettings) aiScoreSettings.style.display = 'none';
            showStatus('Atlassian AI filtering disabled because no Atlassian AI enhancement is enabled.', 'info');
          }

          if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked) {
            showJiraExplanationsToggle.checked = false;
            showStatus('JIRA explanations disabled because AI JIRA enhancement is disabled.', 'info');
          }
        }

        if (aiJiraToggle.checked && atlassianTokenInput && !atlassianTokenInput.value.trim()) {
          showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
          aiJiraToggle.checked = false;
          showStatus('JIRA API token is required for AI JIRA enhancement', 'error');
        } else {
          hideDependencyWarning('ai-jira-toggle');
        }

        if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked && !aiJiraToggle.checked) {
          showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
        } else {
          hideDependencyWarning('show-jira-explanations-toggle');
        }

        const jiraPanel = document.getElementById('settings-jira');
        if (jiraPanel && jiraPanel.style.display === 'block' && switchContext) {
          switchContext('jira');
        }

        manageDependencies();
      });
    }

    if (aiConfluenceToggle) {
      aiConfluenceToggle.addEventListener('change', () => {
        if (!aiConfluenceToggle.checked) {
          const anyAtlassianAiEnabled =
            (aiJiraToggle && aiJiraToggle.checked) ||
            (aiConfluenceToggle && aiConfluenceToggle.checked);

          if (!anyAtlassianAiEnabled && aiFilterToggle && aiFilterToggle.checked) {
            aiFilterToggle.checked = false;
            if (aiScoreSettings) aiScoreSettings.style.display = 'none';
            showStatus('Atlassian AI filtering disabled because no Atlassian AI enhancement is enabled.', 'info');
          }

          if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked) {
            showConfluenceExplanationsToggle.checked = false;
            showStatus('Confluence explanations disabled because AI Confluence enhancement is disabled.', 'info');
          }
        }

        if (aiConfluenceToggle.checked && atlassianTokenInput && !atlassianTokenInput.value.trim()) {
          showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
          aiConfluenceToggle.checked = false;
          showStatus('JIRA API token is required for AI Confluence enhancement', 'error');
        } else {
          hideDependencyWarning('ai-confluence-toggle');
        }

        if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked && !aiConfluenceToggle.checked) {
          showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
        } else {
          hideDependencyWarning('show-confluence-explanations-toggle');
        }

        const confluencePanel = document.getElementById('settings-confluence');
        if (confluencePanel && confluencePanel.style.display === 'block' && switchContext) {
          switchContext('confluence');
        }

        manageDependencies();
      });
    }

    if (aiCommunityToggle) {
      aiCommunityToggle.addEventListener('change', () => {
        if (!aiCommunityToggle.checked) {
          if (communityAiFilterToggle && communityAiFilterToggle.checked) {
            communityAiFilterToggle.checked = false;
            if (communityAiScoreSettings) communityAiScoreSettings.style.display = 'none';
            showStatus('Community AI filtering disabled because Community AI enhancement is disabled.', 'info');
          }

          if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked) {
            showCommunityExplanationsToggle.checked = false;
            showStatus('Community Guide explanations disabled because AI Community enhancement is disabled.', 'info');
          }
        }

        if (showCommunityExplanationsToggle && showCommunityExplanationsToggle.checked && !aiCommunityToggle.checked) {
          showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
        } else {
          hideDependencyWarning('show-community-explanations-toggle');
        }

        const communityPanel = document.getElementById('settings-community-guides');
        if (communityPanel && communityPanel.style.display === 'block' && switchContext) {
          switchContext('community-guides');
        }

        manageDependencies();
      });
    }

    if (showJiraExplanationsToggle) {
      showJiraExplanationsToggle.addEventListener('change', () => {
        if (showJiraExplanationsToggle.checked) {
          if (!aiJiraToggle.checked) {
            showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require AI JIRA enhancement to be enabled.');
            showJiraExplanationsToggle.checked = false;
            showStatus('JIRA explanations require AI JIRA enhancement to be enabled', 'error');
          } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
            showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
            showJiraExplanationsToggle.checked = false;
            showStatus('JIRA API token is required for JIRA explanations', 'error');
          } else {
            hideDependencyWarning('show-jira-explanations-toggle');
          }
        } else {
          hideDependencyWarning('show-jira-explanations-toggle');
        }
      });
    }

    if (showConfluenceExplanationsToggle) {
      showConfluenceExplanationsToggle.addEventListener('change', () => {
        if (showConfluenceExplanationsToggle.checked) {
          if (!aiConfluenceToggle.checked) {
            showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require AI Confluence enhancement to be enabled.');
            showConfluenceExplanationsToggle.checked = false;
            showStatus('Confluence explanations require AI Confluence enhancement to be enabled', 'error');
          } else if (atlassianTokenInput && !atlassianTokenInput.value.trim()) {
            showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
            showConfluenceExplanationsToggle.checked = false;
            showStatus('JIRA API token is required for Confluence explanations', 'error');
          } else {
            hideDependencyWarning('show-confluence-explanations-toggle');
          }
        } else {
          hideDependencyWarning('show-confluence-explanations-toggle');
        }
      });
    }

    if (showCommunityExplanationsToggle) {
      showCommunityExplanationsToggle.addEventListener('change', () => {
        if (showCommunityExplanationsToggle.checked) {
          if (!aiCommunityToggle.checked) {
            showDependencyWarning(showCommunityExplanationsToggle, 'Community Guide explanations require AI Community enhancement to be enabled.');
          } else {
            hideDependencyWarning('show-community-explanations-toggle');
          }
        } else {
          hideDependencyWarning('show-community-explanations-toggle');
        }
      });
    }

    if (aiServiceTokenInput) {
      aiServiceTokenInput.addEventListener('input', function () {
        if (advancedAiToggle && advancedAiToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(advancedAiToggle, 'Advanced AI settings require an AI Service API token.');
          } else {
            hideDependencyWarning('advanced-ai-toggle');
          }
        }
        manageDependencies();
      });
    }

    if (apiEndpointInput) {
      apiEndpointInput.addEventListener('input', () => {
        manageDependencies();
      });
    }

    if (aiModel1Input) {
      aiModel1Input.addEventListener('input', () => {
        manageDependencies();
      });
    }

    if (aiModel2Input) {
      aiModel2Input.addEventListener('input', () => {
        manageDependencies();
      });
    }

    if (aiModel3Input) {
      aiModel3Input.addEventListener('input', () => {
        manageDependencies();
      });
    }

    if (atlassianTokenInput) {
      atlassianTokenInput.addEventListener('input', function () {
        if (aiJiraToggle && aiJiraToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(aiJiraToggle, 'JIRA AI enhancement requires a JIRA API token.');
          } else {
            hideDependencyWarning('ai-jira-toggle');
          }
        }

        if (aiConfluenceToggle && aiConfluenceToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(aiConfluenceToggle, 'Confluence AI enhancement requires a JIRA API token (used for Confluence too).');
          } else {
            hideDependencyWarning('ai-confluence-toggle');
          }
        }

        if (confluencePreloadToggle && confluencePreloadToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(confluencePreloadToggle, 'Confluence preload requires a JIRA API token (used for Confluence too).');
          } else {
            hideDependencyWarning('confluence-preload-toggle');
          }
        }

        if (showJiraExplanationsToggle && showJiraExplanationsToggle.checked && aiJiraToggle && aiJiraToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(showJiraExplanationsToggle, 'JIRA explanations require a valid JIRA API token.');
          } else {
            hideDependencyWarning('show-jira-explanations-toggle');
          }
        }

        if (showConfluenceExplanationsToggle && showConfluenceExplanationsToggle.checked && aiConfluenceToggle && aiConfluenceToggle.checked) {
          if (!this.value.trim()) {
            showDependencyWarning(showConfluenceExplanationsToggle, 'Confluence explanations require a valid Atlassian API token.');
          } else {
            hideDependencyWarning('show-confluence-explanations-toggle');
          }
        }

        if (testAtlassianButton) {
          testAtlassianButton.disabled = !this.value.trim();
        }
      });
    }

    if (aiGlobalEnable) {
      aiGlobalEnable.addEventListener('change', () => {
        if (helpers.aiTestSection) {
          helpers.aiTestSection.style.display = aiGlobalEnable.checked ? 'block' : 'none';
        }
        setAiMasterAvailability(!!aiGlobalEnable.checked);
        if (!aiGlobalEnable.checked) {
          showStatus('Global AI is disabled; AI-dependent toggles are unavailable until enabled.', 'info');
        }
      });
    }
  }

  return {
    createContextWarning,
    manageDependencies,
    setupDependencyListeners,
    showDependencyWarning,
    hideDependencyWarning
  };
}
