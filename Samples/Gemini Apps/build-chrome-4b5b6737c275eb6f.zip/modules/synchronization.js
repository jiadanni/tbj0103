/**
 * Synchronization Utilities
 * Provides primitives for managing concurrency and state consistency
 */

/**
 * A simple async Mutex lock
 * Ensures restricted access to a resource
 */
export class Mutex {
  constructor() {
    this._queue = [];
    this._locked = false;
  }

  isLocked() {
    return this._locked;
  }

  /**
   * Acquire the lock.
   * If strictly one-at-a-time access is needed, await this method.
   * @returns {Promise<Function>} A release function to be called when done.
   */
  lock() {
    return new Promise((resolve) => {
      const release = () => {
        if (this._queue.length > 0) {
          const next = this._queue.shift();
          next();
        } else {
          this._locked = false;
        }
      };

      if (this._locked) {
        this._queue.push(() => resolve(release));
      } else {
        this._locked = true;
        resolve(release);
      }
    });
  }

  /**
   * Run a task while holding the lock
   * @param {Function} task - Async function to execute
   */
  async runExclusive(task) {
    const release = await this.lock();
    try {
      return await task();
    } finally {
      release();
    }
  }
}
