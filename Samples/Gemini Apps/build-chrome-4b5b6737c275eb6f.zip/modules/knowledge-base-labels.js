import { createLogger } from './logger.js';

const logger = createLogger('KnowledgeBaseLabels');
const DEFAULT_LABEL = 'Knowledge Base';

export async function getKnowledgeBaseLabels() {
  try {
    const { knowledgeBaseLabels } = await chrome.storage.local.get('knowledgeBaseLabels');
    const entryLabel = knowledgeBaseLabels?.entryLabel?.trim() || DEFAULT_LABEL;
    const sidebarLabel = knowledgeBaseLabels?.sidebarLabel?.trim() || entryLabel;
    return { entryLabel, sidebarLabel };
  } catch (e) {
    logger.warn('Failed to load knowledge base labels, using defaults', 'getKnowledgeBaseLabels', e);
    return { entryLabel: DEFAULT_LABEL, sidebarLabel: DEFAULT_LABEL };
  }
}

export const DEFAULT_KB_LABELS = { entryLabel: DEFAULT_LABEL, sidebarLabel: DEFAULT_LABEL };
