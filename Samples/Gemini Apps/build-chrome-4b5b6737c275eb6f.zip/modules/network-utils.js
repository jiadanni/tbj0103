/**
 * Network Utilities Module
 * Shared networking helpers including timeout-wrapped fetch.
 * 
 * @module utils/network-utils
 */

import { createLogger } from './logger.js';

const logger = createLogger('NetworkUtils');

/**
 * Fetch with timeout helper.
 * Wraps the standard fetch API with a timeout to prevent hanging requests.
 * 
 * @param {string} url - The URL to fetch
 * @param {Object} [options={}] - Fetch options
 * @param {number} [timeout=30000] - Timeout in milliseconds (default: 30s)
 * @returns {Promise<Response>} The fetch response
 * @throws {Error} Throws AbortError on timeout or other fetch errors
 */
export async function fetchWithTimeout(url, options = {}, timeout = 30000) {
    const controller = new AbortController();

    // If the caller provided a signal, we need to respect it
    if (options.signal) {
        if (options.signal.aborted) {
            throw new DOMException('The operation was aborted.', 'AbortError');
        }
        options.signal.addEventListener('abort', () => controller.abort());
    }

    const id = setTimeout(() => controller.abort(), timeout);

    try {
        const fetchOptions = { ...options, signal: controller.signal };
        const resp = await fetch(url, fetchOptions);
        clearTimeout(id);
        return resp;
    } catch (err) {
        clearTimeout(id);
        if (err.name === 'AbortError') {
            // Differentiate between caller abort and timeout abort if possible, 
            // but generally timeout is the main reason we abort internally.
            // If we could check options.signal.aborted, we'd know if it was external.
            if (options.signal?.aborted) {
                logger.debug('Request aborted by caller', 'fetchWithTimeout', { url });
                throw err; // Re-throw original AbortError
            }

            logger.debug('Request timed out', 'fetchWithTimeout', { url, timeout });
            const abortErr = new Error('Request timed out');
            abortErr.name = 'AbortError';
            throw abortErr;
        }
        logger.warn('Fetch failed', 'fetchWithTimeout', { url, error: err.message });
        throw err;
    }
}
