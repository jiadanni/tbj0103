/**
 * messaging.js
 *
 * Centralized messaging utilities for communication between extension components.
 */

import { MESSAGE_RESPONSE_TIMEOUT_MS } from '../config/constants.js';
import { createLogger } from './logger.js';

const logger = createLogger('Messaging');

/**
 * Sends a message with a timeout.
 * @param {Object} message - The message payload.
 * @param {number} timeout - Timeout in milliseconds.
 * @returns {Promise<any>}
 */
export async function sendMessageWithTimeout(message, timeout = MESSAGE_RESPONSE_TIMEOUT_MS) {
    return new Promise((resolve, reject) => {
        let done = false;
        const timer = setTimeout(() => {
            if (!done) {
                done = true;
                reject(new Error(`No response from background (timeout after ${timeout}ms)`));
            }
        }, timeout);

        try {
            chrome.runtime.sendMessage(message, (resp) => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                const lastErr = chrome.runtime.lastError;
                if (lastErr) return reject(lastErr);
                resolve(resp);
            });
        } catch (err) {
            if (!done) {
                done = true;
                clearTimeout(timer);
                logger.warn('Message sending failed', 'sendMessageWithTimeout', err);
                reject(err);
            }
        }
    });
}
