import { createLogger } from '../utils/logger.js';

const logger = createLogger('LocalSearch');

export function setupLocalSearchControls({
  elements,
  helpers,
  permissions,
  checkLocalServer
}) {
  const {
    localSearchUrlInput,
    requestLocalPermissionButton,
    checkLocalPermissionButton,
    listGrantedOriginsButton,
    revokeLocalOriginsButton,
    localSearchEnableToggle,
    checkLocalServerButton,
    localServerStatusElement,
    permissionModalBackdrop,
    permissionModalOrigin,
    permissionAccept,
    permissionDecline
  } = elements;

  const { showSectionStatus, showStatus } = helpers;
  const { buildOriginFromUrl, requestHostPermission, checkHostPermission } = permissions;

  if (checkLocalServerButton && checkLocalServer) {
    checkLocalServerButton.addEventListener('click', checkLocalServer);
  }

  if (requestLocalPermissionButton) {
    requestLocalPermissionButton.addEventListener('click', async () => {
      if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
        showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
        return;
      }
      const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
      if (!origin) {
        showSectionStatus(localServerStatusElement, 'Invalid Local Search Server URL', 'error');
        return;
      }

      showSectionStatus(localServerStatusElement, `Requesting permission for ${origin}...`, 'info');
      const granted = await requestHostPermission(origin);
      if (granted) {
        showSectionStatus(localServerStatusElement, `Permission granted for ${origin}`, 'success');
        if (localSearchEnableToggle) localSearchEnableToggle.checked = true;
        if (checkLocalServerButton) checkLocalServerButton.disabled = false;
        try { chrome.storage.local.set({ localSearchEnabled: true }); } catch (e) { logger.debug('Error setting localSearchEnabled (granted)', 'local-search', e); }
      } else {
        showSectionStatus(localServerStatusElement, `Permission denied for ${origin}`, 'error');
      }
    });
  }

  if (checkLocalPermissionButton) {
    checkLocalPermissionButton.addEventListener('click', async () => {
      if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
        showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
        return;
      }
      const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
      if (!origin) {
        showSectionStatus(localServerStatusElement, 'Invalid Local Search Server URL', 'error');
        return;
      }
      const has = await checkHostPermission(origin);
      showSectionStatus(localServerStatusElement, has ? `Permission is present for ${origin}` : `No permission for ${origin}`, has ? 'success' : 'error');
    });
  }

  if (listGrantedOriginsButton) {
    listGrantedOriginsButton.addEventListener('click', async () => {
      if (!chrome.permissions || !chrome.permissions.getAll) {
        showSectionStatus(localServerStatusElement, 'Permissions API not available in this context', 'error');
        return;
      }
      chrome.permissions.getAll((perms) => {
        const origins = perms.origins || [];
        if (origins.length === 0) {
          showSectionStatus(localServerStatusElement, 'No origins currently granted to this extension', 'info');
        } else {
          showSectionStatus(localServerStatusElement, `Granted origins:\n${origins.join('\n')}`, 'info');
        }
      });
    });
  }

  if (revokeLocalOriginsButton) {
    revokeLocalOriginsButton.addEventListener('click', async () => {
      if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
        showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
        return;
      }
      try {
        const u = new URL(localSearchUrlInput.value.trim());
        const portPart = u.port ? `:${u.port}` : '';
        const origin1 = `${u.protocol}//127.0.0.1${portPart}/*`;
        const origin2 = `${u.protocol}//localhost${portPart}/*`;

        const removalResults = [];
        if (chrome.permissions && chrome.permissions.remove) {
          await new Promise((resolve) => {
            chrome.permissions.remove({ origins: [origin1] }, (removed) => {
              removalResults.push({ origin: origin1, removed });
              chrome.permissions.remove({ origins: [origin2] }, (removed2) => {
                removalResults.push({ origin: origin2, removed: removed2 });
                resolve();
              });
            });
          });

          const msgs = removalResults.map(r => `${r.origin}: ${r.removed ? 'revoked' : 'not present'}`);
          showSectionStatus(localServerStatusElement, `Revoke results:\n${msgs.join('\n')}`, 'info');
          if (localSearchEnableToggle) localSearchEnableToggle.checked = false;
          if (checkLocalServerButton) checkLocalServerButton.disabled = true;
          try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger.debug('Error setting localSearchEnabled (revoke)', 'local-search', e); }
        } else {
          showSectionStatus(localServerStatusElement, 'Permissions API remove not available', 'error');
        }
      } catch (err) {
        logger.debug('Error in origin revocation:', 'local-search', err);
        showSectionStatus(localServerStatusElement, `Invalid URL: ${err.message}`, 'error');
      }
    });
  }

  if (localSearchEnableToggle) {
    function showPermissionModal(origin) {
      if (!permissionModalBackdrop) return;
      if (permissionModalOrigin) permissionModalOrigin.textContent = origin || '';
      permissionModalBackdrop.style.display = 'flex';
    }

    function hidePermissionModal() {
      if (!permissionModalBackdrop) return;
      permissionModalBackdrop.style.display = 'none';
    }

    localSearchEnableToggle.addEventListener('change', () => {
      if (localSearchEnableToggle.checked && localSearchUrlInput && localSearchUrlInput.value.trim()) {
        const origin = buildOriginFromUrl(localSearchUrlInput.value.trim());
        if (!origin) {
          showStatus('Invalid Local Search Server URL', 'error');
          localSearchEnableToggle.checked = false;
          if (checkLocalServerButton) checkLocalServerButton.disabled = true;
          return;
        }

        showPermissionModal(origin);

        const acceptHandler = async () => {
          hidePermissionModal();
          const granted = await requestHostPermission(origin);
          if (!granted) {
            showStatus('Permission to access the configured Local Search Server was denied. Local search remains disabled.', 'error');
            localSearchEnableToggle.checked = false;
            if (checkLocalServerButton) checkLocalServerButton.disabled = true;
            try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger.debug('Error setting localSearchEnabled', 'local-search', e); }
            return;
          }
          if (checkLocalServerButton) checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
          showStatus('Local vector search enabled.', 'success');
          try { chrome.storage.local.set({ localSearchEnabled: true }); } catch (e) { logger.debug('Error setting localSearchEnabled', 'local-search', e); }
          permissionAccept.removeEventListener('click', acceptHandler);
          permissionDecline.removeEventListener('click', declineHandler);
        };

        const declineHandler = () => {
          hidePermissionModal();
          localSearchEnableToggle.checked = false;
          if (checkLocalServerButton) checkLocalServerButton.disabled = true;
          showStatus('Local search permission request cancelled.', 'info');
          try { chrome.storage.local.set({ localSearchEnabled: false }); } catch (e) { logger.debug('Error setting localSearchEnabled (cancel)', 'local-search', e); }
          permissionAccept.removeEventListener('click', acceptHandler);
          permissionDecline.removeEventListener('click', declineHandler);
        };

        permissionAccept.addEventListener('click', acceptHandler);
        permissionDecline.addEventListener('click', declineHandler);
      } else {
        if (checkLocalServerButton) checkLocalServerButton.disabled = !localSearchEnableToggle.checked;
        showStatus(localSearchEnableToggle.checked ? 'Local vector search enabled.' : 'Local vector search disabled. Test button is unavailable.', 'info');
        try { chrome.storage.local.set({ localSearchEnabled: !!localSearchEnableToggle.checked }); } catch (e) { logger.debug('Error setting localSearchEnabled', 'local-search', e); }
      }
    });
  }
}
