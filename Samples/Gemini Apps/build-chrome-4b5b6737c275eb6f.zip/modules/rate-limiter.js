/**
 * Rate Limiter Utility
 * Implements token bucket algorithm to prevent overwhelming external services
 */

import { RATE_LIMIT_CONFIG } from '../config/constants.js';
import { createLogger } from './logger.js';

const logger = createLogger('RateLimiter');

class RateLimiter {
  constructor(options = {}) {
    this.maxTokens = options.maxTokens || 10; // Max requests in window
    this.refillRate = options.refillRate || 1; // Tokens added per interval
    this.refillInterval = options.refillInterval || 1000; // Interval in ms
    this.tokens = this.maxTokens;
    this.lastRefill = Date.now();
    this.queue = [];
    this.isProcessing = false;
  }

  /**
   * Refills tokens based on elapsed time since last refill
   */
  refill() {
    const now = Date.now();
    const elapsed = now - this.lastRefill;
    const tokensToAdd = Math.floor(elapsed / this.refillInterval) * this.refillRate;

    if (tokensToAdd > 0) {
      this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
      // Advance lastRefill by the amount of time accounted for by the tokens added
      this.lastRefill += tokensToAdd * (this.refillInterval / this.refillRate);
    }

    this.processQueue();
  }

  /**
   * Acquires a token to make a request
   * Supports cancellation via AbortSignal while waiting in the queue.
   * @returns {Promise<void>} Resolves when token is available
   */
  async acquire(signal = null) {
    this.refill();
    if (this.tokens > 0) {
      this.tokens--;
      return Promise.resolve();
    }

    // Queue the request
    return new Promise((resolve, reject) => {
      const entry = { resolve, reject, cleanup: null };
      this.queue.push(entry);

      if (!signal) return;

      // Handle already-aborted signals
      if (signal.aborted) {
        this.queue = this.queue.filter(item => item !== entry);
        reject(new DOMException('Request aborted while waiting for rate limit', 'AbortError'));
        return;
      }

      const abortHandler = () => {
        this.queue = this.queue.filter(item => item !== entry);
        reject(new DOMException('Request aborted while waiting for rate limit', 'AbortError'));
      };

      signal.addEventListener('abort', abortHandler, { once: true });
      entry.cleanup = () => signal.removeEventListener('abort', abortHandler);
    });
  }

  /**
   * Processes queued requests when tokens become available
   */
  processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (this.queue.length > 0 && this.tokens > 0) {
      this.tokens--;
      const entry = this.queue.shift();
      entry?.cleanup?.();
      entry?.resolve?.();
    }

    this.isProcessing = false;
  }

  /**
   * Executes a function with rate limiting
   * @param {Function} fn - Function to execute
   * @param {AbortSignal} signal - Optional abort signal for cancellation
   * @returns {Promise<*>} Result of the function
   */
  async execute(fn, signal = null) {
    // Check if already aborted
    if (signal?.aborted) {
      throw new DOMException('Request aborted before execution', 'AbortError');
    }

    // Wait for token
    await this.acquire(signal);

    // Check again after waiting
    if (signal?.aborted) {
      // Return token since we didn't use it
      this.tokens = Math.min(this.maxTokens, this.tokens + 1);
      throw new DOMException('Request aborted while waiting for rate limit', 'AbortError');
    }

    // Execute function
    return fn();
  }

  /**
   * Cleans up the rate limiter
   */
  destroy() {
    this.tokens = 0;
    // Reject all queued requests
    this.queue.forEach(entry => {
      entry?.cleanup?.();
      entry?.resolve?.();
    });
    this.queue = [];
  }

  /**
   * Gets current state for debugging
   */
  getState() {
    return {
      tokens: this.tokens,
      queueLength: this.queue.length,
      maxTokens: this.maxTokens
    };
  }
}

/**
 * Rate limiter with exponential backoff for failed requests
 */
class RateLimiterWithBackoff extends RateLimiter {
  constructor(options = {}) {
    super(options);
    this.backoffMultiplier = options.backoffMultiplier || 2;
    this.maxBackoff = options.maxBackoff || 30000; // 30 seconds max
    this.baseDelay = options.baseDelay || 1000; // 1 second base
    this.backoffState = new Map(); // Track backoff per endpoint
  }

  /**
   * Executes function with exponential backoff on failure
   * @param {Function} fn - Function to execute
   * @param {string} endpoint - Endpoint identifier for backoff tracking
   * @param {AbortSignal} signal - Optional abort signal
   * @returns {Promise<*>}
   */
  async executeWithBackoff(fn, endpoint = 'default', signal = null) {
    // Check for existing backoff
    const backoffEntry = this.backoffState.get(endpoint);
    if (backoffEntry && Date.now() < backoffEntry.until) {
      const waitTime = backoffEntry.until - Date.now();
      logger.warn(`Rate limiter: Endpoint ${endpoint} in backoff, waiting ${waitTime}ms`, 'rate-limiter', undefined);

      // Wait for backoff to expire or abort
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(resolve, waitTime);

        if (signal) {
          const abortHandler = () => {
            clearTimeout(timeout);
            reject(new DOMException('Request aborted during backoff', 'AbortError'));
          };
          signal.addEventListener('abort', abortHandler);

          // Clean up listener when promise settles
          const cleanup = () => signal.removeEventListener('abort', abortHandler);
          Promise.resolve().then(() => {
            setTimeout(cleanup, 0);
          });
        }
      });
    }

    try {
      const result = await this.execute(fn, signal);
      // Success - clear backoff
      this.backoffState.delete(endpoint);
      return result;
    } catch (error) {
      logger.debug('Execution failed in rate limiter', 'rate-limiter', error);
      // Check if it's a rate limit error (429) or server error (5xx)
      const shouldBackoff = error.status === 429 ||
        (error.status >= 500 && error.status < 600);

      if (shouldBackoff) {
        const currentAttempt = backoffEntry?.attempts || 0;
        const delay = Math.min(
          this.baseDelay * Math.pow(this.backoffMultiplier, currentAttempt),
          this.maxBackoff
        );

        this.backoffState.set(endpoint, {
          attempts: currentAttempt + 1,
          until: Date.now() + delay
        });

        logger.warn(`Rate limiter: Backing off endpoint ${endpoint} for ${delay}ms`, 'rate-limiter', undefined);
      }

      throw error;
    }
  }

  /**
   * Clears backoff state for an endpoint
   */
  clearBackoff(endpoint) {
    this.backoffState.delete(endpoint);
  }

  destroy() {
    super.destroy();
    this.backoffState.clear();
  }
}

// Create default rate limiters for different services
const rateLimiters = {
  ai: new RateLimiterWithBackoff({
    maxTokens: RATE_LIMIT_CONFIG.ai.maxTokens,
    refillRate: RATE_LIMIT_CONFIG.ai.refillRate,
    refillInterval: RATE_LIMIT_CONFIG.ai.refillIntervalMs,
    baseDelay: RATE_LIMIT_CONFIG.ai.baseDelayMs,
    maxBackoff: RATE_LIMIT_CONFIG.ai.maxBackoffMs
  }),

  atlassian: new RateLimiterWithBackoff({
    maxTokens: RATE_LIMIT_CONFIG.atlassian.maxTokens,
    refillRate: RATE_LIMIT_CONFIG.atlassian.refillRate,
    refillInterval: RATE_LIMIT_CONFIG.atlassian.refillIntervalMs,
    baseDelay: RATE_LIMIT_CONFIG.atlassian.baseDelayMs,
    maxBackoff: RATE_LIMIT_CONFIG.atlassian.maxBackoffMs
  }),

  local: new RateLimiter({
    maxTokens: RATE_LIMIT_CONFIG.local.maxTokens,
    refillRate: RATE_LIMIT_CONFIG.local.refillRate,
    refillInterval: RATE_LIMIT_CONFIG.local.refillIntervalMs
  })
};

const cleanupRateLimiters = () => {
  Object.values(rateLimiters).forEach(limiter => limiter.destroy());
};

// Cleanup on unload/pagehide (content/background pages)
if (typeof window !== 'undefined') {
  window.addEventListener('unload', cleanupRateLimiters);
  window.addEventListener('pagehide', cleanupRateLimiters);
}

// Cleanup on MV3 service worker suspend if available
if (typeof chrome !== 'undefined' && chrome.runtime?.onSuspend) {
  chrome.runtime.onSuspend.addListener(cleanupRateLimiters);
}

export { RateLimiter, RateLimiterWithBackoff, rateLimiters, cleanupRateLimiters };
