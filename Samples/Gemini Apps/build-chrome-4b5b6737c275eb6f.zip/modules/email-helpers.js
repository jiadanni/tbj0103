/**
 * Email Helpers Module
 * Utilities for cleaning, filtering, and generating email content
 *
 * @module email-helpers
 */

/**
 * Clean email content by removing signatures, salutations, and boilerplate.
 * Strips institutional headers, contact info, and legal disclaimers to extract
 * the main message body. Uses pattern matching to identify unwanted content.
 *
 * @param {string} emailText - Raw email text (may contain signatures and boilerplate)
 * @returns {string} Cleaned email content (main message body only)
 * @example
 * cleanEmailContent('Hi,\nPlease help.\nBest regards\nJohn')
 * // Returns: 'Hi,\nPlease help.'
 */
export function cleanEmailContent(emailText) {
  if (!emailText || typeof emailText !== 'string') {
    return '';
  }

  // Common salutation patterns that indicate end of relevant content
  const salutationPatterns = [
    /\b(best regards?|regards|sincerely|thank you|thanks|cheers|best)\b/i,
    /\b(kind regards|warm regards|many thanks|with appreciation)\b/i,
    /\b(looking forward|hope this helps|let me know)\b/i,
    /\b(please let me know|feel free to|don't hesitate)\b/i,
    /\b(have a (?:great|good|wonderful) day|have a (?:great|good|wonderful) (?:week|weekend))\b/i
  ];

  // Common signature indicators
  const signaturePatterns = [
    /^[-_=]+$/m, // Lines of dashes, underscores, or equals
    /\b(?:this (?:email|message) is (?:confidential|privileged))/i,
    /\b(?:confidentiality notice|legal disclaimer|privacy notice)\b/i,
    /\b(?:sent from my (?:iphone|ipad|android|mobile|phone))/i,
    /\b(?:virus|malware) free/i,
    /\b(?:scanned by|protected by|powered by)\b/i,
    /\b(?:unsubscribe|opt[- ]?out)\b/i,
    /\b(?:copyright|©|\(c\)) \d{4}/i,
    /\b(?:phone|tel|mobile|fax|email|e-mail):\s*[\+\d\(\)\-\.\s]+/i,
    /\b[\w\.-]+@[\w\.-]+\.\w+\b.*$/m, // Email addresses at end of lines
    /\bhttps?:\/\/[\w\.-]+/i, // URLs often in signatures
    /\b(?:www\.[\w\.-]+\.\w+)/i // Website addresses
  ];

  // Institution-specific patterns
  const institutionPatterns = [
    /\b(?:university|college|school|district|department) of \w+/i,
    /\b\w+ (?:university|college|school|district)\b/i,
    /\b(?:office of|department of) \w+/i,
    /\b(?:instructional|educational|academic|student|faculty) \w+/i,
    /\b(?:title ix|ferpa|hipaa|ada|section 508) \w*/i,
    /\b(?:equal opportunity|non[- ]?discrimination|accessibility)\b/i
  ];

  // Split into lines for analysis
  const lines = emailText.split('\n').map(line => line.trim());
  const cleanLines = [];
  let foundSalutation = false;
  let foundSignature = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Skip empty lines
    if (line.length === 0) {
      // Keep empty lines before salutation/signature
      if (!foundSalutation && !foundSignature) {
        cleanLines.push(line);
      }
      continue;
    }

    // Check for salutations
    if (!foundSalutation) {
      for (const pattern of salutationPatterns) {
        if (pattern.test(line)) {
          foundSalutation = true;
          break;
        }
      }
    }

    // Check for signature patterns
    if (!foundSignature) {
      for (const pattern of [...signaturePatterns, ...institutionPatterns]) {
        if (pattern.test(line)) {
          foundSignature = true;
          break;
        }
      }
    }

    // If we found a salutation or signature indicator, stop including content
    if (foundSalutation || foundSignature) {
      break;
    }

    // Check if line looks like contact info or institutional boilerplate
    const isBoilerplate =
      /^\s*[-_=]{3,}\s*$/.test(line) || // Separator lines
      /^[\s\*\-\+]{0,3}(?:phone|tel|mobile|fax|email|office|address)[\s:]/i.test(line) || // Contact info
      line.length > 100 && (/\b(?:confidential|disclaimer|copyright|privacy|legal)\b/i.test(line)) || // Long legal text
      /^\s*\w+\s+\w+\s*$/.test(line) && i > lines.length - 5; // Name-like pattern near end

    if (!isBoilerplate) {
      cleanLines.push(line);
    }
  }

  // Join back together and clean up
  let cleanedEmail = cleanLines.join('\n').trim();

  // Basic HTML sanitization: Strip tags for defense-in-depth if rendering in HTML context
  // This is a simple regex-based strip which is sufficient for plain text extraction
  cleanedEmail = cleanedEmail.replace(/<[^>]*>?/gm, '');

  // Remove common email artifacts
  cleanedEmail = cleanedEmail
    .replace(/^>+\s*/gm, '') // Remove quote markers
    .replace(/^From:\s*.*/gm, '') // Remove "From:" headers
    .replace(/^Sent:\s*.*/gm, '') // Remove "Sent:" headers
    .replace(/^To:\s*.*/gm, '') // Remove "To:" headers
    .replace(/^Subject:\s*.*/gm, '') // Remove "Subject:" headers
    .replace(/^\s*[-_=]{3,}\s*$/gm, '') // Remove separator lines
    .replace(/\n{3,}/g, '\n\n') // Collapse multiple line breaks
    .trim();

  return cleanedEmail;
}

/**
 * Filter imported email text - stops at original message divider.
 * Extracts only the new reply/forward content by detecting standard dividers
 * like "---- Original Message ----" or "On ... wrote:".
 *
 * @param {string} emailText - Email text to filter (may contain original message)
 * @returns {string} Filtered email text (only the new/reply content, trimmed)
 * @example
 * filterImportedEmailText('Your reply here\n---- Original Message ----\nOld stuff')
 * // Returns: 'Your reply here'
 */
export function filterImportedEmailText(emailText) {
  if (!emailText || typeof emailText !== 'string') {
    return '';
  }

  // Common original message divider patterns
  const originalMessagePatterns = [
    /^-+\s*Original Message\s*-+/im,
    /^=+\s*Original Message\s*=+/im,
    /^_{3,}\s*Original Message\s*_{3,}/im,
    /^-{10,}/im, // Just a line of dashes (10 or more)
    /^={10,}/im, // Just a line of equals (10 or more)
    /^_{10,}/im, // Just a line of underscores (10 or more)
    /^From:\s*.*\n.*Sent:/im, // Outlook-style forwarded message header
    /^On\s+.*wrote:/im, // Gmail-style quoted text
    /^\s*>.*wrote:/im // Another quoted text pattern
  ];

  let earliestMatch = null;
  let earliestIndex = emailText.length;

  // Find the earliest occurrence of any pattern
  for (const pattern of originalMessagePatterns) {
    const match = emailText.match(pattern);
    if (match && match.index < earliestIndex) {
      earliestIndex = match.index;
      earliestMatch = match;
    }
  }

  if (earliestMatch) {
    // Found a divider, return everything before it
    return emailText.substring(0, earliestIndex).trim();
  }

  // No divider found, return original text
  return emailText.trim();
}

/**
 * Generate email signature based on case data.
 * Creates a formatted signature line that includes case owner and product family
 * information. Falls back to generic salutation if data is not available.
 *
 * @param {Object} [caseData={}] - Case information for signature
 * @param {string} [caseData.caseOwner] - Name of the case owner (e.g., "John Smith")
 * @param {string} [caseData.productFamily] - Product family name (e.g., "Canvas LMS")
 * @returns {string} Formatted email signature with newlines ready for appending to email
 * @example
 * generateEmailSignature({ caseOwner: 'Jane Doe', productFamily: 'Canvas' })
 * // Returns: '\n\nKind regards,\nJane Doe\nCanvas Support'
 */
export function generateEmailSignature(caseData = {}) {
  const caseOwner = caseData.caseOwner;
  const productFamily = caseData.productFamily;

  // Check if case owner contains "queue" (case-insensitive)
  // If so, don't include it in the signature as the ticket hasn't been assigned yet
  const isQueueOwner = caseOwner && caseOwner.toLowerCase().includes('queue');

  // If no data can be extracted, just show "Kind regards"
  if ((!caseOwner || isQueueOwner) && !productFamily) {
    return `\n\nKind regards`;
  }

  // Exclude queue owners from signature - only show product support line
  if (isQueueOwner) {
    const product = productFamily || '{Product Family}';
    return `\n\nKind regards,\n${product} Support`;
  }

  const owner = caseOwner || '{Case Owner}';
  const product = productFamily || '{Product Family}';

  return `\n\nKind regards,\n${owner}\n${product} Support`;
}
