/**
 * Retry Utilities Module
 * Provides retry logic for async operations
 * 
 * @module utils/retry-utils
 */

import { createLogger } from './logger.js';

const logger = createLogger('RetryUtils');

/**
 * Retry an async operation with exponential backoff
 * @param {Function} fn - Async function to retry
 * @param {Object} options - Retry options
 * @param {number} [options.maxRetries=2] - Maximum number of retries
 * @param {number} [options.baseDelay=1000] - Base delay in ms for exponential backoff
 * @param {number} [options.maxDelay=30000] - Maximum delay in ms
 * @param {Function} [options.shouldRetry] - Optional function to determine if error should trigger retry
 * @returns {Promise<*>} Result of the function
 */
export async function withRetry(fn, options = {}) {
    const {
        maxRetries = 2,
        baseDelay = 1000,
        maxDelay = 30000,
        shouldRetry = () => true
    } = options;

    let lastError;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;

            // Don't retry if this is the last attempt or if shouldRetry returns false
            if (attempt === maxRetries || !shouldRetry(error)) {
                logger.debug('Operation failed, not retrying', 'withRetry', { error: error.message, attempt });
                throw error;
            }

            // Calculate delay with exponential backoff
            const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);

            logger.debug(`Retry attempt ${attempt + 1}/${maxRetries} after ${delay}ms`, 'withRetry', {
                error: error.message
            });

            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }

    throw lastError;
}

/**
 * Wrap fetch with retry logic
 * @param {string} url - URL to fetch
 * @param {Object} [options={}] - Fetch options
 * @param {Object} [retryOptions={}] - Retry configuration
 * @param {number} [retryOptions.maxRetries=2] - Maximum retries
 * @param {number} [retryOptions.timeout=15000] - Timeout per request in ms
 * @param {AbortSignal} [retryOptions.signal] - External abort signal
 * @returns {Promise<Response>} Fetch response
 */
export async function fetchWithRetry(url, options = {}, retryOptions = {}) {
    const {
        maxRetries = 2,
        timeout = 15000,
        signal: externalSignal
    } = retryOptions;

    return withRetry(
        async () => {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeout);

            // Handle external abort signal
            if (externalSignal) {
                if (externalSignal.aborted) {
                    clearTimeout(timeoutId);
                    throw new DOMException('Request cancelled by user', 'AbortError');
                }
                externalSignal.addEventListener('abort', () => {
                    clearTimeout(timeoutId);
                    controller.abort();
                }, { once: true });
            }

            try {
                const response = await fetch(url, {
                    ...options,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                return response;
            } catch (error) {
                clearTimeout(timeoutId);
                logger.debug('Fetch error in retry loop', 'fetchWithRetry', { error: error.message });
                if (error.name === 'AbortError') {
                    if (externalSignal?.aborted) {
                        throw new DOMException('Request cancelled by user', 'AbortError');
                    }
                    throw new DOMException('Request timed out', 'AbortError');
                }
                throw error;
            }
        },
        {
            maxRetries,
            shouldRetry: (error) => {
                // Don't retry if user cancelled
                if (error.name === 'AbortError' && externalSignal?.aborted) {
                    return false;
                }
                // Retry on network errors and timeouts
                return true;
            }
        }
    );
}
