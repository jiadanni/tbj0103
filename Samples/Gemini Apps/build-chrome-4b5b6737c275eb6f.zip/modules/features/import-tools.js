// modules/sidebar/features/import-tools.js

import { createLogger } from '../../utils/logger.js';
import { Result } from '../../utils/result.js';
import { EmailExtractor } from '../strategies/email-extractor.js';
import { ChatterExtractor } from '../strategies/chatter-extractor.js';
import { SelectionExtractor } from '../strategies/selection-extractor.js';
import * as ShadowDomUtils from '../strategies/shadow-dom-utils.js';

const logger = createLogger('ImportTools');

/**
 * Capture the text the user has typed into the main Chatter publisher box.
 * @returns {Result<string>}
 */
export async function getOperatorInputText(sidebar) {
    try {
        const extractor = new ChatterExtractor(sidebar);
        const text = await extractor.execute();
        return Result.success(text || '');
    } catch (e) {
        logger.warn('Error getting operator input text', 'import-tools', e);
        return Result.failure(e);
    }
}

/**
 * Check if an element is within the sidebar
 */
export function isElementInSidebar(sidebar, element) {
    return ShadowDomUtils.isElementInSidebar(sidebar, element);
}

/**
 * Extract text from an element using multiple methods
 */
export function extractTextFromElement(_sidebar, element) {
    if (ShadowDomUtils.isTextEntryElement(element)) {
        if (element.value) return element.value.trim();
        if (element.innerText) return element.innerText.trim();
        return element.textContent?.trim();
    }
    return null;
}

/**
 * Handle importing text and case context into the original text input
 * @returns {Promise<Result<string>>} The imported text on success
 */
export async function handleImportText(sidebar, overrideText) {
    // Prevent re-entrancy / infinite recursion
    if (handleImportText.isExecuting) {
        logger.warn('Prevented recursive call to handleImportText', 'import-tools');
        return Result.failure(new Error('Import already in progress'));
    }

    const originalInput = sidebar.sidebar.querySelector('#original-text-input');
    if (!originalInput) {
        return Result.failure(new Error('Input field not found'));
    }

    handleImportText.isExecuting = true;
    try {
        logger.info('=== Import Text Debug ===', 'import-tools', undefined);
        let importedText = '';
        let source = '';

        // Priority 0: Explicit override from caller
        if (overrideText && typeof overrideText === 'string' && overrideText.trim().length > 0) {
            importedText = overrideText.trim();
            source = 'Provided Text';
            logger.debug('✓ Using provided text:', 'import-tools', importedText.substring(0, 50) + '...');
        }

        // Priority 1: Email Content
        if (!importedText) {
            const emailStrategy = new EmailExtractor(sidebar);
            let emailText = await emailStrategy.execute();

            // Fallback: If not found, try a broader broadcast request or check cache
            if (!emailText) {
                // Check if we received a broadcast recently
                if (window._pandaid_last_email_text && (Date.now() - (window._pandaid_last_email_ts || 0) < 5000)) {
                    emailText = window._pandaid_last_email_text;
                    logger.debug('✓ Using cached email text from broadcast', 'import-tools');
                } else {
                    // Try one last desperate request with short timeout
                    emailText = await requestEmailContentFromIframes(500);
                }
            }

            if (emailText) {
                importedText = emailText;
                source = 'Email Content';
                logger.debug('✓ Found Email text', 'import-tools');
            }
        }

        // Priority 2: Chatter Input
        if (!importedText) {
            const chatterStrategy = new ChatterExtractor(sidebar);
            const chatterText = chatterStrategy.execute();
            if (chatterText) {
                importedText = chatterText;
                source = 'Chatter Input';
                logger.debug('✓ Found Chatter text', 'import-tools');
            }
        }

        // Priority 3: Selection
        if (!importedText) {
            const selectionStrategy = new SelectionExtractor();
            const selectionText = selectionStrategy.execute();
            if (selectionText) {
                importedText = selectionText;
                source = 'Selected Text';
            }
        }

        // Priority 4: Fallback to Case Context
        if (!importedText) {
            const caseData = sidebar.getCaseDataFromPage();
            let contextText = 'Case Context:\n\n';

            if (caseData.subject) contextText += `Subject: ${caseData.subject}\n`;
            if (caseData.productFamily) contextText += `Product: ${caseData.productFamily}\n`;
            if (caseData.productComponent?.trim()) {
                contextText += `Component: ${caseData.productComponent}\n`;
            } else if (caseData.productComponent !== undefined) {
                contextText += `Component: [Not Specified]\n`;
            }

            contextText += '\n--- Add problem description or additional details here ---';

            importedText = contextText;
            source = 'Case Details';
        }

        // Set the value
        const needsSep = originalInput.value && !originalInput.value.endsWith('\n\n') ? '\n\n' : '';
        originalInput.value = (originalInput.value || '') + (originalInput.value ? needsSep : '') + importedText;
        originalInput.focus();

        // Move cursor to end
        originalInput.setSelectionRange(originalInput.value.length, originalInput.value.length);

        logger.debug(`Import successful: ${source} imported`, 'import-tools');
        return Result.success(importedText);

    } catch (error) {
        logger.error('Error importing text:', 'import-tools', error);
        if (sidebar && typeof sidebar.showError === 'function') {
            sidebar.showError('Failed to import text. Please manually enter your content.');
        }
        return Result.failure(error);
    } finally {
        handleImportText.isExecuting = false;
    }
}

export async function requestEmailContentFromIframes(timeout = 2000) {
    const strategy = new EmailExtractor(null);
    return strategy.requestEmailContentFromIframes(timeout);
}

export function extractEmailText(sidebar) {
    try {
        const strategy = new EmailExtractor(sidebar);
        return Result.success(strategy.extractEmailText(sidebar));
    } catch (e) {
        logger.warn('Error extracting email text', 'import-tools', e);
        return Result.failure(e);
    }
}

// Kept for debugging, consider moving to specific debug util in future
export function getEmailContentDebugInfo(_sidebar) {
    return {
        emailuiComponents: document.querySelectorAll('emailui-rich-text-output').length,
        iframes: document.querySelectorAll('iframe').length,
        contentEditables: document.querySelectorAll('[contenteditable="true"]').length,
    };
}
