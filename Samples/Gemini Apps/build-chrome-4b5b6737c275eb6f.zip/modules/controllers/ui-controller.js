/**
 * UI Controller
 * Manages UI interactions, tab switching, and status updates.
 */
import {
    showSectionStatus,
    showStatus as showStatusHelper,
    showAtlassianUrlInputError,
    hideAtlassianUrlInputError
} from '../ui-helpers.js';

export class UiController {
    constructor(elements) {
        this.elements = elements;
        this.statusElement = elements.statusElement;
    }

    showStatus(message, type = 'info') {
        showStatusHelper(this.statusElement, message, type);
    }

    showSectionStatus(element, message, type = 'info') {
        showSectionStatus(element, message, type);
    }

    showAtlassianError(message) {
        showAtlassianUrlInputError(this.elements.atlassianBaseUrlInput, message);
    }

    hideAtlassianError() {
        hideAtlassianUrlInputError();
    }

    setupTabs() {
        const { tabContainer, tabButtons, tabContents } = this.elements;
        if (!tabContainer) return;

        tabContainer.addEventListener('click', (e) => {
            const button = e.target.closest('.tab-button');
            if (!button) return;

            // Deactivate all
            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            // Activate clicked
            button.classList.add('active');
            const tabId = button.dataset.tab;
            const content = document.getElementById(tabId);
            if (content) {
                content.classList.add('active');
                // If switching to advanced settings, refresh sliders layout if needed
                if (tabId === 'advanced-settings') {
                    window.dispatchEvent(new Event('resize'));
                }
            }
        });
    }
}
