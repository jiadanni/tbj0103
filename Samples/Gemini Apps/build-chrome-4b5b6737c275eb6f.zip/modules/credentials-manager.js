// Token field helpers and event wiring for the options page.

function toggleTokenVisibility(inputElement, buttonElement) {
  const type = inputElement.type === 'password' ? 'text' : 'password';
  inputElement.type = type;
  updateToggleIcon(inputElement, buttonElement);
}

export function updateToggleIcon(inputElement, buttonElement) {
  if (!inputElement || !buttonElement) return;
  const isPassword = inputElement.type === 'password';
  buttonElement.textContent = isPassword ? 'Show' : 'Hide';
  buttonElement.title = isPassword ? 'Token is hidden (click to show)' : 'Token is visible (click to hide)';
}

export function handleTokenPaste(inputElement, buttonElement) {
  if (!inputElement || !buttonElement) return;

  setTimeout(() => {
    if (inputElement.value.trim()) {
      // Keep input as password type after paste - don't auto-reveal
      buttonElement.style.display = 'flex';
      inputElement.removeAttribute('data-is-saved');
    }
  }, 10);
}

export function updateToggleVisibility(inputElement, buttonElement, isTokenSaved = false) {
  if (!inputElement || !buttonElement) return;
  buttonElement.style.display = isTokenSaved && inputElement.value.trim() ? 'none' : 'flex';
}

export function toggleTokenVisibilitySecure(inputElement, buttonElement, isTokenSaved = false, sectionStatusElement = null, showStatus = () => {}) {
  if (!inputElement || !buttonElement) return;

  if (isTokenSaved && inputElement.type === 'password') {
    const message = 'For security reasons, saved tokens cannot be viewed. Clear the field to enter a new token.';
    if (sectionStatusElement) {
      sectionStatusElement.textContent = message;
      sectionStatusElement.className = 'status info';
      sectionStatusElement.style.display = 'block';
      setTimeout(() => {
        sectionStatusElement.style.display = 'none';
      }, 5000);
    } else {
      showStatus(message, 'info');
    }
    return;
  }

  toggleTokenVisibility(inputElement, buttonElement);
}

export function attachTokenFieldHandlers({
  aiServiceTokenInput,
  toggleAiTokenButton,
  atlassianTokenInput,
  toggleAtlassianTokenButton,
  statusElement,
  showStatus
}) {
  if (toggleAiTokenButton && aiServiceTokenInput) {
    toggleAiTokenButton.addEventListener('click', () => {
      const isTokenSaved = aiServiceTokenInput.getAttribute('data-is-saved') === 'true';
      toggleTokenVisibilitySecure(aiServiceTokenInput, toggleAiTokenButton, isTokenSaved, statusElement, showStatus);
    });
  }

  if (toggleAtlassianTokenButton && atlassianTokenInput) {
    toggleAtlassianTokenButton.addEventListener('click', () => {
      const isTokenSaved = atlassianTokenInput.getAttribute('data-is-saved') === 'true';
      toggleTokenVisibilitySecure(atlassianTokenInput, toggleAtlassianTokenButton, isTokenSaved, statusElement, showStatus);
    });
  }

  if (aiServiceTokenInput) {
    aiServiceTokenInput.addEventListener('paste', () => {
      handleTokenPaste(aiServiceTokenInput, toggleAiTokenButton);
      aiServiceTokenInput.removeAttribute('data-is-saved');
    });

    aiServiceTokenInput.addEventListener('input', () => {
      if (aiServiceTokenInput.getAttribute('data-is-saved') === 'true') {
        aiServiceTokenInput.value = '';
        aiServiceTokenInput.removeAttribute('data-is-saved');
        updateToggleVisibility(aiServiceTokenInput, toggleAiTokenButton, false);
        aiServiceTokenInput.type = 'text';
        updateToggleIcon(aiServiceTokenInput, toggleAiTokenButton);
        if (toggleAiTokenButton) toggleAiTokenButton.style.display = 'flex';
        setTimeout(() => aiServiceTokenInput.focus(), 0);
      }
      if (aiServiceTokenInput.value.trim() && toggleAiTokenButton) {
        toggleAiTokenButton.style.display = 'flex';
      }
    });

    aiServiceTokenInput.addEventListener('focus', () => {
      if (!aiServiceTokenInput.getAttribute('data-is-saved') && toggleAiTokenButton) {
        toggleAiTokenButton.style.display = 'flex';
      }
    });
  }

  if (atlassianTokenInput) {
    atlassianTokenInput.addEventListener('paste', () => {
      handleTokenPaste(atlassianTokenInput, toggleAtlassianTokenButton);
      atlassianTokenInput.removeAttribute('data-is-saved');
    });

    atlassianTokenInput.addEventListener('input', () => {
      if (atlassianTokenInput.getAttribute('data-is-saved') === 'true') {
        atlassianTokenInput.value = '';
        atlassianTokenInput.removeAttribute('data-is-saved');
        updateToggleVisibility(atlassianTokenInput, toggleAtlassianTokenButton, false);
        atlassianTokenInput.type = 'text';
        updateToggleIcon(atlassianTokenInput, toggleAtlassianTokenButton);
        if (toggleAtlassianTokenButton) toggleAtlassianTokenButton.style.display = 'flex';
        setTimeout(() => atlassianTokenInput.focus(), 0);
      }
      if (atlassianTokenInput.value.trim() && toggleAtlassianTokenButton) {
        toggleAtlassianTokenButton.style.display = 'flex';
      }
    });

    atlassianTokenInput.addEventListener('focus', () => {
      if (!atlassianTokenInput.getAttribute('data-is-saved') && toggleAtlassianTokenButton) {
        toggleAtlassianTokenButton.style.display = 'flex';
      }
    });
  }
}
