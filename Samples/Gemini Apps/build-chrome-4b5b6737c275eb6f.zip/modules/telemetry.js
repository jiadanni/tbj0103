/**
 * Telemetry and Metrics Utility
 * Provides performance monitoring and error tracking for production debugging
 */

import { createLogger } from './logger.js';

const logger = createLogger('Telemetry');

/**
 * Event types for categorization
 */
export const TelemetryEventType = {
  API_CALL: 'api_call',
  ERROR: 'error',
  PERFORMANCE: 'performance',
  USER_ACTION: 'user_action',
  CACHE_HIT: 'cache_hit',
  CACHE_MISS: 'cache_miss'
};

/**
 * Telemetry configuration
 */
const config = {
  enabled: true,
  maxEvents: 1000, // Maximum events to keep in memory
  samplingRate: 1.0, // 1.0 = 100% of events (reduce for production)
  consoleLogging: true // Log to console for debugging
};

/**
 * In-memory event storage
 */
const events = [];

/**
 * Performance marks for measuring operation duration
 */
const performanceMarks = new Map();

/**
 * Records a telemetry event
 * @param {string} eventType - Type of event (from TelemetryEventType)
 * @param {string} eventName - Name of the event
 * @param {Object} data - Event data
 * @param {Object} metadata - Additional metadata
 */
export function recordEvent(eventType, eventName, data = {}, metadata = {}) {
  // Check if telemetry is enabled and sampling
  if (!config.enabled || Math.random() > config.samplingRate) {
    return;
  }

  const event = {
    id: crypto.randomUUID(),
    type: eventType,
    name: eventName,
    timestamp: Date.now(),
    data: sanitizeData(data),
    metadata: {
      ...metadata,
      userAgent: navigator.userAgent,
      url: window.location?.href
    }
  };

  // Add to events array
  events.push(event);

  // Trim to max size
  if (events.length > config.maxEvents) {
    events.shift();
  }

  // Console logging if enabled
  if (config.consoleLogging) {
    logger.info(`[Telemetry] ${eventType}:${eventName}`, 'telemetry', data);
  }

  return event.id;
}

/**
 * Sanitizes data to remove sensitive information
 * @param {Object} data - Data to sanitize
 * @returns {Object} Sanitized data
 */
function sanitizeData(data) {
  if (!data || typeof data !== 'object') {
    return data;
  }

  const sanitized = {};
  const sensitiveKeys = ['token', 'password', 'apikey', 'secret', 'authorization', 'auth'];

  for (const [key, value] of Object.entries(data)) {
    const lowerKey = key.toLowerCase();

    // Check if key contains sensitive terms
    if (sensitiveKeys.some(term => lowerKey.includes(term))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeData(value);
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

/**
 * Starts a performance measurement
 * @param {string} operationName - Name of the operation
 * @returns {string} Measurement ID
 */
export function startPerformanceMeasurement(operationName) {
  const id = crypto.randomUUID();
  performanceMarks.set(id, {
    name: operationName,
    startTime: performance.now()
  });
  return id;
}

/**
 * Ends a performance measurement and records it
 * @param {string} measurementId - ID returned from startPerformanceMeasurement
 * @param {Object} additionalData - Additional data to record
 */
export function endPerformanceMeasurement(measurementId, additionalData = {}) {
  const mark = performanceMarks.get(measurementId);
  if (!mark) {
    logger.warn(`[Telemetry] Performance mark not found: ${measurementId}`, 'telemetry', undefined);
    return null;
  }

  const duration = performance.now() - mark.startTime;
  performanceMarks.delete(measurementId);

  recordEvent(TelemetryEventType.PERFORMANCE, mark.name, {
    duration,
    durationMs: Math.round(duration),
    ...additionalData
  });

  return duration;
}

/**
 * Wraps an async function with performance tracking
 * @param {string} operationName - Name of the operation
 * @param {Function} fn - Function to wrap
 * @returns {Function} Wrapped function
 */
export function withPerformanceTracking(operationName, fn) {
  return async function (...args) {
    const measurementId = startPerformanceMeasurement(operationName);

    try {
      const result = await fn(...args);
      endPerformanceMeasurement(measurementId, { ok: true });
      return result;
    } catch (error) {
      logger.debug('Error in tracked performance operation', 'telemetry', error);
      endPerformanceMeasurement(measurementId, {
        ok: false,
        error: error.message
      });
      throw error;
    }
  };
}

/**
 * Records an API call event
 * @param {string} endpoint - API endpoint
 * @param {string} method - HTTP method
 * @param {number} status - Response status
 * @param {number} duration - Request duration in ms
 * @param {Object} metadata - Additional metadata
 */
export function recordApiCall(endpoint, method, status, duration, metadata = {}) {
  recordEvent(TelemetryEventType.API_CALL, `${method} ${endpoint}`, {
    endpoint,
    method,
    status,
    duration,
    ok: status >= 200 && status < 300
  }, metadata);
}

/**
 * Records an error event
 * @param {Error|string} error - Error object or message
 * @param {string} context - Context where error occurred
 * @param {Object} additionalData - Additional error data
 */
export function recordError(error, context, additionalData = {}) {
  const errorData = {
    message: error.message || String(error),
    context,
    stack: error.stack,
    name: error.name,
    ...additionalData
  };

  recordEvent(TelemetryEventType.ERROR, context, errorData);
}

/**
 * Records a user action
 * @param {string} action - Action name
 * @param {Object} data - Action data
 */
export function recordUserAction(action, data = {}) {
  recordEvent(TelemetryEventType.USER_ACTION, action, data);
}

/**
 * Records a cache hit
 * @param {string} cacheKey - Cache key
 * @param {Object} metadata - Additional metadata
 */
export function recordCacheHit(cacheKey, metadata = {}) {
  recordEvent(TelemetryEventType.CACHE_HIT, cacheKey, {}, metadata);
}

/**
 * Records a cache miss
 * @param {string} cacheKey - Cache key
 * @param {Object} metadata - Additional metadata
 */
export function recordCacheMiss(cacheKey, metadata = {}) {
  recordEvent(TelemetryEventType.CACHE_MISS, cacheKey, {}, metadata);
}

/**
 * Gets all recorded events
 * @param {Object} filters - Optional filters
 * @param {string} filters.type - Filter by event type
 * @param {number} filters.since - Filter events since timestamp
 * @param {number} filters.limit - Maximum number of events to return
 * @returns {Array} Filtered events
 */
export function getEvents(filters = {}) {
  let filtered = [...events];

  if (filters.type) {
    filtered = filtered.filter(e => e.type === filters.type);
  }

  if (filters.since) {
    filtered = filtered.filter(e => e.timestamp >= filters.since);
  }

  if (filters.limit) {
    filtered = filtered.slice(-filters.limit);
  }

  return filtered;
}

/**
 * Gets aggregated metrics
 * @param {number} timeWindow - Time window in milliseconds (default: last hour)
 * @returns {Object} Aggregated metrics
 */
export function getMetrics(timeWindow = 3600000) {
  const since = Date.now() - timeWindow;
  const recentEvents = events.filter(e => e.timestamp >= since);

  const metrics = {
    totalEvents: recentEvents.length,
    byType: {},
    apiCalls: {
      total: 0,
      successful: 0,
      failed: 0,
      averageDuration: 0
    },
    errors: {
      total: 0,
      byContext: {}
    },
    performance: {
      operations: {}
    },
    cache: {
      hits: 0,
      misses: 0,
      hitRate: 0
    }
  };

  // Aggregate by type
  for (const event of recentEvents) {
    metrics.byType[event.type] = (metrics.byType[event.type] || 0) + 1;

    switch (event.type) {
      case TelemetryEventType.API_CALL:
        metrics.apiCalls.total++;
        if (event.data.success) {
          metrics.apiCalls.successful++;
        } else {
          metrics.apiCalls.failed++;
        }
        break;

      case TelemetryEventType.ERROR:
        metrics.errors.total++;
        const context = event.data.context || 'unknown';
        metrics.errors.byContext[context] = (metrics.errors.byContext[context] || 0) + 1;
        break;

      case TelemetryEventType.PERFORMANCE:
        if (!metrics.performance.operations[event.name]) {
          metrics.performance.operations[event.name] = {
            count: 0,
            totalDuration: 0,
            averageDuration: 0
          };
        }
        const op = metrics.performance.operations[event.name];
        op.count++;
        op.totalDuration += event.data.duration || 0;
        op.averageDuration = op.totalDuration / op.count;
        break;

      case TelemetryEventType.CACHE_HIT:
        metrics.cache.hits++;
        break;

      case TelemetryEventType.CACHE_MISS:
        metrics.cache.misses++;
        break;
    }
  }

  // Calculate cache hit rate
  const totalCacheAccess = metrics.cache.hits + metrics.cache.misses;
  if (totalCacheAccess > 0) {
    metrics.cache.hitRate = (metrics.cache.hits / totalCacheAccess * 100).toFixed(2);
  }

  // Calculate average API call duration
  const apiCallEvents = recentEvents.filter(e => e.type === TelemetryEventType.API_CALL);
  if (apiCallEvents.length > 0) {
    const totalDuration = apiCallEvents.reduce((sum, e) => sum + (e.data.duration || 0), 0);
    metrics.apiCalls.averageDuration = Math.round(totalDuration / apiCallEvents.length);
  }

  return metrics;
}

/**
 * Clears all recorded events
 */
export function clearEvents() {
  events.length = 0;
  performanceMarks.clear();
}

/**
 * Exports events as JSON
 * @param {Object} filters - Optional filters (same as getEvents)
 * @returns {string} JSON string of events
 */
export function exportEvents(filters = {}) {
  const filtered = getEvents(filters);
  return JSON.stringify(filtered, null, 2);
}

/**
 * Configures telemetry settings
 * @param {Object} options - Configuration options
 */
export function configure(options = {}) {
  Object.assign(config, options);
}

/**
 * Gets current configuration
 * @returns {Object} Current configuration
 */
export function getConfig() {
  return { ...config };
}

/**
 * Creates a telemetry session for tracking related operations
 */
export class TelemetrySession {
  constructor(sessionName) {
    this.sessionId = crypto.randomUUID();
    this.sessionName = sessionName;
    this.startTime = Date.now();
    this.events = [];
  }

  /**
   * Records an event within this session
   */
  recordEvent(eventType, eventName, data = {}) {
    const eventId = recordEvent(eventType, eventName, data, {
      sessionId: this.sessionId,
      sessionName: this.sessionName
    });
    this.events.push(eventId);
    return eventId;
  }

  /**
   * Ends the session and records summary
   */
  end(summary = {}) {
    const duration = Date.now() - this.startTime;
    recordEvent(TelemetryEventType.PERFORMANCE, `session_${this.sessionName}`, {
      duration,
      eventsRecorded: this.events.length,
      ...summary
    }, {
      sessionId: this.sessionId
    });
    return {
      sessionId: this.sessionId,
      duration,
      eventsRecorded: this.events.length
    };
  }
}

// Export a default telemetry instance
export default {
  recordEvent,
  recordApiCall,
  recordError,
  recordUserAction,
  recordCacheHit,
  recordCacheMiss,
  startPerformanceMeasurement,
  endPerformanceMeasurement,
  withPerformanceTracking,
  getEvents,
  getMetrics,
  clearEvents,
  exportEvents,
  configure,
  getConfig,
  TelemetrySession,
  TelemetryEventType
};
