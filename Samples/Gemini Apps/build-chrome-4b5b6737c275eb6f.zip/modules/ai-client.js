/**
 * AI Client Module
 * Handles low-level AI API operations: authentication, transport, retries, and caching.
 * 
 * @module api/ai-client
 */

import { getApiEndpoint, ensureHostPermissionForUrl } from '../../security-utils.js';
import { CACHE_TTL, responseCache, setCache, scheduleCachePersist } from '../cache/cache-manager.js';
import { rateLimiters } from '../utils/rate-limiter.js';
import { ErrorMessages } from '../utils/user-notifications.js';
import { handleError, ErrorStrategy } from '../utils/error-handler.js';
import {
    AI_REQUEST_TIMEOUT_MS,
    MAX_API_RETRIES,
    AUTH_FAILURE_THRESHOLD as AUTH_THRESHOLD,
    AUTH_FAILURE_WINDOW_MS as AUTH_WINDOW_MS
} from '../config/constants.js';
import { decrypt } from '../security/crypto-utils.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';
import { Mutex } from '../utils/synchronization.js';

const logger = createLogger('AiClient');
const authStateMutex = new Mutex();

// Token cache to avoid repeated decryption (cleared on token change)
let cachedToken = null;
let cachedTokenEncrypted = null;

const REQUEST_TIMEOUT = AI_REQUEST_TIMEOUT_MS;
const MAX_RETRIES = MAX_API_RETRIES;
const AUTH_FAILURE_THRESHOLD = AUTH_THRESHOLD;
const AUTH_FAILURE_WINDOW_MS = AUTH_WINDOW_MS;

/**
 * Generate a simple hash of a token for tracking purposes
 * @param {string} token - Token to hash
 * @returns {Promise<string>} Hash of the token
 */
async function hashToken(token) {
    if (!token) return '';
    const encoder = new TextEncoder();
    const data = encoder.encode(token);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
}

/**
 * Get the currently active AI model from settings
 * @returns {Promise<string>} Active AI model ID
 */
export async function getActiveAiModel() {
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');

    if (!advancedAiSettings?.models) {
        throw new Error('No AI models configured. Please configure at least one model in the extension settings.');
    }

    const activeModelNum = advancedAiSettings.activeModel || 1;
    const modelKey = `model${activeModelNum}`;
    const activeModel = advancedAiSettings.models[modelKey];

    if (!activeModel || !activeModel.trim()) {
        throw new Error(`Active model (${modelKey}) is not configured. Please set up your AI model in the extension settings.`);
    }

    return activeModel.trim();
}

/**
 * Internal helper to get auth failure state (must be called within mutex)
 */
async function getAuthFailureStateInternal(tokenHash) {
    const failureKey = `aiTokenFailures_${tokenHash}`;
    const stored = await chrome.storage.local.get(failureKey);
    return stored[failureKey] || { count: 0, firstFailureTime: null, lastFailureTime: null };
}

/**
 * Internal helper to set auth failure state (must be called within mutex)
 */
async function setAuthFailureStateInternal(tokenHash, state) {
    const failureKey = `aiTokenFailures_${tokenHash}`;
    await chrome.storage.local.set({ [failureKey]: state });
}

/**
 * Increment auth failure count for a token atomically
 */
async function incrementAuthFailure(token) {
    if (!token) {
        return { count: 0, shouldInvalidate: false, state: null };
    }

    return await authStateMutex.runExclusive(async () => {
        try {
            const tokenHash = await hashToken(token);
            const now = Date.now();

            const state = await getAuthFailureStateInternal(tokenHash);

            if (state.firstFailureTime && (now - state.firstFailureTime) > AUTH_FAILURE_WINDOW_MS) {
                const resetState = { count: 0, firstFailureTime: null, lastFailureTime: null };
                await setAuthFailureStateInternal(tokenHash, resetState);
                return { count: 0, shouldInvalidate: false, state: resetState };
            }

            const updatedState = {
                firstFailureTime: state.count === 0 ? now : state.firstFailureTime,
                lastFailureTime: now,
                count: state.count + 1
            };

            await setAuthFailureStateInternal(tokenHash, updatedState);
            logger.warn(`Auth failure ${updatedState.count}/${AUTH_FAILURE_THRESHOLD} for token hash ${tokenHash}`, 'ai-client');

            const shouldInvalidate = updatedState.count >= AUTH_FAILURE_THRESHOLD;
            return { count: updatedState.count, shouldInvalidate, state: updatedState };
        } catch (error) {
            logger.warn('Failed to increment auth failure state', 'ai-client', error);
            return { count: 0, shouldInvalidate: false, state: null };
        }
    });
}

/**
 * Track authentication failure and determine if token should be invalidated
 */
async function shouldInvalidateToken(error, failedToken) {
    if (!failedToken) return false;

    return await authStateMutex.runExclusive(async () => {
        try {
            const currentData = await chrome.storage.local.get('aiServiceToken');
            const currentTokenEncrypted = currentData?.aiServiceToken;

            if (!currentTokenEncrypted) return false;

            let currentToken = null;
            if (cachedTokenEncrypted === currentTokenEncrypted && cachedToken) {
                currentToken = cachedToken;
            } else {
                try {
                    const result = await decrypt(currentTokenEncrypted);
                    if (!result.ok) throw result.error;
                    currentToken = result.value;
                    cachedTokenEncrypted = currentTokenEncrypted;
                    cachedToken = currentToken;
                } catch (decryptError) {
                    logger.warn('Failed to decrypt stored AI token for auth tracking', 'ai-client', decryptError);
                    return false;
                }
            }

            if (!currentToken || currentToken !== failedToken) {
                return false;
            }

            const tokenHash = await hashToken(failedToken);
            const now = Date.now();

            const state = await getAuthFailureStateInternal(tokenHash);

            if (state.firstFailureTime && (now - state.firstFailureTime) > AUTH_FAILURE_WINDOW_MS) {
                return false;
            }

            const updatedState = {
                firstFailureTime: state.count === 0 ? now : state.firstFailureTime,
                lastFailureTime: now,
                count: state.count + 1
            };

            await setAuthFailureStateInternal(tokenHash, updatedState);

            if (updatedState.count >= AUTH_FAILURE_THRESHOLD) {
                logger.error('Token invalidated after repeated authentication failures', 'ai-client', {
                    failureCount: updatedState.count,
                    threshold: AUTH_FAILURE_THRESHOLD
                });
                return true;
            }

            logger.warn(`Auth failure ${updatedState.count}/${AUTH_FAILURE_THRESHOLD} for token`, 'ai-client');
            return false;
        } catch (error) {
            logger.warn('Failed to check token invalidation status', 'ai-client', error);
            return false;
        }
    });
}

/**
 * Reset auth failure tracking
 */
async function resetAuthFailure(token) {
    if (!token) return;

    return await authStateMutex.runExclusive(async () => {
        try {
            const tokenHash = await hashToken(token);
            // We can just remove it, but internal helper get check might be useful if we want to log
            // But removing is simpler. Let's strictly use internal set/get or direct remove?
            // "reset" usually means remove key or set count 0.
            const failureKey = `aiTokenFailures_${tokenHash}`;
            // Direct removal is fine, it's atomic enough (one OP), but being inside mutex ensures no race with increment.
            // Wait, chrome.storage.local.remove is async.
            // Let's use getAuthFailureStateInternal just to check if we should log.
            const state = await getAuthFailureStateInternal(tokenHash);

            if (state && state.count > 0) {
                logger.info('Auth failure tracking reset after successful request', 'ai-client');
                await chrome.storage.local.remove(failureKey);
            }
        } catch (error) {
            logger.warn('Failed to reset auth failure tracking', 'ai-client', error);
        }
    });
}

/**
 * Check whether AI is enabled and a token is available
 */
export async function hasValidAiServiceToken() {
    const { aiServiceToken, aiEnabled } = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
    const enabled = typeof aiEnabled === 'undefined' ? true : !!aiEnabled;
    return !!aiServiceToken && enabled;
}

/**
 * Get AI service authentication token from storage
 */
export async function getAuthToken() {
    try {
        const data = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
        const enabled = typeof data.aiEnabled === 'undefined' ? true : !!data.aiEnabled;
        if (!enabled) {
            throw new Error('AI disabled by user');
        }
        if (!data || !data.aiServiceToken) {
            throw new Error('No AI Service API token found');
        }

        if (cachedTokenEncrypted === data.aiServiceToken && cachedToken) {
            return cachedToken;
        }

        try {
            const result = await decrypt(data.aiServiceToken);
            if (!result.ok) throw result.error;
            const token = result.value;
            cachedTokenEncrypted = data.aiServiceToken;
            cachedToken = token;
            return token;
        } catch (decryptError) {
            const shouldReconfigure = decryptError.code === 'DECRYPT_FAILED' || decryptError.code === 'SESSION_KEY_MISMATCH';
            if (shouldReconfigure) {
                logger.error('Token decryption failed; user should reconfigure', 'ai-client', decryptError);
                throw new Error('Failed to decrypt AI Service API token. Please reconfigure your token in settings.');
            }
            throw decryptError;
        }
    } catch (error) {
        logger.error('Error retrieving AI Service API token:', 'ai-client', error);
        if (error.message.includes('decrypt')) {
            throw error;
        }
        throw new Error('Failed to retrieve AI Service API token. Please check your settings.');
    }
}

/**
 * Fetch with timeout and automatic retry
 */
async function fetchWithTimeoutAndRetry(url, options, retries = MAX_RETRIES, timeout = REQUEST_TIMEOUT, externalSignal = null) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    if (externalSignal) {
        if (externalSignal.aborted) {
            clearTimeout(id);
            throw new DOMException('Request cancelled by user', 'AbortError');
        }
        externalSignal.addEventListener('abort', () => {
            clearTimeout(id);
            controller.abort();
        }, { once: true });
    }

    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(id);
        return response;
    } catch (error) {
        logger.debug('AI service request error', 'ai-client', error);
        clearTimeout(id);
        if (error.name === 'AbortError') {
            throw new DOMException('Request timed out. Please check your internet connection.', 'AbortError');
        }
        if (retries > 0) {
            logger.info(`Retrying request... (${retries} attempts left)`, 'ai-client', { error: error.message });
            return fetchWithTimeoutAndRetry(url, options, retries - 1, timeout, externalSignal);
        }
        logger.error('AI service request failed after retries', 'ai-client', error);
        throw error;
    }
}

/**
 * Extract operation name from GraphQL query
 */
function getOperationName(query) {
    const match = query.match(/(query|mutation)\s+(\w+)/);
    return match ? match[2] : 'AnonymousOperation';
}

/**
 * Make a GraphQL API request to AI service
 */
export async function makeApiRequest(query, variables = {}, token = null, signal = null) {
    let authToken;
    try {
        authToken = token || await getAuthToken();

        // Check if this token is currently marked as "should invalidate" or has high failure count
        // to prevent thundering herd on a known-bad token.
        if (authToken) {
            const tokenHash = await hashToken(authToken);
            const failureKey = `aiTokenFailures_${tokenHash}`;

            const state = await authStateMutex.runExclusive(async () => {
                return await getAuthFailureStateInternal(tokenHash);
            });

            if (state && state.count >= AUTH_FAILURE_THRESHOLD) {
                const now = Date.now();
                if (!state.firstFailureTime || (now - state.firstFailureTime) < AUTH_FAILURE_WINDOW_MS) {
                    logger.warn('Token is temporarily locked due to high failure rate, skipping request', 'ai-client');
                    return Result.failure(new Error('AI service is temporarily restricted due to repeated authentication failures. Please check your settings.'));
                }
            }
        }
    } catch (error) {
        logger.error('Error in makeApiRequest preprocessing', 'ai-client', error);
        return Result.failure(error);
    }

    const apiEndpoint = await getApiEndpoint();
    await ensureHostPermissionForUrl(apiEndpoint, false);
    const cacheKey = JSON.stringify({ query, variables });
    const now = Date.now();

    const cached = responseCache.get(cacheKey);
    if (cached && (now - cached.timestamp) < CACHE_TTL) {
        return Result.success(cached.data);
    }

    try {
        const response = await rateLimiters.ai.executeWithBackoff(
            async () => {
                return await fetchWithTimeoutAndRetry(apiEndpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Auth-Token': authToken,
                        'X-Request-Source': 'salesforce-extension',
                        'X-Request-ID': crypto.randomUUID()
                    },
                    body: JSON.stringify({
                        query,
                        variables,
                        operationName: getOperationName(query)
                    })
                }, MAX_RETRIES, REQUEST_TIMEOUT, signal);
            },
            'ai-client',
            signal
        );

        if (!response.ok) {
            const errorText = await response.text();
            const error = new Error(`API request failed: ${errorText}`);
            error.status = response.status;
            error.endpoint = apiEndpoint;
            throw error;
        }

        const data = await response.json();

        if (data.errors) {
            const errorMessages = data.errors.map(err => err.message).join('; ');
            const error = new Error(`GraphQL Error: ${errorMessages}`);
            error.status = response.status;
            throw error;
        }

        await setCache(cacheKey, data);

        resetAuthFailure(authToken).catch(err => {
            logger.warn('Failed to reset auth failure tracking', 'ai-client', err);
        });

        scheduleCachePersist();

        return Result.success(data);
    } catch (error) {
        logger.error('API Request Error:', 'ai-client', {
            error: error.message,
            query: getOperationName(query),
            timestamp: new Date().toISOString()
        });

        const isAuthError = error.status === 401 || error.status === 403 ||
            error.message.includes('401') || error.message.includes('403');

        if (isAuthError) {
            const shouldInvalidate = await shouldInvalidateToken(error, authToken);
            if (shouldInvalidate) {
                logger.error('Token invalidated after repeated authentication failures', 'ai-client');
                responseCache.clear();
                cachedToken = null;
                cachedTokenEncrypted = null;
                await chrome.storage.local.remove('aiServiceToken');

                handleError(error, {
                    strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                    context: 'AI Client',
                    operation: 'makeApiRequest:auth',
                    userMessage: ErrorMessages.API_AUTH_FAILED
                });

                return Result.failure(new Error('Authentication failed repeatedly. Your AI Service API token has been cleared. Please update it in the extension settings.'));
            } else {
                handleError(error, {
                    strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                    context: 'AI Client',
                    operation: 'makeApiRequest:auth',
                    userMessage: 'Authentication error. If this persists, please check your API token in settings.'
                });

                return Result.failure(new Error('Authentication failed. Please verify your AI Service API token is correct.'));
            }
        }

        if (error.name !== 'AbortError') {
            handleError(error, {
                strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                context: 'AI Client',
                operation: `makeApiRequest:${getOperationName(query)}`
            });
        }

        return Result.failure(error);
    }
}

/**
 * Test AI service connection.
 * Used during setup and troubleshooting to verify API endpoint and token validity.
 * 
 * @param {string|null} [token=null] - Optional token for testing
 * @param {string|null} [testModel=null] - Optional specific model to test (overrides active model)
 * @returns {Promise<Result>} Standardized Result object with success status and model info
 */
export async function testConnection(token, testModel = null) {
    const apiEndpoint = await getApiEndpoint();
    await ensureHostPermissionForUrl(apiEndpoint, true);

    const model = testModel || await getActiveAiModel();
    const testMutation =
        'mutation TestConnection($model: String!, $prompt: String!) {' +
        '  answerPrompt(input: {' +
        '    model: $model' +
        '    prompt: $prompt' +
        '    temperature: 0.1' +
        '  })' +
        '}';

    const variables = {
        model: model,
        prompt: "Please respond with 'Connection successful' to test the API connection."
    };

    try {
        const startTime = performance.now();
        const result = await makeApiRequest(testMutation, variables, token);

        if (!result.ok) {
            return result;
        }

        const responseTime = Math.round(performance.now() - startTime);
        const updatedApiEndpoint = await getApiEndpoint();

        return Result.success({
            message: result.value.data.answerPrompt || 'Connection successful',
            responseTime: `${responseTime}ms`,
            serverTimestamp: new Date().toISOString(),
            endpoint: updatedApiEndpoint,
            testedModel: model
        });
    } catch (error) {
        logger.error('AI service connection test failed', 'testConnection', error);
        return Result.failure(error);
    }
}

/**
 * Internal helper to get auth failure state for a token (used for testing)
 */
/**
 * Get auth failure state for a token (safe version)
 */
async function getAuthFailureState(token) {
    if (!token) return { count: 0, firstFailureTime: null, lastFailureTime: null };
    return await authStateMutex.runExclusive(async () => {
        const tokenHash = await hashToken(token);
        return await getAuthFailureStateInternal(tokenHash);
    });
}

// Test-only exports
export const __testOnly__authTracking = {
    incrementAuthFailure,
    resetAuthFailure,
    shouldInvalidateToken,
    getAuthFailureState,
    getOperationName,
    hashToken
};
