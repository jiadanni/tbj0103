/**
 * Suggest Solution handler helpers
 */

import { suggestSolution } from '../api/ai-service.js';
import { searchCommunityGuides, searchLocalVectorDB } from '../api/community-service.js';
import { getKnowledgeBaseLabels } from '../utils/knowledge-base-labels.js';
import { Result } from '../utils/result.js';

function formatKeywordResults(results, kbLabel, prefix = '') {
  const solutionText = `${prefix}${results.map(r => `- ${r.title || r.name || r.source || 'Untitled'}`).join('\n')}`;
  const sources = results.map(r => ({
    title: r.title || r.name || 'Untitled',
    snippet: r.excerpt || (r.content && r.content.substring(0, 200)) || '',
    url: r.url || r.link || '#',
    source: r.category || r.section || kbLabel,
    aiRelevanceScore: r.aiRelevanceScore
  }));
  return { solutionText, sources };
}

function buildVectorSources(results) {
  return results.map(r => ({
    title: (r.metadata && (r.metadata.source_page_title || r.metadata.source_file)) || r.title || 'Untitled',
    snippet: r.chunk_text || r.excerpt || '',
    url: r.metadata && r.metadata.source_url ? r.metadata.source_url : (r.url || '#'),
    source: r.metadata && (r.metadata.source || r.metadata.source_page_title) || 'Local DB',
    page: r.metadata?.page_number,
    aiRelevanceScore: r.relevance || r.score
  }));
}

const SEARCH_MODE_HANDLERS = {
  async keyword({ caseData, kbLabels }) {
    const res = await searchCommunityGuides(caseData);
    const results = (res && res.ok) ? res.value : [];
    const { solutionText, sources } = formatKeywordResults(
      results,
      kbLabels.entryLabel,
      'Matching Knowledge Base Articles:\n\n'
    );
    return { solution: solutionText, sources };
  },
  async vector({ caseData, queryText, localSearchEnabled, localSearchServerUrl, kbLabels }) {
    const hasLocal = !!localSearchEnabled && !!(localSearchServerUrl && localSearchServerUrl.trim());
    if (!hasLocal) {
      const res = await searchCommunityGuides(caseData);
      const results = (res && res.ok) ? res.value : [];
      const { solutionText, sources } = formatKeywordResults(
        results,
        kbLabels.entryLabel,
        'Local vector search is disabled; falling back to keyword search.\n\n'
      );
      return { solution: solutionText, sources };
    }

    const vres = await searchLocalVectorDB(queryText);
    const results = vres.ok ? vres.value : [];
    const solution = "Relevant documentation found via vector search:\n\n" + results.map(r => {
      const title = (r.metadata && (r.metadata.source_page_title || r.metadata.source_file)) || r.title || 'Untitled';
      return `- ${title}${r.metadata?.page_number ? ` (Page: ${r.metadata.page_number})` : ''}`;
    }).join('\n');
    return { solution, sources: buildVectorSources(results) };
  },
  async generative({ caseData, queryText, localSearchEnabled, localSearchServerUrl, kbLabels }) {
    const hasLocal = !!localSearchEnabled && !!(localSearchServerUrl && localSearchServerUrl.trim());
    if (!hasLocal) {
      const res = await searchCommunityGuides(caseData);
      const results = (res && res.ok) ? res.value : [];
      const { solutionText, sources } = formatKeywordResults(
        results,
        kbLabels.entryLabel,
        'Searching Knowledge Base...\n\n'
      );
      return { solution: solutionText, sources };
    }

    const vres = await searchLocalVectorDB(queryText);
    const contextResults = vres.ok ? vres.value : [];
    const context = contextResults.map(r => r.chunk_text || r.content || r.excerpt || '').join('\n\n---\n\n');
    const res = await suggestSolution(caseData, context);
    const solution = (res && res.ok) ? res.value : (res.error?.message || 'Failed to generate guidance.');
    return { solution, sources: buildVectorSources(contextResults) };
  }
};

export async function handleSuggestSolutionRequest(request) {
  const { searchSettings = { mode: 'keyword' }, localSearchEnabled, localSearchServerUrl } = await chrome.storage.local.get({
    searchSettings: { mode: 'keyword' },
    localSearchEnabled: false,
    localSearchServerUrl: ''
  });

  const kbLabels = await getKnowledgeBaseLabels();
  const caseData = request.data || {};
  const providedContext = request.context || "";
  const queryText = `${caseData.subject || ''} ${caseData.description || ''}`.trim();

  if (providedContext) {
    const res = await suggestSolution(caseData, providedContext);
    const solution = (res && res.ok) ? res.value : (typeof res === 'string' ? res : 'Failed to synthesize guidance.');
    return Result.success({ solution, sources: [] });
  }

  const handler = SEARCH_MODE_HANDLERS[searchSettings.mode] || SEARCH_MODE_HANDLERS.keyword;
  const result = await handler({
    caseData,
    queryText,
    localSearchEnabled,
    localSearchServerUrl,
    kbLabels
  });

  return Result.success(result);
}
