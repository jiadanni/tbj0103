/**
 * System and Browser Integration Message Handlers
 */
import { Result } from '../utils/result.js';
import { createLogger } from '../utils/logger.js';
import { CACHE_STORAGE_KEY, responseCache } from '../cache/cache-manager.js';
import { storageLocalRemove, tabsQuery, scriptingExecuteScript } from '../utils/chrome-async.js';
import { filterImportedEmailText } from '../utils/email-helpers.js';

const logger = createLogger('SystemHandlers');

/**
 * Clear cache with optional pattern matching
 */
function clearCache(pattern = null) {
    if (!pattern) {
        const count = responseCache.size;
        responseCache.clear();
        return count;
    }

    // Clear only entries matching the pattern
    let cleared = 0;
    for (const [key] of responseCache.entries()) {
        if (key.includes(pattern)) {
            responseCache.delete(key);
            cleared++;
        }
    }
    return cleared;
}

export async function handleOpenOptionsPageRequest() {
    try {
        if (chrome?.runtime?.openOptionsPage) {
            await chrome.runtime.openOptionsPage();
        }
    } catch (err) {
        logger.warn('Failed to open options page directly', 'openOptionsHandler', err);
    }
    return Result.success({ opened: true });
}

export function handleShowNotificationRequest() {
    if (chrome.notifications) {
        // Notifications intentionally suppressed to avoid noisy alerts.
    }
    return Result.success({ notified: true });
}

export async function handleClearCacheRequest(request) {
    const cleared = clearCache(request.pattern);
    await storageLocalRemove(CACHE_STORAGE_KEY);
    logger.debug('Cleared persisted cache storage key', 'clearCacheHandler');
    return Result.success({
        cleared,
        timestamp: new Date().toISOString()
    });
}

export async function handleImportEmailTextRequest() {
    const tabs = await tabsQuery({ active: true, currentWindow: true });
    const activeTab = tabs[0];

    if (!activeTab || !activeTab.id) {
        return Result.failure(new Error('No active tab found'));
    }

    const executionResults = await scriptingExecuteScript({
        target: { tabId: activeTab.id, allFrames: true },
        function: () => {
            const emailSelectors = [
                'body[aria-label="Email Body"][role="textbox"][contenteditable="true"]',
                '[contenteditable="true"][role="textbox"]',
                '.cke_editable',
                '.slds-rich-text-area__content',
                '.forceChatterRichTextEditor [contenteditable="true"]',
                '.cxSharedChatterRichTextEditor [contenteditable="true"]',
                'div[contenteditable="true"]'
            ];

            for (const selector of emailSelectors) {
                const emailBody = document.querySelector(selector);
                if (emailBody && emailBody.innerText && emailBody.innerText.trim()) {
                    return {
                        ok: true,
                        text: emailBody.innerText.trim(),
                        selector: selector,
                        frameUrl: window.location.href
                    };
                }
            }

            if (window.parent !== window) {
                return {
                    ok: false,
                    error: 'Checked iframe: ' + window.location.href + ' - No email content found',
                    frameUrl: window.location.href
                };
            }

            return {
                ok: false,
                error: 'Email body element not found in any frame',
                frameUrl: window.location.href
            };
        }
    });

    const successfulResult = (executionResults || []).find(entry => entry?.result?.ok);

    if (successfulResult?.result?.text) {
        const filteredText = filterImportedEmailText(successfulResult.result.text);
        return Result.success({ text: filteredText });
    }

    const errors = (executionResults || [])
        .map(entry => entry?.result?.error)
        .filter(Boolean)
        .join('; ');

    return Result.failure(new Error(errors ? `Email content not found: ${errors}` : 'Email content not found'));
}
