/**
 * Message Handlers Module
 * Handles all chrome.runtime.onMessage communications via a registry pattern.
 */

import { initializeServiceWorker, getInitializationState, setInitializationState } from '../core/initialization.js';
import { createLogger } from '../utils/logger.js';
import { MESSAGE_HANDLERS } from './registry.js';
import { withTimeout } from '../utils/promise-utils.js';

const logger = createLogger('MessageHandlers');

/**
 * Safe sendResponse wrapper to catch exceptions and log
 * @param {Function} sendResponseFn
 * @param {Object} payload
 */
function safeSendResponse(sendResponseFn, payload) {
  try {
    logger.debug('Sending response', 'safeSendResponse', payload && (payload.ok ? 'success' : 'error'));
    sendResponseFn(payload);
  } catch (err) {
    logger.error('Failed to send response', 'safeSendResponse', { error: err, payload });
    try {
      chrome.runtime.lastError && logger.warn('LastError present', 'safeSendResponse', chrome.runtime.lastError.message);
    } catch (e) {
      logger.debug('Error checking lastError', 'safeSendResponse', e);
    }
  }
}

/**
 * Standardized error response builder
 */
function buildErrorResponse(error, context = 'Unknown') {
  const errorMessage = error instanceof Error ? error.message : String(error);
  logger.error('Error occurred', context, error);

  return {
    ok: false,
    error: errorMessage,
    context: context,
    timestamp: new Date().toISOString()
  };
}

/**
 * Normalizes an operation result into a standardized response object.
 */
function normalizeResponse(result) {
  // Handle Result objects
  if (result && typeof result.ok === 'boolean') {
    if (result.ok) {
      return { ok: true, data: result.value };
    } else {
      const errorMsg = result.error instanceof Error ? result.error.message : String(result.error || 'Unknown error');
      const payload = { ok: false, error: errorMsg };
      if (result.error && typeof result.error === 'object' && result.error.details) {
        payload.details = result.error.details;
      }
      return payload;
    }
  }

  // Handle already standardized responses
  if (result && typeof result === 'object' && Object.prototype.hasOwnProperty.call(result, 'ok')) {
    return result;
  }

  // Handle legacy success-based responses
  if (result && typeof result === 'object' && Object.prototype.hasOwnProperty.call(result, 'success')) {
    return {
      ok: result.success,
      data: result.data,
      error: result.error,
      ...result
    };
  }

  // Handle raw data responses
  return {
    ok: true,
    data: result
  };
}

async function ensureServiceWorkerReady() {
  if (getInitializationState()) {
    return;
  }

  logger.warn('Service worker was not initialized. Attempting reinitialization...');
  try {
    await initializeServiceWorker();
    setInitializationState(true);
  } catch (error) {
    logger.error('Failed to reinitialize service worker', 'ensureServiceWorkerReady', error);
    throw error;
  }
}

/**
 * Initialize the main message listener
 */
export function initializeMessageListener() {
  logger.info('Registering message listener', 'messageHandlers');

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const action = request?.action;
    const handler = action && MESSAGE_HANDLERS[action];

    if (!handler) {
      safeSendResponse(sendResponse, buildErrorResponse(new Error(`Unknown action: ${action}`), 'MessageRouter'));
      return false;
    }

    logger.debug('Message received', 'messageListener', { action, from: sender?.tab?.id || 'extension' });



    (async () => {
      await ensureServiceWorkerReady();
      // Enforce a global timeout on all message handlers to prevent hangs
      return await withTimeout(
        () => handler(request, sender),
        60000,
        `Message handler timed out for action: ${action}`
      );
    })()
      .then(result => {
        safeSendResponse(sendResponse, normalizeResponse(result));
      })
      .catch(error => {
        safeSendResponse(sendResponse, buildErrorResponse(error, action));
      });

    return true;
  });
}
