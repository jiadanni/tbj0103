/**
 * Message Handler Registry
 * Aggregates all specific handler modules into a centralized routing map.
 */
import * as AiHandlers from './ai-handlers.js';
import * as AtlassianHandlers from './atlassian-handlers.js';
import * as AuthHandlers from './auth-handlers.js';
import * as CommunityHandlers from './community-handlers.js';
import * as SystemHandlers from './system-handlers.js';
import { handleSuggestSolutionRequest } from './suggest-solution-handler.js';

export const MESSAGE_HANDLERS = {
    // AI Handlers
    analyzeCase: AiHandlers.handleAnalyzeCaseRequest,
    improveSolution: AiHandlers.handleImproveSolutionRequest,
    spellcheck: AiHandlers.handleSpellcheckRequest,
    suggestSolution: handleSuggestSolutionRequest,

    // Atlassian Handlers
    getRelatedJiraTickets: AtlassianHandlers.handleGetJiraTicketsRequest,
    getRelatedConfluencePages: AtlassianHandlers.handleGetConfluencePagesRequest,
    testAtlassianConnection: AtlassianHandlers.handleTestAtlassianConnectionRequest,
    testConfluenceConnection: AtlassianHandlers.handleTestAtlassianConnectionRequest,
    testJiraConnection: AtlassianHandlers.handleTestAtlassianConnectionRequest,

    // Community Handlers
    getRelatedCommunityGuides: CommunityHandlers.handleGetCommunityGuidesRequest,
    explainCommunityGuide: CommunityHandlers.handleExplainCommunityGuideRequest,

    // Auth Handlers
    testConnection: AuthHandlers.handleTestConnectionRequest,

    // System Handlers
    openOptionsPage: SystemHandlers.handleOpenOptionsPageRequest,
    showNotification: SystemHandlers.handleShowNotificationRequest,
    clearCache: SystemHandlers.handleClearCacheRequest,
    importEmailText: SystemHandlers.handleImportEmailTextRequest
};
