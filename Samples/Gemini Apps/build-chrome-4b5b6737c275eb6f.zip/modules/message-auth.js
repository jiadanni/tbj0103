import { createLogger } from './logger.js';
import { Result } from './result.js';
const logger = createLogger('MessageAuth');

const TOKEN_STORAGE_KEY = 'pandaidMessageNonce';
const TRUSTED_ORIGIN_PATTERN = /^https:\/\/([a-z0-9-]+\.)*(lightning\.force\.com|salesforce\.com|force\.com|visual\.force\.com)$/i;

let cachedToken = null;
let pendingTokenPromise = null;

function generateToken() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `pandaid-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

/**
 * Generate a unique nonce for each message request (not cached).
 * Use this for per-request security validation.
 * @returns {string} - A unique nonce with timestamp and expiry information
 */
export function generateMessageNonce() {
  // Generate unique token each time (never cached)
  const token = generateToken();
  const timestamp = Date.now();
  // Include timestamp for potential expiry validation (5 minute default)
  return `${token}-${timestamp}`;
}

export async function getMessageNonce() {
  if (cachedToken) {
    return cachedToken;
  }
  if (!pendingTokenPromise) {
    pendingTokenPromise = (async () => {
      const storage = chrome?.storage?.session || chrome?.storage?.local;
      if (!storage) {
        cachedToken = generateToken();
        return cachedToken;
      }

      try {
        const stored = await storage.get(TOKEN_STORAGE_KEY);
        if (stored && stored[TOKEN_STORAGE_KEY]) {
          cachedToken = stored[TOKEN_STORAGE_KEY];
          return cachedToken;
        }
      } catch (e) {
        logger.debug('Error reading message nonce from storage', 'message-auth', e);
        // Ignore storage read failures and fall through to token generation.
      }

      const token = generateToken();
      try {
        await storage.set({ [TOKEN_STORAGE_KEY]: token });
      } catch (e) {
        logger.debug('Error saving message nonce to storage', 'message-auth', e);
        // Ignore storage write failures; token stays in memory.
      }
      cachedToken = token;
      return cachedToken;
    })().finally(() => {
      pendingTokenPromise = null;
    });
  }

  return pendingTokenPromise;
}

if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'session' && area !== 'local') return;
    const next = changes[TOKEN_STORAGE_KEY]?.newValue;
    if (next) {
      cachedToken = next;
    }
  });
}

export function isTrustedOrigin(origin, fallbackOrigin = null) {
  if (!origin || typeof origin !== 'string') {
    return false;
  }
  if (origin === 'null') {
    return !!fallbackOrigin && TRUSTED_ORIGIN_PATTERN.test(fallbackOrigin);
  }

  const baseOrigin = fallbackOrigin || (typeof window !== 'undefined' ? window.location.origin : null);
  if (baseOrigin && origin === baseOrigin) {
    return true;
  }

  return TRUSTED_ORIGIN_PATTERN.test(origin);
}

export function getFrameOrigin(frame, fallbackOrigin = null) {
  if (!frame) return Result.failure('No frame provided');
  const baseOrigin = fallbackOrigin || (typeof window !== 'undefined' ? window.location.origin : null);
  const rawSrc = frame.getAttribute('src') || '';

  if (!rawSrc || rawSrc === 'about:blank') {
    return Result.success(baseOrigin);
  }

  try {
    const url = new URL(rawSrc, typeof window !== 'undefined' ? window.location.href : undefined);
    return Result.success(url.origin);
  } catch (err) {
    logger.debug('Error parsing frame origin', 'message-auth', err);
    return Result.failure(err);
  }
}
