/**
 * Centralized JSON Parsing Utility
 * Handles various JSON formats including markdown-wrapped responses and extraction
 * of JSON from mixed content. Provides multiple fallback strategies for robustness.
 *
 * @module json-parser
 */

import { createLogger } from './logger.js';

const logger = createLogger('JsonParser');

/**
 * Parses JSON string with various fallback strategies.
 * Attempts direct parsing first, then tries markdown removal and extraction
 * to handle JSON embedded in markdown code blocks or mixed content.
 *
 * @param {string} jsonString - String to parse (may contain markdown or mixed content)
 * @param {Object} [options={}] - Configuration options
 * @param {*} [options.fallback=null] - Fallback value if parsing fails
 * @param {boolean} [options.throwOnError=false] - Whether to throw errors or return fallback
 * @param {boolean} [options.removeMarkdown=true] - Whether to remove markdown code blocks first
 * @returns {*} Parsed JSON object/array, fallback value, or throws error based on options
 */
export function parseJSON(jsonString, options = {}) {
  const {
    fallback = null,
    throwOnError = false,
    removeMarkdown = true
  } = options;

  if (typeof jsonString !== 'string' || jsonString.trim() === '') {
    if (throwOnError) {
      throw new Error('Invalid input: Expected non-empty string');
    }
    return fallback;
  }

  let cleaned = jsonString.trim();
  if (removeMarkdown) {
    cleaned = removeMarkdownCodeBlocks(cleaned);
  }

  // Attempt direct parse first
  try {
    const parsed = JSON.parse(cleaned);
    return {
      data: parsed,
      isValid: true,
      error: null
    };
  } catch (firstError) {
    logger.debug('Initial JSON.parse failed in parseJSON', 'json-parser', firstError);
    // Attempt to extract first JSON payload from mixed content
    const extracted = extractFirstJSON(cleaned);
    if (extracted) {
      try {
        const parsed = JSON.parse(extracted);
        return {
          data: parsed,
          isValid: true,
          error: null
        };
      } catch (secondError) {
        logger.debug('JSON extraction parsing also failed', 'json-parser', secondError);
        // Fall through to error handling
        if (throwOnError) {
          throw new Error(`JSON parsing failed after extraction: ${secondError.message}`);
        }
      }
    }

    if (throwOnError) {
      throw new Error(`JSON parsing failed: ${firstError.message}`);
    }

    logger.warn('JSON parsing failed, returning fallback', 'json-parser', {
      error: firstError.message,
      sample: jsonString.substring(0, 200)
    });

    return {
      data: fallback,
      isValid: false,
      error: firstError.message
    };
  }
}

/**
 * Removes markdown code blocks and backticks from string.
 * Handles common markdown patterns (```json, ```javascript, inline backticks) to clean
 * responses from AI models that wrap JSON in code blocks.
 *
 * @param {string} str - String to clean (may contain markdown formatting)
 * @returns {string} Cleaned string with markdown removed and trimmed
 */
export function removeMarkdownCodeBlocks(str) {
  if (!str) return '';

  let cleaned = str;
  cleaned = cleaned.replace(/```(?:json|javascript|js)?\s*/gi, '');
  cleaned = cleaned.replace(/```\s*/g, '');
  cleaned = cleaned.replace(/`/g, '');

  return cleaned.trim();
}

/**
 * Safely stringifies an object to JSON with circular reference handling
 * and maximum depth protection.
 *
 * @param {*} obj - Object to stringify
 * @param {Object} [options={}] - Configuration options
 * @param {boolean} [options.pretty=false] - Pretty print output
 * @param {number} [options.maxDepth=10] - Maximum depth to traverse
 * @returns {string} JSON string (or '{}' if stringification fails)
 */
export function safeStringify(obj, options = {}) {
  const {
    pretty = false,
    maxDepth = 10
  } = options;

  const seen = new WeakSet();

  const sanitize = (value, depth = 0) => {
    if (depth > maxDepth) {
      return '[Max Depth Exceeded]';
    }

    if (value && typeof value === 'object') {
      if (seen.has(value)) {
        return '[Circular]';
      }
      seen.add(value);

      if (Array.isArray(value)) {
        return value.map((item) => sanitize(item, depth + 1));
      }

      const result = {};
      for (const [key, val] of Object.entries(value)) {
        result[key] = sanitize(val, depth + 1);
      }
      return result;
    }

    return value;
  };

  try {
    const sanitized = sanitize(obj, 0);
    return JSON.stringify(sanitized, null, pretty ? 2 : 0);
  } catch (error) {
    logger.warn('safeStringify failed, returning empty object', 'json-parser', error);
    return '{}';
  }
}

/**
 * Parses multiple JSON objects/arrays from a string.
 * Extracts all JSON objects and arrays from mixed content.
 *
 * @param {string} str - String containing multiple JSON objects or arrays
 * @returns {Array} Array of parsed objects/arrays (empty if none found)
 */
export function parseMultipleJSON(str) {
  const results = [];
  if (typeof str !== 'string' || str.trim() === '') {
    return results;
  }

  let index = 0;
  const source = str.trim();

  while (index < source.length) {
    const nextOpenIndex = source.slice(index).search(/[\[{]/);
    if (nextOpenIndex === -1) break;

    index += nextOpenIndex;
    const candidate = source.slice(index);
    const extracted = extractFirstJSON(candidate);

    if (!extracted) {
      index += 1;
      continue;
    }

    try {
      results.push(JSON.parse(extracted));
    } catch (error) {
      logger.debug('Skipping invalid JSON fragment in parseMultipleJSON', 'json-parser', error);
    }

    index += extracted.length;
  }

  return results;
}

/**
 * Validates if a string is valid JSON.
 * Performs a quick check without throwing errors.
 *
 * @param {string} str - String to validate
 * @returns {boolean} True if the string is valid JSON (object, array, or primitive)
 */
export function isValidJSON(str) {
  if (typeof str !== 'string') return false;

  try {
    JSON.parse(str);
    return true;
  } catch (error) {
    logger.debug('JSON.parse failed in isValidJSON (expected for non-JSON strings)', 'json-parser', error);
    return false;
  }
}

/**
 * Deep clones an object via structured clone when available,
 * falling back to JSON serialization.
 *
 * @param {*} obj - Object to clone
 * @returns {*} Cloned object or null if cloning fails
 */
export function deepClone(obj) {
  try {
    if (typeof structuredClone === 'function') {
      return structuredClone(obj);
    }
  } catch (error) {
    logger.debug('structuredClone failed in deepClone, falling back to JSON method', 'json-parser', error);
  }

  try {
    return JSON.parse(JSON.stringify(obj));
  } catch (error) {
    logger.warn('deepClone failed', 'json-parser', error);
    return undefined;
  }
}

// ============================================================================
// INTERNAL HELPERS
// ============================================================================

/**
 * Extract the first balanced JSON object or array from a string.
 * Walks the string to find matching braces/brackets while respecting string literals.
 *
 * @private
 * @param {string} str - String to search for JSON
 * @returns {string|null} Extracted JSON substring or null if none found
 */
function extractFirstJSON(str) {
  if (!str) return null;

  const startIndex = str.search(/[\[{]/);
  if (startIndex === -1) return null;

  let depth = 0;
  let inString = false;
  let escapeNext = false;
  const startChar = str[startIndex];
  const endChar = startChar === '{' ? '}' : ']';

  for (let i = startIndex; i < str.length; i++) {
    const char = str[i];

    if (escapeNext) {
      escapeNext = false;
      continue;
    }

    if (char === '\\') {
      escapeNext = true;
      continue;
    }

    if (char === '"') {
      inString = !inString;
      continue;
    }

    if (inString) continue;

    if (char === startChar) {
      depth += 1;
    } else if (char === endChar) {
      depth -= 1;
      if (depth === 0) {
        return str.slice(startIndex, i + 1);
      }
    }
  }

  return null;
}
