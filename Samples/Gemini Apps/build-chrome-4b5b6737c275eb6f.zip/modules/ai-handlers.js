/**
 * AI Related Message Handlers
 */
import { makeApiRequest, improveSolution, spellcheckText, getActiveAiModel } from '../api/ai-service.js';
import { Result } from '../utils/result.js';
import { createLogger } from '../utils/logger.js';
import { AI_ANALYSIS_TIMEOUT_MS, JIRA_TICKETS_TIMEOUT_MS, KNOWLEDGE_BASE_TIMEOUT_MS } from '../config/constants.js';
import { parseJSON } from '../utils/json-parser.js';
import { queueRequest } from '../utils/request-queue.js';
import { showInfo } from '../utils/user-notifications.js';
import { handleError, ErrorStrategy } from '../utils/error-handler.js';
import { withTimeout } from '../utils/promise-utils.js';
import { getJiraTickets } from '../api/atlassian-service.js'; // Needed for analyzeCase orchestration
import { searchCommunityGuides } from '../api/community-service.js'; // Needed for analyzeCase orchestration
import { cleanEmailContent } from '../utils/email-helpers.js';

const logger = createLogger('AiHandlers');

/**
 * Handle standardized Promise settlement for orchestrator
 */
function handleSettledPromise(result, context) {
    if (result.status === 'fulfilled') {
        return result.value;
    } else {
        const error = result.reason;
        const message = error instanceof Error ? error.message : String(error || 'Unknown error');
        logger.error('Promise settlement failed', context, error);
        return {
            error: {
                message: message,
                type: error?.constructor?.name || 'Unknown',
                stack: error?.stack,
                details: {
                    context,
                    timestamp: new Date().toISOString()
                }
            },
            status: 'failed'
        };
    }
}

/**
 * Get AI analysis for the case (Helper)
 */
async function getAIAnalysis(caseData) {
    // Get advanced AI settings
    const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');

    const model = await getActiveAiModel();
    const temperature = advancedAiSettings?.contextSettings?.caseSummary?.temperature ?? 0.7;
    const topP = advancedAiSettings?.contextSettings?.caseSummary?.topP ?? 0.95;
    const topK = advancedAiSettings?.contextSettings?.caseSummary?.topK ?? 40;

    // Create a detailed prompt for case analysis
    const prompt = 'Analyze this Salesforce support case and provide a structured response:\n\n' +
        'Case ID: ' + (caseData.caseId || 'N/A') + '\n' +
        'Subject: ' + (caseData.subject || 'N/A') + '\n' +
        'Product: ' + (caseData.productFamily || 'N/A') + '\n' +
        'Component: ' + (caseData.productComponent || 'N/A') + '\n' +
        'Description: ' + (caseData.description ? cleanEmailContent(caseData.description) : 'N/A') + '\n' +
        'Please provide:\n' +
        '1. A brief summary of the issue\n' +
        '2. 2-3 suggested solutions\n' +
        '3. A confidence score (0-1) for your analysis\n' +
        '4. Whether knowledge base search would be helpful (true/false)\n' +
        '5. Key terms related to this case\n\n' +
        'Format your response as JSON with these fields:\n' +
        '- summary: string\n' +
        '- suggestedSolutions: array of strings\n' +
        '- confidenceScore: number (0-1)\n' +
        '- suggestKnowledgeBase: boolean\n' +
        '- relatedTerms: array of strings';

    const mutation =
        'mutation AnalyzeCase($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) {' +
        '  answerPrompt(input: {' +
        '    model: $model' +
        '    prompt: $prompt' +
        '    temperature: $temperature' +
        '    topP: $topP' +
        '    topK: $topK' +
        '  })' +
        '}';

    const variables = {
        model: model,
        prompt: prompt,
        temperature: temperature,
        topP: topP,
        topK: topK
    };

    const response = await makeApiRequest(mutation, variables);

    // Parse the AI response and structure it
    const aiResponse = response.data.answerPrompt;

    // Parse response using centralized JSON parser with fallback
    const parseResult = parseJSON(aiResponse, {
        fallback: {
            summary: aiResponse.substring(0, 200) + '...',
            suggestedSolutions: [aiResponse],
            confidenceScore: 0.0,  // Indicate low confidence for fallback
            suggestKnowledgeBase: true,
            relatedTerms: []
        },
        removeMarkdown: true
    });

    // Check if parsing was successful or we're using a fallback
    if (!parseResult.isValid) {
        logger.warn('AI response invalid JSON, using fallback', 'ai-handlers', {
            error: parseResult.error,
            sample: aiResponse.substring(0, 100)
        });
        try {
            showInfo('AI returned unstructured text; parsed content may be approximate.');
        } catch (e) {
            logger.debug('Failed to show notification', 'ai-handlers', e);
        }
    }

    const parsedResponse = parseResult.data;

    return {
        summary: parsedResponse.summary ?? 'No summary provided',
        suggestedSolutions: parsedResponse.suggestedSolutions ?? ['No solutions suggested'],
        confidenceScore: parsedResponse.confidenceScore ?? 0.5,
        suggestKnowledgeBase: parsedResponse.suggestKnowledgeBase ?? true,
        relatedTerms: parsedResponse.relatedTerms ?? []
    };
}

/**
 * Main function to analyze case data with enhanced error handling
 * All API calls are queued to prevent overwhelming external services
 */
async function analyzeCase(caseData) {
    try {
        if (!caseData || !caseData.caseId) {
            throw new Error('Invalid case data: Missing caseId');
        }

        // Run API calls in parallel with timeout and rate limiting
        const [aiAnalysis, jiraTickets] = await Promise.allSettled([
            queueRequest(() => withTimeout(() => getAIAnalysis(caseData), AI_ANALYSIS_TIMEOUT_MS, 'AI Analysis timed out'), 'ai-analysis'),
            queueRequest(() => withTimeout(() => getJiraTickets(caseData.caseId), JIRA_TICKETS_TIMEOUT_MS, 'Jira tickets fetch timed out'), 'jira-tickets')
        ]);

        // Handle settled promises
        const results = {
            aiAnalysis: handleSettledPromise(aiAnalysis, 'AI Analysis'),
            jiraTickets: handleSettledPromise(jiraTickets, 'Jira Tickets')
        };

        // Only fetch knowledge base if AI analysis was successful and suggests it
        if (results.aiAnalysis?.suggestKnowledgeBase) {
            try {
                results.knowledgeBase = await queueRequest(
                    () => withTimeout(
                        async () => {
                            const res = await searchCommunityGuides(caseData);
                            // Unwrap Result object
                            if (res && typeof res.ok === 'boolean') {
                                if (res.ok) return res.value;
                                throw res.error;
                            }
                            return res; // Fallback for legacy behavior
                        },
                        KNOWLEDGE_BASE_TIMEOUT_MS,
                        'Knowledge base search timed out'
                    ),
                    'kb-search'
                );
            } catch (error) {
                logger.error('Knowledge base search failed', 'analyzeHandler', error);
                handleError(error, {
                    strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
                    context: 'Knowledge Base',
                    operation: 'searchCommunityGuides',
                    userMessage: 'Unable to fetch knowledge base articles. Please try again.'
                });
                results.knowledgeBase = {
                    error: error.message,
                    status: 'failed'
                };
            }
        }

        return Result.success(results);
    } catch (error) {
        logger.error('Error in analyzeCase', 'analyzeHandler', {
            error: error.message,
            stack: error.stack,
            caseId: caseData?.caseId,
            timestamp: new Date().toISOString()
        });
        handleError(error, {
            strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
            context: 'Case Analysis',
            operation: 'analyzeCase',
            userMessage: 'Case analysis failed. Please check your connection and try again.'
        });
        return Result.failure(error);
    }
}

export async function handleAnalyzeCaseRequest(request) {
    return await analyzeCase(request?.data);
}

export async function handleImproveSolutionRequest(request) {
    return await improveSolution(request.currentSolution, request.caseData);
}

export async function handleSpellcheckRequest(request) {
    return await spellcheckText(request.text, request.caseData);
}
