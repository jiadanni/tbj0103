// modules/utils/debounce.js
//
// Reusable debounce and throttle utilities.

import { FILTER_DEBOUNCE_MS, INPUT_DEBOUNCE_MS } from '../config/constants.js';

/**
 * Creates a debounced version of a function that delays execution
 * until after `wait` milliseconds have passed since the last call.
 *
 * @param {Function} fn - Function to debounce
 * @param {number} [wait=FILTER_DEBOUNCE_MS] - Milliseconds to delay
 * @returns {Function} Debounced function with .cancel() method
 *
 * @example
 * const debouncedSearch = debounce((query) => search(query), 300);
 * input.addEventListener('input', (e) => debouncedSearch(e.target.value));
 */
export function debounce(fn, wait = FILTER_DEBOUNCE_MS) {
  let timeoutId = null;

  function debounced(...args) {
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
    }
    timeoutId = setTimeout(() => {
      timeoutId = null;
      fn.apply(this, args);
    }, wait);
  }

  /**
   * Cancel any pending execution
   */
  debounced.cancel = function () {
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  };

  /**
   * Execute immediately and cancel any pending execution
   */
  debounced.flush = function (...args) {
    debounced.cancel();
    fn.apply(this, args);
  };

  return debounced;
}

/**
 * Creates a throttled version of a function that only executes
 * at most once per `wait` milliseconds.
 *
 * @param {Function} fn - Function to throttle
 * @param {number} [wait=INPUT_DEBOUNCE_MS] - Minimum milliseconds between calls
 * @returns {Function} Throttled function
 *
 * @example
 * const throttledScroll = throttle(() => updatePosition(), 100);
 * window.addEventListener('scroll', throttledScroll);
 */
export function throttle(fn, wait = INPUT_DEBOUNCE_MS) {
  let lastCallTime = 0;
  let timeoutId = null;

  return function throttled(...args) {
    const now = Date.now();
    const remaining = wait - (now - lastCallTime);

    if (remaining <= 0) {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      lastCallTime = now;
      fn.apply(this, args);
    } else if (timeoutId === null) {
      timeoutId = setTimeout(() => {
        lastCallTime = Date.now();
        timeoutId = null;
        fn.apply(this, args);
      }, remaining);
    }
  };
}

/**
 * Creates a debounced function with leading edge execution.
 * Executes immediately on first call, then debounces subsequent calls.
 *
 * @param {Function} fn - Function to debounce
 * @param {number} [wait=FILTER_DEBOUNCE_MS] - Milliseconds to delay
 * @returns {Function} Debounced function with leading edge
 */
export function debounceLeading(fn, wait = FILTER_DEBOUNCE_MS) {
  let timeoutId = null;
  let lastCallTime = 0;

  function debounced(...args) {
    const now = Date.now();

    if (timeoutId !== null) {
      clearTimeout(timeoutId);
    }

    // Execute immediately if enough time has passed
    if (now - lastCallTime >= wait) {
      lastCallTime = now;
      fn.apply(this, args);
    } else {
      // Schedule trailing call
      timeoutId = setTimeout(() => {
        lastCallTime = Date.now();
        timeoutId = null;
        fn.apply(this, args);
      }, wait);
    }
  }

  debounced.cancel = function () {
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  };

  return debounced;
}
