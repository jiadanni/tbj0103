/**
 * Authentication and Connection Message Handlers
 */
import { testConnection } from '../api/ai-service.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';

const logger = createLogger('AuthHandlers');

export async function handleTestConnectionRequest(request) {
    try {
        const result = await testConnection(request.token, request.testModel);
        return result; // testConnection already returns a Result
    } catch (err) {
        // Surface clearer error for permission-related failures that require a user gesture
        if (err && (err.code === 'USER_GESTURE_REQUIRED' || err.code === 'MISSING_HOST_PERMISSION' || (err.message && err.message.toLowerCase().includes('user gesture')))) {
            logger.warn('Permission request required from UI for testConnection', 'testConnection', err);
            return Result.failure(new Error('Permission to access the configured AI endpoint is required. Please open extension options and re-run the test from the options page.'));
        }
        return Result.failure(err);
    }
}
