/**
 * AI Prompt Templates Module
 * Centralized templates for AI prompts used across different services.
 * 
 * @module config/ai-prompts
 */

/**
 * Build JIRA relevance analysis prompt
 * @param {Object} caseData - Case context data
 * @param {Array} tickets - List of JIRA tickets to analyze
 * @param {number} minScore - Minimum relevance score threshold
 * @returns {string} The formatted prompt
 */
export function buildJiraAnalysisPrompt(caseData, tickets, minScore) {
    const ticketsList = tickets.map((ticket, index) =>
        `INDEX ${index}: [${ticket.key}] ${ticket.summary}\n` +
        `   Description: ${typeof ticket.description === 'string' ? ticket.description.substring(0, 200) + '...' : 'No description'}`
    ).join('\n\n');

    return `You are analyzing JIRA tickets for relevance to a Salesforce case. You must provide specific explanations that reference the actual ticket summaries and content.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}

Found JIRA Tickets (please reference by exact index):
${ticketsList}

CRITICAL INSTRUCTIONS:
1. Focus PRIMARILY on the case DESCRIPTION to understand the specific problem being reported
2. Analyze if the ticket addresses the same issue described in the case description
3. DO NOT mention the Product Family in your explanation - it's already used to filter the project
4. Your explanation MUST mention the ticket key and how it relates to the SPECIFIC problem from the description
5. Be STRICT with relevance scoring based on description match:
   - 80-100: Ticket addresses the exact same issue/feature as described in the case
   - 60-79: Ticket relates to same component but addresses a different specific issue
   - 40-59: Ticket shares keywords but addresses unrelated functionality
   - 0-39: Ticket is not meaningfully related despite keyword overlap
6. Only include tickets with relevance score >= ${minScore}
7. If NO tickets meet the ${minScore}+ threshold, return empty array: {"rankedTickets": []}
8. Avoid generic explanations - explain how the ticket addresses the specific problem described
9. Ensure your ticketIndex matches exactly with the INDEX numbers above
10. Return ONLY the top 5 most relevant tickets
11. Format as JSON: {"rankedTickets": [{"ticketIndex": 0, "relevanceScore": 95, "explanation": "Ticket [TICKET-KEY] addresses [SPECIFIC ISSUE] which matches the [SPECIFIC PROBLEM FROM DESCRIPTION]"}]}

EXAMPLE of a good explanation: "Ticket IMP-6397 addresses user group permission configuration issues, matching the missing user roles problem described in this case."

EXAMPLE of rejecting a poor match: If case description is about "user group roles in Reports" and ticket is about "Canvas role duplication", score this LOW (under ${minScore}) because they address completely different features (Reports vs Canvas).

Be very careful with ticketIndex - it must match the INDEX numbers listed above.`;
}

/**
 * Build Confluence relevance analysis prompt
 * @param {Object} caseData - Case context data
 * @param {Array} articles - List of Confluence articles to analyze
 * @param {number} minScore - Minimum relevance score threshold
 * @returns {string} The formatted prompt
 */
export function buildConfluenceAnalysisPrompt(caseData, articles, minScore) {
    const articlesList = articles.map((article, index) =>
        `INDEX ${index}: ${article.title}\n` +
        `   Space: ${article.space}\n` +
        `   Excerpt: ${article.excerpt ? article.excerpt.substring(0, 200) + '...' : 'No excerpt'}`
    ).join('\n\n');

    return `You are analyzing Confluence documentation articles for relevance to a Salesforce case. You must provide specific explanations that reference the actual article titles and content snippets.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}

Found Confluence Articles (please reference by exact index):
${articlesList}

CRITICAL INSTRUCTIONS:
1. Read each article title carefully and understand what SPECIFIC topic it covers
2. Analyze if the article has DIRECT semantic relevance to the case subject and description
3. Your explanation MUST mention the specific article title
4. Connect the article content specifically to the case details - identify shared concepts, features, or components
5. Be STRICT with relevance scoring:
   - 80-100: Article addresses the exact same feature/issue as the case
   - 60-79: Article relates to same component/area but different specific issue
   - 40-59: Article shares some keywords but covers unrelated functionality
   - 0-39: Article is not meaningfully related despite keyword overlap
6. Only include articles with relevance score >= ${minScore}
7. If NO articles meet the ${minScore}+ threshold, return empty array: {"rankedArticles": []}
8. Avoid generic explanations like "matches case context" - explain the SPECIFIC connection
9. Ensure your articleIndex matches exactly with the INDEX numbers above
10. Return ONLY the top 5 most relevant articles
11. Format as JSON: {"rankedArticles": [{"articleIndex": 0, "relevanceScore": 95, "explanation": "The article titled '[EXACT TITLE]' directly addresses [SPECIFIC SHARED FEATURE/COMPONENT] which is the core subject of this case."}]}

EXAMPLE of a good explanation: "The guide titled 'Canvas Integration Setup' directly relates to this case because it provides the authentication steps needed for the Canvas SSO error reported."

EXAMPLE of rejecting a poor match: If case is about "Report export errors" and article is about "Canvas role configuration", score this LOW (under ${minScore}) because they share product context but address completely different features (Reports vs Canvas).

Be very careful with articleIndex - it must match the INDEX numbers listed above.`;
}

/**
 * Build Knowledge Base relevance analysis prompt
 * @param {Object} caseData - Case context data
 * @param {Array} guides - List of knowledge base guides to analyze
 * @param {string} entryLabel - Label for KB entries (e.g., "Knowledge Base", "Help Center")
 * @param {number} limit - Maximum number of results to return
 * @returns {string} The formatted prompt
 */
export function buildKnowledgeBaseAnalysisPrompt(caseData, guides, entryLabel, limit) {
    const guidesList = guides.map((guide, index) => {
        const title = (guide.title || 'Untitled').replace(/^\?+/, '').trim();
        const preview = typeof guide.content === 'string'
            ? guide.content.substring(0, 150)
            : (typeof guide.snippet === 'string' ? guide.snippet.substring(0, 150) : 'No preview available');

        return `INDEX ${index}: ${title}\n` +
            `   Category: ${guide.category || 'N/A'}\n` +
            `   Section: ${guide.section || 'N/A'}\n` +
            `   Keywords: ${guide.keywords ? (Array.isArray(guide.keywords) ? guide.keywords.join(', ') : guide.keywords) : 'None'}\n` +
            `   Preview: ${preview}...`;
    }).join('\n\n');

    return `You are analyzing ${entryLabel} content for relevance to a Salesforce case. You must provide specific explanations that reference the actual article titles and content.

Case Context:
- Subject: ${caseData.subject || 'N/A'}
- Description: ${caseData.description || 'N/A'}
- Product Family: ${caseData.productFamily || 'N/A'}
- Product Component: ${caseData.productComponent || 'N/A'}

Found ${entryLabel} articles (please reference by exact index):
${guidesList}

CRITICAL INSTRUCTIONS:
1. Read each guide title carefully and understand what SPECIFIC topic it covers
2. Analyze if the guide has DIRECT semantic relevance to the case subject and description
3. Your explanation MUST mention the specific guide title
4. Connect the guide content specifically to the case details
5. Be STRICT with relevance scoring:
   - 80-100: Guide addresses the exact same feature/issue as the case
   - 60-79: Guide relates to same component/area but different specific issue
   - 40-59: Guide shares some keywords but covers unrelated functionality
   - 0-39: Guide is not meaningfully related despite keyword overlap
6. Only include guides with relevance score >= 50
7. If NO guides meet the 50+ threshold, return empty array: {"rankedArticles": []}
8. Avoid generic explanations like "matches case context" - explain the SPECIFIC connection
9. Ensure your articleIndex matches exactly with the INDEX numbers above
10. Return ONLY the top ${limit} most relevant guides
11. Format as JSON: {"rankedArticles": [{"articleIndex": 0, "relevanceScore": 95, "explanation": "This ${entryLabel.toLowerCase()} article titled '[EXACT TITLE]' directly addresses [SPECIFIC SHARED FEATURE/COMPONENT]"}]}

Be very careful with articleIndex - it must match the INDEX numbers listed above.`;
}

/**
 * Build the GraphQL mutation for AI analysis
 * @param {string} operationName - Name of the mutation operation
 * @returns {string} The GraphQL mutation string
 */
export function buildAiAnalysisMutation(operationName) {
    return `mutation ${operationName}($model: String!, $prompt: String!, $temperature: Float, $topP: Float, $topK: Int) { answerPrompt(input: { model: $model, prompt: $prompt, temperature: $temperature, topP: $topP, topK: $topK }) }`;
}
