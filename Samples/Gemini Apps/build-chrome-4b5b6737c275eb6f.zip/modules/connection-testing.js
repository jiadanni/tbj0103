import { decrypt } from '../security/crypto-utils.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('ConnectionTesting');

export function createConnectionTesting({
  elements,
  messaging,
  permissions,
  helpers
}) {
  const {
    aiServiceTokenInput,
    aiModel1Input: _aiModel1Input,
    aiModel2Input: _aiModel2Input,
    aiModel3Input: _aiModel3Input,
    activeModel1Radio: _activeModel1Radio,
    activeModel2Radio: _activeModel2Radio,
    activeModel3Radio: _activeModel3Radio,
    testAiButton,
    testAiResultElement,
    testAtlassianButton,
    testAtlassianResultElement,
    atlassianTokenInput,
    atlassianBaseUrlInput,
    atlassianEmailInput,
    verboseLoggingToggle,
    localSearchUrlInput,
    checkLocalServerButton,
    localServerStatusElement
  } = elements;

  const { sendMessageWithTimeout } = messaging;
  const { requestHostPermission, checkHostPermission, buildOriginFromUrl } = permissions;
  const { showSectionStatus } = helpers;

  function showAiPermissionMessage(message) {
    if (!testAiResultElement) return;
    testAiResultElement.textContent = message;
    testAiResultElement.className = 'status error';
    testAiResultElement.style.display = 'block';
  }

  async function ensureAiEndpointPermission() {
    try {
      const { apiEndpoint } = await chrome.storage.local.get('apiEndpoint');
      if (!apiEndpoint) {
        showAiPermissionMessage('✗ Please configure an AI Service API endpoint before testing the connection.');
        return false;
      }

      const origin = buildOriginFromUrl(apiEndpoint);
      if (!origin) {
        showAiPermissionMessage('✗ The configured AI endpoint is invalid. Please update the endpoint and try again.');
        return false;
      }

      const hasPerm = await checkHostPermission(origin);
      if (hasPerm) return true;

      const granted = await requestHostPermission(origin);
      if (!granted) {
        showAiPermissionMessage('✗ Permission to access the AI endpoint was denied. Please allow the request and try again.');
        return false;
      }

      return true;
    } catch (err) {
      logger.warn('AI endpoint permission check/request failed during connection test', 'connection-testing', err);
      showAiPermissionMessage('✗ Unable to request permission for the AI endpoint. Please re-open this page, allow the prompt, and try again.');
      return false;
    }
  }

  async function checkLocalServer() {
    if (!localSearchUrlInput || !localSearchUrlInput.value.trim()) {
      showSectionStatus(localServerStatusElement, 'Please enter a Local Search Server URL first', 'error');
      return;
    }

    const rawInput = localSearchUrlInput.value.trim();
    const baseUrl = rawInput.replace(/\/$/, '');
    const origin = buildOriginFromUrl(rawInput);

    if (!origin) {
      showSectionStatus(localServerStatusElement, 'Local Search URL is invalid. Please include host and optional port (e.g., http://localhost:5002).', 'error');
      return;
    }

    try {
      const hasPerm = await checkHostPermission(origin);
      if (!hasPerm) {
        const granted = await requestHostPermission(origin);
        if (!granted) {
          showSectionStatus(localServerStatusElement, 'Permission to access the Local Search Server was not granted. Click "Request Permission" or allow when prompted.', 'error');
          return;
        }
      }
    } catch (err) {
      logger.warn('Permission check/request failed:', 'connection-testing', err);
    }

    const testUrl = baseUrl + '/search';

    if (checkLocalServerButton) {
      checkLocalServerButton.disabled = true;
      setLoadingState(checkLocalServerButton, 'Checking...');
    }
    if (localServerStatusElement) localServerStatusElement.style.display = 'none';

    try {
      const response = await fetch(testUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: 'health-check' })
      });

      if (!response.ok) {
        const txt = await response.text();
        showSectionStatus(localServerStatusElement, `Server responded ${response.status}: ${txt}`, 'error');
      } else {
        const data = await response.json().catch(() => null);
        const details = data && data.info ? ` - ${JSON.stringify(data.info)}` : '';
        showSectionStatus(localServerStatusElement, `Local search server reachable${details}`, 'success');
      }
    } catch (error) {
      logger.debug('Local search server check error', 'connection-testing', error);
      showSectionStatus(localServerStatusElement, `Failed to reach server: ${error.message}`, 'error');
    } finally {
      if (checkLocalServerButton) {
        checkLocalServerButton.disabled = false;
        checkLocalServerButton.textContent = 'Check Local Server';
      }
      if (localServerStatusElement) localServerStatusElement.style.display = 'block';
    }
  }

  async function testAiConnection() {
    let aiServiceToken = '';

    const isSavedToken = aiServiceTokenInput?.getAttribute('data-is-saved') === 'true';

    if (isSavedToken) {
      try {
        const { aiServiceToken: encryptedToken } = await chrome.storage.local.get('aiServiceToken');
        if (encryptedToken) {
          const result = await decrypt(encryptedToken);
          if (result.ok) {
            aiServiceToken = result.value;
          } else {
            const deErr = result.error;
            // If decryption failed due to session key mismatch, clear the "saved" flag
            // so the UI prompts the user to re-enter the token, surface a helpful message,
            // and return early rather than rethrowing (which produced duplicate logs).
            if (deErr && deErr.code === 'SESSION_KEY_MISMATCH') {
              logger.warn('Saved AI token could not be decrypted - clearing saved flag', 'connection-testing', deErr);
              // Remove saved token and mark input as not-saved to force re-entry
              try {
                await chrome.storage.local.remove('aiServiceToken');
              } catch (e) {
                logger.warn('Failed to remove corrupted saved AI token:', 'connection-testing', e);
              }
              if (aiServiceTokenInput) {
                aiServiceTokenInput.removeAttribute('data-is-saved');
                aiServiceTokenInput.value = '';
              }

              // Show a clear UI message and exit the flow so the user re-enters token
              if (testAiResultElement) {
                testAiResultElement.textContent = '✗ Saved API token could not be decrypted (session key lost). Please re-enter your AI Service API token and save it again.';
                testAiResultElement.className = 'status error';
                testAiResultElement.style.display = 'block';
              }

              return; // stop further processing
            }

            // Other decryption errors - let outer catch handle/log them
            throw deErr;
          }
        }
      } catch (e) {
        logger.error('Failed to decrypt saved AI token:', 'connection-testing', e);
      }
    } else {
      aiServiceToken = aiServiceTokenInput ? aiServiceTokenInput.value.trim() : '';
    }

    if (!aiServiceToken) {
      testAiResultElement.textContent = 'Please enter an AI Service API token first';
      testAiResultElement.className = 'status error';
      testAiResultElement.style.display = 'block';
      return;
    }

    const permissionReady = await ensureAiEndpointPermission();
    if (!permissionReady) return;

    const activeModelRadio = document.querySelector('input[name="active-model"]:checked');
    const activeModelNum = activeModelRadio ? activeModelRadio.value : '1';
    const modelInput = document.getElementById(`ai-model-${activeModelNum}`);
    const activeModel = modelInput ? modelInput.value.trim() : '';

    if (testAiButton) {
      testAiButton.disabled = true;
      setLoadingState(testAiButton, 'Testing AI Service & Model...');
    }
    if (testAiResultElement) testAiResultElement.style.display = 'none';

    document.querySelectorAll('.model-option').forEach(el => {
      el.style.borderColor = '#e0e0e0';
    });

    try {
      const response = await sendMessageWithTimeout({
        action: 'testConnection',
        token: aiServiceToken,
        testModel: activeModel || undefined
      }, 15000);

      if (response.ok) {
        testAiResultElement.textContent = `✓ AI Service connection successful! Response time: ${response.data.responseTime}${activeModel ? `\n✓ Model "${activeModel}" is supported` : ''}`;
        testAiResultElement.className = 'status success';

        const activeModelOption = document.getElementById(`model-option-${activeModelNum}`);
        if (activeModelOption) {
          activeModelOption.style.borderColor = '#28a745';
        }
      } else {
        const errorMsg = response.error || 'Unknown error';
        testAiResultElement.textContent = `✗ AI Service connection failed: ${errorMsg}`;
        testAiResultElement.className = 'status error';

        if (errorMsg.includes('not supported') && activeModel) {
          testAiResultElement.textContent = `✗ Model "${activeModel}" is not supported by the AI service.\n\nPlease choose a different model or check with your administrator for supported models.`;
          const activeModelOption = document.getElementById(`model-option-${activeModelNum}`);
          if (activeModelOption) {
            activeModelOption.style.borderColor = '#dc3545';
          }
        }
      }
    } catch (error) {
      logger.error('Error testing AI connection:', 'connection-testing', error);
      if (error && error.code === 'SESSION_KEY_MISMATCH') {
        testAiResultElement.textContent = '✗ Saved API token could not be decrypted (session key lost). Please re-enter your AI Service API token and save it again.';
      } else {
        testAiResultElement.textContent = `✗ Error: ${error.message || 'Failed to connect to the AI service'}`;
      }
      testAiResultElement.className = 'status error';
    } finally {
      if (testAiResultElement) testAiResultElement.style.display = 'block';
      if (testAiButton) {
        testAiButton.disabled = false;
        testAiButton.textContent = 'Test AI Connection & Validate Model';
      }
    }
  }

  async function testAtlassianConnection() {
    let atlassianToken = '';
    const atlassianBaseUrl = atlassianBaseUrlInput ? atlassianBaseUrlInput.value.trim() : '';
    const atlassianEmail = atlassianEmailInput ? atlassianEmailInput.value.trim() : '';

    const isSavedToken = atlassianTokenInput?.getAttribute('data-is-saved') === 'true';

    if (isSavedToken) {
      try {
        const { atlassianToken: encryptedToken } = await chrome.storage.local.get('atlassianToken');
        if (encryptedToken) {
          const result = await decrypt(encryptedToken);
          if (result.ok) {
            atlassianToken = result.value;
          } else {
            const deErr = result.error;
            if (deErr && deErr.code === 'SESSION_KEY_MISMATCH') {
              logger.warn('Saved Atlassian token could not be decrypted - clearing saved flag', 'connection-testing', deErr);
              try {
                await chrome.storage.local.remove('atlassianToken');
              } catch (e) {
                logger.warn('Failed to remove corrupted saved Atlassian token:', 'connection-testing', e);
              }
              if (atlassianTokenInput) {
                atlassianTokenInput.removeAttribute('data-is-saved');
                atlassianTokenInput.value = '';
              }

              if (testAtlassianResultElement) {
                testAtlassianResultElement.textContent = '✗ Saved Atlassian token could not be decrypted (session key lost). Please re-enter your Atlassian API token and save it again.';
                testAtlassianResultElement.className = 'status error';
                testAtlassianResultElement.style.display = 'block';
              }

              return;
            }

            throw deErr;
          }
        }
      } catch (e) {
        logger.error('Failed to decrypt saved Atlassian token:', 'connection-testing', e);
      }
    } else {
      atlassianToken = atlassianTokenInput ? atlassianTokenInput.value.trim() : '';
    }

    if (!atlassianToken) {
      testAtlassianResultElement.textContent = 'Please enter an Atlassian API token first';
      testAtlassianResultElement.className = 'status error';
      testAtlassianResultElement.style.display = 'block';
      return;
    }

    if (!atlassianBaseUrl) {
      testAtlassianResultElement.textContent = 'Please enter an Atlassian base URL first';
      testAtlassianResultElement.className = 'status error';
      testAtlassianResultElement.style.display = 'block';
      return;
    }

    if (!atlassianEmail) {
      testAtlassianResultElement.textContent = 'Please enter your Atlassian email address first';
      testAtlassianResultElement.className = 'status error';
      testAtlassianResultElement.style.display = 'block';
      return;
    }

    if (testAtlassianButton) {
      testAtlassianButton.disabled = true;
      setLoadingState(testAtlassianButton, 'Testing Atlassian Connection...');
    }
    if (testAtlassianResultElement) testAtlassianResultElement.style.display = 'none';

    try {
      const response = await sendMessageWithTimeout({
        action: 'testAtlassianConnection',
        atlassianToken,
        atlassianBaseUrl,
        atlassianEmail
      }, 45000);

      if (response.ok) {
        const details = response.data || {};
        testAtlassianResultElement.textContent = `Atlassian connection successful! Connected as: ${details.user} (${details.responseTime})`;
        testAtlassianResultElement.className = 'status success';
      } else {
        const baseMsg = response.error || 'Unknown error';
        let detailsMsg = '';
        if (response && response.details) {
          const code = response.details.statusCode;
          const body = response.details.responseBody;
          if (code) detailsMsg += ` Status: ${code}.`;
          if (body && verboseLoggingToggle && verboseLoggingToggle.checked) {
            detailsMsg += ` Response: ${body}`;
          } else if (body) {
            detailsMsg += ' (enable Verbose Logging to see response body)';
          }
        }

        testAtlassianResultElement.textContent = `Atlassian connection failed: ${baseMsg}${detailsMsg}`;
        testAtlassianResultElement.className = 'status error';
      }
    } catch (error) {
      logger.error('Error testing Atlassian connection:', 'connection-testing', error);
      testAtlassianResultElement.textContent = `Error: ${error.message || 'Failed to connect to Atlassian services'}`;
      testAtlassianResultElement.className = 'status error';
    } finally {
      if (testAtlassianResultElement) testAtlassianResultElement.style.display = 'block';
      if (testAtlassianButton) {
        testAtlassianButton.disabled = false;
        testAtlassianButton.textContent = 'Test Atlassian Connection';
      }
    }
  }

  return {
    checkLocalServer,
    testAiConnection,
    testAtlassianConnection
  };
}

function setLoadingState(button, text) {
  if (!button) return;
  button.replaceChildren();
  const spinner = document.createElement('span');
  spinner.className = 'loading';
  button.appendChild(spinner);
  button.appendChild(document.createTextNode(` ${text}`));
}
