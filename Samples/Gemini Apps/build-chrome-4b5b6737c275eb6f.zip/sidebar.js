(function () {
  'use strict';

  /**
   * Promise utilities used throughout the extension.
   */

  const DEFAULT_TIMEOUT_MESSAGE = 'Operation timed out';

  /**
   * Wrap an async operation with a timeout. The operation can be a promise or a
   * function that returns a promise. Ensures the timeout timer is cleared when
   * the operation settles to avoid leaking timers.
   *
   * @param {Promise|Function} operation - Promise or function returning a promise
   * @param {number} ms - Timeout duration in milliseconds
   * @param {string} [errorMessage] - Custom error message for timeout
   * @returns {Promise<any>} Resolves/rejects with the underlying operation
   */
  function withTimeout(operation, ms, errorMessage = DEFAULT_TIMEOUT_MESSAGE) {
    const execute = typeof operation === 'function' ? operation : () => operation;

    if (!Number.isFinite(ms) || ms <= 0) {
      return Promise.resolve().then(() => execute());
    }

    let timeoutId = null;
    let settled = false;

    const startTimer = () => new Promise((_, reject) => {
      timeoutId = setTimeout(() => {
        if (settled) {
          return;
        }
        const error = new Error(errorMessage);
        error.name = 'TimeoutError';
        reject(error);
      }, ms);

      if (typeof timeoutId?.unref === 'function') {
        timeoutId.unref();
      }
    });

    const clearTimer = () => {
      settled = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    };

    return Promise.race([
      Promise.resolve().then(() => execute()),
      startTimer()
    ]).then((result) => {
      clearTimer();
      return result;
    }).catch((error) => {
      clearTimer();
      throw error;
    });
  }

  /**
   * Helper specifically for wrapping dynamic imports with a timeout.
   * @param {string} url - Module URL to import
   * @param {number} timeoutMs - Timeout duration
   * @param {string} [label] - Label for error messages
   * @returns {Promise<any>} Resolves with the imported module
   */
  function importWithTimeout(url, timeoutMs, label = url) {
    const contextLabel = label || url;
    const message = `Dynamic import timed out after ${timeoutMs}ms: ${contextLabel}`;
    return withTimeout(() => import(url), timeoutMs, message);
  }

  /**
   * Centralized Logging Utility
   * Provides consistent logging across the extension with verbose mode support
   *
   * @module logger
   */

  // ============================================================================
  // LOG LEVELS
  // ============================================================================

  /**
   * Log severity levels
   * @enum {string}
   * @readonly
   */
  const LogLevel = {
    ERROR: 'error',   // Critical errors that need immediate attention
    WARN: 'warn',     // Warnings about potential issues
    INFO: 'info',     // Important informational messages (always shown)
    DEBUG: 'debug',   // Detailed debugging information (verbose mode only)
    TRACE: 'trace'    // Very detailed trace information (verbose mode only)
  };

  // ============================================================================
  // LOGGER CLASS
  // ============================================================================

  class Logger {
    /**
     * Create a new logger instance with optional context.
     *
     * @param {string} [context='PandAid'] - Context name for this logger (appears in all log messages)
     */
    constructor(context = 'PandAid') {
      this.context = context;
      this.verboseEnabled = false;
      this.initialized = false;

      // Kick off async load without blocking construction
      this.loadVerbosePreference().catch((error) => {
        logger$o.warn('[Logger] Failed to load verbose preference', 'logger', error);
      });
    }

    /**
     * Load verbose logging preference from Chrome storage.
     * Called automatically during constructor initialization.
     *
     * @private
     * @async
     * @returns {Promise<void>}
     */
    async loadVerbosePreference() {
      if (this.initialized) return;
      this.initialized = true;

      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        return;
      }

      try {
        const result = await chrome.storage.local.get(['verboseLogging']);
        if (Object.prototype.hasOwnProperty.call(result, 'verboseLogging')) {
          this.verboseEnabled = !!result.verboseLogging;
        }
      } catch (error) {
        logger$o.warn('[Logger] Error reading verbose logging preference', 'logger', error);
      }
    }

    /**
     * Set verbose mode at runtime.
     * Useful for toggling detailed logging during debugging or testing.
     *
     * @param {boolean} enabled - Whether to enable verbose logging
     */
    setVerbose(enabled = false) {
      this.verboseEnabled = !!enabled;
    }

    /**
     * Check if verbose logging is currently enabled.
     *
     * @returns {boolean} True if verbose logging is enabled
     */
    isVerboseEnabled() {
      return this.verboseEnabled;
    }

    /**
     * Format log message with timestamp and context.
     * Internal helper method for consistent formatting across all log levels.
     *
     * @private
     * @param {string} level - Log level (from LogLevel enum)
     * @param {string} context - Additional context string
     * @param {string} message - The message to format
     * @returns {string} Formatted message with timestamp
     */
    formatMessage(level, context, message) {
      const timestamp = new Date().toISOString().substring(11, 23); // HH:MM:SS.mmm
      const contextLabel = context ? `${this.context}:${context}` : this.context;
      return `[${timestamp}] [${contextLabel}] [${level.toUpperCase()}] ${message}`;
    }

    /**
     * Log error message (always shown regardless of verbose mode).
     * Use for critical errors that need immediate attention.
     *
     * @param {string} message - The error message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data/error object to log
     */
    error(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.ERROR, context, message);
      if (data !== null) {
        console.error(formatted, data);
      } else {
        console.error(formatted);
      }
    }

    /**
     * Log warning message (always shown regardless of verbose mode).
     * Use for potential issues or unexpected conditions.
     *
     * @param {string} message - The warning message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    warn(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.WARN, context, message);
      if (data !== null) {
        console.warn(formatted, data);
      } else {
        console.warn(formatted);
      }
    }

    /**
     * Log info message (always shown regardless of verbose mode).
     * Use for important informational messages about normal operation.
     *
     * @param {string} message - The info message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    info(message, context = '', data = null) {
      const formatted = this.formatMessage(LogLevel.INFO, context, message);
      if (data !== null) {
        console.info(formatted, data);
      } else {
        console.info(formatted);
      }
    }

    /**
     * Log debug message (only shown if verbose logging is enabled).
     * Use for detailed debugging information during development/troubleshooting.
     *
     * @param {string} message - The debug message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    debug(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.DEBUG, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Log trace message (only shown if verbose logging is enabled).
     * Used for very detailed logging like function entry/exit, state changes, etc.
     *
     * @param {string} message - The trace message to log
     * @param {string} [context=''] - Optional context (e.g., function name, module)
     * @param {*} [data=null] - Optional associated data to log
     */
    trace(message, context = '', data = null) {
      if (!this.verboseEnabled) return;

      const formatted = this.formatMessage(LogLevel.TRACE, context, message);
      if (data !== null) {
        console.debug(formatted, data);
      } else {
        console.debug(formatted);
      }
    }

    /**
     * Create a child logger with a specific context.
     * Child loggers inherit the parent's verbose mode setting.
     *
     * @param {string} childContext - The child context name (appended to parent context)
     * @returns {Logger} New logger instance with combined context
     */
    child(childContext) {
      const childLogger = new Logger(`${this.context}:${childContext}`);
      childLogger.setVerbose(this.verboseEnabled);
      childLogger.initialized = true; // Do not re-read storage; inherit setting
      return childLogger;
    }

    /**
     * Log a group of related messages together.
     * Groups are only shown if verbose logging is enabled.
     *
     * @param {string} groupName - Name/title of the log group
     * @param {Function} fn - Function containing logger calls to group
     */
    group(groupName, fn) {
      if (!this.verboseEnabled) return;

      console.group(`[${this.context}] ${groupName}`);
      try {
        fn();
      } finally {
        console.groupEnd();
      }
    }

    /**
     * Execute a function and log its execution time.
     * Timing output is only shown if verbose logging is enabled.
     *
     * @param {string} label - Label for the timer (shown in timing output)
     * @param {Function} fn - Async function to time (can also be sync)
     * @returns {Promise<*>} Result of the function
     */
    async time(label, fn) {
      const timerLabel = `[${this.context}] ${label}`;
      if (this.verboseEnabled) {
        console.time(timerLabel);
      }

      try {
        return await fn();
      } finally {
        if (this.verboseEnabled) {
          console.timeEnd(timerLabel);
        }
      }
    }
  }

  // ============================================================================
  // GLOBAL LOGGER INSTANCE
  // ============================================================================

  // Create default logger instance
  const defaultLogger = new Logger('PandAid');

  // Export factory function
  function createLogger(context = 'PandAid') {
    const newLogger = new Logger(context);
    newLogger.setVerbose(defaultLogger.isVerboseEnabled());
    return newLogger;
  }

  // Export default logger
  const logger$o = defaultLogger;

  // ============================================================================
  // STORAGE LISTENER
  // ============================================================================

  // Listen for changes to verbose logging preference
  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.verboseLogging) {
        const newValue = !!changes.verboseLogging.newValue;
        defaultLogger.setVerbose(newValue);
        logger$o.info(`[PandAid] Verbose logging ${newValue ? 'enabled' : 'disabled'}`, 'contextual', undefined);
      }
    });
  }

  // modules/config/constants.js
  //
  // Centralized configuration constants for timeouts, intervals, and limits.
  // Import from here instead of using magic numbers throughout the codebase.


  // =============================================================================
  // MESSAGE TIMEOUTS
  // =============================================================================

  /** Default timeout for chrome.runtime message responses (ms) */
  const MESSAGE_RESPONSE_TIMEOUT_MS = 35000;

  /** Timeout for dynamic module imports (ms) */
  const DYNAMIC_IMPORT_TIMEOUT_MS = 10000;

  /**
   * Sidebar State Manager
   * Handles state derivation, settings retrieval, and UI synchronization.
   * Refactored to separate Data (State) from View (DOM).
   */


  const logger$n = createLogger('StateManager');

  class SidebarStateManager {
      constructor() {
          this.isAuthenticated = false;
      }

      /**
       * Load all configuration and derive the target state for the sidebar
       * @returns {Promise<Object>} The calculated state object
       */
      async loadState() {
          // FAST FAIL: Check context validity before anything else
          // This prevents "active" checks or logs from crashing if the runtime is gone
          if (typeof chrome === 'undefined' || !chrome.runtime?.id) {
              return {
                  valid: false,
                  error: new Error('Extension context invalidated')
              };
          }

          try {
              const keys = [
                  'atlassianToken',
                  'aiServiceToken',
                  'preloadSettings',
                  'communityGuides',
                  'sidebarSections',
                  'knowledgeBaseLabels'
              ];

              const storage = await chrome.storage.local.get(keys);

              const sectionVisibility = this.normalizeSectionVisibility(storage.sidebarSections);
              const communitySettings = this.deriveCommunitySettings(storage.preloadSettings, storage.communityGuides);

              return {
                  valid: true,
                  tokens: {
                      atlassian: !!(storage.atlassianToken && storage.atlassianToken.trim()),
                      ai: !!(storage.aiServiceToken)
                  },
                  visibility: sectionVisibility,
                  preload: {
                      jira: storage.preloadSettings?.jira !== false,
                      confluence: storage.preloadSettings?.confluence !== false,
                      community: communitySettings.shouldPreloadCommunity
                  },
                  hasCommunityGuides: communitySettings.hasCommunityGuides,
                  labels: storage.knowledgeBaseLabels || { entryLabel: 'Knowledge Base', sidebarLabel: 'Knowledge Base' }
              };

          } catch (error) {
              logger$n.error('Error loading state:', 'state-manager', error);
              return {
                  valid: false,
                  error: error
              };
          }
      }

      normalizeSectionVisibility(sections = {}) {
          return {
              jira: sections.jira !== false,
              confluence: sections.confluence !== false,
              community: sections.community !== false
          };
      }

      deriveCommunitySettings(preloadSettings = {}, communityGuides = []) {
          const shouldPreloadCommunity = (typeof preloadSettings?.community !== 'undefined')
              ? preloadSettings.community !== false
              : preloadSettings?.knowledgeBase !== false;

          const hasCommunityGuides = Array.isArray(communityGuides) && communityGuides.length > 0;

          return { shouldPreloadCommunity, hasCommunityGuides };
      }
  }

  // ============================================================================
  // UI RENDRING HELPERS (View Layer)
  // These functions apply the State object to the DOM.
  // They mimic the legacy resetToInitialState behavior but use the clean State object.
  // ============================================================================

  function renderStatus(container, className, text) {
      if (!container) return;
      const el = document.createElement('div');
      el.className = className;
      el.textContent = text;
      container.replaceChildren(el);
  }

  /**
   * Apply the calculated state to the Sidebar UI
   * @param {Object} sidebar - The Sidebar View Controller instance
   * @param {Object} state - The state object from SidebarStateManager.loadState()
   */
  function applyStateToView(sidebar, state) {
      if (!state.valid) {
          handleStateLoadError(sidebar, state.error);
          return;
      }

      // 1. Apply Visibility
      if (typeof sidebar.applySectionVisibility === 'function') {
          sidebar.applySectionVisibility(state.visibility);
      }

      // 2. Render Section States (Loading vs Fetch Button)

      // JIRA
      if (state.visibility.jira) {
          if (state.preload.jira) {
              const list = sidebar.sidebar.querySelector('#jira-list');
              renderStatus(list, 'loading', 'Loading JIRA tickets...');
              // Trigger side-effect (Controller action)
              sidebar.preloadJiraTickets().catch((err) => { logger$n.debug('Initial JIRA preload failed in applyStateToView', 'state-manager', err); });
          } else {
              sidebar.renderFetchButton('jira', state.tokens.atlassian);
          }
      }

      // Confluence
      if (state.visibility.confluence) {
          if (state.preload.confluence) {
              const list = sidebar.sidebar.querySelector('#confluence-list');
              renderStatus(list, 'loading', 'Loading Confluence pages...');
              sidebar.preloadConfluenceArticles().catch((err) => { logger$n.debug('Initial Confluence preload failed in applyStateToView', 'state-manager', err); });
          } else {
              sidebar.renderFetchButton('confluence', state.tokens.atlassian);
          }
      }

      // Community / Knowledge Base
      if (state.visibility.community) {
          if (state.preload.community) {
              if (state.hasCommunityGuides) {
                  const list = sidebar.sidebar.querySelector('#community-list');
                  const label = state.labels.sidebarLabel || 'Knowledge Base';
                  renderStatus(list, 'loading', `Loading ${label}...`);
                  sidebar.preloadCommunityGuides().catch((err) => { logger$n.debug('Initial Community preload failed in applyStateToView', 'state-manager', err); });
              } else {
                  // No knowledge base data loaded - show grayed-out fetch button
                  sidebar.renderFetchButton('community', false);
              }
          } else {
              // Preload disabled - show fetch button (grayed out if no data available)
              sidebar.renderFetchButton('community', state.hasCommunityGuides);
          }
      }
  }

  function handleStateLoadError(sidebar, error) {
      // Handle extension context invalidated specifically
      if (error && (error.message.includes('Extension context invalidated') ||
          error.message.includes('receiving end does not exist'))) {
          const reloadMessage = 'PandAid was updated. Please refresh your browser page to continue.';

          ['#jira-list', '#confluence-list', '#community-list'].forEach(selector => {
              const list = sidebar.sidebar.querySelector(selector);
              if (list) {
                  renderStatus(list, 'info', reloadMessage);
                  const btn = document.createElement('button');
                  btn.className = 'action-button';
                  btn.style.marginTop = '8px';
                  btn.textContent = 'Refresh Page';
                  btn.onclick = () => window.location.reload();
                  list.appendChild(btn);
              }
          });
      } else {
          // Fallback: show fetch buttons
          sidebar.renderFetchButton('jira', false);
          sidebar.renderFetchButton('confluence', false);
          sidebar.renderFetchButton('community', false);
      }
  }

  /**
   * Reset UI elements to their initial clean state
   * @param {Object} sidebar - Sidebar instance
   */
  function resetDOM(sidebar) {
      // Clear text areas
      const originalInput = sidebar.sidebar.querySelector('#original-text-input');
      const improvedInput = sidebar.sidebar.querySelector('#improved-text-input');
      if (originalInput) originalInput.value = '';
      if (improvedInput) improvedInput.value = '';

      // Clear current solution state
      sidebar.currentSolution = null;

      // Hide improved section
      const improvedSection = sidebar.sidebar.querySelector('#improved-section');
      if (improvedSection) improvedSection.classList.add('hidden');

      // Remove enhanced badges
      try {
          sidebar.sidebar.querySelectorAll('.related-section.enhanced').forEach(sec => {
              sec.classList.remove('enhanced');
              const badge = sec.querySelector('.enhanced-badge');
              if (badge) badge.remove();
          });
      } catch (e) {
          logger$n.warn('Failed to remove enhanced badges during reset', 'resetDOM', e);
      }

      // Reset Case Info
      const caseDetailsDiv = sidebar.sidebar.querySelector('#case-details');
      if (caseDetailsDiv) {
          const caseInfo = caseDetailsDiv.querySelector('#case-info');
          const loadingHTML = '<div class="loading">Click "PandAid" to load case details...</div>';
          if (caseInfo) caseInfo.innerHTML = loadingHTML;
      }

      // Reset errors and buttons
      sidebar.sidebar.querySelectorAll('.error').forEach(el => el.remove());
      sidebar.sidebar.querySelectorAll('button').forEach(btn => {
          if (btn.id !== 'ai-sidebar-close-btn') {
              const originalText = btn.getAttribute('data-original-text');
              // Simple text reset
              if (originalText) {
                  const textSpan = btn.querySelector('.button-text');
                  if (textSpan) textSpan.textContent = originalText.replace(/^[^\s]+\s/, '');
              }
              btn.disabled = false;
          }
      });

      sidebar.ensureRefreshButtonWired();
  }

  /**
   * messaging.js
   *
   * Centralized messaging utilities for communication between extension components.
   */


  const logger$m = createLogger('Messaging');

  /**
   * Sends a message with a timeout.
   * @param {Object} message - The message payload.
   * @param {number} timeout - Timeout in milliseconds.
   * @returns {Promise<any>}
   */
  async function sendMessageWithTimeout(message, timeout = MESSAGE_RESPONSE_TIMEOUT_MS) {
      return new Promise((resolve, reject) => {
          let done = false;
          const timer = setTimeout(() => {
              if (!done) {
                  done = true;
                  reject(new Error(`No response from background (timeout after ${timeout}ms)`));
              }
          }, timeout);

          try {
              chrome.runtime.sendMessage(message, (resp) => {
                  if (done) return;
                  done = true;
                  clearTimeout(timer);
                  const lastErr = chrome.runtime.lastError;
                  if (lastErr) return reject(lastErr);
                  resolve(resp);
              });
          } catch (err) {
              if (!done) {
                  done = true;
                  clearTimeout(timer);
                  logger$m.warn('Message sending failed', 'sendMessageWithTimeout', err);
                  reject(err);
              }
          }
      });
  }

  // modules/sidebar/state/storage.js


  const logger$l = createLogger('StorageUtils');
  //
  // Helpers for persisting sidebar UI preferences.

  async function applySidebarWidth(sidebarInstance) {
    try {
      const result = await chrome.storage.local.get(['sidebarWidth']);
      const width = result.sidebarWidth || 500;
      const target = sidebarInstance?.sidebarHost || document.documentElement;
      target.style.setProperty('--sidebar-width', `${width}px`);
      if (sidebarInstance?.vlog) {
        sidebarInstance.vlog('[Sidebar] Applied width:', width);
      }
    } catch (error) {
      logger$l.debug('Error in applySidebarWidth, falling back to 500px', 'storage-utils', error);
      const target = sidebarInstance?.sidebarHost || document.documentElement;
      target.style.setProperty('--sidebar-width', '500px');
    }
  }

  function saveCollapseStateEntry(_sidebarInstance, controlId, isCollapsed) {
    try {
      const key = 'sidebarCollapseState';
      chrome.storage.local.get([key], (result) => {
        const state = result[key] || {};
        state[controlId] = !!isCollapsed;
        const put = {};
        put[key] = state;
        chrome.storage.local.set(put, () => { });
      });
    } catch (e) {
      logger$l.error('Error saving collapse state:', 'storage-utils', e);
    }
  }

  function restoreCollapseState(sidebarInstance) {
    const sidebar = sidebarInstance?.sidebar;
    if (!sidebar) return;
    try {
      const key = 'sidebarCollapseState';
      chrome.storage.local.get([key], (result) => {
        const state = result[key] || {};
        const sections = sidebar.querySelectorAll('.related-section');
        sections.forEach(section => {
          const list = section.querySelector('.items-list');
          if (!list) return;
          const id = list.id;
          const shouldCollapse = !!state[id];
          const toggleBtn = section.querySelector('.section-toggle');
          if (shouldCollapse) {
            section.classList.add('collapsed');
            if (toggleBtn) {
              toggleBtn.setAttribute('aria-expanded', 'false');
              toggleBtn.textContent = '▸';
            }
          } else {
            section.classList.remove('collapsed');
            if (toggleBtn) {
              toggleBtn.setAttribute('aria-expanded', 'true');
              toggleBtn.textContent = '▾';
            }
          }
        });
      });
    } catch (e) {
      logger$l.error('Error restoring collapse state:', 'storage-utils', e);
    }
  }

  var storageUtils = /*#__PURE__*/Object.freeze({
    __proto__: null,
    applySidebarWidth: applySidebarWidth,
    restoreCollapseState: restoreCollapseState,
    saveCollapseStateEntry: saveCollapseStateEntry
  });

  const logger$k = createLogger('SidebarLabels');

  function getProductIconHTML$1(sidebar, productName) {
      if (sidebar.uiModule && typeof sidebar.uiModule.getProductIconHTML === 'function') {
          try { return sidebar.uiModule.getProductIconHTML(sidebar, productName); } catch (e) { logger$k.debug('sidebar.uiModule.getProductIconHTML failed in labels.js', 'labels', e); }
      }
      // fallback to existing inline logic
      if (sidebar.utils && typeof sidebar.utils.getProductIconHTML === 'function') {
          try { return sidebar.utils.getProductIconHTML(productName); } catch (e) { logger$k.debug('sidebar.utils.getProductIconHTML failed in labels.js', 'labels', e); }
      }
      if (!productName) return '';
      const productLower = productName.toLowerCase();
      if (productLower === 'impact' || productLower.includes('impact')) {
          return `<img src="${chrome.runtime.getURL('icons/impact.svg')}" alt="Impact" class="product-icon" />`;
      }
      return '';
  }

  /**
   * Get the current label for Knowledge Base based on context.
   */
  function getKnowledgeBaseLabel(sidebar, type = 'entry') {
      const entry = sidebar.knowledgeBaseLabels?.entryLabel || 'Knowledge Base';
      const sidebarLabel = sidebar.knowledgeBaseLabels?.sidebarLabel || entry;

      if (type === 'sidebar') return sidebarLabel;
      if (type === 'options') return `${entry} Guides`;
      return entry;
  }

  /**
   * Load Knowledge Base labels from storage.
   */
  async function loadKnowledgeBaseLabels(sidebar) {
      try {
          const { knowledgeBaseLabels } = await chrome.storage.local.get('knowledgeBaseLabels');
          if (knowledgeBaseLabels) {
              sidebar.knowledgeBaseLabels = {
                  entryLabel: knowledgeBaseLabels.entryLabel?.trim() || 'Knowledge Base',
                  sidebarLabel: knowledgeBaseLabels.sidebarLabel?.trim() || knowledgeBaseLabels.entryLabel?.trim() || 'Knowledge Base'
              };
              if (typeof sidebar.updateKnowledgeBaseSourceConfig === 'function') {
                  sidebar.updateKnowledgeBaseSourceConfig();
              }
              if (typeof sidebar.applyKnowledgeBaseLabelsToSidebar === 'function') {
                  sidebar.applyKnowledgeBaseLabelsToSidebar();
              }
          }
      } catch (e) {
          logger$k.debug('Error loading knowledgeBaseLabels from storage', 'labels', e);
      }
  }

  /**
   * Apply Knowledge Base labels to the sidebar DOM.
   */
  function applyKnowledgeBaseLabelsToSidebar(sidebar) {
      if (!sidebar.sidebar) return;
      const title = sidebar.sidebar.querySelector('#community-guides .section-title');
      if (title) title.textContent = getKnowledgeBaseLabel(sidebar, 'sidebar');
      const filterInput = sidebar.sidebar.querySelector('#community-guides .results-filter');
      if (filterInput) filterInput.placeholder = `Filter ${getKnowledgeBaseLabel(sidebar, 'sidebar')}...`;
  }

  var sidebarUtils = /*#__PURE__*/Object.freeze({
    __proto__: null,
    applyKnowledgeBaseLabelsToSidebar: applyKnowledgeBaseLabelsToSidebar,
    getKnowledgeBaseLabel: getKnowledgeBaseLabel,
    getProductIconHTML: getProductIconHTML$1,
    loadKnowledgeBaseLabels: loadKnowledgeBaseLabels
  });

  // modules/sidebar/ui/results.js
  //
  // Rendering helpers for related results and community sources.

  const logger$j = createLogger('ResultsUI');

  function renderResultList(sidebarInstance, type, items = []) {
    if (typeof sidebarInstance?.isSectionEnabled === 'function' && !sidebarInstance.isSectionEnabled(type)) return;

    if (type === 'community') {
      return displaySources(sidebarInstance, items);
    }

    const cfg = sidebarInstance?.sourceConfig?.get(type);
    const sidebar = sidebarInstance?.sidebar;
    if (!cfg || !sidebar) return;
    const list = sidebar.querySelector(cfg.listSelector);
    if (!list) return;

    if (!items || items.length === 0) {
      renderMessage(list, 'empty', 'No results found.');
      setSectionEnhanced(sidebarInstance, type, false);
      return;
    }

    list.replaceChildren();
    let hasAiData = false;
    let hasFallbackAi = false;
    items.forEach(item => {
      const isConfluence = type === 'confluence';
      const isFallback = !!item.aiFallback;
      if (isFallback) hasFallbackAi = true;

      const container = document.createElement('div');
      container.className = 'result-item';

      const normalizedTitle = (item.title || item.summary || item.key || 'Untitled').replace(/^\?+/, '').trim();
      const link = document.createElement('a');
      link.href = item.url || '#';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.setAttribute('title', normalizedTitle);

      const topRow = document.createElement('div');
      topRow.className = 'item-top-row';

      const title = document.createElement('div');
      title.className = 'item-title';
      title.textContent = normalizedTitle;
      topRow.appendChild(title);

      const meta = document.createElement('div');
      meta.className = 'item-meta';

      if (item.key) {
        const keyBadge = document.createElement('span');
        keyBadge.className = 'item-key';
        keyBadge.textContent = item.key;
        meta.appendChild(keyBadge);
      }

      if (item.source && !isConfluence) {
        const sourceSpan = document.createElement('span');
        sourceSpan.className = 'item-source';
        sourceSpan.textContent = item.source;
        meta.appendChild(sourceSpan);
      }

      const rawScore = (typeof item.aiRelevanceScore === 'number') ? item.aiRelevanceScore : (typeof item.score === 'number' ? item.score : null);
      const score = isFallback ? null : rawScore;
      if (score !== null) {
        const scoreBadge = document.createElement('span');
        scoreBadge.className = 'ai-score-badge';
        scoreBadge.textContent = `AI ${Math.round(score)}%`;
        meta.appendChild(scoreBadge);
        if (!isFallback) hasAiData = true;
      }

      // Unnecessary tooltip removed as per user request
      const explanationText = isFallback
        ? (item.aiExplanation || item.explanation || '')
        : (item.aiExplanation || item.explanation || '');

      if (explanationText && !isFallback) hasAiData = true;

      if (meta.children.length > 0) {
        topRow.appendChild(meta);
      }

      link.appendChild(topRow);

      let excerptText = item.excerpt || item.summary || '';
      // If we have an AI explanation, use that as the excerpt/body instead of the summary
      if (explanationText) {
        excerptText = explanationText;
      }

      // Sanitize leading question marks
      excerptText = excerptText ? excerptText.replace(/^\?+/, '').trim() : '';

      if (!isConfluence && excerptText && excerptText !== normalizedTitle) {
        const excerpt = document.createElement('div');
        excerpt.className = 'item-excerpt';
        excerpt.textContent = excerptText;
        link.appendChild(excerpt);
      }

      container.appendChild(link);
      list.appendChild(container);
    });
    setSectionEnhanced(sidebarInstance, type, hasAiData && !hasFallbackAi);
  }

  function renderErrorState(sidebarInstance, type, message) {
    if (typeof sidebarInstance?.isSectionEnabled === 'function' && !sidebarInstance.isSectionEnabled(type)) return;

    const cfg = sidebarInstance?.sourceConfig?.get(type);
    const sidebar = sidebarInstance?.sidebar;
    if (!cfg || !sidebar) return;
    const list = sidebar.querySelector(cfg.listSelector);
    if (list) {
      const wrapper = document.createElement('div');
      wrapper.className = 'error';
      wrapper.textContent = message;
      list.replaceChildren();
      list.appendChild(wrapper);
    }
  }

  async function displaySources(sidebarInstance, sources) {
    if (typeof sidebarInstance?.isSectionEnabled === 'function' && !sidebarInstance.isSectionEnabled('community')) return;

    const sourcesList = document.getElementById('community-list');
    if (!sourcesList) return;
    if (!sources || sources.length === 0) {
      const label = typeof sidebarInstance?.getKnowledgeBaseLabel === 'function'
        ? sidebarInstance.getKnowledgeBaseLabel('sidebar')
        : 'Knowledge Base';

      // Create a helpful empty state
      sourcesList.replaceChildren();

      // Check if we suspect it's because no file is loaded (by checking if any load was attempted)
      // For now, simpler message is better:
      const msgDiv = document.createElement('div');
      msgDiv.className = 'empty-message';
      msgDiv.innerHTML = `No ${label} results found.<br><br>Ensure you have uploaded a knowledge base file in <a href="#" id="open-options-link">Options</a>.`;

      const optionsLink = msgDiv.querySelector('#open-options-link');
      if (optionsLink) {
        optionsLink.addEventListener('click', (e) => {
          e.preventDefault();
          if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
          } else {
            window.open(chrome.runtime.getURL('options.html'));
          }
        });
      }

      sourcesList.appendChild(msgDiv);
      return;
    }
    let aiEnabled = true;
    let showExplanation = true;
    let userToggledCommunity = null;
    try {
      const stored = await chrome.storage.local.get(['aiEnhancementSettings', 'aiEnabled']);
      const aiEnhancementSettings = stored.aiEnhancementSettings || {};
      const globalAiEnabled = typeof stored.aiEnabled === 'undefined' ? true : !!stored.aiEnabled;
      userToggledCommunity = aiEnhancementSettings?.userToggled?.community;
      const communityEnabled = (typeof userToggledCommunity === 'boolean')
        ? userToggledCommunity
        : (aiEnhancementSettings?.community !== false);
      aiEnabled = !!globalAiEnabled && communityEnabled;
      showExplanation = aiEnhancementSettings?.showExplanations?.community !== false;
    } catch (e) {
      logger$j.debug('Error loading AI settings for community display', 'results', e);
    }

    if (sources && sources.length > 0) {
      sourcesList.replaceChildren();
      let anySourceAi = false;
      let hadFallbackAi = false;
      let isAiOnPerSource = aiEnabled;
      let showInlineExplanationPerSource = showExplanation;
      sources.forEach(source => {
        const isFallback = !!source.aiFallback;
        const rawScore = (typeof source.aiRelevanceScore === 'number') ? source.aiRelevanceScore : (typeof source.score === 'number' ? source.score : null);
        const score = isFallback ? null : rawScore;
        const baseExplanation = source.aiExplanation || source.explanation || null;
        const fallbackNotice = 'AI unavailable; showing traditionally ranked articles. These suggestions may be less accurate.';
        const explanation = isFallback
          ? (baseExplanation ? `${fallbackNotice}\n\n${baseExplanation}` : fallbackNotice)
          : baseExplanation;
        const isAiOn = !isFallback && ((typeof source.aiEnabled !== 'undefined') ? !!source.aiEnabled : isAiOnPerSource);
        const showInlineExplanation = isAiOn && showInlineExplanationPerSource;
        if (isFallback) {
          hadFallbackAi = true;
        } else if (isAiOn && (typeof score === 'number' || explanation)) {
          anySourceAi = true;
        }

        const container = document.createElement('div');
        container.className = 'result-item';

        const link = document.createElement('a');
        link.href = source.url || '#';
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        const titleText = source.title || 'Untitled';
        link.setAttribute('title', titleText);

        const topRow = document.createElement('div');
        topRow.className = 'item-top-row';

        const title = document.createElement('div');
        title.className = 'item-title';
        title.textContent = titleText;
        topRow.appendChild(title);

        const meta = document.createElement('div');
        meta.className = 'item-meta';

        if (isAiOn && typeof score === 'number') {
          const badge = document.createElement('span');
          badge.className = 'ai-score-badge';
          badge.textContent = `AI ${Math.round(score)}%`;
          meta.appendChild(badge);
        }

        if ((isAiOn || isFallback) && explanation) {
          const hint = document.createElement('span');
          hint.className = 'ai-hint';
          hint.setAttribute('tabindex', '0');
          hint.setAttribute('role', 'button');
          hint.setAttribute('aria-label', 'Show AI explanation');
          hint.textContent = '?';
          const tip = document.createElement('span');
          tip.className = 'ai-tooltip-text';
          tip.textContent = explanation + (typeof score === 'number' ? `\n\nAI SCORE: ${Math.round(score)}%` : '');
          hint.appendChild(tip);
          meta.appendChild(hint);
        }

        if (meta.children.length > 0) {
          topRow.appendChild(meta);
        }

        link.appendChild(topRow);

        const snippetText = source.snippet || source.summary || '';
        if (snippetText) {
          const snippet = document.createElement('div');
          snippet.className = 'item-excerpt';
          snippet.textContent = snippetText.length > 300 ? snippetText.substring(0, 300) + '…' : snippetText;
          link.appendChild(snippet);
        }

        container.appendChild(link);

        if (showInlineExplanation && explanation) {
          const exp = document.createElement('div');
          exp.className = 'item-explanation';
          exp.textContent = explanation;
          container.appendChild(exp);
        }

        sourcesList.appendChild(container);
      });
      setSectionEnhanced(sidebarInstance, 'community', anySourceAi && !hadFallbackAi);
    } else if (!sources) {
      renderMessage(sourcesList, 'info', 'No sources were used.', 'p');
    } else {
      renderMessage(sourcesList, 'empty', 'No sources found for this query');
    }
  }

  async function setSectionEnhanced(sidebarInstance, type, hasAiData = false) {
    if (typeof sidebarInstance?.isSectionEnabled === 'function' && !sidebarInstance.isSectionEnabled(type)) return;

    try {
      const cfg = sidebarInstance?.sourceConfig?.get(type);
      const sidebar = sidebarInstance?.sidebar;
      if (!cfg || !sidebar) return;
      const section = sidebar.querySelector(cfg.sectionSelector);
      if (!section) return;
      const h5 = section.querySelector('h5');
      const existing = h5 ? h5.querySelector('.enhanced-badge') : null;

      const stored = await chrome.storage.local.get(['aiEnhancementSettings', 'aiEnabled']);
      const aiSettings = stored.aiEnhancementSettings || {};
      const globalAiEnabled = typeof stored.aiEnabled === 'undefined' ? true : !!stored.aiEnabled;
      const sectionEnabled = !!globalAiEnabled && (aiSettings?.[type] !== false);

      const shouldShow = sectionEnabled && !!hasAiData;

      if (shouldShow) {
        section.classList.add('enhanced');
        if (h5 && !existing) {
          const badge = document.createElement('span');
          badge.className = 'enhanced-badge';
          badge.textContent = 'Enhanced';
          badge.setAttribute('data-tooltip', 'Contains AI-enhanced relevance or explanation');
          const toggleBtn = h5.querySelector('.section-toggle');
          h5.insertBefore(badge, toggleBtn || null);
          setTimeout(() => badge.classList.add('visible'), 20);
        }
      } else {
        section.classList.remove('enhanced');
        if (existing) existing.remove();
      }
    } catch (e) {
      logger$j.debug('Error setting section enhanced badge', 'results', e);
    }
  }

  function updateContent(sidebarInstance, data) {
    if (!sidebarInstance || !sidebarInstance.sidebar) return;

    // Update the appropriate text areas
    const originalInput = sidebarInstance.sidebar.querySelector('#original-text-input');
    const improvedInput = sidebarInstance.sidebar.querySelector('#improved-text-input');

    if (originalInput && improvedInput && data.solution) {
      // Put solution in improved text box
      improvedInput.value = data.solution;
      sidebarInstance.currentSolution = data.solution;

      // Show improved section
      const improvedSection = sidebarInstance.sidebar.querySelector('#improved-section');
      if (improvedSection) {
        improvedSection.classList.remove('hidden');
      }

      // If original is empty, add some context
      if (!originalInput.value.trim()) {
        const caseData = typeof sidebarInstance.getCaseDataFromPage === 'function'
          ? sidebarInstance.getCaseDataFromPage()
          : {};

        let contextText = 'Case Context:\n';
        if (caseData.subject) contextText += `Subject: ${caseData.subject}\n`;
        if (caseData.productFamily) contextText += `Product: ${caseData.productFamily}\n`;

        // Handle Product Component
        if (caseData.productComponent !== undefined && caseData.productComponent !== null) {
          if (caseData.productComponent.trim()) {
            contextText += `Component: ${caseData.productComponent}\n`;
          } else {
            contextText += `Component: [Not Specified]\n`;
          }
        }

        originalInput.value = contextText;
      }
    }

    if (data.sources && typeof sidebarInstance.displaySources === 'function') {
      sidebarInstance.displaySources(data.sources);
    }

    // Only show if already visible; do not auto-open on page load
    if (sidebarInstance.isVisible && typeof sidebarInstance.toggle === 'function') {
      sidebarInstance.toggle(true);
    }
  }

  function renderMessage(container, className, text, tagName = 'div') {
    if (!container) return;
    const el = document.createElement(tagName);
    el.className = className;
    el.textContent = text;
    container.replaceChildren(el);
  }

  var resultRenderer = /*#__PURE__*/Object.freeze({
    __proto__: null,
    displaySources: displaySources,
    renderErrorState: renderErrorState,
    renderResultList: renderResultList,
    setSectionEnhanced: setSectionEnhanced,
    updateContent: updateContent
  });

  // modules/sidebar/event-setup.js
  //
  // Event listener wiring for the sidebar UI.


  const logger$i = createLogger('SidebarEventSetup');

  function setupEventListeners(sidebarInstance) {
    const sidebar = sidebarInstance?.sidebar;
    if (!sidebar) return;

    // Close button
    const closeBtn = sidebar.querySelector('#ai-sidebar-close-btn');
    if (closeBtn) {
      sidebarInstance.boundHandlers.closeBtn = () => sidebarInstance.toggle(false);
      closeBtn.addEventListener('click', sidebarInstance.boundHandlers.closeBtn);
      sidebarInstance.eventHandlers.closeBtn = { element: closeBtn, type: 'click', handler: sidebarInstance.boundHandlers.closeBtn };
    }

    const spellcheckBtn = sidebar.querySelector('#spellcheck-btn');
    if (spellcheckBtn) {
      sidebarInstance.boundHandlers.spellcheckBtn = () => {
        sidebarInstance.showImprovedSection();
        sidebarInstance.handleSpellcheck();
      };
      spellcheckBtn.addEventListener('click', sidebarInstance.boundHandlers.spellcheckBtn);
      sidebarInstance.eventHandlers.spellcheckBtn = { element: spellcheckBtn, type: 'click', handler: sidebarInstance.boundHandlers.spellcheckBtn };
    }

    const suggestBtn = sidebar.querySelector('#suggest-solution-btn');
    if (suggestBtn) {
      sidebarInstance.boundHandlers.suggestBtn = () => {
        sidebarInstance.showImprovedSection();
        sidebarInstance.handleSuggestSolution();
      };
      suggestBtn.addEventListener('click', sidebarInstance.boundHandlers.suggestBtn);
      sidebarInstance.eventHandlers.suggestBtn = { element: suggestBtn, type: 'click', handler: sidebarInstance.boundHandlers.suggestBtn };
    }

    const improveBtn = sidebar.querySelector('#improve-solution-btn');
    if (improveBtn) {
      sidebarInstance.boundHandlers.improveBtn = () => {
        sidebarInstance.showImprovedSection();
        sidebarInstance.handleImproveSolution();
      };
      improveBtn.addEventListener('click', sidebarInstance.boundHandlers.improveBtn);
      sidebarInstance.eventHandlers.improveBtn = { element: improveBtn, type: 'click', handler: sidebarInstance.boundHandlers.improveBtn };
    }

    const importBtn = sidebar.querySelector('#import-text-btn');
    if (importBtn) {
      sidebarInstance.boundHandlers.importBtn = async () => {
        try {
          // Disable button and show loading state
          importBtn.disabled = true;
          const originalText = importBtn.textContent;
          importBtn.textContent = 'Importing...';

          // Add timeout to prevent indefinite hangs (5 second max)
          const importPromise = sidebarInstance.handleImportText();
          const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Import timed out')), 5000)
          );

          await Promise.race([importPromise, timeoutPromise]);

          // Re-enable button
          importBtn.disabled = false;
          importBtn.textContent = originalText;
        } catch (error) {
          logger$i.error('[Sidebar] Error in import text handler:', 'event-setup', error);
          // Re-enable button on error
          importBtn.disabled = false;
          importBtn.textContent = 'Import Text';

          if (sidebarInstance.showError) {
            sidebarInstance.showError('Failed to import text. Please try again.');
          }
        }
      };
      importBtn.addEventListener('click', sidebarInstance.boundHandlers.importBtn);
      sidebarInstance.eventHandlers.importBtn = { element: importBtn, type: 'click', handler: sidebarInstance.boundHandlers.importBtn };
    }

    const copyBtn = sidebar.querySelector('#copy-improved-text-btn');
    if (copyBtn) {
      sidebarInstance.boundHandlers.copyBtn = () => sidebarInstance.handleCopyImprovedText();
      copyBtn.addEventListener('click', sidebarInstance.boundHandlers.copyBtn);
      sidebarInstance.eventHandlers.copyBtn = { element: copyBtn, type: 'click', handler: sidebarInstance.boundHandlers.copyBtn };
    }

    sidebarInstance.boundHandlers.escapeKey = (e) => {
      try {
        const keyIsEscape = e && e.key === 'Escape';
        const trusted = e && typeof e.isTrusted === 'boolean' ? e.isTrusted : true;
        const focusedInside = document.activeElement &&
          (document.activeElement === sidebarInstance.sidebarHost ||
            sidebarInstance.sidebarHost?.contains(document.activeElement) ||
            (sidebarInstance.shadowRoot && sidebarInstance.shadowRoot.activeElement !== null));
        if (keyIsEscape && sidebarInstance.isVisible && trusted && focusedInside) {
          sidebarInstance.vlog('[Sidebar] Escape key accepted for close (trusted & focused inside)');
          sidebarInstance.toggle(false);
        } else if (keyIsEscape && sidebarInstance.isVisible) {
          sidebarInstance.vlog('[Sidebar] Escape key ignored (trusted:', trusted, ', focusedInside:', !!focusedInside, ')');
        }
      } catch (err) {
        logger$i.debug('[Sidebar] Error in escape handler, ignoring close:', 'event-setup', err);
        sidebarInstance.vlog('[Sidebar] Error in escape handler, ignoring close:', err);
      }
    };
    document.addEventListener('keydown', sidebarInstance.boundHandlers.escapeKey);
    sidebarInstance.eventHandlers.escapeKey = { element: document, type: 'keydown', handler: sidebarInstance.boundHandlers.escapeKey };

    sidebarInstance.loadPreloadSettings();
    sidebarInstance.restoreCollapseState();

    const toggles = sidebar.querySelectorAll('.section-toggle');
    toggles.forEach(btn => {
      const handler = () => {
        const controlId = btn.getAttribute('aria-controls');
        const section = btn.closest('.related-section');
        if (!section) return;
        const isCollapsed = section.classList.toggle('collapsed');
        btn.setAttribute('aria-expanded', (!isCollapsed).toString());
        btn.textContent = isCollapsed ? '▸' : '▾';
        sidebarInstance.saveCollapseStateEntry(controlId, isCollapsed);
      };
      btn.addEventListener('click', handler);
      sidebarInstance.eventHandlers[`toggle_${btn.getAttribute('aria-controls')}`] = { element: btn, type: 'click', handler };
    });

    if (sidebarInstance.isVisible) {
      sidebarInstance.loadCaseDetailsEnhanced();
    }

    sidebarInstance.ensureRefreshButtonWired();

    sidebarInstance.resizeObserver = new ResizeObserver(sidebarInstance.handleResize.bind(sidebarInstance));
    sidebarInstance.resizeObserver.observe(sidebar);

    sidebarInstance.boundHandlers.tooltipDelegation = (e) => {
      try {
        const evType = e.type;
        const hint = e.target.closest && e.target.closest('.ai-hint');
        if (!hint) return;
        if (evType === 'mouseover' || evType === 'focusin') {
          sidebarInstance.showTooltipForHint(hint);
        } else if (evType === 'mouseout' || evType === 'focusout') {
          sidebarInstance.hideTooltipForHint(hint);
        }
      } catch (err) {
        logger$i.debug('[Sidebar] Tooltip delegation error:', 'event-setup', err);
      }
    };

    sidebar.addEventListener('mouseover', sidebarInstance.boundHandlers.tooltipDelegation);
    sidebar.addEventListener('mouseout', sidebarInstance.boundHandlers.tooltipDelegation);
    sidebar.addEventListener('focusin', sidebarInstance.boundHandlers.tooltipDelegation);
    sidebar.addEventListener('focusout', sidebarInstance.boundHandlers.tooltipDelegation);
    sidebarInstance.eventHandlers.tooltipDelegation = { element: sidebar, type: 'mouseover/mouseout/focusin/focusout', handler: sidebarInstance.boundHandlers.tooltipDelegation };
  }

  var eventSetup = /*#__PURE__*/Object.freeze({
    __proto__: null,
    setupEventListeners: setupEventListeners
  });

  /**
   * result.js
   *
   * Standardized Result pattern for operation outcomes.
   * Replaces the inconsistent mix of nulls, throws, and {success:false} objects.
   */

  class Result {
      constructor(ok, value, error) {
          this.ok = ok;
          this.value = value;
          this.error = error;
      }

      /**
       * Create a successful result
       * @param {any} value - The success return value
       * @returns {Result}
       */
      static success(value) {
          return new Result(true, value, null);
      }

      /**
       * Create a failure result
       * @param {Error|string} error - The error object or message
       * @returns {Result}
       */
      static failure(error) {
          const errObj = error instanceof Error ? error : new Error(String(error));
          return new Result(false, null, errObj);
      }

      /**
       * Unwrap the value or throw the error
       * @returns {any} The value if success
       * @throws {Error} The error if failure
       */
      unwrap() {
          if (this.ok) {
              return this.value;
          }
          throw this.error;
      }
  }

  // modules/sidebar/state/ai-availability.js


  const logger$h = createLogger('AiAvailability');
  //
  // Manage AI availability state and apply it to the UI.

  function setAiUiAvailability(sidebarInstance, enabled) {
    const sidebar = sidebarInstance?.sidebar;
    try {
      const tooltipMsg = enabled
        ? 'Use AI to spellcheck, suggest guidance, or enhance text.'
        : 'AI features disabled until you configure the AI service and token in Options.';
      sidebarInstance.aiAvailable = !!enabled;
      const setTooltip = (el) => {
        if (!el) return;
        if (!el.dataset.originalTitle) {
          el.dataset.originalTitle = el.getAttribute('title') || '';
        }
        el.setAttribute('title', enabled ? el.dataset.originalTitle : tooltipMsg);
      };

      const actionableButtons = [
        sidebar?.querySelector('#spellcheck-btn'),
        sidebar?.querySelector('#suggest-solution-btn'),
        sidebar?.querySelector('#improve-solution-btn')
      ];
      actionableButtons.forEach(btn => {
        if (!btn) return;
        btn.disabled = !enabled;
        btn.dataset.aiBlocked = enabled ? 'false' : 'true';
        btn.classList.toggle('ai-disabled', !enabled);
        btn.style.opacity = enabled ? '' : '0.5';
        btn.style.pointerEvents = enabled ? '' : 'none';
        setTooltip(btn);
      });

      const actionContainer = sidebar?.querySelector('.action-buttons');
      if (actionContainer) {
        actionContainer.classList.toggle('ai-disabled', !enabled);
        actionContainer.style.opacity = enabled ? '' : '0.45';
      }

      const content = sidebar?.querySelector('.pa-main-content');
      if (content) {
        content.classList.toggle('ai-disabled', !enabled);
        content.style.opacity = enabled ? '' : '0.55';
      }

      const improvedInput = sidebar?.querySelector('#improved-text-input');
      if (improvedInput) {
        improvedInput.readOnly = !enabled;
        improvedInput.classList.toggle('ai-disabled', !enabled);
        setTooltip(improvedInput);
      }
    } catch (e) {
      logger$h.warn('[Sidebar] Failed to apply AI availability state:', 'ai-availability', e);
    }
  }

  async function updateAiAvailability(sidebarInstance) {
    try {
      const { aiEnabled, aiServiceToken, apiEndpoint } = await chrome.storage.local.get(['aiEnabled', 'aiServiceToken', 'apiEndpoint']);
      const masterOn = typeof aiEnabled === 'undefined' ? true : !!aiEnabled;
      const hasToken = !!aiServiceToken;
      const hasEndpoint = !!(apiEndpoint && typeof apiEndpoint === 'string' && apiEndpoint.trim());
      const enabled = masterOn && hasToken && hasEndpoint;

      logger$h.debug(`[AI Availability] masterOn=${masterOn}, hasToken=${hasToken}, hasEndpoint=${hasEndpoint}, enabled=${enabled}`, 'ai-availability');
      setAiUiAvailability(sidebarInstance, enabled);

      return Result.success(enabled);
    } catch (e) {
      logger$h.warn('[Sidebar] Could not read AI availability:', 'ai-availability', e);
      setAiUiAvailability(sidebarInstance, false);
      return Result.failure(e);
    }
  }

  var aiAvailability = /*#__PURE__*/Object.freeze({
    __proto__: null,
    setAiUiAvailability: setAiUiAvailability,
    updateAiAvailability: updateAiAvailability
  });

  // modules/sidebar/ui/loader.js
  //
  // Handles creation and initial structural setup of the sidebar UI.


  const logger$g = createLogger('UI-Loader');

  /**
   * Creates the sidebar element and injects its HTML/CSS structure.
   */
  async function createSidebar(sidebarInstance) {
      if (sidebarInstance.sidebarHost) return;

      // Create sidebar host (the element in the main page DOM)
      const host = document.createElement('div');
      host.id = 'sf-pandaid-sidebar-host';
      sidebarInstance.sidebarHost = host;

      // Attach Shadow Root
      const shadow = host.attachShadow({ mode: 'open' });
      sidebarInstance.shadowRoot = shadow;

      // Create sidebar container inside the shadow DOM
      const sidebar = document.createElement('div');
      sidebar.id = 'sf-case-assistant-sidebar';
      sidebar.className = 'sf-sidebar';
      shadow.appendChild(sidebar);
      sidebarInstance.sidebar = sidebar;

      try {
          const htmlUrl = chrome.runtime.getURL('sidebar.html');
          const cssUrl = chrome.runtime.getURL('sidebar.css');

          // Fetch both HTML and CSS
          const [htmlResp, cssResp] = await Promise.allSettled([fetch(htmlUrl), fetch(cssUrl)]);

          // Apply CSS to Shadow Root only
          if (cssResp.status === 'fulfilled' && cssResp.value.ok) {
              const cssText = await cssResp.value.text();
              const styleEl = document.createElement('style');
              styleEl.id = 'sf-sidebar-styles';
              styleEl.textContent = cssText;
              shadow.appendChild(styleEl);

              // Inject MINIMAL global styles for the tooltip if they aren't already present
              injectGlobalTooltipStyles();
          } else {
              logger$g.warn('Failed to load sidebar.css', 'sidebar');
          }

          // Fetch and insert HTML into the container inside shadow
          if (htmlResp.status === 'fulfilled' && htmlResp.value.ok) {
              const htmlText = await htmlResp.value.text();
              const template = document.createElement('template');
              template.innerHTML = htmlText;
              sidebar.replaceChildren(template.content.cloneNode(true));
          } else {
              logger$g.warn('Failed to load sidebar.html, using inline fallback', 'sidebar');
              injectFallbackMarkup(sidebar);
          }

          // Fix header image src
          const img = sidebar.querySelector('.header-icon');
          if (img) {
              img.src = chrome.runtime.getURL('images/copandacrop48.png');
          }

          // Load and apply custom sidebar label
          try {
              const settings = await chrome.storage.local.get(['sidebarLabel']);
              const sidebarLabel = settings.sidebarLabel?.trim() || 'PandAid Case Assistant';
              const titleEl = sidebar.querySelector('.header-title');
              if (titleEl) {
                  titleEl.textContent = sidebarLabel;
              }
          } catch (e) {
              logger$g.warn('Failed to load sidebar label from storage', 'sidebar', e);
          }

          // Load and apply sidebar width
          if (typeof sidebarInstance.applySidebarWidth === 'function') {
              await sidebarInstance.applySidebarWidth();
          }
      } catch (err) {
          logger$g.error('Error loading sidebar resources:', 'sidebar', err);
      }

      // Append host to DOM
      if (!document.body.contains(host)) {
          document.body.appendChild(host);
      }

      // Setup observer for case-info
      if (typeof sidebarInstance.setupCaseInfoObserver === 'function') {
          try {
              sidebarInstance.setupCaseInfoObserver();
          } catch (e) {
              logger$g.warn('Failed to setup case-info observer:', 'sidebar', e);
          }
      }
  }

  function injectGlobalTooltipStyles() {
      if (document.getElementById('sf-global-tooltip-styles')) return;
      const style = document.createElement('style');
      style.id = 'sf-global-tooltip-styles';
      style.textContent = `
        #sf-global-tooltip {
            position: fixed;
            z-index: 2147483647;
            background: #172B4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 12px;
            line-height: 1.4;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            pointer-events: none;
            display: none;
            max-width: 300px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
    `;
      document.head.appendChild(style);
  }

  function injectFallbackMarkup(sidebar) {
      const header = document.createElement('div');
      header.className = 'ai-sidebar-header';
      const h3 = document.createElement('h3');
      h3.textContent = 'PandAid Case Assistant';
      const closeBtn = document.createElement('button');
      closeBtn.id = 'ai-sidebar-close-btn';
      closeBtn.className = 'sf-sidebar-close';
      closeBtn.textContent = '×';
      header.append(h3, closeBtn);

      const contentWrapper = document.createElement('div');
      contentWrapper.className = 'ai-sidebar-content';
      const innerContent = document.createElement('div');
      innerContent.className = 'pa-main-content';
      const loading = document.createElement('p');
      loading.className = 'loading';
      loading.textContent = 'Sidebar template failed to load.';
      innerContent.appendChild(loading);
      contentWrapper.appendChild(innerContent);

      sidebar.replaceChildren(header, contentWrapper);
  }

  var uiLoader = /*#__PURE__*/Object.freeze({
    __proto__: null,
    createSidebar: createSidebar
  });

  // modules/sidebar/visibility-manager.js
  //
  // Handles the show/hide animation and lifecycle transitions of the sidebar.


  const logger$f = createLogger('Visibility-Manager');

  /**
   * Toggles the sidebar visibility with animations and state management.
   */
  async function toggle(sidebarInstance, show = !sidebarInstance.isVisible) {
      if (sidebarInstance.toggleInProgress) {
          logger$f.vlog('[Sidebar] toggle ignored because another toggle is in progress');
          return;
      }
      sidebarInstance.toggleInProgress = true;

      try {
          await sidebarInstance.ensureInitialized();

          // Prevent multiple simultaneous opens
          if (show && (sidebarInstance.isVisible || sidebarInstance.isOpening)) {
              return;
          }

          // Prevent multiple simultaneous closes
          if (!show && !sidebarInstance.isVisible) {
              return;
          }

          if (!sidebarInstance.sidebar) return;

          // Guard: ignore programmatic close requests within a short grace period after opening
          if (!show && sidebarInstance.suppressImmediateCloseUntil && Date.now() < sidebarInstance.suppressImmediateCloseUntil) {
              return;
          }

          // Guard: ignore close requests that occur immediately after a single-page-app location change
          try {
              const lastNav = window._pandaid_last_location_change || 0;
              if (!show && lastNav && (Date.now() - lastNav) < 1000) {
                  return;
              }
          } catch (e) {
              logger$f.debug('Error checking last location change', 'visibility-manager', e);
          }

          if (show) {
              // Set opening flag when showing
              sidebarInstance.isOpening = true;
              // Set a short grace period to ignore stray close calls immediately after opening
              sidebarInstance.suppressImmediateCloseUntil = Date.now() + 500; // ms

              const host = sidebarInstance.sidebarHost;
              if (!host) return;

              // Make sure the host is in the DOM and visible
              if (!document.body.contains(host)) {
                  document.body.appendChild(host);
              }

              // Always set display to flex before adding the visible class
              host.style.display = 'flex';

              // Force reflow
              void host.offsetWidth;

              // Add the visible class to trigger the slide-in animation
              host.classList.add('visible');

              // Update visibility state
              sidebarInstance.isVisible = true;

              // Load preload settings
              sidebarInstance.loadPreloadSettings().catch(err => {
                  logger$f.error('Error loading preload settings on sidebar open:', 'sidebar', err);
              });

              // Attempt to (re)load case details
              try {
                  sidebarInstance.loadCaseDetailsEnhanced();
              } catch (err) {
                  logger$f.warn('Error triggering case details load on open:', 'sidebar', err);
              }

              // Clear opening flag after animation
              setTimeout(() => {
                  sidebarInstance.isOpening = false;
                  if (typeof sidebarInstance.notifyButtonVisibilityChange === 'function') {
                      sidebarInstance.notifyButtonVisibilityChange();
                  }
              }, 300);

              // Focus close button (inside shadow)
              const closeBtn = sidebarInstance.sidebar ? sidebarInstance.sidebar.querySelector('#ai-sidebar-close-btn') : null;
              if (closeBtn) closeBtn.focus();

          } else {
              // Update visibility state immediately
              sidebarInstance.isVisible = false;

              const host = sidebarInstance.sidebarHost;
              if (!host) return;

              // Slide-out animation
              host.classList.remove('visible');

              // Reset state when closing
              sidebarInstance.resetToInitialState().catch(err => {
                  logger$f.error('Error resetting sidebar state:', 'sidebar', err);
              });

              if (typeof sidebarInstance.notifyButtonVisibilityChange === 'function') {
                  sidebarInstance.notifyButtonVisibilityChange();
              }

              const hideTimeout = setTimeout(() => {
                  if (host) host.style.display = 'none';
              }, 300);

              const handleTransitionEnd = () => {
                  clearTimeout(hideTimeout);
                  if (host) host.style.display = 'none';
                  host.removeEventListener('transitionend', handleTransitionEnd);
              };

              host.addEventListener('transitionend', handleTransitionEnd, { once: true });
          }
      } catch (error) {
          logger$f.error('[Sidebar] toggle failed:', 'sidebar', error);
      } finally {
          sidebarInstance.toggleInProgress = false;
      }
  }

  var visibilityManager = /*#__PURE__*/Object.freeze({
    __proto__: null,
    toggle: toggle
  });

  // modules/sidebar/features/related-content/source-config.js
  //
  // Configuration for related data sources (Jira, Confluence, Knowledge Base).

  /**
   * Configuration for various data sources that the sidebar can preload.
   */
  const PRELOAD_CONFIG = {
      jira: {
          label: 'JIRA tickets',
          listSelector: '#jira-list',
          sectionSelector: '#jira-tickets',
          displayName: 'Work Items',
          loadingMessage: 'Loading JIRA tickets...',
          responseKey: 'tickets',
          actionBuilder: (caseData, isManualFetch) => ({
              action: 'getRelatedJiraTickets',
              caseId: caseData.caseId || caseData.id || '',
              caseData,
              isManualFetch
          })
      },
      confluence: {
          label: 'Confluence pages',
          listSelector: '#confluence-list',
          sectionSelector: '#confluence-pages',
          displayName: 'Confluence articles',
          loadingMessage: 'Loading Confluence pages...',
          responseKey: 'pages',
          actionBuilder: (caseData, isManualFetch) => ({
              action: 'getRelatedConfluencePages',
              caseData,
              isManualFetch
          })
      },
      community: {
          label: 'Knowledge Base',
          listSelector: '#community-list',
          sectionSelector: '#community-guides',
          displayName: 'Knowledge Base',
          loadingMessage: 'Loading Knowledge Base results...',
          responseKey: 'guides',
          actionBuilder: (caseData, isManualFetch) => ({
              action: 'getRelatedCommunityGuides',
              caseData,
              isManualFetch
          })
      }
  };

  // modules/sidebar/features/case-details.js


  const logger$e = createLogger('CaseDetails');

  // Escape special regex characters to prevent ReDoS attacks
  function escapeRegExp(value) {
    const str = (typeof value === 'string' ? value : String(value || '')).slice(0, 200);
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function isElementVisible$1(element) {
    if (!element) return false;
    try {
      const rect = element.getBoundingClientRect();
      const style = window.getComputedStyle(element);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.top < window.innerHeight &&
        rect.bottom > 0 &&
        style.visibility !== 'hidden' &&
        style.display !== 'none' &&
        element.getAttribute('aria-hidden') !== 'true';
    } catch (e) {
      logger$e.debug('Error checking element visibility:', 'case-details', e);
      return false;
    }
  }

  function loadCaseDetails(sidebar) {
    // Fallback: run original inline behavior by calling existing methods
    const caseInfo = sidebar.sidebar.querySelector('#case-info');
    if (!caseInfo) return;
    try { performCaseDetailsLoad(sidebar, caseInfo); } catch (e) { logger$e.error('Error loading case details fallback:', 'case-details', e); }
  }

  // Enhanced version of case details loading with delay and better UI
  // Adds a small retry mechanism in case the sidebar template hasn't been
  // attached yet and '#case-info' is not found immediately.
  function loadCaseDetailsEnhanced(sidebar, attempt = 0) {
    sidebar.vlog('[Sidebar] loadCaseDetailsEnhanced called (attempt', attempt + 1 + ')');
    const caseInfo = sidebar.sidebar && sidebar.sidebar.querySelector ? sidebar.sidebar.querySelector('#case-info') : null;
    if (!caseInfo) {
      if (attempt < 5) {
        const retryDelay = 200; // ms
        logger$e.warn(`[Sidebar] loadCaseDetailsEnhanced: #case-info not found, retrying in ${retryDelay}ms (attempt ${attempt + 1})`, 'case-details', undefined);
        setTimeout(() => loadCaseDetailsEnhanced(sidebar, attempt + 1), retryDelay);
      } else {
        logger$e.warn('[Sidebar] loadCaseDetailsEnhanced: #case-info not found after retries', 'case-details', undefined);
      }
      return;
    }
    try {
      const loading = document.createElement('div');
      loading.className = 'loading';
      loading.textContent = 'Loading case details...';
      caseInfo.replaceChildren(loading);
    } catch (e) { logger$e.warn('Unable to set loading state for case-info:', 'case-details', e); }
    setTimeout(() => { sidebar.vlog('[Sidebar] calling performCaseDetailsLoad after delay'); performCaseDetailsLoad(sidebar, caseInfo); }, 1500);
  }

  function performCaseDetailsLoad(sidebar, caseInfo) {
    try {
      sidebar.vlog('[Sidebar] performCaseDetailsLoad started');
      const caseData = getCaseDataFromPage(sidebar);
      sidebar.vlog('[Sidebar] performCaseDetailsLoad - caseData:', caseData);
      const fragment = document.createDocumentFragment();

      if (caseData.subject) {
        fragment.appendChild(createDetailItem('Subject:', [
          document.createTextNode(caseData.subject)
        ]));
      }
      if (caseData.productFamily) {
        const nodes = [];
        const productIcon = getProductIconElement(sidebar, caseData.productFamily);
        if (productIcon) nodes.push(productIcon);
        const productName = document.createElement('span');
        productName.className = 'product-name';
        productName.textContent = caseData.productFamily;
        nodes.push(productName);
        fragment.appendChild(createDetailItem('Product:', nodes));
      }
      if (caseData.productComponent) {
        const componentText = caseData.productComponentAction
          ? `${caseData.productComponent} - ${caseData.productComponentAction}`
          : caseData.productComponent;
        fragment.appendChild(createDetailItem('Component:', [
          document.createTextNode(componentText)
        ]));
      }

      if (fragment.childNodes.length > 0) {
        caseInfo.replaceChildren(fragment);
      } else {
        const debugInfo = getDebugFieldInfo(sidebar);
        const debugContainer = document.createElement('div');
        debugContainer.className = 'debug-info';
        debugContainer.textContent = 'No case details found';

        const debugButton = document.createElement('button');
        debugButton.className = 'debug-button';
        debugButton.textContent = 'Show Debug Info';

        const hiddenSection = document.createElement('div');
        hiddenSection.style.display = 'none';

        const details = document.createElement('details');
        details.className = 'debug-details';

        const summary = document.createElement('summary');
        summary.className = 'debug-summary';
        summary.textContent = 'Debug Information';

        const pre = document.createElement('pre');
        pre.className = 'debug-pre';
        pre.textContent = debugInfo;

        const refreshButton = document.createElement('button');
        refreshButton.className = 'refresh-button';
        refreshButton.textContent = 'Refresh Page';

        // Add event listeners
        debugButton.addEventListener('click', () => {
          hiddenSection.style.display = 'block';
          debugButton.style.display = 'none';
        });

        refreshButton.addEventListener('click', () => {
          location.reload();
        });

        // Assemble the structure
        details.appendChild(summary);
        details.appendChild(pre);
        hiddenSection.appendChild(details);
        hiddenSection.appendChild(refreshButton);
        debugContainer.appendChild(debugButton);
        debugContainer.appendChild(hiddenSection);

        caseInfo.replaceChildren();
        caseInfo.appendChild(debugContainer);
      }
    } catch (error) {
      logger$e.error('Error loading case details:', 'case-details', error);
      const errorDiv = document.createElement('div');
      errorDiv.className = 'debug-info';
      errorDiv.style.color = '#999';
      errorDiv.textContent = 'Unable to load case details';
      caseInfo.replaceChildren(errorDiv);
      // Show user notification for visibility
      if (sidebar && typeof sidebar.showWarning === 'function') {
        sidebar.showWarning('Unable to load case details. Some case information may not be available.');
      }
    }
  }

  // Retry helper used when Lightning fields are slow to render
  async function retryPerformCaseDetailsLoad(sidebar, attempts = 3, intervalMs = 800) {
    const caseInfo = sidebar.sidebar.querySelector('#case-info');
    if (!caseInfo) return;
    for (let i = 0; i < attempts; i++) {
      try {
        sidebar.vlog(`[Sidebar] retryPerformCaseDetailsLoad attempt ${i + 1}/${attempts}`);
        performCaseDetailsLoad(sidebar, caseInfo);
        const current = getCaseDataFromPage(sidebar);
        if (current && (current.subject || current.productFamily || current.productComponent)) {
          sidebar.vlog('[Sidebar] retry succeeded on attempt', i + 1);
          return;
        }
      } catch (err) {
        logger$e.warn('Retry attempt failed:', 'case-details', err);
      }
      await new Promise(r => setTimeout(r, intervalMs));
    }
    sidebar.vlog('[Sidebar] retries exhausted - no case details found');
  }

  function createDetailItem(label, valueNodes = []) {
    const item = document.createElement('div');
    item.className = 'case-detail-item';

    const labelDiv = document.createElement('div');
    labelDiv.className = 'case-detail-label';
    labelDiv.textContent = label;

    const valueDiv = document.createElement('div');
    valueDiv.className = 'case-detail-value';
    valueNodes.forEach(node => valueDiv.appendChild(node));

    item.appendChild(labelDiv);
    item.appendChild(valueDiv);
    return item;
  }

  function getProductIconElement(sidebar, productFamily) {
    try {
      const iconHtml = sidebar.utils?.getProductIconHTML ? sidebar.utils.getProductIconHTML(productFamily) : '';
      if (!iconHtml) return null;
      const wrapper = document.createElement('div');
      wrapper.className = 'product-icon-wrapper';
      wrapper.insertAdjacentHTML('beforeend', iconHtml);
      // Return the inserted icon if only one node exists, otherwise the wrapper
      return wrapper.childNodes.length === 1 ? wrapper.firstChild : wrapper;
    } catch (e) {
      logger$e.debug('Error getting product icon element:', 'case-details', e);
      return undefined;
    }
  }

  // Get case data from the current page
  function getCaseDataFromPage(sidebar) {
    // First try to get data from the specific Case Details section in the sidebar
    const caseDetailsSection = getCaseDetailsFromSidebar(sidebar);
    if (caseDetailsSection.subject || caseDetailsSection.productFamily || caseDetailsSection.productComponent) {
      // If we got some data from section, but missing caseOwner, try general field extraction
      if (!caseDetailsSection.caseOwner) {
        caseDetailsSection.caseOwner = getFieldValueByLabel(sidebar, 'Case Owner') || getFieldValueByLabel(sidebar, 'Owner') || getFieldValueByLabel(sidebar, 'Assigned To');
      }
      return caseDetailsSection;
    }

    // Fallback to general field extraction
    const caseNumber = getFieldValueByLabel(sidebar, 'Case Number') || getFieldValueByLabel(sidebar, 'Case #') || getCaseIdFromUrl();
    const data = {
      caseId: caseNumber || '',
      caseNumber: caseNumber || '',
      subject: getFieldValueByLabel(sidebar, 'Subject'),
      productFamily: getFieldValueByLabel(sidebar, 'Product Family') || getFieldValueByLabel(sidebar, 'Product'),
      productComponent: (() => {
        // Handle Product Component with proper fallback logic
        const affected = getFieldValueByLabel(sidebar, 'Product Component Affected');
        const section = getFieldValueByLabel(sidebar, 'Product Component Section');

        // Return first found field, even if empty string
        if (affected !== undefined) return affected;
        if (section !== undefined) return section;
        return undefined; // Neither field found
      })(),
      productComponentAction: getFieldValueByLabel(sidebar, 'Product Component Action'),
      caseOwner: getFieldValueByLabel(sidebar, 'Case Owner') || getFieldValueByLabel(sidebar, 'Owner') || getFieldValueByLabel(sidebar, 'Assigned To')
    };

    return data;
  }

  // New method to extract case details specifically from the sidebar/details panel
  function getCaseDetailsFromSidebar(sidebar) {
    try {
      const data = { caseId: '', caseNumber: '', subject: '', productFamily: '', productComponent: '', caseOwner: '' };
      const candidates = [];
      const sidebarSections = ['[title*="Case Details"]', '[aria-label*="Case Details"]', '[data-aura-class*="caseDetail"]', '.slds-card:has([title*="Case Details"])', '.forceRelatedListCardDesktop', '[data-target-selection-name*="case"]'];
      for (const selector of sidebarSections) {
        try {
          const sections = document.querySelectorAll(selector);
          sections.forEach(section => {
            if (!section) return;
            if (sidebar.sidebar && sidebar.sidebar.contains(section)) return;
            candidates.push({
              element: section,
              visible: isElementVisible$1(section),
              textLength: (section.textContent || '').trim().length,
              selector
            });
          });
        } catch (e) {
          logger$e.debug('Sidebar section selector failed:', 'case-details', selector, e);
          // continue to next
        }
      }
      const rightSidebar = document.querySelector('.highlights-panel, .slds-col--padded, [data-aura-class*="highlights"], .oneContent .rightCol');
      if (rightSidebar) {
        candidates.push({
          element: rightSidebar,
          visible: isElementVisible$1(rightSidebar),
          textLength: (rightSidebar.textContent || '').trim().length,
          selector: 'right-sidebar'
        });
      }

      // Prefer visible, more substantial sections first
      candidates.sort((a, b) => {
        if (a.visible && !b.visible) return -1;
        if (!a.visible && b.visible) return 1;
        return (b.textLength || 0) - (a.textLength || 0);
      });

      for (const candidate of candidates) {
        const sectionData = extractFieldsFromSection(sidebar, candidate.element);
        if (sectionData.subject || sectionData.productFamily || sectionData.productComponent || sectionData.caseNumber) {
          if (sectionData.caseNumber && !sectionData.caseId) {
            sectionData.caseId = sectionData.caseNumber;
          }
          return sectionData;
        }
      }
      return data;
    } catch (error) {
      logger$e.error('Error getting case details from sidebar:', 'case-details', error);
      return { caseId: '', caseNumber: '', subject: '', productFamily: '', productComponent: '', caseOwner: '' };
    }
  }

  // Extract specific fields from a given section
  function extractFieldsFromSection(sidebar, section) {
    const data = { caseNumber: '', subject: '', productFamily: '', productComponent: '', caseOwner: '' };
    try {
      const sectionText = section.textContent || '';
      data.caseNumber = extractFieldFromSectionText(sidebar, sectionText, ['Case Number', 'Case #']) || getFieldValueFromSection(sidebar, section, 'Case Number') || getFieldValueFromSection(sidebar, section, 'Case #');
      data.subject = extractFieldFromSectionText(sidebar, sectionText, ['Subject']) || getFieldValueFromSection(sidebar, section, 'Subject');
      data.productFamily = extractFieldFromSectionText(sidebar, sectionText, ['Product Family', 'Product']) || getFieldValueFromSection(sidebar, section, 'Product Family') || getFieldValueFromSection(sidebar, section, 'Product');
      const affected = extractFieldFromSectionText(sidebar, sectionText, ['Product Component Affected', 'Product Component Section', 'Component']);
      const fromSection = getFieldValueFromSection(sidebar, section, 'Product Component Affected') || getFieldValueFromSection(sidebar, section, 'Product Component Section');
      data.productComponent = affected !== null ? affected : fromSection;
      data.productComponentAction = extractFieldFromSectionText(sidebar, sectionText, ['Product Component Action']) || getFieldValueFromSection(sidebar, section, 'Product Component Action');
      data.caseOwner = extractFieldFromSectionText(sidebar, sectionText, ['Case Owner', 'Owner', 'Assigned To']) || getFieldValueFromSection(sidebar, section, 'Case Owner') || getFieldValueFromSection(sidebar, section, 'Owner') || getFieldValueFromSection(sidebar, section, 'Assigned To');
      return data;
    } catch (error) {
      logger$e.error('Error extracting fields from section:', 'case-details', error);
      return data;
    }
  }

  // Extract field value from section text using regex patterns
  function extractFieldFromSectionText(sidebar, text, fieldNames) {
    for (const fieldName of fieldNames) {
      const pattern = new RegExp(`${escapeRegExp(fieldName)}\\s*:?\\s*([^\\n\\r]*)`, 'i');
      const match = text.match(pattern);
      if (match && match[1] !== undefined) {
        const value = match[1].trim();
        if (value.toLowerCase() !== fieldName.toLowerCase() && value.length < 100) return value;
      }
    }
    return null;
  }

  // Get field value specifically from within a section
  function getFieldValueFromSection(sidebar, section, labelText) {
    try {
      const labels = section.querySelectorAll('span, div, label, .slds-form-element__label');
      for (const label of labels) {
        const text = label.textContent?.trim();
        if (text && text.toLowerCase() === labelText.toLowerCase()) {
          const value = findValueForLabel(sidebar, label, labelText);
          if (value) return value;
        }
      }
      return '';
    } catch (error) { logger$e.error('Error getting field value from section:', 'case-details', error); return ''; }
  }

  // Debug helper to show what fields are available on the page
  function getDebugFieldInfo(_sidebar) {
    try {
      const availableLabels = [];
      const lightningSelectors = ['.test-id__field-label', 'span.test-id__field-label', '.slds-form-element__label', '.forceInputLabel', '[data-aura-class*="forceInputLabel"]', '.field-label', '[class*="field-label"]'];
      for (const selector of lightningSelectors) { const labels = document.querySelectorAll(selector); labels.forEach(label => { if (label.textContent && label.textContent.trim()) availableLabels.push(`${selector}: "${label.textContent.trim()}"`); }); }
      const formLabels = document.querySelectorAll('label, .slds-form-element__label'); formLabels.forEach(label => { if (label.textContent && label.textContent.trim() && !availableLabels.some(l => l.includes(label.textContent.trim()))) availableLabels.push(`Form: "${label.textContent.trim()}"`); });
      const caseFieldTerms = ['subject', 'product', 'priority', 'status', 'owner', 'created', 'description', 'case number', 'case #'];
      const allElements = document.querySelectorAll('*');
      for (const element of allElements) {
        if (element.children.length === 0) {
          const text = element.textContent?.trim();
          if (text && text.length < 50) {
            for (const term of caseFieldTerms) { if (text.toLowerCase().includes(term)) { availableLabels.push(`Potential: "${text}"`); break; } }
          }
        }
      }
      const urlInfo = `URL: ${window.location.href.substring(0, 100)}...`;
      const readyState = `Document ready: ${document.readyState}`;
      const lightningReady = document.querySelector('[data-aura-rendered-by]') ? 'Lightning components found' : 'No Lightning components detected';
      return `${urlInfo}
${readyState}
${lightningReady}

Available labels (${availableLabels.length}):
${availableLabels.slice(0, 15).join('\n')}${availableLabels.length > 15 ? `\n... and ${availableLabels.length - 15} more` : ''}`;
    } catch (error) {
      logger$e.debug('Error generating debug field info:', 'case-details', error);
      return `Debug error: ${error.message}`;
    }
  }

  // Helper method to get field values
  function getFieldValueByLabel(sidebar, label) {
    try {
      const lightningSelectors = ['.test-id__field-label', 'span.test-id__field-label', '[data-target-selection-name*="field"]', '.slds-form-element__label', '.forceInputLabel', '[data-aura-class*="forceInputLabel"]', '.field-label', '[class*="field-label"]'];
      for (const selector of lightningSelectors) {
        const labels = document.querySelectorAll(selector);
        for (const labelElement of labels) {
          const labelText = labelElement.textContent?.trim();
          if (labelText && labelText.toLowerCase() === label.toLowerCase()) {
            const value = findValueForLabel(sidebar, labelElement, label);
            if (value !== null) return value;
          }
        }
      }
      const allSpans = document.querySelectorAll('span');
      for (const span of allSpans) {
        const spanText = span.textContent?.trim();
        if (spanText && spanText.toLowerCase() === label.toLowerCase()) {
          const value = findValueForLabel(sidebar, span, label);
          if (value !== null) return value;
        }
      }
      const textPattern = new RegExp(`${escapeRegExp(label)}\\s*:?\\s*([^\\n\\r]+)`, 'i');
      const bodyText = document.body.textContent || '';
      const match = bodyText.match(textPattern);
      if (match && match[1]) {
        const potentialValue = match[1].trim();
        if (potentialValue.toLowerCase() !== label.toLowerCase() && potentialValue.length >= 0 && potentialValue.length < 200) return potentialValue;
      }
      return undefined;
    } catch (error) {
      logger$e.error('Error getting field value for label:', 'case-details', label, error);
      return undefined;
    }
  }

  // Helper method to find value associated with a label element
  function findValueForLabel(sidebar, labelElement, originalLabel) {
    try {
      const formElement = labelElement.closest('.slds-form-element, .forceDetailPanelDesktopLayoutItem, [data-aura-class*="forceDetailPanelDesktopLayoutItem"]');
      if (formElement) {
        if (originalLabel.toLowerCase().includes('owner') || originalLabel.toLowerCase().includes('assigned')) {
          const userSpans = formElement.querySelectorAll('.slds-form-element__control > span, .slds-form-element__control > div > span');
          for (const span of userSpans) {
            const value = span.textContent?.trim();
            if (value && value !== originalLabel && value.split(' ').length >= 2 && value.length > 3 && value.length < 50) {
              if (!value.match(/\b(open|edit|view|preview|click|select|choose|more|less)\b/i)) return value;
            }
          }
        }
        const lightningTexts = formElement.querySelectorAll('lightning-formatted-text, [data-aura-class*="lightning-formatted-text"]');
        for (const lt of lightningTexts) {
          const value = lt.textContent?.trim();
          if (value && value !== originalLabel && value.length > 0 && !value.includes('to change without notice')) return value;
        }
        const controlAreas = formElement.querySelectorAll('.slds-form-element__control, .forceOutputText, [data-aura-class*="forceOutputText"]');
        for (const control of controlAreas) {
          const value = control.textContent?.trim();
          if (value && value !== originalLabel && value.length > 0 && value.length < 200 && !value.includes('to change without notice')) {
            if (!originalLabel.toLowerCase().includes('owner') && !originalLabel.toLowerCase().includes('assigned')) return value;
          }
        }
      }
      return '';
    } catch (error) { logger$e.error('Error finding value for label:', 'case-details', originalLabel, error); return ''; }
  }

  function getCaseIdFromUrl() {
    try {
      const href = window.location.href || '';
      const match = href.match(new RegExp('Case/([A-Za-z0-9]{8,18})'));
      if (match && match[1]) return match[1];
      const pathParts = (window.location.pathname || '').split('/').filter(Boolean);
      const last = pathParts[pathParts.length - 1];
      if (last && /^[A-Za-z0-9]{8,18}$/.test(last)) return last;
    } catch (e) {
      logger$e.debug('Error getting case ID from URL:', 'case-details', e);
    }
    return '';
  }

  var caseDetails = /*#__PURE__*/Object.freeze({
    __proto__: null,
    extractFieldFromSectionText: extractFieldFromSectionText,
    extractFieldsFromSection: extractFieldsFromSection,
    findValueForLabel: findValueForLabel,
    getCaseDataFromPage: getCaseDataFromPage,
    getCaseDetailsFromSidebar: getCaseDetailsFromSidebar,
    getDebugFieldInfo: getDebugFieldInfo,
    getFieldValueByLabel: getFieldValueByLabel,
    getFieldValueFromSection: getFieldValueFromSection,
    loadCaseDetails: loadCaseDetails,
    loadCaseDetailsEnhanced: loadCaseDetailsEnhanced,
    performCaseDetailsLoad: performCaseDetailsLoad,
    retryPerformCaseDetailsLoad: retryPerformCaseDetailsLoad
  });

  /**
   * Base interface for text extraction strategies.
   */
  class InputStrategy {
      /**
       * Check if this strategy applies to the current context or specific element
       * @param {Object} [context] - Contextual information (e.g., sidebar instance, event)
       * @returns {Promise<boolean>|boolean} True if applicable
       */
      canHandle(_context) {
          return false;
      }

      /**
       * Extract text using this strategy
       * @param {Object} [context] - Contextual information
       * @returns {Promise<Result<string|null>>|Result<string|null>} Extracted text or null
       */
      execute(_context) {
          return Result.success(null);
      }
  }

  const logger$d = createLogger('MessageAuth');

  const TOKEN_STORAGE_KEY = 'pandaidMessageNonce';
  const TRUSTED_ORIGIN_PATTERN = /^https:\/\/([a-z0-9-]+\.)*(lightning\.force\.com|salesforce\.com|force\.com|visual\.force\.com)$/i;

  let cachedToken = null;
  let pendingTokenPromise = null;

  function generateToken() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    return `pandaid-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  /**
   * Generate a unique nonce for each message request (not cached).
   * Use this for per-request security validation.
   * @returns {string} - A unique nonce with timestamp and expiry information
   */
  function generateMessageNonce() {
    // Generate unique token each time (never cached)
    const token = generateToken();
    const timestamp = Date.now();
    // Include timestamp for potential expiry validation (5 minute default)
    return `${token}-${timestamp}`;
  }

  async function getMessageNonce() {
    if (cachedToken) {
      return cachedToken;
    }
    if (!pendingTokenPromise) {
      pendingTokenPromise = (async () => {
        const storage = chrome?.storage?.session || chrome?.storage?.local;
        if (!storage) {
          cachedToken = generateToken();
          return cachedToken;
        }

        try {
          const stored = await storage.get(TOKEN_STORAGE_KEY);
          if (stored && stored[TOKEN_STORAGE_KEY]) {
            cachedToken = stored[TOKEN_STORAGE_KEY];
            return cachedToken;
          }
        } catch (e) {
          logger$d.debug('Error reading message nonce from storage', 'message-auth', e);
          // Ignore storage read failures and fall through to token generation.
        }

        const token = generateToken();
        try {
          await storage.set({ [TOKEN_STORAGE_KEY]: token });
        } catch (e) {
          logger$d.debug('Error saving message nonce to storage', 'message-auth', e);
          // Ignore storage write failures; token stays in memory.
        }
        cachedToken = token;
        return cachedToken;
      })().finally(() => {
        pendingTokenPromise = null;
      });
    }

    return pendingTokenPromise;
  }

  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'session' && area !== 'local') return;
      const next = changes[TOKEN_STORAGE_KEY]?.newValue;
      if (next) {
        cachedToken = next;
      }
    });
  }

  function isTrustedOrigin(origin, fallbackOrigin = null) {
    if (!origin || typeof origin !== 'string') {
      return false;
    }
    if (origin === 'null') {
      return !!fallbackOrigin && TRUSTED_ORIGIN_PATTERN.test(fallbackOrigin);
    }

    const baseOrigin = fallbackOrigin || (typeof window !== 'undefined' ? window.location.origin : null);
    if (baseOrigin && origin === baseOrigin) {
      return true;
    }

    return TRUSTED_ORIGIN_PATTERN.test(origin);
  }

  function getFrameOrigin(frame, fallbackOrigin = null) {
    if (!frame) return Result.failure('No frame provided');
    const baseOrigin = fallbackOrigin || (typeof window !== 'undefined' ? window.location.origin : null);
    const rawSrc = frame.getAttribute('src') || '';

    if (!rawSrc || rawSrc === 'about:blank') {
      return Result.success(baseOrigin);
    }

    try {
      const url = new URL(rawSrc, typeof window !== 'undefined' ? window.location.href : undefined);
      return Result.success(url.origin);
    } catch (err) {
      logger$d.debug('Error parsing frame origin', 'message-auth', err);
      return Result.failure(err);
    }
  }

  /**
   * DOM and Shadow DOM utility functions.
   */


  const logger$c = createLogger('ShadowDomUtils');

  /**
   * Check if an element is visible
   * @param {HTMLElement} element
   * @returns {boolean}
   */
  function isElementVisible(element) {
      try {
          const rect = element.getBoundingClientRect();
          const style = window.getComputedStyle(element);
          return rect.width > 0 &&
              rect.height > 0 &&
              rect.top < window.innerHeight &&
              rect.bottom > 0 &&
              style.visibility !== 'hidden' &&
              style.display !== 'none';
      } catch (e) {
          logger$c.debug('Error checking element visibility:', 'shadow-dom-utils', e);
          return false;
      }
  }

  /**
   * Check if an element represents a user-editable text field/editor.
   * Prevents us from harvesting page chrome or button labels.
   * @param {HTMLElement} element
   * @returns {boolean}
   */
  function isTextEntryElement(element) {
      if (!element || (typeof Node !== 'undefined' && element.nodeType !== Node.ELEMENT_NODE)) return false;

      const tag = element.tagName?.toLowerCase();

      if (tag === 'textarea') return true;

      if (tag === 'input') {
          const type = (element.getAttribute('type') || 'text').toLowerCase();
          const textTypes = ['text', 'email', 'search', 'tel', 'url', 'number', 'password', ''];
          return textTypes.includes(type);
      }

      if (element.isContentEditable || element.hasAttribute('contenteditable')) return true;
      if (element.classList?.contains('ql-editor')) return true;
      if (element.getAttribute && element.getAttribute('role') === 'textbox') return true;

      return false;
  }

  /**
   * Check if text is just a placeholder
   * @param {string} text
   * @returns {boolean}
   */
  function isPlaceholderText(text) {
      const placeholderPatterns = [
          'share an update',
          'what\'s on your mind',
          'write a comment',
          'add a comment',
          'type your message',
          'enter text here',
          'click here to',
          'placeholder'
      ];

      const lowerText = text.toLowerCase();
      return placeholderPatterns.some(pattern => lowerText.includes(pattern));
  }

  /**
   * Check if an element is part of the Sidebar
   * @param {Object} sidebar - Sidebar instance
   * @param {HTMLElement} element
   * @returns {boolean}
   */
  function isElementInSidebar$1(sidebar, element) {
      if (!element) return false;
      return sidebar.sidebar?.contains(element) || element.closest('#ai-sidebar, .ai-sidebar');
  }

  /**
   * Check if an element is part of the Subject field (not the Chatter text area).
   * Subject fields should be excluded from Chatter text import.
   * @param {HTMLElement} element
   * @returns {boolean}
   */
  function isSubjectFieldElement(element) {
      if (!element) return false;

      // Check element itself and ancestors for Subject field indicators
      let current = element;
      while (current && current !== document.body) {
          // Check class names for subject-related patterns
          const className = current.className || '';
          const classLower = typeof className === 'string' ? className.toLowerCase() : '';

          // Check for Salesforce subject field patterns
          if (classLower.includes('subject') ||
              classLower.includes('case-subject') ||
              classLower.includes('casesubject')) {
              return true;
          }

          // Check data attributes
          const dataTarget = current.getAttribute?.('data-target-selection-name') || '';
          if (dataTarget.toLowerCase().includes('subject')) {
              return true;
          }

          // Check aria-label
          const ariaLabel = current.getAttribute?.('aria-label') || '';
          if (ariaLabel.toLowerCase().includes('subject')) {
              return true;
          }

          // Check for label associations
          const labelledBy = current.getAttribute?.('aria-labelledby');
          if (labelledBy) {
              const labelElement = document.getElementById(labelledBy);
              if (labelElement?.textContent?.toLowerCase().includes('subject')) {
                  return true;
              }
          }

          // Check preceding label
          const prevSibling = current.previousElementSibling;
          if (prevSibling?.tagName === 'LABEL' &&
              prevSibling.textContent?.toLowerCase().includes('subject')) {
              return true;
          }

          current = current.parentElement;
      }

      return false;
  }

  /**
   * Recursively searches for elements matching a selector, piercing Shadow DOM boundaries.
   * @param {string} selector
   * @param {ParentNode} root
   * @returns {HTMLElement[]}
   */
  function querySelectorAllDeep(selector, root = document) {
      const results = [];

      // Add matches from the current root
      if (root.querySelectorAll) {
          results.push(...Array.from(root.querySelectorAll(selector)));
      }

      // Find all elements with shadow roots in this root
      const elements = root.querySelectorAll ? root.querySelectorAll('*') : [];

      for (const el of elements) {
          if (el.shadowRoot) {
              results.push(...querySelectorAllDeep(selector, el.shadowRoot));
          }
      }

      return results;
  }

  /**
   * Telemetry and Metrics Utility
   * Provides performance monitoring and error tracking for production debugging
   */


  const logger$b = createLogger('Telemetry');

  /**
   * Event types for categorization
   */
  const TelemetryEventType = {
    API_CALL: 'api_call',
    ERROR: 'error',
    PERFORMANCE: 'performance',
    USER_ACTION: 'user_action',
    CACHE_HIT: 'cache_hit',
    CACHE_MISS: 'cache_miss'
  };

  /**
   * Telemetry configuration
   */
  const config = {
    enabled: true,
    maxEvents: 1000, // Maximum events to keep in memory
    samplingRate: 1.0, // 1.0 = 100% of events (reduce for production)
    consoleLogging: true // Log to console for debugging
  };

  /**
   * In-memory event storage
   */
  const events = [];

  /**
   * Performance marks for measuring operation duration
   */
  const performanceMarks = new Map();

  /**
   * Records a telemetry event
   * @param {string} eventType - Type of event (from TelemetryEventType)
   * @param {string} eventName - Name of the event
   * @param {Object} data - Event data
   * @param {Object} metadata - Additional metadata
   */
  function recordEvent(eventType, eventName, data = {}, metadata = {}) {
    // Check if telemetry is enabled and sampling
    if (!config.enabled || Math.random() > config.samplingRate) {
      return;
    }

    const event = {
      id: crypto.randomUUID(),
      type: eventType,
      name: eventName,
      timestamp: Date.now(),
      data: sanitizeData(data),
      metadata: {
        ...metadata,
        userAgent: navigator.userAgent,
        url: window.location?.href
      }
    };

    // Add to events array
    events.push(event);

    // Trim to max size
    if (events.length > config.maxEvents) {
      events.shift();
    }

    // Console logging if enabled
    if (config.consoleLogging) {
      logger$b.info(`[Telemetry] ${eventType}:${eventName}`, 'telemetry', data);
    }

    return event.id;
  }

  /**
   * Sanitizes data to remove sensitive information
   * @param {Object} data - Data to sanitize
   * @returns {Object} Sanitized data
   */
  function sanitizeData(data) {
    if (!data || typeof data !== 'object') {
      return data;
    }

    const sanitized = {};
    const sensitiveKeys = ['token', 'password', 'apikey', 'secret', 'authorization', 'auth'];

    for (const [key, value] of Object.entries(data)) {
      const lowerKey = key.toLowerCase();

      // Check if key contains sensitive terms
      if (sensitiveKeys.some(term => lowerKey.includes(term))) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = sanitizeData(value);
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }

  /**
   * Starts a performance measurement
   * @param {string} operationName - Name of the operation
   * @returns {string} Measurement ID
   */
  function startPerformanceMeasurement(operationName) {
    const id = crypto.randomUUID();
    performanceMarks.set(id, {
      name: operationName,
      startTime: performance.now()
    });
    return id;
  }

  /**
   * Ends a performance measurement and records it
   * @param {string} measurementId - ID returned from startPerformanceMeasurement
   * @param {Object} additionalData - Additional data to record
   */
  function endPerformanceMeasurement(measurementId, additionalData = {}) {
    const mark = performanceMarks.get(measurementId);
    if (!mark) {
      logger$b.warn(`[Telemetry] Performance mark not found: ${measurementId}`, 'telemetry', undefined);
      return null;
    }

    const duration = performance.now() - mark.startTime;
    performanceMarks.delete(measurementId);

    recordEvent(TelemetryEventType.PERFORMANCE, mark.name, {
      duration,
      durationMs: Math.round(duration),
      ...additionalData
    });

    return duration;
  }

  /**
   * Wraps an async function with performance tracking
   * @param {string} operationName - Name of the operation
   * @param {Function} fn - Function to wrap
   * @returns {Function} Wrapped function
   */
  function withPerformanceTracking(operationName, fn) {
    return async function (...args) {
      const measurementId = startPerformanceMeasurement(operationName);

      try {
        const result = await fn(...args);
        endPerformanceMeasurement(measurementId, { ok: true });
        return result;
      } catch (error) {
        logger$b.debug('Error in tracked performance operation', 'telemetry', error);
        endPerformanceMeasurement(measurementId, {
          ok: false,
          error: error.message
        });
        throw error;
      }
    };
  }

  /**
   * Records an API call event
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {number} status - Response status
   * @param {number} duration - Request duration in ms
   * @param {Object} metadata - Additional metadata
   */
  function recordApiCall(endpoint, method, status, duration, metadata = {}) {
    recordEvent(TelemetryEventType.API_CALL, `${method} ${endpoint}`, {
      endpoint,
      method,
      status,
      duration,
      ok: status >= 200 && status < 300
    }, metadata);
  }

  /**
   * Records an error event
   * @param {Error|string} error - Error object or message
   * @param {string} context - Context where error occurred
   * @param {Object} additionalData - Additional error data
   */
  function recordError(error, context, additionalData = {}) {
    const errorData = {
      message: error.message || String(error),
      context,
      stack: error.stack,
      name: error.name,
      ...additionalData
    };

    recordEvent(TelemetryEventType.ERROR, context, errorData);
  }

  /**
   * Records a user action
   * @param {string} action - Action name
   * @param {Object} data - Action data
   */
  function recordUserAction(action, data = {}) {
    recordEvent(TelemetryEventType.USER_ACTION, action, data);
  }

  /**
   * Records a cache hit
   * @param {string} cacheKey - Cache key
   * @param {Object} metadata - Additional metadata
   */
  function recordCacheHit(cacheKey, metadata = {}) {
    recordEvent(TelemetryEventType.CACHE_HIT, cacheKey, {}, metadata);
  }

  /**
   * Records a cache miss
   * @param {string} cacheKey - Cache key
   * @param {Object} metadata - Additional metadata
   */
  function recordCacheMiss(cacheKey, metadata = {}) {
    recordEvent(TelemetryEventType.CACHE_MISS, cacheKey, {}, metadata);
  }

  /**
   * Gets all recorded events
   * @param {Object} filters - Optional filters
   * @param {string} filters.type - Filter by event type
   * @param {number} filters.since - Filter events since timestamp
   * @param {number} filters.limit - Maximum number of events to return
   * @returns {Array} Filtered events
   */
  function getEvents(filters = {}) {
    let filtered = [...events];

    if (filters.type) {
      filtered = filtered.filter(e => e.type === filters.type);
    }

    if (filters.since) {
      filtered = filtered.filter(e => e.timestamp >= filters.since);
    }

    if (filters.limit) {
      filtered = filtered.slice(-filters.limit);
    }

    return filtered;
  }

  /**
   * Gets aggregated metrics
   * @param {number} timeWindow - Time window in milliseconds (default: last hour)
   * @returns {Object} Aggregated metrics
   */
  function getMetrics(timeWindow = 3600000) {
    const since = Date.now() - timeWindow;
    const recentEvents = events.filter(e => e.timestamp >= since);

    const metrics = {
      totalEvents: recentEvents.length,
      byType: {},
      apiCalls: {
        total: 0,
        successful: 0,
        failed: 0,
        averageDuration: 0
      },
      errors: {
        total: 0,
        byContext: {}
      },
      performance: {
        operations: {}
      },
      cache: {
        hits: 0,
        misses: 0,
        hitRate: 0
      }
    };

    // Aggregate by type
    for (const event of recentEvents) {
      metrics.byType[event.type] = (metrics.byType[event.type] || 0) + 1;

      switch (event.type) {
        case TelemetryEventType.API_CALL:
          metrics.apiCalls.total++;
          if (event.data.success) {
            metrics.apiCalls.successful++;
          } else {
            metrics.apiCalls.failed++;
          }
          break;

        case TelemetryEventType.ERROR:
          metrics.errors.total++;
          const context = event.data.context || 'unknown';
          metrics.errors.byContext[context] = (metrics.errors.byContext[context] || 0) + 1;
          break;

        case TelemetryEventType.PERFORMANCE:
          if (!metrics.performance.operations[event.name]) {
            metrics.performance.operations[event.name] = {
              count: 0,
              totalDuration: 0,
              averageDuration: 0
            };
          }
          const op = metrics.performance.operations[event.name];
          op.count++;
          op.totalDuration += event.data.duration || 0;
          op.averageDuration = op.totalDuration / op.count;
          break;

        case TelemetryEventType.CACHE_HIT:
          metrics.cache.hits++;
          break;

        case TelemetryEventType.CACHE_MISS:
          metrics.cache.misses++;
          break;
      }
    }

    // Calculate cache hit rate
    const totalCacheAccess = metrics.cache.hits + metrics.cache.misses;
    if (totalCacheAccess > 0) {
      metrics.cache.hitRate = (metrics.cache.hits / totalCacheAccess * 100).toFixed(2);
    }

    // Calculate average API call duration
    const apiCallEvents = recentEvents.filter(e => e.type === TelemetryEventType.API_CALL);
    if (apiCallEvents.length > 0) {
      const totalDuration = apiCallEvents.reduce((sum, e) => sum + (e.data.duration || 0), 0);
      metrics.apiCalls.averageDuration = Math.round(totalDuration / apiCallEvents.length);
    }

    return metrics;
  }

  /**
   * Clears all recorded events
   */
  function clearEvents() {
    events.length = 0;
    performanceMarks.clear();
  }

  /**
   * Exports events as JSON
   * @param {Object} filters - Optional filters (same as getEvents)
   * @returns {string} JSON string of events
   */
  function exportEvents(filters = {}) {
    const filtered = getEvents(filters);
    return JSON.stringify(filtered, null, 2);
  }

  /**
   * Configures telemetry settings
   * @param {Object} options - Configuration options
   */
  function configure(options = {}) {
    Object.assign(config, options);
  }

  /**
   * Gets current configuration
   * @returns {Object} Current configuration
   */
  function getConfig() {
    return { ...config };
  }

  /**
   * Creates a telemetry session for tracking related operations
   */
  class TelemetrySession {
    constructor(sessionName) {
      this.sessionId = crypto.randomUUID();
      this.sessionName = sessionName;
      this.startTime = Date.now();
      this.events = [];
    }

    /**
     * Records an event within this session
     */
    recordEvent(eventType, eventName, data = {}) {
      const eventId = recordEvent(eventType, eventName, data, {
        sessionId: this.sessionId,
        sessionName: this.sessionName
      });
      this.events.push(eventId);
      return eventId;
    }

    /**
     * Ends the session and records summary
     */
    end(summary = {}) {
      const duration = Date.now() - this.startTime;
      recordEvent(TelemetryEventType.PERFORMANCE, `session_${this.sessionName}`, {
        duration,
        eventsRecorded: this.events.length,
        ...summary
      }, {
        sessionId: this.sessionId
      });
      return {
        sessionId: this.sessionId,
        duration,
        eventsRecorded: this.events.length
      };
    }
  }

  // Export a default telemetry instance
  var telemetry = {
    recordEvent,
    recordApiCall,
    recordError,
    recordUserAction,
    recordCacheHit,
    recordCacheMiss,
    startPerformanceMeasurement,
    endPerformanceMeasurement,
    withPerformanceTracking,
    getEvents,
    getMetrics,
    clearEvents,
    exportEvents,
    configure,
    getConfig,
    TelemetrySession,
    TelemetryEventType
  };

  /**
   * Strategy for extracting text from Email composers (IFrames, CKEditor, Lightning inputs).
   * 
   * Includes telemetry for monitoring extraction method success rates in production.
   */

  const logger$a = createLogger('EmailExtractor');

  // Configuration for extraction behavior
  const EXTRACTION_CONFIG = {
      MIN_TEXT_LENGTH: {
          PRIMARY: 10,        // oneIframeComposer & legacy methods
          IFRAME_BODY: 5,     // Shorter threshold for iframe body text
          FALLBACK: 20        // Stricter threshold for generic fallback
      },
      IFRAME_TIMEOUT: 2000,
      // Regex for matching toolbar UI patterns with word boundaries
      // Matches: "Font Size", "Bold Italic", "Align Left"
      // Does NOT match: "Font size is too small"
      TOOLBAR_PATTERN: /^[\s]*(Font|Size|Format|Bold|Italic|Underline|Align|List|Link|Image|Source|Styles|Paragraph|Heading)\s+(Font|Size|Format|Bold|Italic|Underline|Align|List|Link|Image|Source|Styles|Paragraph|Heading)[\s]*$/i
  };

  /**
   * Extraction strategy names for telemetry and debugging
   */
  const STRATEGY_NAMES = {
      ONE_IFRAME_COMPOSER: 'oneIframeComposer',
      CKEDITOR_IFRAME: 'ckEditorIframe',
      CKEDITOR_BODY: 'ckEditorBody',
      EMAIL_INPUTS: 'emailInputs',
      LIGHTNING_COMPONENT: 'lightningComponent',
      GENERIC_FALLBACK: 'genericFallback',
      IFRAME_MESSAGE: 'iframeMessage'
  };

  class EmailExtractor extends InputStrategy {
      constructor(sidebar) {
          super();
          this.sidebar = sidebar;
      }

      async canHandle() {
          // Check if any email-like elements exist
          const emailElements = document.querySelectorAll('iframe, .emailComposer, [data-aura-class*="email"]');
          return emailElements.length > 0;
      }

      async execute() {
          // Try direct extraction first
          const directResult = await this.extractEmailText(this.sidebar);
          let emailText = directResult.ok ? directResult.value : null;
          logger$a.debug(`Direct extraction result: ${emailText ? 'found ' + emailText.length + ' chars' : 'not found'}`, 'email-extractor');

          // If not found, try iframe message request with longer timeout
          if (!emailText) {
              logger$a.debug('Attempting iframe message request...', 'email-extractor');
              emailText = await this.requestEmailContentFromIframes(2000);
              if (emailText) {
                  this.recordExtractionSuccess(STRATEGY_NAMES.IFRAME_MESSAGE, emailText.length);
              }
              logger$a.debug(`Iframe message result: ${emailText ? 'found ' + emailText.length + ' chars' : 'not found'}`, 'email-extractor');
          }

          // If still not found, record failure
          if (!emailText) {
              this.recordExtractionFailure('all-methods-exhausted');
          }

          return Result.success(emailText);
      }

      /**
       * Record a successful extraction for telemetry
       * @param {string} strategyName - Name of the strategy that succeeded
       * @param {number} textLength - Length of extracted text
       */
      recordExtractionSuccess(strategyName, textLength) {
          try {
              telemetry.recordEvent(
                  TelemetryEventType.USER_ACTION,
                  'email_extraction_success',
                  {
                      strategy: strategyName,
                      textLength: textLength,
                      url: window.location?.hostname || 'unknown'
                  },
                  { component: 'EmailExtractor' }
              );
              logger$a.debug(`Telemetry: extraction success via ${strategyName}`, 'email-extractor');
          } catch (e) {
              // Telemetry should never break extraction
              logger$a.debug('Failed to record telemetry', 'email-extractor', e?.message);
          }
      }

      /**
       * Record failed extraction for telemetry
       * @param {string} reason - Reason for failure
       */
      recordExtractionFailure(reason) {
          try {
              telemetry.recordEvent(
                  TelemetryEventType.ERROR,
                  'email_extraction_failure',
                  {
                      reason: reason,
                      url: window.location?.hostname || 'unknown'
                  },
                  { component: 'EmailExtractor' }
              );
              logger$a.debug(`Telemetry: extraction failed - ${reason}`, 'email-extractor');
          } catch (e) {
              // Telemetry should never break extraction
              logger$a.debug('Failed to record telemetry', 'email-extractor', e?.message);
          }
      }

      /**
       * Helper: Extract text from elements matching a selector
       * @param {string|NodeList} selector - CSS selector or NodeList
       * @param {Function} textExtractor - Function to extract text from element
       * @param {number} minLength - Minimum text length requirement
       * @param {Document} contextDoc - Document to query (for iframe support)
       * @returns {string|null} - Extracted text or null
       */
      extractTextFromElements(selector, textExtractor, minLength, contextDoc) {
          const isToolbarText = this.createToolbarValidator();
          const doc = contextDoc || document;

          try {
              const elements = typeof selector === 'string'
                  ? querySelectorAllDeep(selector, doc)
                  : selector;

              for (const element of elements) {
                  if (isElementInSidebar$1(this.sidebar, element)) continue;
                  const text = textExtractor(element)?.trim();
                  if (text && text.length >= minLength && !isToolbarText(text)) {
                      return text;
                  }
              }
          } catch (error) {
              logger$a.debug('Error extracting from elements', 'email-extractor', error?.message);
          }
          return null;
      }

      /**
       * Creates a toolbar text validator function (with closure over config)
       * @returns {Function} - Validator function
       */
      createToolbarValidator() {
          return (text) => {
              if (!text || typeof text !== 'string') return true;
              const normalized = text.trim();
              if (normalized.length === 0) return true;
              if (text.includes('\n') || text.includes('\r')) return false;
              return EXTRACTION_CONFIG.TOOLBAR_PATTERN.test(normalized);
          };
      }

      /**
       * Extract from iframe document with access checking
       * @param {HTMLIFrameElement} iframe - The iframe element
       * @returns {string|null} - Extracted text or null
       */
      extractFromIframeDocument(iframe) {
          const isToolbarText = this.createToolbarValidator();
          try {
              let doc = null;
              try {
                  doc = iframe.contentDocument || iframe.contentWindow?.document;
              } catch (error) {
                  logger$a.debug('Cross-origin iframe access restricted', 'email-extractor', error?.message);
                  return Result.failure(error);
              }

              if (!doc) return null;

              // Try textarea#editor (standard)
              const editorTextarea = querySelectorAllDeep('textarea#editor, textarea[name="editor"]', doc)[0];
              if (editorTextarea?.value?.trim().length >= EXTRACTION_CONFIG.MIN_TEXT_LENGTH.PRIMARY && !isToolbarText(editorTextarea.value.trim())) {
                  logger$a.debug('✓ Found email text in iframe editor textarea', 'email-extractor');
                  return editorTextarea.value.trim();
              }

              // Try body text (shorter threshold)
              if (doc.body) {
                  const bodyText = doc.body.innerText?.trim();
                  if (bodyText?.length >= EXTRACTION_CONFIG.MIN_TEXT_LENGTH.IFRAME_BODY && !isToolbarText(bodyText)) {
                      logger$a.debug('✓ Found email text in iframe body', 'email-extractor');
                      return bodyText;
                  }
              }

              // Try div[contenteditable]
              const editableDiv = querySelectorAllDeep('div[contenteditable="true"]', doc)[0];
              if (editableDiv?.innerText?.trim().length >= EXTRACTION_CONFIG.MIN_TEXT_LENGTH.IFRAME_BODY && !isToolbarText(editableDiv.innerText.trim())) {
                  logger$a.debug('✓ Found email text in iframe div[contenteditable]', 'email-extractor');
                  return editableDiv.innerText.trim();
              }
          } catch (error) {
              logger$a.debug('Unable to extract from iframe document', 'email-extractor', error?.message);
          }
          return null;
      }

      /**
       * Extract email text using a prioritized strategy loop.
       * Records telemetry for each strategy attempt to aid debugging.
       */
      async extractEmailText(sidebar) {
          // Define strategies in priority order
          const strategies = [
              {
                  name: STRATEGY_NAMES.ONE_IFRAME_COMPOSER,
                  fn: () => this.tryOneIframeComposerStrategy(),
                  async: false
              },
              {
                  name: STRATEGY_NAMES.CKEDITOR_IFRAME,
                  fn: () => this.tryCKEditorIframeStrategy(),
                  async: true
              },
              {
                  name: STRATEGY_NAMES.CKEDITOR_BODY,
                  fn: () => this.tryCKEditorBodyStrategy(sidebar),
                  async: false
              },
              {
                  name: STRATEGY_NAMES.EMAIL_INPUTS,
                  fn: () => this.tryEmailInputsStrategy(sidebar),
                  async: true
              },
              {
                  name: STRATEGY_NAMES.LIGHTNING_COMPONENT,
                  fn: () => this.tryLightningComponentStrategy(sidebar),
                  async: true
              },
              {
                  name: STRATEGY_NAMES.GENERIC_FALLBACK,
                  fn: () => this.tryGenericFallbackStrategy(sidebar),
                  async: false
              }
          ];

          for (const strategy of strategies) {
              try {
                  const result = strategy.async ? await strategy.fn() : strategy.fn();
                  if (result) {
                      logger$a.debug(`✓ Email extraction succeeded via: ${strategy.name}`, 'email-extractor');
                      this.recordExtractionSuccess(strategy.name, result.length);
                      return Result.success(result);
                  }
              } catch (error) {
                  logger$a.debug(`Strategy ${strategy.name} threw error`, 'email-extractor', error?.message);
              }
          }

          // All strategies exhausted
          logger$a.debug('All extraction strategies exhausted', 'email-extractor');
          return Result.success(null);
      }

      tryOneIframeComposerStrategy() {
          const iframeComposers = querySelectorAllDeep('.oneIframeComposer');
          for (const composer of iframeComposers) {
              const iframes = querySelectorAllDeep('iframe', composer);
              for (const iframe of iframes) {
                  const text = this.extractFromIframeDocument(iframe);
                  if (text) return text;
              }
          }
          return null;
      }

      async tryCKEditorIframeStrategy() {
          let selectors = [];
          try {
              const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
              const response = await fetch(configUrl);
              const config = await response.json();
              selectors = config.email.iframeSelectors || [];
          } catch (e) {
              logger$a.debug('Failed to load iframe selectors, using fallback', 'email-extractor');
              selectors = [
                  'iframe.cke_wysiwyg_frame', 'iframe[class*="cke"]', '.cke_contents iframe',
                  'iframe[title*="Email"]', 'iframe[title*="Rich Text"]', 'iframe[title="Email Body"]',
                  'iframe[allowtransparency="true"]'
              ];
          }

          for (const selector of selectors) {
              const ckeIframes = document.querySelectorAll(selector);
              for (const iframe of ckeIframes) {
                  const text = this.extractFromIframeDocument(iframe);
                  if (text) return text;
              }
          }
          return null;
      }

      tryCKEditorBodyStrategy(sidebar) {
          const selector = 'body.cke_editable, .cke_editable[contenteditable="true"], [class*="cke"][contenteditable="true"]';
          return this.extractTextFromElements(
              selector,
              (el) => el.innerText,
              EXTRACTION_CONFIG.MIN_TEXT_LENGTH.PRIMARY
          );
      }

      async tryEmailInputsStrategy(sidebar) {
          let selectors = [];
          try {
              const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
              const response = await fetch(configUrl);
              const config = await response.json();
              selectors = config.email.inputSelectors || [];
          } catch (e) {
              logger$a.debug('Failed to load email input selectors, using fallback', 'email-extractor');
              selectors = ['textarea[placeholder*="email" i]', '.emailComposer textarea'];
          }

          for (const selector of selectors) {
              const text = this.extractTextFromElements(
                  selector,
                  (el) => el.value || el.textContent || el.innerText,
                  EXTRACTION_CONFIG.MIN_TEXT_LENGTH.PRIMARY
              );
              if (text) return text;
          }
          return null;
      }

      async tryLightningComponentStrategy(sidebar) {
          // Lightning components are now covered by the centralized inputSelectors list
          // but we keep this method for structural consistency if needed in future
          return null;
      }

      tryGenericFallbackStrategy(sidebar) {
          // Try contenteditable elements first
          const contentEditables = document.querySelectorAll('[contenteditable="true"]');
          for (const element of contentEditables) {
              if (isElementInSidebar$1(sidebar, element)) continue;
              if (!isElementVisible(element)) continue;
              if (element.closest('[role="toolbar"], .cke_top, .slds-rich-text-editor__toolbar, .ql-toolbar')) continue;
              if (element.classList.contains('cke_top') || element.classList.contains('toolbar')) continue;

              const isToolbarText = this.createToolbarValidator();
              const text = element.innerText?.trim();
              if (text && text.length >= EXTRACTION_CONFIG.MIN_TEXT_LENGTH.FALLBACK && !isToolbarText(text)) {
                  return text;
              }
          }

          // Then try all visible textareas
          const allTextareas = document.querySelectorAll('textarea:not([readonly])');
          for (const textarea of allTextareas) {
              if (isElementInSidebar$1(sidebar, textarea)) continue;
              if (!isElementVisible(textarea)) continue;

              const isToolbarText = this.createToolbarValidator();
              const text = textarea.value?.trim();
              if (text && text.length >= EXTRACTION_CONFIG.MIN_TEXT_LENGTH.FALLBACK && !isToolbarText(text)) {
                  return text;
              }
          }

          return null;
      }

      async requestEmailContentFromIframes(timeout = 2000) {
          // Generate unique nonce for THIS REQUEST (not cached)
          const nonce = generateMessageNonce();
          const fallbackOrigin = window.location?.origin && window.location.origin !== 'null'
              ? window.location.origin
              : null;

          return new Promise((resolve) => {
              const requestId = `email-request-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
              let resolved = false;
              let messageTimeout = null;

              // Define cleanup function (called on both success and timeout)
              const cleanup = () => {
                  if (messageTimeout) clearTimeout(messageTimeout);
                  window.removeEventListener('message', handleResponse);
              };

              // Set up listener for response
              const handleResponse = (event) => {
                  if (resolved) return;
                  try {
                      // Use centralized origin validation (single source of truth)
                      if (!isTrustedOrigin(event.origin, fallbackOrigin)) {
                          logger$a.warn('Rejected message from untrusted origin', 'email-extractor', { origin: event.origin });
                          return;
                      }

                      if (event.data?.action === 'emailContentResponse' &&
                          event.data?.requestId === requestId &&
                          event.data?.nonce === nonce) {
                          resolved = true;
                          cleanup();
                          resolve(event.data.text || null);
                      }
                  } catch (error) {
                      logger$a.debug('Error processing iframe message response', 'email-extractor', error?.message);
                  }
              };

              window.addEventListener('message', handleResponse);

              // Find all potential email iframes
              const emailIframes = querySelectorAllDeep(
                  'iframe.cke_wysiwyg_frame, ' +
                  'iframe[class*="cke"], ' +
                  '.cke_contents iframe, ' +
                  'iframe[title*="Email"], ' +
                  'iframe[title*="Rich Text"], ' +
                  'iframe[name*="vfFrameId"]'
              );

              // Send request to all iframes
              for (const iframe of emailIframes) {
                  try {
                      if (iframe.contentWindow) {
                          const frameOriginRes = getFrameOrigin(iframe, fallbackOrigin);
                          const frameOrigin = frameOriginRes.ok ? frameOriginRes.value : null;
                          if (!isTrustedOrigin(frameOrigin, fallbackOrigin)) continue;
                          const targetOrigin = frameOrigin && frameOrigin !== 'null' ? frameOrigin : fallbackOrigin;
                          if (targetOrigin) {
                              iframe.contentWindow.postMessage({
                                  action: 'requestEmailContent',
                                  requestId: requestId,
                                  nonce
                              }, targetOrigin);
                          }
                      }
                  } catch (error) {
                      logger$a.debug('Failed to post message to iframe', 'email-extractor', { error: error?.message });
                  }
              }

              // Also try nested iframes (VF frames)
              const vfIframes = querySelectorAllDeep('iframe[name*="vfFrameId"], iframe[id*="vfFrameId"]');
              for (const vfFrame of vfIframes) {
                  try {
                      if (vfFrame.contentWindow) {
                          const frameOriginRes = getFrameOrigin(vfFrame, fallbackOrigin);
                          const frameOrigin = frameOriginRes.ok ? frameOriginRes.value : null;
                          if (!isTrustedOrigin(frameOrigin, fallbackOrigin)) continue;
                          const targetOrigin = frameOrigin && frameOrigin !== 'null' ? frameOrigin : fallbackOrigin;
                          if (targetOrigin) {
                              vfFrame.contentWindow.postMessage({
                                  action: 'requestEmailContent',
                                  requestId: requestId,
                                  broadcast: true,
                                  nonce
                              }, targetOrigin);
                          }
                      }
                  } catch (e) {
                      // Attempt to post message to iframe failed; expected if iframe is cross-origin or unreachable
                      logger$a.debug('Failed to post message to iframe', 'email-extractor', e?.message);
                  }
              }

              // Timeout - ensure cleanup is called
              messageTimeout = setTimeout(() => {
                  if (!resolved) {
                      resolved = true;
                      cleanup();
                      resolve(null);
                  }
              }, timeout);
          });
      }
  }

  /**
   * Strategy for extracting text from user selection.
   */

  const logger$9 = createLogger('SelectionExtractor');

  class SelectionExtractor extends InputStrategy {
      canHandle() {
          const selection = window.getSelection();
          return selection && selection.toString().trim().length > 0;
      }

      execute() {
          const selection = window.getSelection();
          const text = selection?.toString()?.trim();
          if (text && text.length > 10) {
              logger$9.debug('Found selected text', 'selection-extractor');
              return text;
          }
          return null;
      }
  }

  /**
   * Helper to extract text from a specific element based on its type.
   * moved from import-tools.js extractTextFromElementHelper
   */
  function extractTextFromElement$1(element) {
      if (!element || !isTextEntryElement(element)) return null;

      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
          const text = element.value?.trim();
          if (text && text.length > 3) return text;
      }

      if (element.isContentEditable || element.hasAttribute('contenteditable')) {
          const innerText = element.innerText?.trim();
          if (innerText && innerText.length > 3 && !isPlaceholderText(innerText)) {
              return innerText;
          }
      }

      const textContent = element.textContent?.trim();
      if (textContent && textContent.length > 3 && !isPlaceholderText(textContent)) {
          return textContent;
      }

      return null;
  }

  /**
   * Strategy for extracting text from Salesforce Chatter publishers.
   */

  const logger$8 = createLogger('ChatterExtractor');

  class ChatterExtractor extends InputStrategy {
      constructor(sidebar) {
          super();
          this.sidebar = sidebar;
      }

      async canHandle() {
          try {
              const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
              const response = await fetch(configUrl);
              const config = await response.json();
              const detectionSelectors = config.chatter.detectionSelectors || [];
              if (detectionSelectors.length > 0) {
                  return !!document.querySelector(detectionSelectors.join(', '));
              }
          } catch (e) {
              logger$8.debug('Failed to load detection selectors, using fallback', 'chatter-extractor');
          }
          // Optimistically check for chatter publisher elements
          return !!document.querySelector('.forceChatterPublisher, .slds-publisher, [class*="chatter"]');
      }

      async execute() {
          return await this.getOperatorInputText(this.sidebar);
      }

      async getOperatorInputText(sidebar) {
          try {
              logger$8.info('=== Chatter Text Detection Debug ===', 'chatter-extractor', undefined);

              // Method 1: Check currently focused element first (but exclude sidebar elements)
              const focusedElement = document.activeElement;

              if (focusedElement && !isElementInSidebar$1(sidebar, focusedElement)) {
                  if (!isTextEntryElement(focusedElement)) {
                      // not text entry
                  } else if (isSubjectFieldElement(focusedElement)) {
                      // subject field
                  } else {
                      const focusedText = extractTextFromElement$1(focusedElement);
                      if (focusedText) {
                          return Result.success(focusedText);
                      }
                  }
              }

              // Method 2: Comprehensive selector search with multiple extraction methods
              let selectors = [];
              try {
                  // We'll use a safer approach for loading config in a strategy
                  const configUrl = chrome.runtime.getURL('modules/config/dom-selectors.json');
                  const response = await fetch(configUrl);
                  const config = await response.json();
                  selectors = config.chatter.publisherSelectors || [];
                  logger$8.debug('Loaded chatter selectors from config', 'chatter-extractor');
              } catch (configError) {
                  logger$8.warn('Failed to load chatter selectors from config, using fallbacks', 'chatter-extractor', configError);
                  selectors = [
                      '.ql-editor',
                      '.forceChatterPublisher .ql-editor',
                      '.slds-publisher .ql-editor',
                      '.publisherContainer .ql-editor',
                      '[data-aura-class*="forceChatterPublisher"] .ql-editor',
                      '.forceChatterCommentPublisher .ql-editor',
                      '[data-aura-class*="CommentPublisher"] .ql-editor',
                      '[contenteditable="true"]',
                      '.forceChatterPublisher [contenteditable="true"]',
                      '.slds-publisher [contenteditable="true"]',
                      '.publisherContainer [contenteditable="true"]',
                      'textarea',
                      'input[type="text"]',
                      '.forceChatterPublisher textarea',
                      '.slds-publisher textarea',
                      '.cke_editable',
                      '.mce-content-body',
                      '[role="textbox"]',
                      '[class*="chatter"] .ql-editor',
                      '[class*="publisher"] .ql-editor',
                      '[class*="composer"] .ql-editor',
                      '[class*="editor"]',
                      'lightning-input-rich-text [contenteditable]',
                      'lightning-textarea textarea',
                      '[data-target-selection-name*="chatter"] .ql-editor',
                      '[data-aura-class*="chatter"] .ql-editor'
                  ];
              }

              const foundElements = [];

              // Search with each selector and collect all potential elements
              for (const selector of selectors) {
                  try {
                      const elements = document.querySelectorAll(selector);
                      for (const element of elements) {
                          // Skip sidebar elements
                          if (isElementInSidebar$1(sidebar, element)) continue;
                          if (!isTextEntryElement(element)) continue;
                          // Skip Subject field elements - we want Chatter text, not case subject
                          if (isSubjectFieldElement(element)) {
                              continue;
                          }

                          const text = extractTextFromElement$1(element);
                          if (text) {
                              foundElements.push({
                                  element: element,
                                  text: text,
                                  selector: selector,
                                  isFocused: element === focusedElement,
                                  isVisible: isElementVisible(element),
                                  length: text.length
                              });
                          }
                      }
                  } catch (e) {
                      logger$8.warn('Selector failed:', 'chatter-extractor', selector, e.message);
                  }
              }

              if (foundElements.length === 0) {
                  return Result.success(null);
              }

              // Priority sorting: focused > visible > longest text
              foundElements.sort((a, b) => {
                  if (a.isFocused && !b.isFocused) return -1;
                  if (!a.isFocused && b.isFocused) return 1;
                  if (a.isVisible && !b.isVisible) return -1;
                  if (!a.isVisible && b.isVisible) return 1;
                  return b.length - a.length; // Longest text first
              });

              const selectedItem = foundElements[0];
              logger$8.debug('✓ Selected text:', 'chatter-extractor', selectedItem.text.substring(0, 50) + '...');

              return Result.success(selectedItem.text);

          } catch (error) {
              logger$8.error('Error getting operator input text:', 'chatter-extractor', error);
              return Result.failure(error);
          }
      }
  }

  // modules/sidebar/features/import-tools.js


  const logger$7 = createLogger('ImportTools');

  /**
   * Capture the text the user has typed into the main Chatter publisher box.
   * @returns {Result<string>}
   */
  async function getOperatorInputText(sidebar) {
      try {
          const extractor = new ChatterExtractor(sidebar);
          const text = await extractor.execute();
          return Result.success(text || '');
      } catch (e) {
          logger$7.warn('Error getting operator input text', 'import-tools', e);
          return Result.failure(e);
      }
  }

  /**
   * Check if an element is within the sidebar
   */
  function isElementInSidebar(sidebar, element) {
      return isElementInSidebar$1(sidebar, element);
  }

  /**
   * Extract text from an element using multiple methods
   */
  function extractTextFromElement(_sidebar, element) {
      if (isTextEntryElement(element)) {
          if (element.value) return element.value.trim();
          if (element.innerText) return element.innerText.trim();
          return element.textContent?.trim();
      }
      return null;
  }

  /**
   * Handle importing text and case context into the original text input
   * @returns {Promise<Result<string>>} The imported text on success
   */
  async function handleImportText(sidebar, overrideText) {
      // Prevent re-entrancy / infinite recursion
      if (handleImportText.isExecuting) {
          logger$7.warn('Prevented recursive call to handleImportText', 'import-tools');
          return Result.failure(new Error('Import already in progress'));
      }

      const originalInput = sidebar.sidebar.querySelector('#original-text-input');
      if (!originalInput) {
          return Result.failure(new Error('Input field not found'));
      }

      handleImportText.isExecuting = true;
      try {
          logger$7.info('=== Import Text Debug ===', 'import-tools', undefined);
          let importedText = '';
          let source = '';

          // Priority 0: Explicit override from caller
          if (overrideText && typeof overrideText === 'string' && overrideText.trim().length > 0) {
              importedText = overrideText.trim();
              source = 'Provided Text';
              logger$7.debug('✓ Using provided text:', 'import-tools', importedText.substring(0, 50) + '...');
          }

          // Priority 1: Email Content
          if (!importedText) {
              const emailStrategy = new EmailExtractor(sidebar);
              let emailText = await emailStrategy.execute();

              // Fallback: If not found, try a broader broadcast request or check cache
              if (!emailText) {
                  // Check if we received a broadcast recently
                  if (window._pandaid_last_email_text && (Date.now() - (window._pandaid_last_email_ts || 0) < 5000)) {
                      emailText = window._pandaid_last_email_text;
                      logger$7.debug('✓ Using cached email text from broadcast', 'import-tools');
                  } else {
                      // Try one last desperate request with short timeout
                      emailText = await requestEmailContentFromIframes(500);
                  }
              }

              if (emailText) {
                  importedText = emailText;
                  source = 'Email Content';
                  logger$7.debug('✓ Found Email text', 'import-tools');
              }
          }

          // Priority 2: Chatter Input
          if (!importedText) {
              const chatterStrategy = new ChatterExtractor(sidebar);
              const chatterText = chatterStrategy.execute();
              if (chatterText) {
                  importedText = chatterText;
                  source = 'Chatter Input';
                  logger$7.debug('✓ Found Chatter text', 'import-tools');
              }
          }

          // Priority 3: Selection
          if (!importedText) {
              const selectionStrategy = new SelectionExtractor();
              const selectionText = selectionStrategy.execute();
              if (selectionText) {
                  importedText = selectionText;
                  source = 'Selected Text';
              }
          }

          // Priority 4: Fallback to Case Context
          if (!importedText) {
              const caseData = sidebar.getCaseDataFromPage();
              let contextText = 'Case Context:\n\n';

              if (caseData.subject) contextText += `Subject: ${caseData.subject}\n`;
              if (caseData.productFamily) contextText += `Product: ${caseData.productFamily}\n`;
              if (caseData.productComponent?.trim()) {
                  contextText += `Component: ${caseData.productComponent}\n`;
              } else if (caseData.productComponent !== undefined) {
                  contextText += `Component: [Not Specified]\n`;
              }

              contextText += '\n--- Add problem description or additional details here ---';

              importedText = contextText;
              source = 'Case Details';
          }

          // Set the value
          const needsSep = originalInput.value && !originalInput.value.endsWith('\n\n') ? '\n\n' : '';
          originalInput.value = (originalInput.value || '') + (originalInput.value ? needsSep : '') + importedText;
          originalInput.focus();

          // Move cursor to end
          originalInput.setSelectionRange(originalInput.value.length, originalInput.value.length);

          logger$7.debug(`Import successful: ${source} imported`, 'import-tools');
          return Result.success(importedText);

      } catch (error) {
          logger$7.error('Error importing text:', 'import-tools', error);
          if (sidebar && typeof sidebar.showError === 'function') {
              sidebar.showError('Failed to import text. Please manually enter your content.');
          }
          return Result.failure(error);
      } finally {
          handleImportText.isExecuting = false;
      }
  }

  async function requestEmailContentFromIframes(timeout = 2000) {
      const strategy = new EmailExtractor(null);
      return strategy.requestEmailContentFromIframes(timeout);
  }

  function extractEmailText(sidebar) {
      try {
          const strategy = new EmailExtractor(sidebar);
          return Result.success(strategy.extractEmailText(sidebar));
      } catch (e) {
          logger$7.warn('Error extracting email text', 'import-tools', e);
          return Result.failure(e);
      }
  }

  // Kept for debugging, consider moving to specific debug util in future
  function getEmailContentDebugInfo(_sidebar) {
      return {
          emailuiComponents: document.querySelectorAll('emailui-rich-text-output').length,
          iframes: document.querySelectorAll('iframe').length,
          contentEditables: document.querySelectorAll('[contenteditable="true"]').length,
      };
  }

  var importTools = /*#__PURE__*/Object.freeze({
    __proto__: null,
    extractEmailText: extractEmailText,
    extractTextFromElement: extractTextFromElement,
    getEmailContentDebugInfo: getEmailContentDebugInfo,
    getOperatorInputText: getOperatorInputText,
    handleImportText: handleImportText,
    isElementInSidebar: isElementInSidebar,
    requestEmailContentFromIframes: requestEmailContentFromIframes
  });

  // AI-driven solution tools (spellcheck, suggest, improve) for the sidebar

  const logger$6 = createLogger('SolutionTools');



  async function handleSpellcheck(self) {
    const originalInput = self.sidebar.querySelector('#original-text-input');
    const improvedInput = self.sidebar.querySelector('#improved-text-input');
    if (!originalInput || !improvedInput) return;
    try {
      const improvedSection = self.sidebar.querySelector('#improved-section');
      const improvedLabel = improvedSection ? improvedSection.querySelector('.input-label') : null;
      if (improvedSection) improvedSection.classList.remove('hidden');
      if (improvedLabel) {
        const copyBtn = improvedLabel.querySelector('#copy-improved-text-btn');
        const labelText = document.createTextNode('Corrected Text');
        Array.from(improvedLabel.childNodes).forEach(n => { if (n.nodeType === Node.TEXT_NODE) n.remove(); });
        if (copyBtn) improvedLabel.insertBefore(labelText, copyBtn);
        else improvedLabel.textContent = 'Corrected Text';
      }
    } catch (e) {
      logger$6.debug('DOM update error (spellcheck header)', 'solution-tools', e);
    }

    const currentText = originalInput.value.trim();
    if (!currentText || currentText === 'Original text or imported content...') {
      originalInput.value = 'Please enter text in the Original Text box to check spelling and grammar.';
      return;
    }

    const originalText = currentText;
    improvedInput.value = 'Checking spelling and grammar...';
    improvedInput.disabled = true;

    try {
      const caseData = (typeof self.getCaseDataFromPage === 'function') ? self.getCaseDataFromPage() : {};
      const response = await sendMessageWithTimeout({ action: 'spellcheck', text: originalText, caseData }, 20000);
      if (response.error) throw new Error(response.error);
      improvedInput.value = response.correctedText || response.data || originalText;
      if (response.correctedText && response.correctedText !== originalText) {
        const tempMessage = 'Spelling and grammar checked - corrections applied to improved text';
        const originalPlaceholder = improvedInput.placeholder;
        improvedInput.placeholder = tempMessage;
        setTimeout(() => { improvedInput.placeholder = originalPlaceholder; }, 3000);
      } else if (response.correctedText === originalText) {
        improvedInput.value = originalText;
        const tempMessage = 'No spelling or grammar errors found';
        const originalPlaceholder = improvedInput.placeholder;
        improvedInput.placeholder = tempMessage;
        setTimeout(() => { improvedInput.placeholder = originalPlaceholder; }, 2000);
      }
    } catch (error) {
      logger$6.error('Error checking spelling:', 'solution-tools', error);
      improvedInput.value = `Error: ${error.message || 'Failed to check spelling and grammar'}`;
      setTimeout(() => { improvedInput.value = ''; }, 3000);
    } finally {
      improvedInput.disabled = false;
    }
  }

  async function handleSuggestSolution(self) {
    const originalInput = self.sidebar.querySelector('#original-text-input');
    const improvedInput = self.sidebar.querySelector('#improved-text-input');
    if (!originalInput || !improvedInput) return;
    try {
      const improvedSection = self.sidebar.querySelector('#improved-section');
      const improvedLabel = improvedSection ? improvedSection.querySelector('.input-label') : null;
      if (improvedSection) improvedSection.classList.remove('hidden');
      if (improvedLabel) {
        const copyBtn = improvedLabel.querySelector('#copy-improved-text-btn');
        const labelText = document.createTextNode('Guidance');
        Array.from(improvedLabel.childNodes).forEach(n => { if (n.nodeType === Node.TEXT_NODE) n.remove(); });
        if (copyBtn) improvedLabel.insertBefore(labelText, copyBtn);
        else improvedLabel.textContent = 'Guidance';
      }
    } catch (e) {
      logger$6.debug('DOM update error (suggest header)', 'solution-tools', e);
    }

    improvedInput.value = 'Analyzing case and generating solution...';
    improvedInput.disabled = true;

    try {
      const caseData = (typeof self.getCaseDataFromPage === 'function') ? self.getCaseDataFromPage() : {};

      // Gather context from rendered results
      const contextLines = [];
      const collectors = [
        { id: '#jira-list', label: 'Jira Work Items' },
        { id: '#confluence-list', label: 'Confluence articles' },
        { id: '#community-list', label: 'Knowledge Base' }
      ];

      collectors.forEach(c => {
        const container = self.sidebar.querySelector(c.id);
        if (container) {
          const items = container.querySelectorAll('.item-title');
          if (items.length > 0) {
            contextLines.push(`${c.label}:`);
            items.forEach(item => contextLines.push(`- ${item.textContent.trim()}`));
          }
        }
      });

      const context = contextLines.join('\n');
      const response = await sendMessageWithTimeout({
        action: 'suggestSolution',
        data: caseData,
        context: context
      }, 20000);

      if (response.error) throw new Error(response.error);
      self.currentSolution = response.solution || response.data?.solution || response.data || 'No solution could be generated.';
      improvedInput.value = self.currentSolution;
    } catch (error) {
      logger$6.error('Error suggesting solution:', 'solution-tools', error);
      improvedInput.value = `Error: ${error.message || 'Failed to generate solution'}`;
    } finally {
      improvedInput.disabled = false;
    }
  }

  async function handleImproveSolution(self) {
    const originalInput = self.sidebar.querySelector('#original-text-input');
    const improvedInput = self.sidebar.querySelector('#improved-text-input');
    if (!originalInput || !improvedInput) return;
    try {
      const improvedSection = self.sidebar.querySelector('#improved-section');
      const improvedLabel = improvedSection ? improvedSection.querySelector('.input-label') : null;
      if (improvedSection) improvedSection.classList.remove('hidden');
      if (improvedLabel) {
        const copyBtn = improvedLabel.querySelector('#copy-improved-text-btn');
        const labelText = document.createTextNode('Enhanced Text');
        Array.from(improvedLabel.childNodes).forEach(n => { if (n.nodeType === Node.TEXT_NODE) n.remove(); });
        if (copyBtn) improvedLabel.insertBefore(labelText, copyBtn);
        else improvedLabel.textContent = 'Enhanced Text';
      }
    } catch (e) {
      logger$6.debug('DOM update error (improve header)', 'solution-tools', e);
    }

    const currentSolution = originalInput.value.trim();
    if (!currentSolution || currentSolution === 'Original text or imported content...') {
      originalInput.value = 'Please enter text in the Original Text box first before improving it.';
      return;
    }

    improvedInput.value = 'Improving the written solution...';
    improvedInput.disabled = true;

    try {
      const caseData = (typeof self.getCaseDataFromPage === 'function') ? self.getCaseDataFromPage() : {};
      const response = await sendMessageWithTimeout({ action: 'improveSolution', currentSolution, caseData }, 20000);
      if (response.error) throw new Error(response.error);
      improvedInput.value = response.improvedSolution || response.data || 'No improvements could be made.';
    } catch (error) {
      logger$6.error('Error improving solution:', 'solution-tools', error);
      improvedInput.value = `Error: ${error.message || 'Failed to improve solution'}`;
    } finally {
      improvedInput.disabled = false;
    }
  }

  var solutionTools = /*#__PURE__*/Object.freeze({
    __proto__: null,
    handleImproveSolution: handleImproveSolution,
    handleSpellcheck: handleSpellcheck,
    handleSuggestSolution: handleSuggestSolution
  });

  // modules/sidebar/features/related-content/data-preloader.js
  //
  // Centralized helper for related-content preloads so sidebar.js can stay lean.


  const logger$5 = createLogger('DataPreloader');

  async function hasAtlassianToken(sidebarInstance) {
    if (sidebarInstance && typeof sidebarInstance.hasAtlassianToken === 'function') {
      return sidebarInstance.hasAtlassianToken();
    }
    return false;
  }

  async function preloadSource(sidebarInstance, type, isManualFetch = false) {
    const config = PRELOAD_CONFIG[type];
    if (!config) {
      logger$5.warn(`[Sidebar] Unknown preload type requested: ${type}`, 'data-preloader', undefined);
      return null;
    }

    if (sidebarInstance && typeof sidebarInstance.isSectionEnabled === 'function' && !sidebarInstance.isSectionEnabled(type)) {
      return null;
    }

    // Prevent Atlassian fetches when no token is configured
    if ((type === 'jira' || type === 'confluence') && !(await hasAtlassianToken(sidebarInstance))) {
      const msg = 'Add an Atlassian API token in Options to load JIRA/Confluence results.';
      sidebarInstance.renderErrorState(type, msg);
      if (typeof sidebarInstance.showWarning === 'function') {
        sidebarInstance.showWarning(msg);
      }
      return null;
    }

    const list = sidebarInstance.sidebar
      ? sidebarInstance.sidebar.querySelector(config.listSelector)
      : null;
    const label = type === 'community' && typeof sidebarInstance?.getKnowledgeBaseLabel === 'function'
      ? sidebarInstance.getKnowledgeBaseLabel('sidebar')
      : config.label;
    const loadingMessage = type === 'community'
      ? `Searching Knowledge Base...`
      : (config.loadingMessage || 'Loading...');

    const loadingEl = document.createElement('div');
    loadingEl.className = 'loading';
    loadingEl.textContent = loadingMessage;

    if (list) {
      list.replaceChildren();
      list.appendChild(loadingEl);
    }

    // Progressive loading updates for community search
    let progressTimer;
    if (type === 'community' && list) {
      progressTimer = setTimeout(() => {
        if (list.contains(loadingEl)) {
          loadingEl.textContent = 'Still searching (taking longer than expected)...';
        }
      }, 5000);
    }

    try {
      const rawCaseData = sidebarInstance.getCaseDataFromPage() || {};

      // Create a lightweight copy of caseData to avoid message size limits
      // CRITICAL: Do NOT spread ...rawCaseData here. It may contain massive objects that break message passing.
      const caseData = {
        subject: rawCaseData.subject ? String(rawCaseData.subject).substring(0, 500) : '',
        description: rawCaseData.description ? String(rawCaseData.description).substring(0, 2500) : '',
        productName: rawCaseData.productName ? String(rawCaseData.productName).substring(0, 100) : '',
        productFamily: rawCaseData.productFamily ? String(rawCaseData.productFamily).substring(0, 100) : '',
        productComponent: rawCaseData.productComponent ? String(rawCaseData.productComponent).substring(0, 200) : '',
        errorMessage: rawCaseData.errorMessage ? String(rawCaseData.errorMessage).substring(0, 500) : '',
        category: rawCaseData.category ? String(rawCaseData.category).substring(0, 100) : ''
      };

      logger$5.debug(`[DataPreloader] Sending ${type} request`, 'data-preloader');
      const response = await sendMessageWithTimeout(
        config.actionBuilder(caseData, isManualFetch),
        15000 // Reduced timeout for faster feedback
      );
      logger$5.debug(`[DataPreloader] Received ${type} response`, 'data-preloader', response);

      if (progressTimer) clearTimeout(progressTimer);

      if (response && response.ok) {
        const items = response[config.responseKey] || response.data || [];
        if (typeof sidebarInstance.renderResultList === 'function') {
          sidebarInstance.renderResultList(type, items);
        }
        return items;
      }

      const errorMsg =
        response && response.error
          ? response.error
          : `Unknown error fetching ${label}`;
      throw new Error(errorMsg);
    } catch (error) {
      logger$5.error(`[Sidebar] Failed to preload ${config.label}:`, 'data-preloader', error);

      // Explicitly clear the loading state and show error message in the list
      if (list) {
        list.replaceChildren();
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = `Unable to load ${label}. ${error.message || 'Please retry.'}`;
        list.appendChild(errorDiv);
      }

      if (typeof sidebarInstance.showError === 'function') {
        sidebarInstance.showError(`Unable to load ${config.label}. ${error.message || ''}`);
      }
      return null;
    }
  }

  var dataPreloader = /*#__PURE__*/Object.freeze({
    __proto__: null,
    SOURCE_CONFIG: PRELOAD_CONFIG,
    preloadSource: preloadSource
  });

  // UI helper functions for the sidebar (exported as functions that accept `self`)


  const logger$4 = createLogger('UiComponents');

  function getProductIconHTML(self, productName) {
    // Defer to utils if present
    if (self.utils && typeof self.utils.getProductIconHTML === 'function') {
      try { return self.utils.getProductIconHTML(productName); } catch (e) { logger$4.debug('self.utils.getProductIconHTML failed in ui-components.js', 'ui-components', e); }
    }

    if (!productName) return '';
    const productLower = (productName || '').toLowerCase();
    if (productLower === 'impact' || productLower.includes('impact')) {
      return `<img src="${chrome.runtime.getURL('icons/impact.svg')}" alt="Impact" class="product-icon" />`;
    }
    return '';
  }

  function showImprovedSection(self) {
    try {
      const improvedSection = self.sidebar.querySelector('#improved-section');
      if (improvedSection && improvedSection.classList.contains('hidden')) {
        improvedSection.classList.remove('hidden');
      }
    } catch (e) {
      logger$4.debug('showImprovedSection error', 'ui-components', e);
    }
  }

  function adjustButtonLabels(self) {
    try {
      const buttons = self.sidebar.querySelectorAll('.action-button');
      const sidebarWidth = self.sidebar.offsetWidth;
      buttons.forEach(button => {
        const buttonText = button.querySelector('.button-text');
        const originalText = button.dataset.originalText;
        const shortText = button.dataset.shortText;
        if (sidebarWidth < 380 && shortText) {
          buttonText.textContent = shortText;
        } else if (buttonText) {
          buttonText.textContent = originalText;
        }
      });
    } catch (e) {
      logger$4.debug('adjustButtonLabels error', 'ui-components', e);
    }
  }

  function renderFetchButton(self, type, isConfigured) {
    if (typeof self.isSectionEnabled === 'function' && !self.isSectionEnabled(type)) return;

    const cfg = self.sourceConfig.get(type);
    if (!cfg) return;

    const list = self.sidebar.querySelector(cfg.listSelector);
    const buttonId = `fetch-${type}-btn`;
    const buttonText = isConfigured ? `${cfg.displayName.replace(/ articles| tickets$/i, '')} Preload disabled - Click to fetch` :
      `Configure ${cfg.displayName.replace(/ tickets| articles$/i, '')}`;

    if (!list) return;

    list.replaceChildren();
    const wrapper = document.createElement('div');
    wrapper.className = 'prefetch-disabled';

    const button = document.createElement('button');
    button.className = `fetch-button ${!isConfigured ? 'disabled' : ''}`.trim();
    button.id = buttonId;
    if (!isConfigured) button.disabled = true;
    const span = document.createElement('span');
    span.textContent = buttonText;
    button.appendChild(span);
    wrapper.appendChild(button);

    if (!isConfigured) {
      const notice = document.createElement('div');
      notice.className = 'prefetch-notice';
      notice.textContent = 'Configure in Options to enable';
      wrapper.appendChild(notice);
    }

    list.appendChild(wrapper);

    if (button) {
      self.boundHandlers[buttonId] = () => {
        if (isConfigured) {
          try {
            cfg.preload(true);
          } catch (err) {
            logger$4.debug('cfg.preload failed in ui-components.js, falling back to fetchRelatedItems', 'ui-components', err);
            self.fetchRelatedItems(type);
          }
        } else {
          try {
            self.sendMessageWithTimeout({ action: 'openOptionsPage' }, 5000).catch(() => { });
          } catch (e) {
            logger$4.debug('sendMessageWithTimeout fallback error', 'ui-components', e);
            try { chrome.runtime.sendMessage({ action: 'openOptionsPage' }); } catch (_) { logger$4.debug('Options page open via sendMessage failed (expected in some contexts)', 'ui-components', _); }
          }
        }
      };
      button.addEventListener('click', self.boundHandlers[buttonId]);
      self.eventHandlers[buttonId] = { element: button, type: 'click', handler: self.boundHandlers[buttonId] };
    }
  }

  async function handleCopyImprovedText(self) {
    const improvedInput = self.sidebar.querySelector('#improved-text-input');
    const copyBtn = self.sidebar.querySelector('#copy-improved-text-btn');
    if (!improvedInput || !copyBtn) return;

    const textToCopy = improvedInput.value.trim();
    if (!textToCopy) {
      copyBtn.style.color = '#ff6b6b';
      copyBtn.title = 'No text to copy';
      setTimeout(() => { copyBtn.style.color = ''; copyBtn.title = 'Copy to clipboard'; }, 1000);
      return;
    }

    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }

      copyBtn.classList.add('copied');
      copyBtn.title = 'Copied!';
      const originalIcon = copyBtn.querySelector('svg')?.cloneNode(true);
      copyBtn.replaceChildren(createCheckIcon());
      setTimeout(() => {
        copyBtn.classList.remove('copied');
        copyBtn.title = 'Copy to clipboard';
        if (originalIcon) {
          copyBtn.replaceChildren(originalIcon);
        }
      }, 2000);
    } catch (error) {
      logger$4.error('Failed to copy text to clipboard:', 'ui-components', error);
      copyBtn.style.color = '#ff6b6b';
      copyBtn.title = 'Copy failed - try selecting and copying manually';
      setTimeout(() => { copyBtn.style.color = ''; copyBtn.title = 'Copy to clipboard'; }, 3000);
    }
  }

  function showError(self, message) {
    try {
      const improvedInput = self.sidebar.querySelector('#improved-text-input');
      if (improvedInput) improvedInput.value = `Error: ${message}`;
      if (typeof self.toggle === 'function') self.toggle(true);
    } catch (e) {
      logger$4.warn('showError failed:', 'ui-components', e);
    }
  }

  function notifyButtonVisibilityChange(self) {
    try {
      const event = new CustomEvent('sidebarToggle', { detail: { isVisible: self.isVisible } });
      self.vlog && self.vlog('[Sidebar] dispatching sidebarToggle event:', { isVisible: self.isVisible });
      window.dispatchEvent(event);
      try {
        const emailIframes = document.querySelectorAll('iframe.cke_wysiwyg_frame, iframe[title*="Email"]');
        if (!emailIframes.length) return;

        getMessageNonce()
          .then((nonce) => {
            const fallbackOrigin = window.location?.origin && window.location.origin !== 'null'
              ? window.location.origin
              : null;

            emailIframes.forEach(iframe => {
              try {
                if (!iframe.contentWindow) return;
                const frameOriginRes = getFrameOrigin(iframe, fallbackOrigin);
                const frameOrigin = frameOriginRes.ok ? frameOriginRes.value : null;
                if (!isTrustedOrigin(frameOrigin, fallbackOrigin)) return;
                const targetOrigin = frameOrigin && frameOrigin !== 'null' ? frameOrigin : fallbackOrigin;
                if (!targetOrigin) return;
                iframe.contentWindow.postMessage({ action: 'sidebarStateChange', isOpen: self.isVisible, nonce }, targetOrigin);
              } catch (err) { logger$4.debug('iframe postMessage error (cross-origin)', 'ui-components', err); }
            });
            self.vlog && self.vlog('[Sidebar] posted sidebarStateChange to iframes:', { isOpen: self.isVisible });
          })
          .catch((err) => {
            logger$4.warn('Failed to fetch message nonce for iframe notification', 'ui-components', err);
          });
      } catch (err) {
        logger$4.warn('Error notifying iframe buttons:', 'ui-components', err);
      }
    } catch (e) {
      logger$4.debug('notifyButtonVisibilityChange error', 'ui-components', e);
    }
  }

  function createCheckIcon() {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '14');
    svg.setAttribute('height', '14');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');

    const polyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    polyline.setAttribute('points', '20,6 9,17 4,12');
    svg.appendChild(polyline);

    return svg;
  }

  var uiComponents = /*#__PURE__*/Object.freeze({
    __proto__: null,
    adjustButtonLabels: adjustButtonLabels,
    getProductIconHTML: getProductIconHTML,
    handleCopyImprovedText: handleCopyImprovedText,
    notifyButtonVisibilityChange: notifyButtonVisibilityChange,
    renderFetchButton: renderFetchButton,
    showError: showError,
    showImprovedSection: showImprovedSection
  });

  const logger$3 = createLogger('TooltipUI');

  function showTooltipForHint(sidebarInstance, hint) {
    if (!hint) return;
    const tipInner = hint.querySelector('.ai-tooltip-text');
    if (!tipInner) return;
    const sidebar = sidebarInstance?.sidebar;

    try {
      let global = document.getElementById('sf-global-tooltip');
      if (!global) {
        global = document.createElement('div');
        global.id = 'sf-global-tooltip';
        document.body.appendChild(global);
      }

      const sidebarRect = sidebar ? sidebar.getBoundingClientRect() : { width: window.innerWidth, left: 0 };
      const hintRect = hint.getBoundingClientRect();

      const inset = 12; // px
      const width = Math.max(240, Math.min(sidebarRect.width - inset * 2, window.innerWidth - 40));
      const left = Math.max(8, Math.round(sidebarRect.left + inset));

      global.textContent = tipInner.textContent || tipInner.innerText || '';
      global.style.width = `${width}px`;
      global.style.display = 'block';
      global.style.visibility = 'hidden';

      const tooltipHeight = global.offsetHeight;
      const spaceBelow = window.innerHeight - hintRect.bottom;
      const spaceAbove = hintRect.top;
      const offset = 8;

      let top;
      if (spaceBelow < tooltipHeight && spaceAbove > spaceBelow) {
        top = Math.round(hintRect.top - tooltipHeight - offset);
      } else {
        top = Math.round(hintRect.bottom + offset);
      }

      global.style.left = `${left}px`;
      global.style.top = `${top}px`;
      global.style.visibility = 'visible';
    } catch (err) {
      logger$3.debug('Error showing hint tooltip', 'tooltip', err);
      const tip = tipInner;
      tip.style.display = 'block';
    }
  }

  function hideTooltipForHint(_sidebarInstance, hint) {
    try {
      const global = document.getElementById('sf-global-tooltip');
      if (global) global.style.display = 'none';
    } catch (e) {
      logger$3.debug('Error hiding hint tooltip', 'tooltip', e);
      const tip = hint && hint.querySelector ? hint.querySelector('.ai-tooltip-text') : null;
      if (tip) tip.style.display = 'none';
    }
  }

  var tooltipManager = /*#__PURE__*/Object.freeze({
    __proto__: null,
    hideTooltipForHint: hideTooltipForHint,
    showTooltipForHint: showTooltipForHint
  });

  /**
   * Shortcuts UI Module
   * Handles keyboard shortcuts help tooltip logic
   * 
   * @module sidebar/ui/shortcuts
   */


  const logger$2 = createLogger('Shortcuts');

  /**
   * Setup keyboard shortcuts help tooltip logic
   * @param {Object} context - The sidebar controller context
   * @param {Function} getShortcutHelpHTML - Function that returns the HTML content for the help tooltip
   */
  function setupShortcutsHelp(context, getShortcutHelpHTML) {
      if (!context.sidebar) return;

      const helpBtn = context.sidebar.querySelector('#shortcuts-help-btn');
      const tooltip = context.sidebar.querySelector('#shortcuts-help-tooltip');
      const content = tooltip?.querySelector('.shortcuts-help-content');

      if (!helpBtn || !tooltip || !content) return;

      helpBtn.setAttribute('role', 'button');
      helpBtn.setAttribute('aria-controls', 'shortcuts-help-tooltip');
      helpBtn.setAttribute('aria-expanded', 'false');

      const renderHelpContent = () => {
          if (typeof getShortcutHelpHTML === 'function') {
              try {
                  content.innerHTML = getShortcutHelpHTML();
                  return;
              } catch (err) {
                  logger$2.warn('Failed to render shortcuts help content', 'shortcuts', err);
              }
          }
          content.textContent = 'Keyboard shortcuts unavailable.';
      };

      const setTooltipOpen = (open) => {
          tooltip.classList.toggle('hidden', !open);
          helpBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
          if (open) renderHelpContent();
      };

      const isTooltipOpen = () => !tooltip.classList.contains('hidden');

      const removeHandler = (key) => {
          const existing = context.eventHandlers[key];
          if (existing) {
              existing.element.removeEventListener(existing.type, existing.handler);
              delete context.eventHandlers[key];
          }
      };

      removeHandler('shortcutsHelpClick');
      removeHandler('shortcutsHelpKeydown');
      removeHandler('shortcutsHelpDismiss');

      context.boundHandlers.shortcutsHelpClick = () => {
          setTooltipOpen(!isTooltipOpen());
      };
      helpBtn.addEventListener('click', context.boundHandlers.shortcutsHelpClick);
      context.eventHandlers.shortcutsHelpClick = { element: helpBtn, type: 'click', handler: context.boundHandlers.shortcutsHelpClick };

      context.boundHandlers.shortcutsHelpKeydown = (event) => {
          if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault();
              setTooltipOpen(!isTooltipOpen());
          }
      };
      helpBtn.addEventListener('keydown', context.boundHandlers.shortcutsHelpKeydown);
      context.eventHandlers.shortcutsHelpKeydown = { element: helpBtn, type: 'keydown', handler: context.boundHandlers.shortcutsHelpKeydown };

      context.boundHandlers.shortcutsHelpDismiss = (event) => {
          if (!isTooltipOpen()) return;
          const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
          const clickInside = path.length
              ? path.includes(helpBtn) || path.includes(tooltip)
              : helpBtn.contains(event.target) || tooltip.contains(event.target);

          if (!clickInside) setTooltipOpen(false);
      };
      document.addEventListener('click', context.boundHandlers.shortcutsHelpDismiss);
      context.eventHandlers.shortcutsHelpDismiss = { element: document, type: 'click', handler: context.boundHandlers.shortcutsHelpDismiss };

      if (!tooltip.classList.contains('hidden')) {
          tooltip.classList.add('hidden');
          helpBtn.setAttribute('aria-expanded', 'false');
      }

      renderHelpContent();
  }

  /**
   * Sidebar Lifecycle Controller
   * Handles initialization, module loading, and cleanup for the sidebar.
   */

  const logger$1 = createLogger('SidebarLifecycleController');

  class SidebarLifecycleController {
      constructor(sidebar) {
          this.sidebar = sidebar;
      }

      async initialize() {
          await this.sidebar.uiLoader.createSidebar(this.sidebar);
          this.sidebar.utils.applyKnowledgeBaseLabelsToSidebar(this.sidebar);
          this.sidebar.utils.loadKnowledgeBaseLabels(this.sidebar);

          try {
              const res = await chrome.storage.local.get(['verboseLogging']);
              if (res && typeof res.verboseLogging === 'boolean') {
                  this.sidebar.verboseLogging = res.verboseLogging;
              }
          } catch (e) {
              logger$1.debug('Error loading verboseLogging preference', 'sidebar', e);
          }

          this.sidebar.eventModule.setupEventListeners(this.sidebar);
          this.sidebar.setupStorageListener();
          await this.sidebar.updateAiAvailability();
          await this.initializeNewFeatures();
      }

      async initializeNewFeatures() {
          if (!this.sidebar.sidebar) return;
          try {
              const initializerModule = await this.safeLoadModule('modules/sidebar/feature-initializer.js', 'feature-initializer');
              if (initializerModule) {
                  const result = await initializerModule.initializeFeatures(this.sidebar);
                  this.sidebar.featureModules = result.featureModules || {};
              }
          } catch (error) {
              logger$1.error('[Sidebar] Feature initialization failed:', 'sidebar', error);
          }
      }

      async safeLoadModule(relativePath, key) {
          try {
              return await importWithTimeout(chrome.runtime.getURL(relativePath), DYNAMIC_IMPORT_TIMEOUT_MS, key);
          } catch (error) {
              logger$1.error(`[Sidebar] Failed to load module ${key}:`, 'sidebar', error);
              return null;
          }
      }

      cleanup() {
          if (this.sidebar.featureModules?.autoSave?.clearAutoSave) {
              this.sidebar.featureModules.autoSave.clearAutoSave();
          }
          if (this.sidebar.sidebar?.parentNode) {
              this.sidebar.sidebar.parentNode.removeChild(this.sidebar.sidebar);
          }
          this.sidebar.sidebar = null;
          this.sidebar.isVisible = false;
      }
  }

  /**
   * Sidebar Event Controller
   * Handles event listener setup and storage change handling for the sidebar.
   */

  createLogger('SidebarEventController');

  class SidebarEventController {
      constructor(sidebar) {
          this.sidebar = sidebar;
      }

      setupEventListeners() {
          this.sidebar.eventModule.setupEventListeners(this.sidebar);
      }

      setupStorageListener() {
          this.sidebar.boundHandlers.storageChange = (changes, areaName) => {
              if (areaName !== 'local') return;
              if (changes.preloadSettings || changes.sidebarSections) this.sidebar.loadPreloadSettings();
              if (changes.sidebarWidth) this.sidebar.applySidebarWidth();
              if (changes.aiEnabled || changes.aiServiceToken || changes.apiEndpoint) this.sidebar.updateAiAvailability();
              if (changes.knowledgeBaseLabels) this.sidebar.utils.loadKnowledgeBaseLabels(this.sidebar);
          };
          chrome.storage.onChanged.addListener(this.sidebar.boundHandlers.storageChange);
      }

      cleanup() {
          if (this.sidebar.eventHandlers) {
              Object.values(this.sidebar.eventHandlers).forEach(({ element, type, handler }) => {
                  element?.removeEventListener?.(type, handler);
              });
          }
          if (chrome.storage?.onChanged && this.sidebar.boundHandlers?.storageChange) {
              chrome.storage.onChanged.removeListener(this.sidebar.boundHandlers.storageChange);
          }
      }
  }

  const logger = createLogger('Sidebar');

  class SalesforceSidebar {
    constructor() {
      this.sidebar = null;
      this.isVisible = false;
      this.currentSolution = null;
      this.isOpening = false;
      this.knowledgeBaseLabels = { entryLabel: 'Knowledge Base', sidebarLabel: 'Knowledge Base' };
      this.toggleInProgress = false;
      this.eventHandlers = {};
      this.boundHandlers = {};
      this.aiAvailable = false;
      this.verboseLogging = false;
      this.sectionVisibility = { jira: true, confluence: true, community: true };

      this.initializationPromise = null;
      this.isInitialized = false;
      this.initializationError = null;

      // Module References
      this.utils = sidebarUtils;
      this.caseModule = caseDetails;
      this.importModule = importTools;
      this.solutionModule = solutionTools;
      this.uiModule = uiComponents;
      this.stateManagerModule = { SidebarStateManager, applyStateToView, resetDOM };
      this.stateManager = new SidebarStateManager();
      this.dataModule = dataPreloader;
      this.tooltipModule = tooltipManager;
      this.storageModule = storageUtils;
      this.aiAvailabilityModule = aiAvailability;
      this.uiLoader = uiLoader;
      this.visibilityModule = visibilityManager;
      this.renderModule = resultRenderer;
      this.eventModule = eventSetup;

      // Controllers
      this.lifecycle = new SidebarLifecycleController(this);
      this.events = new SidebarEventController(this);

      this.initializationPromise = this.initialize()
        .then(() => {
          this.isInitialized = true;
        })
        .catch((error) => {
          logger.error('[Sidebar] Initialization failed:', 'sidebar', error);
          this.isInitialized = false;
          this.initializationError = error;
        });

      this.sourceConfig = new Map([
        ['jira', {
          listSelector: PRELOAD_CONFIG.jira.listSelector,
          sectionSelector: PRELOAD_CONFIG.jira.sectionSelector,
          displayName: PRELOAD_CONFIG.jira.displayName,
          preload: this.preloadJiraTickets.bind(this)
        }],
        ['confluence', {
          listSelector: PRELOAD_CONFIG.confluence.listSelector,
          sectionSelector: PRELOAD_CONFIG.confluence.sectionSelector,
          displayName: PRELOAD_CONFIG.confluence.displayName,
          preload: this.preloadConfluenceArticles.bind(this)
        }],
        ['community', {
          listSelector: PRELOAD_CONFIG.community.listSelector,
          sectionSelector: PRELOAD_CONFIG.community.sectionSelector,
          displayName: this.getKnowledgeBaseLabel('entry'),
          preload: this.preloadCommunityGuides.bind(this)
        }]
      ]);
    }

    async initialize() {
      return this.lifecycle.initialize();
    }

    async ensureInitialized() {
      if (this.isInitialized) return;
      if (!this.initializationPromise) throw new Error('[Sidebar] Initialization never started');
      await this.initializationPromise;
    }

    getKnowledgeBaseLabel(type = 'entry') {
      return this.utils.getKnowledgeBaseLabel(this, type);
    }

    async preloadSource(type, isManualFetch = false) {
      return this.dataModule.preloadSource(this, type, isManualFetch);
    }

    async hasAtlassianToken() {
      try {
        const stored = await chrome.storage.local.get(['atlassianToken']);
        return !!(stored?.atlassianToken?.trim());
      } catch (e) {
        logger.debug('Error checking atlassianToken', 'sidebar', e);
        return false;
      }
    }

    preloadJiraTickets(isManualFetch = false) { return this.preloadSource('jira', isManualFetch); }
    preloadConfluenceArticles(isManualFetch = false) { return this.preloadSource('confluence', isManualFetch); }
    preloadCommunityGuides(isManualFetch = false) { return this.preloadSource('community', isManualFetch); }

    async resetToInitialState() {
      try {
        this.stateManagerModule.resetDOM(this);
        const state = await this.stateManager.loadState();
        this.stateManagerModule.applyStateToView(this, state);
      } catch (e) {
        logger.error('Error in resetToInitialState:', 'sidebar', e);
      }
    }

    async loadPreloadSettings() {
      try {
        const state = await this.stateManager.loadState();
        this.stateManagerModule.applyStateToView(this, state);
      } catch (e) {
        logger.error('Error in loadPreloadSettings:', 'sidebar', e);
      }
    }

    async initializeNewFeatures() {
      return this.lifecycle.initializeNewFeatures();
    }

    async safeLoadModule(relativePath, key) {
      return this.lifecycle.safeLoadModule(relativePath, key);
    }

    setupEventListeners() {
      this.events.setupEventListeners();
    }

    setupStorageListener() {
      this.events.setupStorageListener();
    }

    vlog(...args) {
      if (this.verboseLogging) logger.debug(args.join(' '), 'sidebar');
    }

    isSectionEnabled(type) {
      return this.sectionVisibility?.[type] !== false;
    }

    applySectionVisibility(visibility = {}) {
      this.sectionVisibility = { jira: true, confluence: true, community: true, ...visibility };
      if (!this.sidebar) return;
      this.sourceConfig.forEach((cfg, type) => {
        const enabled = this.isSectionEnabled(type);
        const section = this.sidebar.querySelector(cfg.sectionSelector);
        if (section) {
          section.style.display = enabled ? '' : 'none';
          section.setAttribute('data-section-enabled', String(enabled));
        }
        if (!enabled) this.sidebar.querySelector(cfg.listSelector)?.replaceChildren();
      });
    }

    async toggle(show = !this.isVisible) {
      return this.visibilityModule.toggle(this, show);
    }

    updateContent(data) { return this.renderModule.updateContent(this, data); }
    renderResultList(type, items = []) {
      if (this.isSectionEnabled(type)) return this.renderModule.renderResultList(this, type, items);
    }
    renderErrorState(type, message) {
      if (this.isSectionEnabled(type)) return this.renderModule.renderErrorState(this, type, message);
    }
    renderFetchButton(type, isConfigured) {
      return this.uiModule.renderFetchButton(this, type, isConfigured);
    }

    showImprovedSection() {
      return this.uiModule.showImprovedSection(this);
    }

    adjustButtonLabels() {
      return this.uiModule.adjustButtonLabels(this);
    }

    getProductIconHTML(productName) {
      return this.uiModule.getProductIconHTML(this, productName);
    }

    async loadCaseDetails() {
      await this.ensureInitialized();
      return this.caseModule.loadCaseDetails(this);
    }

    async performCaseDetailsLoad(caseInfo) {
      await this.ensureInitialized();
      return this.caseModule.performCaseDetailsLoad(this, caseInfo);
    }

    async retryPerformCaseDetailsLoad(attempts = 3, intervalMs = 800) {
      await this.ensureInitialized();
      return this.caseModule.retryPerformCaseDetailsLoad(this, attempts, intervalMs);
    }

    async loadCaseDetailsEnhanced(attempt = 0) {
      await this.ensureInitialized();
      return this.caseModule.loadCaseDetailsEnhanced(this, attempt);
    }

    getCaseDataFromPage() {
      return this.caseModule.getCaseDataFromPage(this);
    }

    async handleImportText(overrideText) {
      return this.importModule.handleImportText(this, overrideText);
    }

    async handleCopyImprovedText() {
      return this.uiModule.handleCopyImprovedText(this);
    }

    showWarning(message) {
      logger.warn('[Sidebar] Warning:', 'sidebar', message);
      chrome.runtime.sendMessage({ action: 'showNotification', message, type: 'warning' }).catch((err) => { logger.debug('sendMessage showNotification warning failed', 'sidebar', err); });
    }

    showError(message) {
      logger.error('Error', 'sidebar', message);
      chrome.runtime.sendMessage({ action: 'showNotification', message, type: 'error' }).catch((err) => { logger.debug('sendMessage showNotification error failed', 'sidebar', err); });
      return this.uiModule.showError(this, message);
    }

    notifyButtonVisibilityChange() {
      return this.uiModule.notifyButtonVisibilityChange(this);
    }

    async applySidebarWidth() {
      return this.storageModule.applySidebarWidth(this);
    }

    restoreCollapseState() {
      return this.storageModule.restoreCollapseState(this);
    }

    saveCollapseStateEntry(controlId, isCollapsed) {
      return this.storageModule.saveCollapseStateEntry(this, controlId, isCollapsed);
    }

    async updateAiAvailability() {
      const result = await this.aiAvailabilityModule.updateAiAvailability(this);
      const available = result.ok ? result.value : false;
      this.aiAvailable = available;
      this.aiAvailabilityModule.setAiUiAvailability(this, available);
    }

    // Pure UI Logic still needed here for DOM coordination
    ensureRefreshButtonWired(retryCount = 0) {
      const refreshBtn = this.sidebar.querySelector('#refresh-case-details-btn');
      if (!refreshBtn) {
        if (retryCount < 5) setTimeout(() => this.ensureRefreshButtonWired(retryCount + 1), 500);
        return;
      }
      if (this.eventHandlers.refreshCaseDetails) {
        const existing = this.eventHandlers.refreshCaseDetails;
        existing.element.removeEventListener(existing.type, existing.handler);
      }
      this.boundHandlers.refreshCaseDetails = async () => {
        refreshBtn.disabled = true;
        refreshBtn.classList.add('loading');
        try {
          await this.retryPerformCaseDetailsLoad(4, 700);
        } finally {
          refreshBtn.disabled = false;
          refreshBtn.classList.remove('loading');
        }
      };
      refreshBtn.addEventListener('click', this.boundHandlers.refreshCaseDetails);
      this.eventHandlers.refreshCaseDetails = { element: refreshBtn, type: 'click', handler: this.boundHandlers.refreshCaseDetails };
    }

    async handleSpellcheck() {
      if (!this.aiAvailable) return this.showWarning('AI token not configured.');
      return this.solutionModule.handleSpellcheck(this);
    }

    async handleSuggestSolution() {
      if (!this.aiAvailable) return this.showWarning('AI token not configured.');
      return this.solutionModule.handleSuggestSolution(this);
    }

    async handleImproveSolution() {
      if (!this.aiAvailable) return this.showWarning('AI token not configured.');
      return this.solutionModule.handleImproveSolution(this);
    }

    fetchRelatedItems(type) {
      return this.preloadSource(type, true);
    }

    sendMessageWithTimeout(message, timeoutMs) {
      return sendMessageWithTimeout(message, timeoutMs);
    }

    handleResize() {
      return this.adjustButtonLabels();
    }

    setupShortcutsHelp(getShortcutHelpHTML) {
      setupShortcutsHelp(this, getShortcutHelpHTML);
    }

    showTooltipForHint(hint) {
      return this.tooltipModule.showTooltipForHint(this, hint);
    }

    hideTooltipForHint(hint) {
      return this.tooltipModule.hideTooltipForHint(this, hint);
    }

    updateKnowledgeBaseSourceConfig() {
      const cfg = this.sourceConfig.get('community');
      if (cfg) cfg.displayName = this.getKnowledgeBaseLabel('entry');
    }

    applyKnowledgeBaseLabelsToSidebar() {
      return this.utils.applyKnowledgeBaseLabelsToSidebar(this);
    }

    setupCaseInfoObserver() {
      if (!this.sidebar) return;
      const observer = new MutationObserver((mutations, obs) => {
        for (const m of mutations) {
          for (const node of m.addedNodes) {
            if (node.id === 'case-info' || node.querySelector?.('#case-info')) {
              obs.disconnect();
              setTimeout(() => this.loadCaseDetailsEnhanced(), 100);
              return;
            }
          }
        }
      });
      observer.observe(this.sidebar, { childList: true, subtree: true });
      this.caseInfoObserver = observer;
    }

    cleanup() {
      logger.info('Cleaning up sidebar', 'sidebar');
      this.events.cleanup();
      if (this.resizeObserver) this.resizeObserver.disconnect();
      if (this.caseInfoObserver) this.caseInfoObserver.disconnect();
      this.lifecycle.cleanup();
      this.eventHandlers = {};
      this.boundHandlers = {};
    }
  }

  window.SalesforceSidebar = SalesforceSidebar;

})();
