import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum PaymentType { recurring, recurringIncome, debt, oneOff, oneOffIncome, spendingEnvelope }

extension PaymentTypeExtension on PaymentType {
  String get label {
    switch (this) {
      case PaymentType.recurring:
        return 'Recurring Expense';
      case PaymentType.recurringIncome:
        return 'Recurring Income';
      case PaymentType.debt:
        return 'Debt Payment';
      case PaymentType.oneOff:
        return 'One-time Expense';
      case PaymentType.oneOffIncome:
        return 'One-time Income';
      case PaymentType.spendingEnvelope:
        return 'Spending Envelope';
    }
  }

  /// Returns true if this payment type represents income (positive cash flow)
  bool get isIncomeType {
    return this == PaymentType.recurringIncome || this == PaymentType.oneOffIncome;
  }
}

class PaymentEntry extends Equatable {
  const PaymentEntry({
    required this.id,
    required this.label,
    required this.amountMinorUnits,
    required this.date,
    required this.type,
    this.plannerItemId,
    this.notes,
    this.category,
    this.company,
    this.scheduledDate,
    this.scheduledAmountMinorUnits,
    this.moneyPotId,
  });

  final EntryId id;
  final String label;
  final int amountMinorUnits;
  final DateTime date;
  final PaymentType type;
  final PlannerItemId? plannerItemId;
  final String? notes;

  /// Optional category for organizing payments (e.g., "Groceries", "Utilities", "Salary").
  /// Can be used independently or derived from linked planner item category.
  final String? category;

  /// Optional company/provider name (e.g., "Electric Co", "Comcast", "Acme Corp").
  /// Tracks the source or destination of the payment.
  final String? company;

  /// When payment was originally scheduled (copied from PlannerItem).
  /// Null indicates no variance tracking (legacy or standalone payment).
  final DateTime? scheduledDate;

  /// Expected amount in cents (copied from PlannerItem).
  /// Null indicates amount matched or legacy payment.
  final int? scheduledAmountMinorUnits;

  /// ID of the Money Pot updated by this payment.
  /// Used to reverse the balance update if the payment is deleted.
  final MoneyPotId? moneyPotId;

  PaymentEntry copyWith({
    String? label,
    int? amountMinorUnits,
    DateTime? date,
    PaymentType? type,
    Object? plannerItemId = sentinel,
    Object? notes = sentinel,
    Object? category = sentinel,
    Object? company = sentinel,
    Object? scheduledDate = sentinel,
    Object? scheduledAmountMinorUnits = sentinel,
    Object? moneyPotId = sentinel,
  }) {
    return PaymentEntry(
      id: id,
      label: label ?? this.label,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      date: date ?? this.date,
      type: type ?? this.type,
      plannerItemId: plannerItemId == sentinel
          ? this.plannerItemId
          : plannerItemId as PlannerItemId?,
      notes: notes == sentinel ? this.notes : notes as String?,
      category: category == sentinel ? this.category : category as String?,
      company: company == sentinel ? this.company : company as String?,
      scheduledDate:
          scheduledDate == sentinel ? this.scheduledDate : scheduledDate as DateTime?,
      scheduledAmountMinorUnits: scheduledAmountMinorUnits == sentinel
          ? this.scheduledAmountMinorUnits
          : scheduledAmountMinorUnits as int?,
      moneyPotId: moneyPotId == sentinel ? this.moneyPotId : moneyPotId as MoneyPotId?,
    );
  }

  @override
  List<Object?> get props => [id, label, amountMinorUnits, date, type, plannerItemId, notes, category, company, scheduledDate, scheduledAmountMinorUnits, moneyPotId];
}
