/// Metadata about a currency's formatting requirements.
///
/// This abstraction supports currencies with different subunit ratios:
/// - Most currencies (USD, EUR, GBP): 100 subunits per unit (cents)
/// - Zero-decimal currencies (JPY, VND, KRW): 1 subunit per unit (no decimals)
/// - Three-decimal currencies (KWD, BHD, OMR): 1000 subunits per unit (fils)
class CurrencyInfo {
  const CurrencyInfo({
    required this.code,
    required this.symbol,
    required this.decimalDigits,
    required this.subunitRatio,
    this.symbolPosition = SymbolPosition.before,
    this.groupSeparator = ',',
    this.decimalSeparator = '.',
    this.isFrankfurterSupported = false,
  });

  /// ISO 4217 currency code (e.g., "USD", "EUR", "VND").
  final String code;

  /// Currency symbol for display (e.g., "$", "€", "₫").
  final String symbol;

  /// Number of decimal places to display (0, 2, or 3).
  final int decimalDigits;

  /// How many minor units make up one major unit.
  /// - 100 for most currencies (cents)
  /// - 1 for zero-decimal currencies (yen, dong)
  /// - 1000 for three-decimal currencies (dinar)
  final int subunitRatio;

  /// Whether symbol appears before or after the amount.
  final SymbolPosition symbolPosition;

  /// Character used to separate thousands (e.g., "," or ".").
  final String groupSeparator;

  /// Character used for decimal point (e.g., "." or ",").
  final String decimalSeparator;

  /// Whether this currency is supported by the Frankfurter API.
  final bool isFrankfurterSupported;

  /// Converts a major unit value (e.g., 12.50) to minor units (e.g., 1250).
  int toMinorUnits(double majorUnits) {
    return (majorUnits * subunitRatio).round();
  }

  /// Converts minor units (e.g., 1250) to major units (e.g., 12.50).
  double toMajorUnits(int minorUnits) {
    return minorUnits / subunitRatio;
  }
}

/// Position of currency symbol relative to amount.
enum SymbolPosition {
  before, // $100
  after,  // 100€
}

/// Supported currencies in the app.
///
/// When adding new currencies, also add their metadata to [currencyInfo].
enum AppCurrency {
  // Frankfurter Supported (30)
  aud, brl, cad, chf, cny, czk, dkk, eur, gbp, hkd,
  huf, idr, ils, inr, isk, jpy, krw, mxn, myr, nok,
  nzd, php, pln, ron, sek, sgd, thb, try_, usd, zar,

  // Additional Global Currencies
  aed, afn, all, amd, ang, aoa, ars, awg, azn, bam,
  bbd, bdt, bgn, bhd, bif, bmd, bnd, bob, bsd, btn,
  bwp, byn, bzd, cdf, clp, cop, crc, cup, cve, djf,
  dop, dzd, egp, ern, etb, fjd, fkp, gel, ghs, gip,
  gmd, gnf, gtq, gyd, hnl, htg, iqd, irr, jmd, jod,
  kes, kgs, khr, kmf, kpw, kwd, kyd, kzt, lak, lbp,
  lkr, lrd, lsl, lyd, mad, mdl, mga, mkd, mmk, mnt,
  mop, mru, mur, mvr, mwk, mzn, nad, ngn, nio, npr,
  omr, pab, pen, pgk, pkr, pyg, qar, rsd, rub, rwf,
  sar, sbd, scr, sdg, shp, sll, sos, srd, ssp, stn,
  syp, szl, tjs, tmt, tnd, top, ttd, twd, tzs, uah,
  ugx, uyu, uzs, ves, vnd, vuv, wst, xaf, xcd, xof,
  xpf, yer, zmw,
}

/// Currency metadata lookup.
const Map<AppCurrency, CurrencyInfo> currencyInfo = {
  // Frankfurter Supported (30)
  AppCurrency.aud: CurrencyInfo(code: 'AUD', symbol: r'A$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.brl: CurrencyInfo(code: 'BRL', symbol: r'R$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.cad: CurrencyInfo(code: 'CAD', symbol: r'C$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.chf: CurrencyInfo(code: 'CHF', symbol: 'CHF', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.cny: CurrencyInfo(code: 'CNY', symbol: '¥', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.czk: CurrencyInfo(code: 'CZK', symbol: 'Kč', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.dkk: CurrencyInfo(code: 'DKK', symbol: 'kr', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.eur: CurrencyInfo(code: 'EUR', symbol: '€', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.gbp: CurrencyInfo(code: 'GBP', symbol: '£', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.hkd: CurrencyInfo(code: 'HKD', symbol: r'HK$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.huf: CurrencyInfo(code: 'HUF', symbol: 'Ft', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.idr: CurrencyInfo(code: 'IDR', symbol: 'Rp', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.ils: CurrencyInfo(code: 'ILS', symbol: '₪', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.inr: CurrencyInfo(code: 'INR', symbol: '₹', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.isk: CurrencyInfo(code: 'ISK', symbol: 'Íkr', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.jpy: CurrencyInfo(code: 'JPY', symbol: '¥', decimalDigits: 0, subunitRatio: 1, isFrankfurterSupported: true),
  AppCurrency.krw: CurrencyInfo(code: 'KRW', symbol: '₩', decimalDigits: 0, subunitRatio: 1, isFrankfurterSupported: true),
  AppCurrency.mxn: CurrencyInfo(code: 'MXN', symbol: r'Mex$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.myr: CurrencyInfo(code: 'MYR', symbol: 'RM', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.nok: CurrencyInfo(code: 'NOK', symbol: 'kr', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.nzd: CurrencyInfo(code: 'NZD', symbol: r'NZ$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.php: CurrencyInfo(code: 'PHP', symbol: '₱', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.pln: CurrencyInfo(code: 'PLN', symbol: 'zł', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.ron: CurrencyInfo(code: 'RON', symbol: 'L', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.sek: CurrencyInfo(code: 'SEK', symbol: 'kr', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.sgd: CurrencyInfo(code: 'SGD', symbol: r'S$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.thb: CurrencyInfo(code: 'THB', symbol: '฿', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.try_: CurrencyInfo(code: 'TRY', symbol: '₺', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.usd: CurrencyInfo(code: 'USD', symbol: r'$', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),
  AppCurrency.zar: CurrencyInfo(code: 'ZAR', symbol: 'R', decimalDigits: 2, subunitRatio: 100, isFrankfurterSupported: true),

  // Additional Global Currencies (Selection)
  AppCurrency.aed: CurrencyInfo(code: 'AED', symbol: 'د.إ', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.afn: CurrencyInfo(code: 'AFN', symbol: '؋', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.all: CurrencyInfo(code: 'ALL', symbol: 'L', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.amd: CurrencyInfo(code: 'AMD', symbol: '֏', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ang: CurrencyInfo(code: 'ANG', symbol: 'ƒ', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.aoa: CurrencyInfo(code: 'AOA', symbol: 'Kz', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ars: CurrencyInfo(code: 'ARS', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.awg: CurrencyInfo(code: 'AWG', symbol: 'ƒ', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.azn: CurrencyInfo(code: 'AZN', symbol: '₼', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bam: CurrencyInfo(code: 'BAM', symbol: 'KM', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bbd: CurrencyInfo(code: 'BBD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bdt: CurrencyInfo(code: 'BDT', symbol: '৳', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bgn: CurrencyInfo(code: 'BGN', symbol: 'лв', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bhd: CurrencyInfo(code: 'BHD', symbol: '.د.ب', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.bif: CurrencyInfo(code: 'BIF', symbol: 'FBu', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.bmd: CurrencyInfo(code: 'BMD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bnd: CurrencyInfo(code: 'BND', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bob: CurrencyInfo(code: 'BOB', symbol: 'Bs.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bsd: CurrencyInfo(code: 'BSD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.btn: CurrencyInfo(code: 'BTN', symbol: 'Nu.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bwp: CurrencyInfo(code: 'BWP', symbol: 'P', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.byn: CurrencyInfo(code: 'BYN', symbol: 'Br', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.bzd: CurrencyInfo(code: 'BZD', symbol: r'BZ$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.cdf: CurrencyInfo(code: 'CDF', symbol: 'FC', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.clp: CurrencyInfo(code: 'CLP', symbol: r'$', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.cop: CurrencyInfo(code: 'COP', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.crc: CurrencyInfo(code: 'CRC', symbol: '₡', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.cup: CurrencyInfo(code: 'CUP', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.cve: CurrencyInfo(code: 'CVE', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.djf: CurrencyInfo(code: 'DJF', symbol: 'Fdj', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.dop: CurrencyInfo(code: 'DOP', symbol: r'RD$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.dzd: CurrencyInfo(code: 'DZD', symbol: 'د.ج', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.egp: CurrencyInfo(code: 'EGP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ern: CurrencyInfo(code: 'ERN', symbol: 'Nfk', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.etb: CurrencyInfo(code: 'ETB', symbol: 'Br', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.fjd: CurrencyInfo(code: 'FJD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.fkp: CurrencyInfo(code: 'FKP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.gel: CurrencyInfo(code: 'GEL', symbol: '₾', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ghs: CurrencyInfo(code: 'GHS', symbol: '₵', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.gip: CurrencyInfo(code: 'GIP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.gmd: CurrencyInfo(code: 'GMD', symbol: 'D', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.gnf: CurrencyInfo(code: 'GNF', symbol: 'FG', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.gtq: CurrencyInfo(code: 'GTQ', symbol: 'Q', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.gyd: CurrencyInfo(code: 'GYD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.hnl: CurrencyInfo(code: 'HNL', symbol: 'L', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.htg: CurrencyInfo(code: 'HTG', symbol: 'G', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.iqd: CurrencyInfo(code: 'IQD', symbol: 'ع.د', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.irr: CurrencyInfo(code: 'IRR', symbol: '﷼', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.jmd: CurrencyInfo(code: 'JMD', symbol: r'J$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.jod: CurrencyInfo(code: 'JOD', symbol: 'د.ا', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.kes: CurrencyInfo(code: 'KES', symbol: 'KSh', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.kgs: CurrencyInfo(code: 'KGS', symbol: 'с', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.khr: CurrencyInfo(code: 'KHR', symbol: '៛', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.kmf: CurrencyInfo(code: 'KMF', symbol: 'CF', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.kpw: CurrencyInfo(code: 'KPW', symbol: '₩', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.kwd: CurrencyInfo(code: 'KWD', symbol: 'د.ك', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.kyd: CurrencyInfo(code: 'KYD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.kzt: CurrencyInfo(code: 'KZT', symbol: '₸', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lak: CurrencyInfo(code: 'LAK', symbol: '₭', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lbp: CurrencyInfo(code: 'LBP', symbol: 'ل.ل', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lkr: CurrencyInfo(code: 'LKR', symbol: 'Rs', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lrd: CurrencyInfo(code: 'LRD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lsl: CurrencyInfo(code: 'LSL', symbol: 'L', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.lyd: CurrencyInfo(code: 'LYD', symbol: 'ل.د', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.mad: CurrencyInfo(code: 'MAD', symbol: 'د.م.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mdl: CurrencyInfo(code: 'MDL', symbol: 'L', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mga: CurrencyInfo(code: 'MGA', symbol: 'Ar', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mkd: CurrencyInfo(code: 'MKD', symbol: 'ден', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mmk: CurrencyInfo(code: 'MMK', symbol: 'K', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mnt: CurrencyInfo(code: 'MNT', symbol: '₮', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mop: CurrencyInfo(code: 'MOP', symbol: r'P', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mru: CurrencyInfo(code: 'MRU', symbol: 'UM', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mur: CurrencyInfo(code: 'MUR', symbol: 'Rs', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mvr: CurrencyInfo(code: 'MVR', symbol: 'Rf', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mwk: CurrencyInfo(code: 'MWK', symbol: 'MK', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.mzn: CurrencyInfo(code: 'MZN', symbol: 'MT', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.nad: CurrencyInfo(code: 'NAD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ngn: CurrencyInfo(code: 'NGN', symbol: '₦', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.nio: CurrencyInfo(code: 'NIO', symbol: r'C$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.npr: CurrencyInfo(code: 'NPR', symbol: 'Rs', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.omr: CurrencyInfo(code: 'OMR', symbol: '﷼', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.pab: CurrencyInfo(code: 'PAB', symbol: 'B/.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.pen: CurrencyInfo(code: 'PEN', symbol: 'S/.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.pgk: CurrencyInfo(code: 'PGK', symbol: 'K', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.pkr: CurrencyInfo(code: 'PKR', symbol: 'Rs', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.pyg: CurrencyInfo(code: 'PYG', symbol: '₲', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.qar: CurrencyInfo(code: 'QAR', symbol: '﷼', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.rsd: CurrencyInfo(code: 'RSD', symbol: 'дин.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.rub: CurrencyInfo(code: 'RUB', symbol: '₽', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.rwf: CurrencyInfo(code: 'RWF', symbol: 'FRw', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.sar: CurrencyInfo(code: 'SAR', symbol: '﷼', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.sbd: CurrencyInfo(code: 'SBD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.scr: CurrencyInfo(code: 'SCR', symbol: 'Rs', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.sdg: CurrencyInfo(code: 'SDG', symbol: 'ج.س.', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.shp: CurrencyInfo(code: 'SHP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.sll: CurrencyInfo(code: 'SLL', symbol: 'Le', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.sos: CurrencyInfo(code: 'SOS', symbol: 'Sh', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.srd: CurrencyInfo(code: 'SRD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ssp: CurrencyInfo(code: 'SSP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.stn: CurrencyInfo(code: 'STN', symbol: 'Db', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.syp: CurrencyInfo(code: 'SYP', symbol: '£', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.szl: CurrencyInfo(code: 'SZL', symbol: 'L', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.tjs: CurrencyInfo(code: 'TJS', symbol: 'SM', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.tmt: CurrencyInfo(code: 'TMT', symbol: 'T', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.tnd: CurrencyInfo(code: 'TND', symbol: 'د.ت', decimalDigits: 3, subunitRatio: 1000),
  AppCurrency.top: CurrencyInfo(code: 'TOP', symbol: r'T$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ttd: CurrencyInfo(code: 'TTD', symbol: r'TT$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.twd: CurrencyInfo(code: 'TWD', symbol: r'NT$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.tzs: CurrencyInfo(code: 'TZS', symbol: 'TSh', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.uah: CurrencyInfo(code: 'UAH', symbol: '₴', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ugx: CurrencyInfo(code: 'UGX', symbol: 'USh', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.uyu: CurrencyInfo(code: 'UYU', symbol: r'$U', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.uzs: CurrencyInfo(code: 'UZS', symbol: 'лв', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.ves: CurrencyInfo(code: 'VES', symbol: 'Bs.S', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.vnd: CurrencyInfo(code: 'VND', symbol: '₫', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.vuv: CurrencyInfo(code: 'VUV', symbol: 'Vt', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.wst: CurrencyInfo(code: 'WST', symbol: r'WS$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.xaf: CurrencyInfo(code: 'XAF', symbol: 'FCFA', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.xcd: CurrencyInfo(code: 'XCD', symbol: r'$', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.xof: CurrencyInfo(code: 'XOF', symbol: 'CFA', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.xpf: CurrencyInfo(code: 'XPF', symbol: '₣', decimalDigits: 0, subunitRatio: 1),
  AppCurrency.yer: CurrencyInfo(code: 'YER', symbol: '﷼', decimalDigits: 2, subunitRatio: 100),
  AppCurrency.zmw: CurrencyInfo(code: 'ZMW', symbol: 'ZK', decimalDigits: 2, subunitRatio: 100),
};

/// Gets the [CurrencyInfo] for a currency, with fallback to USD.
CurrencyInfo getCurrencyInfo(AppCurrency currency) {
  return currencyInfo[currency] ?? currencyInfo[AppCurrency.usd]!;
}

String currencyLabel(AppCurrency currency) {
  final info = getCurrencyInfo(currency);
  return '${info.code} (${info.symbol})';
}

String currencySymbol(AppCurrency currency) {
  return getCurrencyInfo(currency).symbol;
}

/// Returns the number of decimal digits for a currency.
int currencyDecimalDigits(AppCurrency currency) {
  return getCurrencyInfo(currency).decimalDigits;
}

/// Returns the subunit ratio for a currency (e.g., 100 for cents).
int currencySubunitRatio(AppCurrency currency) {
  return getCurrencyInfo(currency).subunitRatio;
}

String encodeCurrency(AppCurrency currency) => currency.name;

AppCurrency? decodeCurrency(String? raw) {
  if (raw == null) return null;
  try {
    return AppCurrency.values.firstWhere((e) => e.name == raw);
  } catch (_) {
    return null;
  }
}
