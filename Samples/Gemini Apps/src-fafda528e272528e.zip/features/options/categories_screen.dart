import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n.categories),
          bottom: TabBar(
            tabs: [
              Tab(text: l10n.expenses),
              Tab(text: l10n.income),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _CategoryList(isIncome: false),
            _CategoryList(isIncome: true),
          ],
        ),
      ),
    );
  }
}

class _CategoryList extends StatefulWidget {
  final bool isIncome;

  const _CategoryList({required this.isIncome});

  @override
  State<_CategoryList> createState() => _CategoryListState();
}

class _CategoryListState extends State<_CategoryList> {
  final TextEditingController _addController = TextEditingController();

  @override
  void dispose() {
    _addController.dispose();
    super.dispose();
  }

  void _showAddDialog() {
    final l10n = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(widget.isIncome ? 'Add Income Category' : 'Add Expense Category'),
        content: TextField(
          controller: _addController,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Category name',
          ),
          onSubmitted: (_) => _handleAdd(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: _handleAdd,
            child: Text(l10n.add),
          ),
        ],
      ),
    );
  }

  void _handleAdd() {
    final name = _addController.text.trim();
    if (name.isNotEmpty) {
      ExpenseStoreScope.read(context).addCustomCategory(name, isIncome: widget.isIncome);
      _addController.clear();
      Navigator.pop(context);
    }
  }

  void _showRenameDialog(String oldName) {
    final controller = TextEditingController(text: oldName);
    final l10n = AppLocalizations.of(context)!;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Category'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'New category name',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () {
              final newName = controller.text.trim();
              if (newName.isNotEmpty && newName != oldName) {
                ExpenseStoreScope.read(context).renameCustomCategory(
                  oldName,
                  newName,
                  isIncome: widget.isIncome,
                );
              }
              Navigator.pop(context);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;
    
    final customCategories = widget.isIncome 
        ? store.currentAccount.customIncomeCategories 
        : store.currentAccount.customExpenseCategories;
    
    final defaultCategories = widget.isIncome ? incomeCategories : expenseCategories;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Custom Categories',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
            IconButton(
              onPressed: _showAddDialog,
              icon: const Icon(Icons.add_circle_outline),
              tooltip: 'Add Category',
            ),
          ],
        ),
        if (customCategories.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Center(
              child: Text(
                'No custom categories added yet.',
                style: TextStyle(color: colorScheme.onSurfaceVariant, fontStyle: FontStyle.italic),
              ),
            ),
          )
        else
          Card(
            margin: const EdgeInsets.only(top: 8, bottom: 24),
            child: Column(
              children: customCategories.map((cat) => ListTile(
                title: Text(cat),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit_outlined, size: 20),
                      onPressed: () => _showRenameDialog(cat),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, size: 20),
                      color: colorScheme.error,
                      onPressed: () {
                        ExpenseStoreScope.read(context).removeCustomCategory(cat, isIncome: widget.isIncome);
                      },
                    ),
                  ],
                ),
              )).toList(),
            ),
          ),
        
        Text(
          'Default Categories',
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: defaultCategories.map((cat) => Chip(
            label: Text(cat, style: const TextStyle(fontSize: 12)),
            backgroundColor: colorScheme.surfaceContainerHighest.withOpacity(0.5),
            side: BorderSide.none,
          )).toList(),
        ),
      ],
    );
  }
}
