import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/payment_display.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/gradient_card.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/display_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/money_pots_section.dart';
import 'package:expense_stalker_mobile/src/features/planner/envelope_quick_spend_sheet.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';

class MonthCard extends StatelessWidget {
  const MonthCard({super.key,
    required this.month,
    required this.items,
    required this.payments,
    required this.recentlyClearedItemIds,
    required this.swipeLeft,
    required this.swipeRight,
    required this.settings,
    required this.showCleared,
    required this.sortOrder,
    required this.dateSortMode,
    required this.displayMode,
    this.precomputedStartBalanceCents,
  });

  final DateTime month;
  final List<PlannerItem> items;
  final List<PaymentEntry> payments;
  final Set<String> recentlyClearedItemIds;
  final PlannerSwipeAction swipeLeft;
  final PlannerSwipeAction swipeRight;
  final AppSettingsStore settings;
  final bool showCleared;
  final PlannerSortOrder sortOrder;
  final PlannerDateSortMode dateSortMode;
  final PaymentDisplayMode displayMode;
  /// If provided, this balance is used instead of computing it internally.
  /// This allows the parent to pre-compute balances with correct cleared state.
  final int? precomputedStartBalanceCents;

  @override
  Widget build(BuildContext context) {
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );

    final scheduledItems = items
        .where((item) => item.shouldAppearInMonth(month))
        .toList(growable: false);
    final unclearedItems = <PlannerItem>[];
    final filteredItems = <PlannerItem>[];
    for (final item in scheduledItems) {
      final isCleared = _clearedDateFor(item) != null;
      if (!isCleared) {
        unclearedItems.add(item);
      }
      if (showCleared || !isCleared || recentlyClearedItemIds.contains(item.id) || item.type == PaymentType.spendingEnvelope) {
        filteredItems.add(item);
      }
    }

    final visibleItems = orderedPlannerItems(
      filteredItems,
      sortOrder,
      dateSortMode: dateSortMode,
      viewMode: settings.viewPeriodMode,
      periodInfo: periodInfo,
      actualDateProvider: _clearedDateFor,
    );
    final allCredits = scheduledItems
        .where((p) => p.type.isIncomeType)
        .fold<int>(0, (sum, p) => sum + p.amountMinorUnits);
    final allDebitsValue = -scheduledItems
        .where((p) => !p.type.isIncomeType)
        .fold<int>(0, (sum, p) => sum + p.amountMinorUnits.abs());
    
    final unclearedCredits = unclearedItems
        .where((p) => p.type.isIncomeType)
        .fold<int>(0, (sum, p) => sum + p.amountMinorUnits);

    final unclearedDebitsValue = -unclearedItems
        .where((p) => !p.type.isIncomeType)
        .fold<int>(0, (sum, p) => sum + p.amountMinorUnits.abs());

    final monthOnlyValue = monthOnly(month);
    final nowMonthOnly = monthOnly(DateTime.now());

    // Determine if this card represents the current period
    // In paycheck mode, compare against the current paycheck period's reference month
    // In calendar mode, compare against the current calendar month
    final DateTime currentPeriodMonth;
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        DateTime.now(),
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
    } else {
      currentPeriodMonth = nowMonthOnly;
    }

    final isMatchedPeriod = monthOnlyValue.year == currentPeriodMonth.year &&
        monthOnlyValue.month == currentPeriodMonth.month;
    // Also consider it the "current period" if it matches the actual calendar month,
    // ensuring we show the live balance + uncleared items for the month the user is actually in,
    // even if Paycheck Mode considers the "Accounting Period" to be next/prev month.
    final isCurrentPeriod = isMatchedPeriod || (monthOnlyValue.year == nowMonthOnly.year && monthOnlyValue.month == nowMonthOnly.month);
    
    final isPast = monthOnlyValue.isBefore(currentPeriodMonth) && !isCurrentPeriod;
    final isFutureMonth = monthOnlyValue.isAfter(currentPeriodMonth) && !isCurrentPeriod;

    // For the current period, show the raw manual balance (source of truth).
    // For future months, use precomputed balance if available, otherwise calculate.
    // Note: Zero baseline mode only applies to future months, not the current period.
    final int? startBalanceCents;
    if (isCurrentPeriod) {
      startBalanceCents = settings.currentBalanceCents;
    } else if (precomputedStartBalanceCents != null) {
      // Use precomputed balance from parent (accounts for correct cleared state)
      startBalanceCents = settings.plannerUseZeroBaseline ? 0 : precomputedStartBalanceCents;
    } else {
      // Fallback: compute internally (may not have correct cleared state for current period)
      startBalanceCents = startBalanceCentsForMonth(
        month: month,
        currentBalanceCents: settings.currentBalanceCents,
        useZeroBaseline: settings.plannerUseZeroBaseline,
        plannedTotalForMonth: _plannedTotalForMonth,
        currentPeriodMonth: currentPeriodMonth,
      );
    }
    final showClearedRow =
        settings.monthTotalsDisplayMode == MonthTotalsDisplayMode.showClearedRow;
    // Use custom colors from settings
    final creditColor = settings.creditColor;
    final debitColor = settings.debitColor;

    // Calculate Projected End-of-Month Balance
    // Note: startBalanceCents is:
    // - currentBalanceCents if isCurrentPeriod is true
    // - calculated prediction if isCurrentPeriod is false
    final int baseBalance = startBalanceCents ?? 0;
    
    // For the current period, we only consider remaining (uncleared) items
    // added to the current bank balance.
    // For future periods, we consider ALL planned items added to the
    // predicted starting balance.

    // Primary Row Values (The "Main" View)
    // For Current Period: Defaults to Uncleared (Remaining)
    // For Future: Defaults to All (Planned)
    final int primaryCredits, primaryDebits;
    if (isCurrentPeriod) {
      primaryCredits = unclearedCredits;
      primaryDebits = unclearedDebitsValue;
    } else {
      primaryCredits = allCredits;
      primaryDebits = allDebitsValue;
    }
    final primaryTotal = baseBalance + primaryCredits + primaryDebits;

    // Secondary Row Values (When "Show Cleared Row" is enabled)
    // If enabled, we want to show the breakdown.
    // Usually: Primary = Including Cleared (Gross), Secondary = Excluding Cleared (Net/Remaining).
    // BUT for current period, the "Standard" view is already Net/Remaining.
    // To match User Request: "Total all uncleared transactions with the current balance. In all cases/ always."
    // We ensure the row that displays the TOTAL (which is Secondary when 2 lines are shown) shows the Projected Balance.
    
    final int? secCredits, secDebits, secTotal;
    if (showClearedRow) {
       // If showing cleared row, let's make:
       // Primary Row (Eye) = All/Scheduled (Gross Reference) - Total Hidden
       // Secondary Row (Crossed Eye) = Uncleared (Remaining) - Total Shown = Projected Balance
       
       // Note: This overrides the isCurrentPeriod logic for the Primary Row specifically when split view is on,
       // to allow seeing the "original plan" vs "reality".
       
       // Calculate Secondary (The one with the Total)
       // For future months, use ALL values (same as primary) since nothing can be cleared yet.
       // For current period, use uncleared values to show the remaining items.
       if (isFutureMonth) {
         secCredits = allCredits;
         secDebits = allDebitsValue;
       } else {
         secCredits = unclearedCredits;
         secDebits = unclearedDebitsValue;
       }
       secTotal = baseBalance + (secCredits ?? 0) + (secDebits ?? 0); // Current Balance + Uncleared Loop
    } else {
       secCredits = null;
       secDebits = null;
       secTotal = null;
    }

    // Determine what to pass as "Primary" to the footer builder
    // If split view is ON, we force Primary to be 'All' so we see the contrast.
    // If split view is OFF, we stick to the standard logic (Uncleared for Current, All for Future).
    final int displayCredits = showClearedRow ? allCredits : primaryCredits;
    final int displayDebits = showClearedRow ? allDebitsValue : primaryDebits;
    final int displayTotal = showClearedRow ? (baseBalance + allCredits + allDebitsValue) : primaryTotal;

    // Apply rounding
    final roundingIncrement = settings.roundingIncrement;
    final showCents = settings.showCents;

    final roundedCredits = roundingIncrement > 0 ? roundUpToIncrement(displayCredits, roundingIncrement) : displayCredits;
    final roundedDebits = roundingIncrement > 0 ? roundUpToIncrement(displayDebits, roundingIncrement) : displayDebits;
    // Note: displayTotal includes baseBalance, so we round the final sum
    final roundedTotal = roundingIncrement > 0 ? roundUpToIncrement(displayTotal, roundingIncrement) : displayTotal;

    // Exact row logic (only relevant if not showing cleared row)
    final roundedDiffers = roundedTotal != displayTotal;
    final showExactRow = roundedDiffers && !showClearedRow;

    return SizedBox.expand(
      child: GradientCard(
        isPast: isPast,
        isCurrent: isCurrentPeriod,
        child: Column(
          children: [
            // Pill-style header
            _buildHeader(
              context,
              periodInfo: periodInfo,
              startBalanceCents: startBalanceCents,
              isCurrentPeriod: isCurrentPeriod,
              isFutureMonth: isFutureMonth,
              showCents: showCents,
            ),
            // Item list (grouped or flat based on settings)
            Expanded(
              child: settings.plannerGroupByTheme
                  ? _buildThemeGroupedList(context, visibleItems, isPast, isCurrentPeriod, creditColor, debitColor, periodInfo: periodInfo, showCents: showCents)
                  : (settings.plannerGroupByDate
                      ? _buildGroupedList(context, visibleItems, isPast, isCurrentPeriod, creditColor, debitColor, periodInfo: periodInfo, showCents: showCents)
                      : _buildFlatList(context, visibleItems, isPast, isCurrentPeriod, creditColor, debitColor, showCents: showCents)),
            ),
            MoneyPotsSection(settings: settings, month: month, items: items),
            // Footer with credits/debits/total (Total = Projected Balance)
            _buildFooter(
              context,
              roundedCredits,
              roundedDebits,
              roundedTotal,
              creditColor,
              debitColor,
              showClearedRow: showClearedRow,
              startBalanceCents: startBalanceCents,
              secondaryCredits: showClearedRow ? (roundingIncrement > 0 ? roundUpToIncrement(secCredits!, roundingIncrement) : secCredits) : (showExactRow ? displayCredits : null),
              secondaryDebits: showClearedRow ? (roundingIncrement > 0 ? roundUpToIncrement(secDebits!, roundingIncrement) : secDebits) : (showExactRow ? displayDebits : null),
              secondaryTotal: showClearedRow ? (roundingIncrement > 0 ? roundUpToIncrement(secTotal!, roundingIncrement) : secTotal) : (showExactRow ? displayTotal : null),
              showCents: showCents,
              isExactRow: showExactRow,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context, {
    required PeriodInfo periodInfo,
    required int? startBalanceCents,
    required bool isCurrentPeriod,
    required bool isFutureMonth,
    required bool showCents,
  }) {
    final headerStyle = Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
          fontFeatures: const [FontFeature.tabularFigures()],
          color: Theme.of(context).colorScheme.onSurface,
        );

    return PillHeader(
      label: periodInfo.label,
      badge: isCurrentPeriod
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
                  width: 0.5,
                ),
              ),
              child: Text(
                'CURRENT',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                      fontSize: 9,
                    ),
              ),
            )
          : null,
      trailing: startBalanceCents != null
          ? Text(
              formatMoneyFromCents(startBalanceCents, settings.currencySettings.currency, showCents: showCents),
              style: headerStyle,
            )
          : null,
      onTrailingTap: startBalanceCents != null
          ? () {
              if (isCurrentPeriod) {
                showBalanceActions(context, settings);
              } else if (isFutureMonth) {
                settings.plannerUseZeroBaseline = !settings.plannerUseZeroBaseline;
              }
            }
          : null,
    );
  }

  Widget _buildFlatList(
    BuildContext context,
    List<PlannerItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required bool showCents,
  }) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingNormal,
        AppConstants.paddingSmall,
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
      ),
      itemCount: visibleItems.length,
      separatorBuilder: (_, __) => Divider(
        height: 1,
        color: Theme.of(context).dividerColor,
      ),
      itemBuilder: (context, index) {
        final item = visibleItems[index];
        return _buildItemTile(context, item, isPast, isCurrentPeriod, creditColor, debitColor, showDatePrefix: true, showCents: showCents);
      },
    );
  }

  Widget _buildGroupedList(
    BuildContext context,
    List<PlannerItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
  }) {
    // Group items by day
    final groups = <int, List<PlannerItem>>{};
    for (final item in visibleItems) {
      final clearedDate = _clearedDateFor(item);
      final day = clearedDate?.day ?? effectiveDayOfMonth(item.dayOfMonth, month);
      (groups[day] ??= []).add(item);
    }

    // Sort groups by day
    final sortedDays = groups.keys.toList()
      ..sort((a, b) {
        final cmp = daySortValue(
          a,
          viewMode: settings.viewPeriodMode,
          periodInfo: periodInfo,
        ).compareTo(
          daySortValue(
            b,
            viewMode: settings.viewPeriodMode,
            periodInfo: periodInfo,
          ),
        );
        return sortOrder == PlannerSortOrder.chronological ? cmp : -cmp;
      });


    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontWeight: FontWeight.w600,
        );

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
      ),
      itemCount: sortedDays.length,
      itemBuilder: (context, groupIndex) {
        final day = sortedDays[groupIndex];
        final groupItems = groups[day]!;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date group header
            Padding(
              padding: const EdgeInsets.fromLTRB(
                0,
                AppConstants.paddingSmall,
                0,
                AppConstants.paddingXSmall,
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppConstants.paddingSmall,
                      vertical: AppConstants.paddingXSmall / 2, // 2
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                    ),
                    child: Text(
                      formatDayOfMonth(day, settings.dayFormat),
                      style: groupHeaderStyle,
                    ),
                  ),
                  const SizedBox(width: AppConstants.paddingSmall),
                  Expanded(
                    child: Divider(
                      height: 1,
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                ],
              ),
            ),
            // Items in this group
            ...groupItems.map((item) => _buildItemTile(
                  context, item, isPast, isCurrentPeriod, creditColor, debitColor,
                  showDatePrefix: false, showCents: showCents,
                )),
          ],
        );
      },
    );
  }

  Widget _buildItemTile(
    BuildContext context,
    PlannerItem item,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required bool showDatePrefix,
    required bool showCents,
  }) {
    final clearedDate = _clearedDateFor(item);
    final payment = _paymentFor(item);
    final displayValues = getDisplayValues(
      item: item,
      month: month,
      payment: payment,
    );
    final displayDay = displayValues.date.day;
    final displayAmount = displayValues.amountMinorUnits;
    final datePrefix = showDatePrefix ? '${formatDayOfMonth(displayDay, settings.dayFormat)} · ' : '';
    // Only allow marking paid/unpaid for the current month/period, not future months
    final canArchive = isCurrentPeriod;
    Offset? lastPointerPosition;

    Offset menuSource() {
      if (lastPointerPosition != null) return lastPointerPosition!;
      final box = context.findRenderObject() as RenderBox?;
      if (box != null) {
        final center = box.size.center(Offset.zero);
        return box.localToGlobal(center);
      }
      return Offset.zero;
    }

    Future<void> openMenu() async {
      await showPlannerItemMenu(
        context: context,
        item: item,
        month: month,
        position: menuSource(),
        canArchive: canArchive,
      );
    }

    final isCleared = clearedDate != null;
    final amountColor = item.type.isIncomeType ? creditColor : debitColor;

    // Grey out cleared items or past items
    final isMuted = isPast || (isCleared && isCurrentPeriod);
    final mutedTextColor = Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.4);
    final mutedAmountColor = amountColor.withValues(alpha: 0.4);

    final tile = Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (event) => lastPointerPosition = event.position,
      child: ListTile(
        dense: true,
        visualDensity: const VisualDensity(vertical: -4),
        contentPadding: EdgeInsets.zero,
        onTap: () async {
          // Spending envelopes: show quick-spend sheet instead of archive flow
          if (item.type == PaymentType.spendingEnvelope) {
            final store = ExpenseStoreScope.read(context);
            await showModalBottomSheet(
              context: context,
              backgroundColor: Colors.transparent,
              builder: (ctx) => EnvelopeQuickSpendSheet(
                envelope: item,
                store: store,
                month: month,
              ),
            );
            return;
          }
          
          final wantsMenuOnTap = settings.plannerTapAction == PlannerTapAction.menu;
          if (wantsMenuOnTap || !canArchive || isCleared) {
            await openMenu();
          } else {
            await handleSwipeAction(context, item, PlannerSwipeAction.archive);
          }
        },
        onLongPress: () async {
          // Spending envelopes: long-press always shows menu for editing
          if (item.type == PaymentType.spendingEnvelope) {
            await openMenu();
            return;
          }
          
          final wantsMenuOnTap = settings.plannerTapAction == PlannerTapAction.menu;
          if (wantsMenuOnTap && canArchive) {
            // Long press archives when tap shows menu
            await handleSwipeAction(context, item, PlannerSwipeAction.archive);
          } else {
            // Long press shows menu when tap archives (or when can't archive)
            await openMenu();
          }
        },
        title: _buildItemTitle(
          context,
          item: item,
          datePrefix: datePrefix,
          isCleared: isCleared,
          isCurrentPeriod: isCurrentPeriod,
          isPast: isPast,
          clearedTextColor: mutedTextColor,
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Only show checkmark for cleared items in the current period
            if (isCleared && (isCurrentPeriod || isPast)) ...[
              Icon(
                Icons.check_circle,
                size: 14,
                color: mutedTextColor,
              ),
              const SizedBox(width: AppConstants.paddingSmall - 2), // 6
            ],
            // Date variance indicator
            if (displayValues.hasDateVariance && isCleared && displayValues.scheduledDate != null) ...[
              Tooltip(
                message: AppLocalizations.of(context)!.dueDatePaidDate(
                  displayValues.scheduledDate!.day,
                  displayValues.date.day,
                ),
                child: Icon(
                  Icons.schedule,
                  size: 12,
                  color: Colors.orange.withValues(alpha: 0.7),
                ),
              ),
              const SizedBox(width: AppConstants.paddingXSmall),
            ],
            if (displayValues.hasAmountVariance && isCleared && displayValues.scheduledAmountMinorUnits != null) ...[
              Text(
                formatMoneyFromCents(displayValues.scheduledAmountMinorUnits!, settings.currency, showCents: showCents),
                style: TextStyle(
                  fontSize: 10,
                  fontFeatures: const [FontFeature.tabularFigures()],
                  color: mutedAmountColor,
                  decoration: TextDecoration.lineThrough,
                ),
              ),
              const SizedBox(width: 4),
            ],
            // Spending envelope: show "spent / target" format
            if (item.type == PaymentType.spendingEnvelope) ...[
              Builder(builder: (context) {
                final period = SpendingEnvelopeService.getEnvelopePeriodDates(item, month);
                final spent = SpendingEnvelopeService.getSpentAmountForPeriod(item, payments, period);
                final target = item.amountMinorUnits.abs();
                final progress = target > 0 ? spent / target : 0.0;
                final isOverBudget = progress > 1.0;
                final progressColor = isOverBudget 
                    ? Theme.of(context).colorScheme.error
                    : (progress > 0.8 
                        ? Colors.orange 
                        : debitColor);
                
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Small progress indicator
                    Container(
                      width: 4,
                      height: 16,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        color: Theme.of(context).colorScheme.surfaceContainerHighest,
                      ),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: FractionallySizedBox(
                          heightFactor: progress.clamp(0.0, 1.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(2),
                              color: progressColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '${formatMoneyFromCents(-spent, settings.currencySettings.currency, showCents: showCents)} / ${formatMoneyFromCents(item.amountMinorUnits, settings.currencySettings.currency, showCents: showCents)}',
                      style: TextStyle(
                        fontFeatures: const [FontFeature.tabularFigures()],
                        fontSize: 12,
                        color: isMuted ? mutedAmountColor : progressColor,
                      ),
                    ),
                  ],
                );
              }),
            ] else ...[
              // Standard amount display for non-envelope items
              Text(
                formatMoneyFromCents(displayAmount, settings.currencySettings.currency, showCents: showCents),
                style: TextStyle(
                  fontFeatures: const [FontFeature.tabularFigures()],
                  // Only grey out cleared items in the current period OR past month
                  color: isMuted ? mutedAmountColor : amountColor,
                ),
              ),
            ],
          ],
        ),
      ),
    );

    // Disable swipe actions for:
    // - Past and future months (only current period can toggle paid status)
    // - Spending envelopes (they use quick-spend flow, not archive)
    final isEnvelope = item.type == PaymentType.spendingEnvelope;
    final direction = (!isCurrentPeriod || isEnvelope) ? null : dismissDirection(
      left: swipeLeft,
      right: swipeRight,
    );
    if (direction == null) return tile;

    final isRecorded = clearedDate != null;

    return Dismissible(
      key: ValueKey(item.id),
      direction: direction,
      background: dismissBackground(
        context,
        action: swipeRight,
        alignLeft: true,
        isRecorded: isRecorded,
      ),
      secondaryBackground: dismissBackground(
        context,
        action: swipeLeft,
        alignLeft: false,
        isRecorded: isRecorded,
      ),
      confirmDismiss: (dismissDirection) async {
        final action = dismissDirection == DismissDirection.endToStart
            ? swipeLeft
            : swipeRight;
        return handleSwipeAction(context, item, action);
      },
      child: tile,
    );
  }

  Widget _buildItemTitle(
    BuildContext context, {
    required PlannerItem item,
    required String datePrefix,
    required bool isCleared,
    required bool isCurrentPeriod,
    required bool isPast,
    required Color clearedTextColor,
  }) {
    final textColor = (isCleared && (isCurrentPeriod || isPast)) ? clearedTextColor : (isPast ? clearedTextColor : null);

    // Build the label with optional company suffix
    String buildDisplayLabel(String baseLabel) {
      if (settings.plannerShowPaymentOrigin && item.company != null && item.company!.isNotEmpty) {
        return '$baseLabel (${item.company})';
      }
      return baseLabel;
    }

    // For full display mode or automatic (which defaults to full for month view)
    if (displayMode == PaymentDisplayMode.full || displayMode == PaymentDisplayMode.automatic) {
      return Text(
        '$datePrefix${buildDisplayLabel(item.label)}',
        style: textColor != null ? TextStyle(color: textColor) : null,
      );
    }

    // For icon mode
    if (displayMode == PaymentDisplayMode.icon) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (datePrefix.isNotEmpty)
            Text(
              datePrefix,
              style: textColor != null ? TextStyle(color: textColor) : null,
            ),
          Icon(
            getPaymentIcon(item.label, type: item.type),
            size: 18,
            color: (isCleared && isCurrentPeriod)
                ? clearedTextColor
                : Theme.of(context).colorScheme.onSurface,
          ),
        ],
      );
    }

    // For acronym mode
    return Text(
      '$datePrefix${buildDisplayLabel(generateAcronym(item.label))}',
      style: TextStyle(
        fontWeight: FontWeight.bold,
        color: textColor,
      ),
    );
  }

  Widget _buildFooter(
    BuildContext context,
    int credits,
    int debits,
    int total,
    Color creditColor,
    Color debitColor,
    {required bool showClearedRow,
    int? startBalanceCents,
    int? secondaryCredits,
    int? secondaryDebits,
    int? secondaryTotal,
    required bool showCents,
    bool isExactRow = false}
  ) {
    final l10n = AppLocalizations.of(context)!;
    final baseTextStyle =
        (Theme.of(context).textTheme.labelMedium ?? const TextStyle(fontSize: 12))
            .copyWith(fontFeatures: const [FontFeature.tabularFigures()]);

    // Tooltip logic
    String? secondaryTooltip = l10n.monthTotalsExcludingClearedLabel;
    IconData? secondaryIcon = Icons.visibility_off;
    if (isExactRow) {
      secondaryTooltip = 'Exact total (unrounded)';
      secondaryIcon = Icons.data_usage;
    }

    // Determine if we have multiple rows (which requires aligned columns)
    final hasSecondaryRow = secondaryCredits != null &&
        secondaryDebits != null &&
        secondaryTotal != null;
    final hasLeadingIcon = showClearedRow || isExactRow || hasSecondaryRow;
    final showPrimaryTotal = !showClearedRow && !isExactRow;

    // Build table rows for proper column alignment
    Widget buildIcon(Widget? icon, String? tooltip) {
      if (icon == null) return const SizedBox(width: 16);
      return Tooltip(
        message: tooltip ?? '',
        child: IconTheme(
          data: IconThemeData(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            size: 16,
          ),
          child: icon,
        ),
      );
    }

    Widget buildCredits(int amount) => Text(
          l10n.creditsLabel(formatMoneyFromCents(amount, settings.currencySettings.currency, showCents: showCents)),
          style: TextStyle(color: creditColor),
        );

    Widget buildDebits(int amount) => Text(
          l10n.debitsLabel(formatMoneyFromCents(amount, settings.currencySettings.currency, showCents: showCents)),
          style: TextStyle(color: debitColor),
        );

    Widget buildTotal(int amount, {bool visible = true}) => visible
        ? Text(
            l10n.totalLabel(formatMoneyFromCents(amount, settings.currencySettings.currency, showCents: showCents)),
            style: TextStyle(color: amount >= 0 ? creditColor : debitColor),
          )
        : const SizedBox.shrink();

    return GradientCardFooter(
      child: DefaultTextStyle(
        style: baseTextStyle,
        child: Table(
          defaultColumnWidth: const IntrinsicColumnWidth(),
          columnWidths: const {
            0: IntrinsicColumnWidth(), // Icon column
            1: IntrinsicColumnWidth(), // Credits column
            2: IntrinsicColumnWidth(), // Debits column
            3: FlexColumnWidth(), // Spacer
            4: IntrinsicColumnWidth(), // Total column
          },
          children: [
            // Primary row (Credits/Debits/Total)
            TableRow(
              children: [
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: hasLeadingIcon
                        ? buildIcon(
                            showClearedRow
                                ? const Icon(Icons.visibility)
                                : (isExactRow ? const Icon(Icons.rounded_corner) : null),
                            showClearedRow
                                ? l10n.monthTotalsIncludingClearedLabel
                                : (isExactRow ? 'Rounded total' : null),
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: buildCredits(credits),
                  ),
                ),
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: buildDebits(debits),
                ),
                const TableCell(child: SizedBox.shrink()), // Spacer
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: buildTotal(total, visible: showPrimaryTotal),
                ),
              ],
            ),
            // Secondary row (if present)
            if (secondaryCredits != null &&
                secondaryDebits != null &&
                secondaryTotal != null)
              TableRow(
                children: [
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10, top: 6),
                      child: buildIcon(Icon(secondaryIcon), secondaryTooltip),
                    ),
                  ),
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10, top: 6),
                      child: buildCredits(secondaryCredits),
                    ),
                  ),
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: buildDebits(secondaryDebits),
                    ),
                  ),
                  const TableCell(child: SizedBox.shrink()), // Spacer
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: buildTotal(secondaryTotal),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  DateTime? _clearedDateFor(PlannerItem item) {
    PaymentEntry? best;
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    
    for (final payment in payments) {
      // Additional safety check: payment must be within THIS period
      // This prevents payments from other months being matched to this month's items
      if (payment.date.isBefore(periodInfo.start) ||
          payment.date.isAfter(periodInfo.end)) {
        continue;
      }
      
      if (!paymentMatchesPlannerItem(payment, item, month, settings)) continue;
      if (best == null || payment.date.isAfter(best.date)) best = payment;
    }
    return best?.date;
  }

  PaymentEntry? _paymentFor(PlannerItem item) {
    PaymentEntry? best;
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    
    for (final payment in payments) {
      // Additional safety check: payment must be within THIS period
      // This prevents payments from other months being matched to this month's items
      if (payment.date.isBefore(periodInfo.start) ||
          payment.date.isAfter(periodInfo.end)) {
        continue;
      }
      
      if (!paymentMatchesPlannerItem(payment, item, month, settings)) continue;
      if (best == null || payment.date.isAfter(best.date)) best = payment;
    }
    return best;
  }

  int _plannedTotalForMonth(DateTime targetMonth) {
    // For balance projection, we sum ALL items for each month.
    //
    // The balance projection formula is:
    //   Future month start = currentBalance + sum(all items from current to target-1)
    //
    // We DON'T exclude cleared items because:
    // - currentBalance already reflects cleared payments (money left the bank)
    // - Uncleared items will still be paid (money will leave the bank)
    // - So projection = currentBalance + all remaining scheduled items
    //
    // Previously this tried to exclude "cleared" items for current period,
    // but that caused issues when future cards (e.g., Feb) tried to determine
    // what's cleared in the current period (Jan) - they don't have the right
    // payment context. Simpler and correct: always include all items.
    return items
        .where((item) => item.shouldAppearInMonth(targetMonth))
        .fold<int>(0, (sum, item) => sum + item.amountMinorUnits);
  }

  Widget _buildThemeGroupedList(
    BuildContext context,
    List<PlannerItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
  }) {
    // Group items by category (Theme)
    final groups = <String, List<PlannerItem>>{};
    for (final item in visibleItems) {
      String category = item.category ?? (item.type.isIncomeType ? 'Income' : 'Expenses');
      
      // Fallback if category is empty string
      if (category.trim().isEmpty) {
        category = item.type.isIncomeType ? 'Income' : 'Expenses';
      }
      
      (groups[category] ??= []).add(item);
    }

    // Sort groups alphabetically
    final sortedCategories = groups.keys.toList()..sort();

    // Pre-sort all groups before building to avoid sorting on every frame
    final sortedGroups = <String, List<PlannerItem>>{};
    for (final category in sortedCategories) {
      final categoryItems = groups[category]!.toList(); // Make a copy
      categoryItems.sort((a, b) {
        final dateA = _clearedDateFor(a) ?? effectiveDayOfMonth(a.dayOfMonth, month);
        final dateB = _clearedDateFor(b) ?? effectiveDayOfMonth(b.dayOfMonth, month);

        // Convert to integers for comparison
        final dayA = dateA is DateTime ? dateA.day : dateA as int;
        final dayB = dateB is DateTime ? dateB.day : dateB as int;

        return dayA.compareTo(dayB);
      });
      sortedGroups[category] = categoryItems;
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
          color: isDark ? Colors.white.withValues(alpha: 0.7) : Colors.black.withValues(alpha: 0.7),
          fontWeight: FontWeight.bold,
        );
    
    final theme = Theme.of(context);
    final surfaceColor = theme.colorScheme.surfaceContainerHighest;

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      itemCount: sortedCategories.length,
      itemBuilder: (context, groupIndex) {
        final category = sortedCategories[groupIndex];
        final groupItems = sortedGroups[category]!; // Already sorted

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Category header
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: surfaceColor.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      category,
                      style: groupHeaderStyle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Divider(
                      height: 1,
                      color: theme.dividerColor.withValues(alpha: 0.5),
                    ),
                  ),
                ],
              ),
            ),
            // Items in this group (already sorted)
            ...groupItems.map((item) => _buildItemTile(
                  context, item, isPast, isCurrentPeriod, creditColor, debitColor,
                  showDatePrefix: true,
                  showCents: showCents,
                )),
          ],
        );
      },
    );
  }
}
