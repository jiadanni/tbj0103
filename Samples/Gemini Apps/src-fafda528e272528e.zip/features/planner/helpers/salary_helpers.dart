import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Checks if an item should prompt for paycheck day sync when marked as salary
bool shouldOfferPaycheckDaySync(PlannerItem item, AppSettingsStore settings) {
  // Only offer for recurring income items being marked as salary
  if (item.type != PaymentType.recurringIncome) return false;

  // Offer if paycheckDay is not set or differs from item's day
  return settings.paycheckDay == null || settings.paycheckDay != item.dayOfMonth;
}

/// Syncs the paycheckDay setting from a salary item
void syncPaycheckDayFromSalary(PlannerItem salaryItem, AppSettingsStore settings) {
  settings.paycheckDay = salaryItem.dayOfMonth;
}

/// Returns all planner items marked as salary
List<PlannerItem> getSalaryItems(List<PlannerItem> items) {
  return items.where((item) => item.isSalary).toList();
}

/// Returns the primary (first) salary item if any exist
PlannerItem? getPrimarySalaryItem(List<PlannerItem> items) {
  try {
    return getSalaryItems(items).first;
  } catch (_) {
    return null;
  }
}
