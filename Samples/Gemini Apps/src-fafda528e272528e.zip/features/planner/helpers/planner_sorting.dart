import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';


List<PlannerItem> orderedPlannerItems(
  Iterable<PlannerItem> items,
  PlannerSortOrder order, {
  PlannerDateSortMode dateSortMode = PlannerDateSortMode.scheduledDate,
  ViewPeriodMode viewMode = ViewPeriodMode.calendar,
  PeriodInfo? periodInfo,
  DateTime? Function(PlannerItem)? actualDateProvider,
}) {
  final sorted = items.toList(growable: false);
  sorted.sort((a, b) {
    int dayA = a.dayOfMonth;
    int dayB = b.dayOfMonth;

    if (dateSortMode == PlannerDateSortMode.actualDate && actualDateProvider != null) {
      final dateA = actualDateProvider(a);
      final dateB = actualDateProvider(b);
      if (dateA != null) dayA = dateA.day;
      if (dateB != null) dayB = dateB.day;
    }

    final cmp = daySortValue(
      dayA,
      viewMode: viewMode,
      periodInfo: periodInfo,
    ).compareTo(
      daySortValue(
        dayB,
        viewMode: viewMode,
        periodInfo: periodInfo,
      ),
    );
    final ordered = order == PlannerSortOrder.chronological ? cmp : -cmp;
    if (ordered != 0) return ordered;
    return a.label.compareTo(b.label);
  });
  return sorted;
}

int dayOfMonthValue(PlannerItem item) => item.dayOfMonth;

int daySortValue(
  int day, {
  required ViewPeriodMode viewMode,
  PeriodInfo? periodInfo,
}) {
  if (viewMode != ViewPeriodMode.paycheck || periodInfo == null) {
    return day;
  }

  final startDay = periodInfo.start.day;
  final daysInStartMonth = DateTime.utc(
    periodInfo.start.year,
    periodInfo.start.month + 1,
    0,
  ).day;

  if (day >= startDay) {
    return day - startDay;
  }
  return (daysInStartMonth - startDay + 1) + day;
}
