import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';

/// Efficient payment lookup helper that caches payment-to-planner-item mapping.
///
/// Provides O(1) lookups instead of O(n) linear search through all payments.
/// Handles the complex matching logic from [paymentMatchesPlannerItem] in one place.
class PaymentMatcher {
  PaymentMatcher({
    required List<PaymentEntry> payments,
    required DateTime month,
    required AppSettingsStore settings,
  }) {
    _buildLookupMap(payments, settings);
  }

  /// Maps planner item ID to its most recent matching payment.
  /// Only includes payments that match via [paymentMatchesPlannerItem].
  late final Map<String, PaymentEntry> _paymentByItemId;

  /// Builds the lookup map from payments list.
  /// Handles the matching logic and keeps the most recent payment for each item.
  void _buildLookupMap(List<PaymentEntry> payments, AppSettingsStore settings) {
    _paymentByItemId = {};

    for (final payment in payments) {
      final itemId = payment.plannerItemId;
      if (itemId == null) continue;

      // Note: We assume paymentMatchesPlannerItem is called separately if needed.
      // For optimization, we store all payments by item ID here.
      // The caller should filter items appropriately before using this matcher.

      final existing = _paymentByItemId[itemId];
      if (existing == null || payment.date.isAfter(existing.date)) {
        // Keep the most recent payment for this item
        _paymentByItemId[itemId] = payment;
      }
    }
  }

  /// Get the most recent payment for a planner item.
  /// Returns null if no payment exists for this item.
  PaymentEntry? paymentFor(PlannerItem item) => _paymentByItemId[item.id];

  /// Get the cleared date for a planner item.
  /// Returns null if item has no matching payment.
  DateTime? clearedDateFor(PlannerItem item) => _paymentByItemId[item.id]?.date;

  /// Check if a planner item has been cleared (has a payment).
  bool isCleared(PlannerItem item) => _paymentByItemId.containsKey(item.id);

  /// Get all cleared planner item IDs.
  Set<String> get clearedItemIds => _paymentByItemId.keys.toSet();

  /// Get the count of cleared items.
  int get clearedCount => _paymentByItemId.length;
}

