import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;

/// Contains information about a viewing period (calendar month or paycheck period)
class PeriodInfo {
  const PeriodInfo({
    required this.start,
    required this.end,
    required this.label,
  });

  /// The start date of the period (inclusive)
  final DateTime start;

  /// The end date of the period (inclusive)
  final DateTime end;

  /// The formatted label for display (e.g., "Jan 2025" or "Dec 25 – Jan 24")
  final String label;
}

/// Service for calculating paycheck periods and adjusting dates based on business days.
class PaycheckService {
  /// Gets period information (start, end, label) based on view mode.
  ///
  /// For calendar mode: returns the full calendar month.
  /// For paycheck mode: returns period from paycheckDay of previous month to paycheckDay-1 of referenceMonth.
  ///
  /// Example: referenceMonth = Jan 2025, paycheckDay = 25
  /// Result: start = Dec 25, 2024, end = Jan 24, 2025, label = "Dec 25 – Jan 24"
  /// The period is named by its ending month (January in this case).
  static PeriodInfo getPeriodInfo(
    DateTime referenceMonth,
    ViewPeriodMode mode,
    int? paycheckDay, {
    bool businessAdjust = true,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
  }) {
    final normalized = DateTime.utc(referenceMonth.year, referenceMonth.month);

    if (mode == ViewPeriodMode.calendar) {
      // Calendar month: 1st to last day of month
      final start = DateTime.utc(normalized.year, normalized.month, 1);
      final end = DateTime.utc(
        normalized.year,
        normalized.month + 1,
        0,
      ); // Last day of month
      return PeriodInfo(start: start, end: end, label: _monthLabel(normalized));
    }

    // Paycheck mode
    final day = paycheckDay ?? 1;

    // Calculate start date: paycheckDay of previous month
    final prevMonth = DateTime.utc(normalized.year, normalized.month - 1);
    final daysInPrevMonth = DateTime.utc(prevMonth.year, prevMonth.month + 1, 0).day;
    final startDay = day > daysInPrevMonth ? daysInPrevMonth : day;
    var start = DateTime.utc(prevMonth.year, prevMonth.month, startDay);
    start = _applyBusinessAdjust(start, businessAdjust, adjustDirection);

    // Calculate end date: day before paycheckDay of referenceMonth
    // Special case: if paycheckDay is 1, end is last day of previous month
    DateTime end;
    if (day == 1) {
      // Period ends on last day of previous month (e.g., payday 1st: Dec 1 - Dec 31)
      end = DateTime.utc(
        normalized.year,
        normalized.month,
        0,
      ); // Day 0 = last day of prev month
      end = _applyBusinessAdjust(end, businessAdjust, adjustDirection);
    } else {
      // Compute payday in reference month, apply business adjustment, then end is day before that
      final daysInCurrentMonth = DateTime.utc(
        normalized.year,
        normalized.month + 1,
        0,
      ).day;
      final paydayDay = day.clamp(1, daysInCurrentMonth);
      var payday = DateTime.utc(normalized.year, normalized.month, paydayDay);
      payday = _applyBusinessAdjust(payday, businessAdjust, adjustDirection);
      end = payday.subtract(const Duration(days: 1));
    }

    // Format label: "Dec 25 – Jan 24" or "Dec 25 '25 – Jan 24 '26" if spanning years
    final monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final startMonthName = monthNames[start.month - 1];
    final endMonthName = monthNames[end.month - 1];
    
    // Include year if the period spans different years
    final String label;
    if (start.year != end.year) {
      final startYear = start.year.toString().substring(2); // Last 2 digits
      final endYear = end.year.toString().substring(2); // Last 2 digits
      label = '$startMonthName ${start.day} \'$startYear – $endMonthName ${end.day} \'$endYear';
    } else {
      label = '$startMonthName ${start.day} – $endMonthName ${end.day}';
    }

    return PeriodInfo(start: start, end: end, label: label);
  }

  /// Returns the reference month that contains the given date in paycheck mode.
  ///
  /// In paycheck mode, a period spans from paycheckDay of one month to paycheckDay-1 of the next month.
  /// The period is named by its ending month.
  ///
  /// Example: paycheckDay = 25
  /// - Jan 15, 2025 is in period "Dec 25 – Jan 24" → reference month is Jan 2025
  /// - Jan 27, 2025 is in period "Jan 25 – Feb 24" → reference month is Feb 2025
  static DateTime getCurrentPaycheckPeriodMonth(
    DateTime date,
    int paycheckDay, {
    bool businessAdjust = true,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
  }) {
    final normalized = dateOnly(date);
    final day = paycheckDay.clamp(1, 31);

    // Calculate the payday for the current month
    final currentMonth = DateTime.utc(normalized.year, normalized.month);
    final daysInCurrentMonth = DateTime.utc(currentMonth.year, currentMonth.month + 1, 0).day;
    final paydayDay = day.clamp(1, daysInCurrentMonth);
    var currentPayday = DateTime.utc(currentMonth.year, currentMonth.month, paydayDay);
    currentPayday = _applyBusinessAdjust(currentPayday, businessAdjust, adjustDirection);

    // If we're on or after the payday, we're in the period ending next month
    if (!normalized.isBefore(currentPayday)) {
      return month_math.addMonths(currentMonth, 1);
    }

    // Otherwise, we're in the period ending this month
    return currentMonth;
  }

  static DateTime _applyBusinessAdjust(
    DateTime d,
    bool businessAdjust,
    PaycheckAdjustDirection adjustDirection,
  ) {
    if (!businessAdjust) return d;
    // If Saturday (6) or Sunday (7), move before or after
    if (d.weekday == DateTime.saturday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 1))
          : d.add(const Duration(days: 2));
    }
    if (d.weekday == DateTime.sunday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 2))
          : d.add(const Duration(days: 1));
    }
    return d;
  }

  static String _monthLabel(DateTime month) {
    const names = <String>[
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${names[month.month - 1]} ${month.year}';
  }
}
