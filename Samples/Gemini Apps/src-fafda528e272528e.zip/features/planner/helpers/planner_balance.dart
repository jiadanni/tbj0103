import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;

/// Calculates the starting balance for a future month/period.
///
/// For future periods, the starting balance is the previous period's end balance.
/// This is calculated by starting with the current period's balance and adding all
/// planned items from the current period through the period before the target.
///
/// Parameters:
/// - [month]: The future month/period reference to predict (returns null for past or current)
/// - [currentBalanceCents]: The user's current balance for the current period
/// - [useZeroBaseline]: If true, show $0 as the starting balance instead of the
///   calculated previous period's end balance (useful for showing savings potential)
/// - [plannedTotalForMonth]: Sum of planned items for a given month/period
/// - [currentPeriodMonth]: The reference month for the current period (handles paycheck mode)
///
/// Returns null if the month is in the past or is the current period.
int? startBalanceCentsForMonth({
  required DateTime month,
  required int currentBalanceCents,
  required bool useZeroBaseline,
  required int Function(DateTime month) plannedTotalForMonth,
  DateTime? currentPeriodMonth,
}) {
  // Use provided current period month, or fall back to calendar month
  final now = currentPeriodMonth != null
      ? monthOnly(currentPeriodMonth)
      : monthOnly(DateTime.now());
  final m = monthOnly(month);

  // Don't calculate for past months or the current month/period
  if (m.isBefore(now) || m.isAtSameMomentAs(now)) return null;

  // If useZeroBaseline is true, show 0 instead of the previous period's end balance
  if (useZeroBaseline) return 0;

  // Calculate the previous period's end balance
  // Start with the current period's balance
  var previousPeriodEndBalance = currentBalanceCents;
  var cursor = now;

  // Sum all planned items from current period through the period before the target
  while (cursor.isBefore(m)) {
    previousPeriodEndBalance += plannedTotalForMonth(cursor);
    cursor = monthOnly(month_math.addMonths(cursor, 1));
  }

  return previousPeriodEndBalance;
}

/// Shows balance edit dialog for the current period.
///
/// For the current period, directly opens the edit balance dialog.
/// The zero baseline toggle is only available for future months via header tap.
Future<void> showBalanceActions(
  BuildContext context,
  AppSettingsStore settings,
) async {
  await showEditBalanceDialog(context, settings);
}


Future<void> showEditBalanceDialog(
  BuildContext context,
  AppSettingsStore settings,
) async {
  final next = await showDialog<int?>(
    context: context,
    builder: (context) => EditBalanceDialog(
      initialCents: settings.currentBalanceCents,
      currency: settings.currencySettings.currency,
    ),
  );
  if (!context.mounted) return;
  if (next != null) settings.currentBalanceCents = next;
}

class EditBalanceDialog extends StatefulWidget {
  const EditBalanceDialog({
    super.key,
    required this.initialCents,
    required this.currency,
  });

  final int initialCents;
  final AppCurrency currency;

  @override
  State<EditBalanceDialog> createState() => _EditBalanceDialogState();
}

class _EditBalanceDialogState extends State<EditBalanceDialog> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(
      text: (widget.initialCents / 100).toStringAsFixed(2),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final raw = _controller.text.trim();
    final value = double.tryParse(raw);
    final cents = value != null ? (value * 100).round() : null;
    Navigator.pop(context, cents);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(AppLocalizations.of(context)!.currentBalance),
      content: TextField(
        controller: _controller,
        decoration: InputDecoration(
          labelText: AppLocalizations.of(context)!.amountExample,
          border: const OutlineInputBorder(),
        ),
        keyboardType: const TextInputType.numberWithOptions(
          signed: true,
          decimal: true,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, null),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: _submit,
          child: Text(AppLocalizations.of(context)!.save),
        ),
      ],
    );
  }
}
