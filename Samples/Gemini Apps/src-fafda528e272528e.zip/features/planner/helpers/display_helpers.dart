import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';

// isPastMonth is now imported from planner_dates.dart

/// Holds display values for a payment (either scheduled or actual)
class DisplayValues {
  const DisplayValues({
    required this.date,
    required this.amountMinorUnits,
    required this.hasDateVariance,
    required this.hasAmountVariance,
    this.scheduledDate,
    this.scheduledAmountMinorUnits,
  });

  /// The date to display (actual if past month, scheduled otherwise)
  final DateTime date;

  /// The amount to display in cents (actual if past month, scheduled otherwise)
  final int amountMinorUnits;

  /// Whether the actual date differs from scheduled
  final bool hasDateVariance;

  /// Whether the actual amount differs from scheduled
  final bool hasAmountVariance;

  /// Original scheduled date (for variance display)
  final DateTime? scheduledDate;

  /// Original scheduled amount in cents (for variance display)
  final int? scheduledAmountMinorUnits;

  /// Returns the variance in days (positive if paid later, negative if earlier)
  int? getDateVarianceDays() {
    if (!hasDateVariance || scheduledDate == null) return null;
    return date.day - scheduledDate!.day;
  }

  /// Returns the variance in cents (positive if more paid, negative if less)
  int? getAmountVarianceCents() {
    if (!hasAmountVariance || scheduledAmountMinorUnits == null) return null;
    return amountMinorUnits - scheduledAmountMinorUnits!;
  }
}

/// Selects appropriate display values based on whether month is past/current
DisplayValues getDisplayValues({
  required PlannerItem item,
  required DateTime month,
  PaymentEntry? payment,
}) {
  final isPast = isPastMonth(month);

  // For past months with a recorded payment, show actuals
  if (isPast && payment != null) {
    return DisplayValues(
      date: payment.date,
      amountMinorUnits: payment.amountMinorUnits,
      hasDateVariance: payment.scheduledDate != null &&
                       payment.scheduledDate!.day != payment.date.day,
      hasAmountVariance: payment.scheduledAmountMinorUnits != null &&
                         payment.scheduledAmountMinorUnits != payment.amountMinorUnits,
      scheduledDate: payment.scheduledDate,
      scheduledAmountMinorUnits: payment.scheduledAmountMinorUnits,
    );
  }

  // For current/future months or items without payment, show scheduled
  final effectiveDay = effectiveDayOfMonth(item.dayOfMonth, month);
  return DisplayValues(
    date: DateTime.utc(month.year, month.month, effectiveDay),
    amountMinorUnits: item.amountMinorUnits,
    hasDateVariance: false,
    hasAmountVariance: false,
  );
}
