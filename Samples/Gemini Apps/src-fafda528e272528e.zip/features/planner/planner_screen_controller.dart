import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';
import 'package:expense_stalker_mobile/src/features/planner/multi_month_grid.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_sheet.dart';

/// Manages controller state and zoom calculations for PlannerScreen.
///
/// Handles:
/// - PageController for month pagination
/// - TransformationControllers for sheet and grid zoom/pan
/// - Month window sizing (anchored to earliest month)
/// - Zoom level calculations
class PlannerScreenController {
  PlannerScreenController({
    required this.monthOrigin,
    required this.pageController,
    required this.sheetTransformController,
    required this.gridTransformController,
  });

  static const int monthWindowSize = 121;
  static const int monthOriginPage = monthWindowSize ~/ 2;

  DateTime monthOrigin;
  final PageController pageController;
  final TransformationController sheetTransformController;
  final TransformationController gridTransformController;

  // Sheet view state
  double? lastSheetViewportWidth;
  bool didInitSheetTransform = false;
  double? sheetInitScaleFactorFromPinch;

  // Grid view state
  bool didInitGridTransform = false;
  double? lastGridViewportWidth;
  double? lastGridViewportHeight;
  int gridTargetMonths = 4;

  /// Synchronizes the page view with the store's selected month if needed.
  void syncMonthPageIfNeeded(DateTime selectedMonth, int monthWindowSize) {
    if (!pageController.hasClients) return;
    final desired = monthOriginPage + monthsBetween(monthOrigin, selectedMonth);
    final current = pageController.page?.round();
    if (current == null) return;
    if (desired < 0 || desired >= monthWindowSize) {
      return; // Window needs recentering, handled by caller
    }
    if (current == desired) return;
    pageController.jumpToPage(desired);
  }

  /// Initializes sheet transform if not already done and viewport width is valid.
  void ensureInitialSheetTransform({
    required double viewportWidth,
    required int monthsBeforeSelected,
  }) {
    if (didInitSheetTransform) return;
    if (viewportWidth <= 0) return;

    // Default to showing exactly 2 months
    const targetVisibleMonths = 2.0;
    final baseScale = viewportWidth / (PlannerSheet.columnWidth * targetVisibleMonths);
    final pinchFactor = sheetInitScaleFactorFromPinch;
    sheetInitScaleFactorFromPinch = null;

    final factor = pinchFactor == null ? 1.0 : pinchFactor.clamp(0.4, 1.0);
    final scale = (baseScale * factor).clamp(0.15, 2.5);

    // Calculate translation to show selected month
    // We want the selected month to be at the left edge (or slightly offset?)
    // xTranslation = - (monthsBeforeSelected * columnWidth * scale)
    final xTranslation = -(monthsBeforeSelected * PlannerSheet.columnWidth * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(0, 3, xTranslation);
    
    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      sheetTransformController.value = matrix;
      didInitSheetTransform = true;
    });
  }

  /// Initializes grid transform if not already done and viewport width is valid.
  void ensureInitialGridTransform({
    required double viewportWidth,
    required double viewportHeight,
    required int monthsBeforeSelected,
  }) {
    if (didInitGridTransform) return;
    if (viewportWidth <= 0 || viewportHeight <= 0) return;

    final scale = _gridScaleForViewport(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonths: gridTargetMonths,
    );
    
    // Calculate which row the selected month is in
    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: gridTargetMonths,
    );
    
    // The grid is built with row-major order: index = row * columns + col
    // So row = index ~/ columns
    final selectedRowIndex = monthsBeforeSelected ~/ dimensions.columns;
    
    // When selected month is not in the first row, position it as the second visible row
    // This shows context of previous months above
    final offsetRows = selectedRowIndex > 0 ? selectedRowIndex - 1 : 0;
    
    // Calculate Y offset to bring that row into view
    final yTranslation = -(offsetRows * MultiMonthGrid.outerCardHeight * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(1, 3, yTranslation);
    
    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      gridTransformController.value = matrix;
      didInitGridTransform = true;
    });
  }

  /// Calculates the number of visible months in the sheet view.
  double visibleSheetMonths(double viewportWidth) {
    final scale = sheetTransformController.value.storage[0].abs();
    final normalizedScale = scale <= 0 ? 1.0 : scale;
    return viewportWidth / (PlannerSheet.columnWidth * normalizedScale);
  }

  /// Determines the zoom stage based on viewport width and current scale.
  GridZoomStage sheetZoomStageForWidth(double viewportWidth) {
    if (viewportWidth <= 0) return GridZoomStage.twoMonths;
    final visible = visibleSheetMonths(viewportWidth);
    return gridZoomStageForVisibleMonths(visible);
  }

  GridDimensions gridDimensionsForViewport({
    required double viewportWidth,
    required double viewportHeight,
  }) {
    if (viewportWidth <= 0 || viewportHeight <= 0) {
      return const GridDimensions(columns: 2, rows: 1);
    }
    return calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: gridTargetMonths,
    );
  }

  /// Jumps to a specific zoom stage in the sheet view.
  void jumpToZoomStage(GridZoomStage stage) {
    final viewportWidth = lastSheetViewportWidth;
    if (viewportWidth == null || viewportWidth <= 0) return;
    final targetVisibleMonths = switch (stage) {
      GridZoomStage.twoMonths => 2.0,
      GridZoomStage.fourMonths => 4.0,
      GridZoomStage.sixMonths => 6.0,
    };
    final targetScale = (viewportWidth / (PlannerSheet.columnWidth * targetVisibleMonths))
        .clamp(0.15, 2.5);
    final matrix = Matrix4.identity()
      ..setEntry(0, 0, targetScale)
      ..setEntry(1, 1, targetScale);
    sheetTransformController.value = matrix;
  }

  /// Jumps to a specific number of visible grid months.
  void jumpToGridMonths({
    required int targetMonths,
    required int monthsBeforeSelected,
  }) {
    gridTargetMonths = targetMonths;
    final viewportWidth = lastGridViewportWidth;
    final viewportHeight = lastGridViewportHeight;
    if (viewportWidth == null ||
        viewportHeight == null ||
        viewportWidth <= 0 ||
        viewportHeight <= 0) {
      return;
    }

    final scale = _gridScaleForViewport(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonths: targetMonths,
    );

    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: targetMonths,
    );

    final selectedRowIndex = monthsBeforeSelected ~/ dimensions.columns;
    final offsetRows = selectedRowIndex > 0 ? selectedRowIndex - 1 : 0;
    final yTranslation = -(offsetRows * MultiMonthGrid.outerCardHeight * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(1, 3, yTranslation);
    gridTransformController.value = matrix;
  }

  double _gridScaleForViewport({
    required double viewportWidth,
    required double viewportHeight,
    required int targetMonths,
  }) {
    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: targetMonths,
    );
    final totalWidth = dimensions.columns * MultiMonthGrid.outerCardWidth;
    final totalHeight = dimensions.rows * MultiMonthGrid.outerCardHeight;
    final scale = math.min(
      viewportWidth / totalWidth,
      viewportHeight / totalHeight,
    );
    return scale.clamp(0.3, 2.0);
  }

  /// Snaps the sheet view to the nearest column boundary.
  /// Should be called from onInteractionEnd.
  void snapSheetToGrid() {
    final matrix = sheetTransformController.value;
    final scale = matrix.row0.x; // Current horizontal scale
    final translationX = matrix.row0.w; // Current horizontal translation
    
    // The effective width of one column at current zoom level
    final scaledColumnWidth = PlannerSheet.columnWidth * scale;
    
    // Find the nearest column index
    final nearestColumnIndex = (translationX / scaledColumnWidth).round();
    final snappedX = nearestColumnIndex * scaledColumnWidth;
    
    // Only snap if there's a meaningful difference
    if ((translationX - snappedX).abs() > 0.5) {
      // Create the new matrix with the snapped X value
      final snappedMatrix = matrix.clone()..setEntry(0, 3, snappedX);
      sheetTransformController.value = snappedMatrix;
    }
  }

  /// Snaps the grid view to the nearest row boundary.
  /// Should be called from onInteractionEnd.
  void snapGridToRow() {
    final matrix = gridTransformController.value;
    final scale = matrix.row1.y; // Current vertical scale
    final translationY = matrix.row1.w; // Current vertical translation
    
    // The effective height of one row at current zoom level
    final scaledRowHeight = MultiMonthGrid.outerCardHeight * scale;
    
    // Find the nearest row index
    final nearestRowIndex = (translationY / scaledRowHeight).round();
    final snappedY = nearestRowIndex * scaledRowHeight;
    
    // Only snap if there's a meaningful difference
    if ((translationY - snappedY).abs() > 0.5) {
      // Create the new matrix with the snapped Y value
      final snappedMatrix = matrix.clone()..setEntry(1, 3, snappedY);
      gridTransformController.value = snappedMatrix;
    }
  }

  /// Disposes all controllers.
  void dispose() {
    pageController.dispose();
    sheetTransformController.dispose();
    gridTransformController.dispose();
  }
}
