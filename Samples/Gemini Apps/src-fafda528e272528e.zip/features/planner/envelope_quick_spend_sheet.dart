import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_amount_selector.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';

/// Formats a date as "MMM d" (e.g., "Jan 15")
String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${months[date.month - 1]} ${date.day}';
}
/// Bottom sheet for quick-spending from a spending envelope.
/// 
/// Shows circular preset amount buttons and allows selecting an amount
/// to deduct from the envelope's budget for the current period.
/// Also displays spending history with edit/delete capability.
class EnvelopeQuickSpendSheet extends StatefulWidget {
  const EnvelopeQuickSpendSheet({
    super.key,
    required this.envelope,
    required this.store,
    required this.month,
  });

  final PlannerItem envelope;
  final ExpenseStore store;
  final DateTime month;

  @override
  State<EnvelopeQuickSpendSheet> createState() => _EnvelopeQuickSpendSheetState();
}

class _EnvelopeQuickSpendSheetState extends State<EnvelopeQuickSpendSheet> {
  bool _showHistory = false;

  void _handleAmountSelected(BuildContext context, int amountCents) {
    // Expenses are negative
    final finalAmount = -amountCents.abs();
    
    final payment = PaymentEntry(
      id: newEntryId(),
      label: widget.envelope.label,
      amountMinorUnits: finalAmount,
      date: dateOnly(DateTime.now()),
      type: PaymentType.spendingEnvelope,
      plannerItemId: widget.envelope.id,
      category: widget.envelope.category,
      company: widget.envelope.company,
      moneyPotId: widget.envelope.moneyPotId,
    );
    
    widget.store.upsertPayment(payment);
    
    // Update balance
    final settings = AppSettingsScope.read(context);
    settings.currentBalanceCents += payment.amountMinorUnits;

    Navigator.pop(context);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Spent ${formatMoney(amountCents, settings.currency, showDecimals: settings.showCents)} from ${widget.envelope.label}',
        ),
      ),
    );
  }

  void _showCustomAmountDialog(BuildContext context) {
    Navigator.pop(context);
    
    showDialog(
      context: context,
      builder: (ctx) => _CustomAmountDialog(
        envelope: widget.envelope,
        store: widget.store,
      ),
    );
  }

  void _editPayment(BuildContext context, PaymentEntry payment) {
    showDialog(
      context: context,
      builder: (ctx) => _EditPaymentDialog(
        payment: payment,
        store: widget.store,
        envelope: widget.envelope,
      ),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _deletePayment(BuildContext context, PaymentEntry payment) async {
    final settings = AppSettingsScope.read(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Entry?'),
        content: Text(
          'Delete ${formatMoneyFromCents(payment.amountMinorUnits.abs(), settings.currency, showCents: settings.showCents)} from ${_formatDate(payment.date)}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    
    if (confirmed == true && mounted) {
      // Reverse the balance change
      settings.currentBalanceCents -= payment.amountMinorUnits;
      widget.store.deletePayment(payment.id);
      setState(() {});
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Entry deleted')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final amounts = settings.customQuickAddAmounts;
    final payments = widget.store.paymentsForMonth(widget.month);
    
    // Calculate current spending progress
    final period = SpendingEnvelopeService.getEnvelopePeriodDates(widget.envelope, widget.month);
    final spent = SpendingEnvelopeService.getSpentAmountForPeriod(widget.envelope, payments, period);
    final target = widget.envelope.amountMinorUnits.abs();
    final remaining = target - spent;
    final progress = target > 0 ? spent / target : 0.0;
    final isOverBudget = progress > 1.0;
    
    // Get history entries for this envelope
    final historyEntries = payments
        .where((p) => p.plannerItemId == widget.envelope.id)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date)); // Most recent first
    
    final progressColor = isOverBudget 
        ? Theme.of(context).colorScheme.error
        : (progress > 0.8 
            ? Colors.orange 
            : settings.debitColor);

    return Container(
      padding: const EdgeInsets.only(bottom: 24),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with envelope name
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              widget.envelope.label,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          
          // Spending progress
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Progress bar
                SizedBox(
                  width: 80,
                  height: 8,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                      valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Spent / Target text
                Text(
                  '${formatMoneyFromCents(-spent, settings.currency, showCents: settings.showCents)} / ${formatMoneyFromCents(widget.envelope.amountMinorUnits, settings.currency, showCents: settings.showCents)}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: progressColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          
          // Remaining amount
          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 16),
            child: Text(
              remaining >= 0 
                  ? '${formatMoneyFromCents(remaining, settings.currency, showCents: settings.showCents)} remaining'
                  : '${formatMoneyFromCents(-remaining, settings.currency, showCents: settings.showCents)} over budget',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: remaining >= 0 
                    ? Theme.of(context).colorScheme.onSurfaceVariant
                    : Theme.of(context).colorScheme.error,
              ),
            ),
          ),
          
          // Quick amount buttons
          QuickAmountSelector(
            amounts: amounts,
            onAmountSelected: (amount) => _handleAmountSelected(context, amount),
          ),
          
          const SizedBox(height: 16),
          
          // Custom amount fallback
          TextButton(
            onPressed: () => _showCustomAmountDialog(context),
            child: const Text('Enter Custom Amount'),
          ),
          
          // History section
          if (historyEntries.isNotEmpty) ...[
            const Divider(height: 32),
            InkWell(
              onTap: () => setState(() => _showHistory = !_showHistory),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'History (${historyEntries.length})',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Icon(
                      _showHistory ? Icons.expand_less : Icons.expand_more,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
            if (_showHistory)
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  itemCount: historyEntries.length,
                  itemBuilder: (context, index) {
                    final entry = historyEntries[index];
                    return Dismissible(
                      key: ValueKey(entry.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16.0),
                        color: Theme.of(context).colorScheme.error,
                        child: Icon(
                          Icons.delete,
                          color: Theme.of(context).colorScheme.onError,
                        ),
                      ),
                      confirmDismiss: (_) async {
                        await _deletePayment(context, entry);
                        return false; // We handle deletion ourselves
                      },
                      child: ListTile(
                        dense: true,
                        onTap: () => _editPayment(context, entry),
                        leading: Icon(
                          Icons.receipt_outlined,
                          size: 18,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                        title: Text(_formatDate(entry.date)),
                        trailing: Text(
                          formatMoneyFromCents(entry.amountMinorUnits, settings.currency, showCents: settings.showCents),
                          style: TextStyle(
                            color: settings.debitColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ],
      ),
    );
  }
}

/// Dialog for editing an existing spending entry.
class _EditPaymentDialog extends StatefulWidget {
  const _EditPaymentDialog({
    required this.payment,
    required this.store,
    required this.envelope,
  });

  final PaymentEntry payment;
  final ExpenseStore store;
  final PlannerItem envelope;

  @override
  State<_EditPaymentDialog> createState() => _EditPaymentDialogState();
}

class _EditPaymentDialogState extends State<_EditPaymentDialog> {
  late final TextEditingController _amountController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // Convert cents to dollars for display (absolute value since expenses are negative)
    final amountMajor = widget.payment.amountMinorUnits.abs() / 100.0;
    final text = amountMajor == amountMajor.truncateToDouble()
        ? amountMajor.truncate().toString()
        : amountMajor.toString();
    _amountController = TextEditingController(text: text);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
      _amountController.selection = TextSelection(
        baseOffset: 0,
        extentOffset: _amountController.text.length,
      );
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;
    
    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return;
    
    final settings = AppSettingsScope.read(context);
    
    // Calculate the difference before rounding for balance adjustment
    final oldAmount = widget.payment.amountMinorUnits;
    final newAmount = -rawAmountCents.abs(); // Negative for expenses
    final difference = newAmount - oldAmount;
    
    // Update the payment
    final updated = widget.payment.copyWith(
      amountMinorUnits: newAmount,
    );
    
    widget.store.upsertPayment(updated);
    
    // Adjust balance by the difference
    settings.currentBalanceCents += difference;
    
    if (mounted) {
      Navigator.pop(context);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Updated to ${formatMoney(rawAmountCents, settings.currency, showDecimals: settings.showCents)}'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    
    return AlertDialog(
      title: const Text('Edit Amount'),
      content: TextField(
        controller: _amountController,
        focusNode: _focusNode,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(
          labelText: 'Amount',
          prefixText: '- ',
          border: OutlineInputBorder(),
        ),
        inputFormatters: [
          if (settings.showCents)
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
          else
            FilteringTextInputFormatter.digitsOnly,
        ],
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Save'),
        ),
      ],
    );
  }
}

/// Dialog for entering a custom spending amount.
class _CustomAmountDialog extends StatefulWidget {
  const _CustomAmountDialog({
    required this.envelope,
    required this.store,
  });

  final PlannerItem envelope;
  final ExpenseStore store;

  @override
  State<_CustomAmountDialog> createState() => _CustomAmountDialogState();
}

class _CustomAmountDialogState extends State<_CustomAmountDialog> {
  late final TextEditingController _amountController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;
    
    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return;
    
    final settings = AppSettingsScope.read(context);
    final roundedCents = roundUpToIncrement(
      rawAmountCents, 
      settings.roundingIncrement * 100,
    );
    
    // Expenses are negative
    final finalAmountCents = -roundedCents;

    final payment = PaymentEntry(
      id: newEntryId(),
      label: widget.envelope.label,
      amountMinorUnits: finalAmountCents,
      date: dateOnly(DateTime.now()),
      type: PaymentType.spendingEnvelope,
      plannerItemId: widget.envelope.id,
      category: widget.envelope.category,
      company: widget.envelope.company,
      moneyPotId: widget.envelope.moneyPotId,
    );
    
    widget.store.upsertPayment(payment);
    settings.currentBalanceCents += payment.amountMinorUnits;
    
    if (mounted) {
      Navigator.pop(context);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Spent ${formatMoney(roundedCents, settings.currency, showDecimals: settings.showCents)} from ${widget.envelope.label}'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    
    return AlertDialog(
      title: Text('Spend from ${widget.envelope.label}'),
      content: TextField(
        controller: _amountController,
        focusNode: _focusNode,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(
          labelText: 'Amount',
          prefixText: '- ',
          border: OutlineInputBorder(),
        ),
        inputFormatters: [
          if (settings.showCents)
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
          else
            FilteringTextInputFormatter.digitsOnly,
        ],
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Spend'),
        ),
      ],
    );
  }
}
