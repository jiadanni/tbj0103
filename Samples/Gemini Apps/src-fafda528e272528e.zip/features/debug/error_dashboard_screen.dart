import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';

/// Developer-facing screen for viewing error logs and statistics.
///
/// Shows:
/// - Error count by severity
/// - Error statistics by category
/// - Recent error history
/// - Detailed error information
class ErrorDashboardScreen extends StatefulWidget {
  const ErrorDashboardScreen({super.key});

  @override
  State<ErrorDashboardScreen> createState() => _ErrorDashboardScreenState();
}

class _ErrorDashboardScreenState extends State<ErrorDashboardScreen> {
  ErrorSeverity? _filterSeverity;

  @override
  Widget build(BuildContext context) {
    final tracker = ErrorTracker.instance;
    final errors = _filterSeverity == null
        ? tracker.getRecentErrors()
        : tracker.getErrorsBySeverity(_filterSeverity!);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Error Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => setState(() {}),
            tooltip: 'Refresh',
          ),
        IconButton(
          icon: const Icon(Icons.delete_outline),
          onPressed: _confirmClearHistory,
          tooltip: 'Clear History',
        ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildStatisticsCard(tracker),
          const SizedBox(height: 16),
          _buildFilterChips(),
          const SizedBox(height: 16),
          _buildErrorList(errors),
        ],
      ),
    );
  }

  Widget _buildStatisticsCard(ErrorTracker tracker) {
    final stats = tracker.getErrorStatistics();
    final criticalCount = tracker.getCriticalErrors().length;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Statistics',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem(
                  'Total',
                  tracker.errorCount.toString(),
                  Icons.bug_report,
                  Colors.blue,
                ),
                _buildStatItem(
                  'Critical',
                  criticalCount.toString(),
                  Icons.error,
                  criticalCount > 0 ? Colors.red : Colors.grey,
                ),
                _buildStatItem(
                  'Categories',
                  stats.length.toString(),
                  Icons.category,
                  Colors.orange,
                ),
              ],
            ),
            if (stats.isNotEmpty) ...[
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              Text(
                'By Category',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              ...stats.entries.map((entry) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(entry.key),
                        Chip(
                          label: Text(entry.value.toString()),
                          visualDensity: VisualDensity.compact,
                        ),
                      ],
                    ),
                  )),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, size: 32, color: color),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: color,
              ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _buildFilterChips() {
    return Wrap(
      spacing: 8,
      children: [
        FilterChip(
          label: const Text('All'),
          selected: _filterSeverity == null,
          onSelected: (selected) {
            setState(() => _filterSeverity = null);
          },
        ),
        ...ErrorSeverity.values.map((severity) => FilterChip(
              label: Text(severity.name.toUpperCase()),
              selected: _filterSeverity == severity,
              onSelected: (selected) {
                setState(() => _filterSeverity = selected ? severity : null);
              },
            )),
      ],
    );
  }

  Widget _buildErrorList(List<ErrorContext> errors) {
    if (errors.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            children: [
              Icon(
                Icons.check_circle_outline,
                size: 64,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 16),
              Text(
                'No Errors',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                _filterSeverity == null
                    ? 'No errors have been logged'
                    : 'No ${_filterSeverity!.name} errors',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Errors (${errors.length})',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        ...errors.reversed.map((error) => _buildErrorCard(error)),
      ],
    );
  }

  Widget _buildErrorCard(ErrorContext error) {
    final severityColor = _getSeverityColor(error.severity);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(
          _getSeverityIcon(error.severity),
          color: severityColor,
        ),
        title: Text(error.message),
        subtitle: Text(
          '${error.category} • ${error.severity.name}',
          style: TextStyle(color: severityColor),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showErrorDetails(error),
      ),
    );
  }

  IconData _getSeverityIcon(ErrorSeverity severity) {
    return switch (severity) {
      ErrorSeverity.info => Icons.info_outline,
      ErrorSeverity.warning => Icons.warning_amber,
      ErrorSeverity.error => Icons.error_outline,
      ErrorSeverity.critical => Icons.dangerous,
    };
  }

  Color _getSeverityColor(ErrorSeverity severity) {
    return switch (severity) {
      ErrorSeverity.info => Colors.blue,
      ErrorSeverity.warning => Colors.orange,
      ErrorSeverity.error => Colors.red,
      ErrorSeverity.critical => Colors.purple,
    };
  }

  void _showErrorDetails(ErrorContext error) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) {
          return Container(
            padding: const EdgeInsets.all(16),
            child: ListView(
              controller: scrollController,
              children: [
                Row(
                  children: [
                    Icon(
                      _getSeverityIcon(error.severity),
                      color: _getSeverityColor(error.severity),
                      size: 32,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            error.message,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          Text(
                            '${error.category} • ${error.severity.name.toUpperCase()}',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: _getSeverityColor(error.severity),
                                ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy),
                      onPressed: () => _copyErrorToClipboard(error),
                      tooltip: 'Copy to Clipboard',
                    ),
                  ],
                ),
                const Divider(height: 32),
                if (error.error != null) ...[
                  _buildDetailSection('Error', error.error.toString()),
                  const SizedBox(height: 16),
                ],
                if (error.stackTrace != null) ...[
                  _buildDetailSection('Stack Trace', error.stackTrace.toString()),
                  const SizedBox(height: 16),
                ],
                if (error.additionalData != null &&
                    error.additionalData!.isNotEmpty) ...[
                  _buildDetailSection(
                    'Additional Data',
                    error.additionalData.toString(),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
          child: SelectableText(
            content,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontFamily: 'monospace',
                ),
          ),
        ),
      ],
    );
  }

  Future<void> _copyErrorToClipboard(ErrorContext error) async {
    final json = error.toJson();
    final text = json.entries
        .map((e) => '${e.key}: ${e.value}')
        .join('\n');
    
    await Clipboard.setData(ClipboardData(text: text));
    
    if (mounted) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Error details copied to clipboard'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _confirmClearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Error History'),
        content: const Text(
          'Are you sure you want to clear all error history? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (!mounted || confirmed != true) return;

    ErrorTracker.instance.clearHistory();
    setState(() {});
    if (mounted) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Error history cleared'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

}
