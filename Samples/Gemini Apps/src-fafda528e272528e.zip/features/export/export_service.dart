import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/util/encryption_util.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

/// Export format version for JSON files.
/// Increment when schema changes require migration.
const int kExportVersion = 1;

/// Service for exporting and importing expense data.
///
/// Supports two formats:
/// - JSON: Full backup including all metadata, suitable for restore
/// - CSV: Flattened data suitable for spreadsheet analysis
class ExportService {
  const ExportService._();

  /// Singleton instance.
  static const ExportService instance = ExportService._();

  // ─────────────────────────────────────────────────────────────────────────
  // JSON Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports all accounts as a single JSON file and shares it.
  Future<String?> exportAllAccountsJson(List<Account> accounts, Map<String, ExpenseSnapshot> data, {String? password}) async {
    try {
      Map<String, String>? encryption;
      if (password != null && password.isNotEmpty) {
        // Heavy serialization and encoding
        final plainString = await compute((params) {
          final json = ExpensePersistence.multiAccountToExportJson(params.accounts, params.data);
          return jsonEncode(json);
        }, (accounts: accounts, data: data));
        
        encryption = await EncryptionUtil.encrypt(plainString, password);
      }

      // Final wrap (very light if encrypted, heavy if not)
      final encoded = await compute((params) {
        final json = ExpensePersistence.multiAccountToExportJson(params.accounts, params.data, encryption: params.encryption);
        return const JsonEncoder.withIndent('  ').convert(json);
      }, (accounts: accounts, data: data, encryption: encryption));

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final fileName = 'expense_stalker_all_accounts_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(encoded);

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: 'Expense Stalker Full Backup',
        ),
      );

      try { await file.delete(); } catch (_) {}
      return file.path;
    } catch (error, stackTrace) {
      debugLog(LogCategory.persistence, 'Multi-account JSON export failed', error: error, stackTrace: stackTrace);
      return null;
    }
  }

  /// Exports the given snapshot as a JSON file and shares it.
  Future<String?> exportJson(ExpenseSnapshot snapshot, {String? password, String? accountName}) async {
    try {
      Map<String, String>? encryption;
      if (password != null && password.isNotEmpty) {
        // Heavy serialization and encoding
        final plainString = await compute((s) {
          final json = ExpensePersistence.toExportJson(s);
          return jsonEncode(json);
        }, snapshot);
        
        encryption = await EncryptionUtil.encrypt(plainString, password);
      }

      // Final wrap
      final encoded = await compute((params) {
        final json = ExpensePersistence.toExportJson(params.snapshot, encryption: params.encryption);
        return const JsonEncoder.withIndent('  ').convert(json);
      }, (snapshot: snapshot, encryption: encryption));

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'backup').replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
      final fileName = 'expense_stalker_${safeAccountName}_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(encoded);

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: 'Expense Stalker Backup - $accountName',
        ),
      );

      try { await file.delete(); } catch (_) {}
      return file.path;
    } catch (error, stackTrace) {
      debugLog(LogCategory.persistence, 'JSON export failed', error: error, stackTrace: stackTrace);
      return null;
    }
  }

  /// Imports expense data from a JSON file selected by the user.
  Future<(List<Account>, Map<String, ExpenseSnapshot>)?> importJson({
    Future<String?> Function()? onPasswordRequired,
  }) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return null;

      final filePath = result.files.single.path;
      if (filePath == null) return null;

      final file = File(filePath);
      final content = await file.readAsString();
      
      // Heavy decoding
      var json = await compute(jsonDecode, content) as Map<String, dynamic>;

      if (ExpensePersistence.isEncrypted(json)) {
        if (onPasswordRequired == null) throw const FormatException('File is encrypted but no password provider given');
        final password = await onPasswordRequired();
        if (password == null) return null;

        final encryptionData = json['encryption'] as Map<String, dynamic>;
        final decryptedString = await EncryptionUtil.decrypt(encryptionData, password);
        
        // Heavy decoding of inner content
        json = await compute(jsonDecode, decryptedString) as Map<String, dynamic>;
      }

      // Heavy map-to-object conversion
      return await compute(ExpensePersistence.multiAccountFromExportJson, json);
    } catch (error, stackTrace) {
      debugLog(LogCategory.persistence, 'JSON import failed', error: error, stackTrace: stackTrace);
      return null;
    }
  }
  // Export/import JSON helpers are provided by ExpensePersistence.
  // Local duplication removed to avoid unused code and ensure a single
  // canonical serialization implementation.

  // ─────────────────────────────────────────────────────────────────────────
  // CSV Export
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports the given snapshot as a CSV file and shares it.
  ///
  /// The CSV contains a combined view of planner items and payments,
  /// suitable for analysis in spreadsheet applications.
  ///
  /// Returns the path to the temporary file, or null if cancelled/failed.
  Future<String?> exportCsv(ExpenseSnapshot snapshot, {String? accountName}) async {
    try {
      final csv = await compute((params) {
        return snapshotToCsv(params.snapshot, accountName: params.accountName);
      }, (snapshot: snapshot, accountName: accountName));

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'export').replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
      final fileName = 'expense_stalker_${safeAccountName}_$timestamp.csv';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(csv);

      debugLog(LogCategory.persistence, 'Exported CSV: ${file.path}');

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: 'Expense Stalker Export' + (accountName != null ? ' - $accountName' : ''),
        ),
      );

      // Clean up temporary file after sharing
      try {
        await file.delete();
      } catch (deleteError) {
        // Best effort cleanup; log but don't fail the export
        debugLog(
          LogCategory.persistence,
          'Failed to delete temp file: ${file.path}',
          error: deleteError,
        );
      }

      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'CSV export failed',
        error: error,
        stackTrace: stackTrace,
      );
      ErrorTracker.instance.trackException(
        'export',
        'Failed to export CSV file',
        error,
        stackTrace,
        severity: ErrorSeverity.error,
        additionalData: {
          'plannerItems': snapshot.plannerItems.length,
          'payments': snapshot.payments.length,
        },
      );
      return null;
    }
  }

  @visibleForTesting
  static String snapshotToCsv(ExpenseSnapshot snapshot, {String? accountName}) {
    final buffer = StringBuffer();

    // Metadata Block
    final acctName = accountName ?? snapshot.accountSettings?.name ?? 'Unknown Account';
    buffer.writeln('Account Name,$acctName');
    buffer.writeln('Export Date,${DateTime.now().toIso8601String()}');
    
    if (snapshot.accountSettings != null) {
      final settings = snapshot.accountSettings!;
      // Add relevant settings
      // Note: We can expand this list as needed
      buffer.writeln('Starting Balance,${(settings.startingBalanceCents / 100).toStringAsFixed(2)}');
      if (settings.paycheckDay != null) {
        buffer.writeln('Paycheck Day,${settings.paycheckDay}');
      }
      buffer.writeln('View Period Mode,${settings.viewPeriodMode.name}');
    }
    buffer.writeln(); // Empty line separator

    // Header row - simplified for user analysis
    buffer.writeln(
      'Type,Label,Amount,Date,Category,Frequency,DayOfMonth,Notes,Archived',
    );

    // Planner items
    for (final item in snapshot.plannerItems) {
      buffer.writeln(_plannerItemToCsvRow(item));
    }

    // Payments
    for (final payment in snapshot.payments) {
      buffer.writeln(_paymentEntryToCsvRow(payment));
    }

    return buffer.toString();
  }

  String _formatTimestamp(DateTime timestamp) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${timestamp.year}-${two(timestamp.month)}-${two(timestamp.day)}_'
        '${two(timestamp.hour)}-${two(timestamp.minute)}';
  }

  static String _plannerItemToCsvRow(PlannerItem item) {
    return [
      'Planner',
      _escapeCsvField(item.label),
      (item.amountMinorUnits / 100).toStringAsFixed(2),
      '', // No date for planner items
      item.type.name,
      item.frequency?.name ?? '',
      item.dayOfMonth.toString(),
      _escapeCsvField(item.notes ?? ''),
      item.archived.toString(),
    ].join(',');
  }

  static String _paymentEntryToCsvRow(PaymentEntry entry) {
    return [
      'Payment',
      _escapeCsvField(entry.label),
      (entry.amountMinorUnits / 100).toStringAsFixed(2),
      entry.date.toIso8601String().split('T').first, // YYYY-MM-DD in local time
      entry.type.name,
      '', // No frequency for payments
      '', // No day of month for payments
      _escapeCsvField(entry.notes ?? ''),
      '', // No archived flag for payments
    ].join(',');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Multi-Month Grid CSV Export
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports a multi-month grid view as CSV (rows = items, columns = months).
  ///
  /// Shows which items are paid in each month with an asterisk marker.
  Future<String?> exportGridCsv(
    ExpenseSnapshot snapshot, {
    int monthCount = 6,
    String? accountName,
  }) async {
    try {
      final csv = await compute((params) {
        return snapshotToGridCsv(
          params.snapshot, 
          monthCount: params.monthCount,
          accountName: params.accountName,
        );
      }, (snapshot: snapshot, monthCount: monthCount, accountName: accountName));

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'export').replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
      final fileName = 'expense_stalker_grid_${safeAccountName}_${monthCount}m_$timestamp.csv';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(csv);

      debugLog(LogCategory.persistence, 'Exported Grid CSV: ${file.path}');

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: 'Expense Stalker Grid Export' + (accountName != null ? ' - $accountName' : ''),
        ),
      );

      // Clean up temporary file after sharing
      try {
        await file.delete();
      } catch (deleteError) {
        // Best effort cleanup; log but don't fail the export
        debugLog(
          LogCategory.persistence,
          'Failed to delete temp file: ${file.path}',
          error: deleteError,
        );
      }

      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Grid CSV export failed',
        error: error,
        stackTrace: stackTrace,
      );
      ErrorTracker.instance.trackException(
        'export',
        'Failed to export grid CSV file',
        error,
        stackTrace,
        severity: ErrorSeverity.error,
      );
      return null;
    }
  }

  @visibleForTesting
  static String snapshotToGridCsv(ExpenseSnapshot snapshot, {required int monthCount, String? accountName}) {
    final buffer = StringBuffer();
    final now = DateTime.now();
    
    // Metadata Block
    final acctName = accountName ?? snapshot.accountSettings?.name ?? 'Unknown Account';
    buffer.writeln('Account Name,$acctName');
    buffer.writeln('Export Date,${now.toIso8601String()}');
    buffer.writeln(); // Empty line separator
    
    final startMonth = DateTime.utc(now.year, now.month - (monthCount ~/ 2));
    
    // Generate month headers
    final months = List.generate(
      monthCount,
      (i) => DateTime.utc(startMonth.year, startMonth.month + i),
    );
    
    // Header row
    buffer.write('Item');
    for (final month in months) {
      final monthName = '${_monthName(month.month)} ${month.year}';
      buffer.write(',');
      buffer.write(_escapeCsvField(monthName));
    }
    buffer.writeln();

    // Create payment lookup map: itemId -> month -> payment
    final paymentMap = <PlannerItemId, Map<String, PaymentEntry>>{};
    for (final payment in snapshot.payments) {
      if (payment.plannerItemId == null) continue;
      final monthKey = '${payment.date.year}-${payment.date.month}';
      paymentMap.putIfAbsent(payment.plannerItemId!, () => {});
      paymentMap[payment.plannerItemId!]![monthKey] = payment;
    }

    // Data rows - one per planner item
    for (final item in snapshot.plannerItems) {
      if (item.archived) continue; // Skip archived planner items
      
      buffer.write(_escapeCsvField(item.label));
      
      for (final month in months) {
        buffer.write(',');
        final monthKey = '${month.year}-${month.month}';
        final isPaid = paymentMap[item.id]?.containsKey(monthKey) ?? false;
        final amount = (item.amountMinorUnits / 100).toStringAsFixed(2);
        final value = isPaid ? '$amount*' : amount;
        buffer.write(_escapeCsvField(value));
      }
      buffer.writeln();
    }

    return buffer.toString();
  }

  static String _monthName(int month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month - 1];
  }

  /// Escapes a field for CSV format with formula injection protection.
  ///
  /// Prevents CSV injection attacks by:
  /// - Prefixing fields starting with =, +, -, @, tab, or carriage return with a single quote
  /// - Wrapping fields with commas, quotes, or newlines in quotes
  /// - Doubling existing quotes
  ///
  /// See: https://owasp.org/www-community/attacks/CSV_Injection
  static String _escapeCsvField(String field) {
    if (field.isEmpty) return field;

    String sanitized = field;

    // Formula injection protection: prefix dangerous characters with single quote
    final firstChar = sanitized[0];
    if (firstChar == '=' ||
        firstChar == '+' ||
        firstChar == '-' ||
        firstChar == '@' ||
        firstChar == '\t' ||
        firstChar == '\r') {
      sanitized = "'$sanitized";
    }

    // Standard CSV escaping
    if (sanitized.contains(',') ||
        sanitized.contains('"') ||
        sanitized.contains('\n')) {
      return '"${sanitized.replaceAll('"', '""')}"';
    }

    return sanitized;
  }
}
