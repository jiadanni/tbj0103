import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/util/test_data_generator.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Accounts'),
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          return ListView.builder(
            padding: const EdgeInsets.all(AppConstants.paddingNormal),
            itemCount: store.accounts.length,
            itemBuilder: (context, index) {
              final account = store.accounts[index];
              final isCurrent = account.id == store.currentAccount.id;

              return Card(
                elevation: isCurrent ? 4 : 1,
                margin: const EdgeInsets.only(bottom: AppConstants.paddingNormal),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                  side: isCurrent 
                    ? BorderSide(color: theme.colorScheme.primary, width: 2)
                    : BorderSide.none,
                ),
                child: ListTile(
                  leading: Icon(
                    account.isTestData ? Icons.science : Icons.account_balance_wallet,
                    color: isCurrent ? theme.colorScheme.primary : theme.colorScheme.onSurfaceVariant,
                  ),
                  title: Text(
                    account.name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    'Last modified: ${account.lastModified.toLocal().toString().split('.')[0]}',
                    style: theme.textTheme.bodySmall,
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit_outlined),
                        tooltip: 'Rename Account',
                        onPressed: () => _showRenameAccountDialog(context, store, account),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.red),
                        tooltip: 'Delete Account',
                        onPressed: () => _confirmDelete(context, store, account, isCurrent),
                      ),
                    ],
                  ),
                  onTap: () {
                    if (!isCurrent) {
                      store.switchAccount(account.id);
                    }
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateAccountDialog(context, store),
        label: const Text('Add Account'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  void _showRenameAccountDialog(BuildContext context, ExpenseStore store, Account account) {
    final nameController = TextEditingController(text: account.name);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Account'),
        content: TextField(
          controller: nameController,
          autofocus: true,
          maxLength: AppConstants.maxAccountNameLength,
          decoration: const InputDecoration(
            labelText: 'Account Name',
            helperText: 'Keep it short for better display',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final newName = nameController.text.trim();
              if (newName.isNotEmpty && newName != account.name) {
                store.renameAccount(account.id, newName);
              }
              Navigator.pop(context);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, ExpenseStore store, Account account, bool isCurrent) {
    if (isCurrent) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Cannot Delete Active Account'),
          content: const Text('Switch to a different account first before deleting this one.'),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account'),
        content: Text('Are you sure you want to delete "${account.name}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              store.deleteAccount(account.id);
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showCreateAccountDialog(BuildContext context, ExpenseStore store) {
    final nameController = TextEditingController();
    TestDatasetSize? selectedSize;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Create New Account'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                maxLength: AppConstants.maxAccountNameLength,
                decoration: const InputDecoration(
                  labelText: 'Account Name',
                  hintText: 'e.g. Personal, Savings',
                  helperText: 'Max 20 characters',
                ),
              ),
              const SizedBox(height: 20),
              const Text('Optional: Populate with test data'),
              DropdownButton<TestDatasetSize?>(
                value: selectedSize,
                hint: const Text('No test data'),
                isExpanded: true,
                onChanged: (value) {
                  setState(() {
                    selectedSize = value;
                    if (value != null && nameController.text.isEmpty) {
                      nameController.text = 'Test Data - ${value.name}';
                    }
                  });
                },
                items: [
                  const DropdownMenuItem(value: null, child: Text('No test data')),
                  ...TestDatasetSize.values.map((size) => DropdownMenuItem(
                    value: size,
                    child: Text('${size.name} (${size.paymentCount} payments)'),
                  )),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isNotEmpty) {
                  store.createAccount(name, testSize: selectedSize);
                  Navigator.pop(context);
                }
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
  }
}
