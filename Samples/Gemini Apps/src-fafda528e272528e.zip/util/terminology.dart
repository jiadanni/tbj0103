import 'package:flutter/widgets.dart';

import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Provides user-configurable terminology based on the selected preset.
///
/// This helper resolves terminology strings based on [TerminologyPreset]:
/// - `defaultTerms`: "Scheduled", "Paid", "Mark Paid"
/// - `bills`: "Bills", "Paid", "Mark Paid"
/// - `budget`: "Budget", "Done", "Mark Done"
class Terminology {
  const Terminology._(this._l10n, this._preset);

  final AppLocalizations _l10n;
  final TerminologyPreset _preset;

  /// Creates a [Terminology] instance from the current context.
  factory Terminology.of(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final settings = AppSettingsScope.read(context);
    return Terminology._(l10n, settings.terminologyPreset);
  }

  /// The label for the list tab (e.g., "Scheduled", "Bills", "Budget")
  String get listTabLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_listTab_default,
      TerminologyPreset.bills => _l10n.term_listTab_bills,
      TerminologyPreset.budget => _l10n.term_listTab_budget,
    };
  }

  /// The label for hiding paid items (e.g., "Hide paid items")
  String get hidePaidLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_hidePaid_default,
      TerminologyPreset.bills => _l10n.term_hidePaid_bills,
      TerminologyPreset.budget => _l10n.term_hidePaid_budget,
    };
  }

  /// The label for showing paid items (e.g., "Show paid items")
  String get showPaidLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_showPaid_default,
      TerminologyPreset.bills => _l10n.term_showPaid_bills,
      TerminologyPreset.budget => _l10n.term_showPaid_budget,
    };
  }

  /// The status label for paid/done items (e.g., "Paid", "Done")
  String get itemStatusLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_itemStatus_default,
      TerminologyPreset.bills => _l10n.term_itemStatus_bills,
      TerminologyPreset.budget => _l10n.term_itemStatus_budget,
    };
  }

  String get archiveActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_archiveAction_default,
      TerminologyPreset.bills => _l10n.term_archiveAction_bills,
      TerminologyPreset.budget => _l10n.term_archiveAction_budget,
    };
  }

  String get unarchiveActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_unarchiveAction_default,
      TerminologyPreset.bills => _l10n.term_unarchiveAction_bills,
      TerminologyPreset.budget => _l10n.term_unarchiveAction_budget,
    };
  }

  String get archivedStatusLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_archivedStatus_default,
      TerminologyPreset.bills => _l10n.term_archivedStatus_bills,
      TerminologyPreset.budget => _l10n.term_archivedStatus_budget,
    };
  }

  /// The action label for marking as paid (e.g., "Mark Paid", "Mark Done")
  String get markActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_markAction_default,
      TerminologyPreset.bills => _l10n.term_markAction_bills,
      TerminologyPreset.budget => _l10n.term_markAction_budget,
    };
  }

  /// The action label for unmarking (e.g., "Unmark", "Undo")
  String get unmarkActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_unmarkAction_default,
      TerminologyPreset.bills => _l10n.term_unmarkAction_bills,
      TerminologyPreset.budget => _l10n.term_unmarkAction_budget,
    };
  }

  /// The title for creating a new item (e.g., "New scheduled item")
  String get newItemTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_newItem_default,
      TerminologyPreset.bills => _l10n.term_newItem_bills,
      TerminologyPreset.budget => _l10n.term_newItem_budget,
    };
  }

  /// The title for editing an item (e.g., "Edit scheduled item")
  String get editItemTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_editItem_default,
      TerminologyPreset.bills => _l10n.term_editItem_bills,
      TerminologyPreset.budget => _l10n.term_editItem_budget,
    };
  }

  /// The title for the delete confirmation dialog
  String get deleteTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_deleteTitle_default,
      TerminologyPreset.bills => _l10n.term_deleteTitle_bills,
      TerminologyPreset.budget => _l10n.term_deleteTitle_budget,
    };
  }

  /// The empty state message when there are no items
  String get noItemsMessage {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_noItems_default,
      TerminologyPreset.bills => _l10n.term_noItems_bills,
      TerminologyPreset.budget => _l10n.term_noItems_budget,
    };
  }
}
