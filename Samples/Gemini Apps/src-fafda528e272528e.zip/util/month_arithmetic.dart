/// Safe month arithmetic utilities.
///
/// Prevents overflow and off-by-one errors when adding/subtracting months.
library;

/// Adds or subtracts months from a date safely.
///
/// Handles month overflow/underflow correctly by normalizing year boundaries.
///
/// Examples:
/// - `addMonths(DateTime(2024, 11, 15), 5)` → `DateTime(2025, 4, 15)`
/// - `addMonths(DateTime(2024, 2, 29), 1)` → `DateTime(2024, 3, 29)`
/// - `addMonths(DateTime(2024, 1, 31), 1)` → `DateTime(2024, 2, 29)` (leap year)
/// - `addMonths(DateTime(2024, 3, 15), -5)` → `DateTime(2023, 10, 15)`
DateTime addMonths(DateTime date, int delta) {
  if (delta == 0) return date;

  // Calculate total months from epoch
  final totalMonths = date.year * 12 + date.month - 1 + delta;

  // Extract normalized year and month
  final newYear = totalMonths ~/ 12;
  final newMonth = (totalMonths % 12) + 1;

  // Handle day overflow (e.g., Jan 31 + 1 month → Feb 28/29)
  final maxDayInMonth = _daysInMonth(newYear, newMonth);
  final newDay = date.day > maxDayInMonth ? maxDayInMonth : date.day;

  if (date.isUtc) {
    return DateTime.utc(
      newYear,
      newMonth,
      newDay,
      date.hour,
      date.minute,
      date.second,
      date.millisecond,
      date.microsecond,
    );
  }

  return DateTime(
    newYear,
    newMonth,
    newDay,
    date.hour,
    date.minute,
    date.second,
    date.millisecond,
    date.microsecond,
  );
}

/// Returns the number of days in a given month.
///
/// Handles leap years correctly for February.
int _daysInMonth(int year, int month) {
  if (month == 2) {
    // Leap year calculation
    final isLeapYear = (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0);
    return isLeapYear ? 29 : 28;
  }
  
  // 30 days: April, June, September, November
  if (month == 4 || month == 6 || month == 9 || month == 11) {
    return 30;
  }
  
  // 31 days: January, March, May, July, August, October, December
  return 31;
}

/// Calculates the difference in months between two dates.
///
/// Returns a positive number if [end] is after [start], negative otherwise.
///
/// Examples:
/// - `monthsBetween(DateTime(2024, 1), DateTime(2024, 5))` → `4`
/// - `monthsBetween(DateTime(2024, 5), DateTime(2024, 1))` → `-4`
/// - `monthsBetween(DateTime(2023, 12), DateTime(2024, 2))` → `2`
int monthsBetween(DateTime start, DateTime end) {
  return (end.year - start.year) * 12 + (end.month - start.month);
}

/// Returns a normalized month-only DateTime (day set to 1, time set to 0).
///
/// Useful for month-based comparisons and calculations.
DateTime normalizeToMonth(DateTime date) {
  return DateTime.utc(date.year, date.month);
}
