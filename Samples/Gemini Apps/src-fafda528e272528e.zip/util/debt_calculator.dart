import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;
import 'package:expense_stalker_mobile/src/util/dates.dart';

/// Service for debt payoff and financial calculations.
/// Extracted from PlannerItem to allow for reuse and thorough testing.
class DebtCalculator {
  const DebtCalculator._();

  /// Maximum number of payments before we consider the calculation unreasonable.
  /// 1200 payments = 100 years of monthly payments, which is a sensible upper bound.
  static const int maxReasonablePayments = 1200;

  /// Calculates the estimated final payment date for debt items.
  ///
  /// Returns null if:
  /// - Item is not a debt type
  /// - No remaining balance is set
  /// - Payment amount is zero or negative
  /// - No frequency is set
  /// - Calculated payoff exceeds 100 years (sanity check)
  static DateTime? calculateFinalPaymentDate({
    required PaymentType type,
    required int? remainingBalanceMinorUnits,
    required int amountMinorUnits,
    required RecurrenceFrequency? frequency,
    required DateTime startDate,
    double? exchangeRate,
    DateTime? fromDate,
  }) {
    // Only applicable to debt items
    if (type != PaymentType.debt) return null;

    // Need remaining balance to calculate
    if (remainingBalanceMinorUnits == null || remainingBalanceMinorUnits <= 0) return null;

    // Need non-zero payment amount (use absolute value for expenses).
    final paymentAmountRaw = amountMinorUnits.abs();
    if (paymentAmountRaw == 0) return null;

    // Apply exchange rate conversion if set
    // exchangeRate represents: 1 payment currency = X balance currency
    final paymentAmount = exchangeRate != null && exchangeRate > 0
        ? (paymentAmountRaw * exchangeRate).round()
        : paymentAmountRaw;

    // Sanity check: if payment amount after conversion is zero or negative, bail
    if (paymentAmount <= 0) return null;

    // Need frequency for recurring debt
    if (frequency == null) return null;

    final anchor = fromDate ?? DateTime.now().toUtc();
    
    // Find the next scheduled payment date on or after the anchor date
    DateTime baseDate;
    if (!startDate.isBefore(anchor)) {
      baseDate = startDate;
    } else {
      // startDate is in the past, find next occurrence
      switch (frequency) {
        case RecurrenceFrequency.weekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final weeksPassed = (daysDiff / 7.0).ceil(); 
          baseDate = startDate.add(Duration(days: (weeksPassed < 0 ? 0 : weeksPassed) * 7));
          if (baseDate.isBefore(anchor)) {
             baseDate = baseDate.add(const Duration(days: 7));
          }
          break;
          
        case RecurrenceFrequency.biweekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final fortnightsPassed = (daysDiff / 14.0).ceil();
          baseDate = startDate.add(Duration(days: (fortnightsPassed < 0 ? 0 : fortnightsPassed) * 14));
          if (baseDate.isBefore(anchor)) {
             baseDate = baseDate.add(const Duration(days: 14));
          }
          break;
          
        case RecurrenceFrequency.monthly:
        case RecurrenceFrequency.quarterly:
        case RecurrenceFrequency.yearly:
          final monthsPerPeriod = switch (frequency) {
             RecurrenceFrequency.monthly => 1,
             RecurrenceFrequency.quarterly => 3,
             RecurrenceFrequency.yearly => 12,
             _ => 1,
          };
          
          final monthsDiff = 
              (anchor.year - startDate.year) * 12 + 
              (anchor.month - startDate.month);
          
          var periodsPassed = (monthsDiff / monthsPerPeriod).floor();
          var candidate = month_math.addMonths(startDate, periodsPassed * monthsPerPeriod);
          while (candidate.isBefore(anchor)) {
             periodsPassed++;
             candidate = month_math.addMonths(startDate, periodsPassed * monthsPerPeriod);
          }
          baseDate = candidate;
          break;
      }
    }
    
    // Calculate number of payments needed
    final paymentsNeeded = (remainingBalanceMinorUnits / paymentAmount).ceil();
    if (paymentsNeeded <= 0) return baseDate;

    // Sanity check
    if (paymentsNeeded > maxReasonablePayments) return null;

    final additionalPeriods = paymentsNeeded - 1;
    
    switch (frequency) {
      case RecurrenceFrequency.weekly:
        return baseDate.add(Duration(days: additionalPeriods * 7));
      case RecurrenceFrequency.biweekly:
        return baseDate.add(Duration(days: additionalPeriods * 14));
      case RecurrenceFrequency.monthly:
        return month_math.addMonths(baseDate, additionalPeriods);
      case RecurrenceFrequency.quarterly:
        return month_math.addMonths(baseDate, additionalPeriods * 3);
      case RecurrenceFrequency.yearly:
        return month_math.addMonths(baseDate, additionalPeriods * 12);
    }
  }
}
