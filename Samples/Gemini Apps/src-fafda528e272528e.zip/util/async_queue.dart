import 'dart:async';

/// Exception thrown when a task in [AsyncQueue] exceeds its timeout.
class AsyncQueueTimeoutException implements Exception {
  const AsyncQueueTimeoutException(this.timeout);

  final Duration timeout;

  @override
  String toString() =>
      'AsyncQueueTimeoutException: Task exceeded timeout of ${timeout.inMilliseconds}ms';
}

/// Ensures async tasks execute sequentially (FIFO).
///
/// Prevents race conditions when multiple async operations need to run
/// one-at-a-time in order. Useful for preventing concurrent writes to
/// SharedPreferences or other resources.
///
/// Example:
/// ```dart
/// final queue = AsyncQueue();
///
/// // These will execute sequentially, not concurrently
/// queue.enqueue(() => saveToDatabase(data1));
/// queue.enqueue(() => saveToDatabase(data2));
/// queue.enqueue(() => saveToDatabase(data3));
///
/// // With timeout (optional):
/// queue.enqueue(
///   () => saveToDatabase(data4),
///   timeout: Duration(seconds: 30),
/// );
/// ```
class AsyncQueue {
  /// Creates an AsyncQueue with an optional default timeout.
  ///
  /// If [defaultTimeout] is provided, all tasks will use this timeout
  /// unless overridden in [enqueue].
  AsyncQueue({this.defaultTimeout});

  /// Default timeout applied to all tasks unless overridden.
  final Duration? defaultTimeout;

  Future<void>? _current;
  int _queueDepth = 0;

  /// Returns the current number of pending tasks in the queue.
  int get queueDepth => _queueDepth;

  /// Enqueues a task to run after all previous tasks complete.
  ///
  /// Returns a Future that completes with the task's result, or
  /// completes with an error if the task throws.
  ///
  /// If [timeout] is provided (or [defaultTimeout] was set), the task
  /// will fail with [AsyncQueueTimeoutException] if it exceeds the timeout.
  /// Note: The task continues running in the background even after timeout.
  Future<T> enqueue<T>(
    Future<T> Function() task, {
    Duration? timeout,
  }) {
    final completer = Completer<T>();
    final effectiveTimeout = timeout ?? defaultTimeout;
    _queueDepth++;

    _current = (_current ?? Future.value()).then((_) async {
      try {
        Future<T> taskFuture = task();

        // Apply timeout if specified
        if (effectiveTimeout != null) {
          taskFuture = taskFuture.timeout(
            effectiveTimeout,
            onTimeout: () => throw AsyncQueueTimeoutException(effectiveTimeout),
          );
        }

        final result = await taskFuture;
        completer.complete(result);
      } catch (error, stackTrace) {
        completer.completeError(error, stackTrace);
      } finally {
        _queueDepth--;
      }
    });

    return completer.future;
  }

  /// Clears all pending tasks from the queue.
  ///
  /// Does not cancel the currently running task, only prevents
  /// future tasks from executing.
  void clear() {
    _current = null;
    _queueDepth = 0;
  }
}
