import 'dart:convert';
import 'package:cryptography/cryptography.dart';

/// Utility class for encrypting and decrypting data using AES-GCM and PBKDF2.
class EncryptionUtil {
  const EncryptionUtil._();

  static final _cipher = AesGcm.with256bits();
  static final _kdf = Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: 100000,
    bits: 256,
  );

  /// Encrypts [data] using the provided [password].
  ///
  /// Uses AES-GCM for authenticated encryption and PBKDF2 with 100k iterations
  /// and SHA-256 for key derivation.
  ///
  /// Returns a map containing the version, salt, nonce, ciphertext, and MAC.
  static Future<Map<String, String>> encrypt(String data, String password) async {
    final salt = SecretKeyData.random(length: 16).bytes;
    final secretKey = await _kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(password)),
      nonce: salt,
    );

    final secretBox = await _cipher.encrypt(
      utf8.encode(data),
      secretKey: secretKey,
    );

    return {
      'v': '1',
      's': base64.encode(salt),
      'n': base64.encode(secretBox.nonce),
      'c': base64.encode(secretBox.cipherText),
      'm': base64.encode(secretBox.mac.bytes),
    };
  }

  /// Decrypts [encrypted] data using the provided [password].
  ///
  /// Expects a map with 's' (salt), 'n' (nonce), 'c' (ciphertext), and 'm' (MAC).
  ///
  /// Throws [FormatException] if encryption version is unsupported or if
  /// decryption fails (e.g., wrong password or corrupted data).
  static Future<String> decrypt(Map<String, dynamic> encrypted, String password) async {
    final v = encrypted['v'];
    if (v != '1') {
      throw const FormatException('Unsupported encryption version');
    }

    final salt = base64.decode(encrypted['s'] as String);
    final nonce = base64.decode(encrypted['n'] as String);
    final cipherText = base64.decode(encrypted['c'] as String);
    final mac = base64.decode(encrypted['m'] as String);

    final secretKey = await _kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(password)),
      nonce: salt,
    );

    try {
      final clearTextData = await _cipher.decrypt(
        SecretBox(cipherText, nonce: nonce, mac: Mac(mac)),
        secretKey: secretKey,
      );
      return utf8.decode(clearTextData);
    } catch (e) {
      throw const FormatException('Decryption failed. Incorrect password?');
    }
  }
}
