import 'package:flutter/foundation.dart';

/// Severity levels for error reporting.
enum ErrorSeverity {
  /// Informational message, no action required.
  info,

  /// Warning that doesn't prevent functionality.
  warning,

  /// Error that affects functionality but app can continue.
  error,

  /// Critical error that may crash or corrupt data.
  critical,
}

/// Error context for structured error tracking.
class ErrorContext {
  const ErrorContext({
    required this.category,
    required this.message,
    required this.severity,
    this.error,
    this.stackTrace,
    this.userId,
    this.additionalData,
  });

  final String category;
  final String message;
  final ErrorSeverity severity;
  final Object? error;
  final StackTrace? stackTrace;
  final String? userId;
  final Map<String, dynamic>? additionalData;

  /// Convert to JSON for persistence or analytics.
  Map<String, dynamic> toJson() {
    return {
      'timestamp': DateTime.now().toIso8601String(),
      'category': category,
      'message': message,
      'severity': severity.name,
      'error': error?.toString(),
      'stackTrace': stackTrace?.toString(),
      'userId': userId,
      'additionalData': additionalData,
    };
  }

  @override
  String toString() {
    final buffer = StringBuffer();
    buffer.writeln('[$category] ${severity.name.toUpperCase()}: $message');
    if (error != null) buffer.writeln('Error: $error');
    if (additionalData != null && additionalData!.isNotEmpty) {
      buffer.writeln('Context: $additionalData');
    }
    return buffer.toString();
  }
}

/// Central error tracking and logging service.
///
/// Provides:
/// - Structured error logging with context
/// - Error aggregation and statistics
/// - Integration points for analytics/crash reporting
/// - Error history for debugging
class ErrorTracker {
  ErrorTracker._();

  static final ErrorTracker instance = ErrorTracker._();

  final List<ErrorContext> _errorHistory = [];
  static const int _maxHistorySize = 100;

  /// Track an error with full context.
  ///
  /// Example:
  /// ```dart
  /// ErrorTracker.instance.trackError(
  ///   ErrorContext(
  ///     category: 'authentication',
  ///     message: 'Failed to verify PIN',
  ///     severity: ErrorSeverity.error,
  ///     error: exception,
  ///     stackTrace: stack,
  ///     additionalData: {'attemptCount': 3},
  ///   ),
  /// );
  /// ```
  void trackError(ErrorContext context) {
    // Add to history
    _errorHistory.add(context);
    if (_errorHistory.length > _maxHistorySize) {
      _errorHistory.removeAt(0);
    }

    // Log to console in debug mode
    if (kDebugMode) {
      _logToConsole(context);
    }

    // TODO: Integration points for production error tracking:
    // - Firebase Crashlytics: FirebaseCrashlytics.instance.recordError(...)
    // - Sentry: Sentry.captureException(...)
    // - Custom analytics service
  }

  /// Track an error from an exception and stack trace.
  void trackException(
    String category,
    String message,
    Object error,
    StackTrace stackTrace, {
    ErrorSeverity severity = ErrorSeverity.error,
    Map<String, dynamic>? additionalData,
  }) {
    trackError(
      ErrorContext(
        category: category,
        message: message,
        severity: severity,
        error: error,
        stackTrace: stackTrace,
        additionalData: additionalData,
      ),
    );
  }

  /// Get recent error history.
  List<ErrorContext> getRecentErrors({int? limit}) {
    if (limit == null) return List.unmodifiable(_errorHistory);
    final start = (_errorHistory.length - limit).clamp(0, _errorHistory.length);
    return List.unmodifiable(_errorHistory.sublist(start));
  }

  /// Get error statistics grouped by category.
  Map<String, int> getErrorStatistics() {
    final stats = <String, int>{};
    for (final error in _errorHistory) {
      stats[error.category] = (stats[error.category] ?? 0) + 1;
    }
    return stats;
  }

  /// Get errors by severity.
  List<ErrorContext> getErrorsBySeverity(ErrorSeverity severity) {
    return _errorHistory.where((e) => e.severity == severity).toList();
  }

  /// Get critical errors that need immediate attention.
  List<ErrorContext> getCriticalErrors() {
    return getErrorsBySeverity(ErrorSeverity.critical);
  }

  /// Clear error history (useful for testing or after fixing issues).
  void clearHistory() {
    _errorHistory.clear();
  }

  /// Get total error count.
  int get errorCount => _errorHistory.length;

  /// Check if there are any critical errors.
  bool get hasCriticalErrors =>
      _errorHistory.any((e) => e.severity == ErrorSeverity.critical);

  void _logToConsole(ErrorContext context) {
    final timestamp = DateTime.now().toIso8601String();
    final severityIcon = _getSeverityIcon(context.severity);

    debugPrint('$timestamp $severityIcon ${context.toString()}');

    if (context.stackTrace != null) {
      final lines = context.stackTrace.toString().split('\n').take(5);
      for (final line in lines) {
        debugPrint('  $line');
      }
    }
  }

  String _getSeverityIcon(ErrorSeverity severity) {
    return switch (severity) {
      ErrorSeverity.info => 'ℹ️',
      ErrorSeverity.warning => '⚠️',
      ErrorSeverity.error => '❌',
      ErrorSeverity.critical => '🔥',
    };
  }
}

/// Extension for easier error tracking.
extension ErrorTrackingExtension on Object {
  /// Track this object as an error.
  void trackAsError(
    String category,
    String message, {
    StackTrace? stackTrace,
    ErrorSeverity severity = ErrorSeverity.error,
    Map<String, dynamic>? additionalData,
  }) {
    ErrorTracker.instance.trackException(
      category,
      message,
      this,
      stackTrace ?? StackTrace.current,
      severity: severity,
      additionalData: additionalData,
    );
  }
}
