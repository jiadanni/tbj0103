


String monthLabel(DateTime month) {
  const names = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${names[month.month - 1]} ${month.year}';
}

DateTime monthOnly(DateTime value) => DateTime.utc(value.year, value.month);

DateTime dateOnly(DateTime value) =>
    DateTime.utc(value.year, value.month, value.day);

