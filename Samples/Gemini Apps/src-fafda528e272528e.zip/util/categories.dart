/// Predefined category suggestions for expenses and income.
/// 
/// These are suggestions to help users organize their payments.
/// Users can also enter custom categories freely.
library;

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

/// Common expense categories
const expenseCategories = <String>[
  'Housing',
  'Utilities',
  'Groceries',
  'Dining',
  'Transportation',
  'Insurance',
  'Health',
  'Entertainment',
  'Shopping',
  'Education',
  'Personal Care',
  'Pet Care',
  'Gym/Fitness',
  'Subscriptions',
  'Office Supplies',
  'Gifts',
  'Travel',
  'Repairs',
  'Fuel',
  'Phone/Internet',
];

/// Common income categories
const incomeCategories = <String>[
  'Salary',
  'Freelance',
  'Bonus',
  'Investment',
  'Refund',
  'Gift',
  'Side Gig',
  'Dividend',
  'Rental',
  'Business',
];

/// Get category suggestions for a given payment type
/// 
/// Returns appropriate category suggestions based on whether the payment
/// is an income or expense type, and the current [CategoryPresetMode].
List<String> getCategorySuggestions({
  required bool isIncome,
  required CategoryPresetMode mode,
  List<String> userCategories = const [],
}) {
  final presets = isIncome ? incomeCategories : expenseCategories;
  
  switch (mode) {
    case CategoryPresetMode.defaultPresets:
      return presets;
    case CategoryPresetMode.customOnly:
      return userCategories;
    case CategoryPresetMode.both:
      // Merge and deduplicate
      final all = <String>{...presets, ...userCategories};
      return all.toList()..sort();
  }
}

/// Get all available categories
List<String> getAllCategories() {
  return [...expenseCategories, ...incomeCategories];
}

/// Check if a category is from a predefined list
bool isPredefinedCategory(String category) {
  return expenseCategories.contains(category) || incomeCategories.contains(category);
}
