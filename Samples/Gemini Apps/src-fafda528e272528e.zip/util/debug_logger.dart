import 'package:flutter/foundation.dart';

/// Log categories for structured debug logging.
enum LogCategory {
  persistence('PERSIST'),
  state('STATE'),
  ui('UI'),
  network('NETWORK');

  const LogCategory(this.prefix);
  final String prefix;
}

/// Logs a debug message with optional error and stack trace.
///
/// Only logs in debug mode (kDebugMode). Formatting includes:
/// - ISO 8601 timestamp
/// - Category prefix [PERSIST], [STATE], etc.
/// - Message
/// - Optional error object
/// - Optional stack trace (first 5 lines)
///
/// Example:
/// ```dart
/// debugLog(
///   LogCategory.persistence,
///   'Failed to save data',
///   error: exception,
///   stackTrace: stack,
/// );
/// ```
void debugLog(
  LogCategory category,
  String message, {
  Object? error,
  StackTrace? stackTrace,
}) {
  if (!kDebugMode) return;

  final timestamp = DateTime.now().toIso8601String();
  final prefix = '[${category.prefix}]';

  debugPrint('$timestamp $prefix $message');

  if (error != null) {
    debugPrint('  Error: $error');
  }

  if (stackTrace != null) {
    final lines = stackTrace.toString().split('\n').take(5);
    for (final line in lines) {
      debugPrint('  $line');
    }
  }
}
