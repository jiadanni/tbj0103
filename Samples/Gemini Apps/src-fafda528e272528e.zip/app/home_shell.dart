import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/features/payments/payments_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_screen.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tabIndex = 0;
  late final PageController _pageController;
  bool _hasUserNavigated = false; // Track if user has explicitly navigated

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _tabIndex);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Sync tab index with persisted view mode on initial load ONLY
    // Don't sync if user has already navigated (prevents overriding user's choice)
    if (_hasUserNavigated) return;
    
    final settings = AppSettingsScope.read(context);
    final viewMode = settings.plannerViewMode;
    final desiredIndex = _viewModeToTabIndex(viewMode);
    
    // Sync the tab index if it doesn't match the persisted view mode
    if (_tabIndex != desiredIndex) {
      setState(() {
        _tabIndex = desiredIndex;
      });
      
      // Jump to the correct page immediately
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients && !_hasUserNavigated) {
          _pageController.jumpToPage(_tabIndex);
        }
      });
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  int _viewModeToTabIndex(PlannerViewMode mode) {
    return switch (mode) {
      PlannerViewMode.month => 0,
      PlannerViewMode.grid => 1,
      PlannerViewMode.sheet => 2,
    };
  }

  PlannerViewMode _tabIndexToViewMode(int index) {
    return switch (index) {
      0 => PlannerViewMode.month,
      1 => PlannerViewMode.grid,
      2 => PlannerViewMode.sheet,
      _ => PlannerViewMode.month,
    };
  }

  void _onDestinationSelected(int index) {
    final settings = AppSettingsScope.read(context);
    _hasUserNavigated = true; // Mark that user has navigated
    setState(() => _tabIndex = index);
    
    // Update view mode for planner tabs (0-2)
    if (index < 3) {
      settings.plannerViewMode = _tabIndexToViewMode(index);
    }
    
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final terminology = Terminology.of(context);
    final l10n = AppLocalizations.of(context)!;
    
    // All 4 tabs: 3 planner view modes + payments
    final List<Widget> tabs = const [
      PlannerScreen(viewMode: PlannerViewMode.month), // Month view
      PlannerScreen(viewMode: PlannerViewMode.grid), // Grid view
      PlannerScreen(viewMode: PlannerViewMode.sheet), // Sheet view
      PaymentsScreen(),
    ];

    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: settings.enableTabSwipe
            ? const PageScrollPhysics()
            : const NeverScrollableScrollPhysics(),
        onPageChanged: (index) {
          _hasUserNavigated = true; // Mark that user has navigated
          setState(() => _tabIndex = index);
          // Sync view mode when swiping between planner tabs
          if (index < 3) {
            settings.plannerViewMode = _tabIndexToViewMode(index);
          }
        },
        children: tabs,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: _onDestinationSelected,
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.calendar_view_day_outlined),
            selectedIcon: const Icon(Icons.calendar_view_day),
            label: 'Month',
          ),
          NavigationDestination(
            icon: const Icon(Icons.grid_view_outlined),
            selectedIcon: const Icon(Icons.grid_view),
            label: 'Grid',
          ),
          NavigationDestination(
            icon: const Icon(Icons.table_chart_outlined),
            selectedIcon: const Icon(Icons.table_chart),
            label: 'Sheet',
          ),
          NavigationDestination(
            icon: const Icon(Icons.payments_outlined),
            selectedIcon: const Icon(Icons.payments),
            label: terminology.listTabLabel,
          ),
        ],
      ),
    );
  }
}
