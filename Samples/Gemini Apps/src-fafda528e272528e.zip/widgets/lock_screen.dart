import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Lock screen that requires authentication to access the app.
class LockScreen extends StatefulWidget {
  const LockScreen({
    super.key,
    required this.authService,
    required this.onUnlock,
    this.onAuthStateChanged,
  });

  final AuthService authService;
  final VoidCallback onUnlock;
  /// Called when authentication state changes (true = started, false = ended)
  final ValueChanged<bool>? onAuthStateChanged;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final TextEditingController _pinController = TextEditingController();
  bool _showPinInput = false;
  String _errorMessage = '';
  bool _isBiometricAvailable = false;
  bool _useBiometrics = false;
  bool _hasPin = false;
  bool _isReady = false;
  bool _hasFaceId = false;
  int _lockoutSecondsRemaining = 0;
  int _remainingAttempts = 5;
  bool _isInitialized = false;
  bool _biometricInProgress = false;

  @override
  void initState() {
    super.initState();
    // Validating biometrics requires async calls, done in _initializeLockScreen
    _initializeLockScreen();
  }

  Future<void> _initializeLockScreen() async {
    // Prevent multiple initializations
    if (_isInitialized) return;
    _isInitialized = true;

    // Load PIN presence asynchronously (may use secure storage)
    _hasPin = await widget.authService.hasPIN();
    _useBiometrics = await widget.authService.useBiometrics();
    // Wait for biometric check to complete first to avoid race conditions
    await _checkBiometrics();
    if (!mounted) return;

    final canUseBiometrics = _isBiometricAvailable && _useBiometrics;
    setState(() {
      _isReady = true;
      // Show PIN input only if biometrics are not available/enabled
      _showPinInput = !canUseBiometrics && _hasPin;
    });

    // Auto-trigger biometric auth after a short delay to let UI render
    if (mounted && _isReady && canUseBiometrics) {
      // Use a longer delay and ensure we're still the active screen
      await Future.delayed(const Duration(milliseconds: 500));
      if (mounted && !_biometricInProgress && _isInitialized) {
        _tryBiometricAuth();
      }
    }
  }

  Future<void> _checkBiometrics() async {
    final available = await widget.authService.isBiometricAvailable();
    final biometricTypes = await widget.authService.getAvailableBiometrics();
    if (!mounted) return;
    setState(() {
      _isBiometricAvailable = available;
      // Check if face recognition is available (Face ID on iOS, face unlock on Android)
      _hasFaceId = biometricTypes.any((type) =>
          type == BiometricType.face || type == BiometricType.strong);
    });
  }

  Future<void> _tryBiometricAuth() async {
    // Prevent multiple concurrent biometric attempts
    if (_biometricInProgress) return;
    if (!mounted) return;
    
    _biometricInProgress = true;
    
    // Notify parent that authentication is starting (prevents app lifecycle re-lock)
    widget.onAuthStateChanged?.call(true);

    if (!await widget.authService.useBiometrics()) {
      _biometricInProgress = false;
      widget.onAuthStateChanged?.call(false);
      if (mounted && _hasPin) {
        setState(() => _showPinInput = true);
      }
      return;
    }

    if (!mounted) {
      _biometricInProgress = false;
      widget.onAuthStateChanged?.call(false);
      return;
    }

    final available = await widget.authService.isBiometricAvailable();
    if (!available) {
      _biometricInProgress = false;
      widget.onAuthStateChanged?.call(false);
      if (mounted && _hasPin) {
        setState(() => _showPinInput = true);
      }
      return;
    }

    if (!mounted) {
      _biometricInProgress = false;
      widget.onAuthStateChanged?.call(false);
      return;
    }

    setState(() => _errorMessage = '');

    final success = await widget.authService.authenticateWithBiometrics(
      reason: 'Authenticate to access Expense Stalker',
    );

    // Check if still mounted after async biometric call
    if (!mounted) return;

    if (success) {
      // Successfully authenticated - call onUnlock immediately
      widget.onUnlock();
      // Don't reset flags - widget will be disposed
    } else {
      // Biometric failed - notify parent and allow retry or PIN entry
      widget.onAuthStateChanged?.call(false);
      _biometricInProgress = false;
      if (mounted) {
        setState(() {
          _showPinInput = _hasPin;
          if (_hasPin) {
            _errorMessage = 'Biometric authentication failed. Please use PIN.';
          }
        });
      }
    }
  }

  Future<void> _verifyPIN() async {
    final pin = _pinController.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorMessage = AppLocalizations.of(context)!.enterPIN);
      return;
    }

    try {
      final result = await widget.authService.verifyPIN(pin);
      
      switch (result) {
        case PinVerificationResult.success:
          widget.onUnlock();
          break;
          
        case PinVerificationResult.incorrectPin:
          final remaining = await widget.authService.getRemainingAttempts();
          setState(() {
            _remainingAttempts = remaining;
            if (remaining > 0) {
              _errorMessage = AppLocalizations.of(context)!.incorrectPIN +
                  ' ($remaining ${remaining == 1 ? 'attempt' : 'attempts'} remaining)';
            } else {
              _errorMessage = AppLocalizations.of(context)!.incorrectPIN;
            }
          });
          _pinController.clear();
          break;
          
        case PinVerificationResult.lockedOut:
          final lockoutSeconds = await widget.authService.getLockoutSecondsRemaining();
          setState(() {
            _lockoutSecondsRemaining = lockoutSeconds;
            _errorMessage = 'Too many attempts. Try again in $lockoutSeconds seconds.';
          });
          _pinController.clear();
          _startLockoutCountdown();
          break;
      }
    } catch (e) {
      setState(() => _errorMessage = 'Invalid PIN format');
      _pinController.clear();
    }
  }

  void _startLockoutCountdown() {
    if (_lockoutSecondsRemaining <= 0) return;
    
    Future.delayed(const Duration(seconds: 1), () async {
      if (!mounted) return;
      
      final remaining = await widget.authService.getLockoutSecondsRemaining();
      final attempts = await widget.authService.getRemainingAttempts();
      
      if (!mounted) return;
      
      setState(() {
        _lockoutSecondsRemaining = remaining;
        if (remaining > 0) {
          _errorMessage = 'Too many attempts. Try again in $remaining seconds.';
          _startLockoutCountdown();
        } else {
          _errorMessage = '';
          _remainingAttempts = attempts;
        }
      });
    });
  }

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  void _showPinEntry() {
    setState(() => _showPinInput = true);
  }

  /// Returns the appropriate icon for the available biometric type.
  IconData get _biometricIcon => _hasFaceId ? Icons.face : Icons.fingerprint;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final canUseBiometrics = _isBiometricAvailable && _useBiometrics;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Custom color palette for lock screen
    final backgroundTop = isDark ? const Color(0xFF1A1D27) : const Color(0xFFF6F7FB);
    final backgroundBottom = isDark ? const Color(0xFF0F1118) : const Color(0xFFE6EBF6);
    final surface = isDark ? const Color(0xFF1E2332) : const Color(0xFFFFFFFF);
    final surfaceAlt = isDark ? const Color(0xFF2B3144) : const Color(0xFFF0F3FA);
    final border = isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.08);
    final textPrimary = isDark ? Colors.white : Colors.black87;
    final textSecondary = isDark ? Colors.white70 : Colors.black54;
    final themeColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      body: Stack(
        children: [
          // Gradient background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [backgroundTop, backgroundBottom],
              ),
            ),
          ),
          // Subtle glow orbs for depth
          if (isDark) ...[
            Positioned(
              top: -100,
              right: -50,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      themeColor.withValues(alpha: 0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -50,
              left: -100,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      themeColor.withValues(alpha: 0.1),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ],
          // Main content
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppConstants.paddingLarge),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Lock icon with styled container
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            surface,
                            surfaceAlt,
                          ],
                        ),
                        border: Border.all(color: border),
                        boxShadow: [
                          BoxShadow(
                            color: isDark
                                ? Colors.black.withValues(alpha: 0.3)
                                : Colors.black.withValues(alpha: 0.08),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.lock_outline,
                        size: 48,
                        color: textSecondary,
                      ),
                    ),
                    const SizedBox(height: AppConstants.paddingXLarge),
                    Text(
                      l10n.unlockApp,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: textPrimary,
                          ),
                    ),
                    const SizedBox(height: AppConstants.paddingSmall),
                    Text(
                      canUseBiometrics ? l10n.useBiometric : l10n.unlockWithPIN,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: textSecondary,
                          ),
                    ),
                    const SizedBox(height: AppConstants.paddingLarge * 2), // 48
                    // Show biometrics button first (primary auth method when enabled)
                    // Hide this block when user has chosen to show PIN input
                    if (_isReady && canUseBiometrics && !_showPinInput) ...[
                      _StyledButton(
                        onPressed: _tryBiometricAuth,
                        icon: _biometricIcon,
                        label: l10n.useBiometric,
                        isPrimary: true,
                        surface: surface,
                        border: border,
                        textColor: textPrimary,
                        themeColor: themeColor,
                      ),
                      if (_hasPin) ...[
                        const SizedBox(height: 16),
                        _StyledButton(
                          onPressed: _showPinEntry,
                          icon: Icons.pin,
                          label: l10n.unlockWithPIN,
                          isPrimary: false,
                          surface: surface,
                          border: border,
                          textColor: textSecondary,
                          themeColor: themeColor,
                        ),
                      ],
                    ],
                    // Show PIN input when biometrics unavailable OR user chose to use PIN
                    if (_showPinInput) ...[
                      const SizedBox(height: 16),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 300),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(AppConstants.radiusXLarge),
                            color: surface,
                            border: Border.all(color: border),
                            boxShadow: [
                              BoxShadow(
                                color: isDark
                                    ? Colors.black.withValues(alpha: 0.2)
                                    : Colors.black.withValues(alpha: 0.05),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: TextField(
                            controller: _pinController,
                            enabled: _lockoutSecondsRemaining == 0,
                            decoration: InputDecoration(
                              labelText: l10n.pin,
                              labelStyle: TextStyle(color: textSecondary),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(AppConstants.radiusXLarge),
                                borderSide: BorderSide.none,
                              ),
                              filled: true,
                              fillColor: Colors.transparent,
                              errorText: _errorMessage.isEmpty ? null : _errorMessage,
                              prefixIcon: Icon(Icons.pin, color: textSecondary),
                              counterText: '', // Hide character count
                            ),
                            style: TextStyle(color: textPrimary),
                            keyboardType: TextInputType.number,
                            obscureText: true,
                            maxLength: AuthService.maxPinLength,
                            onSubmitted: (_) => _lockoutSecondsRemaining == 0 ? _verifyPIN() : null,
                            autofocus: !canUseBiometrics,
                          ),
                        ),
                      ),
                      const SizedBox(height: AppConstants.paddingLarge - 4), // 20
                      _StyledButton(
                        onPressed: _lockoutSecondsRemaining == 0 ? _verifyPIN : () {},
                        icon: Icons.lock_open,
                        label: l10n.unlock,
                        isPrimary: true,
                        surface: surface,
                        border: border,
                        textColor: textPrimary,
                        themeColor: themeColor,
                      ),
                      // Show biometric option as secondary when PIN is visible
                      if (canUseBiometrics) ...[
                        const SizedBox(height: 16),
                        _StyledButton(
                          onPressed: _tryBiometricAuth,
                          icon: _biometricIcon,
                          label: l10n.useBiometric,
                          isPrimary: false,
                          surface: surface,
                          border: border,
                          textColor: textSecondary,
                          themeColor: themeColor,
                        ),
                      ],
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A styled button that matches the app's visual theme.
class _StyledButton extends StatelessWidget {
  const _StyledButton({
    required this.onPressed,
    required this.icon,
    required this.label,
    required this.isPrimary,
    required this.surface,
    required this.border,
    required this.textColor,
    required this.themeColor,
  });

  final VoidCallback onPressed;
  final IconData icon;
  final String label;
  final bool isPrimary;
  final Color surface;
  final Color border;
  final Color textColor;
  final Color themeColor;

  @override
  Widget build(BuildContext context) {
    if (isPrimary) {
      return Container(
        constraints: const BoxConstraints(maxWidth: 300),
        width: double.infinity,
        height: AppConstants.buttonHeightPrimary,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppConstants.radiusXLarge),
          gradient: LinearGradient(
            colors: [
              themeColor,
              themeColor.withValues(alpha: 0.8),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: Colors.white),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Secondary button style
    return Container(
      constraints: const BoxConstraints(maxWidth: 300),
      width: double.infinity,
      height: AppConstants.buttonHeightSecondary,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
        color: surface,
        border: Border.all(color: border),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: textColor, size: 20),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
