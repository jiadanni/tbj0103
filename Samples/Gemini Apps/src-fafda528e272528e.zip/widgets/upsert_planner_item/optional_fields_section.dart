import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'upsert_planner_item_style.dart';

class OptionalFieldsSection extends StatefulWidget {
  const OptionalFieldsSection({
    super.key,
    required this.categoryController,
    required this.categoryFocusNode,
    required this.categoryLayerLink,
    required this.selectedCategory,
    required this.companyController,
    required this.isSalary,
    required this.isQuickAdd,
    required this.notesController,
    required this.isIncomeMode,
    required this.type,
    required this.onCategorySelected,
    required this.onIsSalaryChanged,
    required this.onIsQuickAddChanged,
    required this.selectedMoneyPotId,
    required this.onMoneyPotChanged,
    this.remainingBalanceController,
    this.balanceCurrency,
    this.onBalanceCurrencyChanged,
    required this.useActualsForBalance,
    required this.onUseActualsChanged,
    required this.buildCompactCheckbox,
  });

  final TextEditingController categoryController;
  final FocusNode categoryFocusNode;
  final LayerLink categoryLayerLink;
  final String? selectedCategory;
  final TextEditingController companyController;
  final bool isSalary;
  final bool isQuickAdd;
  final TextEditingController notesController;
  final bool isIncomeMode;
  final PaymentType type;
  final ValueChanged<String?> onCategorySelected;
  final ValueChanged<bool> onIsSalaryChanged;
  final ValueChanged<bool> onIsQuickAddChanged;
  final MoneyPotId? selectedMoneyPotId;
  final ValueChanged<MoneyPotId?> onMoneyPotChanged;
  final TextEditingController? remainingBalanceController;
  final AppCurrency? balanceCurrency;
  final ValueChanged<AppCurrency?>? onBalanceCurrencyChanged;
  final bool useActualsForBalance;
  final ValueChanged<bool> onUseActualsChanged;
  
  /// Callback to build the compact checkbox which depends on parent theme state
  final Widget Function({
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) buildCompactCheckbox;

  @override
  State<OptionalFieldsSection> createState() => _OptionalFieldsSectionState();
}

class _OptionalFieldsSectionState extends State<OptionalFieldsSection> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;
    final surfaceVariant = colorScheme.surfaceContainerLow;
    
    final settings = AppSettingsScope.of(context);
    final store = ExpenseStoreScope.read(context);

    return Container(
      decoration: BoxDecoration(
        color: surfaceVariant,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          // Header tap area
          InkWell(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.tune_outlined, size: 16, color: textSecondary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      l10n.moreOptions,
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.5 : 0,
                    duration: AppConstants.animationNormal,
                    child: Icon(Icons.keyboard_arrow_down, size: 18, color: textSecondary),
                  ),
                ],
              ),
            ),
          ),
          // Expandable content
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category & Company row with labels
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: l10n.category,
                          child: RawAutocomplete<String>(
                            textEditingController: widget.categoryController,
                            focusNode: widget.categoryFocusNode,
                            optionsBuilder: (TextEditingValue textEditingValue) {
                              final suggestions = getCategorySuggestions(
                                isIncome: widget.isIncomeMode,
                                mode: settings.categoryPresetMode,
                                userCategories: store.getUserCategories(isIncome: widget.isIncomeMode),
                              );

                              if (textEditingValue.text.isEmpty) {
                                return suggestions;
                              }
                              return suggestions.where((option) {
                                return option.toLowerCase().contains(textEditingValue.text.toLowerCase());
                              });
                            },
                            onSelected: (String selection) {
                              widget.onCategorySelected(selection);
                            },
                            fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
                              return CompositedTransformTarget(
                                link: widget.categoryLayerLink,
                                child: TextField(
                                  controller: controller,
                                  focusNode: focusNode,
                                  style: TextStyle(color: textPrimary, fontSize: 14),
                                  decoration: UpsertPlannerItemStyle.compactInput(context, 'Select or type', floatingLabel: false),
                                  onChanged: (value) {
                                    widget.onCategorySelected(value.trim().isEmpty ? null : value.trim());
                                  },
                                  onSubmitted: (_) => onFieldSubmitted(),
                                ),
                              );
                            },
                            optionsViewBuilder: (context, onSelected, options) {
                              return CompositedTransformFollower(
                                link: widget.categoryLayerLink,
                                showWhenUnlinked: false,
                                offset: const Offset(0, 40),
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Material(
                                    elevation: 8.0,
                                    borderRadius: BorderRadius.circular(8),
                                    color: surface,
                                    child: Container(
                                      width: 180,
                                      constraints: const BoxConstraints(maxHeight: 180),
                                      child: ListView.builder(
                                        padding: const EdgeInsets.symmetric(vertical: 4),
                                        shrinkWrap: true,
                                        itemCount: options.length,
                                        itemBuilder: (BuildContext context, int index) {
                                          final option = options.elementAt(index);
                                          return InkWell(
                                            onTap: () => onSelected(option),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                              child: Text(
                                                option,
                                                style: TextStyle(color: textPrimary, fontSize: 13),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: 'Company',
                          child: TextField(
                            controller: widget.companyController,
                            style: TextStyle(color: textPrimary, fontSize: 14),
                            decoration: UpsertPlannerItemStyle.compactInput(context, 'Enter company', floatingLabel: false),
                          ),
                        ),
                      ),
                    ],
                  ),
                  // Salary toggle - only for recurring income
                  if (widget.isIncomeMode && widget.type == PaymentType.recurringIncome) ...[
                    const SizedBox(height: 8),
                    widget.buildCompactCheckbox(
                      value: widget.isSalary,
                      onChanged: (v) => widget.onIsSalaryChanged(v ?? false),
                      label: l10n.primarySalary,
                      subtitle: l10n.primarySalaryHint,
                    ),
                  ],
                  const SizedBox(height: 8),
                  widget.buildCompactCheckbox(
                    value: widget.isQuickAdd,
                    onChanged: (v) => widget.onIsQuickAddChanged(v ?? false),
                    label: 'Quick Add Capability',
                    subtitle: 'Enable quick adding from planner screen',
                  ),
                  const SizedBox(height: 12),

                  // Spending Envelope Options
                  if (widget.type == PaymentType.spendingEnvelope) ...[
                    widget.buildCompactCheckbox(
                      value: widget.useActualsForBalance,
                      onChanged: (v) => widget.onUseActualsChanged(v ?? false),
                      label: 'Deduct Only Actual Spent',
                      subtitle: 'Current month reserves full budget; Future months deduct only actuals',
                    ),
                    const SizedBox(height: 12),
                  ],

                  // Track in Money Pots (for recurring expenses)
                  if (!widget.isIncomeMode && widget.type == PaymentType.recurring) ...[
                    // Toggle switch
                    SwitchListTile(
                      title: Text(
                        'Track in Money Pots',
                        style: TextStyle(fontSize: 13, color: textPrimary, fontWeight: FontWeight.w500),
                      ),
                      subtitle: Text(
                        widget.selectedMoneyPotId != null 
                          ? 'Automatic pot created with this name'
                          : 'Keeps a running balance of payments',
                        style: TextStyle(fontSize: 11, color: textSecondary),
                      ),
                      value: widget.selectedMoneyPotId != null,
                      onChanged: (bool value) {
                        if (value) {
                           widget.onMoneyPotChanged(const MoneyPotId('enable_smart_tracking'));
                        } else {
                          widget.onMoneyPotChanged(null);
                        }
                      },
                      contentPadding: EdgeInsets.zero,
                      visualDensity: VisualDensity.compact,
                    ),
                    
                    if (widget.selectedMoneyPotId != null) ...[
                      const SizedBox(height: 6),
                      // Balance Field
                      if (widget.remainingBalanceController != null) ...[
                        UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: 'Pot Balance',
                          child: TextField(
                            controller: widget.remainingBalanceController,
                            style: TextStyle(color: textPrimary, fontSize: 14),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              decoration: UpsertPlannerItemStyle.compactInput(
                                context,
                                'Current balance',
                                prefixText: currencySymbol(widget.balanceCurrency ?? settings.currencySettings.currency),
                              ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                    ],
                  ],

                  // Notes field with label
                  UpsertPlannerItemStyle.labeledField(
                    context: context,
                    label: 'Notes',
                    child: TextField(
                      controller: widget.notesController,
                      style: TextStyle(color: textPrimary, fontSize: 14),
                      decoration: UpsertPlannerItemStyle.compactInput(context, 'Add notes (optional)', floatingLabel: false),
                      maxLength: AppConstants.maxNotesLength,
                      maxLines: 2,
                      textInputAction: TextInputAction.done,
                    ),
                  ),
                ],
              ),
            ),
            crossFadeState: _isExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: AppConstants.animationNormal,
          ),
        ],
      ),
    );
  }
}
