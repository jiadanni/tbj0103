import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

class PlannerItemTypeSelector extends StatelessWidget {
  const PlannerItemTypeSelector({
    super.key,
    required this.type,
    required this.isIncomeMode,
    required this.onTypeChanged,
  });

  final PaymentType type;
  final bool isIncomeMode;
  final ValueChanged<PaymentType> onTypeChanged;

  @override
  Widget build(BuildContext context) {
    final subtypes = isIncomeMode
        ? [PaymentType.recurringIncome, PaymentType.oneOffIncome]
        : [
            PaymentType.recurring,
            PaymentType.oneOff,
            PaymentType.debt,
            PaymentType.spendingEnvelope
          ];

    return Wrap(
      spacing: 6,
      runSpacing: 4,
      children: subtypes.map((t) {
        final isSelected = type == t;
        return ChoiceChip(
          label: Text(
            _getShortLabel(t),
            style: TextStyle(
              fontSize: 11,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
          selected: isSelected,
          onSelected: (selected) {
            if (selected) onTypeChanged(t);
          },
          showCheckmark: false,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          labelPadding: EdgeInsets.zero,
          visualDensity: VisualDensity.compact,
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        );
      }).toList(),
    );
  }

  String _getShortLabel(PaymentType type) {
    switch (type) {
      case PaymentType.recurring:
      case PaymentType.recurringIncome:
        return 'Recurring';
      case PaymentType.oneOff:
      case PaymentType.oneOffIncome:
        return 'One-off';
      case PaymentType.debt:
        return 'Debt';
      case PaymentType.spendingEnvelope:
        return 'Envelope';
    }
  }
}

class IncomeExpenseToggle extends StatelessWidget {
  const IncomeExpenseToggle({
    super.key,
    required this.isIncomeMode,
    required this.accentIncome,
    required this.accentExpense,
    required this.onToggle,
  });

  final bool isIncomeMode;
  final Color accentIncome;
  final Color accentExpense;
  final ValueChanged<bool> onToggle;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final surfaceVariant = colorScheme.surfaceContainerLow;

    return Container(
      decoration: BoxDecoration(
        color: surfaceVariant,
        borderRadius: BorderRadius.circular(6),
      ),
      padding: const EdgeInsets.all(2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildMiniToggle(
            context: context,
            label: 'Expense',
            isSelected: !isIncomeMode,
            color: accentExpense,
            onTap: () => onToggle(false),
          ),
          _buildMiniToggle(
            context: context,
            label: 'Income',
            isSelected: isIncomeMode,
            color: accentIncome,
            onTap: () => onToggle(true),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniToggle({
    required BuildContext context,
    required String label,
    required bool isSelected,
    required Color color,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: AppConstants.animationFast,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? color.withValues(alpha: 0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            color: isSelected ? color : (isDark ? Colors.white54 : Colors.black45),
          ),
        ),
      ),
    );
  }
}
