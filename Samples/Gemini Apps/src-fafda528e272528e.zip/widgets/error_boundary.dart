import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';

/// Error boundary widget that catches and handles exceptions in child widgets.
///
/// Prevents single UI errors from crashing the entire app by displaying
/// a fallback error UI instead of propagating the exception.
///
/// Usage:
/// ```dart
/// ErrorBoundary(
///   child: MyScreen(),
/// )
/// ```
class ErrorBoundary extends StatefulWidget {
  const ErrorBoundary({
    super.key,
    required this.child,
    this.fallback,
  });

  final Widget child;
  final Widget Function(Object error, StackTrace? stackTrace)? fallback;

  @override
  State<ErrorBoundary> createState() => _ErrorBoundaryState();
}

class _ErrorBoundaryState extends State<ErrorBoundary> {
  Object? _error;
  StackTrace? _stackTrace;
  ErrorWidgetBuilder? _previousErrorWidgetBuilder;

  @override
  void initState() {
    super.initState();
    // Reset error state when boundary is recreated
    _error = null;
    _stackTrace = null;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Catch errors during build
    // Avoid changing the global ErrorWidget.builder during widget tests.
    // The test binding enforces the builder to remain unchanged across tests,
    // so skip overriding when the current binding is the test binding.
    final bindingType = WidgetsBinding.instance.runtimeType.toString();
    final runningUnderTest = bindingType.contains('TestWidgetsFlutterBinding');
    if (runningUnderTest) {
      return;
    }

    // Save existing builder so we can restore it later (important for tests)
    _previousErrorWidgetBuilder = ErrorWidget.builder;

    ErrorWidget.builder = (FlutterErrorDetails details) {
      // Track the error
      if (_error == null) {
        setState(() {
          _error = details.exception;
          _stackTrace = details.stack;
        });

        ErrorTracker.instance.trackException(
          'ui',
          'Widget build error',
          details.exception,
          details.stack ?? StackTrace.current,
          severity: ErrorSeverity.critical,
          additionalData: {
            'library': details.library,
            'context': details.context?.toString(),
          },
        );
      }

      return ErrorWidget(details.exception);
    };
  }

  @override
  void dispose() {
    // Restore previous ErrorWidget.builder to avoid leaking test modifications
    if (_previousErrorWidgetBuilder != null) {
      ErrorWidget.builder = _previousErrorWidgetBuilder!;
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return widget.fallback?.call(_error!, _stackTrace) ??
          _DefaultErrorWidget(
            error: _error!,
            stackTrace: _stackTrace,
            onRetry: () {
              setState(() {
                _error = null;
                _stackTrace = null;
              });
            },
          );
    }

    return widget.child;
  }
}

/// Default error widget displayed when an error is caught.
class _DefaultErrorWidget extends StatelessWidget {
  const _DefaultErrorWidget({
    required this.error,
    this.stackTrace,
    this.onRetry,
  });

  final Object error;
  final StackTrace? stackTrace;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline,
                size: 64,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 16),
              Text(
                'Something went wrong',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                error.toString(),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              if (onRetry != null) ...[
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
