import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/util/validation.dart';
import 'package:expense_stalker_mobile/src/widgets/planner_item_form_validators.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';

import 'package:expense_stalker_mobile/src/features/planner/helpers/salary_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item/upsert_planner_item_style.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item/type_selector.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item/debt_fields_section.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item/optional_fields_section.dart';

/// Bottom sheet for creating or editing a planner item.
///
/// Returns the updated [PlannerItem] on save, or null if cancelled.
class UpsertPlannerItemSheet extends StatefulWidget {
  const UpsertPlannerItemSheet({
    super.key,
    this.existing,
    required this.defaultStartDate,
  });

  /// If provided, sheet is in edit mode. If null, create mode.
  final PlannerItem? existing;

  /// The default start date to use when creating a new planner item.
  /// Typically set to the currently selected month.
  final DateTime defaultStartDate;

  @override
  State<UpsertPlannerItemSheet> createState() => _UpsertPlannerItemSheetState();
}

class _UpsertPlannerItemSheetState extends State<UpsertPlannerItemSheet> {
  static const _kNewMoneyPotId = MoneyPotId('new_money_pot');
  late final TextEditingController _labelController;
  late final TextEditingController _amountController;
  late final TextEditingController _dayController;
  late final TextEditingController _notesController;
  late final TextEditingController _remainingBalanceController;
  late final TextEditingController _categoryController;
  late final TextEditingController _companyController;
  late final FocusNode _categoryFocusNode;
  late PaymentType _type;
  RecurrenceFrequency? _frequency;
  late DateTime _startDate;
  bool _isPaidOff = false;
  String? _dayValidationError;
  String? _selectedCategory;
  late bool _isSalary;
  late bool _isQuickAdd;
  late bool _useActualsForBalance;
  final LayerLink _categoryLayerLink = LayerLink();

  bool get _isIncomeMode => _type.isIncomeType;
  bool get _isEditMode => widget.existing != null;
  MoneyPotId? _selectedMoneyPotId;
  AppCurrency? _balanceCurrency;
  late final TextEditingController _exchangeRateController;

  bool _safeBool(bool? Function() f) {
    try {
      return f() == true;
    } catch (_) {
      return false;
    }
  }

  @override
  void initState() {
    super.initState();
    _categoryFocusNode = FocusNode();
    final existing = widget.existing;
    _labelController = TextEditingController(text: existing?.label ?? '');
    // Store absolute value only - sign is determined by income/expense toggle
    _amountController = TextEditingController(
      text: existing == null
          ? ''
          : (existing.amountMinorUnits.abs() / 100).toStringAsFixed(2),
    );
    _dayController = TextEditingController(
      text: existing?.dayOfMonth.toString() ?? '',
    );
    _selectedMoneyPotId = existing?.moneyPotId;
    _balanceCurrency = existing?.balanceCurrency;

    int? initialBalanceCents = existing?.remainingBalanceMinorUnits;
    if (_selectedMoneyPotId != null) {
      final pot = AppSettingsScope.read(context).moneyPots.cast<MoneyPot?>().firstWhere(
        (p) => p?.id == _selectedMoneyPotId,
        orElse: () => null,
      );
      if (pot != null) {
        initialBalanceCents = pot.amountMinorUnits;
      }
    }

    _remainingBalanceController = TextEditingController(
      text: initialBalanceCents == null
          ? ''
          : (initialBalanceCents / 100).toStringAsFixed(2),
    );
    _notesController = TextEditingController(text: existing?.notes ?? '');
    _categoryController = TextEditingController(
      text: existing?.category ?? '',
    );
    _companyController = TextEditingController(text: existing?.company ?? '');
    _type = existing?.type ?? PaymentType.recurring;
    _frequency = existing?.frequency ??
        (_type != PaymentType.oneOff && _type != PaymentType.oneOffIncome ? RecurrenceFrequency.monthly : null);
    _startDate = existing?.startDate ?? widget.defaultStartDate;
    _isPaidOff = existing?.paidOffDate != null;
    _selectedCategory = existing?.category;
    _isSalary = _safeBool(() => existing?.isSalary);
    _isQuickAdd = _safeBool(() => existing?.isQuickAdd);
    _useActualsForBalance = _safeBool(() => existing?.useActualsForBalance);
    _exchangeRateController = TextEditingController(
      text: existing?.exchangeRate?.toString() ?? '',
    );

    // Show optional fields if they have existing data - logic removed for simplicity

    // Add listener for real-time day validation
    _dayController.addListener(_validateDay);
  }


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Initial validation will happen on first user interaction
    // We don't validate here to avoid setState during build
  }

  void _validateDay() {
    final result = PlannerItemFormValidation.validateDay(
      _dayController.text,
      context,
    );
    setState(() {
      _dayValidationError = result.dayError;
      // Note: result.dayInfoMessage not shown for compactness
    });
  }

  @override
  void dispose() {
    _dayController.removeListener(_validateDay);
    _labelController.dispose();
    _amountController.dispose();
    _dayController.dispose();
    _notesController.dispose();
    _categoryController.dispose();
    _companyController.dispose();
    _remainingBalanceController.dispose();
    _exchangeRateController.dispose();
    _categoryFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final settings = AppSettingsScope.of(context);

    // Theme-aware color palette
    final backgroundTop = colorScheme.surface;
    final backgroundBottom = colorScheme.surfaceContainerLowest;
    final surface = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    // Use app's credit/debit colors for income/expense accents
    final accentIncome = settings.creditColor;
    final accentExpense = settings.debitColor;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundTop, backgroundBottom],
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 6, 16, 16 + bottomInset),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Title + Income/Expense toggle row
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        _isEditMode
                            ? Terminology.of(context).editItemTitle
                            : Terminology.of(context).newItemTitle,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: textPrimary,
                            ),
                      ),
                    ),
                    IncomeExpenseToggle(
                      isIncomeMode: _isIncomeMode,
                      accentIncome: accentIncome,
                      accentExpense: accentExpense,
                      onToggle: (income) {
                        if (income) {
                          _switchToIncomeMode();
                        } else {
                          _switchToExpenseMode();
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Name field - full width with label
                UpsertPlannerItemStyle.labeledField(
                  context: context,
                  label: 'Name',
                  child: TextField(
                    controller: _labelController,
                    style: TextStyle(color: textPrimary, fontSize: 14),
                    decoration: UpsertPlannerItemStyle.compactInput(context, 'Enter name', floatingLabel: false),
                    maxLength: kMaxLabelLength,
                    textInputAction: TextInputAction.next,
                  ),
                ),
                const SizedBox(height: 12),

                // Amount + Day row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Amount with sign indicator and label
                    Expanded(
                      flex: 3,
                      child: UpsertPlannerItemStyle.labeledField(
                        context: context,
                        label: 'Amount',
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                              decoration: BoxDecoration(
                                color: _isIncomeMode
                                    ? accentIncome.withValues(alpha: 0.12)
                                    : accentExpense.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: border),
                              ),
                              child: Text(
                                _isIncomeMode ? '+' : '−',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: _isIncomeMode ? accentIncome : accentExpense,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: TextField(
                                controller: _amountController,
                                style: TextStyle(color: textPrimary, fontSize: 14),
                                decoration: UpsertPlannerItemStyle.compactInput(context, '0.00', floatingLabel: false),
                                keyboardType: TextInputType.numberWithOptions(
                                  signed: false,
                                  decimal: settings.showCents,
                                ),
                                inputFormatters: [
                                  if (settings.showCents)
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                                  else
                                    FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(AppConstants.maxAmountLength),
                                ],
                                textInputAction: TextInputAction.next,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Day field with label (hidden for spending envelopes)
                    if (_type != PaymentType.spendingEnvelope)
                      SizedBox(
                        width: 70,
                        child: UpsertPlannerItemStyle.labeledField(
                          context: context,
                          label: 'Day',
                          child: TextField(
                            controller: _dayController,
                            style: TextStyle(color: textPrimary, fontSize: 14),
                            decoration: UpsertPlannerItemStyle.compactInput(
                              context,
                              '1-31',
                              floatingLabel: false,
                              errorText: _dayValidationError,
                            ),
                            keyboardType: TextInputType.number,
                            textInputAction: TextInputAction.next,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),

                // Schedule section with label
                UpsertPlannerItemStyle.labeledField(
                  context: context,
                  label: 'Schedule',
                  child: Row(
                    children: [
                      // Date picker
                      InkWell(
                        onTap: _pickStartDate,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(
                            color: surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: border),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.calendar_today_outlined, size: 14, color: textSecondary),
                              const SizedBox(width: 6),
                              Text(
                                DateFormat.MMMd().format(_startDate),
                                style: TextStyle(color: textPrimary, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Frequency dropdown (if applicable)
                      if (_type != PaymentType.oneOff && _type != PaymentType.oneOffIncome) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: border),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<RecurrenceFrequency>(
                              value: _frequency,
                              dropdownColor: surface,
                              isDense: true,
                              style: TextStyle(color: textPrimary, fontSize: 13),
                              icon: Icon(Icons.keyboard_arrow_down, size: 18, color: textSecondary),
                              items: RecurrenceFrequency.values
                                  .map((freq) => DropdownMenuItem(
                                        value: freq,
                                        child: Text(freq.label),
                                      ))
                                  .toList(),
                              onChanged: (value) {
                                if (value != null) setState(() => _frequency = value);
                              },
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Type section with label
                UpsertPlannerItemStyle.labeledField(
                  context: context,
                  label: 'Type',
                  child: PlannerItemTypeSelector(
                    type: _type,
                    isIncomeMode: _isIncomeMode,
                    onTypeChanged: _selectSubtype,
                  ),
                ),
                const SizedBox(height: 12),

                // Debt-specific fields
                if (_type == PaymentType.debt) 
                  DebtFieldsSection(
                    remainingBalanceController: _remainingBalanceController,
                    balanceCurrency: _balanceCurrency,
                    exchangeRateController: _exchangeRateController,
                    selectedMoneyPotId: _selectedMoneyPotId,
                    amountController: _amountController,
                    dayController: _dayController,
                    frequency: _frequency,
                    startDate: _startDate,
                    isEditMode: _isEditMode,
                    isPaidOff: _isPaidOff,
                    onBalanceCurrencyChanged: (value) {
                      setState(() {
                        _balanceCurrency = value;
                        if (value == null) {
                          _exchangeRateController.clear();
                        }
                      });
                    },
                    onMoneyPotChanged: _onMoneyPotChanged,
                    onIsPaidOffChanged: (value) => setState(() => _isPaidOff = value),
                    buildCompactCheckbox: ({required label, required onChanged, required subtitle, required value}) {
                      return UpsertPlannerItemStyle.buildCompactCheckbox(
                        context: context,
                        value: value,
                        onChanged: onChanged,
                        label: label,
                        subtitle: subtitle,
                      );
                    },
                  ),

                // Collapsible optional fields section
                const SizedBox(height: 8),
                OptionalFieldsSection(
                  categoryController: _categoryController,
                  categoryFocusNode: _categoryFocusNode,
                  categoryLayerLink: _categoryLayerLink,
                  selectedCategory: _selectedCategory,
                  companyController: _companyController,
                  isSalary: _isSalary,
                  isQuickAdd: _isQuickAdd,
                  notesController: _notesController,
                  isIncomeMode: _isIncomeMode,
                  type: _type,
                  onCategorySelected: (value) => setState(() => _selectedCategory = value),
                  onIsSalaryChanged: (value) => setState(() => _isSalary = value),
                  onIsQuickAddChanged: (value) => setState(() => _isQuickAdd = value),
                  selectedMoneyPotId: _selectedMoneyPotId,
                  onMoneyPotChanged: _onMoneyPotChanged,
                  remainingBalanceController: _remainingBalanceController,
                  balanceCurrency: _balanceCurrency,
                  onBalanceCurrencyChanged: (AppCurrency? value) {
                    setState(() => _balanceCurrency = value);
                  },
                  useActualsForBalance: _useActualsForBalance,
                  onUseActualsChanged: (value) => setState(() => _useActualsForBalance = value),
                  buildCompactCheckbox: ({required label, required onChanged, required subtitle, required value}) {
                    return UpsertPlannerItemStyle.buildCompactCheckbox(
                      context: context,
                      value: value,
                      onChanged: onChanged,
                      label: label,
                      subtitle: subtitle,
                    );
                  },
                ),

                const SizedBox(height: 16),

                // Save button
                FilledButton(
                  onPressed: _handleSave,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    _isEditMode ? l10n.save : l10n.add,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }



  void _switchToExpenseMode() {
    if (_isIncomeMode) {
      setState(() {
        _type = _type == PaymentType.oneOffIncome ? PaymentType.oneOff : PaymentType.recurring;
        if (_type != PaymentType.oneOff) {
          _frequency ??= RecurrenceFrequency.monthly;
        }
      });
    }
  }

  void _switchToIncomeMode() {
    if (!_isIncomeMode) {
      setState(() {
        _type = _type == PaymentType.oneOff ? PaymentType.oneOffIncome : PaymentType.recurringIncome;
        if (_type != PaymentType.oneOffIncome) {
          _frequency ??= RecurrenceFrequency.monthly;
        }
      });
    }
  }

  void _selectSubtype(PaymentType type) {
    setState(() {
      _type = type;
      if (type == PaymentType.oneOff || type == PaymentType.oneOffIncome) {
        _frequency = null;
      } else {
        _frequency ??= RecurrenceFrequency.monthly;
      }
      if (type == PaymentType.spendingEnvelope) {
        // _isQuickAdd = true; // Removed per user request
      }
    });
  }

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  Future<void> _handleSave() async {
    final label = _labelController.text.trim();
    final rawAmountCents = tryParseMoneyToCents(_amountController.text);
    final dayText = _dayController.text.trim();
    // For spending envelopes, use day 1 as default if not provided
    final day = _type == PaymentType.spendingEnvelope && dayText.isEmpty
        ? 1
        : int.tryParse(dayText);

    // Validate all inputs at once
    final validationError = PlannerItemFormValidation.validateSaveInputs(
      label: label,
      amountMinorUnits: rawAmountCents,
      dayText: dayText,
      dayValidationError: _dayValidationError,
      context: context,
      paymentType: _type,
    );

    if (validationError != null) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(validationError),
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    // day and amountMinorUnits must be non-null at this point due to validation
    if (day == null || rawAmountCents == null) {
      throw StateError('Internal error: invalid form validation state');
    }

    // Apply rounding
    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    // Apply sign based on income/expense mode
    // Income types are positive, expense types are negative
    final amountMinorUnits = _isIncomeMode
        ? finalAmountCents
        : -finalAmountCents;

    final remainingBalanceMinorUnits = (_type == PaymentType.debt || _selectedMoneyPotId != null)
        ? tryParseMoneyToCents(_remainingBalanceController.text)
        : null;

    // Determine finalMoneyPotId synchronously (generate ID now, create pot later)
    MoneyPotId? finalMoneyPotId = _selectedMoneyPotId;
    final needsNewMoneyPot = _selectedMoneyPotId == const MoneyPotId('enable_smart_tracking') || 
                             _selectedMoneyPotId == _kNewMoneyPotId;
    if (needsNewMoneyPot) {
      finalMoneyPotId = newMoneyPotId();
    }

    // Build result SYNCHRONOUSLY - no awaits that can break the flow
    final result = widget.existing == null
        ? PlannerItem(
            id: newPlannerItemId(),
            label: label,
            amountMinorUnits: amountMinorUnits,
            dayOfMonth: day!,
            type: _type,
            startDate: _startDate,
            frequency: _frequency,
            notes: _notesController.text.trim().isEmpty
                ? null
                : _notesController.text.trim(),
            archived: false,
            paidOffDate: null,
            remainingBalanceMinorUnits: remainingBalanceMinorUnits,
            originalAmountMinorUnits: _type == PaymentType.debt ? remainingBalanceMinorUnits : null,
            category: _selectedCategory,
            company: _companyController.text.trim().isEmpty ? null : _companyController.text.trim(),
            isSalary: _isSalary && _type == PaymentType.recurringIncome,
            moneyPotId: needsNewMoneyPot ? finalMoneyPotId : _selectedMoneyPotId,
            isQuickAdd: _isQuickAdd,
            balanceCurrency: _type == PaymentType.debt ? _balanceCurrency : null,
            exchangeRate: _type == PaymentType.debt && _balanceCurrency != null
                ? double.tryParse(_exchangeRateController.text)
                : null,
            useActualsForBalance: _type == PaymentType.spendingEnvelope ? _useActualsForBalance : false,
          )
        : widget.existing!.copyWith(
            label: label,
            amountMinorUnits: amountMinorUnits,
            dayOfMonth: day,
            type: _type,
            frequency: _frequency,
            startDate: _startDate,
            notes: _notesController.text.trim().isEmpty
                ? null
                : _notesController.text.trim(),
            paidOffDate: _isPaidOff ? DateTime.now() : null,
            remainingBalanceMinorUnits: remainingBalanceMinorUnits,
            category: _selectedCategory,
            company: _companyController.text.trim().isEmpty ? null : _companyController.text.trim(),
            isSalary: _isSalary && _type == PaymentType.recurringIncome,
            moneyPotId: needsNewMoneyPot ? finalMoneyPotId : _selectedMoneyPotId,
            isQuickAdd: _isQuickAdd,
            balanceCurrency: _type == PaymentType.debt ? _balanceCurrency : null,
            exchangeRate: _type == PaymentType.debt && _balanceCurrency != null
                ? double.tryParse(_exchangeRateController.text)
                : null,
            useActualsForBalance: _type == PaymentType.spendingEnvelope ? _useActualsForBalance : false,
          );

    // CRITICAL: Pop the result IMMEDIATELY - before any async side-effects.
    // This guarantees the item is returned to PaymentsScreen and saved.
    if (mounted) {
      Navigator.pop(context, result);
    }

    // ---- FIRE-AND-FORGET SIDE EFFECTS (run after pop) ----
    // These operations happen after the sheet is dismissed. If any fail,
    // the item is still saved. User can fix Money Pot issues later.

    // Create new Money Pot if needed
    if (needsNewMoneyPot && finalMoneyPotId != null) {
      final newPot = MoneyPot(
        id: finalMoneyPotId,
        name: label,
        amountMinorUnits: remainingBalanceMinorUnits ?? 0,
        type: MoneyPotType.debt,
      );
      settings.addMoneyPot(newPot); // Fire-and-forget, no await
    } else if (_selectedMoneyPotId != null && !needsNewMoneyPot) {
      // Update the pot linked to this item
      final pot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
        (p) => p?.id == _selectedMoneyPotId,
        orElse: () => null,
      );
      if (pot != null) {
        final needsNameUpdate = pot.name != label;
        final needsBalanceUpdate = remainingBalanceMinorUnits != null && pot.amountMinorUnits != remainingBalanceMinorUnits;
        final needsTypeUpdate = pot.type == MoneyPotType.savings;

        if (needsNameUpdate || needsBalanceUpdate || needsTypeUpdate) {
           settings.updateMoneyPot(pot.copyWith(
             name: needsNameUpdate ? label : null,
             amountMinorUnits: needsBalanceUpdate ? remainingBalanceMinorUnits : null,
             type: needsTypeUpdate ? MoneyPotType.debt : null,
           )); // Fire-and-forget, no await
        }
      }
    }

    // CLEANUP: If we unlinked a Money Pot, check if it's orphaned
    if (widget.existing != null) {
      final oldPotId = widget.existing!.moneyPotId;
      final newPotId = result.moneyPotId;
      
      if (oldPotId != null && newPotId != oldPotId) {
        final store = ExpenseStoreScope.read(context);
        final isUsedByOthers = store.activePlannerItems.any((i) => 
           i.moneyPotId == oldPotId && i.id != result.id
        );
        
        if (!isUsedByOthers) {
          settings.removeMoneyPot(oldPotId); // Fire-and-forget
        }
      }
    }
  }

  Future<void> _showPaycheckSyncDialog(PlannerItem salaryItem) async {

    final dayNum = salaryItem.dayOfMonth;
    final dayStr = dayNum == 1
        ? '1st'
        : dayNum == 2
            ? '2nd'
            : dayNum == 3
                ? '3rd'
                : dayNum == 21
                    ? '21st'
                    : dayNum == 22
                        ? '22nd'
                        : dayNum == 23
                            ? '23rd'
                            : dayNum == 31
                                ? '31st'
                                : '${dayNum}th';

    if (!mounted) return;

    final l10n = AppLocalizations.of(context)!;
    final shouldSync = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.syncPaycheckTitle),
        content: Text(l10n.syncPaycheckMessage(dayStr)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(l10n.noThanks),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(l10n.syncAction),
          ),
        ],
      ),
    );

    if (shouldSync == true && mounted) {
      final settings = AppSettingsScope.read(context);
      syncPaycheckDayFromSalary(salaryItem, settings);
    }
  }

  void _onMoneyPotChanged(MoneyPotId? value) {
    if (value == const MoneyPotId('enable_smart_tracking')) {
      // Smart Tracking: Try to find a pot with same name (case-insensitive)
      // If found -> select it.
      // If not found -> select Create New.
      final settings = AppSettingsScope.read(context);
      final itemName = _labelController.text.trim().toLowerCase();
      
      MoneyPot? match;
      if (itemName.isNotEmpty) {
        // Simple case-insensitive match on name
        try {
          match = settings.moneyPots.firstWhere((p) => p.name.trim().toLowerCase() == itemName);
        } catch (_) {
          // No match found
        }
      }
      
      setState(() {
         _selectedMoneyPotId = match?.id ?? _kNewMoneyPotId;
      });
    } else {
      // Standard selection
      setState(() {
        _selectedMoneyPotId = value;

        // If user manually switched to a specific pot (and it's not "New"),
        // we might want to sync Debt Fields (Remaining Balance) if we were in Debt mode.
        // Even if we are in Recurring mode, it doesn't hurt to have the logic here.
        if (value != _kNewMoneyPotId && value != null) {
            final settings = AppSettingsScope.read(context);
            try {
               final pot = settings.moneyPots.firstWhere((p) => p.id == value);
               // Only update text if empty or different? 
               // Standard behavior was to overwrite.
               _remainingBalanceController.text = (pot.amountMinorUnits / 100).toStringAsFixed(2);
            } catch (_) {}
        }
      });
    }
  }

}
