import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Bottom sheet for adding a quick standalone transaction.
/// 
/// Allows entering amount, label, date, category and income/expense toggle.
/// Returns a [PaymentEntry] on save, or null if cancelled.
class QuickTransactionSheet extends StatefulWidget {
  const QuickTransactionSheet({
    super.key,
  });

  @override
  State<QuickTransactionSheet> createState() => _QuickTransactionSheetState();
}

class _QuickTransactionSheetState extends State<QuickTransactionSheet> {
  late final TextEditingController _amountController;
  late final TextEditingController _labelController;
  late final TextEditingController _companyController;
  late final TextEditingController _notesController;
  late DateTime _date;
  String? _selectedCategory;
  bool _isIncome = false;

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    _labelController = TextEditingController();
    _companyController = TextEditingController();
    _notesController = TextEditingController();
    _date = DateTime.now();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _labelController.dispose();
    _companyController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context)!;
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);
    final colorScheme = Theme.of(context).colorScheme;

    final backgroundTop = isDark ? const Color(0xFF1A1D27) : const Color(0xFFF8F9FC);
    final backgroundBottom = isDark ? const Color(0xFF0F1118) : const Color(0xFFF0F2F8);
    final surface = isDark ? const Color(0xFF252A3A) : Colors.white;
    final border = isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.06);
    final textPrimary = isDark ? Colors.white : const Color(0xFF1A1D27);
    final textSecondary = isDark ? Colors.white60 : const Color(0xFF6B7280);

    final accentColor = _isIncome ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    InputDecoration compactInput(String label, {String? hintText}) {
      return InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: textSecondary, fontSize: 12),
        filled: true,
        fillColor: surface,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
        ),
      );
    }

    final categories = getCategorySuggestions(
      isIncome: _isIncome,
      mode: settings.categoryPresetMode,
      userCategories: store.getUserCategories(isIncome: _isIncome),
    );

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundTop, backgroundBottom],
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppConstants.radiusSheetTop)),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 6, 16, 16 + bottomInset),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Text(
                  'Log Transaction',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: textPrimary,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),

                // Income/Expense Toggle
                Center(
                  child: SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                        value: false,
                        label: Text('Expense'),
                        icon: Icon(Icons.remove_circle_outline),
                      ),
                      ButtonSegment(
                        value: true,
                        label: Text('Income'),
                        icon: Icon(Icons.add_circle_outline),
                      ),
                    ],
                    selected: {_isIncome},
                    onSelectionChanged: (selected) {
                      setState(() {
                        _isIncome = selected.first;
                        _selectedCategory = null; // Reset category when switching type
                      });
                    },
                    style: SegmentedButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Amount & Date Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Amount Field
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _amountController,
                        autofocus: true,
                        style: TextStyle(color: textPrimary, fontSize: 16, fontWeight: FontWeight.w600),
                        decoration: compactInput('Amount').copyWith(
                          prefixIcon: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              _isIncome ? '+' : '−',
                              style: TextStyle(
                                fontSize: 16, 
                                fontWeight: FontWeight.bold,
                                color: accentColor,
                              ),
                            ),
                          ),
                          prefixIconConstraints: const BoxConstraints(minWidth: 40, minHeight: 0),
                        ),
                        keyboardType: TextInputType.numberWithOptions(
                          signed: false,
                          decimal: settings.showCents,
                        ),
                        inputFormatters: [
                          if (settings.showCents)
                            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                          else
                            FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(AppConstants.maxAmountLength),
                        ],
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Date Picker
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: _pickDate,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: border),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Date', style: TextStyle(color: textSecondary, fontSize: 10)),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Icon(Icons.calendar_today, size: 14, color: textPrimary),
                                  const SizedBox(width: 6),
                                  Text(
                                    DateFormat.MMMd().format(_date),
                                    style: TextStyle(color: textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Label
                TextField(
                  controller: _labelController,
                  style: TextStyle(color: textPrimary, fontSize: 14),
                  decoration: compactInput('Label').copyWith(
                    hintText: 'e.g., Starbucks, Rent, Salary',
                  ),
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 12),

                // Company
                TextField(
                  controller: _companyController,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  decoration: compactInput('Company (Optional)').copyWith(
                    hintText: 'e.g., Netflix, Apple, Uber',
                  ),
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 12),

                // Category Dropdown
                DropdownButtonFormField<String?>(
                  value: _selectedCategory,
                  decoration: compactInput('Category'),
                  items: [
                    const DropdownMenuItem<String?>(
                      value: null,
                      child: Text('Uncategorized'),
                    ),
                    ...categories.map((cat) => DropdownMenuItem<String?>(
                      value: cat,
                      child: Text(cat),
                    )),
                  ],
                  onChanged: (value) => setState(() => _selectedCategory = value),
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  dropdownColor: surface,
                ),
                const SizedBox(height: 12),

                // Notes
                TextField(
                  controller: _notesController,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  decoration: compactInput('Notes (Optional)').copyWith(
                    hintText: 'Add extra details...',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 24),

                // Save Button
                FilledButton(
                  onPressed: _handleSave,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppConstants.radiusButton),
                    ),
                  ),
                  child: Text(
                    l10n.save,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _date = picked);
    }
  }

  void _handleSave() {
    final label = _labelController.text.trim();
    if (label.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a label')),
      );
      return;
    }

    final rawAmountCents = tryParseMoneyToCents(_amountController.text);
    if (rawAmountCents == null || rawAmountCents == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount')),
      );
      return;
    }
    
    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    final signedAmountCents = _isIncome ? finalAmountCents : -finalAmountCents;

    final entry = PaymentEntry(
      id: newEntryId(),
      label: label,
      amountMinorUnits: signedAmountCents,
      date: _date,
      type: _isIncome ? PaymentType.oneOffIncome : PaymentType.oneOff,
      category: _selectedCategory,
      company: _companyController.text.trim().isEmpty ? null : _companyController.text.trim(),
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      plannerItemId: null, // Standalone!
    );

    Navigator.pop(context, entry);
  }
}
