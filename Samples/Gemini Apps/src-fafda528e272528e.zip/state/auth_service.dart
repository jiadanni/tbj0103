import 'dart:convert';
import 'package:cryptography/cryptography.dart';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
// import 'package:local_auth/error_codes.dart' as auth_error; // REMOVED: File does not exist in local_auth 3.0.0
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

import 'package:expense_stalker_mobile/src/util/error_tracker.dart';

/// Result of PIN verification attempt.
enum PinVerificationResult {
  /// PIN was correct
  success,
  /// PIN was incorrect
  incorrectPin,
  /// Too many failed attempts, temporarily locked out
  lockedOut,
}

/// Service for handling app authentication (biometric + PIN).
///
/// Manages authentication state, biometric setup, and PIN fallback.
class AuthService {
  final LocalAuthentication _localAuth = LocalAuthentication();
  static const int minPinLength = 4;
  static const int maxPinLength = 8;
  static const String _keyAuthEnabled = 'auth.enabled';
  static const String _keyPinHash = 'auth.pin_hash';
  static const String _keyUseBiometrics = 'auth.use_biometrics';
  static const String _keyDelayBeforeAuthSeconds = 'auth.delay_before_auth_seconds';
  static const String _keyPreventScreenshots = 'auth.prevent_screenshots';

  StorageProvider? _storageProvider;
  bool _isInitialized = false;
  bool _biometricAuthInProgress = false; // Prevent concurrent biometric prompts

  /// Initialize the authentication service.
  ///
  /// Must be called before using any other methods.
  Future<void> initialize() async {
    if (_isInitialized) return;
    // Create storage provider used for sensitive data storage (PIN) and settings.
    _storageProvider = await StorageProvider.create();
    _isInitialized = true;
  }

  /// Check if authentication is enabled.
  Future<bool> isAuthEnabled() async {
    _ensureInitialized();
    return await _storageProvider!.getBool(_keyAuthEnabled) ?? false;
  }

  /// Enable or disable authentication.
  Future<void> setAuthEnabled(bool enabled) async {
    _ensureInitialized();
    await _storageProvider!.setBool(_keyAuthEnabled, enabled);
    // If authentication is being disabled, remove any stored PIN.
    if (!enabled) {
      try {
        await removePIN();
      } catch (e, st) {
        ErrorTracker.instance.trackError(
          ErrorContext(
            category: 'authentication',
            message: 'Failed to remove PIN when disabling authentication',
            severity: ErrorSeverity.warning,
            error: e,
            additionalData: {'stack': st.toString()},
          ),
        );
      }
    }
  }

  /// Check if biometric authentication is available on this device.
  Future<bool> isBiometricAvailable() async {
    try {
      return await _localAuth.canCheckBiometrics && 
             await _localAuth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  /// Get list of available biometric types.
  Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      return await _localAuth.getAvailableBiometrics();
    } catch (_) {
      return [];
    }
  }

  /// Check if biometrics are enabled in settings.
  Future<bool> useBiometrics() async {
    _ensureInitialized();
    return await _storageProvider!.getBool(_keyUseBiometrics) ?? false;
  }

  /// Enable or disable biometric authentication.
  Future<void> setUseBiometrics(bool enabled) async {
    _ensureInitialized();
    await _storageProvider!.setBool(_keyUseBiometrics, enabled);
  }

  /// Get delay before requesting authentication after standby in seconds (0 = immediate).
  Future<int> getDelayBeforeAuthSeconds() async {
    _ensureInitialized();
    return await _storageProvider!.getInt(_keyDelayBeforeAuthSeconds) ?? 0;
  }

  /// Set delay before requesting authentication after standby in seconds (0 = immediate).
  Future<void> setDelayBeforeAuthSeconds(int seconds) async {
    _ensureInitialized();
    await _storageProvider!.setInt(_keyDelayBeforeAuthSeconds, seconds);
  }

  /// Check if screenshot prevention is enabled.
  Future<bool> preventScreenshots() async {
    _ensureInitialized();
    return await _storageProvider!.getBool(_keyPreventScreenshots) ?? false;
  }

  /// Enable or disable screenshot prevention.
  Future<void> setPreventScreenshots(bool enabled) async {
    _ensureInitialized();
    await _storageProvider!.setBool(_keyPreventScreenshots, enabled);
  }

  /// Attempt biometric authentication.
  ///
  /// Returns true if successful, false if failed or not available.
  Future<bool> authenticateWithBiometrics({
    required String reason,
  }) async {
    // Prevent concurrent biometric authentication attempts
    if (_biometricAuthInProgress) return false;
    
    if (!await useBiometrics()) return false;
    if (!await isBiometricAvailable()) return false;

    _biometricAuthInProgress = true;
    try {
      // persistAcrossBackgrounding: true keeps auth dialog open if app goes to background
      // biometricOnly: true prevents device credential fallback which can cause double prompts
      final result = await _localAuth.authenticate(
        localizedReason: reason,
        persistAcrossBackgrounding: true,
        biometricOnly: true,
      );
      return result;
    } on LocalAuthException catch (e) {
      // Handle specific errors from local_auth 3.0.0
      if (e.code == LocalAuthExceptionCode.noBiometricHardware ||
          e.code == LocalAuthExceptionCode.noBiometricsEnrolled) {
        ErrorTracker.instance.trackError(
          ErrorContext(
            category: 'authentication',
            message: 'Biometric authentication not available',
            severity: ErrorSeverity.warning,
            error: e,
            additionalData: {'errorCode': e.code.name},
          ),
        );
        return false;
      }
      // User cancelled or other error
      ErrorTracker.instance.trackError(
        ErrorContext(
          category: 'authentication',
          message: 'Biometric authentication failed',
          severity: ErrorSeverity.info,
          error: e,
          additionalData: {'errorCode': e.code.name},
        ),
      );
      return false;
    } on PlatformException catch (e) {
      // Fallback for legacy platform exceptions
      ErrorTracker.instance.trackError(
        ErrorContext(
          category: 'authentication',
          message: 'Biometric authentication platform error',
          severity: ErrorSeverity.warning,
          error: e,
          additionalData: {'errorCode': e.code},
        ),
      );
      return false;
    } catch (e) {
      ErrorTracker.instance.trackError(
        ErrorContext(
          category: 'authentication',
          message: 'Unexpected biometric authentication error',
          severity: ErrorSeverity.error,
          error: e,
        ),
      );
      return false;
    } finally {
      _biometricAuthInProgress = false;
    }
  }

  /// Check if a PIN is set.
  Future<bool> hasPIN() async {
    _ensureInitialized();
    // Prefer secure storage when available.
    if (_storageProvider == null) {
      throw StateError('Secure storage provider not available; PIN operations require secure storage.');
    }
    final s = await _storageProvider!.getString(_keyPinHash);
    return s != null;
  }

  /// Set a new PIN.
  ///
  /// Throws [ArgumentError] if PIN is invalid (must be 4-8 digits).
  Future<void> setPIN(String pin) async {
    _ensureInitialized();
    _validatePIN(pin);
    final stored = await _createKdfStorageString(pin);
    if (_storageProvider == null) {
      throw StateError('Secure storage provider not available; cannot set PIN.');
    }
    await _storageProvider!.setString(_keyPinHash, stored);
  }

  /// Verify a PIN.
  ///
  /// Returns [PinVerificationResult] indicating success, incorrect PIN, or lockout.
  Future<PinVerificationResult> verifyPIN(String pin) async {
    _ensureInitialized();
    if (_storageProvider == null) {
      throw StateError('Secure storage provider not available; cannot verify PIN.');
    }

    // Check rate limiting first
    if (await _isLockedOut()) {
      return PinVerificationResult.lockedOut;
    }

    final storedHash = await _storageProvider!.getString(_keyPinHash);
    if (storedHash == null) return PinVerificationResult.incorrectPin;
    
    bool verified = false;
    // Check if stored is new JSON format
    try {
      final decoded = jsonDecode(storedHash);
      if (decoded is Map<String, dynamic> && decoded['kdf'] == 'pbkdf2') {
        final saltB64 = decoded['salt'] as String?;
        final iter = decoded['iterations'] as int? ?? 10000;
        final hashB64 = decoded['hash'] as String?;
        if (saltB64 != null && hashB64 != null) {
          final salt = base64Decode(saltB64);
          final expected = base64Decode(hashB64);
          verified = await _verifyPbkdf2(pin, salt, iter, expected);
        }
      }
    } catch (_) {
      // Not JSON or unsupported format, treat as fail
      verified = false;
    }

    if (verified) {
      await _resetFailedAttempts();
      return PinVerificationResult.success;
    } else {
      await _recordFailedAttempt();
      return PinVerificationResult.incorrectPin;
    }
  }

  // --- Rate Limiting Helpers ---

  static const String _keyFailedAttempts = 'auth.failed_attempts';
  static const String _keyLastFailedTime = 'auth.last_failed_attempt_time';
  static const int _maxAttempts = 5;

  int _getLockoutDurationSeconds(int failedAttempts) {
    if (failedAttempts < _maxAttempts) return 0;
    final extraAttempts = failedAttempts - _maxAttempts;
    return switch (extraAttempts) {
      0 => 30, // 5th failure
      1 => 60, // 6th failure
      2 => 300, // 7th failure
      _ => 900, // 8th+ failure
    };
  }

  Future<bool> _isLockedOut() async {
    final lastFailed = await _storageProvider!.getInt(_keyLastFailedTime);
    if (lastFailed == null) return false;

    final failedAttempts = await _storageProvider!.getInt(_keyFailedAttempts) ?? 0;
    if (failedAttempts < _maxAttempts) return false;

    final lastFailedTime = DateTime.fromMillisecondsSinceEpoch(lastFailed);
    final lockoutDuration = _getLockoutDurationSeconds(failedAttempts);
    final lockoutEnd = lastFailedTime.add(Duration(seconds: lockoutDuration));
    
    if (DateTime.now().isBefore(lockoutEnd)) {
      return true;
    } else {
      // Lockout expired, but don't reset count until a success happens?
      // Standard practice: reset count after lockout expires OR reset on first success?
      // Let's reset count if lockout expired to allow retries.
      await _resetFailedAttempts();
      return false;
    }
  }

  Future<void> _recordFailedAttempt() async {
    final attempts = (await _storageProvider!.getInt(_keyFailedAttempts) ?? 0) + 1;
    await _storageProvider!.setInt(_keyFailedAttempts, attempts);
    await _storageProvider!.setInt(_keyLastFailedTime, DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> _resetFailedAttempts() async {
    await _storageProvider!.remove(_keyFailedAttempts);
    await _storageProvider!.remove(_keyLastFailedTime);
  }

  /// Get the number of remaining PIN attempts before lockout.
  ///
  /// Returns [_maxAttempts] if no failed attempts, or remaining attempts.
  Future<int> getRemainingAttempts() async {
    _ensureInitialized();
    final failedAttempts = await _storageProvider!.getInt(_keyFailedAttempts) ?? 0;
    return (_maxAttempts - failedAttempts).clamp(0, _maxAttempts);
  }

  /// Get the number of seconds remaining in the lockout period.
  ///
  /// Returns 0 if not locked out.
  Future<int> getLockoutSecondsRemaining() async {
    _ensureInitialized();
    final lastFailed = await _storageProvider!.getInt(_keyLastFailedTime);
    if (lastFailed == null) return 0;

    final failedAttempts = await _storageProvider!.getInt(_keyFailedAttempts) ?? 0;
    if (failedAttempts < _maxAttempts) return 0;

    final lastFailedTime = DateTime.fromMillisecondsSinceEpoch(lastFailed);
    final lockoutDuration = _getLockoutDurationSeconds(failedAttempts);
    final lockoutEnd = lastFailedTime.add(Duration(seconds: lockoutDuration));
    
    if (DateTime.now().isBefore(lockoutEnd)) {
      return lockoutEnd.difference(DateTime.now()).inSeconds;
    } else {
      return 0;
    }
  }

  /// Remove PIN.
  Future<void> removePIN() async {
    _ensureInitialized();
    if (_storageProvider == null) {
      throw StateError('Secure storage provider not available; cannot remove PIN.');
    }
    await _storageProvider!.remove(_keyPinHash);
  }

  /// Validate PIN format and constraints.
  ///
  /// PIN must be:
  /// - 4-8 characters long
  /// - Numeric only
  /// - Not all the same digit (e.g., 1111, 0000)
  /// - Not a simple ascending/descending sequence (e.g., 1234, 4321)
  void _validatePIN(String pin) {
    if (pin.isEmpty ||
        pin.length < minPinLength ||
        pin.length > maxPinLength) {
      throw ArgumentError('PIN must be $minPinLength-$maxPinLength characters long');
    }
    if (!RegExp(r'^\d+$').hasMatch(pin)) {
      throw ArgumentError('PIN must contain only digits');
    }

    // Check for all same digits (e.g., 1111, 0000, 999999)
    if (pin.split('').toSet().length == 1) {
      throw ArgumentError('PIN cannot be all the same digit');
    }

    // Check for simple ascending sequence (e.g., 1234, 2345, 012345)
    if (_isAscendingSequence(pin)) {
      throw ArgumentError('PIN cannot be a simple ascending sequence');
    }

    // Check for simple descending sequence (e.g., 4321, 9876, 543210)
    if (_isDescendingSequence(pin)) {
      throw ArgumentError('PIN cannot be a simple descending sequence');
    }
  }

  /// Returns true if the PIN is a simple ascending sequence (1234, 2345, etc.)
  bool _isAscendingSequence(String pin) {
    for (int i = 0; i < pin.length - 1; i++) {
      final current = int.parse(pin[i]);
      final next = int.parse(pin[i + 1]);
      // Allow wrap-around: 9 -> 0 counts as ascending
      if (next != (current + 1) % 10) {
        return false;
      }
    }
    return true;
  }

  /// Returns true if the PIN is a simple descending sequence (4321, 9876, etc.)
  bool _isDescendingSequence(String pin) {
    for (int i = 0; i < pin.length - 1; i++) {
      final current = int.parse(pin[i]);
      final next = int.parse(pin[i + 1]);
      // Allow wrap-around: 0 -> 9 counts as descending
      if (next != (current - 1 + 10) % 10) {
        return false;
      }
    }
    return true;
  }

  /// Create a storage string for the given PIN using PBKDF2-SHA256.
  ///
  /// Storage JSON format (stringified):
  /// {
  ///   "kdf": "pbkdf2",
  ///   "iterations": 100000,
  ///   "salt": "<base64>",
  ///   "hash": "<base64>"
  /// }
  Future<String> _createKdfStorageString(String pin) async {
    // Use reasonably high iteration count.
    const iterations = 100000;
    final algorithm = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: iterations, bits: 256);
    // Generate a random salt
    final rnd = Random.secure();
    final salt = List<int>.generate(16, (_) => rnd.nextInt(256));
    final secretKey = SecretKey(utf8.encode(pin));
    final newKey = await algorithm.deriveKey(secretKey: secretKey, nonce: salt);
    final derived = await newKey.extractBytes();
    final jsonMap = {
      'kdf': 'pbkdf2',
      'iterations': iterations,
      'salt': base64Encode(salt),
      'hash': base64Encode(derived),
    };
    return jsonEncode(jsonMap);
  }

  Future<bool> _verifyPbkdf2(String pin, List<int> salt, int iterations, List<int> expected) async {
    final algorithm = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: iterations, bits: expected.length * 8);
    final secretKey = SecretKey(utf8.encode(pin));
    final derivedKey = await algorithm.deriveKey(secretKey: secretKey, nonce: salt);
    final got = await derivedKey.extractBytes();
    return _constantTimeEquals(got, expected);
  }

  

  bool _constantTimeEquals(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var result = 0;
    for (var i = 0; i < a.length; i++) {
      result |= a[i] ^ b[i];
    }
    return result == 0;
  }

  void _ensureInitialized() {
    if (!_isInitialized) {
      throw StateError('AuthService not initialized. Call initialize() first.');
    }
  }

  /// Get biometric type name for display.
  String getBiometricTypeName(List<BiometricType> types) {
    if (types.isEmpty) return 'Biometric';
    if (types.contains(BiometricType.face)) return 'Face ID';
    if (types.contains(BiometricType.fingerprint)) return 'Fingerprint';
    if (types.contains(BiometricType.iris)) return 'Iris';
    return 'Biometric';
  }
}
