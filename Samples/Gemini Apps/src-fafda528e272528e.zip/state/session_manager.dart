import 'dart:async';
import 'package:flutter/widgets.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

/// Manages user session and lock functionality.
///
/// Handles app lock state when resuming from background.
/// Note: Autolock (inactivity timeout) has been removed as device lock handles this.
class SessionManager extends ChangeNotifier {
  SessionManager(this._authService, {StorageProvider? storage}) : _storage = storage;

  final AuthService _authService;
  final StorageProvider? _storage;
  static const String _keyLastStandbyTime = 'session.last_standby_time';

  DateTime? _lastStandbyTime;
  bool _isLocked = true;
  VoidCallback? _onLockCallback;

  /// Whether the app is currently locked.
  bool get isLocked => _isLocked;

  /// Start monitoring session activity.
  Future<void> startSession(BuildContext context, {VoidCallback? onLock}) async {
    _onLockCallback = onLock;

    // Restore last standby time from storage (survives app restarts)
    if (_storage != null) {
      final storedTime = await _storage!.getString(_keyLastStandbyTime);
      if (storedTime != null) {
        try {
          _lastStandbyTime = DateTime.parse(storedTime);
        } catch (_) {
          // Invalid timestamp format, ignore
          _lastStandbyTime = null;
        }
      }
    }

    if (!await _authService.isAuthEnabled()) {
      _isLocked = false;
      notifyListeners();
      return;
    }

    _isLocked = false;
    notifyListeners();
  }

  /// Record that the app is going to standby (background).
  /// Persists the time to storage so it survives app restarts.
  Future<void> enterStandby() async {
    if (!await _authService.isAuthEnabled()) return;
    _lastStandbyTime = DateTime.now();
    
    // Persist to storage so it survives app restarts (critical for security)
    if (_storage != null) {
      await _storage!.setString(_keyLastStandbyTime, _lastStandbyTime!.toIso8601String());
    }
  }

  /// Called when app returns from background. Checks if grace period has expired.
  /// Returns true if the app should be locked, false if within grace period.
  /// 
  /// SECURITY: If _lastStandbyTime is null after checking storage, it means the app
  /// was hard-closed/killed and we MUST lock to prevent unauthorized access.
  Future<bool> shouldLockOnResume() async {
    if (!await _authService.isAuthEnabled()) return false;
    
    // If we don't have a standby time in memory, try to restore from storage
    // (this handles app hard-close/restart scenarios)
    if (_lastStandbyTime == null && _storage != null) {
      final storedTime = await _storage!.getString(_keyLastStandbyTime);
      if (storedTime != null) {
        try {
          _lastStandbyTime = DateTime.parse(storedTime);
        } catch (_) {
          // Invalid format, treat as app hard-close
          _lastStandbyTime = null;
        }
      }
    }
    
    // CRITICAL SECURITY FIX: If we still don't have a standby time, the app was
    // hard-closed. We MUST lock to prevent unauthorized access.
    // BUT exception: If we are currently unlocked (_isLocked == false), then
    // the null timestamp simply means we are active and valid.
    if (_lastStandbyTime == null) {
      if (!_isLocked) {
        return false; // Already unlocked and active
      }
      return true;  // Lock immediately - app was killed/restarted
    }

    final delaySeconds = await _authService.getDelayBeforeAuthSeconds();
    final timeSinceStandby = DateTime.now().difference(_lastStandbyTime!).inSeconds;

    // If within grace period, don't lock
    if (timeSinceStandby < delaySeconds) {
      _lastStandbyTime = null; // Clear standby time
      await _clearStoredStandbyTime();
      return false;
    }

    // Grace period expired, lock the app
    return true;
  }
  
  /// Clear the persisted standby time from storage.
  Future<void> _clearStoredStandbyTime() async {
    if (_storage != null) {
      await _storage!.remove(_keyLastStandbyTime);
    }
  }

  /// Lock the session immediately.
  Future<void> lock() async {
    if (!await _authService.isAuthEnabled()) return;

    _isLocked = true;
    notifyListeners();
    _onLockCallback?.call();
  }

  /// Unlock the session after successful authentication.
  Future<void> unlock() async {
    _isLocked = false;
    _lastStandbyTime = null;
    await _clearStoredStandbyTime();
    notifyListeners();
  }

  /// Stop the session (cleanup).
  void stopSession() {
    // No-op - autolock timer removed
  }

  @override
  void dispose() {
    stopSession();
    super.dispose();
  }
}
