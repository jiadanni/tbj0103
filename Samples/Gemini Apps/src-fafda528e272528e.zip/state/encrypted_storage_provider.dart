import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

/// Encrypted storage provider using `flutter_secure_storage`.
///
/// Stores values securely in the platform-provided secure store (Keychain/Keystore).
class EncryptedStorageProvider implements StorageProvider {
  EncryptedStorageProvider._(this._storage);

  final FlutterSecureStorage _storage;

  /// Create an instance. An optional [storage] may be provided for testing.
  /// 
  /// Uses platform-specific secure storage options:
  /// - **iOS**: `first_unlock_this_device` - data only accessible after first device
  ///   unlock and never leaves device (not included in backups). This is the most
  ///   secure option for financial data.
  /// - **Android**: EncryptedSharedPreferences with AES256 encryption.
  /// 
  /// Note: Data stored with these settings won't survive device migration.
  /// Users should use the app's export feature to backup data before switching devices.
  static Future<EncryptedStorageProvider> create({FlutterSecureStorage? storage}) async {
    final storageInstance = storage ?? const FlutterSecureStorage(
      iOptions: IOSOptions(
        accessibility: KeychainAccessibility.first_unlock_this_device,
      ),
      aOptions: AndroidOptions(
        encryptedSharedPreferences: true,
      ),
    );
    return EncryptedStorageProvider._(storageInstance);
  }

  @override
  Future<String?> getString(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<bool> setString(String key, String value) async {
    try {
      await _storage.write(key: key, value: value);
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<int?> getInt(String key) async {
    final s = await getString(key);
    if (s == null) return null;
    return int.tryParse(s);
  }

  @override
  Future<bool> setInt(String key, int value) async {
    return setString(key, value.toString());
  }

  @override
  Future<bool?> getBool(String key) async {
    final s = await getString(key);
    if (s == null) return null;
    if (s == '1' || s.toLowerCase() == 'true') return true;
    if (s == '0' || s.toLowerCase() == 'false') return false;
    return null;
  }

  @override
  Future<bool> setBool(String key, bool value) async {
    return setString(key, value ? '1' : '0');
  }

  @override
  Future<bool> remove(String key) async {
    try {
      await _storage.delete(key: key);
      return true;
    } catch (_) {
      return false;
    }
  }
}
