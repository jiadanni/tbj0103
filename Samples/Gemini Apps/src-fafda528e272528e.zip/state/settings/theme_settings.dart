import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';

/// Defines a complete color palette for a theme preset.
/// Each theme has colors for both light and dark modes.
class ThemePalette {
  const ThemePalette({
    required this.primary,
    required this.backgroundLight,
    required this.backgroundDark,
    required this.surfaceLight,
    required this.surfaceDark,
    required this.surfaceContainerLight,
    required this.surfaceContainerDark,
  });

  final Color primary;
  final Color backgroundLight;
  final Color backgroundDark;
  final Color surfaceLight;
  final Color surfaceDark;
  final Color surfaceContainerLight;
  final Color surfaceContainerDark;

  Color background(Brightness brightness) =>
      brightness == Brightness.dark ? backgroundDark : backgroundLight;

  Color surface(Brightness brightness) =>
      brightness == Brightness.dark ? surfaceDark : surfaceLight;

  Color surfaceContainer(Brightness brightness) =>
      brightness == Brightness.dark ? surfaceContainerDark : surfaceContainerLight;
}

class ThemeSettings extends ChangeNotifier {
  ThemeSettings(this._storage, {
    required ThemeMode initialThemeMode,
    required ColorPreset initialColorPreset,
    required AppThemePreset initialAppThemePreset,
    required int initialDebitColor,
    required int initialCreditColor,
    required int initialNeutralColor,
    required TextScalePreset initialTextScalePreset,
    required FontPreset initialFontPreset,
  }) : _themeMode = initialThemeMode,
       _colorPreset = initialColorPreset,
       _appThemePreset = initialAppThemePreset,
       _debitColorValue = initialDebitColor,
       _creditColorValue = initialCreditColor,
       _neutralColorValue = initialNeutralColor,
       _textScalePreset = initialTextScalePreset,
       _fontPreset = initialFontPreset;

  final StorageProvider _storage;

  static const _kThemeMode = 'settings.themeMode';
  static const _kColorPreset = 'settings.colors.preset';
  static const _kAppThemePreset = 'settings.colors.appThemePreset';
  static const _kDebitColor = 'settings.colors.debit';
  static const _kCreditColor = 'settings.colors.credit';
  static const _kNeutralColor = 'settings.colors.neutral';
  static const _kTextScalePreset = 'settings.textScale';
  static const _kFontPreset = 'settings.fontPreset';

  static const Map<ColorPreset, (int, int, int)> _presetColors = {
    ColorPreset.classic: (0xFFE53935, 0xFF43A047, 0xFF757575),       // Red / Green / Gray
    ColorPreset.ocean: (0xFFFF7043, 0xFF26A69A, 0xFF546E7A),         // Coral / Teal / Blue-Gray
    ColorPreset.sunset: (0xFFFF9800, 0xFF7E57C2, 0xFF607D8B),        // Orange / Purple / Blue-Gray
    ColorPreset.monochrome: (0xFF757575, 0xFFBDBDBD, 0xFF9E9E9E),    // Gray tones
    ColorPreset.forest: (0xFFA1887F, 0xFF66BB6A, 0xFF8D6E63),        // Brown / Forest Green / Light Brown
    ColorPreset.berry: (0xFFEC407A, 0xFF26C6DA, 0xFF7E57C2),         // Pink / Cyan / Purple
    ColorPreset.lavender: (0xFF9C27B0, 0xFFCDDC39, 0xFF757575),      // Purple / Lime / Gray
    ColorPreset.earth: (0xFFD84315, 0xFF9E9D24, 0xFF795548),         // Rust / Olive / Brown
    ColorPreset.mint: (0xFFAB47BC, 0xFF66BB6A, 0xFF78909C),          // Magenta / Mint / Blue-Gray
    ColorPreset.warm: (0xFFFFB300, 0xFF42A5F5, 0xFFFF7043),          // Amber / Sky Blue / Coral
    ColorPreset.custom: (0xFFE53935, 0xFF43A047, 0xFF757575),        // Red / Green / Gray (default for custom)
  };

  static const Map<AppThemePreset, ThemePalette> _themePalettes = {
    // Classic - Indigo theme, subtle blue tinting
    AppThemePreset.classic: ThemePalette(
      primary: Colors.indigo,
      backgroundLight: Color(0xFFF8F9FC),
      backgroundDark: Color(0xFF0F1118),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF1A1D27),
      surfaceContainerLight: Color(0xFFF0F2F8),
      surfaceContainerDark: Color(0xFF252838),
    ),
    // Ocean - Teal theme, cool blue-green tinting
    AppThemePreset.ocean: ThemePalette(
      primary: Colors.teal,
      backgroundLight: Color(0xFFF5FAFA),
      backgroundDark: Color(0xFF0A1A1F),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF142028),
      surfaceContainerLight: Color(0xFFE8F4F4),
      surfaceContainerDark: Color(0xFF1E2D33),
    ),
    // Sunset - Deep orange theme, warm tinting
    AppThemePreset.sunset: ThemePalette(
      primary: Colors.deepOrange,
      backgroundLight: Color(0xFFFFF9F5),
      backgroundDark: Color(0xFF1F140A),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF281E14),
      surfaceContainerLight: Color(0xFFFFF0E8),
      surfaceContainerDark: Color(0xFF33281E),
    ),
    // Monochrome - Neutral gray theme
    AppThemePreset.monochrome: ThemePalette(
      primary: Colors.blueGrey,
      backgroundLight: Color(0xFFFAFAFA),
      backgroundDark: Color(0xFF121212),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF1C1C1C),
      surfaceContainerLight: Color(0xFFF5F5F5),
      surfaceContainerDark: Color(0xFF262626),
    ),
    // Forest - Green theme, deep forest tinting
    AppThemePreset.forest: ThemePalette(
      primary: Colors.green,
      backgroundLight: Color(0xFFF5FAF5),
      backgroundDark: Color(0xFF0A1F0A),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF142814),
      surfaceContainerLight: Color(0xFFE8F4E8),
      surfaceContainerDark: Color(0xFF1E331E),
    ),
    // Berry - Pink/magenta theme
    AppThemePreset.berry: ThemePalette(
      primary: Color(0xFFE91E63),
      backgroundLight: Color(0xFFFFF5F8),
      backgroundDark: Color(0xFF1A0A14),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF28141E),
      surfaceContainerLight: Color(0xFFFFE8F0),
      surfaceContainerDark: Color(0xFF331E28),
    ),
    // Lavender - Purple theme
    AppThemePreset.lavender: ThemePalette(
      primary: Color(0xFF9C27B0),
      backgroundLight: Color(0xFFFAF5FC),
      backgroundDark: Color(0xFF140A1F),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF1E1428),
      surfaceContainerLight: Color(0xFFF0E8F8),
      surfaceContainerDark: Color(0xFF281E33),
    ),
    // Midnight - Deep blue theme
    AppThemePreset.midnight: ThemePalette(
      primary: Color(0xFF1565C0),
      backgroundLight: Color(0xFFF5F8FC),
      backgroundDark: Color(0xFF0A0F1F),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF141828),
      surfaceContainerLight: Color(0xFFE8F0F8),
      surfaceContainerDark: Color(0xFF1E2233),
    ),
    // Rose - Coral/rose theme
    AppThemePreset.rose: ThemePalette(
      primary: Color(0xFFFF6F61),
      backgroundLight: Color(0xFFFFF8F5),
      backgroundDark: Color(0xFF1F0A0F),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF281418),
      surfaceContainerLight: Color(0xFFFFE8E8),
      surfaceContainerDark: Color(0xFF331E22),
    ),
    // Mint - Mint green theme
    AppThemePreset.mint: ThemePalette(
      primary: Color(0xFF26A69A),
      backgroundLight: Color(0xFFF5FAFA),
      backgroundDark: Color(0xFF0A1F1A),
      surfaceLight: Color(0xFFFFFFFF),
      surfaceDark: Color(0xFF142824),
      surfaceContainerLight: Color(0xFFE8F8F4),
      surfaceContainerDark: Color(0xFF1E332E),
    ),
  };

  /// Get the theme palette for a preset
  static ThemePalette getPalette(AppThemePreset preset) =>
      _themePalettes[preset] ?? _themePalettes[AppThemePreset.classic]!;

  static const Map<TextScalePreset, double> _textScaleFactors = {
    TextScalePreset.small: 0.9,
    TextScalePreset.normal: 1.0,
    TextScalePreset.large: 1.1,
    TextScalePreset.extraLarge: 1.25,
  };

  static const Map<FontPreset, String?> _fontFamilies = {
    FontPreset.system: null,
    FontPreset.monospace: 'monospace',
  };

  ThemeMode _themeMode;
  ColorPreset _colorPreset;
  AppThemePreset _appThemePreset;
  int _debitColorValue;
  int _creditColorValue;
  int _neutralColorValue;
  TextScalePreset _textScalePreset;
  FontPreset _fontPreset;

  ThemeMode get themeMode => _themeMode;

  
  ColorPreset get colorPreset => _colorPreset;
  AppThemePreset get appThemePreset => _appThemePreset;
  // ignore: deprecated_member_use
  Color get debitColor => Color(_debitColorValue);
  // ignore: deprecated_member_use
  Color get creditColor => Color(_creditColorValue);
  // ignore: deprecated_member_use
  Color get neutralColor => Color(_neutralColorValue);
  
  TextScalePreset get textScalePreset => _textScalePreset;
  FontPreset get fontPreset => _fontPreset;
  
  double get textScaleFactor => _textScaleFactors[_textScalePreset] ?? 1.0;
  String? get fontFamily => _fontFamilies[_fontPreset];
  ThemePalette get themePalette => getPalette(_appThemePreset);
  Color get themeSeedColor => themePalette.primary;

  static Map<ColorPreset, (int, int, int)> get presetColors => _presetColors;

  set themeMode(ThemeMode value) {
    if (_themeMode == value) return;
    _themeMode = value;
    _storage.setString(_kThemeMode, AppSettingsCodecs.encodeThemeMode(value));
    notifyListeners();
  }

  set colorPreset(ColorPreset value) {
    if (_colorPreset == value) return;
    _colorPreset = value;
    _storage.setString(_kColorPreset, AppSettingsCodecs.encodeColorPreset(value));
    // Apply preset colors (unless custom, which keeps current custom colors)
    if (value != ColorPreset.custom) {
      final colors = _presetColors[value]!;
      _debitColorValue = colors.$1;
      _creditColorValue = colors.$2;
      _neutralColorValue = colors.$3;
      _storage.setInt(_kDebitColor, _debitColorValue);
      _storage.setInt(_kCreditColor, _creditColorValue);
      _storage.setInt(_kNeutralColor, _neutralColorValue);
    }
    notifyListeners();
  }

  set appThemePreset(AppThemePreset value) {
    if (_appThemePreset == value) return;
    _appThemePreset = value;
    _storage.setString(_kAppThemePreset, AppSettingsCodecs.encodeAppThemePreset(value));
    notifyListeners();
  }

  set debitColor(Color value) {
    // ignore: deprecated_member_use
    final intValue = value.value;
    if (_debitColorValue == intValue) return;
    _debitColorValue = intValue;
    _storage.setInt(_kDebitColor, intValue);
    // Switch to custom preset when user changes color directly
    if (_colorPreset != ColorPreset.custom) {
      _colorPreset = ColorPreset.custom;
      _storage.setString(_kColorPreset, AppSettingsCodecs.encodeColorPreset(ColorPreset.custom));
    }
    notifyListeners();
  }

  set creditColor(Color value) {
    // ignore: deprecated_member_use
    final intValue = value.value;
    if (_creditColorValue == intValue) return;
    _creditColorValue = intValue;
    _storage.setInt(_kCreditColor, intValue);
    // Switch to custom preset when user changes color directly
    if (_colorPreset != ColorPreset.custom) {
      _colorPreset = ColorPreset.custom;
      _storage.setString(_kColorPreset, AppSettingsCodecs.encodeColorPreset(ColorPreset.custom));
    }
    notifyListeners();
  }

  set neutralColor(Color value) {
    // ignore: deprecated_member_use
    final intValue = value.value;
    if (_neutralColorValue == intValue) return;
    _neutralColorValue = intValue;
    _storage.setInt(_kNeutralColor, intValue);
    // Switch to custom preset when user changes color directly
    if (_colorPreset != ColorPreset.custom) {
      _colorPreset = ColorPreset.custom;
      _storage.setString(_kColorPreset, AppSettingsCodecs.encodeColorPreset(ColorPreset.custom));
    }
    notifyListeners();
  }
  
  set textScalePreset(TextScalePreset value) {
    if (_textScalePreset == value) return;
    _textScalePreset = value;
    _storage.setString(_kTextScalePreset, AppSettingsCodecs.encodeTextScalePreset(value));
    notifyListeners();
  }

  set fontPreset(FontPreset value) {
    if (_fontPreset == value) return;
    _fontPreset = value;
    _storage.setString(_kFontPreset, AppSettingsCodecs.encodeFontPreset(value));
    notifyListeners();
  }
}
