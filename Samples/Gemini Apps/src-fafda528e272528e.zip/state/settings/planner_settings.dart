import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

class PlannerSettings extends ChangeNotifier {
  PlannerSettings(this._storage, {
    required DayFormat initialDayFormat,
    required PlannerSwipeAction initialSwipeLeft,
    required PlannerSwipeAction initialSwipeRight,
    required PlannerTapAction initialTapAction,
    required PaymentSwipeAction initialPaymentSwipeLeft,
    required PaymentSwipeAction initialPaymentSwipeRight,
    required PaymentDisplayMode initialPaymentDisplayMode,
    required bool initialEnableTabSwipe,
    required bool initialUseZeroBaseline,
    required bool initialShowClearedItems,
    required PlannerSortOrder initialSortOrder,
    required PlannerDateSortMode initialDateSortMode,
    required bool initialGroupByDate,
    required bool initialGroupByTheme,
    required bool initialShowPaymentOrigin,
    required MonthCardDisplayMode initialMonthCardDisplayMode,
    required MonthTotalsDisplayMode initialMonthTotalsDisplayMode,
    required MultiMonthDisplayMode initialMultiMonthDisplayMode,
    required TerminologyPreset initialTerminologyPreset,
    required PlannerViewMode initialViewMode,
    required PaymentsFilterType initialPaymentsFilterType,
    required PaymentsGroupBy initialPaymentsGroupBy,
    required bool initialPaymentsShowArchived,
    required CategoryPresetMode initialCategoryPresetMode,
  }) : _defaultDayFormat = initialDayFormat,
       _defaultSwipeLeft = initialSwipeLeft,
       _defaultSwipeRight = initialSwipeRight,
       _defaultTapAction = initialTapAction,
       _defaultPaymentSwipeLeft = initialPaymentSwipeLeft,
       _defaultPaymentSwipeRight = initialPaymentSwipeRight,
       _defaultPaymentDisplayMode = initialPaymentDisplayMode,
       _defaultEnableTabSwipe = initialEnableTabSwipe,
       _defaultUseZeroBaseline = initialUseZeroBaseline,
       _defaultShowClearedItems = initialShowClearedItems,
       _defaultSortOrder = initialSortOrder,
       _defaultDateSortMode = initialDateSortMode,
       _defaultGroupByDate = initialGroupByDate,
       _defaultGroupByTheme = initialGroupByTheme,
       _defaultShowPaymentOrigin = initialShowPaymentOrigin,
       _defaultMonthCardDisplayMode = initialMonthCardDisplayMode,
       _defaultMonthTotalsDisplayMode = initialMonthTotalsDisplayMode,
       _defaultMultiMonthDisplayMode = initialMultiMonthDisplayMode,
       _defaultTerminologyPreset = initialTerminologyPreset,
       _defaultViewMode = initialViewMode,
       _defaultPaymentsFilterType = initialPaymentsFilterType,
       _defaultPaymentsGroupBy = initialPaymentsGroupBy,
       _defaultPaymentsShowArchived = initialPaymentsShowArchived,
       _defaultCategoryPresetMode = initialCategoryPresetMode,
       
       _dayFormat = initialDayFormat,
       _plannerSwipeLeft = initialSwipeLeft,
       _plannerSwipeRight = initialSwipeRight,
       _plannerTapAction = initialTapAction,
       _paymentSwipeLeft = initialPaymentSwipeLeft,
       _paymentSwipeRight = initialPaymentSwipeRight,
       _paymentDisplayMode = initialPaymentDisplayMode,
       _enableTabSwipe = initialEnableTabSwipe,
       _plannerUseZeroBaseline = initialUseZeroBaseline,
       _plannerShowClearedItems = initialShowClearedItems,
       _plannerSortOrder = initialSortOrder,
       _plannerDateSortMode = initialDateSortMode,
       _plannerGroupByDate = initialGroupByDate,
       _plannerGroupByTheme = initialGroupByTheme,
       _plannerShowPaymentOrigin = initialShowPaymentOrigin,
       _monthCardDisplayMode = initialMonthCardDisplayMode,
       _monthTotalsDisplayMode = initialMonthTotalsDisplayMode,
       _multiMonthDisplayMode = initialMultiMonthDisplayMode,
       _terminologyPreset = initialTerminologyPreset,
       _plannerViewMode = initialViewMode,
       _paymentsFilterType = initialPaymentsFilterType,
       _paymentsGroupBy = initialPaymentsGroupBy,
       _paymentsShowArchived = initialPaymentsShowArchived,
       _categoryPresetMode = initialCategoryPresetMode;

  final StorageProvider _storage;
  AccountId? _accountId;

  // Default values (fallbacks)
  final DayFormat _defaultDayFormat;
  final PlannerSwipeAction _defaultSwipeLeft;
  final PlannerSwipeAction _defaultSwipeRight;
  final PlannerTapAction _defaultTapAction;
  final PaymentSwipeAction _defaultPaymentSwipeLeft;
  final PaymentSwipeAction _defaultPaymentSwipeRight;
  final PaymentDisplayMode _defaultPaymentDisplayMode;
  final bool _defaultEnableTabSwipe;
  final bool _defaultUseZeroBaseline;
  final bool _defaultShowClearedItems;
  final PlannerSortOrder _defaultSortOrder;
  final PlannerDateSortMode _defaultDateSortMode;
  final bool _defaultGroupByDate;
  final bool _defaultGroupByTheme;
  final bool _defaultShowPaymentOrigin;
  final MonthCardDisplayMode _defaultMonthCardDisplayMode;
  final MonthTotalsDisplayMode _defaultMonthTotalsDisplayMode;
  final MultiMonthDisplayMode _defaultMultiMonthDisplayMode;
  final TerminologyPreset _defaultTerminologyPreset;
  final PlannerViewMode _defaultViewMode;
  final PaymentsFilterType _defaultPaymentsFilterType;
  final PaymentsGroupBy _defaultPaymentsGroupBy;
  final bool _defaultPaymentsShowArchived;
  final CategoryPresetMode _defaultCategoryPresetMode;

  // Keys
  static const _kDayFormat = 'settings.dayFormat';
  static const _kPlannerSwipeLeft = 'settings.planner.swipeLeft';
  static const _kPlannerSwipeRight = 'settings.planner.swipeRight';
  static const _kPlannerTapAction = 'settings.planner.tapAction';
  static const _kPaymentSwipeLeft = 'settings.payment.swipeLeft';
  static const _kPaymentSwipeRight = 'settings.payment.swipeRight';
  static const _kPaymentDisplayMode = 'settings.payment.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kPlannerUseZeroBaseline = 'settings.planner.useZeroBaseline';
  static const _kPlannerShowClearedItems = 'settings.planner.showClearedItems';
  static const _kPlannerSortOrder = 'settings.planner.sortOrder';
  static const _kPlannerDateSortMode = 'settings.planner.dateSortMode';
  static const _kPlannerGroupByDate = 'settings.planner.groupByDate';
  static const _kPlannerShowPaymentOrigin = 'settings.planner.showPaymentOrigin';
  static const _kPlannerGroupByTheme = 'settings.planner.groupByTheme';
  static const _kMonthCardDisplayMode = 'settings.planner.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode = 'settings.planner.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayMode = 'settings.planner.multiMonthDisplayMode';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kPlannerViewMode = 'settings.planner.viewMode';
  static const _kPaymentsFilterType = 'settings.payments.filterType';
  static const _kPaymentsGroupBy = 'settings.payments.groupBy';
  static const _kPaymentsShowArchived = 'settings.payments.showArchived';
  static const _kCategoryPresetMode = 'settings.planner.categoryPresetMode';
  static const _kPaymentsFilterCategory = 'settings.payments.filterCategory'; // [NEW]

  DayFormat _dayFormat;
  PlannerSwipeAction _plannerSwipeLeft;
  PlannerSwipeAction _plannerSwipeRight;
  PlannerTapAction _plannerTapAction;
  PaymentSwipeAction _paymentSwipeLeft;
  PaymentSwipeAction _paymentSwipeRight;
  PaymentDisplayMode _paymentDisplayMode;
  bool _enableTabSwipe;
  bool _plannerUseZeroBaseline;
  bool _plannerShowClearedItems;
  PlannerSortOrder _plannerSortOrder;
  PlannerDateSortMode _plannerDateSortMode;
  bool _plannerGroupByDate;
  bool _plannerGroupByTheme;
  bool _plannerShowPaymentOrigin;
  MonthCardDisplayMode _monthCardDisplayMode;
  MonthTotalsDisplayMode _monthTotalsDisplayMode;
  MultiMonthDisplayMode _multiMonthDisplayMode;
  TerminologyPreset _terminologyPreset;
  PlannerViewMode _plannerViewMode;
  PaymentsFilterType _paymentsFilterType;
  PaymentsGroupBy _paymentsGroupBy;
  bool _paymentsShowArchived;
  CategoryPresetMode _categoryPresetMode;
  String? _paymentsFilterCategory; // [NEW]

  DayFormat get dayFormat => _dayFormat;
  PlannerSwipeAction get plannerSwipeLeft => _plannerSwipeLeft;
  PlannerSwipeAction get plannerSwipeRight => _plannerSwipeRight;
  PlannerTapAction get plannerTapAction => _plannerTapAction;
  PaymentSwipeAction get paymentSwipeLeft => _paymentSwipeLeft;
  PaymentSwipeAction get paymentSwipeRight => _paymentSwipeRight;
  PaymentDisplayMode get paymentDisplayMode => _paymentDisplayMode;
  bool get enableTabSwipe => _enableTabSwipe;
  bool get plannerUseZeroBaseline => _plannerUseZeroBaseline;
  bool get plannerShowClearedItems => _plannerShowClearedItems;
  PlannerSortOrder get plannerSortOrder => _plannerSortOrder;
  PlannerDateSortMode get plannerDateSortMode => _plannerDateSortMode;
  bool get plannerGroupByDate => _plannerGroupByDate;
  bool get plannerGroupByTheme => _plannerGroupByTheme;
  bool get plannerShowPaymentOrigin => _plannerShowPaymentOrigin;
  MonthCardDisplayMode get monthCardDisplayMode => _monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => _monthTotalsDisplayMode;
  MultiMonthDisplayMode get multiMonthDisplayMode => _multiMonthDisplayMode;
  TerminologyPreset get terminologyPreset => _terminologyPreset;
  PlannerViewMode get plannerViewMode => _plannerViewMode;
  PaymentsFilterType get paymentsFilterType => _paymentsFilterType;
  PaymentsGroupBy get paymentsGroupBy => _paymentsGroupBy;
  bool get paymentsShowArchived => _paymentsShowArchived;
  CategoryPresetMode get categoryPresetMode => _categoryPresetMode;
  String? get paymentsFilterCategory => _paymentsFilterCategory; // [NEW]

  AccountId? get accountId => _accountId;

  String _key(String baseKey) {
    if (_accountId != null) {
      return 'account.$_accountId.$baseKey';
    }
    return baseKey;
  }

  Future<void> setAccountId(AccountId? id) async {
    if (_accountId == id) return;
    _accountId = id;
    await _loadSettings();
    notifyListeners();
  }

  Future<void> _loadSettings() async {
    // Helper to read string with fallback: 
    // 1. Account key (if account set)
    // 2. Global key
    Future<String?> readString(String baseKey) async {
      if (_accountId != null) {
        final accountVal = await _storage.getString(_key(baseKey));
        if (accountVal != null) return accountVal;
      }
      return _storage.getString(baseKey);
    }
    
    // Helper for bool
    Future<bool?> readBool(String baseKey) async {
      if (_accountId != null) {
        final accountVal = await _storage.getBool(_key(baseKey));
        if (accountVal != null) return accountVal;
      }
      return _storage.getBool(baseKey);
    }

    // Helper for int


    _dayFormat = AppSettingsCodecs.decodeDayFormat(await readString(_kDayFormat)) ?? _defaultDayFormat;
    _plannerSwipeLeft = AppSettingsCodecs.decodeSwipeAction(await readString(_kPlannerSwipeLeft)) ?? _defaultSwipeLeft;
    _plannerSwipeRight = AppSettingsCodecs.decodeSwipeAction(await readString(_kPlannerSwipeRight)) ?? _defaultSwipeRight;
    _plannerTapAction = AppSettingsCodecs.decodePlannerTapAction(await readString(_kPlannerTapAction)) ?? _defaultTapAction;
    _paymentSwipeLeft = AppSettingsCodecs.decodePaymentSwipeAction(await readString(_kPaymentSwipeLeft)) ?? _defaultPaymentSwipeLeft;
    _paymentSwipeRight = AppSettingsCodecs.decodePaymentSwipeAction(await readString(_kPaymentSwipeRight)) ?? _defaultPaymentSwipeRight;
    _paymentDisplayMode = AppSettingsCodecs.decodePaymentDisplayMode(await readString(_kPaymentDisplayMode)) ?? _defaultPaymentDisplayMode;
    
    _enableTabSwipe = await readBool(_kEnableTabSwipe) ?? _defaultEnableTabSwipe;
    _plannerUseZeroBaseline = await readBool(_kPlannerUseZeroBaseline) ?? _defaultUseZeroBaseline;
    _plannerShowClearedItems = await readBool(_kPlannerShowClearedItems) ?? _defaultShowClearedItems;
    
    _plannerSortOrder = AppSettingsCodecs.decodeSortOrder(await readString(_kPlannerSortOrder)) ?? _defaultSortOrder;
    _plannerDateSortMode = AppSettingsCodecs.decodePlannerDateSortMode(await readString(_kPlannerDateSortMode)) ?? _defaultDateSortMode;
    
    _plannerGroupByDate = await readBool(_kPlannerGroupByDate) ?? _defaultGroupByDate;
    _plannerGroupByTheme = await readBool(_kPlannerGroupByTheme) ?? _defaultGroupByTheme;
    _plannerShowPaymentOrigin = await readBool(_kPlannerShowPaymentOrigin) ?? _defaultShowPaymentOrigin;
    
    _monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(await readString(_kMonthCardDisplayMode)) ?? _defaultMonthCardDisplayMode;
    _monthTotalsDisplayMode = AppSettingsCodecs.decodeMonthTotalsDisplayMode(await readString(_kMonthTotalsDisplayMode)) ?? _defaultMonthTotalsDisplayMode;
    _multiMonthDisplayMode = AppSettingsCodecs.decodeMultiMonthDisplayMode(await readString(_kMultiMonthDisplayMode)) ?? _defaultMultiMonthDisplayMode;
    _terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(await readString(_kTerminologyPreset)) ?? _defaultTerminologyPreset;
    _plannerViewMode = AppSettingsCodecs.decodePlannerViewMode(await readString(_kPlannerViewMode)) ?? _defaultViewMode;
    
    _paymentsFilterType = AppSettingsCodecs.decodePaymentsFilterType(await readString(_kPaymentsFilterType)) ?? _defaultPaymentsFilterType;
    _paymentsGroupBy = AppSettingsCodecs.decodePaymentsGroupBy(await readString(_kPaymentsGroupBy)) ?? _defaultPaymentsGroupBy;
    _paymentsShowArchived = await readBool(_kPaymentsShowArchived) ?? _defaultPaymentsShowArchived;
    _categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(await readString(_kCategoryPresetMode)) ?? _defaultCategoryPresetMode;
    _paymentsFilterCategory = await readString(_kPaymentsFilterCategory); // [NEW]
    
    final quickAddAmountsStr = await readString(_kQuickAddAmounts);
    if (quickAddAmountsStr != null && quickAddAmountsStr.isNotEmpty) {
      try {
        _customQuickAddAmounts = quickAddAmountsStr.split(',').map(int.parse).toList();
      } catch (_) {
        // Fallback to defaults if parsing fails
      }
    }
  }

  set dayFormat(DayFormat value) {
    if (_dayFormat == value) return;
    _dayFormat = value;
    _storage.setString(_key(_kDayFormat), AppSettingsCodecs.encodeDayFormat(value));
    notifyListeners();
  }

  set plannerSwipeLeft(PlannerSwipeAction value) {
    if (_plannerSwipeLeft == value) return;
    _plannerSwipeLeft = value;
    _storage.setString(_key(_kPlannerSwipeLeft), AppSettingsCodecs.encodeSwipeAction(value));
    notifyListeners();
  }

  set plannerSwipeRight(PlannerSwipeAction value) {
    if (_plannerSwipeRight == value) return;
    _plannerSwipeRight = value;
    _storage.setString(_key(_kPlannerSwipeRight), AppSettingsCodecs.encodeSwipeAction(value));
    notifyListeners();
  }

  set plannerTapAction(PlannerTapAction value) {
    if (_plannerTapAction == value) return;
    _plannerTapAction = value;
    _storage.setString(_key(_kPlannerTapAction), AppSettingsCodecs.encodePlannerTapAction(value));
    notifyListeners();
  }

  set paymentSwipeLeft(PaymentSwipeAction value) {
    if (_paymentSwipeLeft == value) return;
    _paymentSwipeLeft = value;
    _storage.setString(_key(_kPaymentSwipeLeft), AppSettingsCodecs.encodePaymentSwipeAction(value));
    notifyListeners();
  }

  set paymentSwipeRight(PaymentSwipeAction value) {
    if (_paymentSwipeRight == value) return;
    _paymentSwipeRight = value;
    _storage.setString(_key(_kPaymentSwipeRight), AppSettingsCodecs.encodePaymentSwipeAction(value));
    notifyListeners();
  }

  set paymentDisplayMode(PaymentDisplayMode value) {
    if (_paymentDisplayMode == value) return;
    _paymentDisplayMode = value;
    _storage.setString(_key(_kPaymentDisplayMode), AppSettingsCodecs.encodePaymentDisplayMode(value));
    notifyListeners();
  }

  set enableTabSwipe(bool value) {
    if (_enableTabSwipe == value) return;
    _enableTabSwipe = value;
    _storage.setBool(_key(_kEnableTabSwipe), value);
    notifyListeners();
  }

  set plannerUseZeroBaseline(bool value) {
    if (_plannerUseZeroBaseline == value) return;
    _plannerUseZeroBaseline = value;
    _storage.setBool(_key(_kPlannerUseZeroBaseline), value);
    notifyListeners();
  }

  set plannerShowClearedItems(bool value) {
    if (_plannerShowClearedItems == value) return;
    _plannerShowClearedItems = value;
    _storage.setBool(_key(_kPlannerShowClearedItems), value);
    notifyListeners();
  }

  set plannerSortOrder(PlannerSortOrder value) {
    if (_plannerSortOrder == value) return;
    _plannerSortOrder = value;
    _storage.setString(_key(_kPlannerSortOrder), AppSettingsCodecs.encodeSortOrder(value));
    notifyListeners();
  }

  set plannerDateSortMode(PlannerDateSortMode value) {
    if (_plannerDateSortMode == value) return;
    _plannerDateSortMode = value;
    _storage.setString(_key(_kPlannerDateSortMode), AppSettingsCodecs.encodePlannerDateSortMode(value));
    notifyListeners();
  }



  set plannerGroupByDate(bool value) {
    if (_plannerGroupByDate == value) return;
    _plannerGroupByDate = value;
    _storage.setBool(_key(_kPlannerGroupByDate), value);
    notifyListeners();
  }

  set plannerGroupByTheme(bool value) {
    if (_plannerGroupByTheme == value) return;
    _plannerGroupByTheme = value;
    _storage.setBool(_key(_kPlannerGroupByTheme), value);
    notifyListeners();
  }

  set plannerShowPaymentOrigin(bool value) {
    if (_plannerShowPaymentOrigin == value) return;
    _plannerShowPaymentOrigin = value;
    _storage.setBool(_key(_kPlannerShowPaymentOrigin), value);
    notifyListeners();
  }

  set monthCardDisplayMode(MonthCardDisplayMode value) {
    if (_monthCardDisplayMode == value) return;
    _monthCardDisplayMode = value;
    _storage.setString(_key(_kMonthCardDisplayMode), AppSettingsCodecs.encodeMonthCardDisplayMode(value));
    notifyListeners();
  }

  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) {
    if (_monthTotalsDisplayMode == value) return;
    _monthTotalsDisplayMode = value;
    _storage.setString(
      _key(_kMonthTotalsDisplayMode),
      AppSettingsCodecs.encodeMonthTotalsDisplayMode(value),
    );
    notifyListeners();
  }

  set multiMonthDisplayMode(MultiMonthDisplayMode value) {
    if (_multiMonthDisplayMode == value) return;
    _multiMonthDisplayMode = value;
    _storage.setString(_key(_kMultiMonthDisplayMode), AppSettingsCodecs.encodeMultiMonthDisplayMode(value));
    notifyListeners();
  }

  set terminologyPreset(TerminologyPreset value) {
    if (_terminologyPreset == value) return;
    _terminologyPreset = value;
    _storage.setString(_key(_kTerminologyPreset), AppSettingsCodecs.encodeTerminologyPreset(value));
    notifyListeners();
  }

  set plannerViewMode(PlannerViewMode value) {
    if (_plannerViewMode == value) return;
    _plannerViewMode = value;
    _storage.setString(_key(_kPlannerViewMode), AppSettingsCodecs.encodePlannerViewMode(value));
    notifyListeners();
  }

  set paymentsFilterType(PaymentsFilterType value) {
    if (_paymentsFilterType == value) return;
    _paymentsFilterType = value;
    _storage.setString(_key(_kPaymentsFilterType), AppSettingsCodecs.encodePaymentsFilterType(value));
    notifyListeners();
  }

  set paymentsGroupBy(PaymentsGroupBy value) {
    if (_paymentsGroupBy == value) return;
    _paymentsGroupBy = value;
    _storage.setString(_key(_kPaymentsGroupBy), AppSettingsCodecs.encodePaymentsGroupBy(value));
    notifyListeners();
  }

  set paymentsShowArchived(bool value) {
    if (_paymentsShowArchived == value) return;
    _paymentsShowArchived = value;
    _storage.setBool(_key(_kPaymentsShowArchived), value);
    notifyListeners();
  }

  set categoryPresetMode(CategoryPresetMode value) {
    if (_categoryPresetMode == value) return;
    _categoryPresetMode = value;
    _storage.setString(
      _key(_kCategoryPresetMode),
      AppSettingsCodecs.encodeCategoryPresetMode(value),
    );
    notifyListeners();
  }

  // [NEW]
  set paymentsFilterCategory(String? value) {
    if (_paymentsFilterCategory == value) return;
    _paymentsFilterCategory = value;
    if (value == null) {
      _storage.remove(_key(_kPaymentsFilterCategory));
    } else {
      _storage.setString(_key(_kPaymentsFilterCategory), value);
    }
    notifyListeners();
  }

  // Quick Spending Amounts
  static const _kQuickAddAmounts = 'settings.planner.quickAddAmounts';
  List<int> _customQuickAddAmounts = const [500, 1000, 2000, 3000, 5000, 10000]; // Default 5, 10, 20, 30, 50, 100
  
  List<int> get customQuickAddAmounts => List.unmodifiable(_customQuickAddAmounts);

  set customQuickAddAmounts(List<int> value) {
    if (listEquals(_customQuickAddAmounts, value)) return;
    _customQuickAddAmounts = List.from(value);
    _storage.setString(
      _key(_kQuickAddAmounts),
      value.join(','),
    );
    notifyListeners();
  }
}
