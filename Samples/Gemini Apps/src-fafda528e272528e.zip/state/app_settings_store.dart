import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/planner_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';

export 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
export 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/planner_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';

class AppSettingsStore extends ChangeNotifier {
  AppSettingsStore._(
    this._storage,
    this.themeSettings,
    this.currencySettings,
    this.plannerSettings,
    this.moneyPotsSettings,
    this._regionPresetId,
  ) {
    themeSettings.addListener(notifyListeners);
    currencySettings.addListener(notifyListeners);
    plannerSettings.addListener(notifyListeners);
    moneyPotsSettings.addListener(notifyListeners);
  }

  final StorageProvider _storage;

  final ThemeSettings themeSettings;
  final CurrencySettings currencySettings;
  final PlannerSettings plannerSettings;
  final MoneyPotsSettings moneyPotsSettings;
  
  String _regionPresetId;
  
  // Reference to ExpenseStore for account-specific settings delegation
  ExpenseStore? _expenseStore;
  
  /// Bind the ExpenseStore after both are initialized.
  /// This allows paycheck settings to be read from the current account.
  void bindExpenseStore(ExpenseStore store) {
    _expenseStore = store;
    // Initialize with current account
    plannerSettings.setAccountId(store.currentAccount.id);
    
    store.addListener(() {
      final nextId = _expenseStore?.currentAccount.id;
      if (nextId != null && plannerSettings.accountId != nextId) {
        // Propagate account change to planner settings
        // This will call notifyListeners() when it finishes loading settings
        plannerSettings.setAccountId(nextId);
      } else {
        // If the account didn't change, we still notify so proxied 
        // properties (like plannerSortOrder) are seen as updated by listeners.
        notifyListeners();
      }
    });
  }

  static const _kRegionPreset = 'settings.regionPreset';
  
  // Forward keys for loadOrCreate convenience (though usage is internal now)
  static const _kThemeMode = 'settings.themeMode';
  static const _kCurrency = 'settings.currency';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';
  static const _kDayFormat = 'settings.dayFormat';
  static const _kPlannerSwipeLeft = 'settings.planner.swipeLeft';
  static const _kPlannerSwipeRight = 'settings.planner.swipeRight';
  static const _kPlannerTapAction = 'settings.planner.tapAction';
  static const _kPaymentSwipeLeft = 'settings.payment.swipeLeft';
  static const _kPaymentSwipeRight = 'settings.payment.swipeRight';
  static const _kPaymentDisplayMode = 'settings.payment.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kPlannerUseZeroBaseline = 'settings.planner.useZeroBaseline';
  static const _kPlannerShowClearedItems = 'settings.planner.showClearedItems';
  static const _kPlannerSortOrder = 'settings.planner.sortOrder';
  static const _kPlannerDateSortMode = 'settings.planner.dateSortMode';
  static const _kPaycheckDay = 'settings.paycheckDay';
  static const _kPaycheckBusinessAdjust = 'settings.paycheck.businessAdjust';
  static const _kPaycheckBusinessAdjustDirection = 'settings.paycheck.businessAdjustDirection';
  static const _kColorPreset = 'settings.colors.preset';
  static const _kAppThemePreset = 'settings.colors.appThemePreset';
  static const _kDebitColor = 'settings.colors.debit';
  static const _kCreditColor = 'settings.colors.credit';
  static const _kNeutralColor = 'settings.colors.neutral';
  static const _kPlannerGroupByDate = 'settings.planner.groupByDate';
  static const _kPlannerGroupByTheme = 'settings.planner.groupByTheme';
  static const _kPlannerShowPaymentOrigin = 'settings.planner.showPaymentOrigin';
  static const _kMonthCardDisplayMode = 'settings.planner.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode = 'settings.planner.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayMode = 'settings.planner.multiMonthDisplayMode';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kTextScalePreset = 'settings.textScale';
  static const _kFontPreset = 'settings.fontPreset';
  static const _kPlannerViewMode = 'settings.planner.viewMode';
  static const _kShowCents = 'settings.currency.showCents';
  static const _kRoundingIncrement = 'settings.currency.roundingIncrement';
  static const _kPaymentsFilterType = 'settings.payments.filterType';
  static const _kPaymentsGroupBy = 'settings.payments.groupBy';
  static const _kPaymentsShowArchived = 'settings.payments.showArchived';
  static const _kCategoryPresetMode = 'settings.planner.categoryPresetMode';
  static const _kMoneyPots = 'settings.moneyPots';
  static const _kMoneyPotsSectionLabel = 'settings.moneyPots.sectionLabel';
  static const _kMoneyPotsScope = 'settings.moneyPots.scope';
  static const _kEnabledCurrencies = 'settings.currency.enabledCurrencies';
  static const _kExchangeRates = 'settings.currency.exchangeRates';
  static const _kAutoUpdateRates = 'settings.currency.autoUpdateRates';

  // ===========================================================================
  // Static Data Access Accessors (Delegated)
  // ===========================================================================

  Map<ColorPreset, (int, int, int)> get presetColors => ThemeSettings.presetColors;

  // ===========================================================================
  // Proxied Getters
  // ===========================================================================

  String get regionPresetId => _regionPresetId;
  List<RegionPreset> get regionPresets => AppSettingsPresets.regionPresets;
  RegionPreset get regionPreset => AppSettingsPresets.regionPresetForId(_regionPresetId);

  // Theme Proxies
  ThemeMode get themeMode => themeSettings.themeMode;
  ColorPreset get colorPreset => themeSettings.colorPreset;
  AppThemePreset get appThemePreset => themeSettings.appThemePreset;
  Color get debitColor => themeSettings.debitColor;
  Color get creditColor => themeSettings.creditColor;
  Color get neutralColor => themeSettings.neutralColor;
  Color get themeSeedColor => themeSettings.themeSeedColor;
  TextScalePreset get textScalePreset => themeSettings.textScalePreset;
  FontPreset get fontPreset => themeSettings.fontPreset;
  double get textScaleFactor => themeSettings.textScaleFactor;
  String? get fontFamily => themeSettings.fontFamily;

  // Currency Proxies
  AppCurrency get currency => currencySettings.currency;
  int get currentBalanceCents => currencySettings.currentBalanceCents;
  bool get showCents => currencySettings.showCents;
  int get roundingIncrement => currencySettings.roundingIncrement;
  Set<AppCurrency> get enabledCurrencies => currencySettings.enabledCurrencies;
  Map<AppCurrency, double> get exchangeRates => currencySettings.exchangeRates;
  bool get autoUpdateRates => currencySettings.autoUpdateRates;

  // Planner Proxies
  // Planner Proxies - Account specific with global fallback
  DayFormat get dayFormat => _expenseStore?.currentAccount.dayFormat ?? plannerSettings.dayFormat;
  PlannerSwipeAction get plannerSwipeLeft => _expenseStore?.currentAccount.plannerSwipeLeft ?? plannerSettings.plannerSwipeLeft;
  PlannerSwipeAction get plannerSwipeRight => _expenseStore?.currentAccount.plannerSwipeRight ?? plannerSettings.plannerSwipeRight;
  PlannerTapAction get plannerTapAction => _expenseStore?.currentAccount.plannerTapAction ?? plannerSettings.plannerTapAction;
  PaymentSwipeAction get paymentSwipeLeft => _expenseStore?.currentAccount.paymentSwipeLeft ?? plannerSettings.paymentSwipeLeft;
  PaymentSwipeAction get paymentSwipeRight => _expenseStore?.currentAccount.paymentSwipeRight ?? plannerSettings.paymentSwipeRight;
  PaymentDisplayMode get paymentDisplayMode => _expenseStore?.currentAccount.paymentDisplayMode ?? plannerSettings.paymentDisplayMode;
  bool get enableTabSwipe => _expenseStore?.currentAccount.enableTabSwipe ?? plannerSettings.enableTabSwipe;
  bool get plannerUseZeroBaseline => _expenseStore?.currentAccount.plannerUseZeroBaseline ?? plannerSettings.plannerUseZeroBaseline;
  bool get plannerShowClearedItems => _expenseStore?.currentAccount.plannerShowClearedItems ?? plannerSettings.plannerShowClearedItems;
  PlannerSortOrder get plannerSortOrder => _expenseStore?.currentAccount.plannerSortOrder ?? plannerSettings.plannerSortOrder;
  PlannerDateSortMode get plannerDateSortMode => _expenseStore?.currentAccount.plannerDateSortMode ?? plannerSettings.plannerDateSortMode;
  
  // ViewPeriodMode is account-specific
  ViewPeriodMode get viewPeriodMode => _expenseStore?.currentAccount.viewPeriodMode ?? ViewPeriodMode.calendar;
  
  // Account-specific settings - these are ONLY stored in the Account model
  // If no account is loaded, we return sensible defaults but cannot persist changes
  int? get paycheckDay => _expenseStore?.currentAccount.paycheckDay;
  bool get isPaycheckModeConfigured => paycheckDay != null;
  bool get paycheckBusinessAdjust => _expenseStore?.currentAccount.paycheckBusinessAdjust ?? true;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection => _expenseStore?.currentAccount.paycheckBusinessAdjustDirection ?? PaycheckAdjustDirection.after;
  int get startingBalanceCents => _expenseStore?.currentAccount.startingBalanceCents ?? currencySettings.currentBalanceCents;
  bool get plannerGroupByDate => _expenseStore?.currentAccount.plannerGroupByDate ?? plannerSettings.plannerGroupByDate;
  bool get plannerGroupByTheme => _expenseStore?.currentAccount.plannerGroupByTheme ?? plannerSettings.plannerGroupByTheme;
  bool get plannerShowPaymentOrigin => _expenseStore?.currentAccount.plannerShowPaymentOrigin ?? plannerSettings.plannerShowPaymentOrigin;
  MonthCardDisplayMode get monthCardDisplayMode => _expenseStore?.currentAccount.monthCardDisplayMode ?? plannerSettings.monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => _expenseStore?.currentAccount.monthTotalsDisplayMode ?? plannerSettings.monthTotalsDisplayMode;
  MultiMonthDisplayMode get multiMonthDisplayMode => _expenseStore?.currentAccount.multiMonthDisplayMode ?? plannerSettings.multiMonthDisplayMode;
  TerminologyPreset get terminologyPreset => _expenseStore?.currentAccount.terminologyPreset ?? plannerSettings.terminologyPreset;
  PlannerViewMode get plannerViewMode => _expenseStore?.currentAccount.plannerViewMode ?? plannerSettings.plannerViewMode;
  PaymentsFilterType get paymentsFilterType => _expenseStore?.currentAccount.paymentsFilterType ?? plannerSettings.paymentsFilterType;
  String? get paymentsFilterCategory => plannerSettings.paymentsFilterCategory; // [NEW] Account-specific handled by plannerSettings internal logic via setAccountId
  PaymentsGroupBy get paymentsGroupBy => _expenseStore?.currentAccount.paymentsGroupBy ?? plannerSettings.paymentsGroupBy;
  bool get paymentsShowArchived => _expenseStore?.currentAccount.paymentsShowArchived ?? plannerSettings.paymentsShowArchived;
  CategoryPresetMode get categoryPresetMode => _expenseStore?.currentAccount.categoryPresetMode ?? plannerSettings.categoryPresetMode;
  List<int> get customQuickAddAmounts => plannerSettings.customQuickAddAmounts;

  // Money Pots - can be global or account-specific based on scope setting
  MoneyPotsScope get moneyPotsScope => moneyPotsSettings.scope;
  
  List<MoneyPot> get moneyPots {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      return _expenseStore!.currentAccount.moneyPots;
    }
    return moneyPotsSettings.moneyPots;
  }
  
  String get moneyPotsSectionLabel {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      return _expenseStore!.currentAccount.moneyPotsSectionLabel ?? MoneyPotsSettings.defaultSectionLabel;
    }
    return moneyPotsSettings.sectionLabel;
  }

  Future<void> updateMoneyPotsSectionLabel(String label) async {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      await _expenseStore!.updateMoneyPotsSectionLabel(label);
    } else {
      moneyPotsSettings.sectionLabel = label;
    }
  }

  Future<void> addMoneyPot(MoneyPot pot) async {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      await _expenseStore!.addMoneyPot(pot);
    } else {
      moneyPotsSettings.addMoneyPot(pot);
    }
  }

  Future<void> updateMoneyPot(MoneyPot pot) async {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      await _expenseStore!.updateMoneyPot(pot);
    } else {
      moneyPotsSettings.updateMoneyPot(pot);
    }
  }

  Future<void> removeMoneyPot(String id) async {
    if (moneyPotsScope == MoneyPotsScope.accountSpecific && _expenseStore != null) {
      await _expenseStore!.removeMoneyPot(id);
    } else {
      moneyPotsSettings.removeMoneyPot(id);
    }
  }

  // ===========================================================================
  // Proxied Setters
  // ===========================================================================

  set themeMode(ThemeMode value) => themeSettings.themeMode = value;
  set colorPreset(ColorPreset value) => themeSettings.colorPreset = value;
  set appThemePreset(AppThemePreset value) => themeSettings.appThemePreset = value;
  set debitColor(Color value) => themeSettings.debitColor = value;
  set creditColor(Color value) => themeSettings.creditColor = value;
  set neutralColor(Color value) => themeSettings.neutralColor = value;
  set textScalePreset(TextScalePreset value) => themeSettings.textScalePreset = value;
  set fontPreset(FontPreset value) => themeSettings.fontPreset = value;

  set currency(AppCurrency value) => currencySettings.currency = value;
  
  // =====================
  // Logic for region preset
  // =====================

  set regionPresetId(String value) {
    if (_regionPresetId == value) return;
    _regionPresetId = value;
    _storage.setString(_kRegionPreset, value);
    final preset = AppSettingsPresets.regionPresetForId(value);
    final locale = AppSettingsPresets.localeFromPlatform();
    final nextCurrency = preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
    final nextDayFormat = preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);
    
    currencySettings.currency = nextCurrency;
    plannerSettings.dayFormat = nextDayFormat;
    notifyListeners();
  }

  // Setters for proxies
  set currentBalanceCents(int value) => currencySettings.currentBalanceCents = value;
  set showCents(bool value) => currencySettings.showCents = value;
  set roundingIncrement(int value) => currencySettings.roundingIncrement = value;
  set autoUpdateRates(bool value) => currencySettings.autoUpdateRates = value;
  void enableCurrency(AppCurrency value) => currencySettings.enableCurrency(value);
  void disableCurrency(AppCurrency value) => currencySettings.disableCurrency(value);
  void setExchangeRate(AppCurrency currency, double rate) => currencySettings.setExchangeRate(currency, rate);
  void updateAllExchangeRates(Map<AppCurrency, double> rates) => currencySettings.updateAllExchangeRates(rates);

  set dayFormat(DayFormat value) {
    if (_expenseStore != null) {
      _expenseStore!.updateDayFormat(value);
    } else {
      plannerSettings.dayFormat = value;
    }
  }

  set plannerSwipeLeft(PlannerSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerSwipeLeft(value);
    } else {
      plannerSettings.plannerSwipeLeft = value;
    }
  }

  set plannerSwipeRight(PlannerSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerSwipeRight(value);
    } else {
      plannerSettings.plannerSwipeRight = value;
    }
  }

  set plannerTapAction(PlannerTapAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerTapAction(value);
    } else {
      plannerSettings.plannerTapAction = value;
    }
  }

  set paymentSwipeLeft(PaymentSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentSwipeLeft(value);
    } else {
      plannerSettings.paymentSwipeLeft = value;
    }
  }

  set paymentSwipeRight(PaymentSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentSwipeRight(value);
    } else {
      plannerSettings.paymentSwipeRight = value;
    }
  }

  set paymentDisplayMode(PaymentDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentDisplayMode(value);
    } else {
      plannerSettings.paymentDisplayMode = value;
    }
  }

  set enableTabSwipe(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateEnableTabSwipe(value);
    } else {
      plannerSettings.enableTabSwipe = value;
    }
  }

  set plannerUseZeroBaseline(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerUseZeroBaseline(value);
    } else {
      plannerSettings.plannerUseZeroBaseline = value;
    }
  }
  set plannerShowClearedItems(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerShowClearedItems(value);
    } else {
      plannerSettings.plannerShowClearedItems = value;
    }
  }
  set plannerSortOrder(PlannerSortOrder value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerSortOrder(value);
    } else {
      plannerSettings.plannerSortOrder = value;
    }
  }
  set plannerDateSortMode(PlannerDateSortMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerDateSortMode(value);
    } else {
      plannerSettings.plannerDateSortMode = value;
    }
  }
  set viewPeriodMode(ViewPeriodMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateViewPeriodMode(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }
  
  // Paycheck setters - these are account-specific only
  set paycheckDay(int? value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckDay(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }
  
  set paycheckBusinessAdjust(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjust(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }
  
  set paycheckBusinessAdjustDirection(PaycheckAdjustDirection value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjustDirection(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }
  
  set startingBalanceCents(int value) {
    if (_expenseStore != null) {
      _expenseStore!.updateStartingBalance(value);
    } else {
      currencySettings.currentBalanceCents = value;
    }
  }
  set plannerGroupByDate(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerGroupByDate(value);
    } else {
      plannerSettings.plannerGroupByDate = value;
    }
  }
  set plannerGroupByTheme(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerGroupByTheme(value);
    } else {
      plannerSettings.plannerGroupByTheme = value;
    }
  }
  set plannerShowPaymentOrigin(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerShowPaymentOrigin(value);
    } else {
      plannerSettings.plannerShowPaymentOrigin = value;
    }
  }
  set monthCardDisplayMode(MonthCardDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateMonthCardDisplayMode(value);
    } else {
      plannerSettings.monthCardDisplayMode = value;
    }
  }
  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateMonthTotalsDisplayMode(value);
    } else {
      plannerSettings.monthTotalsDisplayMode = value;
    }
  }
  set multiMonthDisplayMode(MultiMonthDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateMultiMonthDisplayMode(value);
    } else {
      plannerSettings.multiMonthDisplayMode = value;
    }
  }
  set terminologyPreset(TerminologyPreset value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTerminologyPreset(value);
    } else {
      plannerSettings.terminologyPreset = value;
    }
  }
  set plannerViewMode(PlannerViewMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePlannerViewMode(value);
    } else {
      plannerSettings.plannerViewMode = value;
    }
  }
  set paymentsFilterType(PaymentsFilterType value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentsFilterType(value);
    } else {
      plannerSettings.paymentsFilterType = value;
    }
  }
  set paymentsFilterCategory(String? value) => plannerSettings.paymentsFilterCategory = value; // [NEW]
  set paymentsGroupBy(PaymentsGroupBy value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentsGroupBy(value);
    } else {
      plannerSettings.paymentsGroupBy = value;
    }
  }
  set paymentsShowArchived(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaymentsShowArchived(value);
    } else {
      plannerSettings.paymentsShowArchived = value;
    }
  }
  set categoryPresetMode(CategoryPresetMode value) => plannerSettings.categoryPresetMode = value;
  set customQuickAddAmounts(List<int> value) => plannerSettings.customQuickAddAmounts = value;

  set moneyPotsScope(MoneyPotsScope value) => moneyPotsSettings.scope = value;


  static Future<AppSettingsStore> loadOrCreate() async {
    final storage = await StorageProvider.create();
    try {
      // Load all values
      final themeMode = AppSettingsCodecs.decodeThemeMode(await storage.getString(_kThemeMode)) ?? ThemeMode.system;
      final currencyStored = await storage.getString(_kCurrency);
      final balance = await storage.getInt(_kCurrentBalanceCents) ?? 0;
      final dayFormatStored = await storage.getString(_kDayFormat);
      final swipeLeft = AppSettingsCodecs.decodeSwipeAction(await storage.getString(_kPlannerSwipeLeft)) ?? PlannerSwipeAction.off;
      final swipeRight = AppSettingsCodecs.decodeSwipeAction(await storage.getString(_kPlannerSwipeRight)) ?? PlannerSwipeAction.off;
      final plannerTapAction = AppSettingsCodecs.decodePlannerTapAction(await storage.getString(_kPlannerTapAction)) ?? PlannerTapAction.archive;
      final paymentSwipeLeft = AppSettingsCodecs.decodePaymentSwipeAction(await storage.getString(_kPaymentSwipeLeft)) ?? PaymentSwipeAction.off;
      final paymentSwipeRight = AppSettingsCodecs.decodePaymentSwipeAction(await storage.getString(_kPaymentSwipeRight)) ?? PaymentSwipeAction.off;
      final paymentDisplayMode = AppSettingsCodecs.decodePaymentDisplayMode(await storage.getString(_kPaymentDisplayMode)) ?? PaymentDisplayMode.automatic;
      final enableTabSwipe = await storage.getBool(_kEnableTabSwipe) ?? false;
      final useZeroBaseline = await storage.getBool(_kPlannerUseZeroBaseline) ?? false;
      final showClearedItems = await storage.getBool(_kPlannerShowClearedItems) ?? true;
      
      final regionPresetId = await storage.getString(_kRegionPreset) ?? AppSettingsPresets.autoPresetId;
      final preset = AppSettingsPresets.regionPresetForId(regionPresetId);
      final locale = AppSettingsPresets.localeFromPlatform();
      final fallbackCurrency = preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
      final fallbackDayFormat = preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);
      
      final resolvedCurrency = decodeCurrency(currencyStored) ?? fallbackCurrency;
      final resolvedDayFormat = AppSettingsCodecs.decodeDayFormat(dayFormatStored) ?? fallbackDayFormat;
      
      final sortOrder = AppSettingsCodecs.decodeSortOrder(await storage.getString(_kPlannerSortOrder)) ?? PlannerSortOrder.chronological;
      final dateSortMode = AppSettingsCodecs.decodePlannerDateSortMode(await storage.getString(_kPlannerDateSortMode)) ?? PlannerDateSortMode.scheduledDate;
      // Note: Paycheck settings are now part of Account model only. Removed global loading logic.
      
      final colorPreset = AppSettingsCodecs.decodeColorPreset(await storage.getString(_kColorPreset)) ?? ColorPreset.classic;
      final appThemePreset = AppSettingsCodecs.decodeAppThemePreset(await storage.getString(_kAppThemePreset)) ?? AppThemePreset.monochrome;
      
      final defaultColors = ThemeSettings.presetColors[colorPreset]!;
       final debitColorValue = await storage.getInt(_kDebitColor) ?? defaultColors.$1;
       final creditColorValue = await storage.getInt(_kCreditColor) ?? defaultColors.$2;
       final neutralColorValue = await storage.getInt(_kNeutralColor) ?? defaultColors.$3;
      
      final plannerGroupByDate = await storage.getBool(_kPlannerGroupByDate) ?? false;
      final plannerGroupByTheme = await storage.getBool(_kPlannerGroupByTheme) ?? false;
      final plannerShowPaymentOrigin = await storage.getBool(_kPlannerShowPaymentOrigin) ?? false;
      
      final monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(await storage.getString(_kMonthCardDisplayMode)) ?? MonthCardDisplayMode.full;
      final monthTotalsDisplayMode = AppSettingsCodecs.decodeMonthTotalsDisplayMode(await storage.getString(_kMonthTotalsDisplayMode)) ?? MonthTotalsDisplayMode.includeCleared;
      final multiMonthDisplayMode = AppSettingsCodecs.decodeMultiMonthDisplayMode(await storage.getString(_kMultiMonthDisplayMode)) ?? MultiMonthDisplayMode.automatic;
      
      final terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(await storage.getString(_kTerminologyPreset)) ?? TerminologyPreset.defaultTerms;
      final textScalePreset = AppSettingsCodecs.decodeTextScalePreset(await storage.getString(_kTextScalePreset)) ?? TextScalePreset.normal;
      final fontPreset = AppSettingsCodecs.decodeFontPreset(await storage.getString(_kFontPreset)) ?? FontPreset.system;
      final plannerViewMode = AppSettingsCodecs.decodePlannerViewMode(await storage.getString(_kPlannerViewMode)) ?? PlannerViewMode.month;
      
      final showCents = await storage.getBool(_kShowCents) ?? true;
      final roundingIncrement = await storage.getInt(_kRoundingIncrement) ?? 0;
      
      final paymentsFilterType = AppSettingsCodecs.decodePaymentsFilterType(await storage.getString(_kPaymentsFilterType)) ?? PaymentsFilterType.all;
      final paymentsGroupBy = AppSettingsCodecs.decodePaymentsGroupBy(await storage.getString(_kPaymentsGroupBy)) ?? PaymentsGroupBy.none;
      final paymentsShowArchived = await storage.getBool(_kPaymentsShowArchived) ?? false;
      final categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(await storage.getString(_kCategoryPresetMode)) ?? CategoryPresetMode.defaultPresets;
 
      final enabledCurrenciesRaw = await storage.getString(_kEnabledCurrencies);
      final exchangeRatesRaw = await storage.getString(_kExchangeRates);
      final autoUpdateRates = await storage.getBool(_kAutoUpdateRates) ?? true;

      Set<AppCurrency>? enabledCurrencies;
      if (enabledCurrenciesRaw != null) {
        enabledCurrencies = enabledCurrenciesRaw
            .split(',')
            .map(decodeCurrency)
            .whereType<AppCurrency>()
            .toSet();
      }

      Map<AppCurrency, double>? exchangeRates;
      if (exchangeRatesRaw != null) {
        try {
          final Map<String, dynamic> decoded = json.decode(exchangeRatesRaw);
          exchangeRates = {};
          decoded.forEach((key, value) {
            final currency = decodeCurrency(key);
            if (currency != null) {
              exchangeRates![currency] = (value as num).toDouble();
            }
          });
        } catch (_) {}
      }

      final moneyPotsJson = await storage.getString(_kMoneyPots);
      List<MoneyPot> moneyPots = [];
      if (moneyPotsJson != null) {
        try {
          final List<dynamic> list = jsonDecode(moneyPotsJson);
          moneyPots = list.map((e) => MoneyPot.fromJson(e)).toList();
        } catch (e) {
           debugLog(LogCategory.persistence, 'Failed to decode money pots', error: e);
        }
      }
      
      final moneyPotsSectionLabel = await storage.getString(_kMoneyPotsSectionLabel);
      
      final moneyPotsScopeStr = await storage.getString(_kMoneyPotsScope);
      final moneyPotsScope = MoneyPotsScope.values.firstWhere(
        (e) => e.name == moneyPotsScopeStr,
        orElse: () => MoneyPotsScope.global,
      );

      return AppSettingsStore._(
        storage,
        ThemeSettings(
            storage,
            initialThemeMode: themeMode,
            initialColorPreset: colorPreset,
            initialAppThemePreset: appThemePreset,
             initialDebitColor: debitColorValue,
             initialCreditColor: creditColorValue,
             initialNeutralColor: neutralColorValue,
             initialTextScalePreset: textScalePreset,
            initialFontPreset: fontPreset,
        ),
        CurrencySettings(
            storage,
            initialCurrency: resolvedCurrency,
            initialBalanceCents: balance,
            initialShowCents: showCents,
            initialRoundingIncrement: roundingIncrement,
            initialEnabledCurrencies: enabledCurrencies,
            initialExchangeRates: exchangeRates,
            initialAutoUpdateRates: autoUpdateRates,
        ),
        PlannerSettings(
            storage,
            initialDayFormat: resolvedDayFormat,
            initialSwipeLeft: swipeLeft,
            initialSwipeRight: swipeRight,
            initialTapAction: plannerTapAction,
            initialPaymentSwipeLeft: paymentSwipeLeft,
            initialPaymentSwipeRight: paymentSwipeRight,
            initialPaymentDisplayMode: paymentDisplayMode,
            initialEnableTabSwipe: enableTabSwipe,
            initialUseZeroBaseline: useZeroBaseline,
            initialShowClearedItems: showClearedItems,
            initialSortOrder: sortOrder,
            initialDateSortMode: dateSortMode,
            initialGroupByDate: plannerGroupByDate,
            initialGroupByTheme: plannerGroupByTheme,
            initialShowPaymentOrigin: plannerShowPaymentOrigin,
            initialMonthCardDisplayMode: monthCardDisplayMode,
            initialMonthTotalsDisplayMode: monthTotalsDisplayMode,
            initialMultiMonthDisplayMode: multiMonthDisplayMode,
            initialTerminologyPreset: terminologyPreset,
            initialViewMode: plannerViewMode,
            initialPaymentsFilterType: paymentsFilterType,
            initialPaymentsGroupBy: paymentsGroupBy,
            initialPaymentsShowArchived: paymentsShowArchived,
            initialCategoryPresetMode: categoryPresetMode,
        ),
        MoneyPotsSettings(
          storage, 
          initialMoneyPots: moneyPots,
          initialSectionLabel: moneyPotsSectionLabel,
          initialScope: moneyPotsScope,
        ),
        regionPresetId,
      );
    } catch (error, stackTrace) {
        debugLog(LogCategory.persistence, 'Failed to load settings', error: error, stackTrace: stackTrace);
        rethrow;
    }
  }

  @override
  void dispose() {
    themeSettings.removeListener(notifyListeners);
    currencySettings.removeListener(notifyListeners);
    plannerSettings.removeListener(notifyListeners);
    themeSettings.dispose();
    currencySettings.dispose();
    plannerSettings.dispose();
    moneyPotsSettings.dispose();
    super.dispose();
  }
}

class AppSettingsScope extends InheritedNotifier<AppSettingsStore> {
  const AppSettingsScope({
    super.key,
    required AppSettingsStore store,
    required super.child,
  }) : super(notifier: store);

  static AppSettingsStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppSettingsScope>();
    if (scope == null) {
      throw StateError('AppSettingsStore not found in widget tree.');
    }
    return scope.notifier!;
  }

  static AppSettingsStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppSettingsScope>();
    if (scope == null) {
      throw StateError('AppSettingsStore not found in widget tree.');
    }
    return scope.notifier!;
  }
}
