import 'package:shared_preferences/shared_preferences.dart';

import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

/// Storage provider implementation using SharedPreferences.
///
/// Stores data in plaintext on the device. This is the default implementation
/// used when encryption is disabled (kEnableEncryption = false).
///
/// **Platform Storage Locations**:
/// - Android: XML files in app's private directory
/// - iOS: NSUserDefaults (plist)
/// - No encryption is applied to the data.
class SharedPrefsStorageProvider implements StorageProvider {
  SharedPrefsStorageProvider._(this._prefs);

  final SharedPreferences _prefs;

  static Future<SharedPrefsStorageProvider> create() async {
    final prefs = await SharedPreferences.getInstance();
    return SharedPrefsStorageProvider._(prefs);
  }

  @override
  Future<String?> getString(String key) async {
    try {
      return _prefs.getString(key);
    } on TypeError {
      // If the stored value is not a string, treat as missing instead of crashing.
      return null;
    }
  }

  @override
  Future<bool> setString(String key, String value) async {
    return _prefs.setString(key, value);
  }

  @override
  Future<int?> getInt(String key) async {
    try {
      return _prefs.getInt(key);
    } on TypeError {
      return null;
    }
  }

  @override
  Future<bool> setInt(String key, int value) async {
    return _prefs.setInt(key, value);
  }

  @override
  Future<bool?> getBool(String key) async {
    try {
      return _prefs.getBool(key);
    } on TypeError {
      return null;
    }
  }

  @override
  Future<bool> setBool(String key, bool value) async {
    return _prefs.setBool(key, value);
  }

  @override
  Future<bool> remove(String key) async {
    return _prefs.remove(key);
  }
}
