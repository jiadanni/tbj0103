import 'package:expense_stalker_mobile/src/state/encrypted_storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/shared_prefs_storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/storage_config.dart';


/// Abstract interface for persistent key-value storage.
///
/// Provides a unified API for both encrypted and plaintext storage backends.
/// Implementations must support all standard data types used by the app.
abstract class StorageProvider {
  static Future<StorageProvider> Function()? _overrideFactory;

  /// Overrides the storage provider factory for tests.
  static void setFactoryForTesting(
    Future<StorageProvider> Function()? factory,
  ) {
    _overrideFactory = factory;
  }

  /// Retrieves a string value for the given key.
  ///
  /// Returns null if the key doesn't exist.
  Future<String?> getString(String key);

  /// Stores a string value for the given key.
  ///
  /// Returns true if successful, false otherwise.
  Future<bool> setString(String key, String value);

  /// Retrieves an integer value for the given key.
  ///
  /// Returns null if the key doesn't exist.
  Future<int?> getInt(String key);

  /// Stores an integer value for the given key.
  ///
  /// Returns true if successful, false otherwise.
  Future<bool> setInt(String key, int value);

  /// Retrieves a boolean value for the given key.
  ///
  /// Returns null if the key doesn't exist.
  Future<bool?> getBool(String key);

  /// Stores a boolean value for the given key.
  ///
  /// Returns true if successful, false otherwise.
  Future<bool> setBool(String key, bool value);

  /// Removes a value for the given key.
  ///
  /// Returns true if successful, false otherwise.
  Future<bool> remove(String key);

  /// Factory method to create the appropriate storage provider.
  ///
  /// Returns [EncryptedStorageProvider] if [kEnableEncryption] is true,
  /// otherwise returns [SharedPrefsStorageProvider].
  static Future<StorageProvider> create() async {
    final override = _overrideFactory;
    if (override != null) return override();

    if (kEnableEncryption) {
      return EncryptedStorageProvider.create();
    }
    
    return SharedPrefsStorageProvider.create();
  }
}
