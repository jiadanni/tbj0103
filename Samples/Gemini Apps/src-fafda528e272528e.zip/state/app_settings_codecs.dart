import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

/// Encoding and decoding utilities for AppSettings.
///
/// This class provides static methods to convert between domain enums and
/// their string representations for storage and retrieval.
class AppSettingsCodecs {
  AppSettingsCodecs._(); // Prevent instantiation

  // ============================================================================
  // Theme Mode Encoding/Decoding
  // ============================================================================

  static String encodeThemeMode(ThemeMode mode) {
    return switch (mode) {
      ThemeMode.system => 'system',
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
    };
  }

  static ThemeMode? decodeThemeMode(String? raw) {
    return switch (raw) {
      'system' => ThemeMode.system,
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => null,
    };
  }

  // ============================================================================
  // Day Format Encoding/Decoding
  // ============================================================================

  static String encodeDayFormat(DayFormat format) {
    return switch (format) {
      DayFormat.number => 'number',
      DayFormat.ordinal => 'ordinal',
    };
  }

  static DayFormat? decodeDayFormat(String? raw) {
    return switch (raw) {
      'number' => DayFormat.number,
      'ordinal' => DayFormat.ordinal,
      _ => null,
    };
  }

  // ============================================================================
  // Planner Swipe Action Encoding/Decoding
  // ============================================================================

  static String encodeSwipeAction(PlannerSwipeAction action) {
    return switch (action) {
      PlannerSwipeAction.off => 'off',
      PlannerSwipeAction.edit => 'edit',
      PlannerSwipeAction.archive => 'archive',
    };
  }

  static PlannerSwipeAction? decodeSwipeAction(String? raw) {
    return switch (raw) {
      'off' => PlannerSwipeAction.off,
      'edit' => PlannerSwipeAction.edit,
      'archive' => PlannerSwipeAction.archive,
      _ => null,
    };
  }

  // ============================================================================
  // Planner Tap Action Encoding/Decoding
  // ============================================================================

  static String encodePlannerTapAction(PlannerTapAction action) {
    return switch (action) {
      PlannerTapAction.archive => 'archive',
      PlannerTapAction.menu => 'menu',
    };
  }

  static PlannerTapAction? decodePlannerTapAction(String? raw) {
    return switch (raw) {
      'archive' => PlannerTapAction.archive,
      'menu' => PlannerTapAction.menu,
      _ => null,
    };
  }

  // ============================================================================
  // Payment Swipe Action Encoding/Decoding
  // ============================================================================

  static String encodePaymentSwipeAction(PaymentSwipeAction action) {
    return switch (action) {
      PaymentSwipeAction.off => 'off',
      PaymentSwipeAction.edit => 'edit',
      PaymentSwipeAction.delete => 'delete',
    };
  }

  static PaymentSwipeAction? decodePaymentSwipeAction(String? raw) {
    return switch (raw) {
      'off' => PaymentSwipeAction.off,
      'edit' => PaymentSwipeAction.edit,
      'delete' => PaymentSwipeAction.delete,
      _ => null,
    };
  }

  // ============================================================================
  // Payment Display Mode Encoding/Decoding
  // ============================================================================

  static String encodePaymentDisplayMode(PaymentDisplayMode mode) {
    return switch (mode) {
      PaymentDisplayMode.automatic => 'auto',
      PaymentDisplayMode.full => 'full',
      PaymentDisplayMode.acronym => 'acronym',
      PaymentDisplayMode.icon => 'icon',
    };
  }

  static PaymentDisplayMode? decodePaymentDisplayMode(String? raw) {
    return switch (raw) {
      'auto' => PaymentDisplayMode.automatic,
      'full' => PaymentDisplayMode.full,
      'acronym' => PaymentDisplayMode.acronym,
      'icon' => PaymentDisplayMode.icon,
      _ => null,
    };
  }

  // ============================================================================
  // Planner Sort Order Encoding/Decoding
  // ============================================================================

  static String encodeSortOrder(PlannerSortOrder order) {
    return switch (order) {
      PlannerSortOrder.chronological => 'chronological',
      PlannerSortOrder.reverseChronological => 'reverse',
    };
  }

  static PlannerSortOrder? decodeSortOrder(String? raw) {
    return switch (raw) {
      'chronological' => PlannerSortOrder.chronological,
      'reverse' => PlannerSortOrder.reverseChronological,
      _ => null,
    };
  }

  // ============================================================================
  // Planner Date Sort Mode Encoding/Decoding
  // ============================================================================

  static String encodePlannerDateSortMode(PlannerDateSortMode mode) {
    return switch (mode) {
      PlannerDateSortMode.scheduledDate => 'scheduled',
      PlannerDateSortMode.actualDate => 'actual',
    };
  }

  static PlannerDateSortMode? decodePlannerDateSortMode(String? raw) {
    return switch (raw) {
      'scheduled' => PlannerDateSortMode.scheduledDate,
      'actual' => PlannerDateSortMode.actualDate,
      _ => null,
    };
  }

  // ============================================================================
  // View Period Mode Encoding/Decoding
  // ============================================================================

  static String encodeViewPeriodMode(ViewPeriodMode mode) {
    return switch (mode) {
      ViewPeriodMode.calendar => 'calendar',
      ViewPeriodMode.paycheck => 'paycheck',
    };
  }

  static ViewPeriodMode? decodeViewPeriodMode(String? raw) {
    return switch (raw) {
      'calendar' => ViewPeriodMode.calendar,
      'paycheck' => ViewPeriodMode.paycheck,
      _ => null,
    };
  }

  // ============================================================================
  // Paycheck Adjust Direction Encoding/Decoding
  // ============================================================================

  static String encodeAdjustDirection(PaycheckAdjustDirection d) {
    return switch (d) {
      PaycheckAdjustDirection.before => 'before',
      PaycheckAdjustDirection.after => 'after',
    };
  }

  static PaycheckAdjustDirection? decodeAdjustDirection(String? raw) {
    return switch (raw) {
      'before' => PaycheckAdjustDirection.before,
      'after' => PaycheckAdjustDirection.after,
      _ => null,
    };
  }

  // ============================================================================
  // Color Preset Encoding/Decoding
  // ============================================================================

  static String encodeColorPreset(ColorPreset preset) {
    return switch (preset) {
      ColorPreset.classic => 'classic',
      ColorPreset.ocean => 'ocean',
      ColorPreset.sunset => 'sunset',
      ColorPreset.monochrome => 'monochrome',
      ColorPreset.forest => 'forest',
      ColorPreset.berry => 'berry',
      ColorPreset.lavender => 'lavender',
      ColorPreset.earth => 'earth',
      ColorPreset.mint => 'mint',
      ColorPreset.warm => 'warm',
      ColorPreset.custom => 'custom',
    };
  }

  static ColorPreset? decodeColorPreset(String? raw) {
    return switch (raw) {
      'classic' => ColorPreset.classic,
      'ocean' => ColorPreset.ocean,
      'sunset' => ColorPreset.sunset,
      'monochrome' => ColorPreset.monochrome,
      'forest' => ColorPreset.forest,
      'berry' => ColorPreset.berry,
      'lavender' => ColorPreset.lavender,
      'earth' => ColorPreset.earth,
      'mint' => ColorPreset.mint,
      'warm' => ColorPreset.warm,
      'custom' => ColorPreset.custom,
      _ => null,
    };
  }

  // ============================================================================
  // App Theme Preset Encoding/Decoding
  // ============================================================================

  static String encodeAppThemePreset(AppThemePreset preset) {
    return switch (preset) {
      AppThemePreset.classic => 'classic',
      AppThemePreset.ocean => 'ocean',
      AppThemePreset.sunset => 'sunset',
      AppThemePreset.monochrome => 'monochrome',
      AppThemePreset.forest => 'forest',
      AppThemePreset.berry => 'berry',
      AppThemePreset.lavender => 'lavender',
      AppThemePreset.midnight => 'midnight',
      AppThemePreset.rose => 'rose',
      AppThemePreset.mint => 'mint',
    };
  }

  static AppThemePreset? decodeAppThemePreset(String? raw) {
    return switch (raw) {
      'classic' => AppThemePreset.classic,
      'ocean' => AppThemePreset.ocean,
      'sunset' => AppThemePreset.sunset,
      'monochrome' => AppThemePreset.monochrome,
      'forest' => AppThemePreset.forest,
      'berry' => AppThemePreset.berry,
      'lavender' => AppThemePreset.lavender,
      'midnight' => AppThemePreset.midnight,
      'rose' => AppThemePreset.rose,
      'mint' => AppThemePreset.mint,
      _ => null,
    };
  }

  // ============================================================================
  // Month Card Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMonthCardDisplayMode(MonthCardDisplayMode mode) {
    return switch (mode) {
      MonthCardDisplayMode.full => 'full',
      MonthCardDisplayMode.acronym => 'acronym',
    };
  }

  static MonthCardDisplayMode? decodeMonthCardDisplayMode(String? raw) {
    return switch (raw) {
      'full' => MonthCardDisplayMode.full,
      'acronym' => MonthCardDisplayMode.acronym,
      _ => null,
    };
  }

  // ============================================================================
  // Month Totals Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMonthTotalsDisplayMode(MonthTotalsDisplayMode mode) {
    return switch (mode) {
      MonthTotalsDisplayMode.includeCleared => 'includeCleared',
      MonthTotalsDisplayMode.showClearedRow => 'showClearedRow',
    };
  }

  static MonthTotalsDisplayMode? decodeMonthTotalsDisplayMode(String? raw) {
    return switch (raw) {
      'includeCleared' => MonthTotalsDisplayMode.includeCleared,
      'showClearedRow' => MonthTotalsDisplayMode.showClearedRow,
      _ => null,
    };
  }

  // ============================================================================
  // Multi-Month Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMultiMonthDisplayMode(MultiMonthDisplayMode mode) {
    return switch (mode) {
      MultiMonthDisplayMode.automatic => 'auto',
      MultiMonthDisplayMode.full => 'full',
      MultiMonthDisplayMode.acronym => 'acronym',
      MultiMonthDisplayMode.icon => 'icon',
    };
  }

  static MultiMonthDisplayMode? decodeMultiMonthDisplayMode(String? raw) {
    return switch (raw) {
      'auto' => MultiMonthDisplayMode.automatic,
      'full' => MultiMonthDisplayMode.full,
      'acronym' => MultiMonthDisplayMode.acronym,
      'icon' => MultiMonthDisplayMode.icon,
      _ => null,
    };
  }

  // ============================================================================
  // Terminology Preset Encoding/Decoding
  // ============================================================================

  static String encodeTerminologyPreset(TerminologyPreset preset) {
    return switch (preset) {
      TerminologyPreset.defaultTerms => 'default',
      TerminologyPreset.bills => 'bills',
      TerminologyPreset.budget => 'budget',
    };
  }

  static TerminologyPreset? decodeTerminologyPreset(String? raw) {
    return switch (raw) {
      'default' => TerminologyPreset.defaultTerms,
      'bills' => TerminologyPreset.bills,
      'budget' => TerminologyPreset.budget,
      _ => null,
    };
  }

  // ============================================================================
  // Text Scale Preset Encoding/Decoding
  // ============================================================================

  static String encodeTextScalePreset(TextScalePreset preset) {
    return switch (preset) {
      TextScalePreset.small => 'small',
      TextScalePreset.normal => 'normal',
      TextScalePreset.large => 'large',
      TextScalePreset.extraLarge => 'extraLarge',
    };
  }

  static TextScalePreset? decodeTextScalePreset(String? raw) {
    return switch (raw) {
      'small' => TextScalePreset.small,
      'normal' => TextScalePreset.normal,
      'large' => TextScalePreset.large,
      'extraLarge' => TextScalePreset.extraLarge,
      _ => null,
    };
  }

  // ============================================================================
  // Font Preset Encoding/Decoding
  // ============================================================================

  static String encodeFontPreset(FontPreset preset) {
    return switch (preset) {
      FontPreset.system => 'system',
      FontPreset.monospace => 'monospace',
    };
  }

  static FontPreset? decodeFontPreset(String? raw) {
    return switch (raw) {
      'system' => FontPreset.system,
      'monospace' => FontPreset.monospace,
      _ => null,
    };
  }

  // ============================================================================
  // Planner View Mode Encoding/Decoding
  // ============================================================================

  static String encodePlannerViewMode(PlannerViewMode mode) {
    return switch (mode) {
      PlannerViewMode.month => 'month',
      PlannerViewMode.grid => 'grid',
      PlannerViewMode.sheet => 'sheet',
    };
  }

  static PlannerViewMode? decodePlannerViewMode(String? raw) {
    return switch (raw) {
      'month' => PlannerViewMode.month,
      'grid' => PlannerViewMode.grid,
      'sheet' => PlannerViewMode.sheet,
      _ => null,
    };
  }

  // ============================================================================
  // Payments Filter Type Encoding/Decoding
  // ============================================================================

  static String encodePaymentsFilterType(PaymentsFilterType type) {
    return switch (type) {
      PaymentsFilterType.all => 'all',
      PaymentsFilterType.income => 'income',
      PaymentsFilterType.expenses => 'expenses',
      PaymentsFilterType.debt => 'debt',
      PaymentsFilterType.oneOff => 'oneOff',
      PaymentsFilterType.recurring => 'recurring',
      PaymentsFilterType.category => 'category',
    };
  }

  static PaymentsFilterType? decodePaymentsFilterType(String? raw) {
    return switch (raw) {
      'all' => PaymentsFilterType.all,
      'income' => PaymentsFilterType.income,
      'expenses' => PaymentsFilterType.expenses,
      'debt' => PaymentsFilterType.debt,
      'oneOff' => PaymentsFilterType.oneOff,
      'recurring' => PaymentsFilterType.recurring,
      'category' => PaymentsFilterType.category,
      _ => null,
    };
  }

  // ============================================================================
  // Payments Group By Encoding/Decoding
  // ============================================================================

  static String encodePaymentsGroupBy(PaymentsGroupBy groupBy) {
    return switch (groupBy) {
      PaymentsGroupBy.none => 'none',
      PaymentsGroupBy.category => 'category',
      PaymentsGroupBy.type => 'type',
      PaymentsGroupBy.company => 'company',
      PaymentsGroupBy.dueDate => 'dueDate',
    };
  }

  static PaymentsGroupBy? decodePaymentsGroupBy(String? raw) {
    return switch (raw) {
      'none' => PaymentsGroupBy.none,
      'category' => PaymentsGroupBy.category,
      'type' => PaymentsGroupBy.type,
      'company' => PaymentsGroupBy.company,
      'dueDate' => PaymentsGroupBy.dueDate,
      _ => null,
    };
  }

  // ============================================================================
  // Category Preset Mode Encoding/Decoding
  // ============================================================================

  static String encodeCategoryPresetMode(CategoryPresetMode mode) {
    return switch (mode) {
      CategoryPresetMode.defaultPresets => 'default',
      CategoryPresetMode.customOnly => 'custom',
      CategoryPresetMode.both => 'both',
    };
  }

  static CategoryPresetMode? decodeCategoryPresetMode(String? raw) {
    return switch (raw) {
      'default' => CategoryPresetMode.defaultPresets,
      'custom' => CategoryPresetMode.customOnly,
      'both' => CategoryPresetMode.both,
      _ => null,
    };
  }
}
