import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/state/map_decoder.dart';

class ExpensePersistence {
  ExpensePersistence._(this._storage);

  static const _kAccounts = 'expense.accounts';
  static const _kCurrentAccountId = 'expense.currentAccountId';
  
  // Account-specific key generators
  String _monthKey(AccountId accountId) => 'account.$accountId.selectedMonth';
  String _plannerKey(AccountId accountId) => 'account.$accountId.plannerItems';
  String _paymentsKey(AccountId accountId) => 'account.$accountId.payments';

  final StorageProvider _storage;

  static Future<ExpensePersistence> create() async {
    final storage = await StorageProvider.create();
    return ExpensePersistence._(storage);
  }

  /// Loads accounts metadata.
  Future<List<Account>> loadAccounts() async {
    final accountsJson = await _storage.getString(_kAccounts);
    if (accountsJson == null) {
      return [];
    }
    
    final List<dynamic> decoded = jsonDecode(accountsJson);
    return decoded.map((item) => Account.fromJson(item as Map<String, dynamic>)).toList();
  }

  Future<void> saveAccounts(List<Account> accounts) async {
    final json = jsonEncode(accounts.map((a) => a.toJson()).toList());
    await _storage.setString(_kAccounts, json);
  }

  Future<AccountId?> getCurrentAccountId() async {
    final id = await _storage.getString(_kCurrentAccountId);
    return id != null ? AccountId(id) : null;
  }

  Future<void> setCurrentAccountId(AccountId id) async {
    await _storage.setString(_kCurrentAccountId, id);
  }

  Future<ExpenseSnapshot?> load(AccountId accountId) async {
    try {
      final selectedMonthMillis = await _storage.getInt(_monthKey(accountId));
      final plannerJson = await _storage.getString(_plannerKey(accountId));
      final paymentsJson = await _storage.getString(_paymentsKey(accountId));

      if (selectedMonthMillis == null &&
          plannerJson == null &&
          paymentsJson == null) {
        return null;
      }

      final selectedMonth = selectedMonthMillis == null
          ? monthOnly(DateTime.now())
          : monthOnly(DateTime.fromMillisecondsSinceEpoch(selectedMonthMillis, isUtc: true));

      final snapshot = await compute((params) {
        List<PlannerItem> plannerItems = const [];
        if (params.plannerJson != null) {
          final decoded = jsonDecode(params.plannerJson!);
          if (decoded is List) {
            plannerItems = decoded
                .whereType<Map>()
                .map((m) => PlannerItemCodec.fromJson(m.cast<String, Object?>()))
                .toList(growable: false);
          }
        }

        List<PaymentEntry> payments = const [];
        if (params.paymentsJson != null) {
          final decoded = jsonDecode(params.paymentsJson!);
          if (decoded is List) {
            payments = decoded
                .whereType<Map>()
                .map((m) => PaymentEntryCodec.fromJson(m.cast<String, Object?>()))
                .toList(growable: false);
          }
        }

        return (plannerItems: plannerItems, payments: payments);
      }, (plannerJson: plannerJson, paymentsJson: paymentsJson));

      return ExpenseSnapshot(
        selectedMonth: selectedMonth,
        plannerItems: snapshot.plannerItems,
        payments: snapshot.payments,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Critical error decoding persisted data for account $accountId',
        error: error,
        stackTrace: stackTrace,
      );
      // Rethrow so ExpenseStore doesn't assume the account is empty and overwrite it
      rethrow;
    }
  }

  Future<void> save(AccountId accountId, ExpenseSnapshot snapshot) async {
    final monthResult = await _storage.setInt(
      _monthKey(accountId),
      monthOnly(snapshot.selectedMonth).millisecondsSinceEpoch,
    );
    if (!monthResult) {
      throw StorageException('Failed to persist selected month for account $accountId');
    }

    final (plannerJson, paymentsJson) = await compute((s) {
      final pj = jsonEncode(s.plannerItems.map(PlannerItemCodec.toJson).toList());
      final payj = jsonEncode(s.payments.map(PaymentEntryCodec.toJson).toList());
      return (pj, payj);
    }, snapshot);

    final plannerResult = await _storage.setString(_plannerKey(accountId), plannerJson);
    if (!plannerResult) {
      throw StorageException('Failed to persist planner items for account $accountId');
    }

    final paymentsResult = await _storage.setString(_paymentsKey(accountId), paymentsJson);
    if (!paymentsResult) {
      throw StorageException('Failed to persist payments for account $accountId');
    }
  }

  Future<void> deleteAccountData(AccountId accountId) async {
    await _storage.remove(_monthKey(accountId));
    await _storage.remove(_plannerKey(accountId));
    await _storage.remove(_paymentsKey(accountId));
  }

  // --- Export/Import JSON helpers (shared between persistence and export service)
  
  Map<String, dynamic> snapshotToExportJson(ExpenseSnapshot snapshot, {Map<String, String>? encryption}) {
    final base = {
      'version': 3,
      'exportDate': DateTime.now().toUtc().toIso8601String(),
    };

    if (encryption != null) {
      return {
        ...base,
        'encryption': encryption,
      };
    }

    return {
      ...base,
      'selectedMonth': snapshot.selectedMonth.toUtc().toIso8601String(),
      'plannerItems': snapshot.plannerItems.map(PlannerItemCodec.toJson).toList(),
      'payments': snapshot.payments.map(PaymentEntryCodec.toJson).toList(),
      if (snapshot.accountSettings != null)
        'account': snapshot.accountSettings!.toJson(),
    };
  }

  Map<String, dynamic> accountsToExportJson(List<Account> accounts, Map<String, ExpenseSnapshot> data, {Map<String, String>? encryption}) {
    final base = {
      'version': 2,
      'exportDate': DateTime.now().toUtc().toIso8601String(),
    };

    if (encryption != null) {
      return {
        ...base,
        'encryption': encryption,
      };
    }

    return {
      ...base,
      'accounts': accounts.map((a) {
        final snapshot = data[a.id];
        return {
          'metadata': a.toJson(),
          'data': snapshot != null ? {
            'selectedMonth': snapshot.selectedMonth.toUtc().toIso8601String(),
            'plannerItems': snapshot.plannerItems.map(PlannerItemCodec.toJson).toList(),
            'payments': snapshot.payments.map(PaymentEntryCodec.toJson).toList(),
          } : null,
        };
      }).toList(),
    };
  }

  /// Static convenience wrapper for exporting snapshot to JSON map.
  static Map<String, dynamic> toExportJson(ExpenseSnapshot snapshot, {Map<String, String>? encryption}) {
    return ExpensePersistence._dummy().snapshotToExportJson(snapshot, encryption: encryption);
  }

  static Map<String, dynamic> multiAccountToExportJson(List<Account> accounts, Map<String, ExpenseSnapshot> data, {Map<String, String>? encryption}) {
    return ExpensePersistence._dummy().accountsToExportJson(accounts, data, encryption: encryption);
  }

  /// Checks if the given export JSON is encrypted.
  static bool isEncrypted(Map<String, dynamic> json) {
    return json.containsKey('encryption');
  }

  /// Static convenience wrapper for creating snapshot from export JSON map.
  static ExpenseSnapshot fromExportJson(Map<String, dynamic> json) {
    return ExpensePersistence._dummy().snapshotFromExportJson(json);
  }

  static (List<Account>, Map<String, ExpenseSnapshot>) multiAccountFromExportJson(Map<String, dynamic> json) {
    final version = json['version'] as int? ?? 1;
    if (version == 1 || version == 3) {
      // Convert legacy v1/v3 to v2 format with a single account
      final snapshot = fromExportJson(json);
      final account = Account.create(name: 'Imported Account');
      return ([account], {account.id: snapshot});
    }

    if (version != 2) {
      throw FormatException('Unsupported export version: $version');
    }

    final accountsResult = <Account>[];
    final dataResult = <String, ExpenseSnapshot>{};

    final accountsRaw = json['accounts'] as List<dynamic>? ?? [];
    for (final item in accountsRaw) {
      if (item is Map<String, dynamic>) {
        final metadata = Account.fromJson(item['metadata'] as Map<String, dynamic>);
        accountsResult.add(metadata);
        
        final dataRaw = item['data'] as Map<String, dynamic>?;
        if (dataRaw != null) {
          final selectedMonthStr = dataRaw['selectedMonth'] as String?;
          final selectedMonth = selectedMonthStr != null
              ? DateTime.parse(selectedMonthStr).toLocal()
              : DateTime.now();

          final plannerItems = (dataRaw['plannerItems'] as List<dynamic>? ?? [])
              .whereType<Map<String, dynamic>>()
              .map((m) => PlannerItemCodec.fromJson(m.cast<String, Object?>()))
              .toList();

          final payments = (dataRaw['payments'] as List<dynamic>? ?? [])
              .whereType<Map<String, dynamic>>()
              .map((m) => PaymentEntryCodec.fromJson(m.cast<String, Object?>()))
              .toList();

          dataResult[metadata.id] = ExpenseSnapshot(
            selectedMonth: selectedMonth,
            plannerItems: plannerItems,
            payments: payments,
          );
        }
      }
    }

    return (accountsResult, dataResult);
  }

  // Private dummy constructor helper for static wrappers.
  static ExpensePersistence _dummy() => ExpensePersistence._(_DummyStorage());

  ExpenseSnapshot snapshotFromExportJson(Map<String, dynamic> json) {
    final version = json['version'] as int? ?? 1;
    if (version > 3) {
      throw FormatException('Unsupported export version: $version');
    }

    if (version == 2) {
      // For v2 files, if we ask for a single snapshot, we just take the first account's data
      final (_, data) = multiAccountFromExportJson(json);
      if (data.isEmpty) return ExpenseSnapshot(selectedMonth: DateTime.now(), plannerItems: [], payments: []);
      return data.values.first;
    }

    final selectedMonthStr = json['selectedMonth'] as String?;
    final selectedMonth = selectedMonthStr != null
        ? DateTime.parse(selectedMonthStr).toLocal()
        : DateTime.now();

    final plannerItemsRaw = json['plannerItems'] as List<dynamic>? ?? [];
    final paymentsRaw = json['payments'] as List<dynamic>? ?? [];

    final plannerItems = plannerItemsRaw
        .whereType<Map<String, dynamic>>()
        .map((m) => PlannerItemCodec.fromJson(m.cast<String, Object?>()))
        .toList(growable: false);

    final payments = paymentsRaw
        .whereType<Map<String, dynamic>>()
        .map((m) => PaymentEntryCodec.fromJson(m.cast<String, Object?>()))
        .toList(growable: false);

    return ExpenseSnapshot(
      selectedMonth: selectedMonth,
      plannerItems: plannerItems,
      payments: payments,
      accountSettings: json.containsKey('account') 
          ? Account.fromJson(json['account'] as Map<String, dynamic>)
          : null,
    );
  }

  bool validateSnapshot(ExpenseSnapshot snapshot) {
    // Basic validation: ids present, amounts reasonable, no duplicate ids
    final ids = <String>{};
    final plannerItemIds = <PlannerItemId>{};
    
    // Validate planner items
    for (final item in snapshot.plannerItems) {
      if (item.id.isEmpty) return false;
      if (!ids.add(item.id)) return false; // Duplicate ID check
      plannerItemIds.add(item.id);
    }
    
    // Validate payments
    for (final p in snapshot.payments) {
      if (p.id.isEmpty) return false;
      if (!ids.add(p.id)) return false; // Duplicate ID check
      
      // Validate plannerItemId reference if present
      if (p.plannerItemId != null && 
          p.plannerItemId!.isNotEmpty && 
          !plannerItemIds.contains(p.plannerItemId)) {
        debugLog(
          LogCategory.persistence,
          'Payment ${p.id} references non-existent planner item ${p.plannerItemId}',
        );
        // Don't fail validation - just a broken reference, still importable
        // The payment will work fine, just won't be linked to a planner item
      }
    }
    
    return true;
  }
}

class _DummyStorage implements StorageProvider {
  @override
  Future<bool?> getBool(String key) async => null;

  @override
  Future<int?> getInt(String key) async => null;

  @override
  Future<String?> getString(String key) async => null;

  @override
  Future<bool> setBool(String key, bool value) async => false;

  @override
  Future<bool> setInt(String key, int value) async => false;

  @override
  Future<bool> setString(String key, String value) async => false;

  @override
  Future<bool> remove(String key) async => false;
}

class ExpenseSnapshot {
  const ExpenseSnapshot({
    required this.selectedMonth,
    required this.plannerItems,
    required this.payments,
    this.accountSettings,
  });

  final DateTime selectedMonth;
  final List<PlannerItem> plannerItems;
  final List<PaymentEntry> payments;
  final Account? accountSettings;
}

class PlannerItemCodec {
  static Map<String, Object?> toJson(PlannerItem item) => {
    'id': item.id,
    'label': item.label,
    'amountMinorUnits': item.amountMinorUnits,
    'dayOfMonth': item.dayOfMonth,
    'startDate': item.startDate.toUtc().toIso8601String(),
    'notes': item.notes,
    'type': item.type.name,
    'frequency': item.frequency?.name,
    'archived': item.archived,
    'paidOffDate': item.paidOffDate?.toUtc().toIso8601String(),
    'remainingBalanceMinorUnits': item.remainingBalanceMinorUnits,
    'originalAmountMinorUnits': item.originalAmountMinorUnits,
    'category': item.category,
    'company': item.company,
    'isSalary': item.isSalary,
    'useAsPaycheckBoundary': item.useAsPaycheckBoundary,
    'moneyPotId': item.moneyPotId,
    'isQuickAdd': item.isQuickAdd,
    'balanceCurrency': item.balanceCurrency?.name,
    'exchangeRate': item.exchangeRate,
    'useActualsForBalance': item.useActualsForBalance,
  };

  static PlannerItem fromJson(Map<String, Object?> json) {
    final d = MapDecoder(json);
    final typeStr = d.getString('type');
    final frequencyStr = d.getString('frequency');
    final amountMinorUnits = d.getInt('amountMinorUnits') ?? d.getInt('amountCents') ?? d.getInt('amount') ?? d.getInt('cents') ?? d.getInt('amount_minor_units') ?? 0;

    // Migrate old frequency-based system to new type + frequency system
    PaymentType type;
    RecurrenceFrequency? frequency;

    if (typeStr != null) {
      // New format with explicit type
      try {
        type = PaymentType.values.byName(typeStr);
      } catch (error) {
        debugLog(
          LogCategory.persistence,
          'Invalid PaymentType "$typeStr", defaulting to recurring',
          error: error,
        );
        type = PaymentType.recurring;
      }
      
      // Migration: Convert legacy recurring/oneOff with positive amounts to income types
      if (type == PaymentType.recurring && amountMinorUnits > 0) {
        type = PaymentType.recurringIncome;
      } else if (type == PaymentType.oneOff && amountMinorUnits > 0) {
        type = PaymentType.oneOffIncome;
      }

      if (frequencyStr != null) {
        try {
          frequency = RecurrenceFrequency.values.byName(frequencyStr);
        } catch (error) {
          debugLog(
            LogCategory.persistence,
            'Invalid RecurrenceFrequency "$frequencyStr", attempting legacy mapping',
            error: error,
          );
          frequency = _mapLegacyFrequency(frequencyStr);
        }
      }
    } else {
      // Legacy format - infer type from old frequency field or notes
      final notes = (d.getString('notes')?.toLowerCase()) ?? '';

      if (frequencyStr == 'oneTime' || notes.contains('fixed term') || notes.contains('fixed-term')) {
        type = PaymentType.oneOff;
        frequency = null;
      } else if (notes.contains('debt')) {
        type = PaymentType.debt;
        frequency = _mapLegacyFrequency(frequencyStr) ?? RecurrenceFrequency.monthly;
      } else {
        type = PaymentType.recurring;
        frequency = _mapLegacyFrequency(frequencyStr) ?? RecurrenceFrequency.monthly;
      }
    }
    
    final remainingBalanceMinorUnits = d.getInt('remainingBalanceMinorUnits') ?? d.getInt('remainingBalanceCents') ?? d.getInt('remainingBalance') ?? d.getInt('balance') ?? d.getInt('remaining_balance_minor_units');
    final originalAmountMinorUnits = d.getInt('originalAmountMinorUnits') ?? d.getInt('originalAmountCents') ?? d.getInt('originalAmount') ?? d.getInt('original_amount_minor_units');
    
    // Migration: For existing debts without originalAmountMinorUnits, use remainingBalanceMinorUnits
    final migratedOriginalAmount = originalAmountMinorUnits ?? 
        (type == PaymentType.debt && remainingBalanceMinorUnits != null 
            ? remainingBalanceMinorUnits 
            : null);
    
    final potIdStr = d.getString('moneyPotId');

    return PlannerItem(
      id: PlannerItemId(d.getString('id') ?? newIdRaw()),
      label: d.getString('label') ?? 'Untitled',
      amountMinorUnits: amountMinorUnits,
      dayOfMonth: d.getInt('dayOfMonth') ?? 1,
      type: type,
      startDate: d.getIsoDateTime('startDate') ?? DateTime.now(),
      frequency: frequency,
      notes: d.getString('notes'),
      archived: d.getBool('archived') ?? false,
      paidOffDate: d.getIsoDateTime('paidOffDate'),
      remainingBalanceMinorUnits: remainingBalanceMinorUnits,
      originalAmountMinorUnits: migratedOriginalAmount,
      category: d.getString('category') ?? d.getString('incomeCategory') ?? d.getString('expenseCategory'),
      company: d.getString('company'),
      isSalary: d.getBool('isSalary') ?? false,
      useAsPaycheckBoundary: d.getBool('useAsPaycheckBoundary') ?? false,
      moneyPotId: potIdStr != null ? MoneyPotId(potIdStr) : null,
      isQuickAdd: d.getBool('isQuickAdd') ?? false,
      balanceCurrency: decodeCurrency(d.getString('balanceCurrency')),
      exchangeRate: d.getDouble('exchangeRate'),
      useActualsForBalance: d.getBool('useActualsForBalance') ?? false,
    );
  }

  static RecurrenceFrequency? _mapLegacyFrequency(String? str) {
    if (str == null) return null;
    final lower = str.toLowerCase();
    if (lower.contains('weekly')) {
      if (lower.contains('bi')) return RecurrenceFrequency.biweekly;
      return RecurrenceFrequency.weekly;
    }
    if (lower.contains('monthly')) return RecurrenceFrequency.monthly;
    if (lower.contains('quarterly')) return RecurrenceFrequency.quarterly;
    if (lower.contains('yearly') || lower.contains('annual')) {
      return RecurrenceFrequency.yearly;
    }
    return null;
  }
}

class PaymentEntryCodec {
  static Map<String, Object?> toJson(PaymentEntry entry) => {
    'id': entry.id,
    'label': entry.label,
    'amountMinorUnits': entry.amountMinorUnits,
    'date': entry.date.millisecondsSinceEpoch,
    'type': _encodePaymentType(entry.type),
    'plannerItemId': entry.plannerItemId,
    'notes': entry.notes,
    'category': entry.category,
    'company': entry.company,
    'scheduledDate': entry.scheduledDate?.millisecondsSinceEpoch,
    'scheduledAmountMinorUnits': entry.scheduledAmountMinorUnits,
    'moneyPotId': entry.moneyPotId,
  };

  static PaymentEntry fromJson(Map<String, Object?> json) {
    final d = MapDecoder(json);
    final millis = d.getInt('date');
    final scheduledDateMillis = d.getInt('scheduledDate');
    final plannerItemIdStr = d.getString('plannerItemId');
    final moneyPotIdStr = d.getString('moneyPotId');

    return PaymentEntry(
      id: EntryId(d.getString('id') ?? newIdRaw()),
      label: d.getString('label') ?? 'Untitled',
      amountMinorUnits: d.getInt('amountMinorUnits') ?? d.getInt('amountCents') ?? d.getInt('amount') ?? d.getInt('cents') ?? d.getInt('amount_minor_units') ?? 0,
      date: dateOnly(millis != null
          ? DateTime.fromMillisecondsSinceEpoch(millis, isUtc: true)
          : DateTime.now()),
      type: _decodePaymentType(d.getString('type')) ?? PaymentType.oneOff,
      plannerItemId: plannerItemIdStr != null ? PlannerItemId(plannerItemIdStr) : null,
      notes: d.getString('notes'),
      category: d.getString('category'),
      company: d.getString('company'),
      scheduledDate: scheduledDateMillis != null
          ? dateOnly(DateTime.fromMillisecondsSinceEpoch(scheduledDateMillis, isUtc: true))
          : null,
      scheduledAmountMinorUnits: d.getInt('scheduledAmountMinorUnits') ?? d.getInt('scheduledAmountCents') ?? d.getInt('scheduledAmount') ?? d.getInt('scheduled_amount_minor_units'),
      moneyPotId: moneyPotIdStr != null ? MoneyPotId(moneyPotIdStr) : null,
    );
  }

  static String _encodePaymentType(PaymentType type) {
    return switch (type) {
      PaymentType.recurring => 'recurring',
      PaymentType.recurringIncome => 'recurring-income',
      PaymentType.debt => 'debt',
      PaymentType.oneOff => 'one-off',
      PaymentType.oneOffIncome => 'one-off-income',
      PaymentType.spendingEnvelope => 'spending-envelope',
    };
  }

  static PaymentType? _decodePaymentType(Object? raw) {
    if (raw is! String) return null;
    return switch (raw) {
      'recurring' => PaymentType.recurring,
      'recurring-income' => PaymentType.recurringIncome,
      'debt' => PaymentType.debt,
      'one-off' || 'one_off' || 'oneoff' || 'oneOff' => PaymentType.oneOff,
      'one-off-income' || 'oneOffIncome' => PaymentType.oneOffIncome,
      'spending-envelope' || 'spendingEnvelope' => PaymentType.spendingEnvelope,
      _ => null,
    };
  }
}

class StorageException implements Exception {
  StorageException(this.message);
  final String message;

  @override
  String toString() => 'StorageException: $message';
}
