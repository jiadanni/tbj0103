import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/features/export/export_service.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Screen for exporting and importing expense data.
///
/// Provides options to:
/// - Export all data as JSON (full backup)
/// - Export all data as CSV (for spreadsheet analysis)
/// - Import data from a JSON backup file
class ExportScreen extends StatefulWidget {
  const ExportScreen({super.key});

  @override
  State<ExportScreen> createState() => _ExportScreenState();
}

enum _ExportType { json, jsonAll, csv, gridCsv }

class _ExportScreenState extends State<ExportScreen> {
  _ExportType? _activeExport;
  bool _isImporting = false;
  String? _statusMessage;
  bool _isError = false;
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    _authService.initialize();
  }

  bool get _isExporting => _activeExport != null;

  void _showExportSnackBar(String message) {
    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final palette = _ExportPalette.of(context);

    return Scaffold(
      backgroundColor: palette.backgroundBottom,
      body: Stack(
        children: [
          const _ExportBackdrop(),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              children: [
                _ExportHeader(
                  title: AppLocalizations.of(context)!.exportAndImportTitle,
                  subtitle: '${AppLocalizations.of(context)!.saveYourData} '
                      '${AppLocalizations.of(context)!.restoreYourData}',
                ),
                const SizedBox(height: 20),

                // Status message
                if (_statusMessage != null)
                  _ExportStatusBanner(
                    message: _statusMessage!,
                    isError: _isError,
                  ),
                if (_statusMessage != null) const SizedBox(height: 16),

                // Export section
                _ExportSectionTitle(
                  title: AppLocalizations.of(context)!.exportSectionTitle,
                  description: AppLocalizations.of(context)!.saveYourData,
                ),
                const SizedBox(height: 16),

                _ActionCard(
                  icon: Icons.data_object,
                  title: 'Export "${ExpenseStoreScope.of(context).currentAccount.name}"',
                  description: 'Export all data for the currently selected account.',
                  buttonLabel: 'Export JSON',
                  isLoading: _activeExport == _ExportType.json,
                  onPressed: _isExporting || _isImporting ? null : _exportJson,
                ),
                const SizedBox(height: 12),

                _ActionCard(
                  icon: Icons.backup_outlined,
                  title: 'Export All Accounts',
                  description: 'Backup all accounts and their data into a single file.',
                  buttonLabel: 'Full Backup',
                  isLoading: _activeExport == _ExportType.jsonAll,
                  onPressed: _isExporting || _isImporting ? null : _exportAllJson,
                ),
                const SizedBox(height: 12),

                _ActionCard(
                  icon: Icons.table_chart_outlined,
                  title: AppLocalizations.of(context)!.exportAsCsv,
                  description: AppLocalizations.of(context)!.exportAsCsvDescription,
                  buttonLabel: AppLocalizations.of(context)!.exportCsv,
                  isLoading: _activeExport == _ExportType.csv,
                  onPressed: _isExporting || _isImporting ? null : _exportCsv,
                ),
                const SizedBox(height: 12),

                _ActionCard(
                  icon: Icons.grid_on,
                  title: 'Export as Multi-Month Grid',
                  description:
                      'Export items across months in a grid layout (like the spreadsheet view)',
                  buttonLabel: 'Export Grid CSV',
                  isLoading: _activeExport == _ExportType.gridCsv,
                  onPressed: _isExporting || _isImporting ? null : _exportGridCsv,
                ),

                const SizedBox(height: 28),
                Divider(height: 1, color: palette.border),
                const SizedBox(height: 20),

                // Import section
                _ExportSectionTitle(
                  title: AppLocalizations.of(context)!.importSectionTitle,
                  description: AppLocalizations.of(context)!.restoreYourData,
                ),
                const SizedBox(height: 16),

                _ActionCard(
                  icon: Icons.file_upload_outlined,
                  title: AppLocalizations.of(context)!.importFromJson,
                  description: AppLocalizations.of(context)!.importFromJsonDescription,
                  buttonLabel: AppLocalizations.of(context)!.importJson,
                  isLoading: _isImporting,
                  isDestructive: true,
                  onPressed: _isExporting || _isImporting ? null : _importJson,
                ),

                const SizedBox(height: 20),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: palette.surfaceAlt.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: palette.border),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_outline,
                        size: 20,
                        color: palette.textSecondary,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          AppLocalizations.of(context)!.importWarning,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: palette.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _authenticateForExport() async {
    // If no PIN is set, no authentication required
    if (!await _authService.hasPIN()) {
      return true;
    }

    final l10n = AppLocalizations.of(context)!;

    // Check if we should attempt biometrics (enabled in settings AND enrolled on device)
    final useBiometrics = await _authService.useBiometrics();
    final bioAvailable = await _authService.isBiometricAvailable();
    final bioTypes = await _authService.getAvailableBiometrics();
    final canUseBiometrics = useBiometrics && bioAvailable && bioTypes.isNotEmpty;

    if (canUseBiometrics) {
      // Attempt biometric auth
      final success = await _authService.authenticateWithBiometrics(
        reason: l10n.authenticateToExport,
      );
      
      // If biometrics failed or was cancelled, we assume the user wanted to
      // cancel the operation. We do NOT fallback to PIN here.
      if (!success && mounted) {
        setState(() {
          _statusMessage = l10n.authenticationRequired;
          _isError = true;
        });
      }
      return success;
    }

    // Fall back to PIN dialog ONLY if biometrics were skipped (not enabled/available)
    if (!mounted) return false;
    final pinVerified = await _showPinVerifyDialog(context);
    if (!pinVerified && mounted) {
      setState(() {
        _statusMessage = l10n.authenticationRequired;
        _isError = true;
      });
    }
    return pinVerified;
  }

  Future<bool> _showPinVerifyDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => _PinVerifyDialog(authService: _authService),
    );
    return result ?? false;
  }

  Future<void> _exportJson() async {
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeExport = _ExportType.json;
      _statusMessage = null;
    });

    try {
      final store = ExpenseStoreScope.read(context);
      final snapshot = store.createSnapshot();

      // Password prompt for encryption
      if (!mounted) return;
      final password = await showDialog<String>(
        context: context,
        builder: (context) => const _PasswordPromptDialog(
          title: 'Encrypt Backup?',
          message: 'Protect your backup with AES-GCM encryption. Leave blank for unencrypted export.',
          confirmLabel: 'Export',
          isOptional: true,
        ),
      );

      if (password == null) {
        setState(() => _activeExport = null);
        return;
      }

      final path = await ExportService.instance.exportJson(
        snapshot,
        password: password.isEmpty ? null : password,
        accountName: store.currentAccount.name,
      );

      if (mounted) {
        setState(() {
          _activeExport = null;
          if (path != null) {
            _statusMessage = AppLocalizations.of(context)!.jsonBackupReady;
            _isError = false;
          } else {
            _statusMessage = AppLocalizations.of(context)!.exportCancelled;
            _isError = true;
          }
        });
        _showExportSnackBar(_statusMessage!);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeExport = null;
          _statusMessage = AppLocalizations.of(context)!.exportFailed(e.toString());
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportAllJson() async {
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeExport = _ExportType.jsonAll;
      _statusMessage = null;
    });

    try {
      final store = ExpenseStoreScope.read(context);
      
      // We need to collect snapshots for ALL accounts
      // This is a bit inefficient as it requires loading each one
      // but backups are rare so it's fine.
      final accounts = store.accounts;
      final data = <String, ExpenseSnapshot>{};
      
      // Save current state first
      await store.saveNow();

      // For simplicity in this backup, we only backup the currently loaded account data
      // and whatever else is in persistence. 
      // Actually, ExpensePersistence already handles multiple accounts.
      // We can iterate accounts and load snapshots.
      final persistence = store.persistence;
      for (final account in accounts) {
        if (account.id == store.currentAccount.id) {
          data[account.id] = store.createSnapshot();
        } else {
          final snapshot = await persistence?.load(account.id);
          if (snapshot != null) {
            data[account.id] = snapshot;
          }
        }
      }

      // Password prompt for encryption
      if (!mounted) return;
      final password = await showDialog<String>(
        context: context,
        builder: (context) => const _PasswordPromptDialog(
          title: 'Encrypt Full Backup?',
          message: 'Protect your full backup (all accounts) with AES-GCM encryption. Leave blank for unencrypted export.',
          confirmLabel: 'Export All',
          isOptional: true,
        ),
      );

      if (password == null) {
        setState(() => _activeExport = null);
        return;
      }

      final path = await ExportService.instance.exportAllAccountsJson(
        accounts,
        data,
        password: password.isEmpty ? null : password,
      );

      if (mounted) {
        setState(() {
          _activeExport = null;
          if (path != null) {
            _statusMessage = 'Full backup ready!';
            _isError = false;
          } else {
            _statusMessage = AppLocalizations.of(context)!.exportCancelled;
            _isError = true;
          }
        });
        _showExportSnackBar(_statusMessage!);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeExport = null;
          _statusMessage = 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportCsv() async {
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeExport = _ExportType.csv;
      _statusMessage = null;
    });

    try {
      final store = ExpenseStoreScope.read(context);
      final snapshot = store.createSnapshot();
      final path = await ExportService.instance.exportCsv(
        snapshot,
        accountName: store.currentAccount.name,
      );

      if (mounted) {
        setState(() {
          _activeExport = null;
          if (path != null) {
            _statusMessage = AppLocalizations.of(context)!.csvExportReady;
            _isError = false;
          } else {
            _statusMessage = AppLocalizations.of(context)!.exportCancelled;
            _isError = true;
          }
        });
        _showExportSnackBar(_statusMessage!);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeExport = null;
          _statusMessage = AppLocalizations.of(context)!.exportFailed(e.toString());
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportGridCsv() async {
    if (!await _authenticateForExport()) return;

    // Show month selection dialog
    final monthCount = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Number of Months'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('3 months'),
              onTap: () => Navigator.pop(context, 3),
            ),
            ListTile(
              title: const Text('6 months (recommended)'),
              onTap: () => Navigator.pop(context, 6),
            ),
            ListTile(
              title: const Text('12 months'),
              onTap: () => Navigator.pop(context, 12),
            ),
            ListTile(
              title: const Text('24 months'),
              onTap: () => Navigator.pop(context, 24),
            ),
          ],
        ),
      ),
    );

    if (monthCount == null) return;

    setState(() {
      _activeExport = _ExportType.gridCsv;
      _statusMessage = null;
    });

    try {
      final store = ExpenseStoreScope.read(context);
      final snapshot = store.createSnapshot();
      final path = await ExportService.instance.exportGridCsv(
        snapshot,
        monthCount: monthCount,
        accountName: store.currentAccount.name,
      );

      if (mounted) {
        setState(() {
          _activeExport = null;
          if (path != null) {
            _statusMessage = 'Grid CSV export ready!';
            _isError = false;
          } else {
            _statusMessage = AppLocalizations.of(context)!.exportCancelled;
            _isError = true;
          }
        });
        _showExportSnackBar(_statusMessage!);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeExport = null;
          _statusMessage = AppLocalizations.of(context)!.exportFailed(e.toString());
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _importJson() async {
    if (!await _authenticateForExport()) return;

    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(AppLocalizations.of(context)!.importDialogTitle),
        content: Text(
          AppLocalizations.of(context)!.importDialogMessage,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(AppLocalizations.of(context)!.cancel),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: Text(AppLocalizations.of(context)!.importAction),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    setState(() {
      _isImporting = true;
      _statusMessage = null;
    });

    try {
      final result = await ExportService.instance.importJson(
        onPasswordRequired: () => showDialog<String>(
          context: context,
          builder: (context) => const _PasswordPromptDialog(
            title: 'Encrypted Backup',
            message: 'This backup is encrypted. Please enter the password to unlock it.',
            confirmLabel: 'Unlock',
            isOptional: false,
          ),
        ),
      );

      if (result == null || result.$1.isEmpty) {
        if (mounted) {
          setState(() {
            _isImporting = false;
            _statusMessage = AppLocalizations.of(context)!.importCancelled;
            _isError = false;
          });
        }
        return;
      }

      final (importedAccounts, importedData) = result;

      if (mounted) {
        final store = ExpenseStoreScope.read(context);
        
        // Ask user how to import
        final mode = await showDialog<_ImportMode>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Import Options'),
            content: Text('Found ${importedAccounts.length} account(s) in backup. How would you like to import them?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, _ImportMode.merge),
                child: const Text('Merge into Current'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, _ImportMode.createNew),
                child: const Text('Create New Account(s)'),
              ),
            ],
          ),
        );

        if (mode == null) {
          setState(() => _isImporting = false);
          return;
        }

        if (mode == _ImportMode.merge) {
          // Confirm overwrite with explicit account name
          if (!mounted) return;
          final currentAccountName = store.currentAccount.name;
          final confirmOverwrite = await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Overwrite "$currentAccountName"?'),
              content: Text(
                'This will merge imported data into "$currentAccountName". Existing items may be updated. This action cannot be undone.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: FilledButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.error,
                  ),
                  child: const Text('Overwrite'),
                ),
              ],
            ),
          );

          if (confirmOverwrite != true) {
            setState(() {
              _isImporting = false;
              _statusMessage = 'Import cancelled';
            });
            return;
          }

          // Merge first imported account into current
          final firstSnapshot = importedData[importedAccounts.first.id];
          if (firstSnapshot != null) {
            store.importSnapshot(firstSnapshot);
          }
        } else {
          // Create new accounts for each imported one
          for (final account in importedAccounts) {
            final snapshot = importedData[account.id];
            if (snapshot != null) {
              if (!mounted) break;
              final newAccountName = await showDialog<String>(
                context: context,
                barrierDismissible: false,
                builder: (context) => _NamePromptDialog(
                  title: 'Name Imported Account',
                  message: 'Enter a name for the account from "${account.name}".',
                  initialValue: account.name,
                ),
              );

              if (newAccountName == null) {
                // User cancelled the naming of this account, skip it
                continue;
              }

              await store.createAccount(
                newAccountName,
                testSize: null,
              );
              // Find the newly created account and switch to it before importing
              // We use firstWhere instead of .last to be more robust if background updates happen
              final newAccount = store.accounts.firstWhere(
                (a) => a.name == newAccountName,
                orElse: () => store.accounts.last,
              );
              await store.switchAccount(newAccount.id);
              store.importSnapshot(snapshot);
            }
          }
        }

        setState(() {
          _isImporting = false;
          _statusMessage = 'Import successful!';
          _isError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isImporting = false;
          _statusMessage = AppLocalizations.of(context)!.importFailed(e.toString());
          _isError = true;
        });
      }
    }
  }
}

enum _ImportMode { merge, createNew }

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.buttonLabel,
    required this.onPressed,
    this.isLoading = false,
    this.isDestructive = false,
  });

  final IconData icon;
  final String title;
  final String description;
  final String buttonLabel;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isDestructive;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final palette = _ExportPalette.of(context);

    return Container(
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: palette.border),
        boxShadow: [
          BoxShadow(
            color: palette.shadow,
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isDestructive
                        ? palette.errorColor.withValues(alpha: 0.15)
                        : palette.themeColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isDestructive ? palette.errorColor : palette.themeColor,
                    ),
                  ),
                  child: Icon(
                    icon,
                    color: isDestructive ? palette.errorColor : palette.themeColor,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: palette.textPrimary,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              description,
              style: theme.textTheme.bodySmall?.copyWith(
                color: palette.textSecondary,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: isDestructive
                  ? OutlinedButton(
                      onPressed: onPressed,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: palette.errorColor,
                        side: BorderSide(color: palette.errorColor),
                      ),
                      child: isLoading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(buttonLabel),
                    )
                  : FilledButton.tonal(
                      onPressed: onPressed,
                      style: FilledButton.styleFrom(
                        backgroundColor: palette.themeColor.withValues(alpha: 0.12),
                        foregroundColor: palette.textPrimary,
                      ),
                      child: isLoading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(buttonLabel),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ExportHeader extends StatelessWidget {
  const _ExportHeader({
    required this.title,
    required this.subtitle,
  });

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: palette.surfaceAlt,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: palette.border),
        boxShadow: [
          BoxShadow(
            color: palette.shadow,
            blurRadius: 16,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: palette.themeColor.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: palette.themeColor.withValues(alpha: 0.6)),
            ),
            child: Icon(
              Icons.import_export,
              color: palette.themeColor,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: palette.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: textTheme.bodySmall?.copyWith(
                    color: palette.textSecondary,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportSectionTitle extends StatelessWidget {
  const _ExportSectionTitle({
    required this.title,
    required this.description,
  });

  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: palette.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          description,
          style: textTheme.bodySmall?.copyWith(
            color: palette.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _ExportStatusBanner extends StatelessWidget {
  const _ExportStatusBanner({
    required this.message,
    required this.isError,
  });

  final String message;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final palette = _ExportPalette.of(context);
    final color = isError ? palette.errorColor : palette.themeColor;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: color,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodySmall?.copyWith(
                color: palette.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportBackdrop extends StatelessWidget {
  const _ExportBackdrop();

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [palette.backgroundTop, palette.backgroundBottom],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -90,
              left: -40,
              child: _GlowOrb(
                color: palette.glowPrimary,
                size: 220,
              ),
            ),
            Positioned(
              top: 220,
              right: -50,
              child: _GlowOrb(
                color: palette.glowSecondary,
                size: 180,
              ),
            ),
            Positioned(
              bottom: -120,
              right: -30,
              child: _GlowOrb(
                color: palette.glowMuted,
                size: 260,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  const _GlowOrb({
    required this.color,
    required this.size,
  });

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withValues(alpha: 0)],
          ),
        ),
      ),
    );
  }
}

class _ExportPalette {
  const _ExportPalette({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.surface,
    required this.surfaceAlt,
    required this.border,
    required this.shadow,
    required this.textPrimary,
    required this.textSecondary,
    required this.themeColor,
    required this.errorColor,
    required this.glowPrimary,
    required this.glowSecondary,
    required this.glowMuted,
  });

  final Color backgroundTop;
  final Color backgroundBottom;
  final Color surface;
  final Color surfaceAlt;
  final Color border;
  final Color shadow;
  final Color textPrimary;
  final Color textSecondary;
  final Color themeColor;
  final Color errorColor;
  final Color glowPrimary;
  final Color glowSecondary;
  final Color glowMuted;

  static _ExportPalette of(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return _ExportPalette(
      backgroundTop: isDark ? const Color(0xFF0B1220) : const Color(0xFFF7F5FF),
      backgroundBottom: isDark ? const Color(0xFF0E1A2F) : const Color(0xFFEFF4FF),
      surface: isDark ? const Color(0xFF121B2B) : Colors.white,
      surfaceAlt: isDark ? const Color(0xFF162237) : const Color(0xFFF9FAFF),
      border: isDark ? const Color(0xFF2A3A57) : const Color(0xFFE1E6F2),
      shadow: Colors.black.withValues(alpha: isDark ? 0.25 : 0.08),
      textPrimary: scheme.onSurface,
      textSecondary: scheme.onSurfaceVariant,
      themeColor: scheme.primary,
      errorColor: scheme.error,
      glowPrimary: scheme.primary.withValues(alpha: isDark ? 0.25 : 0.18),
      glowSecondary: scheme.secondary.withValues(alpha: isDark ? 0.22 : 0.16),
      glowMuted: scheme.tertiary.withValues(alpha: isDark ? 0.2 : 0.14),
    );
  }
}

/// PIN verification dialog for export/import authentication.
class _PinVerifyDialog extends StatefulWidget {
  const _PinVerifyDialog({
    required this.authService,
  });

  final AuthService authService;

  @override
  State<_PinVerifyDialog> createState() => _PinVerifyDialogState();
}

class _PinVerifyDialogState extends State<_PinVerifyDialog> {
  final TextEditingController _pinController = TextEditingController();
  String? _errorMessage;
  bool _isVerifying = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_isVerifying) return;
    final l10n = AppLocalizations.of(context)!;
    final pin = _pinController.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorMessage = l10n.enterPIN);
      return;
    }

    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    final result = await widget.authService.verifyPIN(pin);
    if (!mounted) return;
    if (result == PinVerificationResult.success) {
      Navigator.pop(context, true);
      return;
    }

    setState(() {
      _isVerifying = false;
      _errorMessage = l10n.incorrectPIN;
      _pinController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return AlertDialog(
      title: Text(l10n.enterYourPIN),
      content: TextField(
        controller: _pinController,
        keyboardType: TextInputType.number,
        obscureText: true,
        maxLength: AuthService.maxPinLength,
        autofocus: true,
        decoration: InputDecoration(
          labelText: l10n.pin,
          errorText: _errorMessage,
          counterText: '',
        ),
        onSubmitted: (_) => _verify(),
      ),
      actions: [
        TextButton(
          onPressed: _isVerifying ? null : () => Navigator.pop(context, false),
          child: Text(l10n.cancel),
        ),
        FilledButton(
          onPressed: _isVerifying ? null : _verify,
          child: Text(l10n.verify),
        ),
      ],
    );
  }
}

/// Password prompt dialog for encrypted exports/imports.
class _PasswordPromptDialog extends StatefulWidget {
  const _PasswordPromptDialog({
    required this.title,
    required this.message,
    this.confirmLabel = 'OK',
    this.isOptional = false,
  });

  final String title;
  final String message;
  final String confirmLabel;
  final bool isOptional;

  @override
  State<_PasswordPromptDialog> createState() => _PasswordPromptDialogState();
}

class _PasswordPromptDialogState extends State<_PasswordPromptDialog> {
  final TextEditingController _controller = TextEditingController();
  bool _obscureText = true;
  _PasswordStrength _strength = _PasswordStrength.empty;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _updateStrength(String password) {
    setState(() {
      _strength = _calculateStrength(password);
    });
  }

  _PasswordStrength _calculateStrength(String password) {
    if (password.isEmpty) return _PasswordStrength.empty;
    
    final hasLetters = password.contains(RegExp(r'[a-zA-Z]'));
    final hasNumbers = password.contains(RegExp(r'[0-9]'));
    final hasSpecial = password.contains(RegExp(r'[!@#\$%^&*(),.?":{}|<>]'));
    final length = password.length;

    if (length < 8) return _PasswordStrength.weak;
    
    if (length >= 12 && hasLetters && hasNumbers && hasSpecial) {
      return _PasswordStrength.strong;
    }
    
    if (length >= 8 && (hasLetters || hasNumbers)) {
      return _PasswordStrength.medium;
    }

    return _PasswordStrength.weak;
  }

  Color _getStrengthColor(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
      case _PasswordStrength.weak:
        return Colors.red;
      case _PasswordStrength.medium:
        return Colors.orange;
      case _PasswordStrength.strong:
        return Colors.green;
    }
  }
  
  String _getStrengthLabel(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
        return '';
      case _PasswordStrength.weak:
        return 'Weak';
      case _PasswordStrength.medium:
        return 'Medium';
      case _PasswordStrength.strong:
        return 'Strong';
    }
  }

  String _getStrengthRecommendation(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
        return '';
      case _PasswordStrength.weak:
        return 'Use at least 8 characters.';
      case _PasswordStrength.medium:
        return 'Add special characters for a stronger password.';
      case _PasswordStrength.strong:
        return 'Great password!';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final strengthColor = _getStrengthColor(_strength);

    return AlertDialog(
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.message),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              obscureText: _obscureText,
              autofocus: true,
              onChanged: _updateStrength,
              decoration: InputDecoration(
                labelText: 'Password',
                hintText: widget.isOptional ? '(Optional)' : null,
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(_obscureText ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscureText = !_obscureText),
                ),
              ),
              onSubmitted: (_) => Navigator.pop(context, _controller.text),
            ),
            if (_strength != _PasswordStrength.empty) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: LinearProgressIndicator(
                      value: _strength.index / 3,
                      backgroundColor: strengthColor.withValues(alpha: 0.2),
                      color: strengthColor,
                      minHeight: 4,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    _getStrengthLabel(_strength),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: strengthColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                _getStrengthRecommendation(_strength),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context, _controller.text),
          child: Text(widget.confirmLabel),
        ),
      ],
    );
  }
}

enum _PasswordStrength { empty, weak, medium, strong }

/// Dialog for prompting for a name (e.g. account name).
class _NamePromptDialog extends StatefulWidget {
  const _NamePromptDialog({
    required this.title,
    required this.message,
    this.initialValue = '',
  });

  final String title;
  final String message;
  final String initialValue;

  @override
  State<_NamePromptDialog> createState() => _NamePromptDialogState();
}

class _NamePromptDialogState extends State<_NamePromptDialog> {
  late final TextEditingController _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final value = _controller.text.trim();
    if (value.isEmpty) {
      setState(() => _error = 'Name cannot be empty');
      return;
    }
    
    // Check for duplicate names in store
    final store = ExpenseStoreScope.read(context);
    if (store.accounts.any((a) => a.name == value)) {
      setState(() => _error = 'An account with this name already exists');
      return;
    }

    Navigator.pop(context, value);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.message),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            autofocus: true,
            maxLength: AppConstants.maxAccountNameLength,
            decoration: InputDecoration(
              labelText: 'Account Name',
              errorText: _error,
              border: const OutlineInputBorder(),
              counterText: '',
            ),
            onChanged: (v) {
              if (_error != null) setState(() => _error = null);
            },
            onSubmitted: (_) => _submit(),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Create'),
        ),
      ],
    );
  }
}
