import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_actions.dart';
import 'package:expense_stalker_mobile/src/features/planner/month_card.dart';
import 'package:expense_stalker_mobile/src/features/planner/multi_month_grid.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_sheet.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/envelope_logic.dart';

/// Computes the earliest month from planner items' start dates.
/// Returns the current month if no items exist.
DateTime _earliestItemMonth(List<PlannerItem> items) {
  final nowMonth = monthOnly(DateTime.now());
  if (items.isEmpty) return nowMonth;
  var earliest = monthOnly(items.first.startDate);
  for (final item in items.skip(1)) {
    final start = monthOnly(item.startDate);
    if (start.isBefore(earliest)) earliest = start;
  }
  return earliest;
}

/// Computes the starting balance for a future month by chaining from current period.
/// Returns null for past/current periods.
int? _computeStartBalanceForMonth({
  required DateTime targetMonth,
  required DateTime currentPeriodMonth,
  required int currentBalanceCents,
  required List<PlannerItem> items,
  required Function(DateTime, PeriodInfo) Function(DateTime) paymentsBuilder,
  required AppSettingsStore settings,
}) {
  final target = monthOnly(targetMonth);
  final current = monthOnly(currentPeriodMonth);

  // Don't compute for past or current period
  if (!target.isAfter(current)) return null;

  // Helper to check if an item is cleared in a given month
  DateTime? clearedDateFor(PlannerItem item, List<PaymentEntry> payments, DateTime month) {
    PaymentEntry? best;
    for (final payment in payments) {
      if (!paymentMatchesPlannerItem(payment, item, month, settings)) continue;
      if (best == null || payment.date.isAfter(best.date)) best = payment;
    }
    return best?.date;
  }

  // Compute net change for each month from current to target-1
  var balance = currentBalanceCents;
  var cursor = current;

  while (cursor.isBefore(target)) {
    final periodInfo = PaycheckService.getPeriodInfo(
      cursor,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    final monthPayments = paymentsBuilder(cursor)(cursor, periodInfo);
    final isCurrent = cursor.year == current.year && cursor.month == current.month;

    // Sum items for this month
    // For current period: only count uncleared (cleared are in currentBalanceCents)
    // For future periods: count all items
    final monthItems = items.where((item) => item.shouldAppearInMonth(cursor));
    for (final item in monthItems) {
      balance += calculateItemNetChangeForMonth(
        item: item,
        month: cursor,
        payments: monthPayments,
        isCurrentPeriod: isCurrent,
        periodInfo: periodInfo,
        settings: settings,
      );
    }

    cursor = monthOnly(month_math.addMonths(cursor, 1));
  }

  return balance;
}

/// Builds the month view (single month with PageView).
Widget buildMonthView({
  required BuildContext context,
  required PageController pageController,
  required ExpenseStore store,
  required AppSettingsStore settings,
  required DateTime monthOrigin,
  required int monthOriginPage,
  required int monthWindowSize,
  required VoidCallback onPinchOut,
  required Function(int) onPageChanged,
  required Function(DateTime, PeriodInfo) Function(DateTime) paymentsBuilder,
}) {
  final now = DateTime.now();
  final showClearedPreference = settings.plannerShowClearedItems;

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth = (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
          settings.isPaycheckModeConfigured)
      ? PaycheckService.getCurrentPaycheckPeriodMonth(
          now,
          settings.paycheckDay!,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        )
      : monthOnly(now);

  double lastScale = 1.0;
  
  // Compute a single hash for all items to reuse across all month cards (avoid redundant recomputation)
  final itemsHash = store.activePlannerItems.fold<int>(
    0,
    (hash, item) => hash ^ item.id.hashCode ^ item.dayOfMonth ^ item.amountMinorUnits ^ item.label.hashCode,
  );
  
  return GestureDetector(
    onScaleStart: (_) {
      lastScale = 1.0;
    },
    onScaleUpdate: (details) {
      lastScale = details.scale;
    },
    onScaleEnd: (_) {
      if (lastScale < 0.92) {
        onPinchOut();
      }
    },
    child: PageView.builder(
      controller: pageController,
      onPageChanged: onPageChanged,
      itemCount: monthWindowSize,
      itemBuilder: (context, index) {
        final month = monthForPage(monthOrigin, index, monthOriginPage);
        final monthOnlyValue = monthOnly(month);
        final isCardCurrentPeriod = monthOnlyValue.year == currentPeriodMonth.year &&
            monthOnlyValue.month == currentPeriodMonth.month;
        final showClearedForCard = isCardCurrentPeriod ? showClearedPreference : true;
        final periodInfo = PaycheckService.getPeriodInfo(
          month,
          settings.viewPeriodMode,
          settings.paycheckDay,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        );
        final payments = paymentsBuilder(month)(month, periodInfo);

        // Precompute starting balance for future months
        // This ensures correct cleared state handling across periods
        final precomputedBalance = _computeStartBalanceForMonth(
          targetMonth: month,
          currentPeriodMonth: currentPeriodMonth,
          currentBalanceCents: settings.currentBalanceCents,
          items: store.activePlannerItems,
          paymentsBuilder: paymentsBuilder,
          settings: settings,
        );

        return Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: MonthCard(
            // Key based on payments count AND reused items hash to force rebuild when either changes
            key: ValueKey('${month.year}-${month.month}-${payments.length}-$itemsHash'),
            month: month,
            items: store.activePlannerItems,
            payments: payments,
            recentlyClearedItemIds: store.recentlyClearedPlannerItemIds,
            swipeLeft: settings.plannerSwipeLeft,
            swipeRight: settings.plannerSwipeRight,
            settings: settings,
            showCleared: showClearedForCard,
            sortOrder: settings.plannerSortOrder,
            dateSortMode: settings.plannerDateSortMode,
            displayMode: monthCardDisplayModeToPaymentMode(settings.monthCardDisplayMode),
            precomputedStartBalanceCents: precomputedBalance,
          ),
        );
      },
    ),
  );
}

/// Builds the grid view (multi-month grid with zoom).
Widget buildGridView({
  required BuildContext context,
  required TransformationController gridTransformController,
  required ExpenseStore store,
  required AppSettingsStore settings,
  required double viewportWidth,
  required DateTime selectedMonth,
  required int gridColumns,
  required VoidCallback onInitGridTransform,
  required VoidCallback onSnap,
  required Function(DateTime) onMonthTapped,
  required Function(DateTime, PeriodInfo) Function(DateTime) paymentsBuilder,
}) {
  final now = DateTime.now();
  // Start from earliest planner item, show up to 24 months after selected
  final earliestMonth = _earliestItemMonth(store.activePlannerItems);
  final monthsBefore = monthsBetween(earliestMonth, selectedMonth);
  final gridMonths = monthRange(selectedMonth, before: monthsBefore, after: 24);
  final baseBalance = settings.plannerUseZeroBaseline
      ? 0
      : settings.currentBalanceCents;

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth = (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
          settings.isPaycheckModeConfigured)
      ? PaycheckService.getCurrentPaycheckPeriodMonth(
          now,
          settings.paycheckDay!,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        )
      : monthOnly(now);

  return ClipRect(
    child: ListenableBuilder(
      listenable: gridTransformController,
      builder: (context, _) {
        return InteractiveViewer(
          transformationController: gridTransformController,
          minScale: 0.3,
          maxScale: 2.0,
          constrained: false,
          boundaryMargin: EdgeInsets.zero,
          onInteractionEnd: (details) {
            // Snap to nearest row boundary when interaction ends
            onSnap();
          },
          child: MultiMonthGrid(
            months: gridMonths,
            items: store.activePlannerItems,
            paymentsForMonth: (month) {
              final periodInfo = PaycheckService.getPeriodInfo(
                month,
                settings.viewPeriodMode,
                settings.paycheckDay,
                businessAdjust: settings.paycheckBusinessAdjust,
                adjustDirection: settings.paycheckBusinessAdjustDirection,
              );
              return paymentsBuilder(month)(month, periodInfo);
            },
            currency: settings.currencySettings.currency,
            currentMonth: currentPeriodMonth,
            showClearedForCurrentMonth: settings.plannerShowClearedItems,
            recentlyClearedItemIds: store.recentlyClearedPlannerItemIds,
            sortOrder: settings.plannerSortOrder,
            dateSortMode: settings.plannerDateSortMode,
            dayFormat: settings.dayFormat,
            columnsPerRow: gridColumns,
            startingBalanceCents: baseBalance,
            settings: settings,
            displayMode: multiMonthDisplayModeToPaymentMode(settings.multiMonthDisplayMode),
            onMonthTapped: onMonthTapped,
          ),
        );
      },
    ),
  );
}

/// Builds the sheet view (horizontal spreadsheet-style).
Widget buildSheetView({
  required BuildContext context,
  required TransformationController sheetTransformController,
  required ExpenseStore store,
  required AppSettingsStore settings,
  required double viewportWidth,
  required DateTime selectedMonth,
  required GridZoomStage zoomStage,
  required int startingBalanceCents,
  required VoidCallback onInitSheetTransform,
  required VoidCallback onSnap,
  required Function(DateTime) onMonthTapped,
  required Function(DateTime, PeriodInfo) Function(DateTime) paymentsBuilder,
}) {
  final now = DateTime.now();
  // Start from earliest planner item, show up to 36 months after selected
  final earliestMonth = _earliestItemMonth(store.activePlannerItems);
  final monthsBefore = monthsBetween(earliestMonth, selectedMonth);
  final sheetMonths = monthRange(selectedMonth, before: monthsBefore, after: 36);

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth = (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
          settings.isPaycheckModeConfigured)
      ? PaycheckService.getCurrentPaycheckPeriodMonth(
          now,
          settings.paycheckDay!,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        )
      : monthOnly(now);

  // Pre-build widgets to avoid reconstruction on every scroll frame (performance)
  final plannerSheet = PlannerSheet(
    months: sheetMonths,
    items: store.activePlannerItems,
    paymentsForMonth: (month) {
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      return paymentsBuilder(month)(month, periodInfo);
    },
    currency: settings.currencySettings.currency,
    currentMonth: currentPeriodMonth,
    showClearedForCurrentMonth: settings.plannerShowClearedItems,
    recentlyClearedItemIds: store.recentlyClearedPlannerItemIds,
    startingBalanceCents: startingBalanceCents,
    zoomStage: zoomStage,
    sortOrder: settings.plannerSortOrder,
    dayFormat: settings.dayFormat,
    displayMode: effectiveSheetDisplayMode(
      multiMonthDisplayModeToPaymentMode(settings.multiMonthDisplayMode),
      zoomStage,
    ),
    settings: settings,
    onMonthTapped: onMonthTapped,
    showFooters: false, // Hide footers in columns - they'll be shown in fixed overlay
  );

  final footerRow = SheetFooterRow(
    months: sheetMonths,
    items: store.activePlannerItems,
    paymentsForMonth: (month) {
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      return paymentsBuilder(month)(month, periodInfo);
    },
    currency: settings.currencySettings.currency,
    currentMonth: currentPeriodMonth,
    startingBalanceCents: startingBalanceCents,
    zoomStage: zoomStage,
    settings: settings,
  );

  return LayoutBuilder(
    builder: (context, constraints) {
      return ClipRect(
        child: ListenableBuilder(
          listenable: sheetTransformController,
          builder: (context, _) {
            return Stack(
              children: [
                // Main scrollable content (without footers in columns)
                InteractiveViewer(
                  transformationController: sheetTransformController,
                  minScale: 0.28,
                  maxScale: 2.5,
                  constrained: false,
                  panEnabled: true,
                  scaleEnabled: true,
                  panAxis: PanAxis.aligned, // Allow scrolling on either axis but not diagonal (avoids drift)
                  boundaryMargin: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
                  onInteractionEnd: (details) {
                    // Snap to nearest column boundary when interaction ends
                    onSnap();
                  },
                  child: plannerSheet,
                ),
                // Fixed footer at bottom of viewport
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: SizedBox(
                    height: SheetFooterRow.getFooterHeight(zoomStage),
                    child: Transform(
                      // Apply same horizontal translation as the main content but ignore vertical
                      // Scale X and Y only - Z must stay 1.0 for pointer events to work correctly
                      transform: Matrix4.identity()
                        ..translate(
                          sheetTransformController.value.getTranslation().x,
                          0.0,
                        )
                        ..scale(
                          sheetTransformController.value.getMaxScaleOnAxis(),
                          sheetTransformController.value.getMaxScaleOnAxis(),
                          1.0,
                        ),
                      alignment: Alignment.topLeft,
                      child: OverflowBox(
                        alignment: Alignment.topLeft,
                        minWidth: 0,
                        maxWidth: sheetMonths.length * SheetFooterRow.columnWidth,
                        minHeight: SheetFooterRow.getFooterHeight(zoomStage),
                        maxHeight: SheetFooterRow.getFooterHeight(zoomStage),
                        child: footerRow,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      );
    },
  );
}

/// Returns the effective display mode based on zoom stage and user preference.
/// Used for sheet view which adjusts display based on zoom level.
PaymentDisplayMode effectiveSheetDisplayMode(
  PaymentDisplayMode preference,
  GridZoomStage stage,
) {
  if (preference != PaymentDisplayMode.automatic) return preference;
  return switch (stage) {
    GridZoomStage.twoMonths => PaymentDisplayMode.full,
    GridZoomStage.fourMonths => PaymentDisplayMode.acronym,
    GridZoomStage.sixMonths => PaymentDisplayMode.icon,
  };
}

/// Converts MonthCardDisplayMode to PaymentDisplayMode.
/// Month card only supports full and acronym (no icon option).
PaymentDisplayMode monthCardDisplayModeToPaymentMode(MonthCardDisplayMode mode) {
  return switch (mode) {
    MonthCardDisplayMode.full => PaymentDisplayMode.full,
    MonthCardDisplayMode.acronym => PaymentDisplayMode.acronym,
  };
}

/// Converts MultiMonthDisplayMode to PaymentDisplayMode.
PaymentDisplayMode multiMonthDisplayModeToPaymentMode(MultiMonthDisplayMode mode) {
  return switch (mode) {
    MultiMonthDisplayMode.automatic => PaymentDisplayMode.automatic,
    MultiMonthDisplayMode.full => PaymentDisplayMode.full,
    MultiMonthDisplayMode.acronym => PaymentDisplayMode.acronym,
    MultiMonthDisplayMode.icon => PaymentDisplayMode.icon,
  };
}
