import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_actions.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Calculates the net change (in cents) that a planner item contributes to the balance
/// calculation for a given month.
///
/// Handles the complex logic for spending envelopes and the `useActualsForBalance` toggle.
int calculateItemNetChangeForMonth({
  required PlannerItem item,
  required DateTime month,
  required List<PaymentEntry> payments,
  required bool isCurrentPeriod,
  required PeriodInfo periodInfo,
  required AppSettingsStore settings,
}) {
  final amount = item.amountMinorUnits;

  if (isCurrentPeriod) {
    // Current Period Logic:
    // We are starting from the actual bank balance (currentBalanceCents).
    // This balance already reflects everything that has cleared (is in payments).
    
    bool isCleared = false;
    for (final p in payments) {
      if (paymentMatchesPlannerItem(p, item, month, settings, precomputedPeriodInfo: periodInfo)) {
        isCleared = true;
        break;
      }
    }

    // For envelopes, we ALWAYS use actual spend logic, ignoring the toggle.
    if (item.type == PaymentType.spendingEnvelope) {
      // "Use Actuals" mode (enforced):
      // We only care about what was spent. Since actual spending is already
      // reflected in the bank balance, we don't need to deduct anything further
      // from the projected balance.
      return 0;
    }

    // Standard items:
    // If it's cleared, it's already in the bank balance. Skip it.
    if (isCleared) return 0;
    // Otherwise, deduct it as it's expected to leave the bank later.
    return amount;
  } else {
    // Future/Other month logic:
    // We are projecting from a theoretical starting balance.
    
    // For envelopes, we ALWAYS use actual spend logic, ignoring the toggle.
    if (item.type == PaymentType.spendingEnvelope) {
      final period = SpendingEnvelopeService.getEnvelopePeriodDates(item, month);
      final spent = SpendingEnvelopeService.getSpentAmountForPeriod(item, payments, period);
      // spent is positive, so we negate it for consistency (envelopes are debits)
      return -spent;
    }

    // Standard items:
    // Deduct the full planned amount.
    return amount;
  }
}
