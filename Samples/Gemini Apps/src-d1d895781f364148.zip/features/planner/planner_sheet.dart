import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/payment_display.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/display_helpers.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/envelope_logic.dart';

typedef PaymentsForMonth = List<PaymentEntry> Function(DateTime month);

class PlannerSheet extends StatelessWidget {
  const PlannerSheet({
    super.key,
    required this.months,
    required this.items,
    required this.paymentsForMonth,
    required this.currency,
    required this.currentMonth,
    required this.showClearedForCurrentMonth,
    required this.recentlyClearedItemIds,
    required this.startingBalanceCents,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    this.showFooters = true,
    this.onMonthTapped,
  });

  final List<DateTime> months;
  final List<PlannerItem> items;
  final PaymentsForMonth paymentsForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final bool showClearedForCurrentMonth;
  final Set<String> recentlyClearedItemIds;
  final int startingBalanceCents;
  final GridZoomStage zoomStage;
  final PlannerSortOrder sortOrder;
  final DayFormat dayFormat;
  final PaymentDisplayMode displayMode;
  final AppSettingsStore settings;
  final bool showFooters;
  final void Function(DateTime month)? onMonthTapped;

  static const double _kDayWidth = 22;
  static const double _kLabelWidth = 70;
  static const double _kAmountWidth = 62;
  static const double _kRowHeight = 22;
  static const double _kColumnPadding = 6;

  static const double columnWidth = _kDayWidth + _kLabelWidth + _kAmountWidth + _kColumnPadding * 2;

  DateTime? _clearedDateFor(PlannerItem item, List<PaymentEntry> payments, DateTime month) {
    for (final payment in payments) {
      if (paymentMatchesPlannerItem(payment, item, month, settings)) return payment.date;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final rowHeight = _rowHeightForStage(zoomStage);
    final border = BorderSide.none;
    final width = months.length * columnWidth;
    final rowCount = items.length;
    // Account for potential group headers when grouping is enabled.
    // In the worst case, every item could be on a different day.
    final groupHeaderBuffer = settings.plannerGroupByDate ? 31 : 0;
    const footerRowCount = 3; // Start, End, End(C)
    final height = (rowCount + groupHeaderBuffer + 1 + footerRowCount + 1) * rowHeight;
    final normalizedCurrent = monthOnly(currentMonth);
    final currentIndex = months.indexWhere(
      (month) => monthOnly(month) == normalizedCurrent,
    );
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;

    // Cache payments and period info for each month to avoid redundant lookups/calculations
    final cachedPayments = List<List<PaymentEntry>>.filled(months.length, const []);
    final cachedPeriodInfos = List<PeriodInfo?>.filled(months.length, null);
    
    final monthTotals = <int>[];
    for (var i = 0; i < months.length; i++) {
        final month = months[i];
        final monthPayments = paymentsForMonth(month);
        cachedPayments[i] = monthPayments;
        
        final periodInfo = PaycheckService.getPeriodInfo(
          month,
          settings.viewPeriodMode,
          settings.paycheckDay,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        );
        cachedPeriodInfos[i] = periodInfo;

        final isCurrent = monthOnly(month) == normalizedCurrent;
        
        // Use a quicker lookup for totals calculation as well
        final paymentMap = buildPaymentLookupMap(monthPayments);
        
        final netChange = items.where((item) => item.shouldAppearInMonth(month)).fold<int>(0, (sum, item) {
            return sum + calculateItemNetChangeForMonth(
              item: item,
              month: month,
              payments: monthPayments,
              isCurrentPeriod: isCurrent,
              periodInfo: periodInfo,
              settings: settings,
            );
        });
        
        monthTotals.add(netChange);
    }

    // Calculate visible row count for each month to determine max for alignment
    final visibleRowCounts = <int>[];
    for (var i = 0; i < months.length; i++) {
      final month = months[i];
      final normalized = monthOnly(month);
      final isCurrent = normalized.year == currentMonth.year &&
          normalized.month == currentMonth.month;
      final showClearedForMonth = isCurrent ? showClearedForCurrentMonth : true;
      
      // Count visible items for this month
      var rowCount = 0;
      final monthPayments = cachedPayments[i];
      final periodInfo = cachedPeriodInfos[i]!;
      final paymentMap = buildPaymentLookupMap(monthPayments);
      
      for (final item in items.where((item) => item.shouldAppearInMonth(month))) {
        final isCleared = findPaymentWithMap(item: item, paymentMap: paymentMap, month: month, settings: settings, periodInfo: periodInfo) != null;
        if (!showClearedForMonth && isCleared && !recentlyClearedItemIds.contains(item.id) && item.type != PaymentType.spendingEnvelope) {
          continue;
        }
        rowCount++;
      }
      
      // Add group header count if grouping is enabled
      if (settings.plannerGroupByDate) {
        // Estimate group headers (worst case: one per unique day in visible items)
        // For simplicity, add a buffer based on visible items
        rowCount += (rowCount > 0 ? (rowCount ~/ 2) : 0);
      }
      
      visibleRowCounts.add(rowCount);
    }
    
    // Find maximum row count across all months for alignment
    final maxRowCount = visibleRowCounts.isEmpty 
        ? 0 
        : visibleRowCounts.reduce((a, b) => a > b ? a : b);

    final startBalances = List<int>.filled(months.length, 0);
    final cumulativeBalances = List<int>.filled(months.length, 0);
    
    var runningBalance = startingBalanceCents;
    
    for (var i = 0; i < months.length; i++) {
        if (i < baseIndex) {
            startBalances[i] = 0;
            cumulativeBalances[i] = monthTotals[i];
        } else if (i == baseIndex) {
            startBalances[i] = startingBalanceCents;
            cumulativeBalances[i] = startingBalanceCents + monthTotals[i];
            runningBalance = cumulativeBalances[i];
        } else {
            startBalances[i] = runningBalance;
            cumulativeBalances[i] = runningBalance + monthTotals[i];
            runningBalance = cumulativeBalances[i];
        }
    }

    return Material(
      color: Theme.of(context).colorScheme.surface,
      child: SizedBox(
        width: width,
        height: height,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (int i = 0; i < months.length; i++)
              MonthSheetColumn(
                month: months[i],
                items: items,
                payments: cachedPayments[i],
                periodInfo: cachedPeriodInfos[i]!,
                currency: currency,
                border: border,
                dayWidth: _kDayWidth,
                labelWidth: _kLabelWidth,
                amountWidth: _kAmountWidth,
                rowHeight: rowHeight,
                columnPadding: _kColumnPadding,
                isFirst: i == 0,
                showCleared: () {
                  final normalized = monthOnly(months[i]);
                  final isCurrent = normalized.year == currentMonth.year &&
                      normalized.month == currentMonth.month;
                  return isCurrent ? showClearedForCurrentMonth : true;
                }(),
                recentlyClearedItemIds: recentlyClearedItemIds,
                zoomStage: zoomStage,
                sortOrder: sortOrder,
                dayFormat: dayFormat,
                displayMode: displayMode,
                settings: settings,
                currentPeriodMonth: currentMonth,
                isFirstColumn: i == 0,
                startBalanceCents: startBalances[i],
                netTotalCents: monthTotals[i],
                cumulativeBalanceCents: cumulativeBalances[i],
                targetRowCount: maxRowCount,
                showFooters: showFooters,
                onTapped: onMonthTapped,
              ),
          ],
        ),
      ),
    );
  }

  // Using shared helpers from planner_actions.dart:
  // - buildPaymentLookupMap (replaces _buildPaymentMap)
  // - findPaymentWithMap (replaces _findPaymentWithMap)

  double _rowHeightForStage(GridZoomStage stage) {
    switch (stage) {
      case GridZoomStage.sixMonths:
        return 30;
      case GridZoomStage.fourMonths:
        return 26;
      case GridZoomStage.twoMonths:
        return _kRowHeight;
    }
  }
}

class MonthSheetColumn extends StatelessWidget {
  const MonthSheetColumn({super.key,
    required this.month,
    required this.items,
    required this.payments,
    required this.periodInfo,
    required this.currency,
    required this.border,
    required this.dayWidth,
    required this.labelWidth,
    required this.amountWidth,
    required this.rowHeight,
    required this.columnPadding,
    required this.isFirst,
    required this.showCleared,
    required this.recentlyClearedItemIds,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    required this.currentPeriodMonth,
    required this.isFirstColumn,
    required this.startBalanceCents,
    required this.netTotalCents,
    required this.cumulativeBalanceCents,
    required this.targetRowCount,
    this.showFooters = true,
    this.onTapped,
  });

  final DateTime month;
  final List<PlannerItem> items;
  final List<PaymentEntry> payments;
  final PeriodInfo periodInfo;
  final AppCurrency currency;
  final BorderSide border;
  final double dayWidth;
  final double labelWidth;
  final double amountWidth;
  final double rowHeight;
  final double columnPadding;
  final bool isFirst;
  final bool showCleared;
  final Set<String> recentlyClearedItemIds;
  final GridZoomStage zoomStage;
  final PlannerSortOrder sortOrder;
  final DayFormat dayFormat;
  final void Function(DateTime month)? onTapped;
  final PaymentDisplayMode displayMode;
  final AppSettingsStore settings;
  final DateTime currentPeriodMonth;
  final bool isFirstColumn;
  final int startBalanceCents;
  final int netTotalCents;
  final int cumulativeBalanceCents;
  final int targetRowCount;
  final bool showFooters;

  /// Builds the display label with optional company suffix.
  String _buildDisplayLabel(String baseLabel, PlannerItem item) {
    if (settings.plannerShowPaymentOrigin && item.company != null && item.company!.isNotEmpty) {
      return '$baseLabel (${item.company})';
    }
    return baseLabel;
  }

  @override
  Widget build(BuildContext context) {
    final monthNormalized = monthOnly(month);
    final isPast = monthNormalized.isBefore(currentPeriodMonth);
    final isCurrent = monthNormalized.year == currentPeriodMonth.year &&
        monthNormalized.month == currentPeriodMonth.month;
    
    // Use passed periodInfo instead of recalculating
    
    final rows = _buildRows(this.periodInfo);
    final headerLabel = settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured
        ? this.periodInfo.label
        : gridHeaderLabel(
            month,
            zoomStage,
            Localizations.localeOf(context),
          );

    final totalColumnWidth = dayWidth + labelWidth + amountWidth + columnPadding * 2;
    final dividerColor = Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3);

    final headerBackground = isPast
        ? Theme.of(context).colorScheme.surfaceContainerLow
        : Theme.of(context).colorScheme.surfaceContainerHighest;
    final headerStyle = Theme.of(context).textTheme.labelSmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 11,
          fontWeight: FontWeight.w600,
        );
    final dayStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 10,
        );
    final labelStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          fontSize: 10,
        );
    final amountStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 10,
        );
    final endLabel =
        settings.viewPeriodMode == ViewPeriodMode.paycheck ? 'EOP' : 'EOM';

    final content = Container(
      width: totalColumnWidth,
      decoration: BoxDecoration(
        color: isCurrent 
            ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.05)
            : null,
        border: Border(
          left: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : (isFirst ? BorderSide.none : BorderSide(color: dividerColor, width: 1)),
          top: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
          right: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
          bottom: isCurrent 
              ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)
              : BorderSide.none,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Container(
            width: totalColumnWidth,
            height: rowHeight,
            padding: EdgeInsets.symmetric(horizontal: columnPadding),
            decoration: BoxDecoration(
              color: headerBackground,
              border: Border(
                bottom: BorderSide(color: dividerColor, width: 1),
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              headerLabel,
              style: headerStyle,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Data rows (grouped or flat based on settings)
          ..._buildDataRows(
            context,
            rows: rows,
            isCurrent: isCurrent,
            totalColumnWidth: totalColumnWidth,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            dayWidth: dayWidth,
            amountWidth: amountWidth,
            dividerColor: dividerColor,
            dayStyle: dayStyle,
            labelStyle: labelStyle,
            amountStyle: amountStyle,
            periodInfo: this.periodInfo,
          ),
          // Spacer to push footers to bottom if column fills space
          const Spacer(),
          // Footer rows (conditionally shown - may be in fixed overlay instead)
          if (showFooters) ...[
            _FooterRow(
              label: 'Start',
              value: formatMoneyFromCents(startBalanceCents, currency, showCents: settings.showCents),
              valueColor: startBalanceCents < 0
                  ? settings.debitColor
                  : startBalanceCents > 0
                      ? settings.creditColor
                      : null,
              onTap: () {
                settings.plannerUseZeroBaseline = !settings.plannerUseZeroBaseline;
              },
              rowHeight: rowHeight,
              columnPadding: columnPadding,
              totalColumnWidth: totalColumnWidth,
              background: headerBackground,
              dividerColor: dividerColor,
            ),
            _FooterRow(
              label: endLabel,
              value: formatMoneyFromCents(netTotalCents, currency, showCents: settings.showCents),
              valueColor: netTotalCents < 0
                  ? settings.debitColor
                  : netTotalCents > 0
                      ? settings.creditColor
                      : null,
              rowHeight: rowHeight,
              columnPadding: columnPadding,
              totalColumnWidth: totalColumnWidth,
              background: headerBackground,
              dividerColor: dividerColor,
            ),
            _FooterRow(
              label: '$endLabel(C)',
              value: isFirstColumn
                  ? ''
                  : formatMoneyFromCents(cumulativeBalanceCents, currency, showCents: settings.showCents),
              valueColor: cumulativeBalanceCents < 0
                  ? settings.debitColor
                  : cumulativeBalanceCents > 0
                      ? settings.creditColor
                      : null,
              rowHeight: rowHeight,
              columnPadding: columnPadding,
              totalColumnWidth: totalColumnWidth,
              background: headerBackground,
              dividerColor: dividerColor,
            ),
          ],
        ],
      ),
    );

    // Tap to navigate to month view
    final tappable = GestureDetector(
      onLongPress: onTapped != null
          ? () {
              HapticFeedback.selectionClick();
              onTapped!(month);
            }
          : null,
      child: content,
    );

    if (!isPast) return tappable;
    return Opacity(opacity: 0.62, child: tappable);
  }

  List<Widget> _buildDataRows(
    BuildContext context, {
    required List<_SheetRow> rows,
    required bool isCurrent,
    required double totalColumnWidth,
    required double rowHeight,
    required double columnPadding,
    required double dayWidth,
    required double amountWidth,
    required Color dividerColor,
    required TextStyle? dayStyle,
    required TextStyle? labelStyle,
    required TextStyle? amountStyle,
    required PeriodInfo periodInfo,
  }) {
    if (!settings.plannerGroupByDate) {
      // Flat list - original behavior
      return rows.map((row) {
        return _buildRowWidget(
          context,
          row: row,
          isCurrent: isCurrent,
          totalColumnWidth: totalColumnWidth,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          dayWidth: dayWidth,
          amountWidth: amountWidth,
          dividerColor: dividerColor,
          dayStyle: dayStyle,
          labelStyle: labelStyle,
          amountStyle: amountStyle,
          showDay: true,
          isGroupStart: false,
        );
      }).toList();
    }

    // Grouped list - group by day with visual headers
    // We need to group by the actual day number for sorting, not the formatted string
    final groups = <int, List<_SheetRow>>{};
    for (final row in rows) {
      // Parse day number from formatted string or use item's dayOfMonth
      final dayNum = effectiveDayOfMonth(row.item.dayOfMonth, month);
      (groups[dayNum] ??= []).add(row);
    }

    // Sort groups using the same logic as item sorting (handles paycheck mode correctly)
    final sortedDays = groups.keys.toList();
    sortedDays.sort((a, b) {
      final aSortValue = daySortValue(a, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      final bSortValue = daySortValue(b, viewMode: settings.viewPeriodMode, periodInfo: periodInfo);
      // Apply sort order (chronological or reverse)
      return sortOrder == PlannerSortOrder.chronological
          ? aSortValue.compareTo(bSortValue)
          : bSortValue.compareTo(aSortValue);
    });

    final widgets = <Widget>[];
    for (int groupIdx = 0; groupIdx < sortedDays.length; groupIdx++) {
      final day = sortedDays[groupIdx];
      final groupItems = groups[day]!;
      final hasMultipleItems = groupItems.length > 1;

      // Only show group header if there are multiple items on this day
      if (hasMultipleItems) {
        // Add a compact group header row
        widgets.add(
          Container(
            width: totalColumnWidth,
            height: rowHeight * 0.7,
            padding: EdgeInsets.symmetric(horizontal: columnPadding),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
              border: Border(
                bottom: BorderSide(
                  color: dividerColor.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Text(
                  formatDayOfMonth(day, dayFormat),
                  style: dayStyle?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 9,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Container(
                    height: 0.5,
                    color: dividerColor.withValues(alpha: 0.3),
                  ),
                ),
              ],
            ),
          ),
        );

        // Add items in this group (without day column since header shows it)
        for (final row in groupItems) {
          widgets.add(
            _buildRowWidget(
              context,
              row: row,
              isCurrent: isCurrent,
              totalColumnWidth: totalColumnWidth,
              rowHeight: rowHeight,
              columnPadding: columnPadding,
              dayWidth: dayWidth,
              amountWidth: amountWidth,
              dividerColor: dividerColor,
              dayStyle: dayStyle,
              labelStyle: labelStyle,
              amountStyle: amountStyle,
              showDay: false,
              isGroupStart: false,
            ),
          );
        }
      } else {
        // Single item - show inline with day (like flat view)
        widgets.add(
          _buildRowWidget(
            context,
            row: groupItems.first,
            isCurrent: isCurrent,
            totalColumnWidth: totalColumnWidth,
            rowHeight: rowHeight,
            columnPadding: columnPadding,
            dayWidth: dayWidth,
            amountWidth: amountWidth,
            dividerColor: dividerColor,
            dayStyle: dayStyle,
            labelStyle: labelStyle,
            amountStyle: amountStyle,
            showDay: true,
            isGroupStart: false,
          ),
        );
      }
    }

    return widgets;
  }

  Widget _buildRowWidget(
    BuildContext context, {
    required _SheetRow row,
    required bool isCurrent,
    required double totalColumnWidth,
    required double rowHeight,
    required double columnPadding,
    required double dayWidth,
    required double amountWidth,
    required Color dividerColor,
    required TextStyle? dayStyle,
    required TextStyle? labelStyle,
    required TextStyle? amountStyle,
    required bool showDay,
    required bool isGroupStart,
  }) {
    return Opacity(
      opacity: (row.isCleared && isCurrent) ? 0.5 : 1.0,
      child: Container(
        width: totalColumnWidth,
        height: rowHeight,
        padding: EdgeInsets.symmetric(horizontal: columnPadding),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: dividerColor.withValues(alpha: 0.15),
              width: 0.5,
            ),
          ),
        ),
        child: Row(
          children: [
            // Day (only if showDay is true)
            if (showDay)
              SizedBox(
                width: dayWidth,
                child: Text(
                  row.day,
                  style: dayStyle,
                  textAlign: TextAlign.left,
                ),
              ),
            // Label - use Expanded to prevent overflow
            Expanded(
              child: displayMode == PaymentDisplayMode.icon
                  ? Icon(
                      getPaymentIcon(row.label, type: row.item.type),
                      size: 14,
                      color: (row.isCleared && isCurrent)
                          ? Theme.of(context).colorScheme.onSurfaceVariant
                          : Theme.of(context).colorScheme.onSurface,
                    )
                  : displayMode == PaymentDisplayMode.acronym
                      ? Text(
                          _buildDisplayLabel(generateAcronym(row.label), row.item),
                          maxLines: 1,
                          overflow: TextOverflow.clip,
                          style: labelStyle?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: (row.isCleared && isCurrent)
                                ? Theme.of(context).colorScheme.onSurfaceVariant
                                : Theme.of(context).colorScheme.onSurface,
                          ),
                        )
                      : Text(
                          _buildDisplayLabel(row.label, row.item),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: (row.isCleared && isCurrent)
                              ? labelStyle?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                )
                              : labelStyle,
                        ),
            ),
            // Amount
            SizedBox(
              width: amountWidth,
              child: Text(
                formatMoneyFromCents(row.amountMinorUnits, currency, showCents: settings.showCents),
                textAlign: TextAlign.right,
                style: amountStyle?.copyWith(
                  color: row.item.type.isIncomeType
                      ? settings.creditColor
                      : settings.debitColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<_SheetRow> _buildRows(PeriodInfo periodInfo) {
    // Build a fast lookup map for payments
    final paymentMap = <String, List<PaymentEntry>>{};
    final fuzzyCandidates = <PaymentEntry>[];
    for (final payment in payments) {
      if (payment.plannerItemId != null) {
        (paymentMap[payment.plannerItemId!] ??= []).add(payment);
      } else {
        fuzzyCandidates.add(payment);
      }
    }

    PaymentEntry? paymentFor(PlannerItem item) {
      // Check explicit matches first (O(1) lookup + small iteration)
      final explicitMatches = paymentMap[item.id];
      PaymentEntry? best;
      
      if (explicitMatches != null) {
        for (final payment in explicitMatches) {
          if (!paymentMatchesPlannerItem(payment, item, month, settings, precomputedPeriodInfo: periodInfo)) continue;
          if (best == null || payment.date.isAfter(best.date)) best = payment;
        }
      }

      // If no explicit match found, check fuzzy candidates
      // Note: If distinct items, we might want to check fuzzy even if explicit found? 
      // Current logic assumes if explicit exists, we use it? No, existing logic checked ALL.
      // But typically explicit is better. 
      // The original code checked ALL payments and found the 'best' (by date).
      // However, it's highly unlikely one item has both explicit and fuzzy matches in same month.
      // Safe optimization: check fuzzy only if no best yet, OR if we want to be 100% equivalent (check both).
      // Given performance goals, let's assume explicit links take precedence or at least are sufficient if found.
      // But to be safe and match `paymentMatchesPlannerItem` logic (which prioritizes explicit),
      // we should still check fuzzy.
      
      if (fuzzyCandidates.isNotEmpty) {
          for (final payment in fuzzyCandidates) {
            if (!paymentMatchesPlannerItem(payment, item, month, settings, precomputedPeriodInfo: periodInfo)) continue;
             if (best == null || payment.date.isAfter(best.date)) best = payment;
          }
      }
      
      return best;
    }

    final rows = <_SheetRow>[];
    // Filter items to only those that should appear in this month
    final monthItems = items.where((item) => item.shouldAppearInMonth(month)).toList(growable: false);
    final sortedItems = orderedPlannerItems(
      monthItems,
      sortOrder,
      dateSortMode: settings.plannerDateSortMode,
      viewMode: settings.viewPeriodMode,
      periodInfo: periodInfo,
      actualDateProvider: (item) => paymentFor(item)?.date,
    );
    for (final item in sortedItems) {
      final payment = paymentFor(item);
      final displayValues = getDisplayValues(
        item: item,
        month: month,
        payment: payment,
      );
      final isCleared = payment != null;
      if (!showCleared &&
          isCleared &&
          !recentlyClearedItemIds.contains(item.id) &&
          item.type != PaymentType.spendingEnvelope) {
        continue;
      }
      rows.add(
        _SheetRow(
          day: item.type == PaymentType.spendingEnvelope 
              ? '—' 
              : formatDayOfMonth(displayValues.date.day, dayFormat),
          label: item.label,
          amountMinorUnits: displayValues.amountMinorUnits,
          isCleared: isCleared,
          item: item,
        ),
      );
    }
    return rows;
  }
}

class _SheetRow {
  const _SheetRow({
    required this.day,
    required this.label,
    required this.amountMinorUnits,
    required this.isCleared,
    required this.item,
  });

  final String day;
  final String label;
  final int amountMinorUnits;
  final bool isCleared;
  final PlannerItem item;
}

class _FooterRow extends StatelessWidget {
  const _FooterRow({
    required this.label,
    required this.value,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    this.valueColor,
    this.onTap,
  });

  final String label;
  final String value;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final Color? valueColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.labelSmall?.copyWith(
          fontFeatures: const [FontFeature.tabularFigures()],
          fontSize: 11,
          fontWeight: FontWeight.w600,
        );

    Widget row = Container(
      width: totalColumnWidth,
      height: rowHeight,
      padding: EdgeInsets.symmetric(horizontal: columnPadding),
      decoration: BoxDecoration(
        color: background,
        border: Border(
          top: BorderSide(color: dividerColor, width: 1),
        ),
      ),
      child: Row(
        children: [
          // Fixed-width label for consistent alignment
          SizedBox(
            width: 50,
            child: Text(
              label,
              style: style,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Right-aligned value takes remaining space
          Expanded(
            child: Text(
              value,
              style: style?.copyWith(color: valueColor),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: row,
        ),
      );
    }
    return row;
  }
}

/// A fixed footer row widget that displays Start, End, and End(C) values for all months.
/// This is used as a fixed overlay at the bottom of the sheet view.
class SheetFooterRow extends StatelessWidget {
  const SheetFooterRow({
    super.key,
    required this.months,
    required this.items,
    required this.paymentsForMonth,
    required this.currency,
    required this.currentMonth,
    required this.startingBalanceCents,
    required this.zoomStage,
    required this.settings,
  });

  final List<DateTime> months;
  final List<PlannerItem> items;
  final PaymentsForMonth paymentsForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final int startingBalanceCents;
  final GridZoomStage zoomStage;
  final AppSettingsStore settings;

  static const double _kDayWidth = 22;
  static const double _kLabelWidth = 70;
  static const double _kAmountWidth = 62;
  static const double _kRowHeight = 22;
  static const double _kColumnPadding = 6;
  static const double columnWidth = _kDayWidth + _kLabelWidth + _kAmountWidth + _kColumnPadding * 2;

  static double getRowHeight(GridZoomStage stage) {
    switch (stage) {
      case GridZoomStage.sixMonths:
        return 30;
      case GridZoomStage.fourMonths:
        return 26;
      case GridZoomStage.twoMonths:
        return _kRowHeight;
    }
  }

  static double getFooterHeight(GridZoomStage stage) => getRowHeight(stage) * 5;

  @override
  Widget build(BuildContext context) {
    final rowHeight = getRowHeight(zoomStage);
    final normalizedCurrent = monthOnly(currentMonth);
    final currentIndex = months.indexWhere(
      (month) => monthOnly(month) == normalizedCurrent,
    );
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;

    // Calculate totals for each month (same logic as PlannerSheet)
    final monthNetChanges = <int>[];
    final monthCredits = <int>[];
    final monthDebits = <int>[];

    for (var i = 0; i < months.length; i++) {
      final month = months[i];
      final monthPayments = paymentsForMonth(month);
      final isCurrent = monthOnly(month) == normalizedCurrent;
      
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      
      // Use optimized lookup map like PlannerSheet
      final paymentMap = <String, List<PaymentEntry>>{};
      for (final payment in monthPayments) {
        if (payment.plannerItemId != null) {
          (paymentMap[payment.plannerItemId!] ??= []).add(payment);
        } else {
          (paymentMap[''] ??= []).add(payment);
        }
      }

      var credits = 0;
      var debits = 0;
      var netChange = 0;

      final monthItems = items.where((item) => item.shouldAppearInMonth(month));
      for (final item in monthItems) {
          final itemChange = calculateItemNetChangeForMonth(
            item: item,
            month: month,
            payments: monthPayments,
            isCurrentPeriod: isCurrent,
            periodInfo: periodInfo,
            settings: settings,
          );

          if (itemChange > 0) {
            credits += itemChange;
          } else {
            debits += itemChange;
          }
          netChange += itemChange;
      }
      
      monthNetChanges.add(netChange);
      monthCredits.add(credits);
      monthDebits.add(debits);
    }

    final startBalances = List<int>.filled(months.length, 0);
    final cumulativeBalances = List<int>.filled(months.length, 0);
    
    var runningBalance = startingBalanceCents;
    
    for (var i = 0; i < months.length; i++) {
      if (i < baseIndex) {
        startBalances[i] = 0;
        cumulativeBalances[i] = monthNetChanges[i];
      } else if (i == baseIndex) {
        startBalances[i] = startingBalanceCents;
        cumulativeBalances[i] = startingBalanceCents + monthNetChanges[i];
        runningBalance = cumulativeBalances[i];
      } else {
        startBalances[i] = runningBalance;
        cumulativeBalances[i] = runningBalance + monthNetChanges[i];
        runningBalance = cumulativeBalances[i];
      }
    }

    final width = months.length * columnWidth;
    final endLabel = settings.viewPeriodMode == ViewPeriodMode.paycheck ? 'EOP' : 'EOM';
    final headerBackground = Theme.of(context).colorScheme.surfaceContainerHighest;
    final dividerColor = Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3);

    return Material(
      color: headerBackground,
      elevation: 4,
      child: SizedBox(
        width: width,
        height: getFooterHeight(zoomStage),
        child: Row(
          children: [
            for (int i = 0; i < months.length; i++)
              _FooterColumn(
                isFirstColumn: i == 0,
                startBalanceCents: startBalances[i],
                creditsCents: monthCredits[i],
                debitsCents: monthDebits[i],
                cumulativeBalanceCents: cumulativeBalances[i],
                endLabel: endLabel,
                rowHeight: rowHeight,
                columnPadding: _kColumnPadding,
                totalColumnWidth: columnWidth,
                background: headerBackground,
                dividerColor: dividerColor,
                currency: currency,
                settings: settings,
              ),
          ],
        ),
      ),
    );
  }
}

/// A single column of footer rows (Start, End, End(C)) for one month.
class _FooterColumn extends StatelessWidget {
  const _FooterColumn({
    required this.isFirstColumn,
    required this.startBalanceCents,
    required this.creditsCents,
    required this.debitsCents,
    required this.cumulativeBalanceCents,
    required this.endLabel,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    required this.currency,
    required this.settings,
  });

  final bool isFirstColumn;
  final int startBalanceCents;
  final int creditsCents;
  final int debitsCents;
  final int cumulativeBalanceCents;
  final String endLabel;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final AppCurrency currency;
  final AppSettingsStore settings;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _FooterRow(
          label: 'Start',
          value: formatMoneyFromCents(startBalanceCents, currency, showCents: settings.showCents),
          valueColor: startBalanceCents < 0
              ? settings.debitColor
              : startBalanceCents > 0
                  ? settings.creditColor
                  : null,
          onTap: () {
            settings.plannerUseZeroBaseline = !settings.plannerUseZeroBaseline;
          },
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          label: 'Credits',
          value: formatMoneyFromCents(creditsCents, currency, showCents: settings.showCents),
          valueColor: settings.creditColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          label: 'Debits',
          value: formatMoneyFromCents(debitsCents, currency, showCents: settings.showCents),
          valueColor: settings.debitColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          label: endLabel,
          value: formatMoneyFromCents(startBalanceCents + creditsCents + debitsCents, currency, showCents: settings.showCents),
          valueColor: (startBalanceCents + creditsCents + debitsCents) < 0
              ? settings.debitColor
              : (startBalanceCents + creditsCents + debitsCents) > 0
                  ? settings.creditColor
                  : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          label: '$endLabel(C)',
          value: isFirstColumn
              ? ''
              : formatMoneyFromCents(cumulativeBalanceCents, currency, showCents: settings.showCents),
          valueColor: cumulativeBalanceCents < 0
              ? settings.debitColor
              : cumulativeBalanceCents > 0
                  ? settings.creditColor
                  : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
      ],
    );
  }
}
