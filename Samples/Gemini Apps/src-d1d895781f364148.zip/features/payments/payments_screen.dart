import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_actions.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_transaction_sheet.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart'; // [NEW]
import 'package:expense_stalker_mobile/src/widgets/update_payment_sheet.dart';

class PaymentsListItem {
  final PlannerItem? plannerItem;
  final PaymentEntry? standalonePayment;

  PaymentsListItem.fromPlannerItem(this.plannerItem) : standalonePayment = null;
  PaymentsListItem.fromStandalonePayment(this.standalonePayment) : plannerItem = null;

  bool get isPlannerItem => plannerItem != null;
  String get label => plannerItem?.label ?? standalonePayment!.label;
  int get amountMinorUnits => plannerItem?.amountMinorUnits ?? standalonePayment!.amountMinorUnits;
  PaymentType get type => plannerItem?.type ?? standalonePayment!.type;
  String? get category => plannerItem?.category ?? standalonePayment!.category;
  String? get company => plannerItem?.company ?? standalonePayment!.company;
  String? get notes => plannerItem?.notes ?? standalonePayment!.notes;

  bool get archived => plannerItem?.archived ?? false;
  String get id => plannerItem?.id.value ?? standalonePayment!.id.value;

  int? get remainingBalanceMinorUnits => plannerItem?.remainingBalanceMinorUnits;
  AppCurrency? get balanceCurrency => plannerItem?.balanceCurrency;
  DateTime? calculateFinalPaymentDate() => plannerItem?.calculateFinalPaymentDate();
}

class _FilterChipData {
  final String label;
  final PaymentsFilterType type;
  _FilterChipData(this.label, this.type);
}

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  static const _pageSize = AppConstants.pageSizeDefault; // render 50 items at a time

  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  int _loadedCount = _pageSize;
  
  // Memoization for expensive filtering/grouping operations
  List<PaymentsListItem>? _cachedFilteredItems;
  String? _cachedFilterKey;
  Map<String, List<PaymentsListItem>>? _cachedGroupedItems;
  String? _cachedGroupKey;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text.trim().toLowerCase();
    });
  }

  @override
  void dispose() {

    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final maxScroll = _scrollController.position.maxScrollExtent;
    final current = _scrollController.position.pixels;
    if (current >= (maxScroll - AppConstants.scrollThresholdNormal)) {
      setState(() {
        _loadedCount += _pageSize;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    return Scaffold(
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
        return ListenableBuilder(
          listenable: settings,
          builder: (context, _) {
        
         // Generate cache key from filter state
         final filterKey = '${_searchQuery}|${settings.paymentsFilterType}|${settings.paymentsFilterCategory}|${settings.paymentsShowArchived}|${store.plannerItems.length}|${store.payments.length}';
         
         // Use cached filtered items if key matches
         List<PaymentsListItem> filteredItems;
         if (_cachedFilteredItems != null && _cachedFilterKey == filterKey) {
           filteredItems = _cachedFilteredItems!;
         } else {
           filteredItems = _filterItems(store.plannerItems, store.payments, settings);
           _sortItems(filteredItems, settings, store.payments);
           _cachedFilteredItems = filteredItems;
           _cachedFilterKey = filterKey;
         }
         
            final showMore = filteredItems.length > _loadedCount;
            final displayCount = showMore ? _loadedCount : filteredItems.length;

            // Generate cache key for grouping
            final groupKey = '${filterKey}|${settings.paymentsGroupBy}';
            
            // Use cached grouped items if key matches
            Map<String, List<PaymentsListItem>> groupedItems;
            if (_cachedGroupedItems != null && _cachedGroupKey == groupKey) {
              groupedItems = _cachedGroupedItems!;
            } else {
              groupedItems = _groupItems(filteredItems, settings, store.payments);
              _cachedGroupedItems = groupedItems;
              _cachedGroupKey = groupKey;
            }

            return Stack(
              children: [
                Positioned.fill(
                  child: SafeArea(
                  child: CustomScrollView(
                    controller: _scrollController,
                    slivers: [
                      SliverAppBar(
                        pinned: true,
                        title: Text(Terminology.of(context).listTabLabel),
                        actions: [
                          IconButton(
                            tooltip: AppLocalizations.of(context)!.optionsTitle,
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const OptionsScreen(),
                                ),
                              );
                            },
                            icon: PhosphorIcon(PhosphorIcons.gear()),
                          ),
                        ],
                      ),
                      // Filter chips
                      SliverToBoxAdapter(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Search Bar
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                              child: TextField(
                                controller: _searchController,
                                decoration: InputDecoration(
                                  hintText: 'Search payments...',
                                  prefixIcon: const Icon(Icons.search, size: 20),
                                  // Add clear button
                                  suffixIcon: _searchQuery.isNotEmpty
                                      ? IconButton(
                                          icon: const Icon(Icons.clear, size: 18),
                                          onPressed: () {
                                            _searchController.clear();
                                            // FocusScope.of(context).unfocus(); // Optional: keep focus or not
                                          },
                                        )
                                      : null,
                                  isDense: true,
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                                    borderSide: BorderSide(
                                      color: Theme.of(context).colorScheme.outlineVariant,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                                    borderSide: BorderSide(
                                      color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.5),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                                    borderSide: BorderSide(
                                      color: Theme.of(context).colorScheme.primary,
                                      width: 1.5,
                                    ),
                                  ),
                                  filled: true,
                                  fillColor: Theme.of(context).colorScheme.surfaceContainerLowest,
                                ),
                              ),
                            ),

                            // Filter & Group Options
                             Padding(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    clipBehavior: Clip.none,
                                    child: Row(
                                      children: [
                                         // Show Archived Toggle
                                        InkWell(
                                          onTap: () => settings.paymentsShowArchived = !settings.paymentsShowArchived,
                                          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                                          child: AnimatedContainer(
                                            duration: const Duration(milliseconds: 200),
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                            decoration: BoxDecoration(
                                              color: settings.paymentsShowArchived
                                                  ? Theme.of(context).colorScheme.secondaryContainer
                                                  : Colors.transparent,
                                              borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                                              border: Border.all(
                                                color: settings.paymentsShowArchived
                                                    ? Theme.of(context).colorScheme.secondary
                                                    : Theme.of(context).colorScheme.outlineVariant,
                                                width: 1,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(
                                                  settings.paymentsShowArchived ? Icons.visibility : Icons.visibility_off,
                                                  size: 14,
                                                  color: settings.paymentsShowArchived 
                                                    ? Theme.of(context).colorScheme.onSecondaryContainer 
                                                    : Theme.of(context).colorScheme.onSurfaceVariant,
                                                ),
                                                const SizedBox(width: 6),
                                                Text(
                                                  AppLocalizations.of(context)!.showArchived,
                                                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                                        color: settings.paymentsShowArchived 
                                                            ? Theme.of(context).colorScheme.onSecondaryContainer
                                                            : Theme.of(context).colorScheme.onSurfaceVariant,
                                                        fontWeight: FontWeight.w600,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        
                                        const SizedBox(width: 8),
                                        Container(
                                          width: 1, 
                                          height: 20, 
                                          color: Theme.of(context).colorScheme.outlineVariant,
                                        ),
                                        const SizedBox(width: 8),

                                        // Filter Chips (Scrollable Row)
                                        ...[
                                          createFilterChipData('All', PaymentsFilterType.all),
                                          createFilterChipData('Income', PaymentsFilterType.income),
                                          createFilterChipData('Expenses', PaymentsFilterType.expenses),
                                          createFilterChipData('Debt', PaymentsFilterType.debt),
                                          createFilterChipData(
                                            settings.paymentsFilterType == PaymentsFilterType.category && settings.paymentsFilterCategory != null
                                              ? 'Category: ${settings.paymentsFilterCategory}'
                                              : 'Category',
                                            PaymentsFilterType.category
                                          ), // Special case handled logic below
                                          createFilterChipData('Recurring', PaymentsFilterType.recurring),
                                          createFilterChipData('One-off', PaymentsFilterType.oneOff),
                                        ].map((data) => Padding(
                                          padding: const EdgeInsets.only(right: 8),
                                          child: _buildFilterChip(
                                            context,
                                            label: data.label,
                                            selected: settings.paymentsFilterType == data.type,
                                            onSelected: () {
                                              if (data.type == PaymentsFilterType.category) {
                                                  if (settings.paymentsFilterType == PaymentsFilterType.category) {
                                                    _showCategoryFilterDialog(context, settings, store);
                                                  } else {
                                                    if (settings.paymentsFilterCategory == null) {
                                                      _showCategoryFilterDialog(context, settings, store);
                                                    } else {
                                                      settings.paymentsFilterType = PaymentsFilterType.category;
                                                    }
                                                  }
                                              } else {
                                                settings.paymentsFilterType = data.type;
                                              }
                                            },
                                          ),
                                        )),
                                      ],
                                    ),
                                  ),
                                  
                                  const SizedBox(height: 12),
                                  
                                  // Group By Chips
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    clipBehavior: Clip.none,
                                    child: Row(
                                      children: [
                                        Text(
                                          'Group by:',
                                          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        ...[
                                          PaymentsGroupBy.none, // Added None option explicitly? Or just unselect?
                                          PaymentsGroupBy.category,
                                          PaymentsGroupBy.type,
                                          PaymentsGroupBy.company,
                                          PaymentsGroupBy.dueDate,
                                        ].where((g) => g != PaymentsGroupBy.none).map((group) { // Filter none for now, handle logic
                                          final isSelected = settings.paymentsGroupBy == group;
                                          return Padding(
                                            padding: const EdgeInsets.only(right: 8),
                                            child: _buildGroupChip(
                                              context,
                                              label: group == PaymentsGroupBy.dueDate ? 'Due Date' : group.name[0].toUpperCase() + group.name.substring(1),
                                              selected: isSelected,
                                              onSelected: () {
                                                 settings.paymentsGroupBy = isSelected ? PaymentsGroupBy.none : group;
                                              },
                                            ),
                                          );
                                        }),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                  const SliverToBoxAdapter(child: Divider(height: 1)),
                  // Items list
                  if (filteredItems.isEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 32, 16, 32),
                        child: Center(
                          child: Text(
                            settings.paymentsFilterType != PaymentsFilterType.all
                                ? 'No items match the current filter'
                                : Terminology.of(context).noItemsMessage,
                          ),
                        ),
                      ),
                    )
                  else
                    _buildItemsList(context, groupedItems, displayCount, showMore, settings, store),
                  // Extra height for FAB clearance (56 + 16 padding)
                  const SliverToBoxAdapter(child: SizedBox(height: AppConstants.appBarExtendedHeight + 72)),
                ],
              ),
            ),
          ),
          Positioned(
                  right: 16,
                  bottom: 16,
                  child: FloatingActionButton(
                    onPressed: () => _showAddMenu(context),
                    child: PhosphorIcon(PhosphorIcons.plus()),
                  ),
                ),
              ],
            );
          },
        );
        },
      ),
    );
  }



  Widget _buildFilterChip(
    BuildContext context, {
    required String label,
    required bool selected,
    required VoidCallback onSelected,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return InkWell(
      onTap: onSelected,
      borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected 
              ? colorScheme.primaryContainer.withValues(alpha: 0.3)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          border: Border.all(
            color: selected 
                ? colorScheme.primary.withValues(alpha: 0.5) 
                : colorScheme.outlineVariant,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (selected) ...[
              PhosphorIcon(
                PhosphorIcons.check(), 
                size: 12, 
                color: colorScheme.primary,
              ),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(
                color: selected ? colorScheme.primary : colorScheme.onSurfaceVariant,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<PaymentsListItem> _filterItems(List<PlannerItem> items, List<PaymentEntry> payments, AppSettingsStore settings) {
    // Combine all items into a single list
    final allItems = <PaymentsListItem>[
      ...items.map((i) => PaymentsListItem.fromPlannerItem(i)),
      ...payments.map((p) => PaymentsListItem.fromStandalonePayment(p)),
    ];

    if (allItems.isEmpty) return [];

    return allItems.where((item) {
      // 1. Filter by Search Query
      if (_searchQuery.isNotEmpty) {
        final matchesLabel = item.label.toLowerCase().contains(_searchQuery);
        final matchesCategory = item.category?.toLowerCase().contains(_searchQuery) ?? false;
        final matchesCompany = item.company?.toLowerCase().contains(_searchQuery) ?? false;
        final matchesNotes = item.notes?.toLowerCase().contains(_searchQuery) ?? false;
        
        if (!matchesLabel && !matchesCategory && !matchesCompany && !matchesNotes) {
          return false;
        }
      }

      // 2. Filter by Archived
      if (!settings.paymentsShowArchived && item.archived) {
        return false;
      }
      
      // 3. Filter by Type
      switch (settings.paymentsFilterType) {
        case PaymentsFilterType.all:
          return true;
        case PaymentsFilterType.category:
          if (settings.paymentsFilterCategory == null) return true;
          return item.category == settings.paymentsFilterCategory;
        case PaymentsFilterType.income:
          return item.type.isIncomeType;
        case PaymentsFilterType.expenses:
          return !item.type.isIncomeType && item.type != PaymentType.debt;
        case PaymentsFilterType.debt:
          return item.type == PaymentType.debt;
        case PaymentsFilterType.oneOff:
          return item.type == PaymentType.oneOff || item.type == PaymentType.oneOffIncome;
        case PaymentsFilterType.recurring:
          return item.type == PaymentType.recurring || item.type == PaymentType.recurringIncome || item.type == PaymentType.spendingEnvelope;
      }
    }).toList();
  }

  _FilterChipData createFilterChipData(String label, PaymentsFilterType type) {
    return _FilterChipData(label, type);
  }

  Widget _buildGroupChip(
    BuildContext context, {
    required String label,
    required bool selected,
    required VoidCallback onSelected,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return InkWell(
      onTap: onSelected,
      borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected 
              ? colorScheme.secondaryContainer 
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          border: Border.all(
            color: selected 
                ? colorScheme.secondary 
                : colorScheme.outlineVariant,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            color: selected ? colorScheme.onSecondaryContainer : colorScheme.onSurfaceVariant,
            fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }


  void _sortItems(
    List<PaymentsListItem> items, 
    AppSettingsStore settings, 
    List<PaymentEntry> payments,
  ) {
    items.sort((a, b) {
      final dateA = _getItemDate(a, payments, settings);
      final dateB = _getItemDate(b, payments, settings);
      
      if (dateA == null && dateB == null) return 0;
      if (dateA == null) return 1; // Put nulls at end
      if (dateB == null) return -1;
      
      final comparison = dateA.compareTo(dateB);
      // Default to ascending (oldest to newest) unless reverse specified
      return settings.plannerSortOrder == PlannerSortOrder.reverseChronological
          ? -comparison
          : comparison; 
    });
  }

  DateTime? _getItemDate(
    PaymentsListItem item, 
    List<PaymentEntry> payments, 
    AppSettingsStore settings,
  ) {
    if (item.isPlannerItem) {
      if (item.plannerItem == null) return null;
      // Fallback to startDate if no next due date (e.g. ended one-off)
      return _nextDueDate(
        item: item.plannerItem!, 
        payments: payments, 
        settings: settings,
      ) ?? item.plannerItem!.startDate;
    } else {
      return item.standalonePayment?.date;
    }
  }

  Future<void> _showCategoryFilterDialog(
    BuildContext context,
    AppSettingsStore settings,
    ExpenseStore store,
  ) async {
    final suggestions = getCategorySuggestions(
      isIncome: false, // Show expenses by default or merge
      mode: CategoryPresetMode.both,
      userCategories: [
        ...store.currentAccount.customExpenseCategories,
        ...store.currentAccount.customIncomeCategories,
      ],
    );
    // Merge all potential categories
    final allCategories = <String>{
      ...incomeCategories,
      ...expenseCategories,
      ...store.currentAccount.customExpenseCategories,
      ...store.currentAccount.customIncomeCategories,
    }.toList()..sort();

    final selected = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Select Category'),
        children: [
           SimpleDialogOption(
            onPressed: () => Navigator.pop(context, ''), // Clear/All
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('All Categories (Clear Filter)', style: TextStyle(fontStyle: FontStyle.italic)),
            ),
          ),
          const Divider(),
          SizedBox(
            width: double.maxFinite,
            height: 300,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: allCategories.length,
              itemBuilder: (context, index) {
                final cat = allCategories[index];
                return SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, cat),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(cat),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );

    if (selected != null) {
      if (selected.isEmpty) {
         settings.paymentsFilterCategory = null;
         settings.paymentsFilterType = PaymentsFilterType.all;
      } else {
        settings.paymentsFilterCategory = selected;
        settings.paymentsFilterType = PaymentsFilterType.category;
      }
    }
  }

  Map<String, List<PaymentsListItem>> _groupItems(
    List<PaymentsListItem> items,
    AppSettingsStore settings,
    List<PaymentEntry> payments,
  ) {
    if (settings.paymentsGroupBy == PaymentsGroupBy.none) {
      return {'': items};
    }

    final Map<String, List<PaymentsListItem>> groups = {};

    for (final item in items) {
      String groupKey;
      switch (settings.paymentsGroupBy) {
        case PaymentsGroupBy.none:
          groupKey = '';
          break;
        case PaymentsGroupBy.category:
          groupKey = item.category ?? 'Uncategorized';
          break;
        case PaymentsGroupBy.type:
          groupKey = item.type.label;
          break;
        case PaymentsGroupBy.company:
          groupKey = item.company ?? 'No Company';
          break;
        case PaymentsGroupBy.dueDate:
          if (item.isPlannerItem) {
             final nextDue = _nextDueDate(item: item.plannerItem!, payments: payments, settings: settings);
             if (nextDue == null) {
               groupKey = 'No Due Date';
             } else {
               groupKey = _formatDueDate(nextDue);
             }
          } else {
             // Standalone payment
             groupKey = _formatDueDate(item.standalonePayment!.date);
          }
          break;
      }

      (groups[groupKey] ??= []).add(item);
    }

    return groups;
  }

  Widget _buildItemsList(
    BuildContext context,
    Map<String, List<PaymentsListItem>> groupedItems,
    int displayCount,
    bool showMore,
    AppSettingsStore settings,
    ExpenseStore store,
  ) {
    if (settings.paymentsGroupBy == PaymentsGroupBy.none) {
      // Flat list (no grouping)
      final items = groupedItems['']!;
      return SliverList.separated(
        itemCount: displayCount + (showMore ? 1 : 0),
        separatorBuilder: (_, __) => const SizedBox.shrink(),
        itemBuilder: (context, index) {
          if (showMore && index == displayCount) {
             return Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: TextButton(
                  onPressed: () => setState(() => _loadedCount += _pageSize),
                  child: Text(AppLocalizations.of(context)!.showMore),
                ),
              ),
            );
          }
          return _buildItemTile(context, items[index], settings, store);
        },
      );
    }

    // Grouped list
    final sortedGroups = groupedItems.keys.toList()..sort();
    final widgets = <Widget>[];
    int itemCount = 0;

    for (final groupKey in sortedGroups) {
      final groupItems = groupedItems[groupKey]!;
      
      // Add custom group header
      widgets.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
          child: Row(
            children: [
              Text(
                groupKey.toUpperCase(),
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Divider(
                  color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
                  thickness: 1,
                ),
              ),
            ],
          ),
        ),
      );

      // Add items in this group
      for (int i = 0; i < groupItems.length && itemCount < displayCount; i++) {
        widgets.add(_buildItemTile(context, groupItems[i], settings, store));
        // Removed Divider since tiles have bottom borders
        itemCount++;
      }

      if (itemCount >= displayCount) break;
    }

    if (showMore) {
       widgets.add(
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Center(
            child: TextButton(
              onPressed: () => setState(() => _loadedCount += _pageSize),
              child: Text(AppLocalizations.of(context)!.showMore),
            ),
          ),
        ),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) => widgets[index],
        childCount: widgets.length,
      ),
    );
  }

  Widget _buildItemTile(
    BuildContext context,
    PaymentsListItem listItem,
    AppSettingsStore settings,
    ExpenseStore store,
  ) {
    if (listItem.isPlannerItem) {
      final item = listItem.plannerItem!;
      final nextDue = _nextDueDate(
        item: item,
        payments: store.payments,
        settings: settings,
      );
      final l10n = AppLocalizations.of(context)!;
      final dueLabel = nextDue != null ? _formatDueDate(nextDue) : null;
      final typeLabel = item.type == PaymentType.oneOff
          ? item.type.label
          : item.frequency != null
              ? '${item.frequency!.label} ${item.type.label}'
              : item.type.label;
      
      final isDebit = item.amountMinorUnits < 0;
      final amountColor = isDebit ? settings.debitColor : settings.creditColor;
      
      // Calculate derived info strings
      final detailsParts = [
          if (item.archived) Terminology.of(context).archivedStatusLabel,
          typeLabel,
          if (item.category != null && item.category!.isNotEmpty) item.category,
          if (item.company != null && item.company!.isNotEmpty) item.company,
          if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null)
            '${AppLocalizations.of(context)!.remainingBalance} ${formatMoneyFromCents(item.remainingBalanceMinorUnits!, item.balanceCurrency ?? settings.currency, showCents: settings.showCents)}',
          if (item.type == PaymentType.debt && item.calculateFinalPaymentDate() != null)
            '${AppLocalizations.of(context)!.estimatedRepaymentDate} ${_formatDate(item.calculateFinalPaymentDate()!)}',
          if (item.notes != null && item.notes!.isNotEmpty) item.notes,
      ].where((s) => s != null && s.isNotEmpty).cast<String>().join(' • ');

      final tileContent = InkWell(
        onTap: () => _showUpsertPlannerItemSheet(
          context,
          existing: item,
        ),
        onLongPress: () => _showPlannerItemActions(context, item),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3),
                width: 0.5,
              ),
            ),
          ),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Left Accent Bar
                Container(
                  width: 3,
                  decoration: BoxDecoration(
                    color: amountColor.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 12),
                
                // Main Content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        item.label,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          color: item.archived 
                              ? Theme.of(context).colorScheme.onSurfaceVariant.withValues(alpha: 0.7)
                              : Theme.of(context).colorScheme.onSurface,
                          decoration: item.archived ? TextDecoration.lineThrough : null,
                        ),
                      ),
                      if (detailsParts.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          detailsParts,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                            fontSize: 11,
                            decoration: item.archived ? TextDecoration.lineThrough : null,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
                
                const SizedBox(width: 12),
                
                // Trailing: Amount + Due Date
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      formatMoneyFromCents(
                        item.amountMinorUnits,
                        settings.currency,
                        showCents: settings.showCents,
                      ),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: amountColor,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                    if (dueLabel != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        '${AppLocalizations.of(context)!.dueLabel} $dueLabel',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                              fontSize: 11,
                            ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      );

      final direction = _paymentDismissDirection(
        left: settings.paymentSwipeLeft,
        right: settings.paymentSwipeRight,
      );
      if (direction == null) return tileContent;

      return Dismissible(
        key: ValueKey(item.id),
        direction: direction,
        background: item.archived
            ? _resumeDismissBackground(context, alignLeft: true)
            : _paymentDismissBackground(
                context,
                action: settings.paymentSwipeRight,
                alignLeft: true,
              ),
        secondaryBackground: item.archived
            ? _resumeDismissBackground(context, alignLeft: false)
            : _paymentDismissBackground(
                context,
                action: settings.paymentSwipeLeft,
                alignLeft: false,
              ),
        confirmDismiss: (dismissDirection) async {
          final action = dismissDirection == DismissDirection.endToStart
              ? settings.paymentSwipeLeft
              : settings.paymentSwipeRight;
          return _handlePaymentSwipeAction(context, item, action);
        },
        child: tileContent,
      );
    } else {
      // Standalone payment
      final p = listItem.standalonePayment!;
      final isDebit = p.amountMinorUnits < 0;
      final amountColor = isDebit ? settings.debitColor : settings.creditColor;
      
      final tileContent = InkWell(
        onTap: () => _showUpdatePaymentSheetStandalone(context, p),
        onLongPress: () => _showStandalonePaymentActions(context, p),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.3),
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            children: [
               // Left Accent Bar (dashed or lighter for standalone?)
              Container(
                width: 3,
                height: 36,
                decoration: BoxDecoration(
                  color: amountColor.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                      Text(
                        p.label.isEmpty ? 'Payment' : p.label,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                     const SizedBox(height: 4),
                     Text(
                      _formatDate(p.date),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                            fontSize: 11,
                          ),
                    ),
                  ],
                ),
              ),
              Text(
                formatMoneyFromCents(
                  p.amountMinorUnits,
                  settings.currency,
                  showCents: settings.showCents,
                ),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: amountColor,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
        ),
      );

      return Dismissible(
        key: ValueKey('payment_${p.id}'),
        background: _paymentDismissBackground(
                context,
                action: PaymentSwipeAction.delete,
                alignLeft: true,
              ),
        secondaryBackground: _paymentDismissBackground(
                context,
                action: PaymentSwipeAction.delete,
                alignLeft: false,
              ),
        confirmDismiss: (direction) async {
          final confirmed = await _confirmDeleteStandalone(context, p);
          if (confirmed) {
            store.deletePayment(p.id);
            settings.currentBalanceCents -= p.amountMinorUnits;
          }
          return confirmed;
        },
        child: tileContent,
      );
    }
  }

  Future<void> _showPlannerItemActions(
    BuildContext context,
    PlannerItem item,
  ) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final action = await showModalBottomSheet<_PlannerItemAction>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Show debt details header for debt items
              if (item.type == PaymentType.debt && (item.remainingBalanceMinorUnits != null || item.calculateFinalPaymentDate() != null))
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        AppLocalizations.of(context)!.debtDetails,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: AppConstants.paddingSmall),
                      if (item.remainingBalanceMinorUnits != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                AppLocalizations.of(context)!.remainingBalance,
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              Text(
                                formatMoneyFromCents(item.remainingBalanceMinorUnits!, item.balanceCurrency ?? settings.currency, showCents: settings.showCents),
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  fontFeatures: const [FontFeature.tabularFigures()],
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (item.calculateFinalPaymentDate() != null)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              AppLocalizations.of(context)!.estimatedRepaymentDate,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            Text(
                              _formatDate(item.calculateFinalPaymentDate()!),
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              if (item.type == PaymentType.debt && (item.remainingBalanceMinorUnits != null || item.calculateFinalPaymentDate() != null))
                const Divider(height: 1),
              // Show category and company details if available
              if ((item.category != null && item.category!.isNotEmpty) || (item.company != null && item.company!.isNotEmpty))
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (item.category != null && item.category!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppLocalizations.of(context)!.category,
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                item.category ?? '',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (item.company != null && item.company!.isNotEmpty)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              AppLocalizations.of(context)!.company,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item.company!,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              if ((item.category != null && item.category!.isNotEmpty) || (item.company != null && item.company!.isNotEmpty))
                const Divider(height: 1),
              ListTile(
                leading: PhosphorIcon(
                  item.archived ? PhosphorIcons.play() : PhosphorIcons.stop(),
                ),
                title: Text(item.archived
                    ? Terminology.of(context).unarchiveActionLabel
                    : Terminology.of(context).archiveActionLabel),
                onTap: () => Navigator.pop(context, _PlannerItemAction.archive),
              ),
              ListTile(
                leading: PhosphorIcon(PhosphorIcons.trash()),
                title: Text(AppLocalizations.of(context)!.delete),
                onTap: () => Navigator.pop(context, _PlannerItemAction.delete),
              ),
              const SizedBox(height: AppConstants.paddingSmall),
            ],
          ),
        );
      },
    );

    if (!context.mounted || action == null) return;

    switch (action) {
      case _PlannerItemAction.archive:
        store.setPlannerItemArchived(item.id, !item.archived);
        break;
      case _PlannerItemAction.delete:
        final plannerItem = store.plannerItems.firstWhere((p) => p.id.value == item.id);
        final confirmed = await _confirmDelete(context, plannerItem);
        if (confirmed && context.mounted) {
          store.deletePlannerItem(plannerItem.id);
        }
        break;
    }
  }

  Future<void> _showUpsertPlannerItemSheet(
    BuildContext context, {
    PlannerItem? existing,
  }) async {
    final store = ExpenseStoreScope.read(context);
    final result = await showModalBottomSheet<PlannerItem>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpsertPlannerItemSheet(
        existing: existing,
        defaultStartDate: store.selectedMonth,
      ),
    );

    if (!context.mounted || result == null) return;
    store.upsertPlannerItem(result);
  }

  Future<void> _showAddMenu(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final terminology = Terminology.of(context);
    
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.calendar()),
              title: Text(terminology.itemStatusLabel == 'Archived' ? 'Add Scheduled Item' : 'Add Item'),
              subtitle: const Text('Bills, income, or savings targets'),
              onTap: () {
                Navigator.pop(context);
                _showUpsertPlannerItemSheet(context);
              },
            ),
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.receipt()),
              title: const Text('Log Transaction'),
              subtitle: const Text('Quickly record an expense or income'),
              onTap: () {
                Navigator.pop(context);
                _showQuickTransactionSheet(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _showQuickTransactionSheet(BuildContext context) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    
    final result = await showModalBottomSheet<PaymentEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => const QuickTransactionSheet(),
    );

    if (!context.mounted || result == null) return;
    
    // Save the payment
    store.upsertPayment(result);
    // Update balance
    settings.currentBalanceCents += result.amountMinorUnits;
    
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Transaction logged: ${result.label}'),
          action: SnackBarAction(
            label: 'Undo',
            onPressed: () {
              store.deletePayment(result.id);
              settings.currentBalanceCents -= result.amountMinorUnits;
            },
          ),
        ),
      );
    }
  }

  Future<void> _showUpdatePaymentSheetStandalone(BuildContext context, PaymentEntry payment) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final oldAmount = payment.amountMinorUnits;

    final result = await showModalBottomSheet<PaymentEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpdatePaymentSheet(
        payment: payment,
        title: 'Edit Transaction',
      ),
    );

    if (!context.mounted || result == null) return;

    store.upsertPayment(result);
    settings.currentBalanceCents = settings.currentBalanceCents - oldAmount + result.amountMinorUnits;
  }

  Future<void> _showStandalonePaymentActions(BuildContext context, PaymentEntry payment) async {
    final localizations = AppLocalizations.of(context)!;
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    final action = await showModalBottomSheet<_StandalonePaymentAction>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.pencilSimple()),
              title: Text(localizations.edit),
              onTap: () => Navigator.pop(context, _StandalonePaymentAction.edit),
            ),
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.trash()),
              title: Text(localizations.delete),
              onTap: () => Navigator.pop(context, _StandalonePaymentAction.delete),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );

    if (!context.mounted || action == null) return;

    if (action == _StandalonePaymentAction.edit) {
      _showUpdatePaymentSheetStandalone(context, payment);
    } else if (action == _StandalonePaymentAction.delete) {
      final confirmed = await _confirmDeleteStandalone(context, payment);
      if (confirmed && context.mounted) {
        store.deletePayment(payment.id);
        settings.currentBalanceCents -= payment.amountMinorUnits;
      }
    }
  }

  Future<bool> _confirmDeleteStandalone(BuildContext context, PaymentEntry payment) async {
    final localizations = AppLocalizations.of(context)!;
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(localizations.delete),
            content: Text('Are you sure you want to delete this transaction: ${payment.label}?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(localizations.cancel),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.error,
                ),
                child: Text(localizations.delete),
              ),
            ],
          ),
        ) ??
        false;
  }
}



enum _StandalonePaymentAction { edit, delete }

DateTime? _nextDueDate({
  required PlannerItem item,
  required List<PaymentEntry> payments,
  required AppSettingsStore settings,
}) {
  final now = DateTime.now();
  final today = DateTime.utc(now.year, now.month, now.day);
  final currentMonth = DateTime.utc(now.year, now.month, 1);

  // For one-off payments, they only appear in their start month
  if (item.type == PaymentType.oneOff || item.type == PaymentType.oneOffIncome) {
    final startMonth = DateTime.utc(item.startDate.year, item.startDate.month, 1);
    // If start month is before current month, no next due date
    if (startMonth.isBefore(currentMonth)) return null;
  }

  // Start checking from up to 3 months ago to catch overdue items,
  // but never before the item's start date.
  final threeMonthsAgo = DateTime.utc(now.year, now.month - 3, 1);
  final startMonthOfItem = DateTime.utc(item.startDate.year, item.startDate.month, 1);
  
  var checkMonth = threeMonthsAgo.isBefore(startMonthOfItem) 
      ? startMonthOfItem 
      : threeMonthsAgo;

  // Check up to 16 months ahead (3 back + 13 forward)
  for (var i = 0; i < 16; i++) {
    // Check if item should appear in this month
    if (!item.shouldAppearInMonth(checkMonth)) {
      checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);
      continue;
    }

    // Calculate the effective day for this month
    final maxDay = DateUtils.getDaysInMonth(checkMonth.year, checkMonth.month);
    final effectiveDay = item.dayOfMonth <= maxDay ? item.dayOfMonth : maxDay;
    final dueDate = DateTime.utc(checkMonth.year, checkMonth.month, effectiveDay);

    // Check if this occurrence is cleared
    final isCleared = isItemClearedForMonth(
      item: item,
      month: checkMonth,
      payments: payments,
      settings: settings,
    );

    // If not cleared, this is a candidate for next due date
    if (!isCleared) {
      // Return it if it's today or in the future
      if (!dueDate.isBefore(today)) {
        return dueDate;
      }
      
      // If it's in the past (overdue), we still return it as the "next" due date 
      // because it needs attention.
      return dueDate;
    }

    // Move to next month
    checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);
    
    // Safety break: don't search more than 13 months into the future from now
    if (checkMonth.isAfter(DateTime.utc(now.year, now.month + 13, 1))) {
      break;
    }
  }

  return null;
}

// _isItemClearedForMonth removed - now using isItemClearedForMonth from planner_actions.dart

String _formatDueDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

enum _PlannerItemAction { archive, delete }

DismissDirection? _paymentDismissDirection({
  required PaymentSwipeAction left,
  required PaymentSwipeAction right,
}) {
  final leftEnabled = left != PaymentSwipeAction.off;
  final rightEnabled = right != PaymentSwipeAction.off;
  if (leftEnabled && rightEnabled) return DismissDirection.horizontal;
  if (leftEnabled) return DismissDirection.endToStart;
  if (rightEnabled) return DismissDirection.startToEnd;
  return null;
}

Widget _resumeDismissBackground(
  BuildContext context, {
  required bool alignLeft,
}) {
  final bg = Theme.of(context).colorScheme.primaryContainer;
  final fg = Theme.of(context).colorScheme.onPrimaryContainer;
  final icon = PhosphorIcons.play();
  final label = Terminology.of(context).unarchiveActionLabel;

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Widget _paymentDismissBackground(
  BuildContext context, {
  required PaymentSwipeAction action,
  required bool alignLeft,
}) {
  final (bg, fg, label, icon) = switch (action) {
    PaymentSwipeAction.off => (
        Theme.of(context).colorScheme.surface,
        Theme.of(context).colorScheme.onSurface,
        '',
        PhosphorIcons.prohibit(),
      ),
        PaymentSwipeAction.edit => (
        Theme.of(context).colorScheme.primaryContainer,
        Theme.of(context).colorScheme.onPrimaryContainer,
        AppLocalizations.of(context)!.edit,
        PhosphorIcons.pencilSimple(),
      ),
    PaymentSwipeAction.delete => (
        Theme.of(context).colorScheme.errorContainer,
        Theme.of(context).colorScheme.onErrorContainer,
        AppLocalizations.of(context)!.delete,
        PhosphorIcons.trash(),
      ),
  };

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Future<bool> _handlePaymentSwipeAction(
  BuildContext context,
  PlannerItem item,
  PaymentSwipeAction action,
) async {
  final store = ExpenseStoreScope.read(context);

  // If item is ended, any swipe action resumes it
  if (item.archived) {
    store.setPlannerItemArchived(item.id, false);
    if (context.mounted) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.paymentResumed(item.label)),
          duration: AppConstants.snackBarShort,
          action: SnackBarAction(
            label: AppLocalizations.of(context)!.undo,
            onPressed: () => store.setPlannerItemArchived(item.id, true),
          ),
        ),
      );
    }
    return false;
  }

  // Normal behavior for non-archived items
  switch (action) {
    case PaymentSwipeAction.off:
      return false;
    case PaymentSwipeAction.edit:
      final result = await showModalBottomSheet<PlannerItem>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpsertPlannerItemSheet(
          existing: item,
          defaultStartDate: store.selectedMonth,
        ),
      );
      if (result != null) store.upsertPlannerItem(result);
      return false;
    case PaymentSwipeAction.delete:
      final confirmed = await _confirmDelete(context, item);
      if (confirmed) {
        store.deletePlannerItem(item.id);
      }
      return false;
  }
}

Future<bool> _confirmDelete(BuildContext context, PlannerItem item) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (context) {
      final theme = Theme.of(context);
      final scheme = theme.colorScheme;
      final l10n = AppLocalizations.of(context)!;
      final terminology = Terminology.of(context);

      return Dialog(
        insetPadding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingLarge - 4, // 20
          vertical: AppConstants.paddingLarge,
        ),
        backgroundColor: scheme.surfaceContainerHighest,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusDialog),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: AppConstants.dialogIconSize,
                    height: AppConstants.dialogIconSize,
                    decoration: BoxDecoration(
                      color: scheme.errorContainer,
                      borderRadius: BorderRadius.circular(AppConstants.radiusIconBox),
                    ),
                    child: PhosphorIcon(PhosphorIcons.trash(), color: scheme.onErrorContainer),
                  ),
                  const SizedBox(width: AppConstants.paddingNormal),
                  Expanded(
                    child: Text(
                      terminology.deleteTitle,
                      style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                l10n.deletePaymentConfirm(item.label),
                style: theme.textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: scheme.onSurface,
                        side: BorderSide(color: scheme.outlineVariant),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(l10n.cancel),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: FilledButton.styleFrom(
                        backgroundColor: scheme.error,
                        foregroundColor: scheme.onError,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(l10n.delete),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
  return confirmed ?? false;
}

String _formatDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}
