import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_money_pot_sheet.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

class MoneyPotsScreen extends StatelessWidget {
  const MoneyPotsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final store = ExpenseStoreScope.of(context);
    final pots = settings.moneyPotsSettings.moneyPots;
    final accounts = store.accounts;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Money Pots'),
      ),
      body: pots.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    PhosphorIcons.wallet(),
                    size: 64,
                    color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No money pots yet',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Theme.of(context).colorScheme.outline,
                        ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: () => _editPot(context, null),
                    icon: const Icon(Icons.add),
                    label: const Text('Create Money Pot'),
                  ),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: pots.length,
              separatorBuilder: (context, index) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final pot = pots[index];
                return _MoneyPotTile(
                  pot: pot,
                  accounts: accounts,
                  onEdit: () => _editPot(context, pot),
                );
              },
            ),
      floatingActionButton: pots.isNotEmpty
          ? FloatingActionButton(
              onPressed: () => _editPot(context, null),
              child: const Icon(Icons.add),
            )
          : null,
    );
  }

  Future<void> _editPot(BuildContext context, MoneyPot? pot) async {
    final settings = AppSettingsScope.read(context);
    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => UpsertMoneyPotSheet(initialPot: pot),
    );

    if (result is MoneyPot) {
      if (pot == null) {
        settings.addMoneyPot(result);
      } else {
        settings.updateMoneyPot(result);
      }
    } else if (result is DeletePotMarker && pot != null) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Delete Money Pot?'),
          content: Text('Are you sure you want to delete "${pot.name}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(foregroundColor: Theme.of(context).colorScheme.error),
              child: const Text('Delete'),
            ),
          ],
        ),
      );
      if (confirmed == true) {
        settings.removeMoneyPot(pot.id);
      }
    }
  }
}

class _MoneyPotTile extends StatelessWidget {
  const _MoneyPotTile({
    required this.pot,
    required this.accounts,
    required this.onEdit,
  });

  final MoneyPot pot;
  final List<Account> accounts;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final settings = AppSettingsScope.of(context);
    
    final isGlobal = pot.accountIds == null || pot.accountIds!.isEmpty;

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: colorScheme.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: (pot.type == MoneyPotType.savings
                            ? colorScheme.primaryContainer
                            : colorScheme.errorContainer)
                        .withOpacity(0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    pot.type == MoneyPotType.savings
                        ? PhosphorIcons.trendUp()
                        : PhosphorIcons.trendDown(),
                    size: 20,
                    color: pot.type == MoneyPotType.savings
                        ? colorScheme.onPrimaryContainer
                        : colorScheme.onErrorContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        pot.name,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        formatMoney(pot.amountMinorUnits, pot.currency ?? settings.currency),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined),
                  visualDensity: VisualDensity.compact,
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(height: 1),
            const SizedBox(height: 12),
            Text(
              'Visibility',
              style: theme.textTheme.labelMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            _AccountSelector(
              pot: pot,
              accounts: accounts,
            ),
          ],
        ),
      ),
    );
  }
}

class _AccountSelector extends StatelessWidget {
  const _AccountSelector({
    required this.pot,
    required this.accounts,
  });

  final MoneyPot pot;
  final List<Account> accounts;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final settings = AppSettingsScope.read(context);

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        FilterChip(
          label: const Text('Global'),
          selected: pot.accountIds == null || pot.accountIds!.isEmpty,
          onSelected: (selected) {
            if (selected) {
              settings.updateMoneyPot(pot.copyWith(accountIds: null));
            } else if (accounts.isNotEmpty) {
              // If unselecting global, default to current account or first account
              final currentAccount = ExpenseStoreScope.read(context).currentAccount;
              settings.updateMoneyPot(pot.copyWith(accountIds: [currentAccount.id]));
            }
          },
        ),
        ...accounts.map((account) {
          final isSelected = pot.accountIds?.contains(account.id) ?? false;
          return FilterChip(
            label: Text(account.name),
            selected: isSelected,
            onSelected: (selected) {
              List<AccountId> newIds = List.from(pot.accountIds ?? []);
              if (selected) {
                if (!newIds.contains(account.id)) {
                  newIds.add(account.id);
                }
              } else {
                newIds.remove(account.id);
              }
              
              // If no accounts selected, it becomes global (or we can force at least one?)
              // Per logic, empty = global.
              settings.updateMoneyPot(pot.copyWith(accountIds: newIds.isEmpty ? null : newIds));
            },
          );
        }),
      ],
    );
  }
}
