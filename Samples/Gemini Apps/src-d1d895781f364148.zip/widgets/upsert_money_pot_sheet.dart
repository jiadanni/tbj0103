import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/util/validation.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:flutter/services.dart';

class UpsertMoneyPotSheet extends StatefulWidget {
  const UpsertMoneyPotSheet({
    super.key,
    this.initialPot,
  });

  final MoneyPot? initialPot;

  @override
  State<UpsertMoneyPotSheet> createState() => _UpsertMoneyPotSheetState();
}

class _UpsertMoneyPotSheetState extends State<UpsertMoneyPotSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _amountController;
  late MoneyPotType _selectedType;
  AppCurrency? _selectedCurrency;
  List<AccountId>? _selectedAccountIds;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initialPot?.name);
    
    // Convert cents to display amount (e.g. 1250 -> 12.50)
    // Assuming 2 decimal places for simplicity in manual entry for now
    // Or we can just use integer input if strict cents. 
    // Let's assume standard decimal input for user convenience.
    final initialAmount = widget.initialPot?.amountMinorUnits != null 
        ? (widget.initialPot!.amountMinorUnits / 100.0).toStringAsFixed(2) 
        : '';
    _amountController = TextEditingController(text: initialAmount);
    
    
    _selectedType = widget.initialPot?.type ?? MoneyPotType.savings;
    _selectedCurrency = widget.initialPot?.currency;
    _selectedAccountIds = widget.initialPot?.accountIds;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final amountString = _amountController.text.trim();
      // Parse amount
      final amountDouble = double.tryParse(amountString) ?? 0.0;
      final amountMinorUnits = (amountDouble * 100).round();

      final pot = widget.initialPot?.copyWith(
        name: name,
        amountMinorUnits: amountMinorUnits,
        type: _selectedType,
        currency: _selectedCurrency,
        accountIds: _selectedAccountIds,
      ) ?? MoneyPot.create(
        name: name,
        amountMinorUnits: amountMinorUnits,
        type: _selectedType,
        currency: _selectedCurrency,
        accountIds: _selectedAccountIds,
      );

      Navigator.of(context).pop(pot);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final settings = AppSettingsScope.of(context);
    final isEditing = widget.initialPot != null;
    
    final effectiveCurrency = _selectedCurrency ?? settings.currencySettings.currency;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppConstants.paddingNormal),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                isEditing ? 'Edit Money Pot' : 'New Money Pot',
                style: theme.textTheme.titleLarge,
              ),
              const SizedBox(height: AppConstants.paddingNormal),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  hintText: 'e.g. Vacation Fund',
                ),
                validator: (value) => 
                    validateLabel(value, 'Name'),
                textCapitalization: TextCapitalization.sentences,
              ),
              const SizedBox(height: AppConstants.paddingNormal),
              TextFormField(
                controller: _amountController,
                decoration: InputDecoration(
                  labelText: 'Balance',
                  prefixText: currencySymbol(effectiveCurrency),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                   FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                ],
                validator: (value) {
                   if (value == null || value.isEmpty) return 'Amount is required';
                   return null;
                },
              ),
              const SizedBox(height: AppConstants.paddingNormal),
              DropdownButtonFormField<MoneyPotType>(
                value: _selectedType,
                decoration: const InputDecoration(
                  labelText: 'Type',
                ),
                items: MoneyPotType.values.map((type) {
                  return DropdownMenuItem(
                    value: type,
                    child: Text(type == MoneyPotType.savings ? 'Savings / Pot' : 'Debt'),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedType = value);
                  }
                },
              ),
              const SizedBox(height: AppConstants.paddingNormal),
              DropdownButtonFormField<AppCurrency?>(
                value: _selectedCurrency,
                decoration: const InputDecoration(
                  labelText: 'Currency',
                  helperText: 'Leave empty to use app default',
                  helperMaxLines: 2,
                ),
                items: [
                  const DropdownMenuItem<AppCurrency?>(
                    value: null,
                    child: Text('Default (App Setting)'),
                  ),
                  ...AppCurrency.values.map((currency) {
                    return DropdownMenuItem<AppCurrency?>(
                      value: currency,
                      child: Text(currencyLabel(currency)),
                    );
                  }),
                ],
                onChanged: (value) {
                  setState(() => _selectedCurrency = value);
                },
              ),
              const SizedBox(height: AppConstants.paddingNormal),
              DropdownButtonFormField<bool>(
                value: _selectedAccountIds == null || _selectedAccountIds!.isEmpty,
                decoration: const InputDecoration(
                  labelText: 'Visibility',
                  helperText: 'Global pots are visible in all accounts',
                ),
                items: const [
                  DropdownMenuItem(
                    value: true,
                    child: Text('Global (All Accounts)'),
                  ),
                  DropdownMenuItem(
                    value: false,
                    child: Text('Specific Accounts'),
                  ),
                ],
                onChanged: (isGlobal) {
                  if (isGlobal == true) {
                    setState(() => _selectedAccountIds = null);
                  } else {
                    final currentAccountId = ExpenseStoreScope.read(context).currentAccount.id;
                    setState(() => _selectedAccountIds = [currentAccountId]);
                  }
                },
              ),
              if (_selectedAccountIds != null) ...[
                const SizedBox(height: AppConstants.paddingSmall),
                Wrap(
                  spacing: 8,
                  runSpacing: 0,
                  children: ExpenseStoreScope.of(context).accounts.map((account) {
                    final isSelected = _selectedAccountIds!.contains(account.id);
                    return FilterChip(
                      label: Text(account.name),
                      selected: isSelected,
                      onSelected: (selected) {
                        setState(() {
                          final next = List<AccountId>.from(_selectedAccountIds!);
                          if (selected) {
                            if (!next.contains(account.id)) next.add(account.id);
                          } else {
                            next.remove(account.id);
                            if (next.isEmpty) {
                              _selectedAccountIds = null;
                              return;
                            }
                          }
                          _selectedAccountIds = next;
                        });
                      },
                    );
                  }).toList(),
                ),
              ],
              const SizedBox(height: AppConstants.paddingLarge),
              FilledButton(
                onPressed: _submit,
                child: Text(isEditing ? 'Save' : 'Create'),
              ),
              if (isEditing) ...[
                const SizedBox(height: AppConstants.paddingNormal),
                TextButton(
                  onPressed: () {
                     Navigator.of(context).pop(const DeletePotMarker()); 
                  },
                  style: TextButton.styleFrom(foregroundColor: theme.colorScheme.error),
                  child: const Text('Delete'),
                ),
              ],
               const SizedBox(height: AppConstants.paddingLarge),
            ],
          ),
        ),
      ),
    );
  }
}

class DeletePotMarker {
  const DeletePotMarker();
}

