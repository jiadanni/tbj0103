import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/util/validation.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Result of day-of-month validation.
///
/// [dayError] is set if validation failed, [dayInfoMessage] is set for
/// informational messages (e.g., "This day doesn't exist in February").
class DayValidationResult {
  final String? dayError;
  final String? dayInfoMessage;

  const DayValidationResult({
    required this.dayError,
    required this.dayInfoMessage,
  });
}

/// Validation logic for the planner item form.
///
/// Provides static methods for validating individual fields and enforcing
/// constraints on payment amounts based on payment type.
class PlannerItemFormValidation {
  PlannerItemFormValidation._(); // Prevent instantiation

  /// Validates the day-of-month input.
  ///
  /// Returns a DayValidationResult with error and/or info messages.
  /// Days > 28 trigger an info message about month-end handling.
  static DayValidationResult validateDay(String text, BuildContext context) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.required,
        dayInfoMessage: null,
      );
    }

    final day = int.tryParse(trimmed);

    if (day == null) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.enterValidNumber,
        dayInfoMessage: null,
      );
    }

    if (day < 1 || day > 31) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.dayOutOfRange,
        dayInfoMessage: null,
      );
    }

    if (day > 28) {
      return DayValidationResult(
        dayError: null,
        dayInfoMessage: AppLocalizations.of(context)!.paymentScheduledLastDay(day),
      );
    }

    return const DayValidationResult(
      dayError: null,
      dayInfoMessage: null,
    );
  }

  /// Validates that the amount is within acceptable bounds.
  ///
  /// Returns an error message if validation fails, null otherwise.
  static String? validateAmountBounds(int amountMinorUnits) {
    return validateAmountMinorUnits(amountMinorUnits);
  }

  /// Validates all required inputs for saving a planner item.
  ///
  /// Checks that label, amount, and day are provided and valid.
  /// Day is optional for spending envelopes.
  /// Returns an error message if any validation fails, null if all valid.
  static String? validateSaveInputs({
    required String label,
    required int? amountMinorUnits,
    required String dayText,
    required String? dayValidationError,
    required BuildContext context,
    PaymentType? paymentType,
  }) {
    // Spending envelopes don't require a day
    final isDayRequired = paymentType != PaymentType.spendingEnvelope;
    
    if (label.isEmpty || amountMinorUnits == null) {
      return AppLocalizations.of(context)!.enterNameAmountDay;
    }
    
    if (isDayRequired && dayText.isEmpty) {
      return AppLocalizations.of(context)!.enterNameAmountDay;
    }

    final amountError = validateAmountMinorUnits(amountMinorUnits.abs());
    if (amountError != null) {
      return amountError;
    }

    if (isDayRequired && dayValidationError != null) {
      return dayValidationError;
    }

    if (isDayRequired) {
      final day = int.tryParse(dayText.trim());
      if (day != null && (day < 1 || day > 31)) {
        return AppLocalizations.of(context)!.dayOutOfRange;
      }
    }

    return null;
  }

  /// Enforces the correct sign for an amount based on payment type.
  ///
  /// Income types must be positive, expense types must be negative.
  /// Debt amounts stay positive (they represent payment amounts).
  /// Modifies the controller's text if the sign is incorrect.
  static void enforceAmountSign(
    TextEditingController controller,
    PaymentType type,
  ) {
    final text = controller.text.trim();
    if (text.isEmpty) return;

    final amount = double.tryParse(text);
    if (amount == null) return;

    final shouldBePositive = type.isIncomeType;
    final isPositive = amount > 0;
    final isNegative = amount < 0;

    String? nextText;
    if (shouldBePositive && isNegative) {
      nextText = text.replaceFirst(RegExp(r'^-+'), '');
    } else if (!shouldBePositive && isPositive && type != PaymentType.debt) {
      nextText = '-$text';
    }
    // Note: Debt amounts stay positive (they represent payment amounts)

    if (nextText == null || nextText == text) return;
    controller.value = controller.value.copyWith(
      text: nextText,
      selection: TextSelection.collapsed(offset: nextText.length),
      composing: TextRange.empty,
    );
  }
}
