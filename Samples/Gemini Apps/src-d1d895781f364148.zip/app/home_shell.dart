import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import 'package:expense_stalker_mobile/src/features/payments/payments_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_screen.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tabIndex = 0;
  late final PageController _pageController;
  bool _hasUserNavigated = false; // Track if user has explicitly navigated

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _tabIndex);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Sync tab index with persisted view mode on initial load ONLY
    // Don't sync if user has already navigated (prevents overriding user's choice)
    if (_hasUserNavigated) return;
    
    final settings = AppSettingsScope.read(context);
    final viewMode = settings.plannerViewMode;
    final desiredIndex = _viewModeToTabIndex(viewMode);
    
    // Sync the tab index if it doesn't match the persisted view mode
    if (_tabIndex != desiredIndex) {
      setState(() {
        _tabIndex = desiredIndex;
      });
      
      // Jump to the correct page immediately
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients && !_hasUserNavigated) {
          _pageController.jumpToPage(_tabIndex);
        }
      });
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  int _viewModeToTabIndex(PlannerViewMode mode) {
    return switch (mode) {
      PlannerViewMode.month => 0,
      PlannerViewMode.grid => 1,
      PlannerViewMode.sheet => 2,
    };
  }

  PlannerViewMode _tabIndexToViewMode(int index) {
    return switch (index) {
      0 => PlannerViewMode.month,
      1 => PlannerViewMode.grid,
      2 => PlannerViewMode.sheet,
      _ => PlannerViewMode.month,
    };
  }

  void _onDestinationSelected(int index) {
    final settings = AppSettingsScope.read(context);
    _hasUserNavigated = true; // Mark that user has navigated
    setState(() => _tabIndex = index);
    
    // Update view mode for planner tabs (0-2)
    if (index < 3) {
      settings.plannerViewMode = _tabIndexToViewMode(index);
    }
    
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final terminology = Terminology.of(context);
    final l10n = AppLocalizations.of(context)!;
    
    // All 4 tabs: 3 planner view modes + payments
    final List<Widget> tabs = const [
      PlannerScreen(viewMode: PlannerViewMode.month), // Month view
      PlannerScreen(viewMode: PlannerViewMode.grid), // Grid view
      PlannerScreen(viewMode: PlannerViewMode.sheet), // Sheet view
      PaymentsScreen(),
    ];

    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: settings.enableTabSwipe
            ? const PageScrollPhysics()
            : const NeverScrollableScrollPhysics(),
        onPageChanged: (index) {
          _hasUserNavigated = true; // Mark that user has navigated
          setState(() => _tabIndex = index);
          // Sync view mode when swiping between planner tabs
          if (index < 3) {
            settings.plannerViewMode = _tabIndexToViewMode(index);
          }
        },
        children: tabs,
      ),
      bottomNavigationBar: _CustomBottomNav(
        selectedIndex: _tabIndex,
        onDestinationSelected: _onDestinationSelected,
        items: [
          _NavItem(
            icon: PhosphorIcons.rows(),
            selectedIcon: PhosphorIcons.rows(PhosphorIconsStyle.fill),
            label: 'Month',
          ),
          _NavItem(
            icon: PhosphorIcons.squaresFour(),
            selectedIcon: PhosphorIcons.squaresFour(PhosphorIconsStyle.fill),
            label: 'Grid',
          ),
          _NavItem(
            icon: PhosphorIcons.table(),
            selectedIcon: PhosphorIcons.table(PhosphorIconsStyle.fill),
            label: 'Sheet',
          ),
          _NavItem(
            icon: PhosphorIcons.wallet(),
            selectedIcon: PhosphorIcons.wallet(PhosphorIconsStyle.fill),
            label: terminology.listTabLabel,
          ),
        ],
      ),
    );
  }
}

/// Data class for navigation items
class _NavItem {
  const _NavItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
  
  final IconData icon;
  final IconData selectedIcon;
  final String label;
}

/// Custom bottom navigation bar with top-line indicator instead of pill
class _CustomBottomNav extends StatelessWidget {
  const _CustomBottomNav({
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.items,
  });
  
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<_NavItem> items;
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    return Container(
      height: 72 + MediaQuery.paddingOf(context).bottom,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: theme.colorScheme.outlineVariant.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == selectedIndex;
            
            return Expanded(
              child: _NavItemWidget(
                item: item,
                isSelected: isSelected,
                onTap: () => onDestinationSelected(index),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _NavItemWidget extends StatelessWidget {
  const _NavItemWidget({
    required this.item,
    required this.isSelected,
    required this.onTap,
  });
  
  final _NavItem item;
  final bool isSelected;
  final VoidCallback onTap;
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = isSelected 
        ? theme.colorScheme.primary 
        : theme.colorScheme.onSurfaceVariant;
    
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          // Top-line indicator
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            height: 2,
            width: isSelected ? 32 : 0,
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
              borderRadius: BorderRadius.circular(1),
            ),
          ),
          const Spacer(),
          // Icon
          Icon(
            isSelected ? item.selectedIcon : item.icon,
            color: color,
            size: 24,
          ),
          const SizedBox(height: 4),
          // Label
          Text(
            item.label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              fontSize: 11,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
