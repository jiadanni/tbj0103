import 'dart:async';
import 'package:flutter/widgets.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/util/async_queue.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/test_data_generator.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

class ExpenseStore extends ChangeNotifier {
  ExpenseStore({
    required List<Account> accounts,
    required Account currentAccount,
    required DateTime selectedMonth,
    required List<PlannerItem> plannerItems,
    required List<PaymentEntry> payments,
    ExpensePersistence? persistence,
  }) : _accounts = List.unmodifiable(accounts),
       _currentAccount = currentAccount,
       _selectedMonth = monthOnly(selectedMonth),
       _plannerItems = List.unmodifiable(plannerItems),
       _payments = List.unmodifiable(payments),
       _persistence = persistence;

  List<Account> _accounts;
  Account _currentAccount;
  DateTime _selectedMonth;
  List<PlannerItem> _plannerItems;
  List<PaymentEntry> _payments;
  final ExpensePersistence? _persistence;
  Timer? _debounceTimer;
  final AsyncQueue _saveQueue = AsyncQueue();
  final AsyncQueue _accountQueue = AsyncQueue();

  /// Flag to indicate that caches need to be recomputed.
  bool _cacheDirty = true;

  /// The account ID being switched to, used to detect superseded switches.
  AccountId? _pendingSwitchAccountId;

  List<Account> get accounts => _accounts;
  Account get currentAccount => _currentAccount;
  DateTime get selectedMonth => _selectedMonth;
  ExpensePersistence? get persistence => _persistence;

  Future<void> saveNow() async {
    final p = _persistence;
    if (p == null) return;
    _debounceTimer?.cancel();
    await _saveQueue.enqueue(() => p.save(_currentAccount.id, _snapshot()));
  }

  static Future<ExpenseStore> loadOrCreate() async {
    final persistence = await ExpensePersistence.create();
    try {
      final accounts = await persistence.loadAccounts();
      final currentAccountId = await persistence.getCurrentAccountId();
      
      Account selectedAccount;
      if (accounts.isEmpty) {
        // First run or no accounts: create a default Main Account
        selectedAccount = Account.create(name: 'Main Account');
        await persistence.saveAccounts([selectedAccount]);
        await persistence.setCurrentAccountId(selectedAccount.id);
        
        final store = ExpenseStore(
          accounts: [selectedAccount],
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          plannerItems: [],
          payments: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      selectedAccount = accounts.firstWhere(
        (a) => a.id == currentAccountId,
        orElse: () => accounts.first,
      );

      final snapshot = await persistence.load(selectedAccount.id);
      if (snapshot == null) {
        // Account exists but data is missing? Unusual but handle it
        final store = ExpenseStore(
          accounts: accounts,
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          plannerItems: [],
          payments: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      return ExpenseStore(
        accounts: accounts,
        currentAccount: selectedAccount,
        selectedMonth: DateTime.now(),
        plannerItems: snapshot.plannerItems,
        payments: snapshot.payments,
        persistence: persistence,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to load expenses, creating emergency account',
        error: error,
        stackTrace: stackTrace,
      );
      final emergencyAccount = Account.create(name: 'Rescue Account');
      return ExpenseStore(
        accounts: [emergencyAccount],
        currentAccount: emergencyAccount,
        selectedMonth: DateTime.now(),
        plannerItems: [],
        payments: [],
        persistence: persistence,
      );
    }
  }
  
  /// Factory for tests
  factory ExpenseStore.withSampleData() {
    final account = Account.create(name: 'Test Account', isTestData: true);
    final (plannerItems, payments) = TestDataGenerator.generate(size: TestDatasetSize.standard);
    return ExpenseStore(
      accounts: [account],
      currentAccount: account,
      selectedMonth: DateTime.now(),
      plannerItems: plannerItems,
      payments: payments,
    );
  }

  Future<void> switchAccount(AccountId accountId) async {
    if (accountId == _currentAccount.id) return;
    final persistence = _persistence;
    if (persistence == null) return;

    // Track this as the pending switch - supersedes any earlier pending switch
    _pendingSwitchAccountId = accountId;

    await _accountQueue.enqueue(() async {
      await _switchAccountInternal(accountId);
    });
  }

  /// Internal implementation of account switching, must be called from within
  /// an _accountQueue.enqueue block or during initialization.
  Future<void> _switchAccountInternal(AccountId accountId) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (accountId == _currentAccount.id) return;

    // Check if this switch was superseded by a newer request
    if (_pendingSwitchAccountId != accountId) {
      debugLog(
        LogCategory.persistence,
        'Account switch to $accountId superseded by $_pendingSwitchAccountId',
      );
      return;
    }

    try {
      // Ensure current work is saved before switching
      _debounceTimer?.cancel();
      await _saveQueue.enqueue(() => persistence.save(_currentAccount.id, _snapshot()));

      // Check again after save
      if (_pendingSwitchAccountId != accountId) return;

      // Validate account still exists
      final nextAccount = _accounts.cast<Account?>().firstWhere(
        (a) => a?.id == accountId,
        orElse: () => null,
      );
      if (nextAccount == null) {
        debugLog(
          LogCategory.persistence,
          'Account $accountId no longer exists, aborting switch',
        );
        return;
      }

      final snapshot = await persistence.load(accountId);

      // Final check: still the intended switch target after async load?
      if (_pendingSwitchAccountId != accountId) return;

      if (snapshot != null) {
        _currentAccount = nextAccount;
        _selectedMonth = monthOnly(DateTime.now());
        _plannerItems = List.unmodifiable(snapshot.plannerItems);
        _payments = List.unmodifiable(snapshot.payments);

        await persistence.setCurrentAccountId(accountId);

        _cacheDirty = true;
        notifyListeners();
      }
    } finally {
      // Only clear if we are the one who set it (and no newer request came in)
      if (_pendingSwitchAccountId == accountId) {
        _pendingSwitchAccountId = null;
      }
    }
  }

  Future<void> createAccount(String name, {TestDatasetSize? testSize}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    await _accountQueue.enqueue(() async {
      final newAccount = Account.create(name: name, isTestData: testSize != null);
      final List<Account> updatedAccounts = List.from(_accounts)..add(newAccount);

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      if (testSize != null) {
        final (plannerItems, payments) = TestDataGenerator.generate(size: testSize);
        final snapshot = ExpenseSnapshot(
          selectedMonth: monthOnly(DateTime.now()),
          plannerItems: plannerItems,
          payments: payments,
        );
        await persistence.save(newAccount.id, snapshot);
      } else {
        await persistence.save(newAccount.id, ExpenseSnapshot(
          selectedMonth: monthOnly(DateTime.now()),
          plannerItems: [],
          payments: [],
        ));
      }

      notifyListeners();
    });
  }

  Future<void> deleteAccount(AccountId accountId) async {
    if (_accounts.length <= 1) return; // Prevent deleting the last account

    final persistence = _persistence;
    if (persistence == null) return;

    await _accountQueue.enqueue(() async {
      // Re-validate inside the queue
      if (_accounts.length <= 1) return;
      if (!_accounts.any((a) => a.id == accountId)) return;

      final updatedAccounts = _accounts.where((a) => a.id != accountId).toList();
      await persistence.saveAccounts(updatedAccounts);
      await persistence.deleteAccountData(accountId);

      _accounts = List.unmodifiable(updatedAccounts);

      final needsSwitch = accountId == _currentAccount.id;

      if (needsSwitch) {
        // Safe to call internal logic as we are already in the queue
        await _switchAccountInternal(_accounts.first.id);
      } else {
        notifyListeners();
      }
    });
  }

  Future<void> renameAccount(AccountId accountId, String newName) async {
    final persistence = _persistence;
    if (persistence == null) return;

    await _accountQueue.enqueue(() async {
      final index = _accounts.indexWhere((a) => a.id == accountId);
      if (index < 0) return;

      final updatedAccount = _accounts[index].copyWith(
        name: newName,
        lastModified: DateTime.now(),
      );

      final List<Account> updatedAccounts = List.from(_accounts);
      updatedAccounts[index] = updatedAccount;

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      if (accountId == _currentAccount.id) {
        _currentAccount = updatedAccount;
      }

      notifyListeners();
    });
  }

  // --- Account-specific settings updates ---

  /// Update the paycheck day for the current account
  Future<void> updatePaycheckDay(int? day) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final clampedDay = day == null ? null : day.clamp(1, 31);
    if (_currentAccount.paycheckDay == clampedDay) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckDay: clampedDay,
      clearPaycheckDay: day == null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck business day adjustment setting
  Future<void> updatePaycheckBusinessAdjust(bool adjust) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.paycheckBusinessAdjust == adjust) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjust: adjust,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck adjust direction
  Future<void> updatePaycheckBusinessAdjustDirection(PaycheckAdjustDirection direction) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.paycheckBusinessAdjustDirection == direction) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjustDirection: direction,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the starting balance for the current account
  Future<void> updateStartingBalance(int cents) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.startingBalanceCents == cents) return;

    final updatedAccount = _currentAccount.copyWith(
      startingBalanceCents: cents,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> updatePlannerSortOrder(PlannerSortOrder order, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerSortOrder == order) return;
    await _updateAccountSetting((a) => a.copyWith(plannerSortOrder: order), syncToAll: syncToAll);
  }

  Future<void> updatePlannerDateSortMode(PlannerDateSortMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerDateSortMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(plannerDateSortMode: mode), syncToAll: syncToAll);
  }

  Future<void> updateViewPeriodMode(ViewPeriodMode mode) async {
    // Note: ViewPeriodMode is strictly account-specific, no syncToAll
    if (_currentAccount.viewPeriodMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(viewPeriodMode: mode));
  }

  Future<void> updatePlannerViewMode(PlannerViewMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerViewMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(plannerViewMode: mode), syncToAll: syncToAll);
  }

  Future<void> updatePlannerShowClearedItems(bool show, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerShowClearedItems == show) return;
    await _updateAccountSetting((a) => a.copyWith(plannerShowClearedItems: show), syncToAll: syncToAll);
  }

  Future<void> updatePlannerGroupByDate(bool group, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerGroupByDate == group) return;
    await _updateAccountSetting((a) => a.copyWith(plannerGroupByDate: group), syncToAll: syncToAll);
  }

  Future<void> updatePlannerGroupByTheme(bool group, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerGroupByTheme == group) return;
    await _updateAccountSetting((a) => a.copyWith(plannerGroupByTheme: group), syncToAll: syncToAll);
  }

  Future<void> updatePlannerShowPaymentOrigin(bool show, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerShowPaymentOrigin == show) return;
    await _updateAccountSetting((a) => a.copyWith(plannerShowPaymentOrigin: show), syncToAll: syncToAll);
  }

  Future<void> updateMonthTotalsDisplayMode(MonthTotalsDisplayMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.monthTotalsDisplayMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(monthTotalsDisplayMode: mode), syncToAll: syncToAll);
  }

  Future<void> updateMonthCardDisplayMode(MonthCardDisplayMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.monthCardDisplayMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(monthCardDisplayMode: mode), syncToAll: syncToAll);
  }

  Future<void> updateMultiMonthDisplayMode(MultiMonthDisplayMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.multiMonthDisplayMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(multiMonthDisplayMode: mode), syncToAll: syncToAll);
  }

  Future<void> updateDayFormat(DayFormat format, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.dayFormat == format) return;
    await _updateAccountSetting((a) => a.copyWith(dayFormat: format), syncToAll: syncToAll);
  }

  Future<void> updatePlannerSwipeLeft(PlannerSwipeAction action, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerSwipeLeft == action) return;
    await _updateAccountSetting((a) => a.copyWith(plannerSwipeLeft: action), syncToAll: syncToAll);
  }

  Future<void> updatePlannerSwipeRight(PlannerSwipeAction action, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerSwipeRight == action) return;
    await _updateAccountSetting((a) => a.copyWith(plannerSwipeRight: action), syncToAll: syncToAll);
  }

  Future<void> updatePlannerTapAction(PlannerTapAction action, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerTapAction == action) return;
    await _updateAccountSetting((a) => a.copyWith(plannerTapAction: action), syncToAll: syncToAll);
  }

  Future<void> updatePaymentSwipeLeft(PaymentSwipeAction action, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentSwipeLeft == action) return;
    await _updateAccountSetting((a) => a.copyWith(paymentSwipeLeft: action), syncToAll: syncToAll);
  }

  Future<void> updatePaymentSwipeRight(PaymentSwipeAction action, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentSwipeRight == action) return;
    await _updateAccountSetting((a) => a.copyWith(paymentSwipeRight: action), syncToAll: syncToAll);
  }

  Future<void> updatePaymentDisplayMode(PaymentDisplayMode mode, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentDisplayMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(paymentDisplayMode: mode), syncToAll: syncToAll);
  }

  Future<void> updateEnableTabSwipe(bool enable, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.enableTabSwipe == enable) return;
    await _updateAccountSetting((a) => a.copyWith(enableTabSwipe: enable), syncToAll: syncToAll);
  }

  Future<void> updatePlannerUseZeroBaseline(bool useZero, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.plannerUseZeroBaseline == useZero) return;
    await _updateAccountSetting((a) => a.copyWith(plannerUseZeroBaseline: useZero), syncToAll: syncToAll);
  }

  Future<void> updateTerminologyPreset(TerminologyPreset preset, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.terminologyPreset == preset) return;
    await _updateAccountSetting((a) => a.copyWith(terminologyPreset: preset), syncToAll: syncToAll);
  }

  Future<void> updatePaymentsFilterType(PaymentsFilterType type, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentsFilterType == type) return;
    await _updateAccountSetting((a) => a.copyWith(paymentsFilterType: type), syncToAll: syncToAll);
  }

  Future<void> updatePaymentsGroupBy(PaymentsGroupBy grouping, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentsGroupBy == grouping) return;
    await _updateAccountSetting((a) => a.copyWith(paymentsGroupBy: grouping), syncToAll: syncToAll);
  }

  Future<void> updatePaymentsShowArchived(bool show, {bool syncToAll = false}) async {
    if (!syncToAll && _currentAccount.paymentsShowArchived == show) return;
    await _updateAccountSetting((a) => a.copyWith(paymentsShowArchived: show), syncToAll: syncToAll);
  }

  Future<void> updateCategoryPresetMode(CategoryPresetMode mode) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.categoryPresetMode == mode) return;

    final updatedAccount = _currentAccount.copyWith(
      categoryPresetMode: mode,
      lastModified: DateTime.now(),
    );
    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> addCustomCategory(String category, {required bool isIncome}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmed = category.trim();
    if (trimmed.isEmpty) return;

    final existing = isIncome ? _currentAccount.customIncomeCategories : _currentAccount.customExpenseCategories;
    if (existing.contains(trimmed)) return;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: isIncome ? null : [..._currentAccount.customExpenseCategories, trimmed],
      customIncomeCategories: isIncome ? [..._currentAccount.customIncomeCategories, trimmed] : null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> removeCustomCategory(String category, {required bool isIncome}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final existing = isIncome ? _currentAccount.customIncomeCategories : _currentAccount.customExpenseCategories;
    if (!existing.contains(category)) return;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: isIncome ? null : _currentAccount.customExpenseCategories.where((c) => c != category).toList(),
      customIncomeCategories: isIncome ? _currentAccount.customIncomeCategories.where((c) => c != category).toList() : null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> renameCustomCategory(String oldName, String newName, {required bool isIncome}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmedNew = newName.trim();
    if (trimmedNew.isEmpty || trimmedNew == oldName) return;

    final existing = isIncome ? _currentAccount.customIncomeCategories : _currentAccount.customExpenseCategories;
    if (!existing.contains(oldName)) return;

    final updatedExpense = isIncome 
        ? _currentAccount.customExpenseCategories 
        : _currentAccount.customExpenseCategories.map((c) => c == oldName ? trimmedNew : c).toList();
    final updatedIncome = isIncome 
        ? _currentAccount.customIncomeCategories.map((c) => c == oldName ? trimmedNew : c).toList()
        : _currentAccount.customIncomeCategories;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: updatedExpense,
      customIncomeCategories: updatedIncome,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update money pots for the current account
  Future<void> updateMoneyPots(List<MoneyPot> pots) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      moneyPots: pots,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update money pots section label for the current account
  Future<void> updateMoneyPotsSectionLabel(String? label) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      moneyPotsSectionLabel: label,
      clearMoneyPotsSectionLabel: label == null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Add a money pot to the current account
  Future<void> addMoneyPot(MoneyPot pot) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedPots = [..._currentAccount.moneyPots, pot];
    await updateMoneyPots(updatedPots);
  }

  /// Update a money pot in the current account
  Future<void> updateMoneyPot(MoneyPot pot) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final index = _currentAccount.moneyPots.indexWhere((p) => p.id == pot.id);
    if (index < 0) return;

    final updatedPots = List<MoneyPot>.from(_currentAccount.moneyPots);
    updatedPots[index] = pot;
    await updateMoneyPots(updatedPots);
  }

  /// Remove a money pot from the current account
  Future<void> removeMoneyPot(String id) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedPots = _currentAccount.moneyPots.where((p) => p.id != id).toList();
    await updateMoneyPots(updatedPots);
  }


  Future<void> _updateAccountSetting(Account Function(Account) updater, {bool syncToAll = false}) async {
    final persistence = _persistence;
    if (persistence == null) return;

    if (syncToAll) {
      await _accountQueue.enqueue(() async {
        final List<Account> updatedAccounts = _accounts.map((account) {
          return updater(account).copyWith(lastModified: DateTime.now());
        }).toList();

        await persistence.saveAccounts(updatedAccounts);
        _accounts = List.unmodifiable(updatedAccounts);
        
        // Find current account in the updated list
        final currentIndex = updatedAccounts.indexWhere((a) => a.id == _currentAccount.id);
        if (currentIndex >= 0) {
          _currentAccount = updatedAccounts[currentIndex];
        }
        
        notifyListeners();
      });
    } else {
      final updatedAccount = updater(_currentAccount).copyWith(lastModified: DateTime.now());
      await _updateCurrentAccount(updatedAccount, persistence);
    }
  }

  Future<void> _updateCurrentAccount(Account updatedAccount, ExpensePersistence persistence) async {
    await _accountQueue.enqueue(() async {
      final index = _accounts.indexWhere((a) => a.id == updatedAccount.id);
      if (index < 0) return;

      final List<Account> updatedAccounts = List.from(_accounts);
      updatedAccounts[index] = updatedAccount;

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);
      _currentAccount = updatedAccount;

      notifyListeners();
    });
  }

  /// Update settings for a specific account (not necessarily the current one).
  /// This is used by the Account Settings section in Options to edit any account.
  Future<void> updateAccountSettings(
    AccountId accountId, {
    int? paycheckDay,
    bool? clearPaycheckDay,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    PlannerSortOrder? plannerSortOrder,
    PlannerDateSortMode? plannerDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    PlannerViewMode? plannerViewMode,
    bool? plannerShowClearedItems,
    bool? plannerGroupByDate,
    bool? plannerGroupByTheme,
    bool? plannerShowPaymentOrigin,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    DayFormat? dayFormat,
    PlannerSwipeAction? plannerSwipeLeft,
    PlannerSwipeAction? plannerSwipeRight,
    PlannerTapAction? plannerTapAction,
    PaymentSwipeAction? paymentSwipeLeft,
    PaymentSwipeAction? paymentSwipeRight,
    PaymentDisplayMode? paymentDisplayMode,
    bool? enableTabSwipe,
    bool? plannerUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PaymentsFilterType? paymentsFilterType,
    PaymentsGroupBy? paymentsGroupBy,
    bool? paymentsShowArchived,
    CategoryPresetMode? categoryPresetMode,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    await _accountQueue.enqueue(() async {
      final index = _accounts.indexWhere((a) => a.id == accountId);
      if (index < 0) return;

      final account = _accounts[index];
      final updatedAccount = account.copyWith(
        paycheckDay: paycheckDay ?? account.paycheckDay,
        clearPaycheckDay: clearPaycheckDay ?? false,
        paycheckBusinessAdjust: paycheckBusinessAdjust ?? account.paycheckBusinessAdjust,
        paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection ?? account.paycheckBusinessAdjustDirection,
        startingBalanceCents: startingBalanceCents ?? account.startingBalanceCents,
        plannerSortOrder: plannerSortOrder ?? account.plannerSortOrder,
        plannerDateSortMode: plannerDateSortMode ?? account.plannerDateSortMode,
        viewPeriodMode: viewPeriodMode ?? account.viewPeriodMode,
        plannerViewMode: plannerViewMode ?? account.plannerViewMode,
        plannerShowClearedItems: plannerShowClearedItems ?? account.plannerShowClearedItems,
        plannerGroupByDate: plannerGroupByDate ?? account.plannerGroupByDate,
        plannerGroupByTheme: plannerGroupByTheme ?? account.plannerGroupByTheme,
        plannerShowPaymentOrigin: plannerShowPaymentOrigin ?? account.plannerShowPaymentOrigin,
        monthTotalsDisplayMode: monthTotalsDisplayMode ?? account.monthTotalsDisplayMode,
        monthCardDisplayMode: monthCardDisplayMode ?? account.monthCardDisplayMode,
        multiMonthDisplayMode: multiMonthDisplayMode ?? account.multiMonthDisplayMode,
        dayFormat: dayFormat ?? account.dayFormat,
        plannerSwipeLeft: plannerSwipeLeft ?? account.plannerSwipeLeft,
        plannerSwipeRight: plannerSwipeRight ?? account.plannerSwipeRight,
        plannerTapAction: plannerTapAction ?? account.plannerTapAction,
        paymentSwipeLeft: paymentSwipeLeft ?? account.paymentSwipeLeft,
        paymentSwipeRight: paymentSwipeRight ?? account.paymentSwipeRight,
        paymentDisplayMode: paymentDisplayMode ?? account.paymentDisplayMode,
        enableTabSwipe: enableTabSwipe ?? account.enableTabSwipe,
        plannerUseZeroBaseline: plannerUseZeroBaseline ?? account.plannerUseZeroBaseline,
        terminologyPreset: terminologyPreset ?? account.terminologyPreset,
        paymentsFilterType: paymentsFilterType ?? account.paymentsFilterType,
        paymentsGroupBy: paymentsGroupBy ?? account.paymentsGroupBy,
        paymentsShowArchived: paymentsShowArchived ?? account.paymentsShowArchived,
        categoryPresetMode: categoryPresetMode ?? account.categoryPresetMode,
        lastModified: DateTime.now(),
      );

      final List<Account> updatedAccounts = List.from(_accounts);
      updatedAccounts[index] = updatedAccount;

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      // If this is the current account, update it too
      if (accountId == _currentAccount.id) {
        _currentAccount = updatedAccount;
      }

      notifyListeners();
    });
  }

  /// Get an account by ID (or null if not found)
  Account? getAccountById(AccountId accountId) {
    final index = _accounts.indexWhere((a) => a.id == accountId);
    return index >= 0 ? _accounts[index] : null;
  }

  List<PlannerItem>? _cachedActivePlannerItems;
  List<PlannerItem>? _cachedArchivedPlannerItems;
  List<PaymentEntry>? _cachedSelectedMonthPayments;
  String? _cachedPaymentsCacheKey;
  
  // Cache for getUserCategories results
  List<String>? _cachedUserIncomeCategories;
  List<String>? _cachedUserExpenseCategories;
  int _cachedCategoriesItemsHash = -1;
  int _cachedCategoriesPaymentsHash = -1;
  
  // Cache for paymentsForMonth - store by month key
  final Map<String, List<PaymentEntry>> _paymentsForMonthCache = {};
  
  final Map<PlannerItemId, Timer> _recentlyClearedTimers = {};
  final Set<PlannerItemId> _recentlyClearedPlannerItemIds = {};

  // Debounce duration for saving to persistence. Named to document intent.
  static const Duration _kSaveDebounce = AppConstants.saveDebounceDuration;
  static const Duration _kClearedVisibleDuration = Duration(seconds: 5);

  /// Replace an item with the same `id` in [list] or add it if missing.
  /// Returns a new unmodifiable list.
  static List<T> _replaceOrAddById<T, ID>(List<T> list, T item, ID Function(T) idOf) {
    final index = list.indexWhere((e) => idOf(e) == idOf(item));
    final next = list.toList(growable: true);
    if (index >= 0) {
      next[index] = item;
    } else {
      next.add(item);
    }
    return List.unmodifiable(next);
  }

  void setSelectedMonth(DateTime month) {
    final next = monthOnly(month);
    if (_selectedMonth.year == next.year && _selectedMonth.month == next.month) {
      return;
    }
    _selectedMonth = next;
    _touch();
  }

  List<PlannerItem> get plannerItems => _plannerItems;

  /// Returns all active (non-archived) planner items.
  List<PlannerItem> get activePlannerItems {
    _ensureCachesValid();
    return _cachedActivePlannerItems ??=
        _plannerItems.where((p) => !p.archived).toList(growable: false);
  }

  List<PlannerItem> get archivedPlannerItems {
    _ensureCachesValid();
    return _cachedArchivedPlannerItems ??=
        _plannerItems.where((p) => p.archived).toList(growable: false);
  }

  List<PaymentEntry> get payments => _payments;

  Set<PlannerItemId> get recentlyClearedPlannerItemIds =>
      Set.unmodifiable(_recentlyClearedPlannerItemIds);

  List<PaymentEntry> paymentsForMonth(DateTime month, {PeriodInfo? periodInfo}) {
    String cacheKey;
    
    if (periodInfo != null) {
      cacheKey = '${periodInfo.start.millisecondsSinceEpoch}_${periodInfo.end.millisecondsSinceEpoch}';
    } else {
      final m = monthOnly(month);
      cacheKey = '${m.year}${m.month.toString().padLeft(2, '0')}';
    }
    
    // Return cached result if available
    if (_paymentsForMonthCache.containsKey(cacheKey)) {
      return _paymentsForMonthCache[cacheKey]!;
    }
    
    // Compute and cache
    final result = periodInfo != null
        ? (_payments
            .where((p) => !p.date.isBefore(periodInfo.start) && !p.date.isAfter(periodInfo.end))
            .toList(growable: false)
          ..sort((a, b) => b.date.compareTo(a.date)))
        : (_payments
            .where((p) => p.date.year == monthOnly(month).year && p.date.month == monthOnly(month).month)
            .toList(growable: false)
          ..sort((a, b) => b.date.compareTo(a.date)));
    
    _paymentsForMonthCache[cacheKey] = result;
    return result;
  }

  List<PaymentEntry> paymentsForSelectedMonth({PeriodInfo? periodInfo}) {
    final cacheKey = periodInfo != null 
        ? '${periodInfo.start.millisecondsSinceEpoch}_${periodInfo.end.millisecondsSinceEpoch}'
        : '${_selectedMonth.year}${_selectedMonth.month.toString().padLeft(2, '0')}';
    
    _ensureCachesValid();
    
    if (_cachedSelectedMonthPayments != null &&
        _cachedPaymentsCacheKey == cacheKey) {
      return _cachedSelectedMonthPayments!;
    }

    _cachedPaymentsCacheKey = cacheKey;
    _cachedSelectedMonthPayments = paymentsForMonth(_selectedMonth, periodInfo: periodInfo);
    return _cachedSelectedMonthPayments!;
  }
  
  void invalidatePaymentsCache() {
    if (_cacheDirty) return;
    _cacheDirty = true;
    _paymentsForMonthCache.clear(); // Clear month-based payments cache
    _cachedCategoriesItemsHash = -1; // Invalidate categories cache
    _cachedCategoriesPaymentsHash = -1;
    notifyListeners();
  }

  int plannedTotalCentsForSelectedMonth() {
    return activePlannerItems.fold(0, (sum, p) => sum + p.amountMinorUnits);
  }

  int paidTotalCentsForSelectedMonth() {
    return paymentsForSelectedMonth().fold(0, (sum, p) => sum + p.amountMinorUnits);
  }

  List<String> getUserCategories({required bool isIncome}) {
    // Compute hash of items and payments to detect changes
    int itemsHash = 0;
    for (final item in _plannerItems) {
      itemsHash ^= item.id.hashCode ^ item.category.hashCode;
    }
    int paymentsHash = 0;
    for (final p in _payments) {
      paymentsHash ^= p.id.hashCode ^ p.category.hashCode;
    }
    
    // Return cached result if hashes match
    if (isIncome) {
      if (_cachedUserIncomeCategories != null &&
          _cachedCategoriesItemsHash == itemsHash &&
          _cachedCategoriesPaymentsHash == paymentsHash) {
        return _cachedUserIncomeCategories!;
      }
    } else {
      if (_cachedUserExpenseCategories != null &&
          _cachedCategoriesItemsHash == itemsHash &&
          _cachedCategoriesPaymentsHash == paymentsHash) {
        return _cachedUserExpenseCategories!;
      }
    }
    
    // Update hash
    _cachedCategoriesItemsHash = itemsHash;
    _cachedCategoriesPaymentsHash = paymentsHash;
    
    // Compute categories
    final categories = <String>{};
    
    // Add explicitly configured custom categories first
    if (isIncome) {
      categories.addAll(_currentAccount.customIncomeCategories);
    } else {
      categories.addAll(_currentAccount.customExpenseCategories);
    }

    for (final item in _plannerItems) {
      if (item.type.isIncomeType == isIncome) {
        final cat = item.category;
        if (cat != null && cat.isNotEmpty) {
          categories.add(cat);
        }
      }
    }
    for (final payment in _payments) {
      if (payment.type.isIncomeType == isIncome) {
        if (payment.category != null && payment.category!.isNotEmpty) {
          categories.add(payment.category!);
        }
      }
    }
    
    final result = categories.toList()..sort();
    
    // Cache result
    if (isIncome) {
      _cachedUserIncomeCategories = result;
    } else {
      _cachedUserExpenseCategories = result;
    }
    
    return result;
  }

  void goToPreviousMonth() {
    _selectedMonth = monthOnly(DateTime.utc(_selectedMonth.year, _selectedMonth.month - 1));
    _touch();
  }

  void goToNextMonth() {
    _selectedMonth = monthOnly(DateTime.utc(_selectedMonth.year, _selectedMonth.month + 1));
    _touch();
  }

  void upsertPlannerItem(PlannerItem item) {
    _plannerItems = _replaceOrAddById<PlannerItem, PlannerItemId>(_plannerItems, item, (p) => p.id);
    _touch();
  }

  void setPlannerItemArchived(PlannerItemId id, bool archived) {
    final index = _plannerItems.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final next = _plannerItems.toList(growable: true);
    next[index] = next[index].copyWith(archived: archived);
    _plannerItems = List.unmodifiable(next);

    if (!archived) {
      _payments = List.unmodifiable(_payments.where((p) => p.plannerItemId != id));
    }
    _touch();
  }

  void deletePlannerItem(PlannerItemId id) {
    _plannerItems = List.unmodifiable(_plannerItems.where((p) => p.id != id));
    _payments = List.unmodifiable(_payments.where((p) => p.plannerItemId != id));
    _touch();
  }

  void upsertPayment(PaymentEntry entry) {
    final normalized = entry.copyWith(date: dateOnly(entry.date));
    _payments = _replaceOrAddById<PaymentEntry, EntryId>(_payments, normalized, (p) => p.id);
    _touch();
  }

  void markPlannerItemClearedTemporarily(PlannerItemId id, {Duration? duration}) {
    _recentlyClearedPlannerItemIds.add(id);
    _recentlyClearedTimers.remove(id)?.cancel();
    _recentlyClearedTimers[id] = Timer(
      duration ?? _kClearedVisibleDuration,
      () {
        if (_recentlyClearedPlannerItemIds.remove(id)) {
          notifyListeners();
        }
        _recentlyClearedTimers.remove(id)?.cancel();
      },
    );
    notifyListeners();
  }

  void clearPlannerItemClearedTemporarily(PlannerItemId id) {
    _recentlyClearedTimers.remove(id)?.cancel();
    if (_recentlyClearedPlannerItemIds.remove(id)) {
      notifyListeners();
    }
  }

  void deletePayment(EntryId id) {
    _payments = List.unmodifiable(_payments.where((p) => p.id != id));
    _touch();
  }

  void clearAllData() {
    _selectedMonth = monthOnly(DateTime.now());
    _plannerItems = const [];
    _payments = const [];
    _touch(forceImmediate: true);
  }

  ExpenseSnapshot createSnapshot() => _snapshot();

  Future<bool> importSnapshot(ExpenseSnapshot snapshot) async {
    try {
      final persistence = _persistence ?? await ExpensePersistence.create();
      if (!persistence.validateSnapshot(snapshot)) return false;

      _selectedMonth = monthOnly(snapshot.selectedMonth);
      _plannerItems = List.unmodifiable(snapshot.plannerItems);
      _payments = List.unmodifiable(snapshot.payments);
      _touch(forceImmediate: true);
      return true;
    } catch (error, stackTrace) {
      debugLog(LogCategory.persistence, 'Failed to import snapshot', error: error, stackTrace: stackTrace);
      return false;
    }
  }

  void _ensureCachesValid() {
    if (!_cacheDirty) return;
    _cachedActivePlannerItems = null;
    _cachedArchivedPlannerItems = null;
    _cachedSelectedMonthPayments = null;
    _cachedPaymentsCacheKey = null;
    _paymentsForMonthCache.clear();
    _cachedUserIncomeCategories = null;
    _cachedUserExpenseCategories = null;
    _cachedCategoriesItemsHash = -1;
    _cachedCategoriesPaymentsHash = -1;
    _cacheDirty = false;
  }

  void _touch({bool forceImmediate = false}) {
    _cacheDirty = true;
    notifyListeners();
    if (forceImmediate) {
      saveNow();
    } else {
      _scheduleSave();
    }
  }

  void _scheduleSave() {
    final persistence = _persistence;
    if (persistence == null) return;

    final accountId = _currentAccount.id;
    _debounceTimer?.cancel();
    _debounceTimer = Timer(_kSaveDebounce, () {
      _saveQueue.enqueue(() async {
        try {
          await persistence.save(accountId, _snapshot());
        } catch (error, stackTrace) {
          debugLog(LogCategory.persistence, 'Failed to save snapshot for account $accountId', error: error, stackTrace: stackTrace);
          ErrorTracker.instance.trackError(ErrorContext(
            category: 'persistence',
            message: 'Failed to save account $accountId',
            severity: ErrorSeverity.error,
            error: error,
            additionalData: {'stack': stackTrace.toString()},
          ));
        }
      });
    });
  }

  ExpenseSnapshot _snapshot() => ExpenseSnapshot(
    selectedMonth: _selectedMonth,
    plannerItems: _plannerItems,
    payments: _payments,
    accountSettings: _currentAccount,
  );

  @override
  void dispose() {
    final persistence = _persistence;
    
    _debounceTimer?.cancel();
    for (final timer in _recentlyClearedTimers.values) timer.cancel();
    _recentlyClearedTimers.clear();
    
    // CRITICAL: Ensure any pending changes are saved before disposing.
    // If a payment was just added and the 2-second debounce timer hasn't fired yet,
    // we must save immediately to prevent data loss when the app closes.
    if (persistence != null) {
      final accountId = _currentAccount.id;
      _saveQueue.enqueue(() => persistence.save(accountId, _snapshot()));
    }
    
    super.dispose();
  }
}

class ExpenseStoreScope extends InheritedNotifier<ExpenseStore> {
  const ExpenseStoreScope({super.key, required ExpenseStore store, required super.child}) : super(notifier: store);

  static ExpenseStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<ExpenseStoreScope>();
    if (scope == null) {
      throw StateError('ExpenseStoreScope not found in widget tree.');
    }
    return scope.notifier!;
  }

  static ExpenseStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<ExpenseStoreScope>();
    if (scope == null) {
      throw StateError('ExpenseStoreScope not found in widget tree.');
    }
    return scope.notifier!;
  }
}
