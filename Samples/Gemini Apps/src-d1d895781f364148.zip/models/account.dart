import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/account_settings.dart';

class Account extends Equatable {
  final AccountId id;
  final String name;
  final DateTime createdAt;
  final DateTime lastModified;
  final bool isTestData;
  final int? iconCodePoint; // Material icon code point for custom icons
  
  // Encapsulated Settings
  final AccountSettings settings;
  
  // Money Pots (can be account-specific or global based on settings)
  final List<MoneyPot> moneyPots;
  
  // Delegated Getters for backward compatibility and ease of use
  int? get paycheckDay => settings.paycheckDay;
  bool get paycheckBusinessAdjust => settings.paycheckBusinessAdjust;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection => settings.paycheckBusinessAdjustDirection;
  int get startingBalanceCents => settings.startingBalanceCents;
  PlannerSortOrder get plannerSortOrder => settings.plannerSortOrder;
  PlannerDateSortMode get plannerDateSortMode => settings.plannerDateSortMode;
  ViewPeriodMode get viewPeriodMode => settings.viewPeriodMode;
  PlannerViewMode get plannerViewMode => settings.plannerViewMode;
  bool get plannerShowClearedItems => settings.plannerShowClearedItems;
  bool get plannerGroupByDate => settings.plannerGroupByDate;
  bool get plannerGroupByTheme => settings.plannerGroupByTheme;
  bool get plannerShowPaymentOrigin => settings.plannerShowPaymentOrigin;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => settings.monthTotalsDisplayMode;
  MonthCardDisplayMode get monthCardDisplayMode => settings.monthCardDisplayMode;
  MultiMonthDisplayMode get multiMonthDisplayMode => settings.multiMonthDisplayMode;
  DayFormat get dayFormat => settings.dayFormat;
  PlannerSwipeAction get plannerSwipeLeft => settings.plannerSwipeLeft;
  PlannerSwipeAction get plannerSwipeRight => settings.plannerSwipeRight;
  PlannerTapAction get plannerTapAction => settings.plannerTapAction;
  PaymentSwipeAction get paymentSwipeLeft => settings.paymentSwipeLeft;
  PaymentSwipeAction get paymentSwipeRight => settings.paymentSwipeRight;
  PaymentDisplayMode get paymentDisplayMode => settings.paymentDisplayMode;
  bool get enableTabSwipe => settings.enableTabSwipe;
  bool get plannerUseZeroBaseline => settings.plannerUseZeroBaseline;
  TerminologyPreset get terminologyPreset => settings.terminologyPreset;
  PaymentsFilterType get paymentsFilterType => settings.paymentsFilterType;
  PaymentsGroupBy get paymentsGroupBy => settings.paymentsGroupBy;
  bool get paymentsShowArchived => settings.paymentsShowArchived;
  CategoryPresetMode get categoryPresetMode => settings.categoryPresetMode;
  List<String> get customExpenseCategories => settings.customExpenseCategories;
  List<String> get customIncomeCategories => settings.customIncomeCategories;
  String? get moneyPotsSectionLabel => settings.moneyPotsSectionLabel;

  const Account({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.lastModified,
    this.isTestData = false,
    this.iconCodePoint,
    this.settings = const AccountSettings(),
    this.moneyPots = const [],
  });

  factory Account.create({
    required String name,
    bool isTestData = false,
    int? iconCodePoint,
    // Flattened arguments for convenience (delegated to settings)
    int? paycheckDay,
    bool paycheckBusinessAdjust = false,
    PaycheckAdjustDirection paycheckBusinessAdjustDirection = PaycheckAdjustDirection.before,
    int startingBalanceCents = 0,
    PlannerSortOrder plannerSortOrder = PlannerSortOrder.chronological,
    PlannerDateSortMode plannerDateSortMode = PlannerDateSortMode.scheduledDate,
    ViewPeriodMode viewPeriodMode = ViewPeriodMode.calendar,
    PlannerViewMode plannerViewMode = PlannerViewMode.month,
    bool plannerShowClearedItems = true,
    bool plannerGroupByDate = false,
    bool plannerGroupByTheme = false,
    bool plannerShowPaymentOrigin = false,
    MonthTotalsDisplayMode monthTotalsDisplayMode = MonthTotalsDisplayMode.includeCleared,
    MonthCardDisplayMode monthCardDisplayMode = MonthCardDisplayMode.full,
    MultiMonthDisplayMode multiMonthDisplayMode = MultiMonthDisplayMode.automatic,
    DayFormat dayFormat = DayFormat.number,
    PlannerSwipeAction plannerSwipeLeft = PlannerSwipeAction.off,
    PlannerSwipeAction plannerSwipeRight = PlannerSwipeAction.off,
    PlannerTapAction plannerTapAction = PlannerTapAction.archive,
    PaymentSwipeAction paymentSwipeLeft = PaymentSwipeAction.off,
    PaymentSwipeAction paymentSwipeRight = PaymentSwipeAction.off,
    PaymentDisplayMode paymentDisplayMode = PaymentDisplayMode.automatic,
    bool enableTabSwipe = false,
    bool plannerUseZeroBaseline = false,
    TerminologyPreset terminologyPreset = TerminologyPreset.defaultTerms,
    PaymentsFilterType paymentsFilterType = PaymentsFilterType.all,
    PaymentsGroupBy paymentsGroupBy = PaymentsGroupBy.none,
    bool paymentsShowArchived = false,
    CategoryPresetMode categoryPresetMode = CategoryPresetMode.defaultPresets,
    List<String> customExpenseCategories = const [],
    List<String> customIncomeCategories = const [],
    List<MoneyPot> moneyPots = const [],
    String? moneyPotsSectionLabel,
  }) {
    final now = DateTime.now();
    return Account(
      id: newAccountId(),
      name: name,
      createdAt: now,
      lastModified: now,
      isTestData: isTestData,
      iconCodePoint: iconCodePoint,
      moneyPots: moneyPots,
      settings: AccountSettings(
        paycheckDay: paycheckDay,
        paycheckBusinessAdjust: paycheckBusinessAdjust,
        paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
        startingBalanceCents: startingBalanceCents,
        plannerSortOrder: plannerSortOrder,
        plannerDateSortMode: plannerDateSortMode,
        viewPeriodMode: viewPeriodMode,
        plannerViewMode: plannerViewMode,
        plannerShowClearedItems: plannerShowClearedItems,
        plannerGroupByDate: plannerGroupByDate,
        plannerGroupByTheme: plannerGroupByTheme,
        plannerShowPaymentOrigin: plannerShowPaymentOrigin,
        monthTotalsDisplayMode: monthTotalsDisplayMode,
        monthCardDisplayMode: monthCardDisplayMode,
        multiMonthDisplayMode: multiMonthDisplayMode,
        dayFormat: dayFormat,
        plannerSwipeLeft: plannerSwipeLeft,
        plannerSwipeRight: plannerSwipeRight,
        plannerTapAction: plannerTapAction,
        paymentSwipeLeft: paymentSwipeLeft,
        paymentSwipeRight: paymentSwipeRight,
        paymentDisplayMode: paymentDisplayMode,
        enableTabSwipe: enableTabSwipe,
        plannerUseZeroBaseline: plannerUseZeroBaseline,
        terminologyPreset: terminologyPreset,
        paymentsFilterType: paymentsFilterType,
        paymentsGroupBy: paymentsGroupBy,
        paymentsShowArchived: paymentsShowArchived,
        categoryPresetMode: categoryPresetMode,
        customExpenseCategories: customExpenseCategories,
        customIncomeCategories: customIncomeCategories,
        moneyPotsSectionLabel: moneyPotsSectionLabel,
      ),
    );
  }

  Account copyWith({
    String? name,
    DateTime? lastModified,
    bool? isTestData,
    int? iconCodePoint,
    bool clearIcon = false,
    // Delegated to settings.copyWith
    int? paycheckDay,
    bool clearPaycheckDay = false,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    PlannerSortOrder? plannerSortOrder,
    PlannerDateSortMode? plannerDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    PlannerViewMode? plannerViewMode,
    bool? plannerShowClearedItems,
    bool? plannerGroupByDate,
    bool? plannerGroupByTheme,
    bool? plannerShowPaymentOrigin,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    DayFormat? dayFormat,
    PlannerSwipeAction? plannerSwipeLeft,
    PlannerSwipeAction? plannerSwipeRight,
    PlannerTapAction? plannerTapAction,
    PaymentSwipeAction? paymentSwipeLeft,
    PaymentSwipeAction? paymentSwipeRight,
    PaymentDisplayMode? paymentDisplayMode,
    bool? enableTabSwipe,
    bool? plannerUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PaymentsFilterType? paymentsFilterType,
    PaymentsGroupBy? paymentsGroupBy,
    bool? paymentsShowArchived,
    CategoryPresetMode? categoryPresetMode,
    List<String>? customExpenseCategories,
    List<String>? customIncomeCategories,
    List<MoneyPot>? moneyPots,
    String? moneyPotsSectionLabel,
    bool clearMoneyPotsSectionLabel = false,
    // Direct settings override
    AccountSettings? settings,
  }) {
    // If a full settings object is provided, use it.
    // Otherwise, check if individual settings are updated and apply to current settings.
    final effectiveSettings = settings ?? this.settings.copyWith(
      paycheckDay: paycheckDay,
      clearPaycheckDay: clearPaycheckDay,
      paycheckBusinessAdjust: paycheckBusinessAdjust,
      paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
      startingBalanceCents: startingBalanceCents,
      plannerSortOrder: plannerSortOrder,
      plannerDateSortMode: plannerDateSortMode,
      viewPeriodMode: viewPeriodMode,
      plannerViewMode: plannerViewMode,
      plannerShowClearedItems: plannerShowClearedItems,
      plannerGroupByDate: plannerGroupByDate,
      plannerGroupByTheme: plannerGroupByTheme,
      plannerShowPaymentOrigin: plannerShowPaymentOrigin,
      monthTotalsDisplayMode: monthTotalsDisplayMode,
      monthCardDisplayMode: monthCardDisplayMode,
      multiMonthDisplayMode: multiMonthDisplayMode,
      dayFormat: dayFormat,
      plannerSwipeLeft: plannerSwipeLeft,
      plannerSwipeRight: plannerSwipeRight,
      plannerTapAction: plannerTapAction,
      paymentSwipeLeft: paymentSwipeLeft,
      paymentSwipeRight: paymentSwipeRight,
      paymentDisplayMode: paymentDisplayMode,
      enableTabSwipe: enableTabSwipe,
      plannerUseZeroBaseline: plannerUseZeroBaseline,
      terminologyPreset: terminologyPreset,
      paymentsFilterType: paymentsFilterType,
      paymentsGroupBy: paymentsGroupBy,
      paymentsShowArchived: paymentsShowArchived,
      categoryPresetMode: categoryPresetMode,
      customExpenseCategories: customExpenseCategories,
      customIncomeCategories: customIncomeCategories,
      moneyPotsSectionLabel: moneyPotsSectionLabel,
      clearMoneyPotsSectionLabel: clearMoneyPotsSectionLabel,
    );

    return Account(
      id: id,
      name: name ?? this.name,
      createdAt: createdAt,
      lastModified: lastModified ?? this.lastModified,
      isTestData: isTestData ?? this.isTestData,
      iconCodePoint: clearIcon ? null : (iconCodePoint ?? this.iconCodePoint),
      moneyPots: moneyPots ?? this.moneyPots,
      settings: effectiveSettings,
    );
  }

  /// Whether paycheck mode is configured for this account
  bool get isPaycheckModeConfigured => settings.isPaycheckModeConfigured;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'lastModified': lastModified.millisecondsSinceEpoch,
      'isTestData': isTestData,
      'iconCodePoint': iconCodePoint,
      'settings': settings.toJson(),
      'moneyPots': moneyPots.map((p) => p.toJson()).toList(),
    };
  }

  factory Account.fromJson(Map<String, dynamic> json) {
    // Determine if we are loading legacy (flat) JSON or new (nested) JSON
    final settingsJson = json['settings'];
    final AccountSettings settings;
    
    if (settingsJson is Map<String, dynamic>) {
      // New format
      settings = AccountSettings.fromJson(settingsJson);
    } else {
      // Legacy format: pass the whole JSON to AccountSettings.fromJson
      // This works because the legacy JSON has the fields at root, which the
      // AccountSettings.fromJson parser will look for.
      settings = AccountSettings.fromJson(json);
    }

    return Account(
      id: AccountId(json['id'] as String? ?? newIdRaw()),
      name: json['name'] as String? ?? 'Untitled Account',
      createdAt: DateTime.fromMillisecondsSinceEpoch(json['createdAt'] as int? ?? DateTime.now().millisecondsSinceEpoch),
      lastModified: DateTime.fromMillisecondsSinceEpoch(json['lastModified'] as int? ?? DateTime.now().millisecondsSinceEpoch),
      isTestData: json['isTestData'] as bool? ?? false,
      iconCodePoint: json['iconCodePoint'] as int?,
      moneyPots: _parseMoneyPots(json['moneyPots']),
      settings: settings,
    );
  }

  static List<MoneyPot> _parseMoneyPots(dynamic value) {
    if (value is List) {
      return value
          .map((e) {
            try {
              return MoneyPot.fromJson(e as Map<String, dynamic>);
            } catch (_) {
              return null;
            }
          })
          .whereType<MoneyPot>()
          .toList();
    }
    return const [];
  }

  @override
  List<Object?> get props => [
    id, name, createdAt, lastModified, isTestData, iconCodePoint,
    settings, moneyPots,
  ];
}
