import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/util/debt_calculator.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum RecurrenceFrequency {
  weekly('Weekly'),
  biweekly('Bi-weekly'),
  monthly('Monthly'),
  quarterly('Quarterly'),
  yearly('Yearly');

  const RecurrenceFrequency(this.label);
  final String label;
}

class PlannerItem extends Equatable {
  const PlannerItem({
    required this.id,
    required this.label,
    required this.amountMinorUnits,
    required this.dayOfMonth,
    required this.type,
    required this.startDate,
    this.frequency,
    this.notes,
    this.archived = false,
    this.paidOffDate,
    this.remainingBalanceMinorUnits,
    this.originalAmountMinorUnits,
    this.category,
    this.company,
    this.isSalary = false,
    this.useAsPaycheckBoundary = false,
    this.moneyPotId,
    this.isQuickAdd = false,
    this.balanceCurrency,
    this.exchangeRate,
    this.useActualsForBalance = false,
  });

  final PlannerItemId id;
  final String label;
  final int amountMinorUnits;
  final int dayOfMonth;
  final DateTime startDate;
  final String? notes;
  final PaymentType type;
  final RecurrenceFrequency? frequency;
  final bool archived;
  final DateTime? paidOffDate;
  final int? remainingBalanceMinorUnits;
  final int? originalAmountMinorUnits;

  /// Optional category for organizing items (e.g., "Housing", "Food", "Salary").
  /// Unified with PaymentEntry category handling.
  final String? category;

  /// Optional company/provider name (e.g., "Electric Co", "Comcast", "Acme Corp").
  /// Tracks the source or destination of the payment.
  final String? company;

  /// Whether this income item is a primary salary source.
  /// Used to identify salary payments and optionally sync paycheck period settings.
  /// Only meaningful for recurringIncome type items.
  final bool isSalary;

  /// Whether this salary defines a paycheck period boundary.
  /// Multiple salaries can be boundaries simultaneously (e.g., dual-income households).
  /// Only meaningful for recurringIncome type items marked as isSalary.
  final bool useAsPaycheckBoundary;

  /// ID of the Money Pot linked to this planner item.
  /// If set, the item's remaining balance may be synced with the pot.
  final MoneyPotId? moneyPotId;

  /// Whether this item should appear in the "Quick Add" menu on the planner screen.
  final bool isQuickAdd;

  /// Currency code for the remaining balance (e.g., usd, eur).
  /// If null, the balance is in the app's default currency.
  final AppCurrency? balanceCurrency;

  /// Exchange rate: how many balance currency units per 1 payment currency unit.
  /// Example: If loan is in USD and you pay in EUR, rate of 1.08 means 1 EUR = 1.08 USD.
  /// Used in payoff calculations to convert payment amounts.
  final double? exchangeRate;

  /// Whether to use the actual amount spent (sum of payments) instead of the
  /// full envelope amount when calculating the starting balance for future months.
  ///
  /// If true:
  /// - Current month: Full amount is still deducted (to show remaining budget)
  /// - Future months: Only actual spent amount from previous months is deducted
  ///
  /// If false (default):
  /// - Full amount is always deducted (standard "set aside" logic)
  final bool useActualsForBalance;

  PlannerItem copyWith({
    String? label,
    int? amountMinorUnits,
    int? dayOfMonth,
    DateTime? startDate,
    Optional<String>? notes,
    PaymentType? type,
    Optional<RecurrenceFrequency>? frequency,
    bool? archived,
    Optional<DateTime>? paidOffDate,
    Optional<int>? remainingBalanceMinorUnits,
    Optional<int>? originalAmountMinorUnits,
    Optional<String>? category,
    Optional<String>? company,
    bool? isSalary,
    bool? useAsPaycheckBoundary,
    Optional<MoneyPotId>? moneyPotId,
    bool? isQuickAdd,
    Optional<AppCurrency>? balanceCurrency,
    Optional<double>? exchangeRate,
    bool? useActualsForBalance,
  }) {
    return PlannerItem(
      id: id,
      label: label ?? this.label,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      dayOfMonth: dayOfMonth ?? this.dayOfMonth,
      startDate: startDate ?? this.startDate,
      notes: notes != null ? notes.value : this.notes,
      type: type ?? this.type,
      frequency: frequency != null ? frequency.value : this.frequency,
      archived: archived ?? this.archived,
      paidOffDate: paidOffDate != null ? paidOffDate.value : this.paidOffDate,
      remainingBalanceMinorUnits: remainingBalanceMinorUnits != null
          ? remainingBalanceMinorUnits.value
          : this.remainingBalanceMinorUnits,
      originalAmountMinorUnits: originalAmountMinorUnits != null
          ? originalAmountMinorUnits.value
          : this.originalAmountMinorUnits,
      category: category != null ? category.value : this.category,
      company: company != null ? company.value : this.company,
      isSalary: isSalary ?? this.isSalary,
      useAsPaycheckBoundary:
          useAsPaycheckBoundary ?? this.useAsPaycheckBoundary,
      moneyPotId: moneyPotId != null ? moneyPotId.value : this.moneyPotId,
      isQuickAdd: isQuickAdd ?? this.isQuickAdd,
      balanceCurrency: balanceCurrency != null
          ? balanceCurrency.value
          : this.balanceCurrency,
      exchangeRate: exchangeRate != null ? exchangeRate.value : this.exchangeRate,
      useActualsForBalance: useActualsForBalance ?? this.useActualsForBalance,
    );
  }

  @override
  List<Object?> get props => [id, label, amountMinorUnits, dayOfMonth, startDate, notes, type, frequency, archived, paidOffDate, remainingBalanceMinorUnits, originalAmountMinorUnits, category, company, isSalary, useAsPaycheckBoundary, moneyPotId, isQuickAdd, balanceCurrency, exchangeRate, useActualsForBalance];

  /// Determines if this planner item should be displayed in a given month.
  ///
  /// Uses the `startDate` to determine when items should begin appearing.
  /// All items respect their start date - they won't appear before it.
  ///
  /// **Semantics by PaymentType:**
  /// - `oneOff`: Only appears in the month matching startDate
  /// - `debt`: Appears from startDate onwards until paid off
  /// - `recurring`: Appears based on frequency starting from startDate:
  ///   - `monthly`: Every month
  ///   - `quarterly`: Every 3 months on calendar quarter months
  ///   - `yearly`: Once per year
  ///   - `weekly`/`biweekly`: Every month (sub-monthly scheduling not yet supported)
  bool shouldAppearInMonth(DateTime month) {
    // Normalize to month-only for comparison (using UTC)
    final normalizedMonth = DateMath.toUtcMonth(month);
    final normalizedStart = DateMath.toUtcMonth(startDate);
    
    // Item shouldn't appear before its start date
    if (normalizedMonth.isBefore(normalizedStart)) {
      return false;
    }
    
    // One-off items only appear in their start month
    if (type == PaymentType.oneOff || type == PaymentType.oneOffIncome) {
      return normalizedMonth.year == normalizedStart.year &&
             normalizedMonth.month == normalizedStart.month;
    }
    
    // Debt items appear from start date until paid off
    if (type == PaymentType.debt) {
      if (paidOffDate != null) {
        final normalizedPaidOff = DateMath.toUtcMonth(paidOffDate!);
        return !normalizedMonth.isAfter(normalizedPaidOff);
      }

      if (remainingBalanceMinorUnits != null && remainingBalanceMinorUnits! <= 0) {
        return false;
      }
      
      // If no manual paid off date, use calculated final payment date
      final calculatedFinalDate = calculateFinalPaymentDate();
      if (calculatedFinalDate != null) {
        final normalizedFinalDate = DateMath.toUtcMonth(calculatedFinalDate);
        return !normalizedMonth.isAfter(normalizedFinalDate);
      }
      
      return true;
    }
    
    // Spending envelopes and recurring items depend on frequency
    // Both follow the same appearance logic based on their frequency setting
    if (type == PaymentType.spendingEnvelope || 
        type == PaymentType.recurring || 
        type == PaymentType.recurringIncome) {
      if (frequency == null) {
        // No frequency specified, appear every month
        return true;
      }
      
      final monthsSinceStart = (normalizedMonth.year - normalizedStart.year) * 12 +
                               (normalizedMonth.month - normalizedStart.month);
      
      switch (frequency!) {
        case RecurrenceFrequency.weekly:
        case RecurrenceFrequency.biweekly:
        case RecurrenceFrequency.monthly:
          return true; // Appear every month
        case RecurrenceFrequency.quarterly:
          final firstQuarterlyDate = _firstQuarterlyPaymentDate();
          final normalizedFirst = DateMath.toUtcMonth(firstQuarterlyDate);
          if (normalizedMonth.isBefore(normalizedFirst)) return false;
          final monthsSinceFirst = month_math.monthsBetween(
            normalizedFirst,
            normalizedMonth,
          );
          return monthsSinceFirst % 3 == 0;
        case RecurrenceFrequency.yearly:
          return monthsSinceStart % 12 == 0;
      }
    }
    
    // Fallback: Recurring items depend on frequency (legacy path)
    
    final monthsSinceStart = (normalizedMonth.year - normalizedStart.year) * 12 +
                             (normalizedMonth.month - normalizedStart.month);
    
    switch (frequency!) {
      case RecurrenceFrequency.weekly:
      case RecurrenceFrequency.biweekly:
      case RecurrenceFrequency.monthly:
        return true; // Appear every month
      case RecurrenceFrequency.quarterly:
        final firstQuarterlyDate = _firstQuarterlyPaymentDate();
        final normalizedFirst = DateMath.toUtcMonth(firstQuarterlyDate);
        if (normalizedMonth.isBefore(normalizedFirst)) return false;
        final monthsSinceFirst = month_math.monthsBetween(
          normalizedFirst,
          normalizedMonth,
        );
        return monthsSinceFirst % 3 == 0;
      case RecurrenceFrequency.yearly:
        return monthsSinceStart % 12 == 0;
    }
  }

  /// Calculates the first quarterly payment date on or after [startDate].
  ///
  /// Quarterly months are: March (3), June (6), September (9), December (12).
  /// The formula `(3 - (month % 3)) % 3` gives months to next quarter:
  /// - Jan (1) → 2 months to Mar
  /// - Feb (2) → 1 month to Mar
  /// - Mar (3) → 0 months (already quarterly)
  /// - Apr (4) → 2 months to Jun
  /// - ...
  /// - Dec (12) → 0 months (already quarterly)
  ///
  /// Handles year transitions correctly via [month_math.addMonths].
  DateTime _firstQuarterlyPaymentDate() {
    final start = DateMath.toUtcDate(startDate);
    final startMonth = start.month;

    // Calculate months until the next quarterly month (Mar, Jun, Sep, Dec)
    final monthsToNextQuarter = (3 - (startMonth % 3)) % 3;
    final firstQuarterMonth = month_math.addMonths(
      DateTime.utc(start.year, start.month, 1),
      monthsToNextQuarter,
    );

    // Use effective day (handle months with fewer days, e.g., dayOfMonth=31 in Feb)
    final firstQuarterDay = _effectiveDayOfMonth(
      firstQuarterMonth.year,
      firstQuarterMonth.month,
    );

    var candidate = DateTime.utc(
      firstQuarterMonth.year,
      firstQuarterMonth.month,
      firstQuarterDay,
    );

    // Edge case: if the quarterly month matches but the day is before startDate's day,
    // we need to advance to the next quarter
    if (candidate.isBefore(start)) {
      final nextQuarterMonth = month_math.addMonths(
        DateTime.utc(candidate.year, candidate.month, 1),
        3,
      );
      final nextQuarterDay = _effectiveDayOfMonth(
        nextQuarterMonth.year,
        nextQuarterMonth.month,
      );
      candidate = DateTime.utc(
        nextQuarterMonth.year,
        nextQuarterMonth.month,
        nextQuarterDay,
      );
    }

    return candidate;
  }

  int _effectiveDayOfMonth(int year, int month) {
    final maxDay = DateTime.utc(year, month + 1, 0).day;
    return dayOfMonth <= maxDay ? dayOfMonth : maxDay;
  }

  /// Calculates the estimated final payment date for debt items.
  ///
  /// Returns null if:
  /// - Item is not a debt type
  /// - No remaining balance is set
  /// - Payment amount is zero or negative
  /// - No frequency is set
  /// - Calculated payoff exceeds 100 years (sanity check)
  ///
  /// The calculation assumes regular payments of `amountMinorUnits` at the
  /// specified `frequency` starting from the next scheduled occurrence
  /// on or after `fromDate` (defaults to now).
  DateTime? calculateFinalPaymentDate({DateTime? fromDate}) {
    return DebtCalculator.calculateFinalPaymentDate(
      type: type,
      remainingBalanceMinorUnits: remainingBalanceMinorUnits,
      amountMinorUnits: amountMinorUnits,
      frequency: frequency,
      startDate: startDate,
      exchangeRate: exchangeRate,
      fromDate: fromDate,
    );
  }

  /// Returns the progress percentage (0-100) of debt payment.
  ///
  /// Returns null if not applicable (not debt or no remaining balance set).
  /// Calculates progress as: (originalAmount - remainingBalance) / originalAmount * 100
  double? getDebtProgressPercentage() {
    if (type != PaymentType.debt || remainingBalanceMinorUnits == null) return null;
    if (remainingBalanceMinorUnits! <= 0) return 100.0;
    
    // If originalAmountMinorUnits is not set, fall back to using remainingBalance as original
    final original = originalAmountMinorUnits ?? remainingBalanceMinorUnits!;
    if (original <= 0) return 0.0;
    
    final paid = original - remainingBalanceMinorUnits!;
    final percentage = (paid / original) * 100.0;
    
    // Clamp between 0 and 100
    return percentage.clamp(0.0, 100.0);
  }
}
