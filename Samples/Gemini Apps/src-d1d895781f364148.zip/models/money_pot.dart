import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum MoneyPotType {
  savings,
  debt;

  String get id => name;
}

class MoneyPot {
  final MoneyPotId id;
  final String name;
  final int amountMinorUnits;
  final MoneyPotType type;
  final AppCurrency? currency;
  final List<AccountId>? accountIds; // null = global, non-empty = specific accounts

  const MoneyPot({
    required this.id,
    required this.name,
    required this.amountMinorUnits,
    required this.type,
    this.currency,
    this.accountIds,
  });

  factory MoneyPot.create({
    required String name,
    required int amountMinorUnits,
    required MoneyPotType type,
    AppCurrency? currency,
    List<AccountId>? accountIds,
  }) {
    return MoneyPot(
      id: newMoneyPotId(),
      name: name,
      amountMinorUnits: amountMinorUnits,
      type: type,
      currency: currency,
      accountIds: accountIds,
    );
  }

  MoneyPot copyWith({
    Object? name = sentinel,
    Object? amountMinorUnits = sentinel,
    Object? type = sentinel,
    Object? currency = sentinel,
    Object? accountIds = sentinel,
  }) {
    return MoneyPot(
      id: id,
      name: name == sentinel ? this.name : name as String,
      amountMinorUnits:
          amountMinorUnits == sentinel ? this.amountMinorUnits : amountMinorUnits as int,
      type: type == sentinel ? this.type : type as MoneyPotType,
      currency: currency == sentinel ? this.currency : currency as AppCurrency?,
      accountIds: accountIds == sentinel ? this.accountIds : accountIds as List<AccountId>?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'amountMinorUnits': amountMinorUnits,
      'type': type.id,
      'currency': currency?.name,
      'accountIds': accountIds,
    };
  }

  factory MoneyPot.fromJson(Map<String, dynamic> json) {
    return MoneyPot(
      id: MoneyPotId(json['id'] as String),
      name: json['name'] as String,
      amountMinorUnits: ((json['amountMinorUnits'] ??
              json['amountCents'] ??
              json['amount'] ??
              json['cents'] ??
              json['amount_minor_units'] ??
              0) as num)
          .toInt(),
      type: MoneyPotType.values.firstWhere(
        (e) => e.id == json['type'],
        orElse: () => MoneyPotType.savings,
      ),
      currency: decodeCurrency(json['currency']),
      accountIds: (json['accountIds'] as List?)?.map((e) => AccountId(e as String)).toList(),
    );
  }
}
