import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

class AccountSettings extends Equatable {
  // Paycheck Settings
  final int? paycheckDay;
  final bool paycheckBusinessAdjust;
  final PaycheckAdjustDirection paycheckBusinessAdjustDirection;
  
  // Balance Settings
  final int startingBalanceCents;

  // Planner View Settings
  final PlannerSortOrder plannerSortOrder;
  final PlannerDateSortMode plannerDateSortMode;
  final ViewPeriodMode viewPeriodMode;
  final PlannerViewMode plannerViewMode;
  final bool plannerShowClearedItems;
  final bool plannerGroupByDate;
  final bool plannerGroupByTheme;
  final bool plannerShowPaymentOrigin;
  
  // Display Modes
  final MonthTotalsDisplayMode monthTotalsDisplayMode;
  final MonthCardDisplayMode monthCardDisplayMode;
  final MultiMonthDisplayMode multiMonthDisplayMode;
  final DayFormat dayFormat;
  
  // Interaction Settings
  final PlannerSwipeAction plannerSwipeLeft;
  final PlannerSwipeAction plannerSwipeRight;
  final PlannerTapAction plannerTapAction;
  final PaymentSwipeAction paymentSwipeLeft;
  final PaymentSwipeAction paymentSwipeRight;
  final PaymentDisplayMode paymentDisplayMode;
  final bool enableTabSwipe;
  final bool plannerUseZeroBaseline;
  
  // Terminology & Categories
  final TerminologyPreset terminologyPreset;
  final PaymentsFilterType paymentsFilterType;
  final PaymentsGroupBy paymentsGroupBy;
  final bool paymentsShowArchived;
  final CategoryPresetMode categoryPresetMode;
  final List<String> customExpenseCategories;
  final List<String> customIncomeCategories;
  final String? moneyPotsSectionLabel;

  const AccountSettings({
    this.paycheckDay,
    this.paycheckBusinessAdjust = false,
    this.paycheckBusinessAdjustDirection = PaycheckAdjustDirection.before,
    this.startingBalanceCents = 0,
    this.plannerSortOrder = PlannerSortOrder.chronological,
    this.plannerDateSortMode = PlannerDateSortMode.scheduledDate,
    this.viewPeriodMode = ViewPeriodMode.calendar,
    this.plannerViewMode = PlannerViewMode.month,
    this.plannerShowClearedItems = true,
    this.plannerGroupByDate = false,
    this.plannerGroupByTheme = false,
    this.plannerShowPaymentOrigin = false,
    this.monthTotalsDisplayMode = MonthTotalsDisplayMode.includeCleared,
    this.monthCardDisplayMode = MonthCardDisplayMode.full,
    this.multiMonthDisplayMode = MultiMonthDisplayMode.automatic,
    this.dayFormat = DayFormat.number,
    this.plannerSwipeLeft = PlannerSwipeAction.off,
    this.plannerSwipeRight = PlannerSwipeAction.off,
    this.plannerTapAction = PlannerTapAction.archive,
    this.paymentSwipeLeft = PaymentSwipeAction.off,
    this.paymentSwipeRight = PaymentSwipeAction.off,
    this.paymentDisplayMode = PaymentDisplayMode.automatic,
    this.enableTabSwipe = false,
    this.plannerUseZeroBaseline = false,
    this.terminologyPreset = TerminologyPreset.defaultTerms,
    this.paymentsFilterType = PaymentsFilterType.all,
    this.paymentsGroupBy = PaymentsGroupBy.none,
    this.paymentsShowArchived = false,
    this.categoryPresetMode = CategoryPresetMode.defaultPresets,
    this.customExpenseCategories = const [],
    this.customIncomeCategories = const [],
    this.moneyPotsSectionLabel,
  });

  /// Whether paycheck mode is configured for this account
  bool get isPaycheckModeConfigured => paycheckDay != null;

  AccountSettings copyWith({
    int? paycheckDay,
    bool clearPaycheckDay = false,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    PlannerSortOrder? plannerSortOrder,
    PlannerDateSortMode? plannerDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    PlannerViewMode? plannerViewMode,
    bool? plannerShowClearedItems,
    bool? plannerGroupByDate,
    bool? plannerGroupByTheme,
    bool? plannerShowPaymentOrigin,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    DayFormat? dayFormat,
    PlannerSwipeAction? plannerSwipeLeft,
    PlannerSwipeAction? plannerSwipeRight,
    PlannerTapAction? plannerTapAction,
    PaymentSwipeAction? paymentSwipeLeft,
    PaymentSwipeAction? paymentSwipeRight,
    PaymentDisplayMode? paymentDisplayMode,
    bool? enableTabSwipe,
    bool? plannerUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PaymentsFilterType? paymentsFilterType,
    PaymentsGroupBy? paymentsGroupBy,
    bool? paymentsShowArchived,
    CategoryPresetMode? categoryPresetMode,
    List<String>? customExpenseCategories,
    List<String>? customIncomeCategories,
    String? moneyPotsSectionLabel,
    bool clearMoneyPotsSectionLabel = false,
  }) {
    return AccountSettings(
      paycheckDay: clearPaycheckDay ? null : (paycheckDay ?? this.paycheckDay),
      paycheckBusinessAdjust: paycheckBusinessAdjust ?? this.paycheckBusinessAdjust,
      paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection ?? this.paycheckBusinessAdjustDirection,
      startingBalanceCents: startingBalanceCents ?? this.startingBalanceCents,
      plannerSortOrder: plannerSortOrder ?? this.plannerSortOrder,
      plannerDateSortMode: plannerDateSortMode ?? this.plannerDateSortMode,
      viewPeriodMode: viewPeriodMode ?? this.viewPeriodMode,
      plannerViewMode: plannerViewMode ?? this.plannerViewMode,
      plannerShowClearedItems: plannerShowClearedItems ?? this.plannerShowClearedItems,
      plannerGroupByDate: plannerGroupByDate ?? this.plannerGroupByDate,
      plannerGroupByTheme: plannerGroupByTheme ?? this.plannerGroupByTheme,
      plannerShowPaymentOrigin: plannerShowPaymentOrigin ?? this.plannerShowPaymentOrigin,
      monthTotalsDisplayMode: monthTotalsDisplayMode ?? this.monthTotalsDisplayMode,
      monthCardDisplayMode: monthCardDisplayMode ?? this.monthCardDisplayMode,
      multiMonthDisplayMode: multiMonthDisplayMode ?? this.multiMonthDisplayMode,
      dayFormat: dayFormat ?? this.dayFormat,
      plannerSwipeLeft: plannerSwipeLeft ?? this.plannerSwipeLeft,
      plannerSwipeRight: plannerSwipeRight ?? this.plannerSwipeRight,
      plannerTapAction: plannerTapAction ?? this.plannerTapAction,
      paymentSwipeLeft: paymentSwipeLeft ?? this.paymentSwipeLeft,
      paymentSwipeRight: paymentSwipeRight ?? this.paymentSwipeRight,
      paymentDisplayMode: paymentDisplayMode ?? this.paymentDisplayMode,
      enableTabSwipe: enableTabSwipe ?? this.enableTabSwipe,
      plannerUseZeroBaseline: plannerUseZeroBaseline ?? this.plannerUseZeroBaseline,
      terminologyPreset: terminologyPreset ?? this.terminologyPreset,
      paymentsFilterType: paymentsFilterType ?? this.paymentsFilterType,
      paymentsGroupBy: paymentsGroupBy ?? this.paymentsGroupBy,
      paymentsShowArchived: paymentsShowArchived ?? this.paymentsShowArchived,
      categoryPresetMode: categoryPresetMode ?? this.categoryPresetMode,
      customExpenseCategories: customExpenseCategories ?? this.customExpenseCategories,
      customIncomeCategories: customIncomeCategories ?? this.customIncomeCategories,
      moneyPotsSectionLabel: clearMoneyPotsSectionLabel ? null : (moneyPotsSectionLabel ?? this.moneyPotsSectionLabel),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'paycheckDay': paycheckDay,
      'paycheckBusinessAdjust': paycheckBusinessAdjust,
      'paycheckBusinessAdjustDirection': paycheckBusinessAdjustDirection.name,
      'startingBalanceCents': startingBalanceCents,
      'plannerSortOrder': plannerSortOrder.name,
      'plannerDateSortMode': plannerDateSortMode.name,
      'viewPeriodMode': viewPeriodMode.name,
      'plannerViewMode': plannerViewMode.name,
      'plannerShowClearedItems': plannerShowClearedItems,
      'plannerGroupByDate': plannerGroupByDate,
      'plannerGroupByTheme': plannerGroupByTheme,
      'plannerShowPaymentOrigin': plannerShowPaymentOrigin,
      'monthTotalsDisplayMode': monthTotalsDisplayMode.name,
      'monthCardDisplayMode': monthCardDisplayMode.name,
      'multiMonthDisplayMode': multiMonthDisplayMode.name,
      'dayFormat': dayFormat.name,
      'plannerSwipeLeft': plannerSwipeLeft.name,
      'plannerSwipeRight': plannerSwipeRight.name,
      'plannerTapAction': plannerTapAction.name,
      'paymentSwipeLeft': paymentSwipeLeft.name,
      'paymentSwipeRight': paymentSwipeRight.name,
      'paymentDisplayMode': paymentDisplayMode.name,
      'enableTabSwipe': enableTabSwipe,
      'plannerUseZeroBaseline': plannerUseZeroBaseline,
      'terminologyPreset': terminologyPreset.name,
      'paymentsFilterType': paymentsFilterType.name,
      'paymentsGroupBy': paymentsGroupBy.name,
      'paymentsShowArchived': paymentsShowArchived,
      'categoryPresetMode': categoryPresetMode.name,
      'customExpenseCategories': customExpenseCategories,
      'customIncomeCategories': customIncomeCategories,
      'moneyPotsSectionLabel': moneyPotsSectionLabel,
    };
  }

  factory AccountSettings.fromJson(Map<String, dynamic> json) {
    return AccountSettings(
      paycheckDay: json['paycheckDay'] as int?,
      paycheckBusinessAdjust: json['paycheckBusinessAdjust'] as bool? ?? false,
      paycheckBusinessAdjustDirection: _parseAdjustDirection(json['paycheckBusinessAdjustDirection']),
      startingBalanceCents: ((json['startingBalanceCents'] ?? json['startingBalance'] ?? json['balanceCents'] ?? json['balance'] ?? 0) as num).toInt(),
      plannerSortOrder: _parseEnum(PlannerSortOrder.values, json['plannerSortOrder'], PlannerSortOrder.chronological),
      plannerDateSortMode: _parseEnum(PlannerDateSortMode.values, json['plannerDateSortMode'], PlannerDateSortMode.scheduledDate),
      viewPeriodMode: _parseEnum(ViewPeriodMode.values, json['viewPeriodMode'], ViewPeriodMode.calendar),
      plannerViewMode: _parseEnum(PlannerViewMode.values, json['plannerViewMode'], PlannerViewMode.month),
      plannerShowClearedItems: json['plannerShowClearedItems'] as bool? ?? true,
      plannerGroupByDate: json['plannerGroupByDate'] as bool? ?? false,
      plannerGroupByTheme: json['plannerGroupByTheme'] as bool? ?? false,
      plannerShowPaymentOrigin: json['plannerShowPaymentOrigin'] as bool? ?? false,
      monthTotalsDisplayMode: _parseEnum(MonthTotalsDisplayMode.values, json['monthTotalsDisplayMode'], MonthTotalsDisplayMode.includeCleared),
      monthCardDisplayMode: _parseEnum(MonthCardDisplayMode.values, json['monthCardDisplayMode'], MonthCardDisplayMode.full),
      multiMonthDisplayMode: _parseEnum(MultiMonthDisplayMode.values, json['multiMonthDisplayMode'], MultiMonthDisplayMode.automatic),
      dayFormat: _parseEnum(DayFormat.values, json['dayFormat'], DayFormat.number),
      plannerSwipeLeft: _parseEnum(PlannerSwipeAction.values, json['plannerSwipeLeft'], PlannerSwipeAction.off),
      plannerSwipeRight: _parseEnum(PlannerSwipeAction.values, json['plannerSwipeRight'], PlannerSwipeAction.off),
      plannerTapAction: _parseEnum(PlannerTapAction.values, json['plannerTapAction'], PlannerTapAction.archive),
      paymentSwipeLeft: _parseEnum(PaymentSwipeAction.values, json['paymentSwipeLeft'], PaymentSwipeAction.off),
      paymentSwipeRight: _parseEnum(PaymentSwipeAction.values, json['paymentSwipeRight'], PaymentSwipeAction.off),
      paymentDisplayMode: _parseEnum(PaymentDisplayMode.values, json['paymentDisplayMode'], PaymentDisplayMode.automatic),
      enableTabSwipe: json['enableTabSwipe'] as bool? ?? false,
      plannerUseZeroBaseline: json['plannerUseZeroBaseline'] as bool? ?? false,
      terminologyPreset: _parseEnum(TerminologyPreset.values, json['terminologyPreset'], TerminologyPreset.defaultTerms),
      paymentsFilterType: _parseEnum(PaymentsFilterType.values, json['paymentsFilterType'], PaymentsFilterType.all),
      paymentsGroupBy: _parseEnum(PaymentsGroupBy.values, json['paymentsGroupBy'], PaymentsGroupBy.none),
      paymentsShowArchived: json['paymentsShowArchived'] as bool? ?? false,
      categoryPresetMode: _parseEnum(CategoryPresetMode.values, json['categoryPresetMode'], CategoryPresetMode.defaultPresets),
      customExpenseCategories: _parseList(json['customExpenseCategories']),
      customIncomeCategories: _parseList(json['customIncomeCategories']),
      moneyPotsSectionLabel: json['moneyPotsSectionLabel'] as String?,
    );
  }

  static List<String> _parseList(dynamic value) {
    if (value is List) {
      return value.map((e) => e.toString()).toList();
    }
    return const [];
  }

  static T _parseEnum<T extends Enum>(List<T> values, dynamic value, T defaultValue) {
    if (value is String) {
      return values.firstWhere(
        (e) => e.name == value,
        orElse: () => defaultValue,
      );
    }
    return defaultValue;
  }

  static PaycheckAdjustDirection _parseAdjustDirection(dynamic value) {
    if (value == null) return PaycheckAdjustDirection.before;
    if (value is String) {
      return PaycheckAdjustDirection.values.firstWhere(
        (e) => e.name == value,
        orElse: () => PaycheckAdjustDirection.before,
      );
    }
    return PaycheckAdjustDirection.before;
  }

  @override
  List<Object?> get props => [
    paycheckDay, paycheckBusinessAdjust, paycheckBusinessAdjustDirection, startingBalanceCents,
    plannerSortOrder, plannerDateSortMode, viewPeriodMode, plannerViewMode,
    plannerShowClearedItems, plannerGroupByDate, plannerGroupByTheme, plannerShowPaymentOrigin,
    monthTotalsDisplayMode, monthCardDisplayMode, multiMonthDisplayMode,
    dayFormat, plannerSwipeLeft, plannerSwipeRight, plannerTapAction,
    paymentSwipeLeft, paymentSwipeRight, paymentDisplayMode, enableTabSwipe,
    plannerUseZeroBaseline, terminologyPreset, paymentsFilterType, paymentsGroupBy,
    paymentsShowArchived, categoryPresetMode,
    customExpenseCategories, customIncomeCategories,
    moneyPotsSectionLabel,
  ];
}
