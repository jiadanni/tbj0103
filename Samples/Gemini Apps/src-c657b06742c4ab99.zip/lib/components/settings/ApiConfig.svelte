<script lang="ts">
	import { onMount } from 'svelte';
	import { settings } from '$lib/stores/settings';
	import { auth } from '$lib/stores/auth';
	import { createYouTubeClient } from '$lib/utils/youtubeClient';
	import { page } from '$app/stores';

	let newYoutubeKey = '';
	let clientId = '';
	let vimeoToken = '';

	let validatingYouTube = false;
	let validatingVimeo = false;
	let connectingAuth = false;

	let youtubeError = '';
	let vimeoError = '';
	let vimeoValid: boolean | null = null;

	// Sanitize API key by removing BOM, whitespace, and other invisible characters
	function sanitizeApiKey(key: string): string {
		return key
			.replace(/^\uFEFF/, '') // Remove BOM
			.replace(/^[\s\u200B-\u200D\uFEFF]+/, '') // Remove leading whitespace and zero-width chars
			.replace(/[\s\u200B-\u200D\uFEFF]+$/, '') // Remove trailing whitespace and zero-width chars
			.trim();
	}

	onMount(() => {
		if ($settings) {
			vimeoToken = sanitizeApiKey($settings.vimeo.accessToken);
		}
		if ($auth) {
			clientId = $auth.clientId;
		}
	});

	async function addYouTubeKey() {
		if (!newYoutubeKey) return;

		// Sanitize the key before validation
		newYoutubeKey = sanitizeApiKey(newYoutubeKey);

		if (!newYoutubeKey) {
			youtubeError = 'Please enter an API key.';
			return;
		}

		validatingYouTube = true;
		youtubeError = '';

		try {
			const client = createYouTubeClient(newYoutubeKey);
			const valid = await client.validateApiKey();

			if (valid) {
				await settings.addYouTubeKey(newYoutubeKey);
				newYoutubeKey = ''; // Clear input on success
			} else {
				youtubeError = 'API key validation failed. Please check your key.';
			}
		} catch (error) {
			console.error('YouTube API validation error:', error);
			if (error instanceof Error) {
				youtubeError = error.message;
			} else {
				youtubeError = 'Failed to validate API key. Please check your internet connection.';
			}
		} finally {
			validatingYouTube = false;
		}
	}

	async function removeKey(index: number) {
		if (confirm('Are you sure you want to remove this API key?')) {
			await settings.removeYouTubeKey(index);
		}
	}

	async function saveClientId() {
		if (!clientId) return;
		auth.setClientId(clientId.trim());
	}

	async function connectYouTube() {
		if (!clientId) {
			alert('Please save a Client ID first.');
			return;
		}

		connectingAuth = true;
		try {
			// Redirect to Google
			const redirectUri = `${$page.url.origin}/auth/callback`;
			const authUrl = auth.getAuthUrl(redirectUri);
			window.location.href = authUrl;
		} catch (e) {
			console.error(e);
			alert('Failed to generate auth URL');
			connectingAuth = false;
		}
	}

	function logout() {
		if (confirm('Disconnect your YouTube account?')) {
			auth.logout();
		}
	}

	async function validateVimeoToken() {
		if (!vimeoToken) return;

		// Sanitize the token before validation
		vimeoToken = sanitizeApiKey(vimeoToken);

		if (!vimeoToken) {
			vimeoError = 'Please enter an access token.';
			return;
		}

		validatingVimeo = true;
		vimeoValid = null;
		vimeoError = '';

		try {
			// Vimeo validation would go here
			vimeoValid = true;
			await settings.updateVimeoToken(vimeoToken);
		} catch (error) {
			console.error('Vimeo API validation error:', error);
			vimeoValid = false;
			if (error instanceof Error) {
				vimeoError = error.message;
			} else {
				vimeoError = 'Failed to validate access token.';
			}
		} finally {
			validatingVimeo = false;
		}
	}
</script>

<div class="space-y-8">
	<div>
		<h2 class="text-2xl font-bold mb-4">API Configuration</h2>
		<p class="text-gray-600 dark:text-gray-400 mb-6">
			Configure your own API keys for video platforms. Your keys are stored securely in your browser
			and never sent to any server.
		</p>
	</div>

	<!-- YouTube API Key -->
	<div class="card">
		<h3 class="text-xl font-semibold mb-4">YouTube API Keys (Public Data)</h3>
		<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
			Used for searching videos and getting channel details. Add multiple keys to increase your
			daily quota limit (stacking).
		</p>

		<div class="space-y-4">
			<!-- List existing keys -->
			{#if $settings?.youtube.apiKeys && $settings.youtube.apiKeys.length > 0}
				<div class="space-y-2">
					{#each $settings.youtube.apiKeys as key, i}
						<div
							class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700"
						>
							<div class="flex items-center gap-3 overflow-hidden">
								<div
									class="flex-shrink-0 w-2 h-2 rounded-full {i === $settings.youtube.activeKeyIndex
										? 'bg-green-500 animate-pulse'
										: 'bg-gray-400'}"
								></div>
								<span class="font-mono text-sm truncate">
									{key.substring(0, 8)}...{key.substring(key.length - 4)}
								</span>
								{#if i === $settings.youtube.activeKeyIndex}
									<span
										class="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full dark:bg-primary-900 dark:text-primary-300"
										>Active</span
									>
								{/if}
							</div>
							<button
								class="text-red-500 hover:text-red-700 p-1"
								on:click={() => removeKey(i)}
								title="Remove Key"
							>
								<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"
									><path
										stroke-linecap="round"
										stroke-linejoin="round"
										stroke-width="2"
										d="M6 18L18 6M6 6l12 12"
									></path></svg
								>
							</button>
						</div>
					{/each}
				</div>
			{/if}

			<!-- Add new key -->
			<div class="flex gap-2">
				<input
					type="text"
					bind:value={newYoutubeKey}
					class="input flex-1"
					placeholder="Paste new API Key..."
				/>

				<button
					class="btn btn-primary whitespace-nowrap"
					on:click={addYouTubeKey}
					disabled={!newYoutubeKey || validatingYouTube}
				>
					{#if validatingYouTube}
						Validating...
					{:else}
						Add Key
					{/if}
				</button>
			</div>

			{#if youtubeError}
				<div class="text-red-600 dark:text-red-400 text-sm">
					✗ {youtubeError}
				</div>
			{/if}

			{#if $settings && $settings.youtube.apiKeys.length > 0}
				<div class="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
					<div class="text-sm">
						<div class="flex justify-between mb-2">
							<span>Quota Used (Today):</span>
							<span class="font-semibold"
								>{$settings.youtube.quotaUsed} / {$settings.youtube.quotaLimit}</span
							>
						</div>
						<div class="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-2">
							<div
								class="bg-primary-600 h-2 rounded-full transition-all"
								style="width: {Math.min(
									100,
									($settings.youtube.quotaUsed / $settings.youtube.quotaLimit) * 100
								)}%"
							></div>
						</div>
					</div>
				</div>
			{/if}
		</div>

		<details class="mt-4">
			<summary class="cursor-pointer text-sm text-primary-600 dark:text-primary-400">
				How to get a YouTube API key?
			</summary>
			<div class="mt-2 text-sm text-gray-600 dark:text-gray-400 space-y-2">
				<ol class="list-decimal list-inside space-y-1">
					<li>
						Go to <a href="https://console.cloud.google.com" target="_blank" class="underline"
							>Google Cloud Console</a
						>
					</li>
					<li>Create a new project or select an existing one</li>
					<li>Enable the YouTube Data API v3</li>
					<li>Create credentials (API Key)</li>
					<li>Copy the API key and paste it above</li>
				</ol>
			</div>
		</details>
	</div>

	<!-- OAuth Connection -->
	<div class="card">
		<h3 class="text-xl font-semibold mb-4">YouTube Account (Private Data)</h3>
		<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
			Connect your account to import your Liked Videos and Subscriptions. Requires creating an OAuth
			Client ID.
		</p>

		<div class="space-y-4">
			<div>
				<label class="block text-sm font-medium mb-2">OAuth Client ID</label>
				<div class="flex gap-2">
					<input
						type="text"
						bind:value={clientId}
						class="input flex-1"
						placeholder="apps.googleusercontent.com..."
					/>
					<button
						class="btn btn-secondary"
						on:click={saveClientId}
						disabled={!clientId || clientId === $auth.clientId}
					>
						Save
					</button>
				</div>
			</div>

			{#if $auth.clientId}
				<div class="border-t border-gray-200 dark:border-gray-700 pt-4">
					{#if $auth.isAuthenticated}
						<div
							class="flex items-center justify-between bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800"
						>
							<div class="flex items-center gap-3">
								<div
									class="w-10 h-10 bg-green-100 dark:bg-green-800 rounded-full flex items-center justify-center text-green-600 dark:text-green-300"
								>
									<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
										><path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M5 13l4 4L19 7"
										></path></svg
									>
								</div>
								<div>
									<div class="font-medium text-green-800 dark:text-green-200">Connected</div>
									<div class="text-xs text-green-600 dark:text-green-400">Access tokens active</div>
								</div>
							</div>
							<button class="btn btn-sm btn-outline-danger" on:click={logout}>Disconnect</button>
						</div>
					{:else}
						<button
							class="btn btn-primary w-full"
							on:click={connectYouTube}
							disabled={connectingAuth}
						>
							{#if connectingAuth}Connect...{:else}Connect YouTube Account{/if}
						</button>
						<p class="text-xs text-gray-500 mt-2 text-center">
							You will be redirected to Google to authorize access.
						</p>
					{/if}
				</div>
			{/if}
		</div>

		<details class="mt-4">
			<summary class="cursor-pointer text-sm text-primary-600 dark:text-primary-400">
				How to set up OAuth?
			</summary>
			<div class="mt-2 text-sm text-gray-600 dark:text-gray-400 space-y-2">
				<ol class="list-decimal list-inside space-y-1">
					<li>Go to Google Cloud Console > APIs & Services > Credentials.</li>
					<li>Create Credentials > OAuth Client ID > Web Application.</li>
					<li>Add <code>{$page.url.origin}/auth/callback</code> to "Authorized redirect URIs".</li>
					<li>Copy the Client ID and paste it above.</li>
				</ol>
			</div>
		</details>
	</div>

	<!-- Vimeo Access Token -->
	<div class="card">
		<h3 class="text-xl font-semibold mb-4">Vimeo Access Token</h3>

		<div class="space-y-4">
			<div>
				<label class="block text-sm font-medium mb-2">Access Token</label>
				<input type="text" bind:value={vimeoToken} class="input" placeholder="Your Vimeo token" />
			</div>

			<button
				class="btn btn-primary"
				on:click={validateVimeoToken}
				disabled={!vimeoToken || validatingVimeo}
			>
				{#if validatingVimeo}
					Validating...
				{:else}
					Validate & Save
				{/if}
			</button>

			{#if vimeoValid === true}
				<div class="text-green-600 dark:text-green-400 text-sm">✓ Access token is valid!</div>
			{:else if vimeoValid === false}
				<div class="text-red-600 dark:text-red-400 text-sm">
					✗ {vimeoError || 'Invalid access token. Please check and try again.'}
				</div>
			{/if}
		</div>

		<details class="mt-4">
			<summary class="cursor-pointer text-sm text-primary-600 dark:text-primary-400">
				How to get a Vimeo access token?
			</summary>
			<div class="mt-2 text-sm text-gray-600 dark:text-gray-400 space-y-2">
				<ol class="list-decimal list-inside space-y-1">
					<li>
						Go to <a href="https://developer.vimeo.com" target="_blank" class="underline"
							>Vimeo Developer</a
						>
					</li>
					<li>Create a new app</li>
					<li>Generate a personal access token</li>
					<li>Copy the token and paste it above</li>
				</ol>
			</div>
		</details>
	</div>
</div>
