<script lang="ts">
	import { playbackHistory, type PlaybackRecord } from '$lib/stores/playbackHistory';
	import VideoCard from '$lib/components/core/VideoCard.svelte';
	import { confirm } from '$lib/stores/confirm';
	import { formatDuration } from '$lib/utils/helpers';

	let tab: 'all' | 'completed' | 'in-progress' = 'all';
	let allRecords: PlaybackRecord[] = [];
	let completedRecords: PlaybackRecord[] = [];
	let inProgressRecords: PlaybackRecord[] = [];
	let stats = {
		totalVideos: 0,
		completedVideos: 0,
		inProgressVideos: 0,
		totalWatchTime: 0,
		totalWatches: 0
	};

	// Reactively update when playbackHistory changes
	$: {
		allRecords = playbackHistory.getAll();
		completedRecords = playbackHistory.getCompleted();
		inProgressRecords = playbackHistory.getInProgress();
		stats = playbackHistory.getStats();
	}

	$: displayedRecords =
		tab === 'all' ? allRecords : tab === 'completed' ? completedRecords : inProgressRecords;

	function formatDate(timestamp: number): string {
		const date = new Date(timestamp);
		const now = new Date();
		const diffMs = now.getTime() - date.getTime();
		const diffMins = Math.floor(diffMs / 60000);
		const diffHours = Math.floor(diffMs / 3600000);
		const diffDays = Math.floor(diffMs / 86400000);

		if (diffMins < 1) return 'Just now';
		if (diffMins < 60) return `${diffMins} min ago`;
		if (diffHours < 24) return `${diffHours}h ago`;
		if (diffDays < 7) return `${diffDays}d ago`;

		return date.toLocaleDateString();
	}

	function formatWatchTime(seconds: number): string {
		const hours = Math.floor(seconds / 3600);
		const minutes = Math.floor((seconds % 3600) / 60);

		if (hours > 0) {
			return `${hours}h ${minutes}m`;
		}
		return `${minutes}m`;
	}

	async function handleClearHistory() {
		const confirmed = await confirm.confirm({
			title: 'Clear Playback History?',
			message:
				'This will permanently delete all your playback history and progress data. This action cannot be undone.',
			confirmText: 'Clear History',
			cancelText: 'Cancel',
			danger: true
		});

		if (confirmed) {
			playbackHistory.clear();
		}
	}
</script>

<svelte:head>
	<title>Playback History - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<!-- Header -->
	<div class="flex items-center justify-between">
		<div>
			<h1 class="text-3xl font-bold mb-2">Playback History</h1>
			<p style="color: var(--text-secondary);">Track your video watching progress and statistics</p>
		</div>

		{#if allRecords.length > 0}
			<button class="btn btn-secondary" on:click={handleClearHistory}> Clear History </button>
		{/if}
	</div>

	<!-- Stats -->
	{#if allRecords.length > 0}
		<div class="grid grid-cols-2 md:grid-cols-5 gap-4">
			<div class="card text-center">
				<div class="text-3xl font-bold text-primary-600 dark:text-primary-400">
					{stats.totalVideos}
				</div>
				<div class="text-sm mt-1" style="color: var(--text-secondary);">Total Videos</div>
			</div>

			<div class="card text-center">
				<div class="text-3xl font-bold text-green-600 dark:text-green-400">
					{stats.completedVideos}
				</div>
				<div class="text-sm mt-1" style="color: var(--text-secondary);">Completed</div>
			</div>

			<div class="card text-center">
				<div class="text-3xl font-bold text-yellow-600 dark:text-yellow-400">
					{stats.inProgressVideos}
				</div>
				<div class="text-sm mt-1" style="color: var(--text-secondary);">In Progress</div>
			</div>

			<div class="card text-center">
				<div class="text-3xl font-bold text-blue-600 dark:text-blue-400">
					{formatWatchTime(stats.totalWatchTime)}
				</div>
				<div class="text-sm mt-1" style="color: var(--text-secondary);">Watch Time</div>
			</div>

			<div class="card text-center">
				<div class="text-3xl font-bold text-purple-600 dark:text-purple-400">
					{stats.totalWatches}
				</div>
				<div class="text-sm mt-1" style="color: var(--text-secondary);">Total Plays</div>
			</div>
		</div>
	{/if}

	<!-- Tabs -->
	<div class="flex gap-2 border-b border-gray-200 dark:border-gray-700">
		<button
			class="px-4 py-2 -mb-px border-b-2 transition-colors {tab === 'all'
				? 'border-primary-600 text-primary-600 dark:text-primary-400 font-semibold'
				: 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}"
			on:click={() => (tab = 'all')}
		>
			All ({allRecords.length})
		</button>
		<button
			class="px-4 py-2 -mb-px border-b-2 transition-colors {tab === 'completed'
				? 'border-primary-600 text-primary-600 dark:text-primary-400 font-semibold'
				: 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}"
			on:click={() => (tab = 'completed')}
		>
			Completed ({completedRecords.length})
		</button>
		<button
			class="px-4 py-2 -mb-px border-b-2 transition-colors {tab === 'in-progress'
				? 'border-primary-600 text-primary-600 dark:text-primary-400 font-semibold'
				: 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}"
			on:click={() => (tab = 'in-progress')}
		>
			In Progress ({inProgressRecords.length})
		</button>
	</div>

	<!-- History List -->
	{#if displayedRecords.length === 0}
		<div class="card text-center py-12">
			<svg
				class="w-24 h-24 text-gray-400 mx-auto mb-4"
				fill="none"
				stroke="currentColor"
				viewBox="0 0 24 24"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
				/>
			</svg>
			<h2 class="text-xl font-semibold mb-2">
				{#if tab === 'all'}
					No playback history yet
				{:else if tab === 'completed'}
					No completed videos
				{:else}
					No videos in progress
				{/if}
			</h2>
			<p class="mb-4" style="color: var(--text-secondary);">
				Start watching videos to see your history here.
			</p>
			<a href="/" class="btn btn-primary inline-block"> Browse Videos </a>
		</div>
	{:else}
		<div class="space-y-4">
			{#each displayedRecords as record (record.video.id)}
				<div class="card">
					<div class="flex gap-4">
						<!-- Thumbnail -->
						<div class="relative flex-shrink-0">
							<img
								src={record.video.thumbnail}
								alt={record.video.title}
								class="w-40 h-24 object-cover rounded"
							/>
							{#if record.progress > 0}
								<div class="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 h-1">
									<div class="h-full bg-primary-600" style="width: {record.progress * 100}%"></div>
								</div>
							{/if}
						</div>

						<!-- Info -->
						<div class="flex-1 min-w-0">
							<h3 class="font-semibold text-lg mb-1">{record.video.title}</h3>
							<p class="text-sm mb-2" style="color: var(--text-secondary);">
								{record.video.channelTitle}
							</p>

							<div class="flex flex-wrap gap-3 text-sm text-gray-600 dark:text-gray-400">
								<span class="flex items-center gap-1">
									<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
										/>
									</svg>
									{formatDate(record.lastWatched)}
								</span>

								<span class="flex items-center gap-1">
									<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
										/>
									</svg>
									{Math.round(record.progress * 100)}% watched
								</span>

								<span class="flex items-center gap-1">
									<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
										/>
									</svg>
									Played {record.watchCount}x
								</span>

								{#if record.completed}
									<span class="flex items-center gap-1 text-green-600 dark:text-green-400">
										<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
											<path
												fill-rule="evenodd"
												d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
												clip-rule="evenodd"
											/>
										</svg>
										Completed
									</span>
								{/if}
							</div>
						</div>

						<!-- Actions -->
						<div class="flex flex-col gap-2">
							<button
								class="btn btn-secondary btn-sm"
								on:click={() => playbackHistory.remove(record.video.id)}
							>
								Remove
							</button>
						</div>
					</div>
				</div>
			{/each}
		</div>
	{/if}
</div>
