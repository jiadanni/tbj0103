<script lang="ts">
	import { onMount } from 'svelte';
	import SearchBar from '$lib/components/core/SearchBar.svelte';
	import VideoCard from '$lib/components/core/VideoCard.svelte';
	import ControlPanel from '$lib/components/core/ControlPanel.svelte';
	import SkeletonCard from '$lib/components/SkeletonCard.svelte';
	import { settings, hasYouTubeKey } from '$lib/stores/settings';
	import { activeProfile } from '$lib/stores/profiles';
	import { recentlyViewed } from '$lib/stores/history';
	import { paths } from '$lib/stores/paths';
	import { createYouTubeClient } from '$lib/utils/youtubeClient';
	import { scorer } from '$lib/engines/scorer';
	import { AIService } from '$lib/engines/ai';
	import type { VideoMetadata } from '$lib/types';

	let searchQuery = '';
	let videos: VideoMetadata[] = [];
	let loading = false;
	let error = '';
	let showFilters = false;

	async function handleSearch(event: CustomEvent<{ query: string; useAI: boolean }>) {
		const { query, useAI } = event.detail;
		searchQuery = query;
		loading = true;
		error = '';
		videos = [];

		try {
			if (!$settings?.youtube.apiKey) {
				error = 'Please configure your YouTube API key in Settings';
				return;
			}

			const client = createYouTubeClient($settings.youtube.apiKey);
			let searchQueries = [query];

			// Enhance search with AI if enabled
			if (useAI && $settings.ai.enabled && $activeProfile) {
				const aiService = new AIService($settings.ai);
				const enhanced = await aiService.enhanceSearch(query, $activeProfile);
				searchQueries = enhanced;
			}

			// Search with the first query (or all if AI enhanced)
			const result = await client.search(searchQueries[0], 25);

			// Update quota
			await settings.updateQuota(client.getQuotaUsed());

			// Score and rank videos
			if ($activeProfile) {
				videos = scorer.rankVideos(result.videos, $activeProfile.filters);
			} else {
				videos = result.videos;
			}
		} catch (err) {
			error = err instanceof Error ? err.message : 'Search failed';
		} finally {
			loading = false;
		}
	}

	function handleClear() {
		searchQuery = '';
		videos = [];
		error = '';
	}
</script>

<svelte:head>
	<title>Vektor - Intentional Video Discovery</title>
</svelte:head>

<div class="space-y-6">
	<!-- Welcome / Setup Banner -->
	{#if !$hasYouTubeKey}
		<div
			class="card bg-primary-50 dark:bg-primary-900 border-2 border-primary-200 dark:border-primary-700"
		>
			<h2 class="text-2xl font-bold mb-2">Welcome to Vektor!</h2>
			<p class="mb-4" style="color: var(--text-secondary);">
				Get started by configuring your YouTube API key to enable video search and discovery.
			</p>
			<a href="/settings/api" class="btn btn-primary"> Configure API Keys </a>
		</div>
	{:else}
		<!-- Search Section -->
		<div class="card">
			<div class="flex items-center justify-between mb-4">
				<h1 class="text-2xl font-bold">Discover Videos</h1>
				<button class="btn btn-secondary" on:click={() => (showFilters = !showFilters)}>
					{showFilters ? 'Hide' : 'Show'} Filters
				</button>
			</div>

			<SearchBar
				bind:value={searchQuery}
				enableAI={$settings?.ai.enabled || false}
				on:search={handleSearch}
				on:clear={handleClear}
			/>

			{#if $activeProfile}
				<div class="mt-4 text-sm" style="color: var(--text-secondary);">
					Active Profile: <span class="font-semibold">{$activeProfile.name}</span>
				</div>
			{/if}
		</div>

		<!-- Filters (Collapsible) -->
		{#if showFilters}
			<ControlPanel />
		{/if}

		<!-- Active Learning Paths -->
		{#if $paths.length > 0 && !searchQuery && !loading}
			<div class="card">
				<div class="flex items-center justify-between mb-4">
					<h2 class="text-xl font-semibold">In Progress</h2>
					<a href="/paths" class="text-sm text-primary-600 dark:text-primary-400 hover:underline">
						View All Paths
					</a>
				</div>

				<div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
					{#each $paths.slice(0, 3) as path}
						<a
							href="/paths/{path.id}"
							class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow group"
						>
							<h3 class="font-semibold group-hover:text-primary-600 transition-colors">
								{path.name}
							</h3>
							<p class="text-xs mt-1" style="color: var(--text-muted);">{path.description}</p>
							<div class="mt-4">
								<div class="flex justify-between text-xs mb-1">
									<span>Progress</span>
									<span class="font-medium"
										>{Math.round(
											(path.progress.completed.length / path.videos.length) * 100
										)}%</span
									>
								</div>
								<div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
									<div
										class="bg-primary-600 h-1.5 rounded-full"
										style="width: {(path.progress.completed.length / path.videos.length) * 100}%"
									></div>
								</div>
							</div>
						</a>
					{/each}
				</div>
			</div>
		{/if}

		<!-- Recently Viewed -->
		{#if $recentlyViewed.length > 0 && !searchQuery && !loading}
			<div class="card">
				<div class="flex items-center justify-between mb-4">
					<h2 class="text-xl font-semibold">Recently Viewed</h2>
					<button
						class="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
						on:click={() => recentlyViewed.clear()}
					>
						Clear All
					</button>
				</div>

				<div
					class="grid gap-6 {$activeProfile?.appearance.layout === 'list'
						? 'grid-cols-1'
						: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}"
				>
					{#each $recentlyViewed.slice(0, 6) as video (video.id)}
						<VideoCard {video} />
					{/each}
				</div>
			</div>
		{:else if !searchQuery && !loading && $paths.length === 0}
			<div class="card text-center py-12">
				<div
					class="w-16 h-16 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mx-auto mb-4 text-primary-600 dark:text-primary-400"
				>
					<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
						/>
					</svg>
				</div>
				<h2 class="text-xl font-semibold mb-2">Build Your Knowledge</h2>
				<p class="mb-6 max-w-md mx-auto" style="color: var(--text-secondary);">
					Start searching for educational content and add them to learning paths to track your
					progress here.
				</p>
				<button class="btn btn-primary" on:click={() => document.querySelector('input')?.focus()}>
					Start Searching
				</button>
			</div>
		{/if}

		<!-- Results -->
		{#if loading}
			<div>
				<h2 class="text-xl font-semibold mb-4">Searching...</h2>
				<SkeletonCard count={$activeProfile?.appearance.layout === 'list' ? 1 : 6} />
			</div>
		{:else if error}
			<div class="card bg-red-50 dark:bg-red-900 border-2 border-red-200 dark:border-red-700">
				<p class="text-red-700 dark:text-red-300">{error}</p>
			</div>
		{:else if videos.length > 0}
			<div>
				<div class="flex items-center justify-between mb-4">
					<h2 class="text-xl font-semibold">Results ({videos.length})</h2>
				</div>

				<div
					class="grid gap-6 {$activeProfile?.appearance.layout === 'list'
						? 'grid-cols-1'
						: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}"
				>
					{#each videos as video (video.id)}
						<VideoCard {video} />
					{/each}
				</div>
			</div>
		{:else if searchQuery}
			<div class="text-center py-12" style="color: var(--text-secondary);">
				<p>No results found for "{searchQuery}"</p>
			</div>
		{/if}
	{/if}

	<!-- Quick Stats -->
	{#if $settings && $hasYouTubeKey}
		<div class="card bg-gray-50 dark:bg-gray-800">
			<h3 class="text-lg font-semibold mb-4">API Usage</h3>
			<div class="space-y-2">
				<div class="flex justify-between text-sm">
					<span>YouTube Quota:</span>
					<span class="font-semibold"
						>{$settings.youtube.quotaUsed} / {$settings.youtube.quotaLimit}</span
					>
				</div>
				<div class="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-2">
					<div
						class="bg-primary-600 h-2 rounded-full transition-all"
						style="width: {($settings.youtube.quotaUsed / $settings.youtube.quotaLimit) * 100}%"
					></div>
				</div>
			</div>
		</div>
	{/if}
</div>
