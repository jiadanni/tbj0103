import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';

import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

import 'widgets/priority_breakdown_chart.dart';
import 'widgets/category_spending_card.dart';
import 'widgets/trend_analysis_card.dart';
import 'widgets/date_range_selector.dart';
import 'package:expense_stalker_mobile/src/widgets/gradient_card.dart';

import 'package:expense_stalker_mobile/src/models/insight_context.dart';
import 'package:expense_stalker_mobile/src/features/insights/widgets/insights_discover_sheet.dart';
import 'package:expense_stalker_mobile/src/features/insights/widgets/transaction_details_sheet.dart';

class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});

  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  InsightsDateRange _selectedRange = InsightsDateRange.currentPeriod;
  late ViewPeriodMode _viewMode;

  // Cached calculations
  List<CategorySpending>? _cachedCategorySpending;
  PriorityBreakdown? _cachedPriorityBreakdown;
  List<SpendingTrend>? _cachedTrends;

  int? _cachedDataHash;
  InsightsDateRange? _cachedRange;
  ViewPeriodMode? _cachedViewMode;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final settings = AppSettingsScope.of(context);
    _viewMode = settings.viewPeriodMode;
  }

  PriorityBreakdown _mergeBreakdowns(PriorityBreakdown a, PriorityBreakdown b) {
    if (a == PriorityBreakdown.empty) return b;
    if (b == PriorityBreakdown.empty) return a;

    final total = a.totalMinorUnits + b.totalMinorUnits;
    if (total == 0) return PriorityBreakdown.empty;

    final critical = a.criticalMinorUnits + b.criticalMinorUnits;
    final advisable = a.advisableMinorUnits + b.advisableMinorUnits;
    final optional = a.optionalMinorUnits + b.optionalMinorUnits;
    final strategic = a.strategicMinorUnits + b.strategicMinorUnits;
    final frivolous = a.frivolousMinorUnits + b.frivolousMinorUnits;

    return PriorityBreakdown(
      criticalMinorUnits: critical,
      advisableMinorUnits: advisable,
      optionalMinorUnits: optional,
      strategicMinorUnits: strategic,
      frivolousMinorUnits: frivolous,
      criticalPercentage: (critical / total) * 100,
      advisablePercentage: (advisable / total) * 100,
      optionalPercentage: (optional / total) * 100,
      strategicPercentage: (strategic / total) * 100,
      frivolousPercentage: (frivolous / total) * 100,
      totalMinorUnits: total,
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final settings = AppSettingsScope.of(context);
    final theme = Theme.of(context);

    // Compute cache key
    final dataHash = Object.hash(
      Object.hashAll(store.pulses),
      Object.hashAll(store.timelineItems),
    );

    // Recompute if data, range, or view mode changed
    if (_cachedDataHash != dataHash ||
        _cachedRange != _selectedRange ||
        _cachedViewMode != _viewMode) {
      // Current month always uses TimelineItems (scheduled amounts, same as month view)
      // Historical months use archived Pulses (actual transactions)
      final now = DateTime.now();
      final referenceMonth = DateTime(now.year, now.month, 1);

      // Get current month's spending from TimelineItems
      final currentMonthSpending =
          InsightsCalculator.calculateCategorySpendingFromItems(
            store.timelineItems.where((item) => !item.archived).toList(),
            store.pulses,
            referenceMonth,
            _viewMode,
            settings.paycheckDay,
            settings,
          );

      // Calculate current month accurate breakdown (from items directly)
      final periodInfo = PaycheckService.getPeriodInfo(
        referenceMonth,
        _viewMode,
        settings.paycheckDay,
      );
      final currentScheduledItems = store.timelineItems
          .where((item) => !item.archived)
          .where(
            (item) => PaycheckService.shouldItemAppearInPeriod(
              item,
              periodInfo,
              referenceMonth,
            ),
          )
          .toList();
      final currentBreakdown =
          InsightsCalculator.calculatePriorityBreakdownFromItems(
            currentScheduledItems,
            store.pulses,
            referenceMonth,
            settings,
          );

      // Include imported transactions (bank imports) that exist as pulses in the
      // current period but aren't represented by TimelineItems. Without this,
      // imported transactions would be invisible in the current-period summary.
      final linkedItemIds = store.pulses
          .where((p) => p.timelineItemId != null)
          .map((p) => p.timelineItemId!.value)
          .toSet();
      final currentPeriodImportPulses =
          InsightsCalculator.filterByDateRange(
                store.pulses,
                InsightsDateRange.currentPeriod,
                viewMode: _viewMode,
                paycheckDay: settings.paycheckDay,
              )
              .where(
                (p) =>
                    p.timelineItemId == null ||
                    !linkedItemIds.contains(p.timelineItemId!.value),
              )
              .where((p) => p.source.isImported)
              .toList();

      final importSpending = InsightsCalculator.calculateCategorySpending(
        currentPeriodImportPulses,
        store.timelineItems,
        settings.includeInternalTransfersInReports,
      );
      final importBreakdown =
          InsightsCalculator.calculateAccuratePriorityBreakdown(
            pulses: currentPeriodImportPulses,
            timelineItems: store.timelineItems,
            includeInternalTransfers:
                settings.includeInternalTransfersInReports,
          );

      // Merge TimelineItem-based results with imported pulse results
      final mergedCurrentSpending = InsightsCalculator.mergeCategorySpending(
        currentMonthSpending,
        importSpending,
      );
      final mergedCurrentBreakdown = _mergeBreakdowns(
        currentBreakdown,
        importBreakdown,
      );

      if (_selectedRange == InsightsDateRange.currentPeriod) {
        // Current period only - TimelineItems + imported pulses
        _cachedCategorySpending = mergedCurrentSpending;
        _cachedPriorityBreakdown = mergedCurrentBreakdown;
      } else {
        // Historical periods - combine current month (TimelineItems) + past months (Pulses)
        // Filter pulses to EXCLUDE current month (we use TimelineItems for that)
        final monthStart = DateTime(now.year, now.month, 1);
        final historicalPulses = InsightsCalculator.filterByDateRange(
          store.pulses,
          _selectedRange,
          viewMode: _viewMode,
          paycheckDay: settings.paycheckDay,
        ).where((p) => p.date.isBefore(monthStart)).toList();

        final historicalSpending = InsightsCalculator.calculateCategorySpending(
          historicalPulses,
          store.timelineItems,
          settings.includeInternalTransfersInReports,
        );

        // Calculate historical accurate breakdown
        final historicalBreakdown =
            InsightsCalculator.calculateAccuratePriorityBreakdown(
              pulses: historicalPulses,
              timelineItems: store.timelineItems,
              includeInternalTransfers:
                  settings.includeInternalTransfersInReports,
            );

        // Merge current month spending (including imports) with historical spending
        final mergedSpending = InsightsCalculator.mergeCategorySpending(
          mergedCurrentSpending,
          historicalSpending,
        );

        // Fix average calculation: Force divisor based on selected range
        // The merge logic might underestimate the span if months are missing data.
        // For "Last X Periods", we want average over X months.
        int divisor = 1;
        switch (_selectedRange) {
          case InsightsDateRange.currentPeriod:
            divisor = 1;
          case InsightsDateRange.last3Periods:
            divisor = 3;
          case InsightsDateRange.last6Periods:
            divisor = 6;
          case InsightsDateRange.lastYear:
            divisor = 12;
          case InsightsDateRange.allTime:
            divisor = 1; // Keep as is (or use actual span)
        }

        if (divisor > 1) {
          _cachedCategorySpending = mergedSpending
              .map(
                (cs) => CategorySpending(
                  category: cs.category,
                  totalMinorUnits: cs.totalMinorUnits,
                  averageMonthlyMinorUnits: cs.totalMinorUnits ~/ divisor,
                  transactionCount: cs.transactionCount,
                  priority: cs.priority,
                ),
              )
              .toList();
        } else {
          _cachedCategorySpending = mergedSpending;
        }

        // Merge breakdowns
        _cachedPriorityBreakdown = _mergeBreakdowns(
          mergedCurrentBreakdown,
          historicalBreakdown,
        );
      }

      _cachedTrends = InsightsCalculator.calculateTrends(
        store.pulses,
        store.timelineItems,
        settings.includeInternalTransfersInReports,
      );

      _cachedDataHash = dataHash;
      _cachedRange = _selectedRange;
      _cachedViewMode = _viewMode;
    }

    final hasData = store.pulses.isNotEmpty;
    final isPaycheckMode =
        _viewMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured;
    final periodLabel = isPaycheckMode ? 'Paycheck Period' : 'Calendar Month';

    String moneyFormatter(int cents) =>
        formatMoney(cents, settings.currency, showDecimals: settings.showCents);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            pinned: false,
            title: Text(
              Terminology.of(context).insightsLabel,
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            centerTitle: false,
            backgroundColor: theme.scaffoldBackgroundColor,
            actions: [
              IconButton(
                tooltip: 'Smart ${Terminology.of(context).insightsTabLabel}',
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => InsightsDiscoverSheet(
                      contextData: InsightContext(
                        allPulses: store.pulses,
                        filteredPulses: InsightsCalculator.filterByDateRange(
                          store.pulses,
                          _selectedRange,
                          viewMode: _viewMode,
                          paycheckDay: settings.paycheckDay,
                        ),
                        timelineItems: store.timelineItems,
                        categorySpending: _cachedCategorySpending!,
                        priorityBreakdown: _cachedPriorityBreakdown!,
                        currentDate: DateTime.now(),
                        formatMoney: (cents) => formatMoney(
                          cents,
                          settings.currency,
                          showDecimals: settings.showCents,
                        ),
                        settings: settings.insightSettings,
                      ),
                    ),
                  );
                },
                icon: PhosphorIcon(PhosphorIcons.lightbulb()),
              ),
              if (settings.isPaycheckModeConfigured)
                IconButton(
                  tooltip: isPaycheckMode
                      ? 'Switch to Calendar'
                      : 'Switch to Paycheck',
                  onPressed: () {
                    setState(() {
                      _viewMode = isPaycheckMode
                          ? ViewPeriodMode.calendar
                          : ViewPeriodMode.paycheck;
                    });
                  },
                  icon: PhosphorIcon(
                    isPaycheckMode
                        ? PhosphorIcons.calendar()
                        : PhosphorIcons.wallet(),
                  ),
                ),
              IconButton(
                tooltip: 'Options',
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const OptionsScreen(),
                    fullscreenDialog: true,
                  ),
                ),
                icon: PhosphorIcon(PhosphorIcons.gear()),
              ),
            ],
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    periodLabel,
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  DateRangeSelector(
                    selectedRange: _selectedRange,
                    isPaycheckMode: isPaycheckMode,
                    onRangeChanged: (range) =>
                        setState(() => _selectedRange = range),
                  ),
                ],
              ),
            ),
          ),

          if (!hasData)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    PhosphorIcon(
                      PhosphorIcons.chartLine(),
                      size: 64,
                      color: theme.colorScheme.onSurfaceVariant.withValues(
                        alpha: 0.5,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      Terminology.of(context).noTransactionsMessage,
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Start tracking expenses to see insights',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            )
          else if (_cachedCategorySpending!.isNotEmpty &&
              _cachedCategorySpending!.length == 1 &&
              _cachedCategorySpending!.first.category == 'Uncategorized')
            SliverFillRemaining(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      PhosphorIcon(
                        PhosphorIcons.tag(),
                        size: 64,
                        color: theme.colorScheme.primary.withValues(alpha: 0.5),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Categorize Your Expenses',
                        style: theme.textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Add categories to transactions to see detailed insights about your spending by category.',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 24),
                      OutlinedButton.icon(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: PhosphorIcon(PhosphorIcons.tag()),
                        label: const Text('Go Back to Categorize'),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else ...[
            SliverToBoxAdapter(
              child: PriorityBreakdownChart(
                breakdown: _cachedPriorityBreakdown ?? PriorityBreakdown.empty,
                formatMoney: moneyFormatter,
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // Trends section
            if (_cachedTrends!.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: PillHeader(
                  label:
                      '${Terminology.of(context).trendsLabel.toUpperCase()} (VS PREVIOUS)',
                ),
              ),
              SliverList.separated(
                itemCount: _cachedTrends!.length,
                separatorBuilder: (_, _) =>
                    const Divider(height: 1, indent: 68),
                itemBuilder: (context, index) => TrendAnalysisCard(
                  trend: _cachedTrends![index],
                  formatMoney: moneyFormatter,
                  onTap: () {
                    final trend = _cachedTrends![index];

                    // Use the selected date range filter (respects paycheck mode)
                    // Now includes projected items for current period
                    final combinedPulses =
                        InsightsCalculator.getTransactionsForPeriod(
                          pulses: store.pulses,
                          timelineItems: store.timelineItems,
                          range: _selectedRange,
                          viewMode: _viewMode,
                          paycheckDay: settings.paycheckDay,
                          includeInternalTransfers:
                              settings.includeInternalTransfersInReports,
                        );

                    // Filter for category
                    final itemMap = {
                      for (var i in store.timelineItems) i.id.value: i,
                    };
                    final labelToItemMap = {
                      for (var i in store.timelineItems)
                        i.label.toLowerCase(): i,
                    };

                    final transactions = combinedPulses.where((p) {
                      if (p.type.isIncomeType) return false;

                      final category =
                          InsightsCalculator.resolveCategory(
                            p,
                            itemMap,
                            labelToItemMap,
                          ) ??
                          'Uncategorized';
                      return category == trend.category;
                    }).toList();

                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      builder: (_) => TransactionDetailsSheet(
                        title:
                            '${trend.category} (${_selectedRange.labelForMode(isPaycheckMode)})',
                        transactions: transactions,
                        formatMoney: moneyFormatter,
                      ),
                    );
                  },
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
            ],

            // Category spending section
            if (_cachedCategorySpending!.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: PillHeader(
                  label: Terminology.of(
                    context,
                  ).categorySpendingLabel.toUpperCase(),
                ),
              ),
              SliverList.separated(
                itemCount: _cachedCategorySpending!.length.clamp(0, 10),
                separatorBuilder: (_, _) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final spending = _cachedCategorySpending![index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: CategorySpendingCard(
                      spending: spending,
                      formatMoney: moneyFormatter,
                      onTap: () {
                        // Use the selected date range filter (respects paycheck mode)
                        // Now includes projected items for current period
                        final combinedPulses =
                            InsightsCalculator.getTransactionsForPeriod(
                              pulses: store.pulses,
                              timelineItems: store.timelineItems,
                              range: _selectedRange,
                              viewMode: _viewMode,
                              paycheckDay: settings.paycheckDay,
                              includeInternalTransfers:
                                  settings.includeInternalTransfersInReports,
                            );

                        // Filter for category
                        final itemMap = {
                          for (var i in store.timelineItems) i.id.value: i,
                        };
                        final labelToItemMap = {
                          for (var i in store.timelineItems)
                            i.label.toLowerCase(): i,
                        };

                        final transactions = combinedPulses.where((p) {
                          if (p.type.isIncomeType) return false;

                          final category =
                              InsightsCalculator.resolveCategory(
                                p,
                                itemMap,
                                labelToItemMap,
                              ) ??
                              'Uncategorized';
                          return category == spending.category;
                        }).toList();

                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => TransactionDetailsSheet(
                            title:
                                '${spending.category} (${_selectedRange.labelForMode(isPaycheckMode)})',
                            transactions: transactions,
                            formatMoney: moneyFormatter,
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ],

            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ],
      ),
    );
  }
}
