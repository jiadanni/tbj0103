import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/widgets/update_pulse_sheet.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

class TransactionDetailsSheet extends StatefulWidget {
  const TransactionDetailsSheet({
    super.key,
    required this.title,
    required this.transactions,
    required this.formatMoney,
  });

  final String title;
  final List<PulseEntry> transactions;
  final String Function(int) formatMoney;

  @override
  State<TransactionDetailsSheet> createState() =>
      _TransactionDetailsSheetState();
}

class _TransactionDetailsSheetState extends State<TransactionDetailsSheet> {
  late List<PulseEntry> _transactions;

  @override
  void initState() {
    super.initState();
    _transactions = List<PulseEntry>.from(widget.transactions)
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  Future<void> _editTransaction(PulseEntry transaction) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    final updated = await showModalBottomSheet<PulseEntry>(
      context: context,
      isScrollControlled: true,
      builder: (_) => UpdatePulseSheet(
        pulse: transaction,
        title: 'Edit ${Terminology.of(context).transactionLabel}',
      ),
    );

    if (updated != null && mounted) {
      // Apply balance diff
      if (!settings.balanceUpdatesDisabled) {
        settings.currentBalanceCents =
            settings.currentBalanceCents -
            transaction.amountMinorUnits +
            updated.amountMinorUnits;
      }

      // Update store
      store.upsertPulse(updated);

      // Update local list
      setState(() {
        final index = _transactions.indexWhere((p) => p.id == updated.id);
        if (index >= 0) {
          _transactions[index] = updated;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: theme.scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              // Handle
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: theme.colorScheme.onSurfaceVariant.withValues(
                    alpha: 0.4,
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      widget.title,
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Tap a ${Terminology.of(context).transactionLabel.toLowerCase()} to edit',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),

              if (_transactions.isEmpty)
                Expanded(
                  child: Center(
                    child: Text(
                      'No ${Terminology.of(context).transactionLabel.toLowerCase()}s found',
                    ),
                  ),
                )
              else
                Expanded(
                  child: ListView.separated(
                    controller: scrollController,
                    itemCount: _transactions.length,
                    separatorBuilder: (_, _) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final transaction = _transactions[index];
                      final amount =
                          transaction.transactionAmountMinorUnits ??
                          transaction.amountMinorUnits;

                      return ListTile(
                        onTap: () => _editTransaction(transaction),
                        leading: CircleAvatar(
                          backgroundColor: theme.colorScheme.primaryContainer,
                          child: Icon(
                            PhosphorIcons.receipt(),
                            color: theme.colorScheme.onPrimaryContainer,
                            size: 20,
                          ),
                        ),
                        title: Text(
                          transaction.label,
                          style: theme.textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              DateFormat.yMMMd().format(transaction.date),
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                            if (transaction.category != null)
                              Text(
                                transaction.category!,
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              widget.formatMoney(amount),
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Icon(
                              Icons.chevron_right,
                              size: 20,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
