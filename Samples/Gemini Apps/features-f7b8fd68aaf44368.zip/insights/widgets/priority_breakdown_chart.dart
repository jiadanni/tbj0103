import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

/// Displays a donut chart showing critical/advisable/optional breakdown.
class PriorityBreakdownChart extends StatelessWidget {
  const PriorityBreakdownChart({
    super.key,
    required this.breakdown,
    required this.formatMoney,
  });

  final PriorityBreakdown breakdown;
  final String Function(int) formatMoney;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasData = breakdown.totalMinorUnits > 0;

    // Use theme colors
    final criticalColor = theme.colorScheme.error;
    final advisableColor = theme.colorScheme.primary;
    final strategicColor = theme.colorScheme.secondary;
    final optionalColor = theme.colorScheme.tertiary;
    final frivolousColor = theme
        .colorScheme
        .errorContainer; // Distinct from critical but warning-like

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header moved to parent/removed here to be flexible
          if (!hasData)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 32),
                child: Text(
                  'No expense data',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            )
          else
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Donut chart
                SizedBox(
                  width: 140, // Slightly larger
                  height: 140,
                  child: CustomPaint(
                    painter: _DonutChartPainter(
                      breakdown: breakdown,
                      backgroundColor:
                          theme.colorScheme.surfaceContainerHighest,
                      criticalColor: criticalColor,
                      advisableColor: advisableColor,
                      strategicColor: strategicColor,
                      optionalColor: optionalColor,
                      frivolousColor: frivolousColor,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Total',
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                          Text(
                            formatMoney(breakdown.totalMinorUnits),
                            style: theme.textTheme.labelLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 32),
                // Legend
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _LegendItem(
                        color: criticalColor,
                        label: 'Essential',
                        percentage: breakdown.criticalPercentage,
                        amount: formatMoney(breakdown.criticalMinorUnits),
                      ),
                      const SizedBox(height: 8), // Reduced gap to fit 5 items
                      _LegendItem(
                        color: advisableColor,
                        label: 'Important',
                        percentage: breakdown.advisablePercentage,
                        amount: formatMoney(breakdown.advisableMinorUnits),
                      ),
                      const SizedBox(height: 8),
                      _LegendItem(
                        color: strategicColor,
                        label: 'Strategic',
                        percentage: breakdown.strategicPercentage,
                        amount: formatMoney(breakdown.strategicMinorUnits),
                      ),
                      const SizedBox(height: 8),
                      _LegendItem(
                        color: optionalColor,
                        label: 'Discretionary',
                        percentage: breakdown.optionalPercentage,
                        amount: formatMoney(breakdown.optionalMinorUnits),
                      ),
                      const SizedBox(height: 8),
                      _LegendItem(
                        color: frivolousColor,
                        label: 'Frivolous',
                        percentage: breakdown.frivolousPercentage,
                        amount: formatMoney(breakdown.frivolousMinorUnits),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  const _LegendItem({
    required this.color,
    required this.label,
    required this.percentage,
    required this.amount,
  });

  final Color color;
  final String label;
  final double percentage;
  final String amount;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (percentage <= 0)
      return const SizedBox.shrink(); // Hide if 0%? Or show as 0? Let's hide to save space if 5 items

    return Row(
      children: [
        Container(
          width: 8, // Smaller dot
          height: 8,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle, // Circle instead of square
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    amount,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '(${percentage.toStringAsFixed(0)}%)',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _DonutChartPainter extends CustomPainter {
  _DonutChartPainter({
    required this.breakdown,
    required this.backgroundColor,
    required this.criticalColor,
    required this.advisableColor,
    required this.strategicColor,
    required this.optionalColor,
    required this.frivolousColor,
  });

  final PriorityBreakdown breakdown;
  final Color backgroundColor;
  final Color criticalColor;
  final Color advisableColor;
  final Color strategicColor;
  final Color optionalColor;
  final Color frivolousColor;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;
    final strokeWidth = 16.0; // Thicker clearer ring
    final innerRadius = radius - strokeWidth / 2; // Adjusted for stroke center

    final rect = Rect.fromCircle(center: center, radius: innerRadius);

    // Background circle
    final bgPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, innerRadius, bgPaint);

    if (breakdown.totalMinorUnits == 0) return;

    // Draw segments
    double startAngle = -math.pi / 2; // Start from top

    void drawSegment(double percentage, Color color) {
      if (percentage <= 0) return;

      // Add a small gap if there are multiple segments
      final gapSize = 0.05; // rad
      final rawSweep = (percentage / 100) * 2 * math.pi;

      // Ensure specific sweep isn't negative if percentage is tiny
      final effectiveSweep = math.max(
        0.001,
        rawSweep - (percentage < 100 ? gapSize : 0),
      );

      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round;

      if (effectiveSweep > 0) {
        canvas.drawArc(rect, startAngle, effectiveSweep, false, paint);
      }
      startAngle += rawSweep; // Advance by the full angle
    }

    drawSegment(breakdown.criticalPercentage, criticalColor);
    drawSegment(breakdown.advisablePercentage, advisableColor);
    drawSegment(breakdown.strategicPercentage, strategicColor);
    drawSegment(breakdown.optionalPercentage, optionalColor);
    drawSegment(breakdown.frivolousPercentage, frivolousColor);
  }

  @override
  bool shouldRepaint(covariant _DonutChartPainter oldDelegate) {
    // Explicitly check breakdown equality (now that it is Equatable)
    return oldDelegate.breakdown != breakdown ||
        oldDelegate.backgroundColor != backgroundColor ||
        oldDelegate.criticalColor != criticalColor ||
        oldDelegate.strategicColor != strategicColor;
  }
}
