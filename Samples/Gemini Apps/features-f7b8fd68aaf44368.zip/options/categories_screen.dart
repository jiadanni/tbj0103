import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/src/util/pulse_display.dart';
import 'package:expense_stalker_mobile/src/features/options/icon_picker_dialog.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/features/options/subcategories_screen.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n?.categories ?? 'Categories'),
          bottom: TabBar(
            tabs: [
              Tab(text: Terminology.of(context).debitsLabel),
              Tab(text: Terminology.of(context).creditsLabel),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _CategoryList(isIncome: false),
            _CategoryList(isIncome: true),
          ],
        ),
      ),
    );
  }
}

class _CategoryList extends StatefulWidget {
  final bool isIncome;

  const _CategoryList({required this.isIncome});

  @override
  State<_CategoryList> createState() => _CategoryListState();
}

class _CategoryListState extends State<_CategoryList> {
  final TextEditingController _addController = TextEditingController();

  @override
  void dispose() {
    _addController.dispose();
    super.dispose();
  }

  void _showAddDialog() {
    final l10n = AppLocalizations.of(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          widget.isIncome
              ? 'Add ${Terminology.of(context).creditsLabel} Category'
              : 'Add ${Terminology.of(context).debitsLabel} Category',
        ),
        content: TextField(
          controller: _addController,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Category name'),
          onSubmitted: (_) => _handleAdd(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          TextButton(onPressed: _handleAdd, child: Text(l10n?.add ?? 'Add')),
        ],
      ),
    );
  }

  void _handleAdd() {
    final name = _addController.text.trim();
    if (name.isNotEmpty) {
      ExpenseStoreScope.read(
        context,
      ).addCustomCategory(name, isIncome: widget.isIncome);
      _addController.clear();
      Navigator.pop(context);
    }
  }

  void _showRenameDialog(String oldName) {
    final controller = TextEditingController(text: oldName);
    final l10n = AppLocalizations.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Category'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'New category name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          TextButton(
            onPressed: () {
              final newName = controller.text.trim();
              if (newName.isNotEmpty && newName != oldName) {
                ExpenseStoreScope.read(context).renameCustomCategory(
                  oldName,
                  newName,
                  isIncome: widget.isIncome,
                );
              }
              Navigator.pop(context);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  Future<void> _handleIconChange(String category) async {
    final newIconCodePoint = await showDialog<int>(
      context: context,
      builder: (context) => const IconPickerDialog(),
    );

    if (newIconCodePoint != null && mounted) {
      await ExpenseStoreScope.read(
        context,
      ).updateCategoryIcon(category, newIconCodePoint);
    }
  }

  void _navigateToSubcategories(String category) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            SubcategoriesScreen(category: category, isIncome: widget.isIncome),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;

    final customCategories = widget.isIncome
        ? store.currentAccount.customIncomeCategories
        : store.currentAccount.customExpenseCategories;

    final defaultCategories = widget.isIncome
        ? incomeCategories
        : expenseCategories;
    final categoryIcons = store.currentAccount.categoryIcons;
    final customSubcategoriesMap = store.currentAccount.customSubcategories;

    int getSubcategoryCount(String category) {
      final defaultCount = getSubcategorySuggestions(
        category: category,
        isIncome: widget.isIncome,
      ).length;
      final customCount = customSubcategoriesMap[category]?.length ?? 0;
      return defaultCount + customCount;
    }

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        if (customCategories.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Custom Categories',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  onPressed: _showAddDialog,
                  icon: const Icon(Icons.add_circle_outline),
                  tooltip: 'Add Category',
                ),
              ],
            ),
          ),
          ...customCategories.map((cat) {
            final count = getSubcategoryCount(cat);
            return ListTile(
              leading: GestureDetector(
                onTap: () => _handleIconChange(cat),
                child: CircleAvatar(
                  backgroundColor: colorScheme.surfaceContainerHighest,
                  child: Icon(
                    getPulseIcon(
                      cat,
                      type: widget.isIncome
                          ? PulseType.oneOffIncome
                          : PulseType.oneOff,
                      categoryIcons: categoryIcons,
                    ),
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              title: Text(cat),
              subtitle: Text('$count subcategor${count == 1 ? 'y' : 'ies'}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined, size: 20),
                    onPressed: () => _showRenameDialog(cat),
                    tooltip: 'Rename Category',
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    color: colorScheme.error,
                    onPressed: () {
                      ExpenseStoreScope.read(
                        context,
                      ).removeCustomCategory(cat, isIncome: widget.isIncome);
                    },
                    tooltip: 'Delete Category',
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
              onTap: () => _navigateToSubcategories(cat),
            );
          }),
          const Divider(),
        ],

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Default Categories',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (customCategories.isEmpty)
                IconButton(
                  onPressed: _showAddDialog,
                  icon: const Icon(Icons.add_circle_outline),
                  tooltip: 'Add Custom Category',
                ),
            ],
          ),
        ),
        ...defaultCategories.map((cat) {
          final count = getSubcategoryCount(cat);
          return ListTile(
            leading: GestureDetector(
              onTap: () => _handleIconChange(cat),
              child: CircleAvatar(
                backgroundColor: colorScheme.surfaceContainerHighest,
                child: Icon(
                  getPulseIcon(
                    cat,
                    type: widget.isIncome
                        ? PulseType.oneOffIncome
                        : PulseType.oneOff,
                    categoryIcons: categoryIcons,
                  ),
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            title: Text(cat),
            subtitle: Text('$count subcategor${count == 1 ? 'y' : 'ies'}'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _navigateToSubcategories(cat),
          );
        }),

        // Add safe area at the bottom
        const SizedBox(height: 32),
      ],
    );
  }
}
