import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class SubcategoriesScreen extends StatefulWidget {
  final String category;
  final bool isIncome;

  const SubcategoriesScreen({
    super.key,
    required this.category,
    required this.isIncome,
  });

  @override
  State<SubcategoriesScreen> createState() => _SubcategoriesScreenState();
}

class _SubcategoriesScreenState extends State<SubcategoriesScreen> {
  final TextEditingController _addController = TextEditingController();

  @override
  void dispose() {
    _addController.dispose();
    super.dispose();
  }

  void _showAddSubcategoryDialog() {
    final l10n = AppLocalizations.of(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add Subcategory to ${widget.category}'),
        content: TextField(
          controller: _addController,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Subcategory name'),
          onSubmitted: (_) {
            _handleAdd();
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          TextButton(onPressed: _handleAdd, child: Text(l10n?.add ?? 'Add')),
        ],
      ),
    );
  }

  void _handleAdd() {
    final name = _addController.text.trim();
    if (name.isNotEmpty) {
      ExpenseStoreScope.read(
        context,
      ).addCustomSubcategory(widget.category, name);
      _addController.clear();
      Navigator.pop(context);
    }
  }

  void _showRenameSubcategoryDialog(String oldName) {
    final controller = TextEditingController(text: oldName);
    final l10n = AppLocalizations.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Subcategory'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'New subcategory name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          TextButton(
            onPressed: () {
              final newName = controller.text.trim();
              if (newName.isNotEmpty && newName != oldName) {
                ExpenseStoreScope.read(
                  context,
                ).renameCustomSubcategory(widget.category, oldName, newName);
              }
              Navigator.pop(context);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;

    // Default subcategories
    final defaultSubcategories = getSubcategorySuggestions(
      category: widget.category,
      isIncome: widget.isIncome,
    );

    // Custom subcategories
    final customSubcategoriesMap = store.currentAccount.customSubcategories;
    final customSubcategories = customSubcategoriesMap[widget.category] ?? [];

    final hasDefault = defaultSubcategories.isNotEmpty;
    final hasCustom = customSubcategories.isNotEmpty;

    return Scaffold(
      appBar: AppBar(title: Text('${widget.category} Subcategories')),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddSubcategoryDialog,
        tooltip: 'Add Subcategory',
        child: const Icon(Icons.add),
      ),
      body: (!hasDefault && !hasCustom)
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.category_outlined,
                      size: 64,
                      color: colorScheme.onSurfaceVariant.withValues(
                        alpha: 0.5,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No subcategories yet',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Add custom subcategories to organize your expenses in more detail.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                if (hasDefault) ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(
                      'Default',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ...defaultSubcategories.map(
                    (sub) => ListTile(
                      leading: const CircleAvatar(
                        radius: 16,
                        child: Icon(Icons.subdirectory_arrow_right, size: 16),
                      ),
                      title: Text(sub),
                    ),
                  ),
                ],

                if (hasCustom) ...[
                  Padding(
                    padding: EdgeInsets.fromLTRB(
                      16,
                      hasDefault ? 24 : 16,
                      16,
                      8,
                    ),
                    child: Text(
                      'Custom',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ...customSubcategories.map(
                    (sub) => ListTile(
                      leading: const CircleAvatar(
                        radius: 16,
                        child: Icon(Icons.subdirectory_arrow_right, size: 16),
                      ),
                      title: Text(sub),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined, size: 20),
                            onPressed: () => _showRenameSubcategoryDialog(sub),
                            tooltip: 'Rename',
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 20),
                            color: colorScheme.error,
                            onPressed: () {
                              ExpenseStoreScope.read(
                                context,
                              ).removeCustomSubcategory(widget.category, sub);
                            },
                            tooltip: 'Delete',
                          ),
                        ],
                      ),
                    ),
                  ),
                ],

                // Add some padding at the bottom for the FAB
                const SizedBox(height: 80),
              ],
            ),
    );
  }
}
