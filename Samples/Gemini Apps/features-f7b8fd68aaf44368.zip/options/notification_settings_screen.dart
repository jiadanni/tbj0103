import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/services/notification_service.dart';
import 'package:intl/intl.dart';

/// Screen for managing notification preferences.
///
/// Provides controls for:
/// - Master notification toggle
/// - Daily alert settings
/// - Weekly alert settings
/// - Weekly summary settings
/// - Week start day configuration
class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  final NotificationService _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    _notificationService.initialize();
  }

  Future<void> _selectTime({
    required BuildContext context,
    required int initialHour,
    required int initialMinute,
    required Function(TimeOfDay) onTimeSelected,
  }) async {
    final initialTime = TimeOfDay(hour: initialHour, minute: initialMinute);
    final selectedTime = await showTimePicker(
      context: context,
      initialTime: initialTime,
    );

    if (selectedTime != null) {
      onTimeSelected(selectedTime);
    }
  }

  Future<void> _rescheduleNotifications(
    ExpenseStore store,
    AppSettingsStore settings,
  ) async {
    await _notificationService.scheduleFromSettings(store, settings);
  }

  String _formatTime(int hour, int minute) {
    final now = DateTime.now();
    final time = DateTime(now.year, now.month, now.day, hour, minute);
    return DateFormat.jm().format(time);
  }

  String _getDayName(int day) {
    switch (day) {
      case 1:
        return 'Monday';
      case 2:
        return 'Tuesday';
      case 3:
        return 'Wednesday';
      case 4:
        return 'Thursday';
      case 5:
        return 'Friday';
      case 6:
        return 'Saturday';
      case 7:
        return 'Sunday';
      default:
        return 'Unknown';
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final settings = AppSettingsScope.of(context);
    final theme = Theme.of(context);

    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final account = store.currentAccount;

        final accountSettings = account.settings;

        return Scaffold(
          appBar: AppBar(title: const Text('Notifications')),
          body: ListView(
            children: [
              // Master toggle
              SwitchListTile(
                secondary: Icon(
                  accountSettings.notificationsEnabled
                      ? PhosphorIconsDuotone.bell
                      : PhosphorIconsDuotone.bellSlash,
                  color: theme.colorScheme.primary,
                ),
                title: const Text('Enable Notifications'),
                subtitle: const Text(
                  'Master toggle for all notification features',
                ),
                value: accountSettings.notificationsEnabled,
                onChanged: (value) async {
                  store.updateAccountSettings(
                    account.id,
                    notificationsEnabled: value,
                  );

                  if (value) {
                    // Request permissions when enabling notifications
                    await _notificationService.requestPermissions();
                  }

                  await _rescheduleNotifications(store, settings);
                },
              ),

              const Divider(),

              // Daily Alert Section
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    Icon(
                      PhosphorIconsDuotone.sun,
                      size: 20,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'DAILY ALERT',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: const Text('Daily Alert'),
                subtitle: const Text(
                  'Daily projected expenses, income, and balance',
                ),
                value: accountSettings.dailyAlertEnabled,
                onChanged: accountSettings.notificationsEnabled
                    ? (value) async {
                        store.updateAccountSettings(
                          account.id,
                          dailyAlertEnabled: value,
                        );
                        await _rescheduleNotifications(store, settings);
                      }
                    : null,
              ),
              if (accountSettings.dailyAlertEnabled)
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                  leading: const SizedBox(width: 24),
                  title: const Text('Alert Time'),
                  subtitle: Text(
                    _formatTime(
                      accountSettings.dailyAlertHour,
                      accountSettings.dailyAlertMinute,
                    ),
                  ),
                  trailing: TextButton(
                    onPressed: accountSettings.notificationsEnabled
                        ? () => _selectTime(
                            context: context,
                            initialHour: accountSettings.dailyAlertHour,
                            initialMinute: accountSettings.dailyAlertMinute,
                            onTimeSelected: (time) async {
                              store.updateAccountSettings(
                                account.id,
                                dailyAlertHour: time.hour,
                                dailyAlertMinute: time.minute,
                              );
                              await _rescheduleNotifications(store, settings);
                            },
                          )
                        : null,
                    child: const Text('Change'),
                  ),
                ),

              const Divider(),

              // Weekly Alert Section
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    Icon(
                      PhosphorIconsDuotone.calendarCheck,
                      size: 20,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'WEEKLY ALERT',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: const Text('Weekly Alert'),
                subtitle: const Text('Reminder at the start of each week'),
                value: accountSettings.weeklyAlertEnabled,
                onChanged: accountSettings.notificationsEnabled
                    ? (value) async {
                        store.updateAccountSettings(
                          account.id,
                          weeklyAlertEnabled: value,
                        );
                        await _rescheduleNotifications(store, settings);
                      }
                    : null,
              ),
              if (accountSettings.weeklyAlertEnabled)
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                  leading: const SizedBox(width: 24),
                  title: const Text('Alert Time'),
                  subtitle: Text(
                    _formatTime(
                      accountSettings.weeklyAlertHour,
                      accountSettings.weeklyAlertMinute,
                    ),
                  ),
                  trailing: TextButton(
                    onPressed: accountSettings.notificationsEnabled
                        ? () => _selectTime(
                            context: context,
                            initialHour: accountSettings.weeklyAlertHour,
                            initialMinute: accountSettings.weeklyAlertMinute,
                            onTimeSelected: (time) async {
                              store.updateAccountSettings(
                                account.id,
                                weeklyAlertHour: time.hour,
                                weeklyAlertMinute: time.minute,
                              );
                              await _rescheduleNotifications(store, settings);
                            },
                          )
                        : null,
                    child: const Text('Change'),
                  ),
                ),

              const Divider(),

              // Weekly Summary Section
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    Icon(
                      PhosphorIconsDuotone.chartBar,
                      size: 20,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'WEEKLY SUMMARY',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: const Text('Weekly Summary'),
                subtitle: const Text('Summary at the end of each week'),
                value: accountSettings.weeklySummaryEnabled,
                onChanged: accountSettings.notificationsEnabled
                    ? (value) async {
                        store.updateAccountSettings(
                          account.id,
                          weeklySummaryEnabled: value,
                        );
                        await _rescheduleNotifications(store, settings);
                      }
                    : null,
              ),
              if (accountSettings.weeklySummaryEnabled)
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                  leading: const SizedBox(width: 24),
                  title: const Text('Summary Time'),
                  subtitle: Text(
                    _formatTime(
                      accountSettings.weeklySummaryHour,
                      accountSettings.weeklySummaryMinute,
                    ),
                  ),
                  trailing: TextButton(
                    onPressed: accountSettings.notificationsEnabled
                        ? () => _selectTime(
                            context: context,
                            initialHour: accountSettings.weeklySummaryHour,
                            initialMinute: accountSettings.weeklySummaryMinute,
                            onTimeSelected: (time) async {
                              store.updateAccountSettings(
                                account.id,
                                weeklySummaryHour: time.hour,
                                weeklySummaryMinute: time.minute,
                              );
                              await _rescheduleNotifications(store, settings);
                            },
                          )
                        : null,
                    child: const Text('Change'),
                  ),
                ),

              const Divider(),

              // Week Configuration Section
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    Icon(
                      PhosphorIconsDuotone.calendar,
                      size: 20,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'WEEK CONFIGURATION',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: const Text('Week Start Day'),
                subtitle: Text(_getDayName(accountSettings.weekStartDay)),
                trailing: DropdownButton<int>(
                  value: accountSettings.weekStartDay,
                  onChanged: accountSettings.notificationsEnabled
                      ? (value) async {
                          if (value == null) return;
                          store.updateAccountSettings(
                            account.id,
                            weekStartDay: value,
                          );
                          await _rescheduleNotifications(store, settings);
                        }
                      : null,
                  items: List.generate(7, (index) {
                    final day = index + 1;
                    return DropdownMenuItem<int>(
                      value: day,
                      child: Text(_getDayName(day)),
                    );
                  }),
                ),
              ),

              const SizedBox(height: 16),

              // Info Card
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Card(
                  color: theme.colorScheme.primaryContainer.withValues(
                    alpha: 0.3,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              PhosphorIconsDuotone.info,
                              color: theme.colorScheme.primary,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'About Notifications',
                              style: theme.textTheme.titleSmall?.copyWith(
                                color: theme.colorScheme.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Daily alerts show your projected expenses, income, and remaining balance for today.\n\n'
                          'Weekly alerts remind you at the start of each week to plan your expenses.\n\n'
                          'Weekly summaries provide an overview of your spending at the end of each week.\n\n'
                          'All notifications use your device\'s local timezone.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(
                              alpha: 0.7,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
