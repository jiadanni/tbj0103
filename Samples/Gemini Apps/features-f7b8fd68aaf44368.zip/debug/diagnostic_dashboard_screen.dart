import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:share_plus/share_plus.dart';

/// Developer-facing screen for viewing error logs and diagnostic events.
///
/// Shows:
/// - Event logs from DebugLogger
/// - Error logs and statistics from ErrorTracker
/// - Detailed error information
class DiagnosticDashboardScreen extends StatefulWidget {
  const DiagnosticDashboardScreen({super.key});

  @override
  State<DiagnosticDashboardScreen> createState() =>
      _DiagnosticDashboardScreenState();
}

class _DiagnosticDashboardScreenState extends State<DiagnosticDashboardScreen> {
  ErrorSeverity? _filterSeverity;
  LogCategory? _filterCategory;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Diagnostic Dashboard'),
          actions: [
            IconButton(
              icon: const Icon(Icons.copy_all),
              onPressed: _copyAllLogs,
              tooltip: 'Copy All Logs',
            ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: _shareAllLogs,
              tooltip: 'Share All Logs',
            ),
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () => setState(() {}),
              tooltip: 'Refresh',
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: _confirmClearHistory,
              tooltip: 'Clear History',
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Logs', icon: Icon(Icons.list_alt)),
              Tab(text: 'Errors', icon: Icon(Icons.bug_report)),
            ],
          ),
        ),
        body: TabBarView(children: [_buildLogsTab(), _buildErrorsTab()]),
      ),
    );
  }

  Widget _buildLogsTab() {
    final logs = DebugLogger.instance.logHistory.toList().reversed.toList();
    final filteredLogs = _filterCategory == null
        ? logs
        : logs.where((l) => l.category == _filterCategory).toList();

    return Column(
      children: [
        _buildLogFilters(),
        Expanded(
          child: filteredLogs.isEmpty
              ? const Center(child: Text('No logs found'))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: filteredLogs.length,
                  itemBuilder: (context, index) =>
                      _buildLogTile(filteredLogs[index]),
                ),
        ),
      ],
    );
  }

  Widget _buildLogFilters() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Wrap(
        spacing: 8,
        children: [
          FilterChip(
            label: const Text('All'),
            selected: _filterCategory == null,
            onSelected: (_) => setState(() => _filterCategory = null),
          ),
          ...LogCategory.values.map(
            (cat) => FilterChip(
              label: Text(cat.name.toUpperCase()),
              selected: _filterCategory == cat,
              onSelected: (selected) =>
                  setState(() => _filterCategory = selected ? cat : null),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogTile(LogEntry entry) {
    final color = _getCategoryColor(entry.category);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '${entry.timestamp.hour.toString().padLeft(2, '0')}:${entry.timestamp.minute.toString().padLeft(2, '0')}:${entry.timestamp.second.toString().padLeft(2, '0')}.${entry.timestamp.millisecond.toString().padLeft(3, '0')}',
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(fontFamily: 'monospace'),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: color.withValues(alpha: 0.3)),
                ),
                child: Text(
                  entry.category.prefix,
                  style: TextStyle(
                    color: color,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          SelectableText(
            entry.message,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontFamily: 'monospace',
              fontSize: 13,
            ),
          ),
          if (entry.error != null) ...[
            const SizedBox(height: 4),
            Text(
              'Error: ${entry.error}',
              style: const TextStyle(
                color: Colors.red,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
          const Divider(),
        ],
      ),
    );
  }

  Color _getCategoryColor(LogCategory category) {
    return switch (category) {
      LogCategory.persistence => Colors.blue,
      LogCategory.state => Colors.green,
      LogCategory.ui => Colors.orange,
      LogCategory.network => Colors.purple,
      LogCategory.export => Colors.teal,
    };
  }

  Widget _buildErrorsTab() {
    final tracker = ErrorTracker.instance;
    final errors = _filterSeverity == null
        ? tracker.getRecentErrors()
        : tracker.getErrorsBySeverity(_filterSeverity!);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildStatisticsCard(tracker),
        const SizedBox(height: 16),
        _buildSeverityFilters(),
        const SizedBox(height: 16),
        _buildErrorList(errors),
      ],
    );
  }

  Widget _buildStatisticsCard(ErrorTracker tracker) {
    final stats = tracker.getErrorStatistics();
    final criticalCount = tracker.getCriticalErrors().length;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Statistics', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem(
                  'Total',
                  tracker.errorCount.toString(),
                  Icons.bug_report,
                  Colors.blue,
                ),
                _buildStatItem(
                  'Critical',
                  criticalCount.toString(),
                  Icons.error,
                  criticalCount > 0 ? Colors.red : Colors.grey,
                ),
                _buildStatItem(
                  'Categories',
                  stats.length.toString(),
                  Icons.category,
                  Colors.orange,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Column(
      children: [
        Icon(icon, size: 32, color: color),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildSeverityFilters() {
    return Wrap(
      spacing: 8,
      children: [
        FilterChip(
          label: const Text('All'),
          selected: _filterSeverity == null,
          onSelected: (_) => setState(() => _filterSeverity = null),
        ),
        ...ErrorSeverity.values.map(
          (severity) => FilterChip(
            label: Text(severity.name.toUpperCase()),
            selected: _filterSeverity == severity,
            onSelected: (selected) =>
                setState(() => _filterSeverity = selected ? severity : null),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorList(List<ErrorContext> errors) {
    if (errors.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            children: [
              Icon(
                Icons.check_circle_outline,
                size: 64,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 16),
              const Text(
                'No Errors',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Errors (${errors.length})',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        ...errors.reversed.map((error) => _buildErrorCard(error)),
      ],
    );
  }

  Widget _buildErrorCard(ErrorContext error) {
    final severityColor = _getSeverityColor(error.severity);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(_getSeverityIcon(error.severity), color: severityColor),
        title: Text(error.message),
        subtitle: Text(
          '${error.category} • ${error.severity.name}',
          style: TextStyle(color: severityColor),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showErrorDetails(error),
      ),
    );
  }

  void _showErrorDetails(ErrorContext error) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) {
          return Container(
            padding: const EdgeInsets.all(16),
            child: ListView(
              controller: scrollController,
              children: [
                Row(
                  children: [
                    Icon(
                      _getSeverityIcon(error.severity),
                      color: _getSeverityColor(error.severity),
                      size: 32,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            error.message,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          Text(
                            '${error.category} • ${error.severity.name.toUpperCase()}',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: _getSeverityColor(error.severity),
                                ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy),
                      onPressed: () => _copyErrorToClipboard(error),
                    ),
                  ],
                ),
                const Divider(height: 32),
                if (error.error != null)
                  _buildDetailSection('Error', error.error.toString()),
                if (error.stackTrace != null)
                  _buildDetailSection(
                    'Stack Trace',
                    error.stackTrace.toString(),
                  ),
                if (error.additionalData != null &&
                    error.additionalData!.isNotEmpty)
                  _buildDetailSection(
                    'Additional Data',
                    error.additionalData.toString(),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          width: double.infinity,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
          child: SelectableText(
            content,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Future<void> _copyErrorToClipboard(ErrorContext error) async {
    final text =
        'Summary: ${error.message}\nCategory: ${error.category}\nSeverity: ${error.severity.name}\nError: ${error.error}\nStack: ${error.stackTrace}';
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Copied to clipboard')));
  }

  Future<void> _copyAllLogs() async {
    final allLogs = DebugLogger.instance.toFormattedString();
    final allErrors = ErrorTracker.instance.toFormattedString();
    final combined =
        '=== SYSTEM LOGS ===\n$allLogs\n\n=== ERROR TRACKER ===\n$allErrors';

    await Clipboard.setData(ClipboardData(text: combined));
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All logs and errors copied to clipboard'),
        ),
      );
  }

  Future<void> _shareAllLogs() async {
    final allLogs = DebugLogger.instance.toFormattedString();
    final allErrors = ErrorTracker.instance.toFormattedString();
    final combined =
        '=== SYSTEM LOGS ===\n$allLogs\n\n=== ERROR TRACKER ===\n$allErrors';

    await SharePlus.instance.share(
      ShareParams(text: combined, subject: 'Expense Stalker Diagnostic Logs'),
    );
  }

  Future<void> _confirmClearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Histories'),
        content: const Text('Clear both event logs and error history?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      ErrorTracker.instance.clearHistory();
      DebugLogger.instance.clear();
      setState(() {});
    }
  }

  IconData _getSeverityIcon(ErrorSeverity severity) => switch (severity) {
    ErrorSeverity.info => Icons.info_outline,
    ErrorSeverity.warning => Icons.warning_amber,
    ErrorSeverity.error => Icons.error_outline,
    ErrorSeverity.critical => Icons.dangerous,
  };

  Color _getSeverityColor(ErrorSeverity severity) => switch (severity) {
    ErrorSeverity.info => Colors.blue,
    ErrorSeverity.warning => Colors.orange,
    ErrorSeverity.error => Colors.red,
    ErrorSeverity.critical => Colors.purple,
  };
}
