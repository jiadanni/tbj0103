import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Experience step - feature overview and demo data toggle.
class ExperienceStep extends StatelessWidget {
  const ExperienceStep({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.demoDataEnabled,
    required this.onToggleDemoData,
  });

  final VoidCallback onNext;
  final VoidCallback onBack;
  final bool demoDataEnabled;
  final ValueChanged<bool> onToggleDemoData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Back button
            IconButton(
              onPressed: onBack,
              icon: PhosphorIcon(
                PhosphorIcons.arrowLeft(),
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Title
            Text(
              'Explore Expense Stalker',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingSmall),

            Text(
              'Discover how to take control of your finances.',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),

            const SizedBox(height: AppConstants.paddingXLarge),

            // Feature Highlights
            _FeatureItem(
              icon: PhosphorIcons.calendarCheck(PhosphorIconsStyle.duotone),
              color: colorScheme.primary,
              title: l10n?.onboardingTourTimelineTitle ?? 'Timeline',
              subtitle:
                  l10n?.onboardingFeatureTimeline ??
                  'Flexible daily, monthly or paycheck-based views.',
            ),
            const SizedBox(height: AppConstants.paddingMedium),
            _FeatureItem(
              icon: PhosphorIcons.pulse(PhosphorIconsStyle.duotone),
              color: colorScheme.secondary,
              title: l10n?.onboardingTourPulseTitle ?? 'Pulse',
              subtitle:
                  l10n?.onboardingFeaturePulse ??
                  'Your recurring financial heartbeats, fully automated.',
            ),
            const SizedBox(height: AppConstants.paddingMedium),
            _FeatureItem(
              icon: PhosphorIcons.lightbulb(PhosphorIconsStyle.duotone),
              color: colorScheme.tertiary,
              title: l10n?.onboardingTourInsightsTitle ?? 'Insights',
              subtitle:
                  l10n?.onboardingFeatureInsights ??
                  'Spend wiser with automated behavioral patterns.',
            ),

            const Spacer(),

            // Demo Data Toggle Card
            GestureDetector(
              onTap: () => onToggleDemoData(!demoDataEnabled),
              child: AnimatedContainer(
                duration: AppConstants.animationNormal,
                padding: const EdgeInsets.all(AppConstants.paddingMedium),
                decoration: BoxDecoration(
                  color: demoDataEnabled
                      ? colorScheme.primaryContainer.withValues(alpha: 0.4)
                      : colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
                  border: Border.all(
                    color: demoDataEnabled
                        ? colorScheme.primary
                        : colorScheme.outline.withValues(alpha: 0.2),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: demoDataEnabled
                            ? colorScheme.primary.withValues(alpha: 0.2)
                            : colorScheme.onSurface.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(
                          AppConstants.radiusMedium,
                        ),
                      ),
                      child: PhosphorIcon(
                        PhosphorIcons.database(PhosphorIconsStyle.duotone),
                        size: 24,
                        color: demoDataEnabled
                            ? colorScheme.primary
                            : colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                    const SizedBox(width: AppConstants.paddingMedium),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            l10n?.onboardingDemoDataToggle ?? 'Show Demo Data',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            l10n?.onboardingDemoDataSubtitle ??
                                'Helpful to explore if you are a first time user.',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: colorScheme.onSurface.withValues(
                                alpha: 0.6,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(value: demoDataEnabled, onChanged: onToggleDemoData),
                  ],
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingLarge),

            // Continue button
            SizedBox(
              width: double.infinity,
              height: AppConstants.buttonHeightPrimary,
              child: FilledButton(
                onPressed: onNext,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusButton,
                    ),
                  ),
                ),
                child: Text(
                  l10n?.onboardingContinue ?? 'Continue',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),
          ],
        ),
      ),
    );
  }
}

class _FeatureItem extends StatelessWidget {
  const _FeatureItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          ),
          child: PhosphorIcon(icon, color: color, size: 28),
        ),
        const SizedBox(width: AppConstants.paddingMedium),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                subtitle,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
