import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Account setup step - configure initial account settings, region and currency.
class AccountSetupStep extends StatefulWidget {
  const AccountSetupStep({
    super.key,
    required this.onNext,
    required this.accountName,
    required this.startingBalance,
    required this.selectedIconIndex,
    required this.selectedRegionId,
    required this.selectedCurrency,
    required this.onAccountNameChanged,
    required this.onStartingBalanceChanged,
    required this.onIconSelected,
    required this.onRegionSelected,
    required this.onCurrencySelected,
  });

  final VoidCallback onNext;
  final String accountName;
  final int startingBalance;
  final int selectedIconIndex;
  final String selectedRegionId;
  final AppCurrency selectedCurrency;
  final ValueChanged<String> onAccountNameChanged;
  final ValueChanged<int> onStartingBalanceChanged;
  final ValueChanged<int> onIconSelected;
  final ValueChanged<String> onRegionSelected;
  final ValueChanged<AppCurrency> onCurrencySelected;

  @override
  State<AccountSetupStep> createState() => _AccountSetupStepState();
}

class _AccountSetupStepState extends State<AccountSetupStep> {
  late final TextEditingController _nameController;
  late final TextEditingController _balanceController;
  final _formKey = GlobalKey<FormState>();

  static List<IconData> get _accountIcons => [
    PhosphorIcons.wallet(),
    PhosphorIcons.bank(),
    PhosphorIcons.creditCard(),
    PhosphorIcons.piggyBank(),
    PhosphorIcons.coins(),
    PhosphorIcons.chartLine(),
    PhosphorIcons.house(),
    PhosphorIcons.car(),
    PhosphorIcons.airplane(),
    PhosphorIcons.shoppingCart(),
    PhosphorIcons.heart(),
    PhosphorIcons.star(),
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.accountName);
    _balanceController = TextEditingController(
      text: widget.startingBalance == 0
          ? ''
          : formatMoneyFromCentsNoSymbol(widget.startingBalance),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _balanceController.dispose();
    super.dispose();
  }

  void _onBalanceChanged(String value) {
    // Parse the balance input as cents
    final cleaned = value.replaceAll(RegExp(r'[^\d.-]'), '');
    final parsed = double.tryParse(cleaned) ?? 0;
    final cents = (parsed * 100).round();
    widget.onStartingBalanceChanged(cents);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Header
              Center(
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppConstants.paddingMedium),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: colorScheme.primaryContainer.withValues(
                          alpha: 0.3,
                        ),
                      ),
                      child: PhosphorIcon(
                        PhosphorIcons.wallet(PhosphorIconsStyle.duotone),
                        size: 48,
                        color: colorScheme.primary,
                      ),
                    ),
                    const SizedBox(height: AppConstants.paddingMedium),
                    Text(
                      l10n?.appTitle ?? 'Expense Stalker',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: AppConstants.paddingXSmall),
                    Text(
                      l10n?.onboardingWelcomeTagline ??
                          'Sleek, private expense tracking.',
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: AppConstants.paddingXLarge),

              // Section: Account
              _SectionHeader(
                title: l10n?.onboardingAccountSetupTitle ?? 'Account Setup',
              ),

              const SizedBox(height: AppConstants.paddingMedium),

              // Account name field
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: l10n?.onboardingAccountName ?? 'Account Name',
                  hintText:
                      l10n?.onboardingAccountNameHint ?? 'e.g. Daily Spending',
                  prefixIcon: Icon(
                    PhosphorIcons.textT(),
                    color: colorScheme.primary,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusMedium,
                    ),
                  ),
                ),
                textCapitalization: TextCapitalization.words,
                maxLength: AppConstants.maxAccountNameLength,
                onChanged: widget.onAccountNameChanged,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return l10n?.onboardingAccountNameRequired ??
                        'Account name is required';
                  }
                  return null;
                },
              ),

              const SizedBox(height: AppConstants.paddingSmall),

              // Starting balance field
              TextFormField(
                controller: _balanceController,
                decoration: InputDecoration(
                  labelText:
                      l10n?.onboardingStartingBalance ?? 'Starting Balance',
                  hintText: l10n?.onboardingStartingBalanceHint ?? '0.00',
                  prefixIcon: Icon(
                    PhosphorIcons.currencyDollar(),
                    color: colorScheme.primary,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusMedium,
                    ),
                  ),
                ),
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                  signed: true,
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[\d.-]')),
                ],
                onChanged: _onBalanceChanged,
              ),

              const SizedBox(height: AppConstants.paddingLarge),

              // Icon picker title
              Text(
                l10n?.onboardingChooseIcon ?? 'Choose an Icon',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),

              const SizedBox(height: AppConstants.paddingSmall),

              // Icon grid
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: List.generate(_accountIcons.length, (index) {
                  final isSelected = index == widget.selectedIconIndex;
                  return GestureDetector(
                    onTap: () => widget.onIconSelected(index),
                    child: AnimatedContainer(
                      duration: AppConstants.animationFast,
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? colorScheme.primaryContainer
                            : colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(
                          AppConstants.radiusMedium,
                        ),
                        border: isSelected
                            ? Border.all(color: colorScheme.primary, width: 2)
                            : null,
                      ),
                      child: Icon(
                        _accountIcons[index],
                        size: 20,
                        color: isSelected
                            ? colorScheme.primary
                            : colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                  );
                }),
              ),

              const SizedBox(height: AppConstants.paddingXLarge),

              // Section: Region & Currency
              _SectionHeader(
                title: l10n?.onboardingRegionTitle ?? 'Region & Currency',
              ),

              const SizedBox(height: AppConstants.paddingMedium),

              // Region selection chips
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: AppSettingsPresets.regionPresets.map((preset) {
                  final isSelected = preset.id == widget.selectedRegionId;
                  return ChoiceChip(
                    label: Text(preset.label),
                    selected: isSelected,
                    onSelected: (_) {
                      widget.onRegionSelected(preset.id);
                      if (preset.currency != null) {
                        widget.onCurrencySelected(preset.currency!);
                      }
                    },
                    selectedColor: colorScheme.primaryContainer,
                    backgroundColor: colorScheme.surfaceContainerHighest,
                    labelStyle: TextStyle(
                      color: isSelected
                          ? colorScheme.onPrimaryContainer
                          : colorScheme.onSurface,
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: AppConstants.paddingMedium),

              // Currency dropdown
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(
                    AppConstants.radiusMedium,
                  ),
                  border: Border.all(
                    color: colorScheme.outline.withValues(alpha: 0.3),
                  ),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<AppCurrency>(
                    value: widget.selectedCurrency,
                    isExpanded: true,
                    icon: PhosphorIcon(
                      PhosphorIcons.caretDown(),
                      color: colorScheme.onSurface,
                    ),
                    items: AppCurrency.values.map((currency) {
                      return DropdownMenuItem<AppCurrency>(
                        value: currency,
                        child: Row(
                          children: [
                            Text(
                              currency.symbol,
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                currency.name.toUpperCase(),
                                style: theme.textTheme.bodyLarge,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (currency) {
                      if (currency != null) {
                        widget.onCurrencySelected(currency);
                      }
                    },
                  ),
                ),
              ),

              const SizedBox(height: AppConstants.paddingXLarge),

              // Next button
              SizedBox(
                width: double.infinity,
                height: AppConstants.buttonHeightPrimary,
                child: FilledButton(
                  onPressed: () {
                    if (_formKey.currentState?.validate() ?? false) {
                      widget.onNext();
                    }
                  },
                  style: FilledButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusButton,
                      ),
                    ),
                  ),
                  child: Text(
                    l10n?.onboardingGetStarted ?? 'Get Started',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onPrimary,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: AppConstants.paddingMedium),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Text(
      title,
      style: theme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.bold,
        color: theme.colorScheme.primary,
      ),
    );
  }
}

/// Helper to format cents as decimal string without currency symbol.
String formatMoneyFromCentsNoSymbol(int cents) {
  final dollars = cents / 100;
  return dollars.toStringAsFixed(2);
}
