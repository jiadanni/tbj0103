import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Demo data toggle step.
class DemoDataStep extends StatelessWidget {
  const DemoDataStep({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.demoDataEnabled,
    required this.onToggle,
  });

  final VoidCallback onNext;
  final VoidCallback onBack;
  final bool demoDataEnabled;
  final ValueChanged<bool> onToggle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Back button
            IconButton(
              onPressed: onBack,
              icon: PhosphorIcon(
                PhosphorIcons.arrowLeft(),
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Title
            Text(
              l10n?.onboardingDemoDataTitle ?? 'Demo Data',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingSmall),

            Text(
              l10n?.onboardingDemoDataSubtitle ??
                  'Would you like to start with some sample data to explore features?',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),

            const Spacer(),

            // Toggle card
            GestureDetector(
              onTap: () => onToggle(!demoDataEnabled),
              child: AnimatedContainer(
                duration: AppConstants.animationNormal,
                padding: const EdgeInsets.all(AppConstants.paddingLarge),
                decoration: BoxDecoration(
                  color: demoDataEnabled
                      ? colorScheme.primaryContainer
                      : colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
                  border: Border.all(
                    color: demoDataEnabled
                        ? colorScheme.primary
                        : colorScheme.outline.withValues(alpha: 0.3),
                    width: demoDataEnabled ? 2 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: demoDataEnabled
                                ? colorScheme.primary.withValues(alpha: 0.2)
                                : colorScheme.onSurface.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusMedium,
                            ),
                          ),
                          child: PhosphorIcon(
                            PhosphorIcons.database(PhosphorIconsStyle.duotone),
                            size: 32,
                            color: demoDataEnabled
                                ? colorScheme.primary
                                : colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                        ),
                        const SizedBox(width: AppConstants.paddingMedium),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n?.onboardingDemoDataToggle ??
                                    'Enable Demo Data',
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: colorScheme.onSurface,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n?.onboardingDemoDataDescription ??
                                    'Fills your timeline with sample transactions and plans.',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: colorScheme.onSurface.withValues(
                                    alpha: 0.7,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch(value: demoDataEnabled, onChanged: onToggle),
                      ],
                    ),

                    if (demoDataEnabled) ...[
                      const SizedBox(height: AppConstants.paddingMedium),
                      const Divider(),
                      const SizedBox(height: AppConstants.paddingMedium),
                      _DemoDataFeature(
                        icon: PhosphorIcons.calendarCheck(),
                        text:
                            l10n?.onboardingDemoDataFeature1 ??
                            'Sample Timeline Items',
                      ),
                      const SizedBox(height: 8),
                      _DemoDataFeature(
                        icon: PhosphorIcons.pulse(),
                        text:
                            l10n?.onboardingDemoDataFeature2 ??
                            'Recorded Pulses',
                      ),
                      const SizedBox(height: 8),
                      _DemoDataFeature(
                        icon: PhosphorIcons.chartLine(),
                        text:
                            l10n?.onboardingDemoDataFeature3 ??
                            'Insight Analytics',
                      ),
                    ],
                  ],
                ),
              ),
            ),

            const Spacer(),

            // Info card
            if (!demoDataEnabled)
              Container(
                padding: const EdgeInsets.all(AppConstants.paddingMedium),
                decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(
                    AppConstants.radiusMedium,
                  ),
                ),
                child: Row(
                  children: [
                    PhosphorIcon(
                      PhosphorIcons.info(),
                      color: colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        l10n?.onboardingDemoDataSkipHint ??
                            'You can clear demo data anytime in settings.',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurface.withValues(alpha: 0.7),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: AppConstants.paddingLarge),

            // Next button
            SizedBox(
              width: double.infinity,
              height: AppConstants.buttonHeightPrimary,
              child: FilledButton(
                onPressed: onNext,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusButton,
                    ),
                  ),
                ),
                child: Text(
                  l10n?.onboardingContinue ?? 'Continue',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),
          ],
        ),
      ),
    );
  }
}

class _DemoDataFeature extends StatelessWidget {
  const _DemoDataFeature({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        PhosphorIcon(icon, size: 18, color: colorScheme.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurface.withValues(alpha: 0.8),
            ),
          ),
        ),
      ],
    );
  }
}
