import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/widgets/sparkline_chart.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

class MonthProjection {
  final DateTime month;
  final int startBalanceCents;
  final int endBalanceCents;
  final int netChange;

  MonthProjection({
    required this.month,
    required this.startBalanceCents,
    required this.endBalanceCents,
    required this.netChange,
  });
}

/// Calculates projected balances for multiple future months.
///
/// If [zeroStartMonth] is provided, all months BEFORE it will show zero balance,
/// and projection starts fresh from that month.
///
/// If [deductEnvelopes] is false, envelope items are excluded from the calculation.
///
/// [envelopeOverrides] - per-envelope overrides for current month.
/// Key is envelope ID, value is true (use actuals) or false (use budget).
/// If an envelope is not in the map, it uses its timeline setting.
///
/// [futureMonthsUseActuals] - if provided, overrides future months' envelope
/// calculation to use actuals (true) or full budget (false).
List<MonthProjection> calculateMultiMonthProjections({
  required int currentBalanceCents,
  required int monthsAhead,
  required int Function(
    DateTime month, {
    bool includeEnvelopes,
    Map<String, bool>? envelopeOverrides,
    Map<String, bool>? futureEnvelopeOverrides,
  })
  plannedTotalForMonth,
  required DateTime currentPeriodMonth,
  required int currentPeriodNetChange,
  DateTime? zeroStartMonth,
  bool deductEnvelopes = true,
  Map<String, bool>? envelopeOverrides,
  Map<String, bool>? futureEnvelopeOverrides,
}) {
  final projections = <MonthProjection>[];
  var cursor = monthOnly(currentPeriodMonth);
  var balance = currentBalanceCents;

  // Normalize zeroStartMonth for comparison
  final normalizedZeroStart = zeroStartMonth != null
      ? monthOnly(zeroStartMonth)
      : null;

  for (int i = 0; i < monthsAhead; i++) {
    cursor = monthOnly(month_math.addMonths(currentPeriodMonth, i));

    // If we haven't reached the zero start month yet, show zero balance
    if (normalizedZeroStart != null && cursor.isBefore(normalizedZeroStart)) {
      projections.add(
        MonthProjection(
          month: cursor,
          startBalanceCents: 0,
          endBalanceCents: 0,
          netChange: 0,
        ),
      );
      continue;
    }

    // If we're at the zero start month, reset balance to 0
    if (normalizedZeroStart != null &&
        normalizedZeroStart.year == cursor.year &&
        normalizedZeroStart.month == cursor.month) {
      balance = 0;
    }

    // For current period, use the pre-calculated net change from footer
    // (unless we have envelope overrides for current month)
    // For future periods, calculate using plannedTotalForMonth
    final isCurrentPeriod =
        cursor.year == currentPeriodMonth.year &&
        cursor.month == currentPeriodMonth.month;
    final int netChange;
    if (isCurrentPeriod &&
        (envelopeOverrides == null || envelopeOverrides.isEmpty)) {
      // No overrides - use pre-calculated value from timeline
      netChange = currentPeriodNetChange;
    } else {
      // Use overrides for current month, or futureMonthsUseActuals for future
      netChange = plannedTotalForMonth(
        cursor,
        includeEnvelopes: deductEnvelopes,
        envelopeOverrides: isCurrentPeriod ? envelopeOverrides : null,
        futureEnvelopeOverrides: isCurrentPeriod
            ? null
            : futureEnvelopeOverrides,
      );
    }
    final endBalance = balance + netChange;

    projections.add(
      MonthProjection(
        month: cursor,
        startBalanceCents: balance,
        endBalanceCents: endBalance,
        netChange: netChange,
      ),
    );

    balance = endBalance;
  }

  return projections;
}

class BalanceProjectionSheet extends StatefulWidget {
  const BalanceProjectionSheet({
    super.key,
    required this.currentMonth,
    required this.currentBalanceCents,
    required this.currentPeriodNetChange,
    required this.items,
    required this.settings,
    required this.plannedTotalForMonth,
    required this.currentPeriodMonth,
    this.initialZeroStartMonth,
  });

  final DateTime currentMonth;
  final int currentBalanceCents;
  final int currentPeriodNetChange;
  final List<TimelineItem> items;
  final AppSettingsStore settings;
  final int Function(
    DateTime month, {
    bool includeEnvelopes,
    Map<String, bool>? envelopeOverrides,
    Map<String, bool>? futureEnvelopeOverrides,
  })
  plannedTotalForMonth;
  final DateTime currentPeriodMonth;

  /// If set, this month will be pre-selected as the "start from zero" point.
  /// Used when opening projection from a future month.
  final DateTime? initialZeroStartMonth;

  @override
  State<BalanceProjectionSheet> createState() => _BalanceProjectionSheetState();
}

class _BalanceProjectionSheetState extends State<BalanceProjectionSheet> {
  DateTime? selectedZeroStartMonth;
  bool deductEnvelopes = true;
  bool showNetChange = false;
  int _monthsToProject = AppConstants.defaultProjectionMonths;

  // Per-envelope overrides for current month
  // Key = envelope ID, value = true (use actuals) or false (use budget)
  // Empty map = inherit from timeline settings
  Map<String, bool> envelopeOverrides = {};

  // Future months: per-envelope overrides
  // Key = envelope ID, value = true (use actuals) or false (use budget)
  // If not present, falls back to timeline defaults (usually budget for future)
  Map<String, bool> futureEnvelopeOverrides = {};

  @override
  void initState() {
    super.initState();
    deductEnvelopes = widget.settings.balanceProjectionDeductEnvelopes;
    showNetChange = widget.settings.balanceProjectionShowDelta;
    selectedZeroStartMonth = widget.initialZeroStartMonth;
    // Default: use full budget for future months (better for planning)
    futureEnvelopeOverrides = {};
  }

  /// Get envelopes from items list
  List<TimelineItem> get _envelopes => widget.items
      .where(
        (item) => item.type == PulseType.spendingEnvelope && !item.archived,
      )
      .toList();

  @override
  Widget build(BuildContext context) {
    // Generate projections
    final projections = calculateMultiMonthProjections(
      currentBalanceCents: widget.currentBalanceCents,
      monthsAhead: _monthsToProject,
      plannedTotalForMonth: widget.plannedTotalForMonth,
      currentPeriodMonth: widget.currentPeriodMonth,
      currentPeriodNetChange: widget.currentPeriodNetChange,
      zeroStartMonth: selectedZeroStartMonth,
      deductEnvelopes: deductEnvelopes,
      envelopeOverrides: envelopeOverrides.isNotEmpty
          ? envelopeOverrides
          : null,
      futureEnvelopeOverrides: deductEnvelopes ? futureEnvelopeOverrides : null,
    );

    // Prepare chart data
    // If a zero start month is selected, filter data to start from there?
    // User expectation: "tapping a month to start from zero".
    // If we just show the whole 5 years but zeroed out before, the graph looks flat then jumps.
    // Maybe we should zoom the graph to the relevant period if zero start is active?
    // The user said "the first point should be zero".
    // This implies we should only plot the relevant range.

    List<MonthProjection> chartProjections = projections;
    bool prependZeroPoint = false;

    if (selectedZeroStartMonth != null) {
      // Find the index of the start month
      final startIndex = projections.indexWhere(
        (p) =>
            p.month.year == selectedZeroStartMonth!.year &&
            p.month.month == selectedZeroStartMonth!.month,
      );

      if (startIndex >= 0) {
        chartProjections = projections.sublist(startIndex);
        prependZeroPoint = true;
      }
    }

    // Limit chart to prevent Y-axis flattening/scaling issues
    if (chartProjections.length > AppConstants.chartMaxMonths) {
      chartProjections = chartProjections
          .take(AppConstants.chartMaxMonths)
          .toList();
    }

    final chartValues = <num>[];
    final chartLabels = <String>[];

    if (prependZeroPoint) {
      chartValues.add(0);
      chartLabels.add('Start');
    }

    for (final p in chartProjections) {
      chartValues.add(p.endBalanceCents);
      // Label logic: Show month name? e.g. "Jan", "Feb"
      // or "Jan 26" if crossing years?
      chartLabels.add(_formatChartLabel(p.month));
    }

    final showCents = widget.settings.showCents;
    final creditColor = widget.settings.creditColor;
    final debitColor = widget.settings.debitColor;

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              // Drag handle
              Padding(
                padding: const EdgeInsets.only(top: 12, bottom: 8),
                child: Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.outlineVariant,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ),

              // Header
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 4,
                ),
                child: Text(
                  'Balance Projection',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              const Divider(height: 1),

              Expanded(
                child: RadioGroup<DateTime?>(
                  groupValue: selectedZeroStartMonth,
                  onChanged: (val) =>
                      setState(() => selectedZeroStartMonth = val),
                  child: ListView(
                    controller: scrollController,
                    padding: EdgeInsets.zero,
                    children: [
                      const SizedBox(height: 16),

                      // Start balance card
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: Theme.of(
                                context,
                              ).colorScheme.outlineVariant,
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Current Balance',
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                              ),
                              Text(
                                formatMoneyFromCents(
                                  widget.currentBalanceCents,
                                  widget.settings.currencySettings.currency,
                                  showCents: showCents,
                                ),
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontFeatures: const [
                                        FontFeature.tabularFigures(),
                                      ],
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Sparkline chart
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: SizedBox(
                          height: 150, // Increased height for labels
                          child: SparklineChart(
                            values: chartValues,
                            labels: chartLabels,
                            creditColor: creditColor,
                            debitColor: debitColor,
                          ),
                        ),
                      ),

                      // Controls below graph - organized by section
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Future months section
                            _buildControlRow(
                              context,
                              label: 'Future months',
                              children: [
                                _buildControlChip(
                                  context,
                                  label:
                                      'Deduct ${Terminology.of(context).budgetLabel}s',
                                  isActive: deductEnvelopes,
                                  onTap: () => setState(
                                    () => deductEnvelopes = !deductEnvelopes,
                                  ),
                                ),
                                if (deductEnvelopes) ...[
                                  const SizedBox(width: 8),
                                  ..._envelopes.map((envelope) {
                                    // Determine current state for FUTURE
                                    final hasOverride = futureEnvelopeOverrides
                                        .containsKey(envelope.id.value);
                                    final isUsingActuals = hasOverride
                                        ? futureEnvelopeOverrides[envelope
                                              .id
                                              .value]!
                                        : SpendingEnvelopeService.isUsingActuals(
                                            envelope,
                                            false,
                                            widget.settings,
                                          );

                                    return Padding(
                                      padding: const EdgeInsets.only(right: 8),
                                      child: _buildEnvelopeChip(
                                        context,
                                        envelope: envelope,
                                        isUsingActuals: isUsingActuals,
                                        hasOverride: hasOverride,
                                        onTap: () {
                                          setState(() {
                                            if (hasOverride) {
                                              // Toggle: if new value matches default, remove override
                                              final newValue =
                                                  !futureEnvelopeOverrides[envelope
                                                      .id
                                                      .value]!;
                                              final defaultValue =
                                                  SpendingEnvelopeService.isUsingActuals(
                                                    envelope,
                                                    false,
                                                    widget.settings,
                                                  );
                                              if (newValue == defaultValue) {
                                                futureEnvelopeOverrides.remove(
                                                  envelope.id.value,
                                                );
                                              } else {
                                                futureEnvelopeOverrides[envelope
                                                        .id
                                                        .value] =
                                                    newValue;
                                              }
                                            } else {
                                              // Add override
                                              futureEnvelopeOverrides[envelope
                                                      .id
                                                      .value] =
                                                  !isUsingActuals;
                                            }
                                          });
                                        },
                                      ),
                                    );
                                  }),
                                ],
                              ],
                            ),

                            // Current month section - show envelope toggles
                            if (_envelopes.isNotEmpty) ...[
                              const SizedBox(height: 8),
                              _buildControlRow(
                                context,
                                label: 'Current month',
                                children: [
                                  ..._envelopes.map((envelope) {
                                    // Determine current state: override or timeline default
                                    final hasOverride = envelopeOverrides
                                        .containsKey(envelope.id.value);
                                    final isUsingActuals = hasOverride
                                        ? envelopeOverrides[envelope.id.value]!
                                        : SpendingEnvelopeService.isUsingActuals(
                                            envelope,
                                            true,
                                            widget.settings,
                                          );

                                    return Padding(
                                      padding: const EdgeInsets.only(right: 8),
                                      child: _buildEnvelopeChip(
                                        context,
                                        envelope: envelope,
                                        isUsingActuals: isUsingActuals,
                                        hasOverride: hasOverride,
                                        onTap: () {
                                          setState(() {
                                            if (hasOverride) {
                                              // Toggle the override value, or remove if back to default
                                              final newValue =
                                                  !envelopeOverrides[envelope
                                                      .id
                                                      .value]!;
                                              final defaultValue =
                                                  SpendingEnvelopeService.isUsingActuals(
                                                    envelope,
                                                    true,
                                                    widget.settings,
                                                  );
                                              if (newValue == defaultValue) {
                                                envelopeOverrides.remove(
                                                  envelope.id.value,
                                                );
                                              } else {
                                                envelopeOverrides[envelope
                                                        .id
                                                        .value] =
                                                    newValue;
                                              }
                                            } else {
                                              // Add override with opposite of default
                                              envelopeOverrides[envelope
                                                      .id
                                                      .value] =
                                                  !isUsingActuals;
                                            }
                                          });
                                        },
                                      ),
                                    );
                                  }),
                                ],
                              ),
                            ],

                            // Show Net toggle on its own line
                            const SizedBox(height: 8),
                            Center(
                              child: _buildControlChip(
                                context,
                                label: 'Show Net',
                                isActive: showNetChange,
                                onTap: () => setState(
                                  () => showNetChange = !showNetChange,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Description
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Text(
                          'Select a future month to simulate a fresh start (0 balance).',
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurfaceVariant,
                              ),
                        ),
                      ),

                      const Divider(height: 16),

                      // List Header
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 8,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Month',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            Text(
                              'Balance',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ],
                        ),
                      ),

                      // Month projections list
                      for (int i = 0; i < projections.length; i++) ...[
                        // Year Divider
                        if (i > 0 &&
                            projections[i].month.year !=
                                projections[i - 1].month.year)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Divider(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.outlineVariant,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                  child: Text(
                                    projections[i].month.year.toString(),
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelSmall
                                        ?.copyWith(
                                          color: Theme.of(
                                            context,
                                          ).colorScheme.onSurfaceVariant,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                                Expanded(
                                  child: Divider(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.outlineVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),

                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          child: Builder(
                            builder: (context) {
                              // Determine if this month is "before" the zero start (should be greyed out)
                              final isBeforeZeroStart =
                                  selectedZeroStartMonth != null &&
                                  projections[i].month.isBefore(
                                    selectedZeroStartMonth!,
                                  );
                              final isSelected =
                                  selectedZeroStartMonth != null &&
                                  selectedZeroStartMonth!.year ==
                                      projections[i].month.year &&
                                  selectedZeroStartMonth!.month ==
                                      projections[i].month.month;

                              return Opacity(
                                opacity: isBeforeZeroStart ? 0.4 : 1.0,
                                child: ListTile(
                                  leading: Radio<DateTime?>(
                                    // First row uses null to represent "no zero start"
                                    value: i == 0 ? null : projections[i].month,
                                  ),
                                  title: Text(
                                    _formatPeriodLabel(projections[i].month),
                                    style: Theme.of(
                                      context,
                                    ).textTheme.titleMedium,
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        formatMoneyFromCents(
                                          projections[i].endBalanceCents,
                                          widget
                                              .settings
                                              .currencySettings
                                              .currency,
                                          showCents: showCents,
                                        ),
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleMedium
                                            ?.copyWith(
                                              fontFeatures: const [
                                                FontFeature.tabularFigures(),
                                              ],
                                              fontWeight: FontWeight.bold,
                                              color:
                                                  projections[i]
                                                          .endBalanceCents >=
                                                      0
                                                  ? creditColor
                                                  : debitColor,
                                            ),
                                      ),
                                      if (showNetChange)
                                        Text(
                                          '(${projections[i].netChange >= 0 ? '+' : ''}${formatMoneyFromCents(projections[i].netChange, widget.settings.currencySettings.currency, showCents: showCents)})',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                fontFeatures: const [
                                                  FontFeature.tabularFigures(),
                                                ],
                                                fontWeight: FontWeight.w500,
                                                color:
                                                    projections[i].netChange >=
                                                        0
                                                    ? creditColor.withValues(
                                                        alpha: 0.9,
                                                      )
                                                    : debitColor.withValues(
                                                        alpha: 0.9,
                                                      ),
                                              ),
                                        ),
                                    ],
                                  ),
                                  onTap: () {
                                    setState(() {
                                      // For first row, set to null (reset)
                                      // For other rows, toggle selection
                                      if (i == 0) {
                                        selectedZeroStartMonth = null;
                                      } else if (isSelected) {
                                        selectedZeroStartMonth = null;
                                      } else {
                                        selectedZeroStartMonth =
                                            projections[i].month;
                                      }
                                    });
                                  },
                                ),
                              );
                            },
                          ),
                        ),
                      ],

                      // Load More Button
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Center(
                          child: OutlinedButton(
                            onPressed: () {
                              setState(() {
                                _monthsToProject += AppConstants.loadMoreMonths;
                              });
                            },
                            child: const Text('Load More (1 Year)'),
                          ),
                        ),
                      ),

                      // Bottom padding for scrolling
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _formatPeriodLabel(DateTime date) {
    final periodInfo = PaycheckService.getPeriodInfo(
      date,
      widget.settings.viewPeriodMode,
      widget.settings.paycheckDay,
      businessAdjust: widget.settings.paycheckBusinessAdjust,
      adjustDirection: widget.settings.paycheckBusinessAdjustDirection,
      includeMonth: widget.settings.paycheckShowMonthInTimeline,
    );
    return periodInfo.label;
  }

  String _formatChartLabel(DateTime date) {
    // Format: "Jan 25"
    // Use standard DateFormat if available or simple manual format
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final monthName = months[date.month - 1];
    final shortYear = date.year.toString().substring(2);
    return '$monthName $shortYear';
  }

  Widget _buildControlChip(
    BuildContext context, {
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isActive
              ? colorScheme.primaryContainer
              : colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? colorScheme.primary : colorScheme.outlineVariant,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isActive) ...[
              Icon(
                Icons.check,
                size: 14,
                color: colorScheme.onPrimaryContainer,
              ),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(
                color: isActive
                    ? colorScheme.onPrimaryContainer
                    : colorScheme.onSurfaceVariant,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlRow(
    BuildContext context, {
    required String label,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: 100,
          child: Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: children),
          ),
        ),
      ],
    );
  }

  Widget _buildEnvelopeChip(
    BuildContext context, {
    required TimelineItem envelope,
    required bool isUsingActuals,
    required bool hasOverride,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    // Show envelope name with indicator of mode
    final modeLabel = isUsingActuals ? 'Actual' : 'Budget';

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: hasOverride
              ? colorScheme.tertiaryContainer
              : colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: hasOverride
                ? colorScheme.tertiary
                : colorScheme.outlineVariant,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              envelope.label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: hasOverride
                    ? colorScheme.onTertiaryContainer
                    : colorScheme.onSurfaceVariant,
                fontWeight: hasOverride ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            const SizedBox(width: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              decoration: BoxDecoration(
                color: isUsingActuals
                    ? colorScheme.primaryContainer.withValues(alpha: 0.7)
                    : colorScheme.secondaryContainer.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                modeLabel,
                style: theme.textTheme.labelSmall?.copyWith(
                  fontSize: 9,
                  color: isUsingActuals
                      ? colorScheme.onPrimaryContainer
                      : colorScheme.onSecondaryContainer,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
