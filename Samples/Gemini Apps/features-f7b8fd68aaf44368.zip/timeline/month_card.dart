import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/pulse_display.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/gradient_card.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/display_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/money_pots_section.dart';
import 'package:expense_stalker_mobile/src/features/timeline/envelope_quick_spend_sheet.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/envelope_logic.dart';
import 'package:expense_stalker_mobile/src/features/timeline/balance_projection_sheet.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/month_year_picker_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/convert_standalone_pulses.dart';
import 'package:expense_stalker_mobile/src/widgets/update_pulse_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/timeline_item_picker.dart';

/// Safe Tooltip widget that avoids ticker lifecycle issues
class SafeTooltip extends StatelessWidget {
  const SafeTooltip({super.key, required this.message, required this.child});

  final String message;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    // Don't wrap in Tooltip if message is empty
    if (message.isEmpty) {
      return child;
    }
    return Tooltip(message: message, child: child);
  }
}

class MonthCard extends StatelessWidget {
  const MonthCard({
    super.key,
    required this.month,
    required this.items,
    required this.pulses,
    required this.recentlyClearedItemIds,
    required this.swipeLeft,
    required this.swipeRight,
    required this.settings,
    required this.showCleared,
    required this.sortOrder,
    required this.dateSortMode,
    required this.displayMode,
    this.precomputedStartBalanceCents,
    this.onJumpToMonth,
  });

  final DateTime month;
  final List<TimelineItem> items;
  final List<PulseEntry> pulses;
  final Set<String> recentlyClearedItemIds;
  final TimelineSwipeAction swipeLeft;
  final TimelineSwipeAction swipeRight;
  final AppSettingsStore settings;
  final bool showCleared;
  final TimelineSortOrder sortOrder;
  final TimelineDateSortMode dateSortMode;
  final PulseDisplayMode displayMode;

  /// If provided, this balance is used instead of computing it internally.
  /// This allows the parent to pre-compute balances with correct cleared state.
  final int? precomputedStartBalanceCents;
  final ValueChanged<DateTime>? onJumpToMonth;

  @override
  Widget build(BuildContext context) {
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
      includeMonth: settings.paycheckShowMonthInTimeline,
    );
    final lookupMap = _buildPulseLookupMap(settings);

    // Merge registered items with any standalone/orphaned pulses in this month
    // so they appear in the list as virtual items.
    final allItems = mergeItemsWithStandalonePulses(items, pulses, month);

    final scheduledItems = allItems
        .where(
          (item) => PaycheckService.shouldItemAppearInPeriod(
            item,
            periodInfo,
            month,
            ignoreSkips: true,
          ),
        )
        .toList(growable: false);

    // Calculate period info early for filtering logic
    final monthOnlyValue = monthOnly(month);
    final nowMonthOnly = monthOnly(DateTime.now());

    // Determine if this card represents the current period
    // In paycheck mode, compare against the current paycheck period's reference month
    // In calendar mode, compare against the current calendar month
    final DateTime currentPeriodMonth;
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        DateTime.now(),
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
    } else {
      currentPeriodMonth = nowMonthOnly;
    }

    // In paycheck mode, only the paycheck period reference month should be marked as current.
    // In calendar mode, use the calendar month comparison.
    // We should NOT fall back to the calendar month in paycheck mode, as this would cause
    // two periods to be marked as "current" on payday (e.g., both Jan and Feb when Jan 25 is pay day).
    final isCurrentPeriod =
        monthOnlyValue.year == currentPeriodMonth.year &&
        monthOnlyValue.month == currentPeriodMonth.month;

    final isPast =
        monthOnlyValue.isBefore(currentPeriodMonth) && !isCurrentPeriod;

    // Filter items based on cleared status and period context
    final unclearedItems = <TimelineItem>[];
    final filteredItems = <TimelineItem>[];
    for (final item in scheduledItems) {
      final isCleared = _clearedDateFor(item.id, lookupMap) != null;
      if (!isCleared) {
        unclearedItems.add(item);
      }

      final isSkipped = item.isSkippedInMonth(month);
      // Hide skipped items if the setting is disabled
      if (isSkipped && !settings.timelineShowSkippedItems) continue;

      // In past periods, show all items (they're all cleared by definition)
      // In current period, apply the showCleared toggle to show/hide cleared items
      if (isPast ||
          showCleared ||
          !isCleared ||
          recentlyClearedItemIds.contains(item.id) ||
          item.type == PulseType.spendingEnvelope ||
          isSkipped) {
        filteredItems.add(item);
      }
    }

    final visibleItems = orderedTimelineItems(
      filteredItems,
      sortOrder,
      dateSortMode: dateSortMode,
      viewMode: settings.viewPeriodMode,
      periodInfo: periodInfo,
      actualDateProvider: (item) => _clearedDateFor(item.id, lookupMap),
    );
    final isFutureMonth =
        monthOnlyValue.isAfter(currentPeriodMonth) && !isCurrentPeriod;

    final store = ExpenseStoreScope.read(context);
    final isTargetMonth =
        monthOnlyValue.year == store.selectedMonth.year &&
        monthOnlyValue.month == store.selectedMonth.month;
    final unclearedPayments = unclearedItems
        .where((i) => i.type != PulseType.spendingEnvelope)
        .toList();
    final allPaymentsCleared = unclearedPayments.isEmpty;

    int plannedTotalCallback(
      DateTime m, {
      bool includeEnvelopes = true,
      Map<String, bool>? envelopeOverrides,
      Map<String, bool>? futureEnvelopeOverrides,
    }) => _plannedTotalForMonth(
      m,
      currentPeriodMonth,
      includeEnvelopes: includeEnvelopes,
      envelopeOverrides: envelopeOverrides,
      futureEnvelopeOverrides: futureEnvelopeOverrides,
    );

    int allCredits = 0;
    int allDebitsValue = 0;
    int unclearedCredits = 0;
    int unclearedDebitsValue = 0;

    for (final item in scheduledItems) {
      // Virtual items represent standalone pulses (transactions without a linked timeline item).
      // Only skip them if they're CLEARED (already reflected in bank balance).
      // If they have a future date and aren't cleared yet, they should be included as pending.
      final isVirtual = item.id.value.startsWith('virtual_');
      if (isVirtual && !isPast) {
        // Check if this virtual item's pulse is already cleared (in the bank balance)
        final pulseId = item.id.value.substring('virtual_'.length);
        final pulse = pulses.where((p) => p.id.value == pulseId).firstOrNull;
        // If pulse exists and its date is in the past or today, it's cleared - skip it
        // If pulse has a future date, it's pending - include it
        if (pulse != null) {
          final now = DateTime.now();
          final pulseDate = pulse.date;
          final isCleared = !pulseDate.isAfter(
            DateTime(now.year, now.month, now.day),
          );
          if (isCleared) continue;
        } else {
          continue; // No pulse found, skip
        }
      }

      // 1. Calculate "Gross" change (as if it's a future month)
      final grossChange = calculateItemNetChangeForMonth(
        item: item,
        month: month,
        pulses: pulses,
        isCurrentPeriod:
            false, // Forces full amount (or actuals if toggle is on)
        periodInfo: periodInfo,
        settings: settings,
        ignoreCleared: true,
      );
      if (grossChange > 0) {
        allCredits += grossChange;
      } else {
        allDebitsValue += grossChange;
      }

      // 2. Calculate "Net" change (remaining items relative to bank balance)
      final netChange = calculateItemNetChangeForMonth(
        item: item,
        month: month,
        pulses: pulses,
        isCurrentPeriod: isCurrentPeriod,
        periodInfo: periodInfo,
        settings: settings,
      );
      if (netChange > 0) {
        unclearedCredits += netChange;
      } else {
        unclearedDebitsValue += netChange;
      }
    }

    // For the current period, show the raw manual balance (source of truth).
    // For future months, use precomputed balance if available, otherwise calculate.
    // Note: Zero baseline mode only applies to future months, not the current period.
    final int? startBalanceCents;
    if (isCurrentPeriod) {
      startBalanceCents = settings.currentBalanceCents;
    } else if (precomputedStartBalanceCents != null) {
      // Use precomputed balance from parent (accounts for correct cleared state)
      startBalanceCents = settings.timelineUseZeroBaseline
          ? 0
          : precomputedStartBalanceCents;
    } else {
      // Fallback: compute internally (may not have correct cleared state for current period)
      startBalanceCents = startBalanceCentsForMonth(
        month: month,
        currentBalanceCents: settings.currentBalanceCents,
        useZeroBaseline: settings.timelineUseZeroBaseline,
        plannedTotalForMonth: (m) => plannedTotalCallback(m),
        currentPeriodMonth: currentPeriodMonth,
      );
    }
    final showClearedRow =
        settings.monthTotalsDisplayMode ==
            MonthTotalsDisplayMode.showClearedRow &&
        isCurrentPeriod;
    // Use custom colors from settings
    final creditColor = settings.creditColor;
    final debitColor = settings.debitColor;

    // Calculate Projected End-of-Month Balance
    // Note: startBalanceCents is:
    // - currentBalanceCents if isCurrentPeriod is true
    // - calculated prediction if isCurrentPeriod is false
    final int baseBalance = startBalanceCents ?? 0;

    // For the current period, we only consider remaining (uncleared) items
    // added to the current bank balance.
    // For future periods, we consider ALL planned items added to the
    // predicted starting balance.

    // Primary Row Values (The "Main" View)
    // For Current Period: Defaults to Uncleared (Remaining)
    // For Future: Defaults to All (Planned)
    final int primaryCredits, primaryDebits;
    if (isCurrentPeriod) {
      primaryCredits = unclearedCredits;
      primaryDebits = unclearedDebitsValue;
    } else {
      primaryCredits = allCredits;
      primaryDebits = allDebitsValue;
    }
    final primaryTotal = baseBalance + primaryCredits + primaryDebits;

    // Secondary Row Values (When "Show Cleared Row" is enabled)
    // If enabled, we want to show the breakdown.
    // Usually: Primary = Including Cleared (Gross), Secondary = Excluding Cleared (Net/Remaining).
    // BUT for current period, the "Standard" view is already Net/Remaining.
    // To match User Request: "Total all uncleared transactions with the current balance. In all cases/ always."
    // We ensure the row that displays the TOTAL (which is Secondary when 2 lines are shown) shows the Projected Balance.

    final int? secCredits, secDebits, secTotal;
    if (showClearedRow) {
      // If showing cleared row, let's make:
      // Primary Row (Eye) = All/Scheduled (Gross Reference) - Total Hidden
      // Secondary Row (Crossed Eye) = Uncleared (Remaining) - Total Shown = Projected Balance

      // Note: This overrides the isCurrentPeriod logic for the Primary Row specifically when split view is on,
      // to allow seeing the "original plan" vs "reality".

      // Calculate Secondary (The one with the Total)
      // For future months, use ALL values (same as primary) since nothing can be cleared yet.
      // For current period, use uncleared values to show the remaining items.
      if (isFutureMonth) {
        secCredits = allCredits;
        secDebits = allDebitsValue;
      } else {
        secCredits = unclearedCredits;
        secDebits = unclearedDebitsValue;
      }
      secTotal =
          baseBalance +
          secCredits +
          secDebits; // Current Balance + Uncleared Loop
    } else {
      secCredits = null;
      secDebits = null;
      secTotal = null;
    }

    // Determine what to pass as "Primary" to the footer builder
    // If split view is ON, show 'All' for credits/debits display.
    // End Balance is ALWAYS: Bank Balance + Uncleared (for current period).
    final int displayCredits = showClearedRow ? allCredits : primaryCredits;
    final int displayDebits = showClearedRow ? allDebitsValue : primaryDebits;
    // End balance = Bank Balance + Uncleared transactions only.
    // Bank balance already reflects cleared transactions, so we never add them again.
    final int displayTotal =
        baseBalance + unclearedCredits + unclearedDebitsValue;

    // Apply rounding
    final roundingIncrement = settings.roundingIncrement;
    final showCents = settings.showCents;

    final roundedCredits = roundingIncrement > 0
        ? roundUpToIncrement(displayCredits, roundingIncrement)
        : displayCredits;
    final roundedDebits = roundingIncrement > 0
        ? roundUpToIncrement(displayDebits, roundingIncrement)
        : displayDebits;
    // Note: displayTotal includes baseBalance, so we round the final sum
    final roundedTotal = roundingIncrement > 0
        ? roundUpToIncrement(displayTotal, roundingIncrement)
        : displayTotal;

    // Exact row logic (only relevant if not showing cleared row)
    final roundedDiffers = roundedTotal != displayTotal;
    final showExactRow = roundedDiffers && !showClearedRow;

    // Separate envelopes from regular items for distinct UI sections
    // Filter out archived envelopes so they don't appear in the BUDGETS section
    final envelopeItems = visibleItems
        .where(
          (item) => item.type == PulseType.spendingEnvelope && !item.archived,
        )
        .toList();
    final regularItems = visibleItems
        .where((item) => item.type != PulseType.spendingEnvelope)
        .toList();

    return SizedBox.expand(
      child: GradientCard(
        isPast: isPast,
        isCurrent: isCurrentPeriod,
        fullBleed: true,
        child: Column(
          children: [
            // Pill-style header
            _buildHeader(
              context,
              periodInfo: periodInfo,
              startBalanceCents: startBalanceCents,
              isCurrentPeriod: isCurrentPeriod,
              isFutureMonth: isFutureMonth,
              showCents: showCents,
            ),
            // Spending envelopes section (at top, separate from regular activities)
            if (envelopeItems.isNotEmpty)
              _buildEnvelopesSection(
                context,
                envelopeItems,
                isPast,
                isCurrentPeriod,
                isFutureMonth,
                debitColor,
                showCents: showCents,
              ),
            // Item list (grouped or flat based on settings) - regular items only
            Expanded(
              child: settings.timelineSplitClearedAndPending
                  ? _buildSplitList(
                      context,
                      regularItems,
                      isPast,
                      isCurrentPeriod,
                      creditColor,
                      debitColor,
                      periodInfo: periodInfo,
                      showCents: showCents,
                      lookupMap: lookupMap,
                    )
                  : (settings.timelineGroupByTheme
                        ? _buildThemeGroupedList(
                            context,
                            regularItems,
                            isPast,
                            isCurrentPeriod,
                            creditColor,
                            debitColor,
                            periodInfo: periodInfo,
                            showCents: showCents,
                            lookupMap: lookupMap,
                          )
                        : (settings.timelineGroupByDate
                              ? _buildGroupedList(
                                  context,
                                  regularItems,
                                  isPast,
                                  isCurrentPeriod,
                                  creditColor,
                                  debitColor,
                                  periodInfo: periodInfo,
                                  showCents: showCents,
                                  lookupMap: lookupMap,
                                )
                              : _buildFlatList(
                                  context,
                                  regularItems,
                                  isPast,
                                  isCurrentPeriod,
                                  creditColor,
                                  debitColor,
                                  showCents: showCents,
                                  lookupMap: lookupMap,
                                ))),
            ),
            if (isCurrentPeriod)
              MoneyPotsSection(
                settings: settings,
                month: month,
                items: items,
                pulses: pulses,
              ),
            if (isTargetMonth && (isPast || allPaymentsCleared))
              _buildAdvancePeriodButton(context),
            // Footer with credits/debits/total (Total = Projected Balance)
            _buildFooter(
              context,
              roundedCredits,
              roundedDebits,
              roundedTotal,
              creditColor,
              debitColor,
              showClearedRow: showClearedRow,
              startBalanceCents: startBalanceCents,
              secondaryCredits: showClearedRow
                  ? (roundingIncrement > 0
                        ? roundUpToIncrement(secCredits!, roundingIncrement)
                        : secCredits)
                  : (showExactRow ? displayCredits : null),
              secondaryDebits: showClearedRow
                  ? (roundingIncrement > 0
                        ? roundUpToIncrement(secDebits!, roundingIncrement)
                        : secDebits)
                  : (showExactRow ? displayDebits : null),
              secondaryTotal: showClearedRow
                  ? (roundingIncrement > 0
                        ? roundUpToIncrement(secTotal!, roundingIncrement)
                        : secTotal)
                  : (showExactRow ? displayTotal : null),
              showCents: showCents,
              isExactRow: showExactRow,
              currentPeriodMonth: currentPeriodMonth,
              plannedTotalForMonth: plannedTotalCallback,
              currentPeriodNetChange: primaryCredits + primaryDebits,
              isPast: isPast,
              isFutureMonth: isFutureMonth,
            ),
          ],
        ),
      ),
    );
  }

  /// Builds a compact horizontal section for spending envelopes at the top.
  /// Uses a glassmorphic design that blends seamlessly with the gradient card.
  Widget _buildEnvelopesSection(
    BuildContext context,
    List<TimelineItem> envelopes,
    bool isPast,
    bool isCurrentPeriod,
    bool isFutureMonth,
    Color debitColor, {
    required bool showCents,
  }) {
    final store = ExpenseStoreScope.read(context);
    final colorScheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingNormal,
        vertical: AppConstants.paddingSmall,
      ),
      // No background color - let the gradient card show through
      // Only a subtle bottom border for separation
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outlineVariant.withValues(
              alpha: isDark ? 0.2 : 0.15,
            ),
            width: 0.5,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header - very subtle
          Padding(
            padding: const EdgeInsets.only(bottom: 6, left: 2),
            child: Text(
              Terminology.of(context).budgetsLabel.toUpperCase(),
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
                fontSize: 9,
                color: colorScheme.onSurface.withValues(alpha: 0.5),
              ),
            ),
          ),
          // Horizontal scrollable envelope chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: envelopes.map((envelope) {
                final period = SpendingEnvelopeService.getEnvelopePeriodDates(
                  envelope,
                  month,
                  settings,
                );
                final spent = SpendingEnvelopeService.getSpentAmountForPeriod(
                  envelope,
                  pulses,
                  period,
                );
                // FIX: Use period end date to capture variations
                final target = envelope.getAmountForDate(period.$2).abs();

                // Determine if we're showing actuals or budgeted
                final showingActuals = isCurrentPeriod
                    ? (envelope.useActualsForCurrentBalance ??
                          settings.globalEnvelopeCurrentDeductActuals)
                    : (envelope.useActualsForFutureBalance ??
                          settings.globalEnvelopeFutureDeductActuals);

                // Progress calculation depends on context
                final progress = isFutureMonth
                    ? (showingActuals ? 0.0 : 1.0)
                    : (target > 0 ? spent / target : 0.0);
                final isOverBudget = progress > 1.0 && !isFutureMonth;

                // Glassmorphic chip styling - semi-transparent with subtle blur effect
                final Color progressColor;
                final Color accentColor; // Used for border and highlights

                if (isCurrentPeriod) {
                  if (showingActuals) {
                    progressColor = isOverBudget
                        ? (target == 0
                              ? colorScheme.primary
                              : colorScheme.error)
                        : (progress > 0.8
                              ? Colors.orange
                              : colorScheme.primary);
                    accentColor = colorScheme.primary;
                  } else {
                    progressColor = isOverBudget
                        ? (target == 0 ? debitColor : colorScheme.error)
                        : (progress > 0.8 ? Colors.orange : debitColor);
                    accentColor = debitColor;
                  }
                } else if (isFutureMonth) {
                  progressColor = colorScheme.onSurface.withValues(alpha: 0.3);
                  accentColor = colorScheme.outlineVariant;
                } else {
                  // Past months
                  progressColor = isOverBudget
                      ? (target == 0
                            ? debitColor.withValues(alpha: 0.7)
                            : colorScheme.error.withValues(alpha: 0.7))
                      : (progress > 0.8
                            ? Colors.orange.withValues(alpha: 0.7)
                            : debitColor.withValues(alpha: 0.7));
                  accentColor = debitColor.withValues(alpha: 0.5);
                }

                // Glassmorphic background - uses theme's onSurface color for universal compatibility
                // This creates a subtle "lift" effect that works with any background color
                final chipBgColor = isDark
                    ? colorScheme.onSurface.withValues(
                        alpha: 0.08,
                      ) // Light text color at low alpha on dark bg
                    : colorScheme.surface.withValues(
                        alpha: 0.7,
                      ); // Surface color on light bg

                final borderColor = isDark
                    ? accentColor.withValues(
                        alpha: showingActuals && isCurrentPeriod ? 0.6 : 0.25,
                      )
                    : accentColor.withValues(
                        alpha: showingActuals && isCurrentPeriod ? 0.5 : 0.2,
                      );

                return Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: GestureDetector(
                    onTap: () {
                      // Toggle between actual/budgeted display for all months
                      if (isCurrentPeriod) {
                        final currentValue =
                            envelope.useActualsForCurrentBalance ??
                            settings.globalEnvelopeCurrentDeductActuals;
                        store.upsertTimelineItem(
                          envelope.copyWith(
                            useActualsForCurrentBalance: Optional(
                              !currentValue,
                            ),
                          ),
                        );
                      } else if (isFutureMonth) {
                        final currentValue =
                            envelope.useActualsForFutureBalance ??
                            settings.globalEnvelopeFutureDeductActuals;
                        store.upsertTimelineItem(
                          envelope.copyWith(
                            useActualsForFutureBalance: Optional(!currentValue),
                          ),
                        );
                      }
                    },
                    onLongPress: isCurrentPeriod
                        ? () async {
                            // Quick-add only for current month
                            await showModalBottomSheet(
                              context: context,
                              backgroundColor: Colors.transparent,
                              builder: (ctx) => EnvelopeQuickSpendSheet(
                                envelope: envelope,
                                store: store,
                                month: month,
                              ),
                            );
                          }
                        : null,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: chipBgColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: borderColor,
                          width: showingActuals && isCurrentPeriod ? 1.5 : 0.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Compact progress indicator (vertical bar)
                          Container(
                            width: 4,
                            height: 28,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(2),
                              color: colorScheme.onSurface.withValues(
                                alpha: 0.08,
                              ),
                            ),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: FractionallySizedBox(
                                heightFactor: progress.clamp(0.0, 1.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(2),
                                    color: progressColor,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Name row with primary (deducted) amount
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    envelope.label,
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelMedium
                                        ?.copyWith(
                                          fontWeight: FontWeight.w600,
                                          color: colorScheme.onSurface,
                                        ),
                                  ),
                                  const SizedBox(width: 8),
                                  // Primary amount (the one being deducted from balance)
                                  Text(
                                    isFutureMonth
                                        ? (showingActuals
                                              ? formatMoneyFromCents(
                                                  0,
                                                  settings
                                                      .currencySettings
                                                      .currency,
                                                  showCents: showCents,
                                                )
                                              : formatMoneyFromCents(
                                                  target,
                                                  settings
                                                      .currencySettings
                                                      .currency,
                                                  showCents: showCents,
                                                ))
                                        : (showingActuals
                                              ? formatMoneyFromCents(
                                                  -spent,
                                                  settings
                                                      .currencySettings
                                                      .currency,
                                                  showCents: showCents,
                                                )
                                              : formatMoneyFromCents(
                                                  target,
                                                  settings
                                                      .currencySettings
                                                      .currency,
                                                  showCents: showCents,
                                                )),
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelMedium
                                        ?.copyWith(
                                          fontFeatures: const [
                                            FontFeature.tabularFigures(),
                                          ],
                                          fontWeight: FontWeight.w700,
                                          color: showingActuals
                                              ? progressColor
                                              : colorScheme.onSurface
                                                    .withValues(alpha: 0.8),
                                        ),
                                  ),
                                  const SizedBox(width: 6),
                                  // Mode indicator label (replaces cryptic dot)
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: showingActuals
                                          ? colorScheme.primaryContainer
                                          : colorScheme.secondaryContainer,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      showingActuals ? 'Actual' : 'Budget',
                                      style: TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w600,
                                        color: showingActuals
                                            ? colorScheme.onPrimaryContainer
                                            : colorScheme.onSecondaryContainer,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              // Secondary amount (the other number for context)
                              if (!isFutureMonth) ...[
                                const SizedBox(height: 1),
                                Text(
                                  showingActuals
                                      ? (target == 0
                                            ? 'unplanned spending'
                                            : 'spent of ${formatMoneyFromCents(target, settings.currencySettings.currency, showCents: showCents)} budget')
                                      : '${formatMoneyFromCents(target - spent, settings.currencySettings.currency, showCents: showCents)} left to set aside',
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        fontFeatures: const [
                                          FontFeature.tabularFigures(),
                                        ],
                                        fontSize: 9,
                                        color: colorScheme.onSurface.withValues(
                                          alpha: 0.5,
                                        ),
                                        fontWeight: FontWeight.w400,
                                      ),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context, {
    required PeriodInfo periodInfo,
    required int? startBalanceCents,
    required bool isCurrentPeriod,
    required bool isFutureMonth,
    required bool showCents,
  }) {
    final headerStyle = Theme.of(context).textTheme.titleMedium?.copyWith(
      fontWeight: FontWeight.w600,
      fontFeatures: const [FontFeature.tabularFigures()],
      color: Theme.of(context).colorScheme.onSurface,
    );

    return PillHeader(
      label: periodInfo.label,
      onLabelTap: onJumpToMonth != null
          ? () async {
              final picked = await showModalBottomSheet<DateTime>(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (context) => MonthYearPickerSheet(
                  initialDate: month,
                  firstDate: month_math.addMonths(
                    DateTime.now(),
                    -60,
                  ), // ± 5 years
                  lastDate: month_math.addMonths(DateTime.now(), 60),
                ),
              );
              if (picked != null) onJumpToMonth!(picked);
            }
          : null,
      badge: isCurrentPeriod
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: Theme.of(
                    context,
                  ).colorScheme.primary.withValues(alpha: 0.5),
                  width: 0.5,
                ),
              ),
              child: Text(
                'CURRENT',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                  fontSize: 9,
                ),
              ),
            )
          : null,
      trailing: startBalanceCents != null
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Balance Text - Tappable ONLY for Current Period
                InkWell(
                  onTap: () {
                    if (isCurrentPeriod) {
                      showEditBalanceDialog(context, settings);
                    }
                  },
                  borderRadius: BorderRadius.circular(4),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 2,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          formatMoneyFromCents(
                            startBalanceCents,
                            settings.currencySettings.currency,
                            showCents: showCents,
                          ),
                          style: headerStyle,
                        ),
                        if (isCurrentPeriod) ...[
                          const SizedBox(width: 4),
                          Icon(
                            Icons.edit_outlined,
                            size: 12,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurface.withValues(alpha: 0.3),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),

                if (settings.balanceUpdatesDisabled) ...[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.lock_outline,
                    size: 14,
                    color: Theme.of(
                      context,
                    ).colorScheme.onSurface.withValues(alpha: 0.5),
                  ),
                ],

                // Zero Baseline Toggle - ONLY for Future Months
                // Uses labeled chip for clear state indication and proper touch target (44px min)
                if (isFutureMonth) ...[
                  const SizedBox(width: 8),
                  InkWell(
                    onTap: () {
                      // Toggle zero baseline for all months (current and future)
                      settings.timelineUseZeroBaseline =
                          !settings.timelineUseZeroBaseline;
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      // Padding ensures 44px+ touch target height
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: settings.timelineUseZeroBaseline
                            ? Theme.of(context).colorScheme.primaryContainer
                            : Theme.of(
                                context,
                              ).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: settings.timelineUseZeroBaseline
                              ? Theme.of(context).colorScheme.primary
                              : Theme.of(context).colorScheme.outlineVariant,
                          width: 1,
                        ),
                      ),
                      child: Text(
                        settings.timelineUseZeroBaseline
                            ? 'Fresh Start'
                            : 'Carry Forward',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          fontSize: 10,
                          fontWeight: settings.timelineUseZeroBaseline
                              ? FontWeight.bold
                              : FontWeight.normal,
                          color: settings.timelineUseZeroBaseline
                              ? Theme.of(context).colorScheme.onPrimaryContainer
                              : Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            )
          : null,
      // Removed onTrailingTap as we now handle taps individually in the trailing widget
      onTrailingTap: null,
    );
  }

  Widget _buildFlatList(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    // Timeline list: no horizontal dividers, clean spacing
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingNormal,
        AppConstants.paddingSmall,
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
      ),
      itemCount: visibleItems.length,
      itemBuilder: (context, index) {
        final item = visibleItems[index];
        return _buildItemTile(
          context,
          item,
          isPast,
          isCurrentPeriod,
          creditColor,
          debitColor,
          showDatePrefix: true,
          showCents: showCents,
          lookupMap: lookupMap,
        );
      },
    );
  }

  Widget _buildGroupedList(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    // Group items by day
    final groups = <int, List<TimelineItem>>{};
    for (final item in visibleItems) {
      final clearedDate = _clearedDateFor(item.id, lookupMap);
      final day =
          clearedDate?.day ?? effectiveDayOfMonth(item.dayOfMonth, month);
      (groups[day] ??= []).add(item);
    }

    // Sort groups by day
    final sortedDays = groups.keys.toList()
      ..sort((a, b) {
        final cmp =
            daySortValue(
              a,
              viewMode: settings.viewPeriodMode,
              periodInfo: periodInfo,
            ).compareTo(
              daySortValue(
                b,
                viewMode: settings.viewPeriodMode,
                periodInfo: periodInfo,
              ),
            );
        return sortOrder == TimelineSortOrder.chronological ? cmp : -cmp;
      });

    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontWeight: FontWeight.w600,
    );

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
        AppConstants.paddingNormal,
        AppConstants.paddingXSmall,
      ),
      itemCount: sortedDays.length,
      itemBuilder: (context, groupIndex) {
        final day = sortedDays[groupIndex];
        final groupItems = groups[day]!;

        // Timeline layout: vertical line on left, date as node
        final timelineColor = Theme.of(
          context,
        ).colorScheme.outlineVariant.withValues(alpha: 0.4);
        final isFirst = groupIndex == 0;
        final isLast = groupIndex == sortedDays.length - 1;

        return IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Timeline column: vertical line with date node
              SizedBox(
                width: 44,
                child: Column(
                  children: [
                    // Top line segment (hidden on first item)
                    Container(
                      width: 2,
                      height: 12,
                      color: isFirst ? Colors.transparent : timelineColor,
                    ),
                    // Date node
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 4,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(
                          context,
                        ).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: timelineColor, width: 1),
                      ),
                      child: Text(
                        formatDayOfMonth(
                          DateTime(month.year, month.month, day),
                          settings.dayFormat,
                        ),
                        style: groupHeaderStyle?.copyWith(fontSize: 10),
                      ),
                    ),
                    // Bottom line segment (extends to fill remaining space)
                    Expanded(
                      child: Container(
                        width: 2,
                        color: isLast ? Colors.transparent : timelineColor,
                      ),
                    ),
                  ],
                ),
              ),
              // Items column
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 4, bottom: 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: groupItems
                        .map(
                          (item) => _buildItemTile(
                            context,
                            item,
                            isPast,
                            isCurrentPeriod,
                            creditColor,
                            debitColor,
                            showDatePrefix: false,
                            showCents: showCents,
                            lookupMap: lookupMap,
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildItemTile(
    BuildContext context,
    TimelineItem item,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required bool showDatePrefix,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    final clearedDate = _clearedDateFor(item.id, lookupMap);
    final pulse = _pulseFor(item.id, lookupMap);
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    final displayValues = getDisplayValues(
      item: item,
      month: month,
      pulse: pulse,
      periodInfo: periodInfo,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
    // final displayDay = displayValues.date.day;
    final displayAmount = displayValues.amountMinorUnits;
    // Don't show date prefix for spending envelopes - they represent a budget period, not a specific date
    final datePrefix =
        (showDatePrefix && item.type != PulseType.spendingEnvelope)
        ? '${formatDayOfMonth(displayValues.date, settings.dayFormat)} · '
        : '';
    // Only allow marking paid/unpaid for the current month/period, not future months
    final canArchive = isCurrentPeriod;
    Offset? lastPointerPosition;

    Offset menuSource() {
      if (lastPointerPosition != null) return lastPointerPosition!;
      final box = context.findRenderObject() as RenderBox?;
      if (box != null) {
        final center = box.size.center(Offset.zero);
        return box.localToGlobal(center);
      }
      return Offset.zero;
    }

    Future<void> openMenu() async {
      // Virtual items (standalone pulses) need special handling
      // They have IDs like 'virtual_pulseId'
      if (item.id.value.startsWith('virtual_')) {
        final pulseIdValue = item.id.value.substring('virtual_'.length);
        final store = ExpenseStoreScope.read(context);
        final pulse = store.pulses
            .where((p) => p.id.value == pulseIdValue)
            .firstOrNull;
        if (pulse != null) {
          // Show a context menu for the imported transaction
          final selection = await showMenu<String>(
            context: context,
            position: RelativeRect.fromLTRB(
              menuSource().dx,
              menuSource().dy,
              (context.findRenderObject() as RenderBox?)?.size.width ?? 0,
              0,
            ),
            items: [
              // Header with transaction info
              PopupMenuItem<String>(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                enabled: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pulse.label.isNotEmpty
                          ? pulse.label
                          : 'Untitled Transaction',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      formatMoneyFromCents(
                        pulse.amountMinorUnits,
                        settings.currency,
                        showCents: settings.showCents,
                      ),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    if (pulse.rawImportDescription != null &&
                        pulse.rawImportDescription!.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        pulse.rawImportDescription!,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const PopupMenuDivider(),
              // Link to Schedule option (primary action)
              if (pulse.timelineItemId == null)
                const PopupMenuItem<String>(
                  value: 'link',
                  child: Row(
                    children: [
                      Icon(Icons.link, size: 20),
                      SizedBox(width: 12),
                      Text('Link to Schedule'),
                    ],
                  ),
                )
              else
                PopupMenuItem<String>(
                  value: 'unlink',
                  child: Row(
                    children: [
                      Icon(Icons.link_off, size: 20),
                      const SizedBox(width: 12),
                      const Text('Unlink from Schedule'),
                    ],
                  ),
                ),
              const PopupMenuItem<String>(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit_outlined, size: 20),
                    SizedBox(width: 12),
                    Text('Edit Transaction'),
                  ],
                ),
              ),
              PopupMenuItem<String>(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(
                      Icons.delete_outline,
                      size: 20,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Delete',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );

          if (!context.mounted || selection == null) return;

          if (selection == 'link') {
            // Show the TimelineItemPicker to link this pulse
            final selectedItemId = await showModalBottomSheet<TimelineItemId>(
              context: context,
              isScrollControlled: true,
              showDragHandle: true,
              builder: (context) => TimelineItemPicker(
                month: monthOnly(pulse.date),
                items: store.activeTimelineItems,
                existingPulses: store.pulses,
                currentLinkedItemId: pulse.timelineItemId,
              ),
            );
            if (selectedItemId != null) {
              store.upsertPulse(pulse.copyWith(timelineItemId: selectedItemId));
            }
          } else if (selection == 'unlink') {
            store.upsertPulse(pulse.copyWith(timelineItemId: null));
          } else if (selection == 'edit') {
            final oldAmount = pulse.amountMinorUnits;
            final result = await showModalBottomSheet<PulseEntry?>(
              context: context,
              isScrollControlled: true,
              showDragHandle: true,
              builder: (ctx) => UpdatePulseSheet(
                pulse: pulse,
                title: 'Edit Transaction',
                onDelete: () {
                  store.deletePulse(pulse.id);
                  if (!settings.balanceUpdatesDisabled) {
                    settings.currentBalanceCents -= pulse.amountMinorUnits;
                  }
                },
              ),
            );
            if (result != null) {
              store.upsertPulse(result);
              if (!settings.balanceUpdatesDisabled) {
                settings.currentBalanceCents =
                    settings.currentBalanceCents -
                    oldAmount +
                    result.amountMinorUnits;
              }
            }
          } else if (selection == 'delete') {
            final confirmed = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Delete Transaction?'),
                content: const Text('Are you sure? This cannot be undone.'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: TextButton.styleFrom(
                      foregroundColor: Theme.of(context).colorScheme.error,
                    ),
                    child: const Text('Delete'),
                  ),
                ],
              ),
            );
            if (confirmed == true) {
              store.deletePulse(pulse.id);
              if (!settings.balanceUpdatesDisabled) {
                settings.currentBalanceCents -= pulse.amountMinorUnits;
              }
            }
          }
          return;
        }
      }

      await showTimelineItemMenu(
        context: context,
        item: item,
        month: month,
        position: menuSource(),
        canArchive: canArchive,
        periodInfo: periodInfo,
      );
    }

    final isCleared = clearedDate != null;
    final isSkipped = item.isSkippedInMonth(month);
    final isPaused = item.pausedDate != null;
    // Check if this month is prior to the freeze date (for strikethrough on frozen items)
    final isPriorToFreeze =
        isPaused &&
        month.isBefore(DateTime(item.pausedDate!.year, item.pausedDate!.month));
    final amountColor = item.type.isIncomeType ? creditColor : debitColor;

    // Grey out cleared items, past items, skipped items, or items prior to freeze
    final isMuted =
        isPast ||
        (isCleared && isCurrentPeriod) ||
        isSkipped ||
        isPriorToFreeze;
    final mutedTextColor = Theme.of(
      context,
    ).colorScheme.onSurface.withValues(alpha: 0.4);
    final mutedAmountColor = amountColor.withValues(
      alpha: (isSkipped || isPriorToFreeze) ? 0.2 : 0.4,
    );

    // Strikethrough for skipped items OR months prior to freeze date for frozen items
    final textDecoration = (isSkipped || isPriorToFreeze)
        ? TextDecoration.lineThrough
        : null;

    final tile = Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (event) => lastPointerPosition = event.position,
      child: Row(
        children: [
          // Colored indicator bar (4px) for credit/debit status
          Container(
            width: 4,
            height: 32,
            decoration: BoxDecoration(
              color: isMuted ? amountColor.withValues(alpha: 0.3) : amountColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          // The main list tile content
          Expanded(
            child: ListTile(
              dense: true,
              visualDensity: const VisualDensity(vertical: -4),
              contentPadding: EdgeInsets.zero,
              onTap: () async {
                // If skipped, tap always opens menu (likely to unskip)
                if (isSkipped) {
                  await openMenu();
                  return;
                }

                // If frozen (paused), single tap opens menu to allow unfreeze
                if (isPaused) {
                  await openMenu();
                  return;
                }

                // Spending envelopes: toggle actual/budgeted display
                if (item.type == PulseType.spendingEnvelope) {
                  final store = ExpenseStoreScope.read(context);
                  if (isCurrentPeriod) {
                    final currentValue =
                        item.useActualsForCurrentBalance ??
                        settings.globalEnvelopeCurrentDeductActuals;
                    store.upsertTimelineItem(
                      item.copyWith(
                        useActualsForCurrentBalance: Optional(!currentValue),
                      ),
                    );
                  } else {
                    final currentValue =
                        item.useActualsForFutureBalance ??
                        settings.globalEnvelopeFutureDeductActuals;
                    store.upsertTimelineItem(
                      item.copyWith(
                        useActualsForFutureBalance: Optional(!currentValue),
                      ),
                    );
                  }
                  return;
                }

                final wantsMenuOnTap =
                    settings.timelineTapAction == TimelineTapAction.menu;
                if (wantsMenuOnTap || !canArchive || isCleared) {
                  await openMenu();
                } else {
                  await handleItemAction(
                    context,
                    item,
                    TimelineSwipeAction.archive,
                  );
                }
              },
              onLongPress: () async {
                // Spending envelopes: long-press shows quick-add for current month only
                if (item.type == PulseType.spendingEnvelope) {
                  if (isCurrentPeriod) {
                    final store = ExpenseStoreScope.read(context);
                    await showModalBottomSheet(
                      context: context,
                      backgroundColor: Colors.transparent,
                      builder: (ctx) => EnvelopeQuickSpendSheet(
                        envelope: item,
                        store: store,
                        month: month,
                      ),
                    );
                  }
                  // Future months: no action on long-press
                  return;
                }

                final wantsMenuOnTap =
                    settings.timelineTapAction == TimelineTapAction.menu;
                if (wantsMenuOnTap && canArchive) {
                  // Long press archives when tap shows menu
                  await handleItemAction(
                    context,
                    item,
                    TimelineSwipeAction.archive,
                  );
                } else {
                  // Long press shows menu when tap archives (or when can't archive)
                  await openMenu();
                }
              },
              title: _buildItemTitle(
                context,
                item: item,
                datePrefix: datePrefix,
                isCleared: isCleared,
                isCurrentPeriod: isCurrentPeriod,
                isPast: isPast,
                clearedTextColor: mutedTextColor,
                isSkipped: isSkipped,
                isPriorToFreeze: isPriorToFreeze,
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Only show checkmark for cleared items in the current period
                  if (isCleared && (isCurrentPeriod || isPast)) ...[
                    Icon(Icons.check_circle, size: 14, color: mutedTextColor),
                    const SizedBox(width: AppConstants.paddingSmall - 2), // 6
                  ],
                  // Date variance indicator (only for imported transactions)
                  if (displayValues.hasDateVariance &&
                      isCleared &&
                      displayValues.scheduledDate != null &&
                      pulse?.isImported == true) ...[
                    Tooltip(
                      message: AppLocalizations.of(context)!.dueDatePaidDate(
                        displayValues.scheduledDate!.day,
                        displayValues.date.day,
                      ),
                      child: Icon(
                        Icons.schedule,
                        size: 12,
                        color: Colors.orange.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(width: AppConstants.paddingXSmall),
                  ],
                  // Salary business day adjustment indicator
                  if (displayValues.hasSalaryBusinessDayAdjustment &&
                      displayValues.rawSalaryDate != null) ...[
                    Tooltip(
                      message:
                          'Scheduled: ${displayValues.rawSalaryDate!.day}, Actual: ${displayValues.date.day} (weekend)',
                      child: Text(
                        '${displayValues.rawSalaryDate!.day}*',
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent,
                          fontFeatures: [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                    const SizedBox(width: AppConstants.paddingXSmall),
                  ],
                  if (displayValues.hasAmountVariance &&
                      isCleared &&
                      displayValues.scheduledAmountMinorUnits != null) ...[
                    Text(
                      formatMoneyFromCents(
                        displayValues.scheduledAmountMinorUnits!,
                        settings.currency,
                        showCents: showCents,
                      ),
                      style: TextStyle(
                        fontSize: 10,
                        fontFeatures: const [FontFeature.tabularFigures()],
                        color: mutedAmountColor,
                        decoration: TextDecoration.lineThrough,
                      ),
                    ),
                    const SizedBox(width: 4),
                  ],
                  // Spending envelope: show "spent / target" format
                  if (item.type == PulseType.spendingEnvelope) ...[
                    Builder(
                      builder: (context) {
                        final period =
                            SpendingEnvelopeService.getEnvelopePeriodDates(
                              item,
                              month,
                              settings,
                            );
                        final spent =
                            SpendingEnvelopeService.getSpentAmountForPeriod(
                              item,
                              pulses,
                              period,
                            );
                        // FIX: Use period end date to capture variations
                        final target = item.getAmountForDate(period.$2).abs();
                        final progress = target > 0 ? spent / target : 0.0;
                        final isOverBudget = progress > 1.0;
                        final progressColor = isOverBudget
                            ? Theme.of(context).colorScheme.error
                            : (progress > 0.8 ? Colors.orange : debitColor);

                        return Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Small progress indicator
                            Container(
                              width: 4,
                              height: 16,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(2),
                                color: Theme.of(
                                  context,
                                ).colorScheme.surfaceContainerHighest,
                              ),
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                child: FractionallySizedBox(
                                  heightFactor: progress.clamp(0.0, 1.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(2),
                                      color: progressColor,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '${formatMoneyFromCents(-spent, settings.currencySettings.currency, showCents: showCents)} / ${formatMoneyFromCents(target, settings.currencySettings.currency, showCents: showCents)}',
                              style: TextStyle(
                                fontFeatures: const [
                                  FontFeature.tabularFigures(),
                                ],
                                fontSize: 12,
                                color: isMuted
                                    ? mutedAmountColor
                                    : progressColor,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ] else ...[
                    // Standard amount display for non-envelope items
                    Text(
                      formatMoneyFromCents(
                        displayAmount,
                        settings.currencySettings.currency,
                        showCents: showCents,
                      ),
                      style: TextStyle(
                        fontFeatures: const [FontFeature.tabularFigures()],
                        color: isMuted ? mutedAmountColor : amountColor,
                        decoration: textDecoration,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );

    // Disable swipe actions for:
    // - Past and future months (only current period can toggle paid status)
    // - Spending envelopes (they use quick-spend flow, not archive)
    final isEnvelope = item.type == PulseType.spendingEnvelope;
    final direction = (!isCurrentPeriod || isEnvelope)
        ? null
        : dismissDirection(left: swipeLeft, right: swipeRight);
    if (direction == null) return tile;

    final isRecorded = clearedDate != null;

    return Dismissible(
      key: ValueKey(item.id),
      direction: direction,
      background: dismissBackground(
        context,
        action: swipeRight,
        alignLeft: true,
        isRecorded: isRecorded,
      ),
      secondaryBackground: dismissBackground(
        context,
        action: swipeLeft,
        alignLeft: false,
        isRecorded: isRecorded,
      ),
      confirmDismiss: (dismissDirection) async {
        final action = dismissDirection == DismissDirection.endToStart
            ? swipeLeft
            : swipeRight;
        return handleItemAction(context, item, action);
      },
      child: tile,
    );
  }

  Widget _buildItemTitle(
    BuildContext context, {
    required TimelineItem item,
    required String datePrefix,
    required bool isCleared,
    required bool isCurrentPeriod,
    required bool isPast,
    required Color clearedTextColor,
    bool isSkipped = false,
    bool isPriorToFreeze = false,
  }) {
    final textColor =
        (isCleared && (isCurrentPeriod || isPast)) ||
            isSkipped ||
            isPriorToFreeze
        ? clearedTextColor
        : (isPast ? clearedTextColor : null);
    final decoration = (isSkipped || isPriorToFreeze)
        ? TextDecoration.lineThrough
        : null;

    // Build the label with optional company suffix
    String buildDisplayLabel(String baseLabel) {
      if (settings.getTimelineShowPulseOrigin(TimelineViewMode.month) &&
          item.origin != null &&
          item.origin!.isNotEmpty) {
        return '$baseLabel (${item.origin})';
      }
      return baseLabel;
    }

    // For full display mode or automatic (which defaults to full for month view)
    if (displayMode == PulseDisplayMode.full ||
        displayMode == PulseDisplayMode.automatic) {
      return Text(
        '$datePrefix${buildDisplayLabel(item.label)}',
        style: TextStyle(color: textColor, decoration: decoration),
      );
    }

    // For icon mode
    if (displayMode == PulseDisplayMode.icon) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (datePrefix.isNotEmpty)
            Text(
              datePrefix,
              style: textColor != null ? TextStyle(color: textColor) : null,
            ),
          Icon(
            getPulseIcon(
              item.label,
              type: item.type,
              categoryIcons: settings.categoryIcons,
            ),
            size: 18,
            color: (isCleared && isCurrentPeriod)
                ? clearedTextColor
                : Theme.of(context).colorScheme.onSurface,
          ),
        ],
      );
    }

    // For acronym mode
    return Text(
      '$datePrefix${buildDisplayLabel(generateAcronym(item.label))}',
      style: TextStyle(fontWeight: FontWeight.bold, color: textColor),
    );
  }

  Widget _buildFooter(
    BuildContext context,
    int credits,
    int debits,
    int total,
    Color creditColor,
    Color debitColor, {
    required bool showClearedRow,
    int? startBalanceCents,
    int? secondaryCredits,
    int? secondaryDebits,
    int? secondaryTotal,
    required bool showCents,
    bool isExactRow = false,
    required DateTime currentPeriodMonth,
    required int Function(
      DateTime month, {
      bool includeEnvelopes,
      Map<String, bool>? envelopeOverrides,
      Map<String, bool>? futureEnvelopeOverrides,
    })
    plannedTotalForMonth,
    required int currentPeriodNetChange,
    required bool isPast,
    required bool isFutureMonth,
  }) {
    final l10n = AppLocalizations.of(context)!;
    final baseTextStyle =
        (Theme.of(context).textTheme.labelMedium ??
                const TextStyle(fontSize: 12))
            .copyWith(fontFeatures: const [FontFeature.tabularFigures()]);

    // Tooltip logic
    String? secondaryTooltip = l10n.monthTotalsExcludingClearedLabel;
    String secondaryLabel = 'Pending';
    if (isExactRow) {
      secondaryTooltip = isPast
          ? 'Exact net (unrounded)'
          : 'Exact end balance (unrounded)';
      secondaryLabel = 'Exact';
    }

    // For current month: currentPeriodNetChange does NOT account for future envelope overrides
    // because it uses the "standard" display logic of month card.
    // However, the BalanceProjectionSheet will recalculate everything anyway.

    final hasSecondaryRow =
        secondaryCredits != null &&
        secondaryDebits != null &&
        secondaryTotal != null;
    final hasLeadingIcon = showClearedRow || isExactRow || hasSecondaryRow;
    final showPrimaryTotal = !showClearedRow && !isExactRow;

    // Build table rows for proper column alignment
    Widget buildLabel(String? label, String? tooltip) {
      if (label == null) return const SizedBox(width: 16);
      final labelText = Text(
        label,
        style: baseTextStyle.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontWeight: FontWeight.w600,
          fontSize: 10,
        ),
      );
      // Only wrap in Tooltip if tooltip text exists
      if (tooltip == null || tooltip.isEmpty) {
        return labelText;
      }
      return Tooltip(message: tooltip, child: labelText);
    }

    Widget buildCredits(int amount) => Text(
      l10n.creditsLabel(
        formatMoneyFromCents(
          amount,
          settings.currencySettings.currency,
          showCents: showCents,
        ),
      ),
      style: TextStyle(color: creditColor),
    );

    Widget buildDebits(int amount) => Text(
      l10n.debitsLabel(
        formatMoneyFromCents(
          amount,
          settings.currencySettings.currency,
          showCents: showCents,
        ),
      ),
      style: TextStyle(color: debitColor),
    );

    void openBalanceProjection() async {
      // Don't allow projection from past months
      if (isPast) return;

      await showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isScrollControlled: true,
        builder: (context) => BalanceProjectionSheet(
          currentMonth: month,
          currentBalanceCents: settings.currentBalanceCents,
          currentPeriodNetChange: currentPeriodNetChange,
          items: items,
          settings: settings,
          plannedTotalForMonth: plannedTotalForMonth,
          currentPeriodMonth: currentPeriodMonth,
          // For future months, pre-select that month as the starting point
          initialZeroStartMonth: isFutureMonth ? month : null,
        ),
      );
    }

    Widget buildTotal(int amount, {bool visible = true}) => visible
        ? GestureDetector(
            behavior: HitTestBehavior.opaque,
            // Disable tap for past months
            onTap: isPast ? null : openBalanceProjection,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
              child: Text(
                // Use "Net" for past periods (we don't know the actual end balance),
                // "End Balance" for current/future (we have a known starting balance)
                isPast
                    ? l10n.netLabel(
                        formatMoneyFromCents(
                          amount,
                          settings.currencySettings.currency,
                          showCents: showCents,
                        ),
                      )
                    : l10n.totalLabel(
                        formatMoneyFromCents(
                          amount,
                          settings.currencySettings.currency,
                          showCents: showCents,
                        ),
                      ),
                // Dim the text for past months to indicate it's not tappable
                style: isPast
                    ? TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      )
                    : null,
              ),
            ),
          )
        : const SizedBox.shrink();

    return GradientCardFooter(
      child: DefaultTextStyle(
        style: baseTextStyle,
        child: Table(
          defaultColumnWidth: const IntrinsicColumnWidth(),
          columnWidths: const {
            0: IntrinsicColumnWidth(), // Icon column
            1: IntrinsicColumnWidth(), // Credits column
            2: IntrinsicColumnWidth(), // Debits column
            3: FlexColumnWidth(), // Spacer
            4: IntrinsicColumnWidth(), // Total column
          },
          children: [
            // Primary row (Credits/Debits/Total)
            TableRow(
              children: [
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: hasLeadingIcon
                        ? buildLabel(
                            showClearedRow
                                ? 'All'
                                : (isExactRow ? 'Rounded' : null),
                            showClearedRow
                                ? l10n.monthTotalsIncludingClearedLabel
                                : (isExactRow ? 'Rounded balance' : null),
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: buildCredits(credits),
                  ),
                ),
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: buildDebits(debits),
                ),
                const TableCell(child: SizedBox.shrink()), // Spacer
                TableCell(
                  verticalAlignment: TableCellVerticalAlignment.middle,
                  child: buildTotal(total, visible: showPrimaryTotal),
                ),
              ],
            ),
            // Secondary row (if present)
            if (secondaryCredits != null &&
                secondaryDebits != null &&
                secondaryTotal != null)
              TableRow(
                children: [
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10, top: 6),
                      child: buildLabel(secondaryLabel, secondaryTooltip),
                    ),
                  ),
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10, top: 6),
                      child: buildCredits(secondaryCredits),
                    ),
                  ),
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: buildDebits(secondaryDebits),
                    ),
                  ),
                  const TableCell(child: SizedBox.shrink()), // Spacer
                  TableCell(
                    verticalAlignment: TableCellVerticalAlignment.middle,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: buildTotal(secondaryTotal),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  DateTime? _clearedDateFor(
    TimelineItemId itemId,
    Map<TimelineItemId, PulseEntry?> lookupMap,
  ) {
    if (pulses.isEmpty) return null;
    return lookupMap[itemId]?.date;
  }

  PulseEntry? _pulseFor(
    TimelineItemId itemId,
    Map<TimelineItemId, PulseEntry?> lookupMap,
  ) {
    if (pulses.isEmpty) return null;
    return lookupMap[itemId];
  }

  Map<TimelineItemId, PulseEntry?> _buildPulseLookupMap(
    AppSettingsStore settings,
  ) {
    final map = <TimelineItemId, PulseEntry?>{};
    for (final item in items) {
      PulseEntry? best;
      for (final pulse in pulses) {
        if (pulseMatchesTimelineItem(pulse, item, month, settings)) {
          if (best == null || pulse.date.isAfter(best.date)) best = pulse;
        }
      }
      map[item.id] = best;
    }
    return map;
  }

  int _plannedTotalForMonth(
    DateTime targetMonth,
    DateTime currentPeriodMonth, {
    bool includeEnvelopes = true,
    Map<String, bool>? envelopeOverrides,
    Map<String, bool>? futureEnvelopeOverrides,
  }) {
    // For balance projection, we sum ALL items for each month.
    //
    // The balance projection formula is:
    //   Future month start = currentBalance + sum(all items from current to target-1)

    final periodInfo = PaycheckService.getPeriodInfo(
      targetMonth,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );

    // Note: MonthCard only has pulse for ITS OWN month.
    // If targetMonth is different, we have no pulse to use for "Actuals" logic.
    // However, if targetMonth is in the future, spent amount will be 0 anyway.
    final relevantPulses = (monthOnly(targetMonth) == monthOnly(month))
        ? pulses
        : const <PulseEntry>[];
    final isCurrentPeriod =
        monthOnly(targetMonth) == monthOnly(currentPeriodMonth);

    return items
        .where((item) => !item.archived)
        .where(
          (item) => PaycheckService.shouldItemAppearInPeriod(
            item,
            periodInfo,
            targetMonth,
            ignoreSkips: true,
          ),
        )
        .where(
          (item) => includeEnvelopes || item.type != PulseType.spendingEnvelope,
        )
        .fold<int>(0, (sum, item) {
          // Determine useActuals override for this item
          bool? useActualsOverride;
          if (item.type == PulseType.spendingEnvelope) {
            if (isCurrentPeriod && envelopeOverrides != null) {
              // Check for per-envelope override
              useActualsOverride = envelopeOverrides[item.id.value];
            } else if (!isCurrentPeriod) {
              // Check for per-envelope future override
              // If not found, fall back to global settings or item settings
              if (futureEnvelopeOverrides != null &&
                  futureEnvelopeOverrides.containsKey(item.id.value)) {
                useActualsOverride = futureEnvelopeOverrides[item.id.value];
              }
            }
          }

          return sum +
              calculateItemNetChangeForMonth(
                item: item,
                month: targetMonth,
                pulses: relevantPulses,
                isCurrentPeriod: isCurrentPeriod,
                periodInfo: periodInfo,
                settings: settings,
                useActualsOverride: useActualsOverride,
              );
        });
  }

  Widget _buildThemeGroupedList(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    // Group items by category (Theme)
    final groups = <String, List<TimelineItem>>{};
    for (final item in visibleItems) {
      String category =
          item.category ?? (item.type.isIncomeType ? 'Income' : 'Expenses');

      // Fallback if category is empty string
      if (category.trim().isEmpty) {
        category = item.type.isIncomeType ? 'Income' : 'Expenses';
      }

      (groups[category] ??= []).add(item);
    }

    // Sort groups alphabetically
    final sortedCategories = groups.keys.toList()..sort();

    // Pre-sort all groups before building to avoid sorting on every frame
    final sortedGroups = <String, List<TimelineItem>>{};
    for (final category in sortedCategories) {
      final categoryItems = groups[category]!.toList(); // Make a copy
      categoryItems.sort((a, b) {
        final dateA =
            _clearedDateFor(a.id, lookupMap) ??
            effectiveDayOfMonth(a.dayOfMonth, month);
        final dateB =
            _clearedDateFor(b.id, lookupMap) ??
            effectiveDayOfMonth(b.dayOfMonth, month);

        // Convert to integers for comparison
        final dayA = dateA is DateTime ? dateA.day : dateA as int;
        final dayB = dateB is DateTime ? dateB.day : dateB as int;

        return dayA.compareTo(dayB);
      });
      sortedGroups[category] = categoryItems;
    }

    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontWeight: FontWeight.bold,
    );

    final theme = Theme.of(context);
    final surfaceColor = theme.colorScheme.surfaceContainerHighest;

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      itemCount: sortedCategories.length,
      itemBuilder: (context, groupIndex) {
        final category = sortedCategories[groupIndex];
        final groupItems = sortedGroups[category]!; // Already sorted

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Category header
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: surfaceColor.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(category, style: groupHeaderStyle),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Divider(
                      height: 1,
                      color: theme.dividerColor.withValues(alpha: 0.5),
                    ),
                  ),
                ],
              ),
            ),
            // Items in this group (already sorted)
            ...groupItems.map(
              (item) => _buildItemTile(
                context,
                item,
                isPast,
                isCurrentPeriod,
                creditColor,
                debitColor,
                showDatePrefix: true,
                showCents: showCents,
                lookupMap: lookupMap,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSplitList(
    BuildContext context,
    List<TimelineItem> items,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    // 1. Split items
    final pendingItems = <TimelineItem>[];
    final clearedItems = <TimelineItem>[];

    for (final item in items) {
      if (_clearedDateFor(item.id, lookupMap) != null) {
        clearedItems.add(item);
      } else {
        pendingItems.add(item);
      }
    }

    // 2. Build slivers for each group
    // Pending first
    final pendingSlivers = _buildContentSlivers(
      context,
      pendingItems,
      isPast,
      isCurrentPeriod,
      creditColor,
      debitColor,
      periodInfo: periodInfo,
      showCents: showCents,
      lookupMap: lookupMap,
    );

    // Cleared second
    final clearedSlivers = _buildContentSlivers(
      context,
      clearedItems,
      isPast,
      isCurrentPeriod,
      creditColor,
      debitColor,
      periodInfo: periodInfo,
      showCents: showCents,
      lookupMap: lookupMap,
    );

    return CustomScrollView(
      slivers: [
        if (pendingItems.isNotEmpty) ...[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            sliver: SliverToBoxAdapter(
              child: Text(
                'PENDING',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.primary,
                  letterSpacing: 1.2,
                  fontSize: 11,
                ),
              ),
            ),
          ),
          ...pendingSlivers,
        ],

        if (pendingItems.isNotEmpty && clearedItems.isNotEmpty)
          SliverPadding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            sliver: SliverToBoxAdapter(
              child: Divider(
                indent: 16,
                endIndent: 16,
                color: Theme.of(
                  context,
                ).colorScheme.outlineVariant.withValues(alpha: 0.5),
              ),
            ),
          ),

        if (clearedItems.isNotEmpty) ...[
          if (pendingItems.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              sliver: SliverToBoxAdapter(
                child: Text(
                  'CLEARED',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: Theme.of(
                      context,
                    ).colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
                    letterSpacing: 1.2,
                    fontSize: 11,
                  ),
                ),
              ),
            ),
          ...clearedSlivers,
        ],

        // Add bottom padding
        const SliverPadding(padding: EdgeInsets.only(bottom: 16)),
      ],
    );
  }

  List<Widget> _buildContentSlivers(
    BuildContext context,
    List<TimelineItem> items,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    if (items.isEmpty) return [];

    if (settings.timelineGroupByTheme) {
      return _buildThemeGroupedSlivers(
        context,
        items,
        isPast,
        isCurrentPeriod,
        creditColor,
        debitColor,
        periodInfo: periodInfo,
        showCents: showCents,
        lookupMap: lookupMap,
      );
    } else if (settings.timelineGroupByDate) {
      return _buildGroupedSlivers(
        context,
        items,
        isPast,
        isCurrentPeriod,
        creditColor,
        debitColor,
        periodInfo: periodInfo,
        showCents: showCents,
        lookupMap: lookupMap,
      );
    } else {
      return [
        _buildFlatSliver(
          context,
          items,
          isPast,
          isCurrentPeriod,
          creditColor,
          debitColor,
          showCents: showCents,
          lookupMap: lookupMap,
        ),
      ];
    }
  }

  Widget _buildFlatSliver(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    return SliverList(
      delegate: SliverChildBuilderDelegate((context, index) {
        final item = visibleItems[index];
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
          child: _buildItemTile(
            context,
            item,
            isPast,
            isCurrentPeriod,
            creditColor,
            debitColor,
            showDatePrefix: true,
            showCents: showCents,
            lookupMap: lookupMap,
          ),
        );
      }, childCount: visibleItems.length),
    );
  }

  List<Widget> _buildGroupedSlivers(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    final groups = <int, List<TimelineItem>>{};
    for (final item in visibleItems) {
      final clearedDate = _clearedDateFor(item.id, lookupMap);
      final day =
          clearedDate?.day ?? effectiveDayOfMonth(item.dayOfMonth, month);
      (groups[day] ??= []).add(item);
    }

    final sortedDays = groups.keys.toList()
      ..sort((a, b) {
        final cmp =
            daySortValue(
              a,
              viewMode: settings.viewPeriodMode,
              periodInfo: periodInfo,
            ).compareTo(
              daySortValue(
                b,
                viewMode: settings.viewPeriodMode,
                periodInfo: periodInfo,
              ),
            );
        return sortOrder == TimelineSortOrder.chronological ? cmp : -cmp;
      });

    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontWeight: FontWeight.w600,
    );

    return [
      SliverList(
        delegate: SliverChildBuilderDelegate((context, groupIndex) {
          final day = sortedDays[groupIndex];
          final groupItems = groups[day]!;
          final timelineColor = Theme.of(
            context,
          ).colorScheme.outlineVariant.withValues(alpha: 0.4);
          final isFirst = groupIndex == 0;
          final isLast = groupIndex == sortedDays.length - 1;

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(
                    width: 44,
                    child: Column(
                      children: [
                        Container(
                          width: 2,
                          height: 12,
                          color: isFirst ? Colors.transparent : timelineColor,
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: timelineColor, width: 1),
                          ),
                          child: Text(
                            formatDayOfMonth(
                              DateTime(month.year, month.month, day),
                              settings.dayFormat,
                            ),
                            style: groupHeaderStyle?.copyWith(fontSize: 10),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            width: 2,
                            color: isLast ? Colors.transparent : timelineColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 4, bottom: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: groupItems
                            .map(
                              (item) => _buildItemTile(
                                context,
                                item,
                                isPast,
                                isCurrentPeriod,
                                creditColor,
                                debitColor,
                                showDatePrefix: false,
                                showCents: showCents,
                                lookupMap: lookupMap,
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }, childCount: sortedDays.length),
      ),
    ];
  }

  List<Widget> _buildThemeGroupedSlivers(
    BuildContext context,
    List<TimelineItem> visibleItems,
    bool isPast,
    bool isCurrentPeriod,
    Color creditColor,
    Color debitColor, {
    required PeriodInfo periodInfo,
    required bool showCents,
    required Map<TimelineItemId, PulseEntry?> lookupMap,
  }) {
    final groups = <String, List<TimelineItem>>{};
    for (final item in visibleItems) {
      String category =
          item.category ?? (item.type.isIncomeType ? 'Income' : 'Expenses');
      if (category.trim().isEmpty) {
        category = item.type.isIncomeType ? 'Income' : 'Expenses';
      }
      (groups[category] ??= []).add(item);
    }

    final sortedCategories = groups.keys.toList()..sort();
    final sortedGroups = <String, List<TimelineItem>>{};
    for (final category in sortedCategories) {
      final categoryItems = groups[category]!.toList();
      categoryItems.sort((a, b) {
        final dateA =
            _clearedDateFor(a.id, lookupMap) ??
            effectiveDayOfMonth(a.dayOfMonth, month);
        final dateB =
            _clearedDateFor(b.id, lookupMap) ??
            effectiveDayOfMonth(b.dayOfMonth, month);
        final dayA = dateA is DateTime ? dateA.day : dateA as int;
        final dayB = dateB is DateTime ? dateB.day : dateB as int;
        return dayA.compareTo(dayB);
      });
      sortedGroups[category] = categoryItems;
    }

    final groupHeaderStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontWeight: FontWeight.bold,
    );
    final theme = Theme.of(context);
    final surfaceColor = theme.colorScheme.surfaceContainerHighest;

    return [
      SliverList(
        delegate: SliverChildBuilderDelegate((context, groupIndex) {
          final category = sortedCategories[groupIndex];
          final groupItems = sortedGroups[category]!;

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: surfaceColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(category, style: groupHeaderStyle),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Divider(
                          height: 1,
                          color: theme.dividerColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                ...groupItems.map(
                  (item) => _buildItemTile(
                    context,
                    item,
                    isPast,
                    isCurrentPeriod,
                    creditColor,
                    debitColor,
                    showDatePrefix: true,
                    showCents: showCents,
                    lookupMap: lookupMap,
                  ),
                ),
              ],
            ),
          );
        }, childCount: sortedCategories.length),
      ),
    ];
  }

  Widget _buildAdvancePeriodButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingNormal,
        vertical: 8.0,
      ),
      child: FilledButton.tonalIcon(
        onPressed: () {
          final store = ExpenseStoreScope.read(context);
          store.goToNextMonth();
        },
        icon: const Icon(Icons.fast_forward),
        label: const Text('Advance to Next Period'),
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
      ),
    );
  }
}
