import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/multi_month_grid.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_sheet.dart';

/// Manages controller state and zoom calculations for TimelineScreen.
///
/// Handles:
/// - PageController for month pagination
/// - TransformationControllers for sheet and grid zoom/pan
/// - Month window sizing (anchored to earliest month)
/// - Zoom level calculations
class TimelineScreenController {
  TimelineScreenController({
    required this.monthOrigin,
    required this.pageController,
    required this.sheetTransformController,
    required this.gridTransformController,
    required TickerProvider vsync,
  }) : _vsync = vsync {
    _animationController = AnimationController(
      vsync: _vsync,
      duration: const Duration(milliseconds: 300),
    );
    _animationController.addListener(() {
      if (_snapAnimation != null) {
        final matrix = _snapAnimation!.value;
        if (_isSnappingSheet) {
          sheetTransformController.value = matrix;
        } else {
          gridTransformController.value = matrix;
        }
      }
    });
  }

  static const int monthWindowSize = 121;
  static const int monthOriginPage = monthWindowSize ~/ 2;

  DateTime monthOrigin;
  final PageController pageController;
  final TransformationController sheetTransformController;
  final TransformationController gridTransformController;
  final TickerProvider _vsync;

  late final AnimationController _animationController;
  Animation<Matrix4>? _snapAnimation;
  bool _isSnappingSheet = true;

  // Sheet view state
  double? lastSheetViewportWidth;
  bool didInitSheetTransform = false;
  double? sheetInitScaleFactorFromPinch;

  // Grid view state
  bool didInitGridTransform = false;
  double? lastGridViewportWidth;
  double? lastGridViewportHeight;
  int gridTargetMonths = 4;

  /// Synchronizes the page view with the store's selected month if needed.
  void syncMonthPageIfNeeded(DateTime selectedMonth, int monthWindowSize) {
    if (!pageController.hasClients) return;
    final desired = monthOriginPage + monthsBetween(monthOrigin, selectedMonth);
    final current = pageController.page?.round();
    if (current == null) return;
    if (desired < 0 || desired >= monthWindowSize) {
      return; // Window needs recentering, handled by caller
    }
    if (current == desired) return;
    pageController.jumpToPage(desired);
  }

  /// Initializes sheet transform if not already done and viewport width is valid.
  void ensureInitialSheetTransform({
    required double viewportWidth,
    required int monthsBeforeSelected,
    double? columnWidth,
  }) {
    if (didInitSheetTransform) return;
    if (viewportWidth <= 0) return;

    final effectiveColumnWidth = columnWidth ?? TimelineSheet.columnWidth;

    // Default to showing exactly 2 months
    const targetVisibleMonths = 2.0;
    final baseScale =
        viewportWidth / (effectiveColumnWidth * targetVisibleMonths);
    final pinchFactor = sheetInitScaleFactorFromPinch;
    sheetInitScaleFactorFromPinch = null;

    final factor = pinchFactor == null ? 1.0 : pinchFactor.clamp(0.4, 1.0);
    final scale = (baseScale * factor).clamp(0.15, 2.5);

    // Calculate translation to show selected month
    // We want the selected month to be at the left edge (or slightly offset?)
    // xTranslation = - (monthsBeforeSelected * columnWidth * scale)
    final xTranslation = -(monthsBeforeSelected * effectiveColumnWidth * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(0, 3, xTranslation);

    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      sheetTransformController.value = matrix;
      didInitSheetTransform = true;
    });
  }

  /// Initializes grid transform if not already done and viewport width is valid.
  void ensureInitialGridTransform({
    required double viewportWidth,
    required double viewportHeight,
    required int monthsBeforeSelected,
  }) {
    if (didInitGridTransform) return;
    if (viewportWidth <= 0 || viewportHeight <= 0) return;

    final scale = _gridScaleForViewport(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonths: gridTargetMonths,
    );

    // Calculate which row the selected month is in
    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: gridTargetMonths,
    );

    // The grid is built with row-major order: index = row * columns + col
    // So row = index ~/ columns
    final selectedRowIndex = monthsBeforeSelected ~/ dimensions.columns;

    // Position the selected month's row at the top of the viewport
    final offsetRows = selectedRowIndex;

    // Calculate Y offset to bring that row into view
    final yTranslation = -(offsetRows * MultiMonthGrid.outerCardHeight * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(1, 3, yTranslation);

    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      gridTransformController.value = matrix;
      didInitGridTransform = true;
    });
  }

  /// Calculates the number of visible months in the sheet view.
  double visibleSheetMonths(double viewportWidth, {double? columnWidth}) {
    final effectiveColumnWidth = columnWidth ?? TimelineSheet.columnWidth;
    final scale = sheetTransformController.value.storage[0].abs();
    final normalizedScale = scale <= 0 ? 1.0 : scale;
    return viewportWidth / (effectiveColumnWidth * normalizedScale);
  }

  /// Determines the zoom stage based on viewport width and current scale.
  GridZoomStage sheetZoomStageForWidth(
    double viewportWidth, {
    double? columnWidth,
  }) {
    if (viewportWidth <= 0) return GridZoomStage.twoMonths;
    final visible = visibleSheetMonths(viewportWidth, columnWidth: columnWidth);
    return gridZoomStageForVisibleMonths(visible);
  }

  GridDimensions gridDimensionsForViewport({
    required double viewportWidth,
    required double viewportHeight,
  }) {
    if (viewportWidth <= 0 || viewportHeight <= 0) {
      return const GridDimensions(columns: 2, rows: 1);
    }
    return calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: gridTargetMonths,
    );
  }

  /// Jumps to a specific zoom stage in the sheet view.
  void jumpToZoomStage(GridZoomStage stage, {double? columnWidth}) {
    final viewportWidth = lastSheetViewportWidth;
    if (viewportWidth == null || viewportWidth <= 0) return;
    final effectiveColumnWidth = columnWidth ?? TimelineSheet.columnWidth;
    final targetVisibleMonths = switch (stage) {
      GridZoomStage.twoMonths => 2.0,
      GridZoomStage.fourMonths => 4.0,
      GridZoomStage.sixMonths => 6.0,
    };
    final targetScale =
        (viewportWidth / (effectiveColumnWidth * targetVisibleMonths)).clamp(
          0.15,
          2.5,
        );
    final matrix = Matrix4.identity()
      ..setEntry(0, 0, targetScale)
      ..setEntry(1, 1, targetScale);
    sheetTransformController.value = matrix;
  }

  /// Jumps to a specific number of visible grid months.
  void jumpToGridMonths({
    required int targetMonths,
    required int monthsBeforeSelected,
  }) {
    gridTargetMonths = targetMonths;
    final viewportWidth = lastGridViewportWidth;
    final viewportHeight = lastGridViewportHeight;
    if (viewportWidth == null ||
        viewportHeight == null ||
        viewportWidth <= 0 ||
        viewportHeight <= 0) {
      return;
    }

    final scale = _gridScaleForViewport(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonths: targetMonths,
    );

    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: targetMonths,
    );

    final selectedRowIndex = monthsBeforeSelected ~/ dimensions.columns;
    final offsetRows = selectedRowIndex;
    final yTranslation = -(offsetRows * MultiMonthGrid.outerCardHeight * scale);

    final matrix = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(1, 3, yTranslation);
    gridTransformController.value = matrix;
  }

  double _gridScaleForViewport({
    required double viewportWidth,
    required double viewportHeight,
    required int targetMonths,
  }) {
    final dimensions = calculateGridDimensions(
      viewportWidth: viewportWidth,
      viewportHeight: viewportHeight,
      targetMonthCount: targetMonths,
    );
    final totalWidth = dimensions.columns * MultiMonthGrid.outerCardWidth;
    final totalHeight = dimensions.rows * MultiMonthGrid.outerCardHeight;
    final scale = math.min(
      viewportWidth / totalWidth,
      viewportHeight / totalHeight,
    );
    return scale.clamp(0.3, 2.0);
  }

  /// Snaps the sheet view to the nearest column boundary.
  /// Should be called from onInteractionEnd.
  ///
  /// [columnWidth] - The effective column width (accounting for settings like showPulseOrigin).
  /// [visibleMonths] - Number of currently visible months (for period-based snapping).
  /// Snaps the sheet view to the nearest column boundary.
  /// Should be called from onInteractionEnd.
  ///
  /// [columnWidth] - The effective column width (accounting for settings like showPulseOrigin).
  /// [visibleMonths] - Number of currently visible months (for period-based snapping).
  void snapSheetToGrid(
    ScaleEndDetails details, {
    double? columnWidth,
    int? visibleMonths,
  }) {
    final matrix = sheetTransformController.value;
    final scale = matrix.row0.x; // Current horizontal scale
    final translationX = matrix.row0.w; // Current horizontal translation

    final effectiveColumnWidth = columnWidth ?? TimelineSheet.columnWidth;

    // The effective width of one column at current zoom level
    final scaledColumnWidth = effectiveColumnWidth * scale;
    final snapWidth =
        scaledColumnWidth; // Snap to 1 column always for clean movement

    // Determine target index based on velocity + current position
    final currentIndex = translationX / snapWidth;
    final velocityX = details.velocity.pixelsPerSecond.dx;

    double targetIndex;

    if (velocityX.abs() > 200) {
      // Swipe detected: Move to next/prev index regardless of distance
      // If velocity is positive (swipe right), we want to decrease index (move towards 0 or positive x)
      // If velocity is negative (swipe left), we want to increase index (move towards negative x)
      // Note: translation is negative as we scroll right.
      if (velocityX < 0) {
        // Swipe Left -> Move "forward" in time (more negative translation) -> rounds closer to -infinity
        targetIndex = (currentIndex - 0.5).floorToDouble();
      } else {
        // Swipe Right -> Move "back" in time (more positive translation) -> rounds closer to +infinity
        targetIndex = (currentIndex + 0.5).ceilToDouble();
      }
    } else {
      // Slow drag: Snap to nearest
      targetIndex = currentIndex.roundToDouble();
    }

    final snappedX = targetIndex * snapWidth;

    // Only snap if there's a meaningful difference
    if ((translationX - snappedX).abs() > 0.5) {
      _isSnappingSheet = true;
      _animateSnap(matrix, matrix.clone()..setEntry(0, 3, snappedX));
    }
  }

  /// Snaps the grid view to the nearest row boundary.
  /// Should be called from onInteractionEnd.
  void snapGridToRow(ScaleEndDetails details) {
    final matrix = gridTransformController.value;
    final scale = matrix.row1.y; // Current vertical scale
    final translationY = matrix.row1.w; // Current vertical translation

    // The effective height of one row at current zoom level
    final scaledRowHeight = MultiMonthGrid.outerCardHeight * scale;

    // Determine target index based on velocity + current position
    final currentIndex = translationY / scaledRowHeight;
    final velocityY = details.velocity.pixelsPerSecond.dy;

    double targetIndex;

    if (velocityY.abs() > 50) {
      // Swipe detected
      if (velocityY < 0) {
        // Swipe Up -> Move down timeline (more negative translation)
        targetIndex = (currentIndex - 0.5).floorToDouble();
      } else {
        // Swipe Down -> Move up timeline (more positive translation)
        targetIndex = (currentIndex + 0.5).ceilToDouble();
      }
    } else {
      // Slow drag: Snap to nearest
      targetIndex = currentIndex.roundToDouble();
    }

    final snappedY = targetIndex * scaledRowHeight;

    // Only snap if there's a meaningful difference
    if ((translationY - snappedY).abs() > 0.5) {
      _isSnappingSheet = false;
      _animateSnap(matrix, matrix.clone()..setEntry(1, 3, snappedY));
    }
  }

  void _animateSnap(Matrix4 from, Matrix4 to) {
    _snapAnimation = Matrix4Tween(begin: from, end: to).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );
    _animationController.forward(from: 0);
  }

  /// Disposes all controllers.
  void dispose() {
    _animationController.dispose();
    pageController.dispose();
    sheetTransformController.dispose();
    gridTransformController.dispose();
  }
}
