import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/features/timeline/timeline_screen_controller.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/view_mode_builders.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_dates.dart';

class TimelineBody extends StatelessWidget {
  final TimelineViewMode viewMode;
  final DateTime earliestMonth;
  final DateTime selectedMonth;
  final TimelineScreenController controller;
  final Function(TimelineViewMode) onViewModeChanged;
  final VoidCallback onJumpToSelectedMonth;

  const TimelineBody({
    super.key,
    required this.viewMode,
    required this.earliestMonth,
    required this.selectedMonth,
    required this.controller,
    required this.onViewModeChanged,
    required this.onJumpToSelectedMonth,
    required this.items,
    required this.sortOrder,
    required this.showCleared,
    required this.settings, // Pass settings explicitly rather than reading from context to avoid issues
  });

  final List<TimelineItem> items;
  final TimelineSortOrder sortOrder;
  final bool showCleared;
  final AppSettingsStore settings;

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.read(context);
    // settings passed in constructor now

    return Expanded(
      child: LayoutBuilder(
        builder: (context, constraints) {
          if (viewMode == TimelineViewMode.month) {
            return NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                // Check if we should randomize on swipe
                if (settings.randomizeColorOnPeriodChange &&
                    notification is ScrollUpdateNotification &&
                    notification.metrics is PageMetrics) {
                  final pageMetrics = notification.metrics as PageMetrics;
                  final page = pageMetrics.page;

                  if (page != null) {
                    final targetIndex = page.round();
                    final targetMonth = monthForPage(
                      controller.monthOrigin,
                      targetIndex,
                      TimelineScreenController.monthOriginPage,
                    );

                    // If we've crossed the threshold to a new month that isn't yet selected
                    if (store.selectedMonth.year != targetMonth.year ||
                        store.selectedMonth.month != targetMonth.month) {
                      // Trigger theme change immediately
                      settings.setRandomTheme();

                      // Update selection immediately to prevent repeated triggers
                      // and to sync the UI state with the visual page
                      store.setSelectedMonth(targetMonth);
                    }
                  }
                }
                return false;
              },
              child: buildMonthView(
                context: context,
                pageController: controller.pageController,
                store: store,
                items: items,
                settings: settings,
                sortOrder: sortOrder,
                monthOrigin: controller.monthOrigin,
                monthOriginPage: TimelineScreenController.monthOriginPage,
                monthWindowSize:
                    monthsBetween(
                      earliestMonth,
                      monthOnly(
                        month_math.addMonths(
                          _maxMonth(
                            _maxMonth(monthOnly(DateTime.now()), selectedMonth),
                            earliestMonth,
                          ),
                          TimelineScreenController.monthOriginPage,
                        ),
                      ),
                    ) +
                    1, // Recomputed here or passed
                showClearedItems: showCleared,
                onPinchOut: () {
                  onViewModeChanged(TimelineViewMode.grid);
                },
                onPageChanged: (index) {
                  final newMonth = monthForPage(
                    controller.monthOrigin,
                    index,
                    TimelineScreenController.monthOriginPage,
                  );

                  // Randomize theme on period change if enabled
                  // Note: This might be redundant if NotificationListener caught it,
                  // but we keep it as a fallback for non-scroll updates (e.g. accessibility actions)
                  if (settings.randomizeColorOnPeriodChange &&
                      (store.selectedMonth.year != newMonth.year ||
                          store.selectedMonth.month != newMonth.month)) {
                    settings.setRandomTheme();
                  }

                  store.setSelectedMonth(newMonth);
                },
                pulseBuilder: (month) =>
                    (month, periodInfo) =>
                        store.pulseForMonth(month, periodInfo: periodInfo),
              ),
            );
          }

          if (viewMode == TimelineViewMode.grid) {
            controller.lastGridViewportWidth = constraints.maxWidth;
            controller.lastGridViewportHeight = constraints.maxHeight;
            controller.ensureInitialGridTransform(
              viewportWidth: constraints.maxWidth,
              viewportHeight: constraints.maxHeight,
              monthsBeforeSelected: month_math.monthsBetween(
                earliestMonth,
                selectedMonth,
              ),
            );

            final gridDimensions = controller.gridDimensionsForViewport(
              viewportWidth: constraints.maxWidth,
              viewportHeight: constraints.maxHeight,
            );

            return buildGridView(
              context: context,
              gridTransformController: controller.gridTransformController,
              store: store,
              items: items,
              settings: settings,
              sortOrder: sortOrder,
              viewportWidth: constraints.maxWidth,
              selectedMonth: selectedMonth,
              gridColumns: gridDimensions.columns,
              showClearedItems: showCleared,
              onInitGridTransform: () {},
              onSnap: controller.snapGridToRow,
              onMonthTapped: (month) {
                store.setSelectedMonth(month);
                onViewModeChanged(TimelineViewMode.month);
                onJumpToSelectedMonth();
              },
              pulseBuilder: (month) =>
                  (month, periodInfo) =>
                      store.pulseForMonth(month, periodInfo: periodInfo),
            );
          }

          controller.lastSheetViewportWidth = constraints.maxWidth;
          // Compute months before selected to set initial scroll position
          final monthsBefore = month_math.monthsBetween(
            earliestMonth,
            selectedMonth,
          );

          // Get dynamic column width based on settings (for showPulseOrigin)
          final dynamicColumnWidth = TimelineSheet.getColumnWidth(settings);

          controller.ensureInitialSheetTransform(
            viewportWidth: constraints.maxWidth,
            monthsBeforeSelected: monthsBefore,
            columnWidth: dynamicColumnWidth,
          );

          final zoomStage = controller.sheetZoomStageForWidth(
            constraints.maxWidth,
            columnWidth: dynamicColumnWidth,
          );
          final baseBalance = settings.timelineUseZeroBaseline
              ? 0
              : settings.currentBalanceCents;

          // Calculate visible months for period-based pagination
          final visibleMonths = controller
              .visibleSheetMonths(
                constraints.maxWidth,
                columnWidth: dynamicColumnWidth,
              )
              .round();

          return buildSheetView(
            context: context,
            sheetTransformController: controller.sheetTransformController,
            store: store,
            items: items,
            settings: settings,
            sortOrder: sortOrder,
            viewportWidth: constraints.maxWidth,
            selectedMonth: selectedMonth,
            zoomStage: zoomStage,
            startingBalanceCents: baseBalance,
            showClearedItems: showCleared,
            onInitSheetTransform: () {},
            onSnap: (details) => controller.snapSheetToGrid(
              details,
              columnWidth: dynamicColumnWidth,
              visibleMonths: visibleMonths,
            ),
            onMonthTapped: (month) {
              store.setSelectedMonth(month);
              onViewModeChanged(TimelineViewMode.month);
              onJumpToSelectedMonth();
            },
            pulseBuilder: (month) =>
                (month, periodInfo) =>
                    store.pulseForMonth(month, periodInfo: periodInfo),
          );
        },
      ),
    );
  }

  // Simplified version of the math needed here
  DateTime _maxMonth(DateTime a, DateTime b) {
    final aMonth = monthOnly(a);
    final bMonth = monthOnly(b);
    return aMonth.isAfter(bMonth) ? aMonth : bMonth;
  }
}
