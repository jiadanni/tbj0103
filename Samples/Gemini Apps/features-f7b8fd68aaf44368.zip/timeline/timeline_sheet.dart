import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/pulse_display.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_helpers.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/display_helpers.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/envelope_logic.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/convert_standalone_pulses.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/pot_projection.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

/// Returns the effective day format, upgrading to month-inclusive formats
/// when the period spans two calendar months.
DayFormat _effectiveDayFormat(DayFormat userFormat, PeriodInfo periodInfo) {
  // If the period doesn't span two months, use the user's preferred format
  if (periodInfo.start.month == periodInfo.end.month &&
      periodInfo.start.year == periodInfo.end.year) {
    return userFormat;
  }

  // Period spans two months - upgrade formats without month info
  switch (userFormat) {
    case DayFormat.ordinal:
      return DayFormat.ordinalMonth;
    case DayFormat.number:
      return DayFormat.numericDayMonth;
    case DayFormat.ordinalMonth:
    case DayFormat.numericMonthDay:
    case DayFormat.numericDayMonth:
      // Already includes month info
      return userFormat;
  }
}

typedef PulsesForMonth = List<PulseEntry> Function(DateTime month);

class TimelineSheet extends StatelessWidget {
  const TimelineSheet({
    super.key,
    required this.months,
    required this.items,
    required this.pulseForMonth,
    required this.currency,
    required this.currentMonth,
    required this.showClearedForCurrentMonth,
    required this.recentlyClearedItemIds,
    required this.startingBalanceCents,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    this.showFooters = true,
    this.onMonthTapped,
    this.viewportHeight,
    this.showHeaders = true,
  });

  final List<DateTime> months;
  final List<TimelineItem> items;
  final PulsesForMonth pulseForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final bool showClearedForCurrentMonth;
  final Set<String> recentlyClearedItemIds;
  final int startingBalanceCents;
  final GridZoomStage zoomStage;
  final TimelineSortOrder sortOrder;
  final DayFormat dayFormat;
  final PulseDisplayMode displayMode;
  final AppSettingsStore settings;
  final bool showFooters;
  final void Function(DateTime month)? onMonthTapped;
  final double? viewportHeight;
  final bool showHeaders;

  static const double _kDayWidth = 28;
  static const double _kMinLabelWidth = 80;
  static const double _kExpandedLabelWidth = 140;
  static const double _kAmountWidth = 74;
  static const double _kRowHeight = 28;
  static const double _kColumnPadding = 6;

  /// Default column width for zoom calculations (uses minimum label width).
  /// This is used by TimelineScreenController for consistent zoom behavior.
  static const double columnWidth =
      _kDayWidth + _kMinLabelWidth + _kAmountWidth + _kColumnPadding * 2;

  static double getDayColumnWidth(DayFormat format) {
    switch (format) {
      case DayFormat.number:
        return 28.0;
      case DayFormat.ordinal:
        return 38.0;
      case DayFormat.numericMonthDay:
      case DayFormat.numericDayMonth:
        return 44.0;
      case DayFormat.ordinalMonth:
        return 56.0;
    }
  }

  /// Calculates the column width based on settings.
  static double getColumnWidth(AppSettingsStore settings) {
    final dayWidth = getDayColumnWidth(settings.dayFormat);
    final labelWidth =
        settings.getTimelineShowPulseOrigin(TimelineViewMode.sheet)
        ? _kExpandedLabelWidth
        : _kMinLabelWidth;
    return dayWidth + labelWidth + _kAmountWidth + _kColumnPadding * 2;
  }

  static double getRowHeight(GridZoomStage stage) {
    switch (stage) {
      case GridZoomStage.sixMonths:
        return 36;
      case GridZoomStage.fourMonths:
        return 32;
      case GridZoomStage.twoMonths:
        return _kRowHeight;
    }
  }

  @override
  Widget build(BuildContext context) {
    final rowHeight = getRowHeight(zoomStage);
    final border = BorderSide.none;

    final labelWidth =
        settings.getTimelineShowPulseOrigin(TimelineViewMode.sheet)
        ? _kExpandedLabelWidth
        : _kMinLabelWidth;
    final columnWidth =
        _kDayWidth + labelWidth + _kAmountWidth + _kColumnPadding * 2;

    final width = months.length * columnWidth;

    final normalizedCurrent = monthOnly(currentMonth);
    final currentIndex = months.indexWhere(
      (month) => monthOnly(month) == normalizedCurrent,
    );
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;

    // Cache pulse and period info for each month to avoid redundant lookups/calculations
    final cachedPulses = List<List<PulseEntry>>.filled(months.length, const []);
    final cachedPeriodInfos = List<PeriodInfo?>.filled(months.length, null);
    final cachedItems = List<List<TimelineItem>>.filled(
      months.length,
      const [],
    );

    final monthTotals = <int>[];
    for (var i = 0; i < months.length; i++) {
      final month = months[i];
      final monthPulses = pulseForMonth(month);
      cachedPulses[i] = monthPulses;

      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
        includeMonth: settings.paycheckShowMonthInTimeline,
      );
      cachedPeriodInfos[i] = periodInfo;

      final isCurrent = monthOnly(month) == normalizedCurrent;

      // Merge registered items with any standalone/orphaned pulses in this month
      final mergedItems = mergeItemsWithStandalonePulses(
        items,
        monthPulses,
        month,
      );
      cachedItems[i] = mergedItems;

      // Use a quicker lookup for totals calculation as well
      // ignore: unused_local_variable
      final pulseMap = buildPulseLookupMap(monthPulses);

      // Compute net change for propagation using common helper
      final netChange = calculateTotalNetChangeForPeriod(
        month: month,
        items: mergedItems,
        pulses: monthPulses,
        periodInfo: periodInfo,
        isCurrentPeriod: isCurrent,
        settings: settings,
        pulseMap: pulseMap,
      );

      monthTotals.add(netChange);
    }

    final double height;
    final int maxRowCount;
    final pots = settings.moneyPots.take(3).toList(); // Ensure consistency

    if (viewportHeight != null) {
      height = viewportHeight!;
      maxRowCount = 0; // Not used when using list view
    } else {
      // Calculate visible row count for each month to determine max for alignment
      final visibleRowCounts = <int>[];
      for (var i = 0; i < months.length; i++) {
        final month = months[i];

        final showClearedForMonth = showClearedForCurrentMonth;

        var rowCount = 0;
        final periodInfo = cachedPeriodInfos[i];
        final pulseMap = buildPulseLookupMap(cachedPulses[i]);

        for (final item in cachedItems[i].where(
          (item) => PaycheckService.shouldItemAppearInPeriod(
            item,
            periodInfo!,
            month,
          ),
        )) {
          final isCleared =
              findPulseWithMap(
                item: item,
                pulseMap: pulseMap,
                month: month,
                settings: settings,
                periodInfo: periodInfo!,
              ) !=
              null;
          if (!showClearedForMonth &&
              isCleared &&
              !recentlyClearedItemIds.contains(item.id) &&
              item.type != PulseType.spendingEnvelope) {
            continue;
          }
          rowCount++;
        }

        if (settings.timelineGroupByDate) {
          // Estimate group headers
          rowCount += (rowCount > 0 ? (rowCount ~/ 2) : 0);
        }

        visibleRowCounts.add(rowCount);
      }

      maxRowCount = visibleRowCounts.isEmpty
          ? 0
          : visibleRowCounts.reduce((a, b) => a > b ? a : b);

      final potsCount = pots.length;
      final hasPots = potsCount > 0;
      final staticRows =
          (hasPots ? potsCount + 1 : 0) +
          6; // 1 (month header) + 5 (footer rows)
      final totalRowCount = maxRowCount + staticRows;
      height = totalRowCount * rowHeight;
    }

    final startBalances = List<int>.filled(months.length, 0);
    final cumulativeBalances = List<int>.filled(months.length, 0);

    var runningBalance = startingBalanceCents;

    for (var i = 0; i < months.length; i++) {
      if (i < baseIndex) {
        startBalances[i] = 0;
        cumulativeBalances[i] = monthTotals[i];
      } else if (i == baseIndex) {
        startBalances[i] = startingBalanceCents;
        cumulativeBalances[i] = startingBalanceCents + monthTotals[i];
        runningBalance = cumulativeBalances[i];
      } else {
        startBalances[i] = runningBalance;
        cumulativeBalances[i] = runningBalance + monthTotals[i];
        runningBalance = cumulativeBalances[i];
      }
    }

    // Project Money Pot balances across all months
    final initialPots = settings.moneyPots;
    final projectedPots = projectMoneyPotBalances(
      initialPots: initialPots,
      months: months,
      items: items,
      pulseForMonth: pulseForMonth,
      settings: settings,
      currentMonth: currentMonth,
    );

    return Material(
      color: Theme.of(context).colorScheme.surface,
      child: SizedBox(
        width: width,
        height: height,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (int i = 0; i < months.length; i++)
              RepaintBoundary(
                child: MonthSheetColumn(
                  month: months[i],
                  items: cachedItems[i],
                  pulses: cachedPulses[i],
                  periodInfo: cachedPeriodInfos[i]!,
                  currency: currency,
                  border: border,
                  dayWidth: _kDayWidth,
                  labelWidth: labelWidth,
                  amountWidth: _kAmountWidth,
                  rowHeight: rowHeight,
                  columnPadding: _kColumnPadding,
                  isFirst: i == 0,
                  showCleared: showClearedForCurrentMonth,
                  recentlyClearedItemIds: recentlyClearedItemIds,
                  zoomStage: zoomStage,
                  sortOrder: sortOrder,
                  dayFormat: dayFormat,
                  displayMode: displayMode,
                  settings: settings,
                  currentPeriodMonth: currentMonth,
                  isFirstColumn: i == 0,
                  startBalanceCents: startBalances[i],
                  netTotalCents: monthTotals[i],
                  cumulativeBalanceCents: cumulativeBalances[i],
                  targetRowCount: maxRowCount,
                  showFooters: showFooters,
                  onTapped: onMonthTapped,
                  moneyPots: showHeaders
                      ? projectedPots[i].take(3).toList()
                      : const [],
                  useListView: viewportHeight != null,
                  showHeaders: showHeaders,
                ),
              ),
          ],
        ),
      ),
    );
  }

  // Using shared helpers from timeline_actions.dart:
  // - buildPulseLookupMap (replaces _buildPulseMap)
  // - findPulseWithMap (replaces _findPulseWithMap)
}

class MonthSheetColumn extends StatelessWidget {
  const MonthSheetColumn({
    super.key,
    required this.month,
    required this.items,
    required this.pulses,
    required this.periodInfo,
    required this.currency,
    required this.border,
    required this.dayWidth,
    required this.labelWidth,
    required this.amountWidth,
    required this.rowHeight,
    required this.columnPadding,
    required this.isFirst,
    required this.showCleared,
    required this.recentlyClearedItemIds,
    required this.zoomStage,
    required this.sortOrder,
    required this.dayFormat,
    required this.displayMode,
    required this.settings,
    required this.currentPeriodMonth,
    required this.isFirstColumn,
    required this.startBalanceCents,
    required this.netTotalCents,
    required this.cumulativeBalanceCents,
    required this.targetRowCount,
    this.showFooters = true,
    this.onTapped,
    this.moneyPots = const [],
    this.useListView = false,
    this.showHeaders = true,
  });

  final List<MoneyPot> moneyPots;

  final DateTime month;
  final List<TimelineItem> items;
  final List<PulseEntry> pulses;
  final PeriodInfo periodInfo;
  final AppCurrency currency;
  final BorderSide border;
  final double dayWidth;
  final double labelWidth;
  final double amountWidth;
  final double rowHeight;
  final double columnPadding;
  final bool isFirst;
  final bool showCleared;
  final Set<String> recentlyClearedItemIds;
  final GridZoomStage zoomStage;
  final TimelineSortOrder sortOrder;
  final DayFormat dayFormat;
  final void Function(DateTime month)? onTapped;
  final PulseDisplayMode displayMode;
  final AppSettingsStore settings;
  final DateTime currentPeriodMonth;
  final bool isFirstColumn;
  final int startBalanceCents;
  final int netTotalCents;
  final int cumulativeBalanceCents;
  final int targetRowCount;
  final bool showFooters;
  final bool useListView;
  final bool showHeaders;

  /// Builds the display label with optional company suffix.
  String _buildDisplayLabel(String baseLabel, TimelineItem item) {
    if (settings.getTimelineShowPulseOrigin(TimelineViewMode.sheet) &&
        item.origin != null &&
        item.origin!.isNotEmpty) {
      return '$baseLabel (${item.origin})';
    }
    return baseLabel;
  }

  @override
  Widget build(BuildContext context) {
    final monthNormalized = monthOnly(month);
    final isPast = monthNormalized.isBefore(currentPeriodMonth);
    final isCurrent =
        monthNormalized.year == currentPeriodMonth.year &&
        monthNormalized.month == currentPeriodMonth.month;

    // When paycheck period spans two months, auto-upgrade day format to include month
    // so users can distinguish which month each transaction belongs to.
    final effectiveDayFormat = _effectiveDayFormat(dayFormat, periodInfo);

    final rows = _buildRows(
      periodInfo: periodInfo,
      items: items, // Using instance field items
      month: month,
      settings: settings,
      sortOrder: sortOrder,
      showCleared: showCleared,
      recentlyClearedItemIds: recentlyClearedItemIds,
      dayFormat: effectiveDayFormat,
    );
    final headerLabel =
        settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured
        ? periodInfo.label
        : gridHeaderLabel(month, zoomStage, Localizations.localeOf(context));

    final totalColumnWidth =
        dayWidth + labelWidth + amountWidth + columnPadding * 2;
    final dividerColor = Theme.of(
      context,
    ).colorScheme.outlineVariant.withValues(alpha: 0.3);

    final headerBackground = isPast
        ? Theme.of(context).colorScheme.surfaceContainerLow
        : Theme.of(context).colorScheme.surfaceContainerHighest;
    final headerStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      fontFeatures: const [FontFeature.tabularFigures()],
      fontSize: 12,
      fontWeight: FontWeight.w600,
    );
    final dayStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontFeatures: const [FontFeature.tabularFigures()],
    );
    final labelStyle = Theme.of(context).textTheme.bodySmall;
    final amountStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
      fontFeatures: const [FontFeature.tabularFigures()],
    );
    final endLabel = settings.viewPeriodMode == ViewPeriodMode.paycheck
        ? 'EOP'
        : 'EOM';

    // Prepare display items
    final displayItems = _prepareDisplayItems(
      rows: rows,
      periodInfo: periodInfo,
      isCurrent: isCurrent,
    );

    Widget buildDisplayItem(_SheetDisplayItem item) {
      if (item is _SheetRowItem) {
        return _buildRowWidget(
          context,
          row: item.row,
          isCurrent: isCurrent,
          isPast: isPast,
          totalColumnWidth: totalColumnWidth,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          dayWidth: dayWidth,
          amountWidth: amountWidth,
          dividerColor: dividerColor,
          dayStyle: dayStyle,
          labelStyle: labelStyle,
          amountStyle: amountStyle,
          showDay: item.showDay,
          isGroupStart: false,
        );
      } else if (item is _SheetGroupHeaderItem) {
        return Container(
          width: totalColumnWidth,
          height: rowHeight * 0.7,
          padding: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: Theme.of(
              context,
            ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
            border: Border(
              bottom: BorderSide(
                color: dividerColor.withValues(alpha: 0.3),
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            children: [
              Text(
                formatDayOfMonth(
                  DateTime(month.year, month.month, item.day),
                  item.dayFormat,
                ),
                style: dayStyle?.copyWith(
                  fontWeight: FontWeight.w600,
                  fontSize: 11,
                ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Container(
                  height: 0.5,
                  color: dividerColor.withValues(alpha: 0.3),
                ),
              ),
            ],
          ),
        );
      } else if (item is _SheetBudgetHeaderItem) {
        return InkWell(
          onTap: () {
            settings.envelopesSectionCollapsed =
                !settings.envelopesSectionCollapsed;
          },
          child: Container(
            width: totalColumnWidth,
            height: rowHeight,
            padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
            alignment: Alignment.centerLeft,
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
              border: Border(
                bottom: BorderSide(
                  color: dividerColor.withValues(alpha: 0.1),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'BUDGETS',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.0,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                if (item.isCurrent && item.isFirstColumn)
                  Icon(
                    item.isCollapsed ? Icons.expand_more : Icons.expand_less,
                    size: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              ],
            ),
          ),
        );
      } else if (item is _SheetMonthHeaderItem) {
        return _buildMonthHeader(context, item, totalColumnWidth, dividerColor);
      }
      return const SizedBox.shrink();
    }

    // BUDGETS Section logic moved to _prepareDisplayItems

    // Header Widget
    Widget headerWidget = Container(
      width: totalColumnWidth,
      height: rowHeight,
      padding: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: headerBackground,
        border: Border(bottom: BorderSide(color: dividerColor, width: 1)),
      ),
      alignment: Alignment.center,
      child: isCurrent
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                headerLabel,
                style: headerStyle?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            )
          : Padding(
              padding: EdgeInsets.symmetric(horizontal: columnPadding - 2),
              child: Text(
                headerLabel,
                style: headerStyle,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
    );

    // Add tap if needed
    if (onTapped != null) {
      headerWidget = GestureDetector(
        onLongPress: () {
          HapticFeedback.selectionClick();
          onTapped!(month);
        },
        child: headerWidget,
      );
    }

    final containerDecoration = BoxDecoration(
      color: isCurrent
          ? (Theme.of(context).brightness == Brightness.dark
                ? Colors.teal.withValues(alpha: 0.1)
                : Colors.teal.withValues(alpha: 0.05))
          : null,
      border: Border(
        left: isFirst
            ? BorderSide.none
            : BorderSide(
                color: Theme.of(
                  context,
                ).colorScheme.outline.withValues(alpha: 0.4),
                width: 2,
              ),
      ),
    );

    if (useListView) {
      // --- ListView Mode (Scrolling) ---
      return Container(
        width: totalColumnWidth,
        decoration: containerDecoration,
        child: Column(
          children: [
            // Header & Pots (if showHeaders is true)
            if (showHeaders) ...[
              headerWidget,
              if (moneyPots.isNotEmpty) ...[
                Container(
                  width: totalColumnWidth,
                  height: rowHeight,
                  padding: const EdgeInsets.symmetric(
                    vertical: 2,
                    horizontal: 8,
                  ),
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.3),
                    border: Border(
                      bottom: BorderSide(
                        color: dividerColor.withValues(alpha: 0.1),
                        width: 0.5,
                      ),
                    ),
                  ),
                  child: Text(
                    Terminology.of(context).potsLabel.toUpperCase(),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.0,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                for (final pot in moneyPots) _buildPotRow(context, pot),
              ],
            ],

            // List
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: displayItems.length + 1, // +1 for bottom padding
                itemBuilder: (context, index) {
                  if (index == displayItems.length) {
                    return SizedBox(height: rowHeight);
                  }
                  return buildDisplayItem(displayItems[index]);
                },
              ),
            ),

            // Footers
            if (showFooters) ...[
              _buildFooter(
                context,
                headerBackground,
                dividerColor,
                endLabel,
                totalColumnWidth,
              ),
            ],
          ],
        ),
      );
    }

    // --- Original Static Layout Mode ---
    final content = Container(
      width: totalColumnWidth,
      decoration: containerDecoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          headerWidget,
          // Data rows
          ...displayItems.map(buildDisplayItem),
          // Spacer
          const Spacer(),
          // Money Pots section (compact)
          if (moneyPots.isNotEmpty) ...[
            Container(
              width: totalColumnWidth,
              height: rowHeight,
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                border: Border(
                  bottom: BorderSide(
                    color: dividerColor.withValues(alpha: 0.1),
                    width: 0.5,
                  ),
                ),
              ),
              child: Text(
                Terminology.of(context).potsLabel.toUpperCase(),
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            for (final pot in moneyPots) _buildPotRow(context, pot),
          ],
          if (showFooters) ...[
            _buildFooter(
              context,
              headerBackground,
              dividerColor,
              endLabel,
              totalColumnWidth,
            ),
          ] else ...[
            SizedBox(height: rowHeight * 5),
          ],
        ],
      ),
    );

    // Tap to navigate to month view (only wraps content in non-ListView mode, logic slightly duplicative but safe)
    // Wait, I wrapped headerWidget above if onTapped != null.
    // In original code, the WHOLE COLUMN was tappable via 'content'.
    // In ListView mode, we probably only want header tappable (which I did).
    // In Static mode, let's keep original behavior:

    // Actually, original: `final tappable = GestureDetector(onLongPress: ... child: content)`.

    final tappable = GestureDetector(
      onLongPress: onTapped != null
          ? () {
              HapticFeedback.selectionClick();
              onTapped!(month);
            }
          : null,
      child: content,
    );

    if (!isPast) return tappable;
    return Opacity(opacity: 0.62, child: tappable);
  }

  // Refactor Footer Building to reuse
  Widget _buildFooter(
    BuildContext context,
    Color headerBackground,
    Color dividerColor,
    String endLabel,
    double totalColumnWidth,
  ) {
    return Column(
      children: [
        _FooterRow(
          date: month,
          label: Terminology.of(context).startLabel,
          value: formatMoneyFromCents(
            startBalanceCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: startBalanceCents < 0
              ? settings.debitColor
              : startBalanceCents > 0
              ? settings.creditColor
              : null,
          onTap: () {
            settings.timelineUseZeroBaseline =
                !settings.timelineUseZeroBaseline;
          },
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: headerBackground,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: Terminology.of(context).creditsLabel,
          value: formatMoneyFromCents(
            0,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: settings.creditColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: headerBackground,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: Terminology.of(context).debitsLabel,
          value: formatMoneyFromCents(
            0,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: settings.debitColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: headerBackground,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: endLabel,
          value: formatMoneyFromCents(
            netTotalCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: netTotalCents < 0
              ? settings.debitColor
              : netTotalCents > 0
              ? settings.creditColor
              : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: headerBackground,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: '$endLabel(C)',
          value: isFirstColumn
              ? ''
              : formatMoneyFromCents(
                  cumulativeBalanceCents,
                  currency,
                  showCents: settings.showCents,
                ),
          valueColor: cumulativeBalanceCents < 0
              ? settings.debitColor
              : cumulativeBalanceCents > 0
              ? settings.creditColor
              : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: headerBackground,
          dividerColor: dividerColor,
        ),
      ],
    );
  }

  Widget _buildPotRow(BuildContext context, MoneyPot pot) {
    final displayColor = pot.type == MoneyPotType.savings
        ? settings.creditColor
        : settings.debitColor;

    // Pot projection logic simplified for sheet view
    final amount = pot.amountMinorUnits;

    return Container(
      width: labelWidth + amountWidth + dayWidth + columnPadding * 2,
      height: rowHeight,
      padding: EdgeInsets.symmetric(horizontal: columnPadding),
      child: Row(
        children: [
          const SizedBox(width: 22), // Same as _kDayWidth
          Expanded(
            child: Text(
              pot.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          Text(
            formatMoneyFromCents(
              amount,
              currency,
              showCents: settings.showCents,
            ),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              fontFeatures: const [FontFeature.tabularFigures()],
              color: displayColor,
            ),
          ),
        ],
      ),
    );
  }

  List<_SheetDisplayItem> _prepareDisplayItems({
    required List<_SheetRow> rows,
    required PeriodInfo periodInfo,
    required bool isCurrent,
  }) {
    final regularRows = rows
        .where((r) => r.item.type != PulseType.spendingEnvelope)
        .toList();
    final budgetRows = rows
        .where((r) => r.item.type == PulseType.spendingEnvelope)
        .toList();

    final items = <_SheetDisplayItem>[];

    // Check if we should insert month headers (Paycheck mode)
    // Only show inline headers if:
    // 1. Paycheck mode is configured (headers needed to separate splits)
    // 2. AND the period actually spans across month boundaries (otherwise the single column header is sufficient)
    //    If start/end are in same month/year, it's a single month period -> duplicates column header.
    final bool spansMonths =
        periodInfo.start.month != periodInfo.end.month ||
        periodInfo.start.year != periodInfo.end.year;

    final bool showMonthHeaders =
        settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured &&
        spansMonths;

    int? lastMonth;

    // 1. Regular Rows
    if (!settings.timelineGroupByDate) {
      // Flat list
      for (final row in regularRows) {
        if (showMonthHeaders) {
          final rowMonth = row.date.month;
          if (lastMonth != null && lastMonth != rowMonth) {
            items.add(_SheetMonthHeaderItem(row.date));
          }
          lastMonth = rowMonth;
        }
        items.add(_SheetRowItem(row, showDay: true));
      }
    } else {
      // Grouped list
      final groups = <int, List<_SheetRow>>{};
      for (final row in regularRows) {
        // Use effective day for grouping to match existing logic,
        // but remember we might want the actual date for headers.
        // The `row.date` should already be the effective date from `_buildRows`.
        final dayNum = row.date.day;
        (groups[dayNum] ??= []).add(row);
      }

      final sortedDays = groups.keys.toList();
      sortedDays.sort((a, b) {
        final aSortValue = daySortValue(
          a,
          viewMode: settings.viewPeriodMode,
          periodInfo: periodInfo,
        );
        final bSortValue = daySortValue(
          b,
          viewMode: settings.viewPeriodMode,
          periodInfo: periodInfo,
        );
        return sortOrder == TimelineSortOrder.chronological
            ? aSortValue.compareTo(bSortValue)
            : bSortValue.compareTo(aSortValue);
      });

      for (final day in sortedDays) {
        final groupItems = groups[day]!;
        final firstItem = groupItems.first;

        if (showMonthHeaders) {
          final groupMonth = firstItem.date.month;
          if (lastMonth != null && lastMonth != groupMonth) {
            items.add(_SheetMonthHeaderItem(firstItem.date));
          }
          lastMonth = groupMonth;
        }

        if (groupItems.length > 1) {
          items.add(_SheetGroupHeaderItem(day, dayFormat));
          for (final row in groupItems) {
            items.add(_SheetRowItem(row, showDay: false));
          }
        } else {
          items.add(_SheetRowItem(groupItems.first, showDay: true));
        }
      }
    }

    // 2. Budgets Section
    if (budgetRows.isNotEmpty) {
      items.add(
        _SheetBudgetHeaderItem(
          isCollapsed: settings.envelopesSectionCollapsed,
          isFirstColumn: isFirstColumn,
          isCurrent: isCurrent,
        ),
      );

      if (!settings.envelopesSectionCollapsed) {
        for (final row in budgetRows) {
          items.add(_SheetRowItem(row, showDay: false));
        }
      }
    }

    return items;
  }

  Widget _buildRowWidget(
    BuildContext context, {
    required _SheetRow row,
    required bool isCurrent,
    required bool isPast,
    required double totalColumnWidth,
    required double rowHeight,
    required double columnPadding,
    required double dayWidth,
    required double amountWidth,
    required Color dividerColor,
    required TextStyle? dayStyle,
    required TextStyle? labelStyle,
    required TextStyle? amountStyle,
    required bool showDay,
    required bool isGroupStart,
  }) {
    final isMuted = row.isCleared && isCurrent;

    // We want the row to be interactive
    Offset? lastTapPosition;

    void handleTap() {
      // Respect tap action setting
      // FIX: If item is already cleared (including virtual items), show menu instead of archive action
      if (settings.timelineTapAction == TimelineTapAction.archive &&
          !row.isCleared) {
        handleItemAction(context, row.item, TimelineSwipeAction.archive);
      } else {
        // Calculate isCurrentPeriod for canArchive
        final nowMonthOnly = monthOnly(DateTime.now());
        DateTime currentPeriodMonth;
        if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured) {
          currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
            DateTime.now(),
            settings.paycheckDay!,
            businessAdjust: settings.paycheckBusinessAdjust,
            adjustDirection: settings.paycheckBusinessAdjustDirection,
          );
        } else {
          currentPeriodMonth = nowMonthOnly;
        }
        final isCurrentPeriod =
            month.year == currentPeriodMonth.year &&
            month.month == currentPeriodMonth.month;

        // Show the menu for this item
        showTimelineItemMenu(
          context: context,
          item: row.item,
          month: month,
          position: lastTapPosition ?? Offset.zero,
          canArchive: isCurrentPeriod,
          pulse: row.pulse,
        );
      }
    }

    return Opacity(
      opacity: isPast ? 0.5 : (isMuted ? 0.5 : 1.0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTapDown: (details) => lastTapPosition = details.globalPosition,
          onTap: handleTap,
          child: Container(
            width: totalColumnWidth,
            height: rowHeight,
            padding: EdgeInsets.symmetric(horizontal: columnPadding),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: dividerColor.withValues(alpha: 0.15),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                // Day (only if showDay is true)
                if (showDay)
                  SizedBox(
                    width: dayWidth,
                    child: Text(
                      row.day,
                      style: dayStyle,
                      textAlign: TextAlign.left,
                    ),
                  ),
                // Label - use Expanded to prevent overflow
                Expanded(
                  child: displayMode == PulseDisplayMode.icon
                      ? Icon(
                          getPulseIcon(
                            row.label,
                            type: row.item.type,
                            categoryIcons: settings.categoryIcons,
                          ),
                          size: 14,
                          color: isPast
                              ? Theme.of(context).colorScheme.onSurfaceVariant
                              : Theme.of(context).colorScheme.onSurface,
                        )
                      : displayMode == PulseDisplayMode.acronym
                      ? Text(
                          _buildDisplayLabel(
                            generateAcronym(row.label),
                            row.item,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.clip,
                          style: labelStyle?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: isPast
                                ? Theme.of(context).colorScheme.onSurfaceVariant
                                : Theme.of(context).colorScheme.onSurface,
                          ),
                        )
                      : Text(
                          _buildDisplayLabel(row.label, row.item),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: isPast
                              ? labelStyle?.copyWith(
                                  color: Theme.of(
                                    context,
                                  ).colorScheme.onSurfaceVariant,
                                )
                              : labelStyle,
                        ),
                ),
                // Amount
                SizedBox(
                  width: amountWidth,
                  child: Text(
                    formatMoneyFromCents(
                      row.amountMinorUnits,
                      currency,
                      showCents: settings.showCents,
                    ),
                    textAlign: TextAlign.right,
                    style: amountStyle?.copyWith(
                      color: row.item.type.isIncomeType
                          ? settings.creditColor
                          : settings.debitColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<_SheetRow> _buildRows({
    required PeriodInfo periodInfo,
    required List<TimelineItem> items,
    required DateTime month,
    required AppSettingsStore settings,
    required TimelineSortOrder sortOrder,
    required bool showCleared,
    required Set<String> recentlyClearedItemIds,
    required DayFormat dayFormat,
  }) {
    // Build a fast lookup map for pulse
    final pulseMap = <String, List<PulseEntry>>{};
    final fuzzyCandidates = <PulseEntry>[];
    for (final pulse in pulses) {
      if (pulse.timelineItemId != null) {
        (pulseMap[pulse.timelineItemId!] ??= []).add(pulse);
      } else {
        fuzzyCandidates.add(pulse);
      }
    }

    PulseEntry? pulseFor(TimelineItem item) {
      // Check explicit matches first (O(1) lookup + small iteration)
      final explicitMatches = pulseMap[item.id];
      PulseEntry? best;

      if (explicitMatches != null) {
        for (final pulse in explicitMatches) {
          if (!pulseMatchesTimelineItem(
            pulse,
            item,
            month,
            settings,
            precomputedPeriodInfo: periodInfo,
          )) {
            continue;
          }
          if (best == null || pulse.date.isAfter(best.date)) best = pulse;
        }
      }

      // If no explicit match found, check fuzzy candidates
      // Note: If distinct items, we might want to check fuzzy even if explicit found?
      // Current logic assumes if explicit exists, we use it? No, existing logic checked ALL.
      // But typically explicit is better.
      // The original code checked ALL pulse and found the 'best' (by date).
      // However, it's highly unlikely one item has both explicit and fuzzy matches in same month.
      // Safe optimization: check fuzzy only if no best yet, OR if we want to be 100% equivalent (check both).
      // Given performance goals, let's assume explicit links take precedence or at least are sufficient if found.
      // But to be safe and match `pulseMatchesTimelineItem` logic (which prioritizes explicit),
      // we should still check fuzzy.

      if (fuzzyCandidates.isNotEmpty) {
        for (final pulse in fuzzyCandidates) {
          if (!pulseMatchesTimelineItem(
            pulse,
            item,
            month,
            settings,
            precomputedPeriodInfo: periodInfo,
          )) {
            continue;
          }
          if (best == null || pulse.date.isAfter(best.date)) best = pulse;
        }
      }

      return best;
    }

    final rows = <_SheetRow>[];
    // Filter items to only those that should appear in this month
    final monthItems = items
        .where(
          (item) =>
              PaycheckService.shouldItemAppearInPeriod(item, periodInfo, month),
        )
        .toList(growable: false);
    final sortedItems = orderedTimelineItems(
      monthItems,
      sortOrder,
      dateSortMode: settings.timelineDateSortMode,
      viewMode: settings.viewPeriodMode,
      periodInfo: periodInfo,
      actualDateProvider: (item) => pulseFor(item)?.date,
    );
    for (final item in sortedItems) {
      final pulse = pulseFor(item);
      final displayValues = getDisplayValues(
        item: item,
        month: month,
        pulse: pulse,
        periodInfo: periodInfo,
      );
      final isCleared = pulse != null;
      final isSkipped = item.isSkippedInMonth(month);

      if (isSkipped && !settings.timelineShowSkippedItems) {
        continue;
      }

      if (!showCleared &&
          isCleared &&
          !recentlyClearedItemIds.contains(item.id) &&
          item.type != PulseType.spendingEnvelope) {
        continue;
      }

      int amountMinorUnits = displayValues.amountMinorUnits;
      if (item.type == PulseType.spendingEnvelope) {
        final period = SpendingEnvelopeService.getEnvelopePeriodDates(
          item,
          month,
          settings,
        );
        final spent = SpendingEnvelopeService.getSpentAmountForPeriod(
          item,
          pulses,
          period,
        );
        final budget = item.getAmountForDate(period.$2).abs();
        final isCurrent = monthOnly(month) == monthOnly(currentPeriodMonth);
        final useActuals = SpendingEnvelopeService.isUsingActuals(
          item,
          isCurrent,
          settings,
        );

        if (useActuals) {
          amountMinorUnits = spent;
        } else {
          // If not using actuals, show the reserved budget OR the actual spent if it exceeds budget
          // This addresses user confusion when they overspend a budget (especially a $0 one).
          amountMinorUnits = spent > budget ? spent : budget;
        }
      }

      rows.add(
        _SheetRow(
          day: item.type == PulseType.spendingEnvelope
              ? '—'
              : formatDayOfMonth(displayValues.date, dayFormat),
          date: displayValues.date,
          label: item.label,
          amountMinorUnits: amountMinorUnits,
          isCleared: isCleared,
          item: item,
          pulse: pulse,
        ),
      );
    }
    return rows;
  }
}

class _SheetRow {
  const _SheetRow({
    required this.day,
    required this.date,
    required this.label,
    required this.amountMinorUnits,
    required this.isCleared,
    required this.item,
    this.pulse,
  });

  final String day;
  final DateTime date;
  final String label;
  final int amountMinorUnits;
  final bool isCleared;
  final TimelineItem item;
  final PulseEntry? pulse;
}

class _FooterRow extends StatelessWidget {
  const _FooterRow({
    required this.label,
    required this.value,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    this.valueColor,
    this.onTap,
    required this.date,
  });

  final DateTime date;
  final String label;
  final String value;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final Color? valueColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.labelMedium?.copyWith(
      fontFeatures: const [FontFeature.tabularFigures()],
      fontSize: 12,
      fontWeight: FontWeight.w600,
    );

    Widget row = Container(
      width: totalColumnWidth,
      height: rowHeight,
      padding: EdgeInsets.symmetric(horizontal: columnPadding),
      decoration: BoxDecoration(
        color: background,
        border: Border(top: BorderSide(color: dividerColor, width: 1)),
      ),
      child: Row(
        children: [
          // Fixed-width label for consistent alignment
          SizedBox(
            width: 60,
            child: Text(
              label,
              style: style,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Right-aligned value takes remaining space
          Expanded(
            child: Text(
              value,
              style: style?.copyWith(color: valueColor),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(onTap: onTap, child: row),
      );
    }
    return row;
  }
}

/// A fixed footer row widget that displays Start, End, and End(C) values for all months.
/// This is used as a fixed overlay at the bottom of the sheet view.
class SheetFooterRow extends StatelessWidget {
  const SheetFooterRow({
    super.key,
    required this.months,
    required this.items,
    required this.pulseForMonth,
    required this.currency,
    required this.currentMonth,
    required this.startingBalanceCents,
    required this.zoomStage,
    required this.settings,
  });

  final List<DateTime> months;
  final List<TimelineItem> items;
  final PulsesForMonth pulseForMonth;
  final AppCurrency currency;
  final DateTime currentMonth;
  final int startingBalanceCents;
  final GridZoomStage zoomStage;
  final AppSettingsStore settings;

  /// Default column width (matching TimelineSheet).
  static const double columnWidth = TimelineSheet.columnWidth;

  /// Calculates the column width based on settings (matching TimelineSheet).
  static double getColumnWidth(AppSettingsStore settings) =>
      TimelineSheet.getColumnWidth(settings);

  static double getRowHeight(GridZoomStage stage) =>
      TimelineSheet.getRowHeight(stage);

  static double getFooterHeight(
    GridZoomStage stage,
    AppSettingsStore settings,
  ) {
    final rowHeight = getRowHeight(stage);
    double height = rowHeight * 5; // Start, Credits, Debits, End, End(C)

    final potsCount = settings.moneyPots.length;
    if (potsCount > 0) {
      height += rowHeight; // POTS Label
      if (settings.moneyPotsSectionCollapsed != true) {
        height += potsCount * rowHeight;
      }
    }
    return height;
  }

  @override
  Widget build(BuildContext context) {
    final rowHeight = getRowHeight(zoomStage);

    final normalizedCurrent = monthOnly(currentMonth);
    final currentIndex = months.indexWhere(
      (month) => monthOnly(month) == normalizedCurrent,
    );
    final baseIndex = currentIndex >= 0 ? currentIndex : 0;

    final footerHeight = getFooterHeight(zoomStage, settings);

    // Calculate totals for each month (same logic as TimelineSheet)
    final monthNetChanges = <int>[];
    final monthCredits = <int>[];
    final monthDebits = <int>[];

    for (var i = 0; i < months.length; i++) {
      final month = months[i];
      final monthPulses = pulseForMonth(month);
      final isCurrent = monthOnly(month) == normalizedCurrent;

      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
        includeMonth: settings.paycheckShowMonthInTimeline,
      );

      // Use optimized lookup map like TimelineSheet
      final pulseMap = <String, List<PulseEntry>>{};
      for (final pulse in monthPulses) {
        if (pulse.timelineItemId != null) {
          (pulseMap[pulse.timelineItemId!] ??= []).add(pulse);
        } else {
          (pulseMap[''] ??= []).add(pulse);
        }
      }

      var credits = 0;
      var debits = 0;

      // We still need to split credits/debits for the footer columns
      // Filter items that should appear in this period
      final periodItems = items.where(
        (item) => PaycheckService.shouldItemAppearInPeriod(
          item,
          periodInfo,
          month,
          ignoreSkips: true,
        ),
      );

      for (final item in periodItems) {
        if (item.id.value.startsWith('virtual_')) continue;

        final itemChange = calculateItemNetChangeForMonth(
          item: item,
          month: month,
          pulses: monthPulses,
          isCurrentPeriod: isCurrent,
          periodInfo: periodInfo,
          settings: settings,
          pulseMap: pulseMap,
        );

        if (itemChange > 0) {
          credits += itemChange;
        } else {
          debits += itemChange;
        }
      }

      monthNetChanges.add(credits + debits);
      monthCredits.add(credits);
      monthDebits.add(debits);
    }

    final startBalances = List<int>.filled(months.length, 0);
    final cumulativeBalances = List<int>.filled(months.length, 0);

    var runningBalance = startingBalanceCents;

    for (var i = 0; i < months.length; i++) {
      if (i < baseIndex) {
        startBalances[i] = 0;
        cumulativeBalances[i] = monthNetChanges[i];
      } else if (i == baseIndex) {
        startBalances[i] = startingBalanceCents;
        cumulativeBalances[i] = startingBalanceCents + monthNetChanges[i];
        runningBalance = cumulativeBalances[i];
      } else {
        startBalances[i] = runningBalance;
        cumulativeBalances[i] = runningBalance + monthNetChanges[i];
        runningBalance = cumulativeBalances[i];
      }
    }

    final dynamicColumnWidth = getColumnWidth(settings);
    final width = months.length * dynamicColumnWidth;
    final endLabel = settings.viewPeriodMode == ViewPeriodMode.paycheck
        ? 'EOP'
        : 'EOM';
    final headerBackground = Theme.of(
      context,
    ).colorScheme.surfaceContainerHighest;
    final dividerColor = Theme.of(
      context,
    ).colorScheme.outlineVariant.withValues(alpha: 0.3);

    // Project Money Pot balances across all months
    final projectedPotsList = projectMoneyPotBalances(
      initialPots: settings.moneyPots,
      months: months,
      items: items,
      pulseForMonth: pulseForMonth,
      settings: settings,
      currentMonth: currentMonth,
    );

    return Material(
      color: headerBackground,
      elevation: 4,
      child: SizedBox(
        width: width,
        height: footerHeight,
        child: Row(
          children: [
            for (int i = 0; i < months.length; i++)
              _FooterColumn(
                month: months[i],
                isFirstColumn: i == 0,
                startBalanceCents: startBalances[i],
                creditsCents: monthCredits[i],
                debitsCents: monthDebits[i],
                cumulativeBalanceCents: cumulativeBalances[i],
                endLabel: endLabel,
                rowHeight: rowHeight,
                columnPadding: TimelineSheet._kColumnPadding,
                totalColumnWidth: dynamicColumnWidth,
                background: headerBackground,
                dividerColor: dividerColor,
                currency: currency,
                settings: settings,
                pots: projectedPotsList[i],
              ),
          ],
        ),
      ),
    );
  }
}

Widget _buildMonthHeader(
  BuildContext context,
  _SheetMonthHeaderItem item,
  double width,
  Color dividerColor,
) {
  return Container(
    width: width,
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: Theme.of(
        context,
      ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
      border: Border(bottom: BorderSide(color: dividerColor)),
    ),
    child: Text(
      DateFormat('MMMM').format(item.date),
      style: Theme.of(context).textTheme.labelSmall?.copyWith(
        fontWeight: FontWeight.bold,
        color: Theme.of(context).colorScheme.primary,
      ),
    ),
  );
}

/// A single column of footer rows (Start, End, End(C)) for one month.
class _FooterColumn extends StatelessWidget {
  const _FooterColumn({
    required this.month,
    required this.isFirstColumn,
    required this.startBalanceCents,
    required this.creditsCents,
    required this.debitsCents,
    required this.cumulativeBalanceCents,
    required this.endLabel,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    required this.currency,
    required this.settings,
    required this.pots,
  });

  final DateTime month;
  final bool isFirstColumn;
  final int startBalanceCents;
  final int creditsCents;
  final int debitsCents;
  final int cumulativeBalanceCents;
  final String endLabel;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final AppCurrency currency;
  final AppSettingsStore settings;
  final List<MoneyPot> pots;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _FooterRow(
          date: month,
          label: 'Start',
          value: formatMoneyFromCents(
            startBalanceCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: startBalanceCents < 0
              ? settings.debitColor
              : startBalanceCents > 0
              ? settings.creditColor
              : null,
          onTap: () {
            settings.timelineUseZeroBaseline =
                !settings.timelineUseZeroBaseline;
          },
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: 'Credits',
          value: formatMoneyFromCents(
            creditsCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: settings.creditColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: 'Debits',
          value: formatMoneyFromCents(
            debitsCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: settings.debitColor,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: endLabel,
          value: formatMoneyFromCents(
            startBalanceCents + creditsCents + debitsCents,
            currency,
            showCents: settings.showCents,
          ),
          valueColor: (startBalanceCents + creditsCents + debitsCents) < 0
              ? settings.debitColor
              : (startBalanceCents + creditsCents + debitsCents) > 0
              ? settings.creditColor
              : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),
        _FooterRow(
          date: month,
          label: '$endLabel(C)',
          value: isFirstColumn
              ? ''
              : formatMoneyFromCents(
                  cumulativeBalanceCents,
                  currency,
                  showCents: settings.showCents,
                ),
          valueColor: cumulativeBalanceCents < 0
              ? settings.debitColor
              : cumulativeBalanceCents > 0
              ? settings.creditColor
              : null,
          rowHeight: rowHeight,
          columnPadding: columnPadding,
          totalColumnWidth: totalColumnWidth,
          background: background,
          dividerColor: dividerColor,
        ),

        // Money Pots Section
        if (pots.isNotEmpty) ...[
          // Label / Toggle Row
          InkWell(
            onTap: () {
              settings.moneyPotsSectionCollapsed =
                  !(settings.moneyPotsSectionCollapsed == true);
            },
            child: Container(
              width: totalColumnWidth,
              height: rowHeight,
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                border: Border(
                  bottom: BorderSide(
                    color: dividerColor.withValues(alpha: 0.1),
                    width: 0.5,
                  ),
                  right: BorderSide(
                    color: dividerColor.withValues(alpha: 0.15),
                    width: 0.5,
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'POTS',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.0,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                  if (isFirstColumn)
                    Icon(
                      settings.moneyPotsSectionCollapsed
                          ? Icons.expand_more
                          : Icons.expand_less,
                      size: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                ],
              ),
            ),
          ),

          // Actual Pots
          if (settings.moneyPotsSectionCollapsed != true)
            for (final pot in pots)
              _FooterRow(
                date: month,
                label: pot.name,
                value: formatMoneyFromCents(
                  pot.amountMinorUnits,
                  pot.currency ?? currency,
                  showCents: settings.showCents,
                ),
                valueColor: pot.amountMinorUnits < 0
                    ? settings.debitColor
                    : pot.amountMinorUnits > 0
                    ? settings.creditColor
                    : null,
                rowHeight: rowHeight,
                columnPadding: columnPadding,
                totalColumnWidth: totalColumnWidth,
                background: background,
                dividerColor: dividerColor,
              ),
        ],
      ],
    );
  }
}

/// A fixed header row widget that displays Month labels and Money Pots.
class SheetHeaderRow extends StatelessWidget {
  const SheetHeaderRow({
    super.key,
    required this.months,
    required this.zoomStage,
    required this.settings,
    required this.onMonthTapped,
  });

  final List<DateTime> months;
  final GridZoomStage zoomStage;
  final AppSettingsStore settings;
  final void Function(DateTime)? onMonthTapped;

  static double getColumnWidth(AppSettingsStore settings) =>
      TimelineSheet.getColumnWidth(settings);
  static double getRowHeight(GridZoomStage stage) =>
      TimelineSheet.getRowHeight(stage);

  static double getHeaderHeight(
    GridZoomStage stage,
    AppSettingsStore settings,
  ) {
    return getRowHeight(stage); // Only Month/Period Label
  }

  @override
  Widget build(BuildContext context) {
    final dynamicColumnWidth = getColumnWidth(settings);
    final width = months.length * dynamicColumnWidth;
    final rowHeight = getRowHeight(zoomStage);
    final headerHeight = getHeaderHeight(zoomStage, settings);

    final headerBackground = Theme.of(
      context,
    ).colorScheme.surfaceContainerHighest;
    final dividerColor = Theme.of(
      context,
    ).colorScheme.outlineVariant.withValues(alpha: 0.3);

    return Material(
      color: headerBackground,
      elevation: 4,
      child: SizedBox(
        width: width,
        height: headerHeight,
        child: Row(
          children: [
            for (int i = 0; i < months.length; i++)
              _HeaderColumn(
                month: months[i],
                isFirstColumn: i == 0,
                rowHeight: rowHeight,
                columnPadding: TimelineSheet._kColumnPadding,
                totalColumnWidth: dynamicColumnWidth,
                background: headerBackground,
                dividerColor: dividerColor,
                settings: settings,
                zoomStage: zoomStage,
                onTap: onMonthTapped,
                dayWidth: TimelineSheet.getDayColumnWidth(settings.dayFormat),
                labelWidth:
                    settings.getTimelineShowPulseOrigin(TimelineViewMode.sheet)
                    ? TimelineSheet._kExpandedLabelWidth
                    : TimelineSheet._kMinLabelWidth,
                amountWidth: TimelineSheet._kAmountWidth,
                currency: settings.currencySettings.currency,
              ),
          ],
        ),
      ),
    );
  }
}

class _HeaderColumn extends StatelessWidget {
  const _HeaderColumn({
    required this.month,
    required this.isFirstColumn,
    required this.rowHeight,
    required this.columnPadding,
    required this.totalColumnWidth,
    required this.background,
    required this.dividerColor,
    required this.settings,
    required this.zoomStage,
    required this.onTap,
    required this.dayWidth,
    required this.labelWidth,
    required this.amountWidth,
    required this.currency,
  });

  final DateTime month;
  final bool isFirstColumn;
  final double rowHeight;
  final double columnPadding;
  final double totalColumnWidth;
  final Color background;
  final Color dividerColor;
  final AppSettingsStore settings;
  final GridZoomStage zoomStage;
  final void Function(DateTime)? onTap;
  final double dayWidth;
  final double labelWidth;
  final double amountWidth;
  final AppCurrency currency;

  @override
  Widget build(BuildContext context) {
    // Get period info for paycheck mode label
    final periodInfo = PaycheckService.getPeriodInfo(
      month,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
      includeMonth: settings.paycheckShowMonthInTimeline,
    );

    // Use paycheck period label in paycheck mode, otherwise month label
    final headerLabel =
        settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured
        ? periodInfo.label
        : gridHeaderLabel(month, zoomStage, Localizations.localeOf(context));

    // Check for current period highlight
    final now = DateTime.now();
    final DateTime currentPeriodMonth =
        (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
            settings.isPaycheckModeConfigured)
        ? PaycheckService.getCurrentPaycheckPeriodMonth(
            now,
            settings.paycheckDay!,
            businessAdjust: settings.paycheckBusinessAdjust,
            adjustDirection: settings.paycheckBusinessAdjustDirection,
          )
        : monthOnly(now);
    final isCurrent = monthOnly(month).isAtSameMomentAs(currentPeriodMonth);

    final headerStyle = Theme.of(context).textTheme.labelMedium?.copyWith(
      fontFeatures: const [FontFeature.tabularFigures()],
      fontSize: 12,
      fontWeight: FontWeight.w600,
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Month Header
        GestureDetector(
          onTap: onTap != null ? () => onTap!(month) : null,
          child: Container(
            width: totalColumnWidth,
            height: rowHeight,
            padding: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: background,
              border: Border(
                bottom: BorderSide(color: dividerColor, width: 1),
                right: BorderSide(
                  color: dividerColor.withValues(alpha: 0.15),
                  width: 0.5,
                ),
              ),
            ),
            alignment: Alignment.center,
            child: isCurrent
                ? Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      headerLabel,
                      style: headerStyle?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                : Text(
                    headerLabel,
                    style: headerStyle,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
          ),
        ),
      ],
    );
  }
}

// --- Display Items for Lazy Loading ---

abstract class _SheetDisplayItem {}

class _SheetRowItem extends _SheetDisplayItem {
  final _SheetRow row;
  final bool showDay;

  _SheetRowItem(this.row, {this.showDay = true});
}

class _SheetGroupHeaderItem extends _SheetDisplayItem {
  final int day;
  final DayFormat dayFormat;

  _SheetGroupHeaderItem(this.day, this.dayFormat);
}

class _SheetBudgetHeaderItem extends _SheetDisplayItem {
  final bool isCollapsed;
  final bool isFirstColumn;
  final bool isCurrent;

  _SheetBudgetHeaderItem({
    required this.isCollapsed,
    required this.isFirstColumn,
    required this.isCurrent,
  });
}

class _SheetMonthHeaderItem extends _SheetDisplayItem {
  final DateTime date;
  _SheetMonthHeaderItem(this.date);
}
