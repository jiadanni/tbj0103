import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_actions.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Calculates the net change (in cents) that a timeline item contributes to the balance
/// calculation for a given month.
///
/// Handles the complex logic for spending envelopes and the `useActualsForBalance` toggle.
///
/// [pulseMap] - Optional pre-built lookup map for O(1) pulse lookups. If not provided,
/// falls back to O(n) iteration through pulses.
///
/// [useActualsOverride] - if provided, overrides the envelope's useActuals setting.
/// true = use actuals (only deduct what was spent), false = use budget (reserve full amount).
int calculateItemNetChangeForMonth({
  required TimelineItem item,
  required DateTime month,
  required List<PulseEntry> pulses,
  required bool isCurrentPeriod,
  required PeriodInfo periodInfo,
  required AppSettingsStore settings,
  Map<String, List<PulseEntry>>? pulseMap,
  bool ignoreCleared = false,
  bool? useActualsOverride,
}) {
  // If item doesn't appear in this period (Paycheck Mode or Calendar Mode), it contributes nothing.
  // We use the centralized helper to handle split-month logic correctly.
  if (!PaycheckService.shouldItemAppearInPeriod(item, periodInfo, month)) {
    return 0;
  }

  // Determine the effective date for amount lookup.
  // For Paycheck Mode:
  // - If the item recurs in the PREVIOUS month (tail of period) and falls in the period window,
  //   we must use the previous month to get the correct amount/recurrence.
  // - Otherwise, we use the reference month.
  DateTime effectiveDate = month;

  if (item.type != PulseType.spendingEnvelope) {
    // Check if this item is actually falling in the previous month's part of the period
    // This happens if:
    // 1. It recurs in the previous month
    // 2. Its day is >= period start day (approximate check, PaycheckService has exact logic)
    // To be precise: Check if it should appear in the PREVIOUS month.
    // If so, and it matches the period start criteria, use prev month.

    final prevMonth = DateTime.utc(month.year, month.month - 1);
    // Note: We already know it appears in the period. We just need to know WHICH part.
    // If it recurs in the previous month AND that instance is in the period...
    if (item.shouldAppearInMonth(prevMonth)) {
      // Now check if that instance falls within period start
      final day = item.dayOfMonth;
      final daysInPrev = DateTime.utc(
        prevMonth.year,
        prevMonth.month + 1,
        0,
      ).day;
      final effectiveDayPrev = day > daysInPrev ? daysInPrev : day;

      // If the item's day in prev month is ON or AFTER the period start, it belongs to the tail.
      if (effectiveDayPrev >= periodInfo.start.day) {
        effectiveDate = prevMonth;
      }
    }

    // Specific effective date calculation
    if (item.type == PulseType.oneOff || item.type == PulseType.oneOffIncome) {
      effectiveDate = item.startDate;
    } else {
      // Recurring: use dayOfMonth clamped to effective month length
      final lastDay = DateTime.utc(
        effectiveDate.year,
        effectiveDate.month + 1,
        0,
      ).day;
      final day = item.dayOfMonth > lastDay ? lastDay : item.dayOfMonth;
      effectiveDate = DateTime.utc(
        effectiveDate.year,
        effectiveDate.month,
        day,
      );
    }
  }

  final rawAmount = item.getAmountForDate(effectiveDate);
  // For foreign-currency debt items, `amountMinorUnits` is stored in the
  // loan currency. Convert to app currency using the exchange rate so the
  // balance totals reflect the correct settlement amount.
  final amount =
      (item.balanceCurrency != null &&
          item.exchangeRate != null &&
          item.exchangeRate! > 0)
      ? (rawAmount * item.exchangeRate!).round()
      : rawAmount;

  if (isCurrentPeriod) {
    // Current Period Logic:
    // We are starting from the actual bank balance (currentBalanceCents).
    // This balance already reflects everything that has cleared (is in pulse).

    bool isCleared = false;

    // Use lookup map if provided for O(1) lookup, otherwise fall back to O(n) iteration
    if (pulseMap != null) {
      final explicitMatches = pulseMap[item.id.value];
      if (explicitMatches != null) {
        for (final p in explicitMatches) {
          if (pulseMatchesTimelineItem(
            p,
            item,
            month,
            settings,
            precomputedPeriodInfo: periodInfo,
          )) {
            isCleared = true;
            break;
          }
        }
      }
    } else {
      for (final p in pulses) {
        if (pulseMatchesTimelineItem(
          p,
          item,
          month,
          settings,
          precomputedPeriodInfo: periodInfo,
        )) {
          isCleared = true;
          break;
        }
      }
    }

    // For envelopes, logic depends on the "Deduct Only Actual Spent" strategy
    if (item.type == PulseType.spendingEnvelope) {
      // Use override if provided, otherwise use helper to resolve effective strategy
      final useActuals =
          useActualsOverride ??
          SpendingEnvelopeService.isUsingActuals(item, true, settings);

      if (useActuals) {
        // "Deduct Only Actual Spent" (Enabled):
        // Current Month: Only deduct what was spent. Since actual spending is
        // already in the bank balance, we return 0 adjustment.
        // Future Months: Deduct the full budget for planning purposes.
        return 0;
      } else {
        // "Reserve Full Budget" (Disabled):
        // Current Month: We want the final balance to reflect the FULL budget deduction.
        // We already have 'spent' deducted in the bank balance.
        // We need to deduct the 'remaining' budget.
        //
        // ASSUMPTION: currentBalanceCents already reflects actual spending via recorded
        // pulses. This calculation adds the unspent budget portion to show the reserved
        // envelope amount. If a user manually adjusts their balance AND logs envelope
        // spending, the numbers may not align - envelope spending should be the source
        // of truth for envelope-related transactions.
        final period = SpendingEnvelopeService.getEnvelopePeriodDates(
          item,
          month,
          settings,
        );
        final spent = SpendingEnvelopeService.getSpentAmountForPeriod(
          item,
          pulses,
          period,
        );

        // FIX: Use the end of the period to capture any variations active during the period.
        // If we use 'month' (1st), we miss variations that start mid-month.
        final target = item.getAmountForDate(period.$2).abs();

        final remaining = target - spent;

        // If there is budget left, deduct it (negative).
        // If overspent (remaining < 0), we don't add back money; we let the actuals stand.
        // NOTE: This calculates the *remaining* budget to settle.
        return remaining > 0 ? -remaining : 0;
      }
    }

    // Standard items:
    // If it's cleared, it's already in the bank balance. Skip it.
    if (isCleared) return 0;
    // Otherwise, deduct it as it's expected to leave the bank later.
    return amount;
  } else {
    // Future/Other month logic:
    // We are projecting from a theoretical starting balance.

    // For envelopes:
    // Future Month Logic:
    // Check "useActualsForFutureBalance" strategy.
    if (item.type == PulseType.spendingEnvelope) {
      // Use override if provided, otherwise use helper to resolve effective strategy
      final useActuals =
          useActualsOverride ??
          SpendingEnvelopeService.isUsingActuals(item, false, settings);

      if (useActuals) {
        // "Deduct Only Actual Spent" (Enabled for Future):
        // Only deduct what was spent. Since actual spending is NOT in the bank balance (it's future),
        // we normally would rely on a projection table.
        // BUT wait, this function returns a "net change" TO the balance.
        // For future months, this item normally deducts its budget from the running balance.
        // If we want "Actuals Only", we should deduct the `spent` amount.
        // But future spent is likely 0 unless planned in advance.

        final period = SpendingEnvelopeService.getEnvelopePeriodDates(
          item,
          month,
          settings,
        );
        final spent = SpendingEnvelopeService.getSpentAmountForPeriod(
          item,
          pulses,
          period,
        );

        // Return negative of spent (deduction)
        return -spent; // Likely 0, which is correct if nothing spent yet.
      } else {
        // "Reserve Full Budget" (Disabled/Default for Future):
        // Always deduct the FULL budget for planning purposes.
        // FIX: Use the end of the period to capture any variations active during the period.
        final period = SpendingEnvelopeService.getEnvelopePeriodDates(
          item,
          month,
          settings,
        );
        return -item.getAmountForDate(period.$2).abs(); // Ensure negative
      }
    }

    // Standard items:
    // FIX(Issue #28): Check if item is already cleared/paid in this future month!
    // Since we start with currentBalance (which includes ALL recorded pulses),
    // if a future item is already recorded, we must NOT deduct the plan again.

    // Check if cleared
    bool isCleared = false;
    if (pulseMap != null) {
      final explicitMatches = pulseMap[item.id.value];
      if (explicitMatches != null) {
        for (final p in explicitMatches) {
          if (pulseMatchesTimelineItem(
            p,
            item,
            month,
            settings,
            precomputedPeriodInfo: periodInfo,
          )) {
            isCleared = true;
            break;
          }
        }
      }
    } else {
      for (final p in pulses) {
        if (pulseMatchesTimelineItem(
          p,
          item,
          month,
          settings,
          precomputedPeriodInfo: periodInfo,
        )) {
          isCleared = true;
          break;
        }
      }
    }

    if (!ignoreCleared && isCleared) return 0;

    // Deduct the full planned amount if not cleared.
    return amount;
  }
}

/// Calculates the total net change for all items in a given period.
///
/// This unifies the logic for filtering items, skipping virtual orphans,
/// and calculating their individual net changes.
int calculateTotalNetChangeForPeriod({
  required DateTime month,
  required List<TimelineItem> items,
  required List<PulseEntry> pulses,
  required PeriodInfo periodInfo,
  required bool isCurrentPeriod,
  required AppSettingsStore settings,
  Map<String, List<PulseEntry>>? pulseMap,
}) {
  int total = 0;

  // Filter items that should appear in this period
  // We use ignoreSkips: true to match MonthCard logic - skipped items are included
  // in the loop but calculateItemNetChangeForMonth returns 0 for them.
  final periodItems = items.where(
    (item) => PaycheckService.shouldItemAppearInPeriod(
      item,
      periodInfo,
      month,
      ignoreSkips: true,
    ),
  );

  for (final item in periodItems) {
    // Skip virtual items from orphaned pulses - they represent past transactions
    // already reflected in currentBalanceCents. Including them would double-count.
    if (item.id.value.startsWith('virtual_')) continue;

    total += calculateItemNetChangeForMonth(
      item: item,
      month: month,
      pulses: pulses,
      isCurrentPeriod: isCurrentPeriod,
      periodInfo: periodInfo,
      settings: settings,
      pulseMap: pulseMap,
    );
  }

  // 3. Add standalone pulses (manual entries, imported transactions)
  // These contribute directly to the balance as they aren't linked to any timeline item.
  // IMPORTANT: For the current period, cleared pulses (date <= today) are already
  // reflected in currentBalanceCents, so we only add FUTURE-dated ones.
  // For future periods, all pulses in that period should be included.
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);

  for (final pulse in pulses) {
    if (pulse.timelineItemId == null) {
      if (isCurrentPeriod) {
        // Only include future-dated standalone pulses (not yet in bank balance)
        if (pulse.date.isAfter(today)) {
          total += pulse.amountMinorUnits;
        }
        // Cleared pulses (date <= today) are already in currentBalanceCents - skip them
      } else {
        // Future periods: include all standalone pulses in that period
        total += pulse.amountMinorUnits;
      }
    }
  }

  return total;
}
