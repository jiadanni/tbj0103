import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Holds display values for a pulse (either scheduled or actual)
class DisplayValues {
  const DisplayValues({
    required this.date,
    required this.amountMinorUnits,
    required this.hasDateVariance,
    required this.hasAmountVariance,
    this.scheduledDate,
    this.scheduledAmountMinorUnits,
    this.hasSalaryBusinessDayAdjustment = false,
    this.rawSalaryDate,
  });

  /// The date to display (actual if past month, scheduled otherwise)
  final DateTime date;

  /// The amount to display in cents (actual if past month, scheduled otherwise)
  final int amountMinorUnits;

  /// Whether the actual date differs from scheduled
  final bool hasDateVariance;

  /// Whether the actual amount differs from scheduled
  final bool hasAmountVariance;

  /// Original scheduled date (for variance display)
  final DateTime? scheduledDate;

  /// Original scheduled amount in cents (for variance display)
  final int? scheduledAmountMinorUnits;

  final bool
  hasSalaryBusinessDayAdjustment; // True if salary date was weekend-adjusted
  final DateTime? rawSalaryDate; // Original scheduled date before adjustment

  /// Returns the variance in days (positive if paid later, negative if earlier)
  int? getDateVarianceDays() {
    if (!hasDateVariance || scheduledDate == null) return null;
    return date.day - scheduledDate!.day;
  }

  /// Returns the variance in cents (positive if more paid, negative if less)
  int? getAmountVarianceCents() {
    if (!hasAmountVariance || scheduledAmountMinorUnits == null) return null;
    return amountMinorUnits - scheduledAmountMinorUnits!;
  }
}

/// Selects appropriate display values based on whether month is past/current
///
/// When [periodInfo] is provided and the period spans two months (paycheck mode),
/// the display date will correctly fall in the appropriate month (current or previous).
DisplayValues getDisplayValues({
  required TimelineItem item,
  required DateTime month,
  PulseEntry? pulse,
  PeriodInfo? periodInfo,
  bool businessAdjust = true,
  PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
}) {
  // For any item with a recorded pulse (past, current, or future), show actuals.
  // This ensures the displayed date matches the sorting order and reflects
  // when the payment actually occurred (including date changes on Mark page).
  if (pulse != null) {
    return DisplayValues(
      date: pulse.date,
      amountMinorUnits: pulse.amountMinorUnits,
      hasDateVariance:
          pulse.scheduledDate != null &&
          pulse.scheduledDate!.day != pulse.date.day,
      hasAmountVariance:
          pulse.scheduledAmountMinorUnits != null &&
          pulse.scheduledAmountMinorUnits != pulse.amountMinorUnits,
      scheduledDate: pulse.scheduledDate,
      scheduledAmountMinorUnits: pulse.scheduledAmountMinorUnits,
    );
  }

  // For items without a pulse, show scheduled
  // Determine the correct month for display (handles split-month paycheck periods)
  final displayMonth = _getDisplayMonthForItem(item, month, periodInfo);
  final effectiveDay = effectiveDayOfMonth(item.dayOfMonth, displayMonth);
  final displayDate = DateTime.utc(
    displayMonth.year,
    displayMonth.month,
    effectiveDay,
  );

  // Calculate salary adjustment if applicable
  var adjustedDate = displayDate;
  bool hasSalaryAdjustment = false;
  DateTime? rawSalaryDate;

  if (item.isSalary && businessAdjust) {
    adjustedDate = PaycheckService.applyBusinessAdjust(
      displayDate,
      businessAdjust,
      adjustDirection,
    );
    if (adjustedDate != displayDate) {
      hasSalaryAdjustment = true;
      rawSalaryDate = displayDate;
    }
  }

  final rawAmount = item.getAmountForDate(adjustedDate);
  // For foreign-currency debt items, `amountMinorUnits` is in the loan
  // currency. Convert to app currency using the exchange rate so the
  // timeline row shows the correct settlement amount (e.g. £1,000 × 1.2 = €1,200).
  final scheduledAmount =
      (item.balanceCurrency != null &&
          item.exchangeRate != null &&
          item.exchangeRate! > 0)
      ? (rawAmount * item.exchangeRate!).round()
      : rawAmount;

  return DisplayValues(
    date: adjustedDate,
    amountMinorUnits: scheduledAmount,
    hasDateVariance: false,
    hasAmountVariance: false,
    hasSalaryBusinessDayAdjustment: hasSalaryAdjustment,
    rawSalaryDate: rawSalaryDate,
  );
}

/// Determines the correct month for displaying an item when the period spans two months.
///
/// For paycheck mode where period spans e.g., Feb 23 - Mar 22:
/// - Items with dayOfMonth >= 23 should display in Feb (previous month)
/// - Items with dayOfMonth <= 22 should display in Mar (reference month)
DateTime _getDisplayMonthForItem(
  TimelineItem item,
  DateTime referenceMonth,
  PeriodInfo? periodInfo,
) {
  if (periodInfo == null) {
    return referenceMonth;
  }

  // Check if period spans two months
  final periodSpansTwoMonths =
      periodInfo.start.month != periodInfo.end.month ||
      periodInfo.start.year != periodInfo.end.year;

  if (!periodSpansTwoMonths) {
    return referenceMonth;
  }

  // Period spans two months - determine which month this item belongs to
  final itemDay = item.dayOfMonth;
  final prevMonth = DateTime.utc(referenceMonth.year, referenceMonth.month - 1);
  final daysInPrev = DateTime.utc(prevMonth.year, prevMonth.month + 1, 0).day;

  // Clamp item day to the previous month's max days
  final effectiveDayPrev = itemDay > daysInPrev ? daysInPrev : itemDay;

  // If item's day is >= period start day (which is in prev month), it falls in prev month
  if (effectiveDayPrev >= periodInfo.start.day) {
    // Check if item actually recurs in the previous month
    if (item.shouldAppearInMonth(prevMonth)) {
      return prevMonth;
    }
  }

  // Otherwise, item falls in the reference month
  return referenceMonth;
}
