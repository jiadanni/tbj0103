import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_amount_selector.dart';

// =============================================================================
// Quick Spending Flow (Spending Envelopes)
// =============================================================================

void showQuickSpendingFlow(BuildContext context, ExpenseStore store) async {
  // 1. Filter for spending envelopes
  final envelopes = store.activeTimelineItems
      .where((i) => i.type == PulseType.spendingEnvelope)
      .toList();

  if (envelopes.isEmpty) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('No ${Terminology.of(context).budgetLabel}s'),
        content: Text(
          'You don\'t have any ${Terminology.of(context).budgetLabel.toLowerCase()}s set up.\n\nCreate a Timeline Item with type "${Terminology.of(context).budgetLabel}" to use this feature.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    return;
  }

  // 2. Select Envelope
  TimelineItem? selectedEnvelope;
  if (envelopes.length == 1) {
    selectedEnvelope = envelopes.first;
  } else {
    selectedEnvelope = await showModalBottomSheet<TimelineItem>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      // Reuse the selector sheet structure
      builder: (ctx) => _EnvelopeSelectorSheet(items: envelopes),
    );
  }

  if (selectedEnvelope == null || !context.mounted) return;

  // 3. Select Amount
  await showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent, // Let the widget handle styling
    builder: (ctx) =>
        _QuickSpendingAmountSheet(envelope: selectedEnvelope!, store: store),
  );
}

class _EnvelopeSelectorSheet extends StatelessWidget {
  const _EnvelopeSelectorSheet({required this.items});

  final List<TimelineItem> items;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Select ${Terminology.of(context).budgetLabel}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Flexible(
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: items.length,
              separatorBuilder: (_, _) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final item = items[index];
                return ListTile(
                  title: Text(item.label),
                  subtitle: item.origin != null ? Text(item.origin!) : null,
                  onTap: () => Navigator.pop(context, item),
                  leading: CircleAvatar(
                    backgroundColor: Colors.red.withValues(alpha: 0.1),
                    child: const Icon(
                      Icons.arrow_downward,
                      color: Colors.red,
                      size: 16,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _QuickSpendingAmountSheet extends StatelessWidget {
  const _QuickSpendingAmountSheet({
    required this.envelope,
    required this.store,
  });

  final TimelineItem envelope;
  final ExpenseStore store;

  void _handleAmountSelected(BuildContext context, int amountCents) {
    // Determine sign: Expenses are negative
    final finalAmount = -amountCents.abs();

    final pulse = PulseEntry(
      id: newEntryId(),
      label: envelope.label,
      amountMinorUnits: finalAmount,
      date: DateTime.now(),
      type: PulseType.spendingEnvelope,
      timelineItemId: envelope.id,
      category: envelope.category,
      origin: envelope.origin,
      moneyPotId: envelope.moneyPotId,
    );

    store.upsertPulse(pulse);

    // Update balance
    final settings = AppSettingsScope.read(context);
    if (!settings.balanceUpdatesDisabled) {
      settings.currentBalanceCents += pulse.amountMinorUnits;
    }

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Spent ${formatMoney(amountCents, settings.currency, showDecimals: settings.showCents)} from ${envelope.label}',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    // Get custom amounts from envelope or fallback to global settings
    final amounts = envelope.quickAddAmounts ?? settings.customQuickAddAmounts;

    return Container(
      padding: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Quick Spend: ${envelope.label}',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          QuickAmountSelector(
            amounts: amounts,
            onAmountSelected: (amount) =>
                _handleAmountSelected(context, amount),
          ),
          // Removed manual entry fallback as it pointed to the deleted dialog.
          // Users should use Log Transaction flow if they need custom amounts.
        ],
      ),
    );
  }
}
