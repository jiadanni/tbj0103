import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

/// Helper to merge registered timeline items with standalone orphaned pulses for display.
///
/// Identify orphaned pulses (those without a valid timelineItemId or where the parent item is missing)
/// and convert them into virtual [TimelineItem]s so they can be rendered in visual views
/// (Month Card, Grid, Sheet) which iterate over TimelineItems.
///
/// Also performs "Visual Linking" (Fuzzy Matching):
/// If an orphaned pulse matches an unlinked scheduled item (same amount, close date),
/// we "visually link" them by returning a modified scheduled item (with cleared date)
/// instead of showing duplicates.
List<TimelineItem> mergeItemsWithStandalonePulses(
  List<TimelineItem> registeredItems,
  List<PulseEntry> pulses,
  DateTime month,
) {
  // 1. Identify explicitly linked items
  final linkedItemIds = <String>{};
  for (final p in pulses) {
    if (p.timelineItemId != null) {
      linkedItemIds.add(p.timelineItemId!.value);
    }
  }

  // 2. Separate registered items into linked vs unlinked (candidates for fuzzy matching)
  final unlinkedScheduledItems = <TimelineItem>[];
  final finalItemsMap =
      <String, TimelineItem>{}; // Map by ID to preserve order/uniqueness

  for (final item in registeredItems) {
    // If explicit link exists, keep it as is
    if (linkedItemIds.contains(item.id.value)) {
      finalItemsMap[item.id.value] = item;
    } else {
      // Unlinked items are candidates for fuzzy matching
      unlinkedScheduledItems.add(item);
      // Add to final map initially (will be replaced if matched)
      finalItemsMap[item.id.value] = item;
    }
  }

  // 3. Find orphans (pulses with no explicit parent)
  final orphans = pulses.where((p) {
    if (p.timelineItemId == null) return true;
    // If ID exists but not in registeredItems, generic orphan (deleted parent?)
    // But since we just collected all linkedItemIds from pulses themselves,
    // we only care if the ID is strictly null here for 'pure' orphans.
    // If it HAS an ID but that ID isn't in registeredItems, it's a "ghost" link.
    // We treat those as orphans too for display purposes.
    final hasParent = registeredItems.any(
      (i) => i.id.value == p.timelineItemId!.value,
    );
    return !hasParent;
  });

  final virtualItems = <TimelineItem>[];

  // 4. Fuzzy Match Orphans to Unlinked Scheduled Items
  // FIX(Issue #32): Stricter matching with label/category validation to prevent misassignment.
  for (final orphan in orphans) {
    int? bestMatchIndex;
    double bestScore = 0;

    // Multi-criteria matching:
    // - Amount must match exactly (required)
    // - Label similarity (weighted)
    // - Category match (weighted)
    // - Date proximity (weighted)
    // Only match if combined score exceeds threshold

    for (int i = 0; i < unlinkedScheduledItems.length; i++) {
      final candidate = unlinkedScheduledItems[i];

      // Amount MUST match exactly - this is the primary filter
      if (candidate.amountMinorUnits != orphan.amountMinorUnits) {
        continue;
      }

      double score = 0;

      // Label similarity check (0-40 points)
      final orphanLabel = orphan.label.toLowerCase().trim();
      final candidateLabel = candidate.label.toLowerCase().trim();
      if (orphanLabel == candidateLabel) {
        score += 40; // Exact match
      } else if (orphanLabel.contains(candidateLabel) ||
          candidateLabel.contains(orphanLabel)) {
        score += 30; // Substring match
      } else {
        // Check for common significant words (ignore short words)
        final orphanWords = orphanLabel
            .split(RegExp(r'\s+'))
            .where((w) => w.length > 2)
            .toSet();
        final candidateWords = candidateLabel
            .split(RegExp(r'\s+'))
            .where((w) => w.length > 2)
            .toSet();
        final commonWords = orphanWords.intersection(candidateWords);
        if (commonWords.isNotEmpty) {
          score += 10 + (commonWords.length * 5).clamp(0, 20); // 10-30 points
        }
      }

      // Category match check (0-30 points)
      final orphanCategory = orphan.category?.toLowerCase().trim();
      final candidateCategory = candidate.category?.toLowerCase().trim();
      if (orphanCategory != null && candidateCategory != null) {
        if (orphanCategory == candidateCategory) {
          score += 30; // Exact category match
        } else if (orphanCategory.contains(candidateCategory) ||
            candidateCategory.contains(orphanCategory)) {
          score +=
              15; // Partial category match (e.g., "Insurance" vs "Liability Insurance")
        }
      } else if (orphanCategory == null && candidateCategory == null) {
        score += 10; // Both uncategorized - slight bonus
      }

      // Date proximity check (0-30 points)
      final candidateDate = DateTime(
        month.year,
        month.month,
        candidate.dayOfMonth,
      );
      final diff = orphan.date.difference(candidateDate).inDays.abs();
      if (diff == 0) {
        score += 30; // Same day
      } else if (diff <= 2) {
        score += 20; // Within 2 days
      } else if (diff <= 4) {
        score += 10; // Within 4 days
      }
      // More than 4 days: no date bonus, but still could match on label/category

      // Only consider this a match if score meets threshold
      // Threshold of 50 ensures at least:
      // - Exact label match (40) + some date proximity (10+), OR
      // - Exact category (30) + exact date (30), OR
      // - Strong label (30) + category (30), etc.
      if (score >= 50 && score > bestScore) {
        bestScore = score;
        bestMatchIndex = i;
      }
    }

    if (bestMatchIndex != null) {
      // MATCH FOUND!
      // 1. "Visually Link": Update the scheduled item to appear matched/paid?
      // Actually, we don't need to return a modified item to 'show as paid' because
      // the UI (MonthCard) looks up pulses by ID. Since we are NOT updating the DB,
      // we can't easily make the UI "see" this link unless we modify the item's ID
      // or the View's pulse lookup logic.
      //
      // EASIER APPROACH: suppress the orphan (don't create virtual item)
      // AND suppress the scheduled item? No, user wants to see it.
      //
      // BETTER: We can't easily modify the scheduled item to "have" the pulse ID without confusing interaction logic.
      //
      // ALTERNATIVE: Since the user sees duplicates (one "unpaid" scheduled, one "paid" standalone),
      // the goal is to hide one.
      // If we hide the scheduled item, we lose the "plan".
      // If we hide the orphan, we lose the "reality". // Wait, if we hide the orphan, the scheduled item remains "unpaid".
      //
      // We want the scheduled item to look "paid" by this orphan.
      // The MonthCard determines "paid" status by calling `_clearedDateFor(item)` -> looks for pulse with `timelineItemId == item.id`.
      //
      // Since we can't change the pulse's `timelineItemId` here (DB limitation),
      // we must return a Virtual Item that LOOKS like the scheduled item but IS the orphan?
      // Or simpler: Just treat them as distinct but don't show the duplicate?
      //
      // User complained about "Duplicates".
      // If we just hide the scheduled item (remove from `finalItemsMap`),
      // and show the orphan (as a virtual item), that solves "duplicate".
      // The virtual item will show the actual date/amount (Reality).
      // The scheduled "Plan" is hidden. This is acceptable for past/cleared items.

      final matchedItem = unlinkedScheduledItems[bestMatchIndex];

      // Remove the scheduled item from the final list
      finalItemsMap.remove(matchedItem.id.value);

      // Create a virtual item that "replaces" it.
      // We give it the ID of the orphan so interactions work (edit/delete pulse).
      virtualItems.add(
        TimelineItem(
          id: TimelineItemId('virtual_${orphan.id.value}'),
          label: orphan.label.isEmpty
              ? matchedItem.label
              : orphan
                    .label, // Use orphan label or scheduled? Match usually implies same.
          amountMinorUnits: orphan.amountMinorUnits,
          dayOfMonth: orphan.date.day,
          type: matchedItem.type, // Keep the type (e.g. valid category icon)
          startDate: orphan.date,
          frequency: null,
          category: orphan.category ?? matchedItem.category,
          origin: orphan.origin,
          notes: orphan.notes,
          moneyPotId: orphan.moneyPotId,
        ),
      );

      // Remove from pool so it's not matched again
      unlinkedScheduledItems.removeAt(bestMatchIndex);
    } else {
      // No match, pure orphan. Add as virtual item.
      virtualItems.add(
        TimelineItem(
          id: TimelineItemId('virtual_${orphan.id.value}'),
          label: orphan.label.isEmpty ? 'Untitled Transaction' : orphan.label,
          amountMinorUnits: orphan.amountMinorUnits,
          dayOfMonth: orphan.date.day,
          type: orphan.type,
          startDate: orphan.date,
          frequency: null,
          category: orphan.category,
          origin: orphan.origin,
          notes: orphan.notes,
          moneyPotId: orphan.moneyPotId,
          transactionCurrency: orphan.transactionCurrency,
          transactionAmountMinorUnits: orphan.transactionAmountMinorUnits,
          exchangeRate: orphan.exchangeRate,
        ),
      );
    }
  }

  return [...finalItemsMap.values, ...virtualItems];
}
