import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Service for spending envelope calculations.
///
/// Spending envelopes are TimelineItems with type [PulseType.spendingEnvelope]
/// that track variable expenses against a target budget. Users log spending
/// via Quick Add, creating PulseEntry records linked to the envelope.
class SpendingEnvelopeService {
  /// Calculates the period boundaries for a spending envelope.
  ///
  /// When [settings] is provided and paycheck mode is configured, uses the
  /// global paycheck period boundaries from [PaycheckService].
  /// Otherwise, falls back to the envelope's own dayOfMonth (reset day).
  ///
  /// For monthly envelopes in paycheck mode:
  /// - Uses PaycheckService.getPeriodInfo() for period boundaries
  ///
  /// For monthly envelopes in calendar mode or without settings:
  /// - Period is based on envelope's dayOfMonth
  static (DateTime start, DateTime end) getEnvelopePeriodDates(
    TimelineItem envelope,
    DateTime referenceMonth, [
    AppSettingsStore? settings,
  ]) {
    // If settings provided and paycheck mode is configured, use global period
    if (settings != null &&
        settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      final periodInfo = PaycheckService.getPeriodInfo(
        referenceMonth,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      return (periodInfo.start, periodInfo.end);
    }

    // Fallback to legacy behavior based on envelope's own reset day
    final resetDay = envelope.dayOfMonth;
    final frequency = envelope.frequency ?? RecurrenceFrequency.monthly;

    switch (frequency) {
      case RecurrenceFrequency.weekly:
        // Find the most recent reset day (weekday matching resetDay mod 7)
        // For simplicity, treat weekly as starting from the 1st of month
        // and running in 7-day chunks
        final monthStart = DateTime.utc(
          referenceMonth.year,
          referenceMonth.month,
          1,
        );
        final monthEnd = DateTime.utc(
          referenceMonth.year,
          referenceMonth.month + 1,
          0,
        );
        return (monthStart, monthEnd);

      case RecurrenceFrequency.biweekly:
        // Similar to weekly, but 14-day chunks
        final monthStart = DateTime.utc(
          referenceMonth.year,
          referenceMonth.month,
          1,
        );
        final monthEnd = DateTime.utc(
          referenceMonth.year,
          referenceMonth.month + 1,
          0,
        );
        return (monthStart, monthEnd);

      case RecurrenceFrequency.monthly:
        if (resetDay == 1) {
          // Standard: 1st to last day of month
          final start = DateTime.utc(
            referenceMonth.year,
            referenceMonth.month,
            1,
          );
          final end = DateTime.utc(
            referenceMonth.year,
            referenceMonth.month + 1,
            0,
          );
          return (start, end);
        } else {
          // Custom reset day: e.g., 15th to 14th
          // Determine if we're before or after the reset day in the reference month
          final refDay = referenceMonth.day;

          if (refDay >= resetDay) {
            // Current period started this month on resetDay
            final start = DateTime.utc(
              referenceMonth.year,
              referenceMonth.month,
              resetDay,
            );
            // Ends next month on resetDay - 1
            final nextMonth = DateTime.utc(
              referenceMonth.year,
              referenceMonth.month + 1,
              1,
            );
            final endDay = resetDay - 1;
            final maxEndDay = DateTime.utc(
              nextMonth.year,
              nextMonth.month + 1,
              0,
            ).day;
            final end = DateTime.utc(
              nextMonth.year,
              nextMonth.month,
              endDay > maxEndDay ? maxEndDay : endDay,
            );
            return (start, end);
          } else {
            // Current period started last month on resetDay
            final prevMonth = DateTime.utc(
              referenceMonth.year,
              referenceMonth.month - 1,
              1,
            );
            final maxPrevDay = DateTime.utc(
              prevMonth.year,
              prevMonth.month + 1,
              0,
            ).day;
            final startDay = resetDay > maxPrevDay ? maxPrevDay : resetDay;
            final start = DateTime.utc(
              prevMonth.year,
              prevMonth.month,
              startDay,
            );
            // Ends this month on resetDay - 1
            final endDay = resetDay - 1;
            final maxEndDay = DateTime.utc(
              referenceMonth.year,
              referenceMonth.month + 1,
              0,
            ).day;
            final end = DateTime.utc(
              referenceMonth.year,
              referenceMonth.month,
              endDay > maxEndDay ? maxEndDay : endDay,
            );
            return (start, end);
          }
        }

      case RecurrenceFrequency.quarterly:
        // 3-month periods starting from envelope's start month
        final startMonth = envelope.startDate;
        final monthsSinceStart =
            (referenceMonth.year - startMonth.year) * 12 +
            (referenceMonth.month - startMonth.month);
        final quarterIndex = monthsSinceStart ~/ 3;
        final quarterStartMonth = DateTime.utc(
          startMonth.year,
          startMonth.month + (quarterIndex * 3),
          1,
        );
        final quarterEndMonth = DateTime.utc(
          quarterStartMonth.year,
          quarterStartMonth.month + 3,
          0,
        );
        return (quarterStartMonth, quarterEndMonth);

      case RecurrenceFrequency.yearly:
        // Full year from start date anniversary
        final startMonth = envelope.startDate;
        final yearsSinceStart = referenceMonth.year - startMonth.year;
        final yearStart = DateTime.utc(
          startMonth.year + yearsSinceStart,
          startMonth.month,
          1,
        );
        final yearEnd = DateTime.utc(yearStart.year + 1, yearStart.month, 0);
        return (yearStart, yearEnd);
    }
  }

  /// Sums all PulseEntry amounts linked to this envelope within the period.
  ///
  /// Returns the absolute value of spent amount (always positive).
  static int getSpentAmountForPeriod(
    TimelineItem envelope,
    List<PulseEntry> pulses,
    (DateTime start, DateTime end) period,
  ) {
    return pulses
        .where((p) => p.timelineItemId == envelope.id)
        .where((p) => _isDateInPeriod(p.date, period))
        .fold(0, (sum, p) => sum + p.amountMinorUnits.abs());
  }

  /// Returns the number of pulses recorded against this envelope in the period.
  static int getPulseCountForPeriod(
    TimelineItem envelope,
    List<PulseEntry> pulses,
    (DateTime start, DateTime end) period,
  ) {
    return pulses
        .where((p) => p.timelineItemId == envelope.id)
        .where((p) => _isDateInPeriod(p.date, period))
        .length;
  }

  /// Returns the remaining amount for the envelope period.
  ///
  /// Calculated as: target - spent (can be negative if overspent).
  static int getRemainingAmount(
    TimelineItem envelope,
    List<PulseEntry> pulses,
    (DateTime start, DateTime end) period,
  ) {
    final target = envelope.amountMinorUnits.abs();
    final spent = getSpentAmountForPeriod(envelope, pulses, period);
    return target - spent;
  }

  /// Returns the spending progress as a ratio from 0.0 to 1.0+.
  ///
  /// Values > 1.0 indicate overspending.
  static double getProgress(
    TimelineItem envelope,
    List<PulseEntry> pulses,
    (DateTime start, DateTime end) period,
  ) {
    final target = envelope.amountMinorUnits.abs();
    if (target == 0) return 0.0;
    final spent = getSpentAmountForPeriod(envelope, pulses, period);
    return spent / target;
  }

  /// Checks if a date falls within the given period (inclusive).
  static bool _isDateInPeriod(
    DateTime date,
    (DateTime start, DateTime end) period,
  ) {
    return DateMath.isInRangeInclusive(date, period.$1, period.$2);
  }

  /// Helper to determine the effective strategy for an envelope.
  ///
  /// Resolves the override vs global default logic.
  static bool isUsingActuals(
    TimelineItem item,
    bool isCurrent,
    AppSettingsStore settings,
  ) {
    if (isCurrent) {
      return item.useActualsForCurrentBalance ??
          settings.globalEnvelopeCurrentDeductActuals;
    } else {
      // Future or Past (non-current)
      return item.useActualsForFutureBalance ??
          settings.globalEnvelopeFutureDeductActuals;
    }
  }
}
