import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show DateTimeRange;

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/state/settings_export.dart';
import 'package:expense_stalker_mobile/src/util/encryption_util.dart';
import 'package:expense_stalker_mobile/src/config/version_info.dart';
import 'package:expense_stalker_mobile/src/util/computation_tracer.dart'
    as tracer;
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

/// Export format version for JSON files.
/// Increment when schema changes require migration.
const int kExportVersion = 1;

/// Exception thrown when checksum validation fails during import.
class ChecksumValidationException implements Exception {
  const ChecksumValidationException(this.message);
  final String message;

  @override
  String toString() => 'ChecksumValidationException: $message';
}

/// Service for exporting and importing expense data.
///
/// Supports two formats:
/// - JSON: Full backup including all metadata, suitable for restore
/// - CSV: Flattened data suitable for spreadsheet analysis
class ExportService {
  const ExportService._();

  /// Singleton instance.
  static const ExportService instance = ExportService._();

  // ─────────────────────────────────────────────────────────────────────────
  // JSON Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports all accounts as a single JSON file and shares it.
  ///
  /// If [excludePulses] is true, only timeline items are exported without
  /// historic transactions. This is useful for clean imports after data cleanup.
  Future<String> exportAllAccountsJson(
    List<Account> accounts,
    Map<String, ExpenseSnapshot> data, {
    String? password,
    bool excludePulses = false,
  }) async {
    try {
      Map<String, String>? encryption;
      if (password != null && password.isNotEmpty) {
        // Heavy serialization and encoding
        final plainString = await compute((params) {
          final json = ExpensePersistence.multiAccountToExportJson(
            params.accounts,
            params.data,
            excludePulses: params.excludePulses,
          );
          return jsonEncode(json);
        }, (accounts: accounts, data: data, excludePulses: excludePulses));

        encryption = await EncryptionUtil.encrypt(plainString, password);
      }

      // Generate the JSON map first
      var json = await compute(
        (params) {
          return ExpensePersistence.multiAccountToExportJson(
            params.accounts,
            params.data,
            encryption: params.encryption,
            excludePulses: params.excludePulses,
          );
        },
        (
          accounts: accounts,
          data: data,
          encryption: encryption,
          excludePulses: excludePulses,
        ),
      );

      // Add checksum for data integrity validation (only for unencrypted exports)
      if (encryption == null) {
        json = await ExpensePersistence.addChecksum(json);
      }

      // Final encoding
      final encoded = const JsonEncoder.withIndent('  ').convert(json);

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final suffix = excludePulses ? '_clean' : '';
      final fileName = 'expense_stalker_all_accounts${suffix}_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(encoded);

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: fileName,
        ),
      );

      try {
        await file.delete();
      } catch (e, st) {
        debugLog(
          LogCategory.persistence,
          'Failed to delete temporary export file',
          error: e,
          stackTrace: st,
        );
      }
      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Multi-account JSON export failed',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  /// Exports the given snapshot as a JSON file and shares it.
  ///
  /// If [excludePulses] is true, only timeline items are exported without
  /// historic transactions. This is useful for clean imports after data cleanup.
  Future<String> exportJson(
    ExpenseSnapshot snapshot, {
    String? password,
    String? accountName,
    bool excludePulses = false,
  }) async {
    try {
      Map<String, String>? encryption;
      if (password != null && password.isNotEmpty) {
        // Heavy serialization and encoding
        final plainString = await compute((params) {
          final json = ExpensePersistence.toExportJson(
            params.snapshot,
            excludePulses: params.excludePulses,
          );
          return jsonEncode(json);
        }, (snapshot: snapshot, excludePulses: excludePulses));

        encryption = await EncryptionUtil.encrypt(plainString, password);
      }

      // Generate the JSON map first
      var json = await compute(
        (params) {
          return ExpensePersistence.toExportJson(
            params.snapshot,
            encryption: params.encryption,
            excludePulses: params.excludePulses,
          );
        },
        (
          snapshot: snapshot,
          encryption: encryption,
          excludePulses: excludePulses,
        ),
      );

      // Add checksum for data integrity validation (only for unencrypted exports)
      if (encryption == null) {
        json = await ExpensePersistence.addChecksum(json);
      }

      // Final encoding
      final encoded = const JsonEncoder.withIndent('  ').convert(json);

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'backup').replaceAll(
        RegExp(r'[^a-zA-Z0-9]'),
        '_',
      );
      final suffix = excludePulses ? '_clean' : '';
      final fileName =
          'expense_stalker_$safeAccountName${suffix}_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(encoded);

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: fileName,
        ),
      );

      try {
        await file.delete();
      } catch (e, st) {
        debugLog(
          LogCategory.persistence,
          'Failed to delete temporary export file',
          error: e,
          stackTrace: st,
        );
      }
      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'JSON export failed',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  /// Imports expense data from a JSON file selected by the user.
  ///
  /// Returns a tuple of (accounts, data) on success, or null if cancelled.
  /// Validates checksum if present; throws [ChecksumValidationException] if
  /// checksum validation fails and [onChecksumFailure] is not provided or returns false.
  Future<(List<Account>, Map<String, ExpenseSnapshot>)?> importJson({
    Future<String?> Function()? onPasswordRequired,
    Future<bool> Function()? onChecksumFailure,
  }) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return null;

      final filePath = result.files.single.path;
      if (filePath == null) return null;

      final file = File(filePath);
      final content = await file.readAsString();

      // Heavy decoding
      var json = await compute(jsonDecode, content) as Map<String, dynamic>;

      if (ExpensePersistence.isEncrypted(json)) {
        if (onPasswordRequired == null) {
          throw const FormatException(
            'File is encrypted but no password provider given',
          );
        }
        final password = await onPasswordRequired();
        if (password == null) return null;

        final encryptionData = json['encryption'] as Map<String, dynamic>;
        final decryptedString = await EncryptionUtil.decrypt(
          encryptionData,
          password,
        );

        // Heavy decoding of inner content
        json =
            await compute(jsonDecode, decryptedString) as Map<String, dynamic>;
      }

      // Validate checksum if present
      final checksumResult = await ExpensePersistence.validateChecksum(json);
      if (checksumResult == ChecksumValidation.invalid) {
        // Checksum mismatch - data may be corrupted
        if (onChecksumFailure != null) {
          final shouldContinue = await onChecksumFailure();
          if (!shouldContinue) {
            throw const ChecksumValidationException(
              'Checksum validation failed - import cancelled by user',
            );
          }
          // User chose to continue despite checksum failure
          debugLog(
            LogCategory.persistence,
            'User chose to continue import despite checksum failure',
          );
        } else {
          throw const ChecksumValidationException(
            'Checksum validation failed - data may be corrupted',
          );
        }
      }

      // Heavy map-to-object conversion
      return await compute(ExpensePersistence.multiAccountFromExportJson, json);
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'JSON import failed',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }
  // Export/import JSON helpers are provided by ExpensePersistence.
  // Local duplication removed to avoid unused code and ensure a single
  // canonical serialization implementation.

  // ─────────────────────────────────────────────────────────────────────────
  // Settings Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports global app settings as a JSON file and shares it.
  ///
  /// Exports theme, currency, timeline settings, and global money pots.
  /// Account-specific settings (paycheck, starting balance) are excluded.
  Future<String> exportSettingsJson(AppSettingsStore settings) async {
    try {
      // Generate JSON map on main thread (AppSettingsStore can't be sent to isolate)
      final json = SettingsExport.toJson(settings);

      // Use compute only for the string encoding
      final encoded = await compute((j) {
        return const JsonEncoder.withIndent('  ').convert(j);
      }, json);

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final fileName = 'expense_stalker_settings_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(encoded);

      debugLog(LogCategory.persistence, 'Exported settings: ${file.path}');

      await SharePlus.instance.share(
        ShareParams(
          files: [
            XFile(file.path, name: fileName, mimeType: 'application/json'),
          ],
          subject: fileName,
        ),
      );

      try {
        await file.delete();
      } catch (e, st) {
        debugLog(
          LogCategory.persistence,
          'Failed to delete temporary settings export file',
          error: e,
          stackTrace: st,
        );
      }
      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Settings export failed',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  /// Imports settings from a JSON file selected by the user.
  ///
  /// Returns true if import was successful, false if cancelled or failed.
  Future<bool> importSettingsJson(AppSettingsStore settings) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return false;

      final filePath = result.files.single.path;
      if (filePath == null) return false;

      final file = File(filePath);
      final content = await file.readAsString();

      final json = await compute(jsonDecode, content) as Map<String, dynamic>;

      // Validate it's a settings export (not a data export)
      if (!json.containsKey('theme') &&
          !json.containsKey('currency') &&
          !json.containsKey('timeline')) {
        throw const FormatException(
          'File does not appear to be a settings export',
        );
      }

      return await SettingsExport.applyFromJson(settings, json);
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Settings import failed',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CSV Export
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports the given snapshot as a CSV file and shares it.
  ///
  /// The CSV contains a combined view of timeline items and pulse,
  /// suitable for analysis in spreadsheet applications.
  ///
  /// If [pulsesOnly] is true, only pulse entries are exported without timeline items.
  /// This is useful for reviewing historic transactions with variance tracking.
  ///
  /// If [timelineOnly] is true, only timeline items are exported without pulses.
  /// This is useful for clean imports after data iteration/cleanup.
  ///
  /// Returns the path to the temporary file, or null if cancelled/failed.
  Future<String> exportCsv(
    ExpenseSnapshot snapshot, {
    String? accountName,
    bool pulsesOnly = false,
    bool timelineOnly = false,
    DateTimeRange? dateRange,
  }) async {
    assert(
      !(pulsesOnly && timelineOnly),
      'Cannot set both pulsesOnly and timelineOnly',
    );

    try {
      final csv = await compute(
        (params) {
          return snapshotToCsv(
            params.snapshot,
            accountName: params.accountName,
            pulsesOnly: params.pulsesOnly,
            timelineOnly: params.timelineOnly,
            dateRange: params.dateRange,
          );
        },
        (
          snapshot: snapshot,
          accountName: accountName,
          pulsesOnly: pulsesOnly,
          timelineOnly: timelineOnly,
          dateRange: dateRange,
        ),
      );

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'export').replaceAll(
        RegExp(r'[^a-zA-Z0-9]'),
        '_',
      );
      final suffix = pulsesOnly ? '_pulses' : (timelineOnly ? '_timeline' : '');
      final fileName =
          'expense_stalker_$safeAccountName${suffix}_$timestamp.csv';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(csv);

      debugLog(LogCategory.persistence, 'Exported CSV: ${file.path}');

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: fileName,
        ),
      );

      // Clean up temporary file after sharing
      try {
        await file.delete();
      } catch (deleteError) {
        // Best effort cleanup; log but don't fail the export
        debugLog(
          LogCategory.persistence,
          'Failed to delete temp file: ${file.path}',
          error: deleteError,
        );
      }

      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'CSV export failed',
        error: error,
        stackTrace: stackTrace,
      );
      ErrorTracker.instance.trackException(
        'export',
        'Failed to export CSV file',
        error,
        stackTrace,
        severity: ErrorSeverity.error,
        additionalData: {
          'timelineItems': snapshot.timelineItems.length,
          'pulses': snapshot.pulses.length,
          'pulsesOnly': pulsesOnly,
          'timelineOnly': timelineOnly,
        },
      );
      rethrow;
    }
  }

  /// Exports both Schedule (Timeline) and Actuals (Pulses) as separate CSV files.
  /// This is a debug tool to help users verify their data consistency.
  Future<void> exportDebugSuite(
    ExpenseSnapshot snapshot, {
    String? accountName,
    DateTimeRange? dateRange,
  }) async {
    // 1. Export Timeline (Schedule)
    await exportCsv(
      snapshot,
      accountName: accountName,
      timelineOnly: true,
      dateRange: dateRange,
    );

    // 2. Export Pulses (Actuals/Imports)
    await exportCsv(
      snapshot,
      accountName: accountName,
      pulsesOnly: true,
      dateRange: dateRange,
    );
  }

  /// Exports a comprehensive debug bundle for AI-assisted troubleshooting.
  ///
  /// The bundle includes:
  /// - App metadata (version, platform, timestamps)
  /// - Timeline items (scheduled/projected transactions)
  /// - Pulses (actual/historical transactions)
  /// - Error history from ErrorTracker
  /// - Debug logs from DebugLogger
  /// - App settings snapshot
  /// - Data consistency analysis
  ///
  /// Returns the path to the exported file.
  Future<String> exportDebugBundle(
    ExpenseSnapshot snapshot,
    AppSettingsStore settings, {
    String? accountName,
    DateTimeRange? dateRange,
  }) async {
    try {
      debugLog(LogCategory.export, 'Starting debug bundle export');

      final now = DateTime.now();
      final acctName =
          accountName ?? snapshot.accountSettings?.name ?? 'Unknown Account';

      // Build the comprehensive debug bundle
      final bundle = await compute(
        _buildDebugBundle,
        _DebugBundleParams(
          snapshot: snapshot,
          settingsJson: SettingsExport.toJson(settings),
          accountName: acctName,
          dateRange: dateRange,
          exportTimestamp: now,
          appVersion: VersionInfo.appVersion,
          gitCommit: VersionInfo.gitCommitHash,
          errorHistory: ErrorTracker.instance.toJson(),
          debugLogs: DebugLogger.instance.toJson(),
        ),
      );

      // Write to temporary file
      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(now);
      final fileName = 'expense_stalker_debug_$timestamp.json';
      final file = File('${tempDir.path}/$fileName');

      final encoded = const JsonEncoder.withIndent('  ').convert(bundle);
      await file.writeAsString(encoded);

      // Share the file
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: 'Expense Stalker Debug Bundle - $timestamp',
        ),
      );

      // Clean up temp file
      try {
        await file.delete();
      } catch (e, st) {
        debugLog(
          LogCategory.persistence,
          'Failed to delete temporary debug bundle file',
          error: e,
          stackTrace: st,
        );
      }

      debugLog(
        LogCategory.export,
        'Debug bundle export completed successfully',
      );
      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.export,
        'Debug bundle export failed',
        error: error,
        stackTrace: stackTrace,
      );
      ErrorTracker.instance.trackException(
        'export',
        'Debug bundle export failed',
        error,
        stackTrace,
      );
      rethrow;
    }
  }

  @visibleForTesting
  static String snapshotToCsv(
    ExpenseSnapshot snapshot, {
    String? accountName,
    bool pulsesOnly = false,
    bool timelineOnly = false,
    DateTimeRange? dateRange,
  }) {
    final buffer = StringBuffer();

    // Metadata Block
    final acctName =
        accountName ?? snapshot.accountSettings?.name ?? 'Unknown Account';
    buffer.writeln('Account Name,$acctName');
    buffer.writeln('Export Date,${DateTime.now().toIso8601String()}');
    if (dateRange != null) {
      final start = dateRange.start.toIso8601String().split('T').first;
      final end = dateRange.end.toIso8601String().split('T').first;
      buffer.writeln('Date Range,$start to $end');
    }
    if (pulsesOnly) {
      buffer.writeln('Export Type,Pulses Only');
    } else if (timelineOnly) {
      buffer.writeln('Export Type,Timeline Only');
    }

    if (snapshot.accountSettings != null) {
      final settings = snapshot.accountSettings!;
      // Add relevant settings
      // Note: We can expand this list as needed
      buffer.writeln(
        'Starting Balance,${(settings.startingBalanceCents / 100).toStringAsFixed(2)}',
      );
      if (settings.paycheckDay != null) {
        buffer.writeln('Paycheck Day,${settings.paycheckDay}');
      }
      buffer.writeln('View Period Mode,${settings.viewPeriodMode.name}');
    }
    buffer.writeln(); // Empty line separator

    if (!pulsesOnly) {
      // Timeline items header and data
      buffer.writeln(
        'Type,Id,Label,Amount,StartDate,Category,Origin,PulseType,Frequency,DayOfMonth,Priority,IsSalary,UseAsPaycheckBoundary,MoneyPotId,Notes,Archived,PausedDate,AutoResumeDate,Subcategory,PaidOffDate,RemainingBalance,OriginalAmount,BalanceCurrency,ExchangeRate',
      );
      for (final item in snapshot.timelineItems) {
        buffer.writeln(_timelineItemToCsvRow(item));
      }
      buffer.writeln(); // Separator between sections
    }

    if (!timelineOnly) {
      // Pulses header and data
      buffer.writeln(
        'Type,Id,Label,Amount,Date,Category,Origin,PulseType,TimelineItemId,IsStandalone,ScheduledDate,ScheduledAmount,AmountVariance,DaysVariance,Priority,MoneyPotId,Notes,Subcategory,IsInternalTransfer',
      );
      for (final pulse in snapshot.pulses) {
        if (dateRange != null) {
          // Check if pulse is before start OR after end (inclusive of end day)
          // We add 1 day to end to make the check exclusive of the NEXT day's midnight
          final endInclusive = dateRange.end.add(const Duration(days: 1));
          if (pulse.date.isBefore(dateRange.start) ||
              !pulse.date.isBefore(endInclusive)) {
            continue;
          }
        }
        buffer.writeln(_pulseEntryToCsvRow(pulse));
      }
    }

    return buffer.toString();
  }

  String _formatTimestamp(DateTime timestamp) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${timestamp.year}-${two(timestamp.month)}-${two(timestamp.day)}_'
        '${two(timestamp.hour)}-${two(timestamp.minute)}';
  }

  static String _timelineItemToCsvRow(TimelineItem item) {
    return [
      'Timeline',
      _escapeCsvField(item.id.value),
      _escapeCsvField(item.label),
      (item.amountMinorUnits / 100).toStringAsFixed(2),
      // Use UTC for consistent round-trip (matches JSON export behavior)
      item.startDate.toUtc().toIso8601String(),
      _escapeCsvField(item.category ?? ''),
      _escapeCsvField(item.origin ?? ''),
      item.type.name,
      item.frequency?.label ?? '',
      item.dayOfMonth.toString(),
      item.priority?.name ?? '',
      item.isSalary.toString(),
      item.useAsPaycheckBoundary.toString(),
      item.moneyPotId?.value ?? '',
      _escapeCsvField(item.notes ?? ''),
      item.archived.toString(),
      item.pausedDate?.toUtc().toIso8601String() ?? '',
      item.autoResumeDate?.toUtc().toIso8601String() ?? '',
      _escapeCsvField(item.subcategory ?? ''),
      item.paidOffDate?.toUtc().toIso8601String() ?? '',
      item.remainingBalanceMinorUnits != null
          ? (item.remainingBalanceMinorUnits! / 100).toStringAsFixed(2)
          : '',
      item.originalAmountMinorUnits != null
          ? (item.originalAmountMinorUnits! / 100).toStringAsFixed(2)
          : '',
      item.balanceCurrency?.name ?? '',
      item.exchangeRate?.toString() ?? '',
    ].join(',');
  }

  static String _pulseEntryToCsvRow(PulseEntry entry) {
    // Calculate variances if scheduled data is available
    final amountVariance = entry.scheduledAmountMinorUnits != null
        ? ((entry.amountMinorUnits - entry.scheduledAmountMinorUnits!) / 100)
              .toStringAsFixed(2)
        : '';
    final daysVariance = entry.scheduledDate != null
        ? entry.date.difference(entry.scheduledDate!).inDays.toString()
        : '';

    return [
      'Pulse',
      _escapeCsvField(entry.id.value),
      _escapeCsvField(entry.label),
      (entry.amountMinorUnits / 100).toStringAsFixed(2),
      // Use UTC for consistent round-trip (matches JSON export behavior)
      entry.date.toUtc().toIso8601String(),
      _escapeCsvField(entry.category ?? ''),
      _escapeCsvField(entry.origin ?? ''),
      entry.type.name,
      entry.timelineItemId?.value ?? '',
      (entry.timelineItemId == null).toString(), // IsStandalone
      entry.scheduledDate?.toUtc().toIso8601String() ?? '',
      entry.scheduledAmountMinorUnits != null
          ? (entry.scheduledAmountMinorUnits! / 100).toStringAsFixed(2)
          : '',
      amountVariance,
      daysVariance,
      entry.priority?.name ?? '',
      entry.moneyPotId?.value ?? '',
      _escapeCsvField(entry.notes ?? ''),
      _escapeCsvField(entry.subcategory ?? ''),
      entry.isInternalTransfer.toString(),
    ].join(',');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Multi-Month Grid CSV Export
  // ─────────────────────────────────────────────────────────────────────────

  /// Exports a multi-month grid view as CSV (rows = items, columns = months).
  ///
  /// Shows which items are paid in each month with an asterisk marker.
  Future<String> exportGridCsv(
    ExpenseSnapshot snapshot, {
    int monthCount = 6,
    String? accountName,
    DateTimeRange? dateRange,
  }) async {
    try {
      final csv = await compute(
        (params) {
          return snapshotToGridCsv(
            params.snapshot,
            monthCount: params.monthCount,
            accountName: params.accountName,
            dateRange: params.dateRange,
          );
        },
        (
          snapshot: snapshot,
          monthCount: monthCount,
          accountName: accountName,
          dateRange: dateRange,
        ),
      );

      final tempDir = await getTemporaryDirectory();
      final timestamp = _formatTimestamp(DateTime.now());
      final safeAccountName = (accountName ?? 'export').replaceAll(
        RegExp(r'[^a-zA-Z0-9]'),
        '_',
      );
      final fileName =
          'expense_stalker_grid_${safeAccountName}_${monthCount}m_$timestamp.csv';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(csv);

      debugLog(LogCategory.persistence, 'Exported Grid CSV: ${file.path}');

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, name: fileName)],
          subject: fileName,
        ),
      );

      // Clean up temporary file after sharing
      try {
        await file.delete();
      } catch (deleteError) {
        // Best effort cleanup; log but don't fail the export
        debugLog(
          LogCategory.persistence,
          'Failed to delete temp file: ${file.path}',
          error: deleteError,
        );
      }

      return file.path;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Grid CSV export failed',
        error: error,
        stackTrace: stackTrace,
      );
      ErrorTracker.instance.trackException(
        'export',
        'Failed to export grid CSV file',
        error,
        stackTrace,
        severity: ErrorSeverity.error,
      );
      rethrow;
    }
  }

  @visibleForTesting
  static String snapshotToGridCsv(
    ExpenseSnapshot snapshot, {
    required int monthCount,
    String? accountName,
    DateTimeRange? dateRange,
    DateTime? referenceDate,
  }) {
    final buffer = StringBuffer();
    final now = referenceDate ?? DateTime.now();

    // Metadata Block
    final acctName =
        accountName ?? snapshot.accountSettings?.name ?? 'Unknown Account';
    buffer.writeln('Account Name,$acctName');
    buffer.writeln('Export Date,${now.toIso8601String()}');
    buffer.writeln('Legend,* = Paid / Past');

    DateTime startMonth;
    int actualMonthCount = monthCount;

    if (dateRange != null) {
      startMonth = DateTime.utc(dateRange.start.year, dateRange.start.month);
      final endMonth = DateTime.utc(dateRange.end.year, dateRange.end.month);
      // Calculate months between start and end (inclusive)
      actualMonthCount =
          (endMonth.year - startMonth.year) * 12 +
          endMonth.month -
          startMonth.month +
          1;

      final startStr = dateRange.start.toIso8601String().split('T').first;
      final endStr = dateRange.end.toIso8601String().split('T').first;
      buffer.writeln('Date Range,$startStr to $endStr');
    } else {
      startMonth = DateTime.utc(now.year, now.month - (monthCount ~/ 2));
    }

    buffer.writeln(); // Empty line separator

    // Generate month headers
    final months = List.generate(
      actualMonthCount,
      (i) => DateTime.utc(startMonth.year, startMonth.month + i),
    );

    // Header row
    buffer.write('Item');
    for (final month in months) {
      final monthName = '${_monthName(month.month)} ${month.year}';
      buffer.write(',');
      buffer.write(_escapeCsvField(monthName));
    }
    buffer.writeln();

    // Create pulse lookup map: itemId -> month -> pulse
    final pulseMap = <TimelineItemId, Map<String, PulseEntry>>{};
    for (final pulse in snapshot.pulses) {
      if (pulse.timelineItemId == null) continue;
      final monthKey = '${pulse.date.year}-${pulse.date.month}';
      pulseMap.putIfAbsent(pulse.timelineItemId!, () => {});
      pulseMap[pulse.timelineItemId!]![monthKey] = pulse;
    }

    // Data rows - one per timeline item
    for (final item in snapshot.timelineItems) {
      if (item.archived) continue; // Skip archived timeline items

      buffer.write(_escapeCsvField(item.label));

      for (final month in months) {
        final shouldAppear = item.shouldAppearInMonth(
          month,
          referenceDate: referenceDate,
        );
        buffer.write(',');

        if (!shouldAppear) {
          buffer.write(''); // Empty cell
          continue;
        }

        final monthKey = '${month.year}-${month.month}';
        final isRecordedPaid =
            pulseMap[item.id]?.containsKey(monthKey) ?? false;

        // Use amount for that specific date if possible, but timeline item recurrence is tricky.
        // Usually amount is constant unless history changes.
        // We can use getAmountForDate(month) to be safe if variable amounts exist.
        final monthlyAmount = item.getAmountForDate(month);

        final amount = (monthlyAmount / 100).toStringAsFixed(2);
        final value = isRecordedPaid ? '$amount*' : amount;
        buffer.write(_escapeCsvField(value));
      }
      buffer.writeln();
    }

    return buffer.toString();
  }

  static String _monthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[month - 1];
  }

  /// Escapes a field for CSV format with formula injection protection.
  ///
  /// Prevents CSV injection attacks by:
  /// - Prefixing fields starting with =, +, -, @, tab, or carriage return with a single quote
  /// - Wrapping fields with commas, quotes, or newlines in quotes
  /// - Doubling existing quotes
  ///
  /// See: https://owasp.org/www-community/attacks/CSV_Injection
  static String _escapeCsvField(String field) {
    if (field.isEmpty) return field;

    String sanitized = field;

    // Formula injection protection: prefix dangerous characters with single quote
    final firstChar = sanitized[0];
    if (firstChar == '=' ||
        firstChar == '+' ||
        firstChar == '-' ||
        firstChar == '@' ||
        firstChar == '\t' ||
        firstChar == '\r') {
      sanitized = "'$sanitized";
    }

    // Standard CSV escaping
    if (sanitized.contains(',') ||
        sanitized.contains('"') ||
        sanitized.contains('\n')) {
      return '"${sanitized.replaceAll('"', '""')}"';
    }

    return sanitized;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Debug Bundle Helpers (for isolate computation)
// ─────────────────────────────────────────────────────────────────────────────

/// Parameters for debug bundle generation in isolate.
class _DebugBundleParams {
  const _DebugBundleParams({
    required this.snapshot,
    required this.settingsJson,
    required this.accountName,
    required this.exportTimestamp,
    required this.appVersion,
    required this.gitCommit,
    required this.errorHistory,
    required this.debugLogs,
    this.dateRange,
  });

  final ExpenseSnapshot snapshot;
  final Map<String, dynamic> settingsJson;
  final String accountName;
  final DateTimeRange? dateRange;
  final DateTime exportTimestamp;
  final String appVersion;
  final String gitCommit;
  final Map<String, dynamic> errorHistory;
  final Map<String, dynamic> debugLogs;
}

/// Builds the debug bundle JSON in an isolate.
Map<String, dynamic> _buildDebugBundle(_DebugBundleParams params) {
  final snapshot = params.snapshot;
  final settings = snapshot.accountSettings;

  // Filter data by date range if specified
  List<TimelineItem> timelineItems = snapshot.timelineItems;
  List<PulseEntry> pulses = snapshot.pulses;

  if (params.dateRange != null) {
    final range = params.dateRange!;
    final endInclusive = range.end.add(const Duration(days: 1));

    pulses = pulses.where((p) {
      return !p.date.isBefore(range.start) && p.date.isBefore(endInclusive);
    }).toList();
  }

  // Generate consistency analysis
  final consistencyReport = _analyzeDataConsistency(timelineItems, pulses);

  return {
    'bundleVersion': 1,
    'bundleType': 'debug_export',
    'exportedAt': params.exportTimestamp.toUtc().toIso8601String(),

    // App Metadata
    'metadata': {
      'appVersion': params.appVersion,
      'gitCommit': params.gitCommit,
      'exportTimestamp': params.exportTimestamp.toUtc().toIso8601String(),
      'exportTimestampLocal': params.exportTimestamp.toIso8601String(),
      'accountName': params.accountName,
      'dateRangeFilter': params.dateRange != null
          ? {
              'start': params.dateRange!.start
                  .toIso8601String()
                  .split('T')
                  .first,
              'end': params.dateRange!.end.toIso8601String().split('T').first,
            }
          : null,
    },

    // Account Settings Snapshot
    'accountSettings': settings != null
        ? {
            'startingBalanceCents': settings.startingBalanceCents,
            'paycheckDay': settings.paycheckDay,
            'viewPeriodMode': settings.viewPeriodMode.name,
          }
        : null,

    // App Settings Snapshot
    'appSettings': params.settingsJson,

    // Data Summary (for quick overview)
    'dataSummary': {
      'timelineItemCount': timelineItems.length,
      'pulseCount': pulses.length,
      'activeTimelineItems': timelineItems.where((t) => !t.archived).length,
      'archivedTimelineItems': timelineItems.where((t) => t.archived).length,
      'standalonePulses': pulses.where((p) => p.timelineItemId == null).length,
      'linkedPulses': pulses.where((p) => p.timelineItemId != null).length,
    },

    // Timeline Items (projected/scheduled)
    'timelineItems': timelineItems.map((item) {
      return {
        'id': item.id.value,
        'label': item.label,
        'amountMinorUnits': item.amountMinorUnits,
        'startDate': item.startDate.toIso8601String().split('T').first,
        'category': item.category,
        'subcategory': item.subcategory,
        'origin': item.origin,
        'type': item.type.name,
        'frequency': item.frequency?.name,
        'dayOfMonth': item.dayOfMonth,
        'priority': item.priority?.name,
        'isSalary': item.isSalary,
        'moneyPotId': item.moneyPotId?.value,
        'archived': item.archived,
        'pausedDate': item.pausedDate?.toIso8601String().split('T').first,
        'autoResumeDate': item.autoResumeDate
            ?.toIso8601String()
            .split('T')
            .first,
        'notes': item.notes,
      };
    }).toList(),

    // Pulses (actual transactions)
    'pulses': pulses.map((pulse) {
      // Calculate variances
      final amountVariance = pulse.scheduledAmountMinorUnits != null
          ? pulse.amountMinorUnits - pulse.scheduledAmountMinorUnits!
          : null;
      final daysVariance = pulse.scheduledDate != null
          ? pulse.date.difference(pulse.scheduledDate!).inDays
          : null;

      return {
        'id': pulse.id.value,
        'label': pulse.label,
        'amountMinorUnits': pulse.amountMinorUnits,
        'date': pulse.date.toIso8601String().split('T').first,
        'category': pulse.category,
        'subcategory': pulse.subcategory,
        'origin': pulse.origin,
        'type': pulse.type.name,
        'timelineItemId': pulse.timelineItemId?.value,
        'isStandalone': pulse.timelineItemId == null,
        'scheduledDate': pulse.scheduledDate
            ?.toIso8601String()
            .split('T')
            .first,
        'scheduledAmountMinorUnits': pulse.scheduledAmountMinorUnits,
        'amountVariance': amountVariance,
        'daysVariance': daysVariance,
        'priority': pulse.priority?.name,
        'moneyPotId': pulse.moneyPotId?.value,
        'notes': pulse.notes,
      };
    }).toList(),

    // Error History
    'errorHistory': params.errorHistory,

    // Debug Logs
    'debugLogs': params.debugLogs,

    // Data Consistency Analysis
    'consistencyAnalysis': consistencyReport,

    // Computed State Traces (for AI-assisted debugging)
    'computedState': tracer.traceComputations(
      timelineItems: timelineItems,
      pulses: pulses,
      referenceDate: params.exportTimestamp,
      projectionMonths: 15, // ~1 year ahead + 3 months back
      startingBalance: settings?.startingBalanceCents ?? 0,
    ),
  };
}

/// Analyzes data consistency between timeline items and pulses.
Map<String, dynamic> _analyzeDataConsistency(
  List<TimelineItem> timelineItems,
  List<PulseEntry> pulses,
) {
  final issues = <Map<String, dynamic>>[];
  final warnings = <Map<String, dynamic>>[];

  // Build a map of timeline items by ID for quick lookup
  final timelineById = {for (final item in timelineItems) item.id: item};

  // Check for orphaned pulses (linked to non-existent timeline items)
  for (final pulse in pulses) {
    if (pulse.timelineItemId != null) {
      if (!timelineById.containsKey(pulse.timelineItemId)) {
        issues.add({
          'type': 'orphaned_pulse',
          'severity': 'warning',
          'pulseId': pulse.id.value,
          'pulseLabel': pulse.label,
          'missingTimelineId': pulse.timelineItemId?.value,
          'description':
              'Pulse references a timeline item that no longer exists',
        });
      }
    }
  }

  // Check for significant variances
  for (final pulse in pulses) {
    // Calculate variance if scheduled amount exists
    if (pulse.scheduledAmountMinorUnits != null) {
      final amountVariance =
          pulse.amountMinorUnits - pulse.scheduledAmountMinorUnits!;
      if (amountVariance.abs() > 1000) {
        warnings.add({
          'type': 'large_amount_variance',
          'severity': 'info',
          'pulseId': pulse.id.value,
          'pulseLabel': pulse.label,
          'varianceMinorUnits': amountVariance,
          'description':
              'Pulse has a large variance from scheduled amount (>${(amountVariance / 100).abs().toStringAsFixed(2)})',
        });
      }
    }

    // Calculate days variance if scheduled date exists
    if (pulse.scheduledDate != null) {
      final daysVariance = pulse.date.difference(pulse.scheduledDate!).inDays;
      if (daysVariance.abs() > 7) {
        warnings.add({
          'type': 'large_date_variance',
          'severity': 'info',
          'pulseId': pulse.id.value,
          'pulseLabel': pulse.label,
          'daysVariance': daysVariance,
          'description':
              'Pulse occurred ${daysVariance.abs()} days from scheduled date',
        });
      }
    }
  }

  // Check for duplicate timeline items (same label, amount, day)
  final seen = <String>{};
  for (final item in timelineItems) {
    if (item.archived) continue;
    final key =
        '${item.label}|${item.amountMinorUnits}|${item.dayOfMonth}|${item.frequency}';
    if (seen.contains(key)) {
      warnings.add({
        'type': 'potential_duplicate',
        'severity': 'info',
        'timelineItemId': item.id.value,
        'label': item.label,
        'description':
            'Timeline item may be a duplicate (same label, amount, day, frequency)',
      });
    }
    seen.add(key);
  }

  return {
    'analysisTimestamp': DateTime.now().toUtc().toIso8601String(),
    'issueCount': issues.length,
    'warningCount': warnings.length,
    'healthScore': _calculateHealthScore(
      issues.length,
      warnings.length,
      pulses.length,
    ),
    'issues': issues,
    'warnings': warnings,
  };
}

/// Calculates a simple health score (0-100) based on issues found.
int _calculateHealthScore(int issueCount, int warningCount, int totalPulses) {
  if (totalPulses == 0) return 100;

  // Issues are weighted more heavily than warnings
  final penalty = (issueCount * 10) + (warningCount * 2);
  final score = 100 - penalty;
  return score.clamp(0, 100);
}
