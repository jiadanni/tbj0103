import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import '../models/course.dart';
import '../models/skill.dart';
import '../models/exercise.dart';

class CourseProvider extends ChangeNotifier {
  Course? _currentCourse;
  Course? get currentCourse => _currentCourse;

  List<String> _availableLanguages = [];
  List<String> get availableLanguages => _availableLanguages;

  Future<void> loadAvailableLanguages() async {
    // In a real app, this would scan the assets directory
    // For now, we'll hardcode available languages
    _availableLanguages = ['spanish', 'french', 'german', 'dutch', 'portuguese', 'japanese', 'chinese'];
    notifyListeners();
  }

  Future<void> loadCourse(String languageCode) async {
    try {
      // Load course.json
      final courseJsonString = await rootBundle.loadString('assets/courses/$languageCode/course.json');
      final courseData = jsonDecode(courseJsonString);

      final String id = courseData['id'];
      final String name = courseData['name'];
      final String targetLanguage = courseData['targetLanguage'];
      final String nativeLanguage = courseData['nativeLanguage'];
      final List<String> skillIds = List<String>.from(courseData['skills']);

      List<Skill> loadedSkills = [];

      for (String skillId in skillIds) {
        // Load skill.json
        final skillJsonString = await rootBundle.loadString('assets/courses/$languageCode/skills/$skillId/skill.json');
        final skillData = jsonDecode(skillJsonString);

        final String skillName = skillData['name'];
        final String skillDescription = skillData['description'];
        final int skillLevel = skillData['level'];
        final List<dynamic> exerciseTypesData = skillData['exerciseTypes'];

        List<Exercise> loadedExercises = [];

        for (var exerciseTypeData in exerciseTypesData) {
          final String exerciseType = exerciseTypeData['type'];
          final int exerciseCount = exerciseTypeData['count'];

          for (int i = 1; i <= exerciseCount; i++) {
            final String exercisePath = 'assets/courses/$languageCode/skills/$skillId/$exerciseType/ex_$i.json';
            final exerciseJsonString = await rootBundle.loadString(exercisePath);
            final exerciseData = jsonDecode(exerciseJsonString);
            loadedExercises.add(Exercise.fromJson(exerciseData));
          }
        }
        loadedSkills.add(Skill(
          id: skillId,
          name: skillName,
          description: skillDescription,
          level: skillLevel,
          exercises: loadedExercises,
        ));
      }

      _currentCourse = Course(
        id: id,
        name: name,
        targetLanguage: targetLanguage,
        nativeLanguage: nativeLanguage,
        skills: loadedSkills,
      );
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading course: $e');
    }
  }

  int getCurrentSkillIndex(Map<String, double> skillMastery) {
    if (_currentCourse == null) return 0;

    for (int i = 0; i < _currentCourse!.skills.length; i++) {
      final skill = _currentCourse!.skills[i];
      final mastery = skillMastery[skill.id] ?? 0.0;
      if (mastery < 100.0) {
        return i;
      }
    }

    return _currentCourse!.skills.length - 1;
  }
}
