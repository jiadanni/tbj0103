// Core Type Definitions for Vektor

export type FormatType = 'tutorial' | 'lecture' | 'documentary' | 'interview' | 'vlog' | 'other';

export interface ContentFilters {
	density: number; // 0-1 slider (light -> deep)
	pace: number; // 0-1 slider (slow -> fast)
	maxDuration: number; // minutes, 0 = unlimited
	formats: FormatType[];
	blockedKeywords: string[];
	allowedChannels: string[];
	qualityThreshold: number; // 0-1 min like ratio
}

export interface UserProfile {
	id: string;
	name: string;
	filters: ContentFilters;
	sources: ('youtube' | 'vimeo')[];
	appearance: {
		theme: 'light' | 'dark' | 'auto';
		layout: 'grid' | 'list';
	};
}

export interface PathVideo {
	id: string;
	source: 'youtube' | 'vimeo';
	sourceId: string;
	title: string;
	duration: number;
	order: number;
	required: boolean;
}

export interface LearningPath {
	id: string;
	title: string;
	description: string;
	objectives: string[];
	keywords: string[];
	difficulty: 'beginner' | 'intermediate' | 'advanced';
	estimatedHours: number;
	videos: PathVideo[];
	progress: {
		completed: string[];
		current: string;
		notes: { [videoId: string]: string };
	};
}

export interface ApiConfig {
	youtube: {
		apiKeys: string[];
		activeKeyIndex: number;
		quotaUsed: number;
		quotaLimit: number;
	};
	vimeo: {
		accessToken: string;
	};
	ai: AIConfig;
}

export interface AIConfig {
	enabled: boolean;
	provider: 'lm_studio' | 'ollama' | 'openrouter' | 'mcp';
	endpoint: string;
	apiKey?: string;
	model: string;
}

export interface VideoMetadata {
	id: string;
	source: 'youtube' | 'vimeo';
	sourceId: string;
	title: string;
	description: string;
	duration: number;
	thumbnail: string;
	channelId: string;
	channelTitle: string;
	publishedAt: string;
	hasTranscript: boolean;
	transcript?: {
		text: string;
		wordCount: number;
	};
	stats?: {
		viewCount: number;
		likeCount: number;
		commentCount: number;
	};
}

export interface ChannelMetadata {
	id: string;
	title: string;
	description: string;
	thumbnail: string;
	customUrl?: string; // e.g. @handle
	stats?: {
		viewCount: number;
		subscriberCount: number;
		videoCount: number;
	};
}

export interface ImportItem {
	type: 'video' | 'channel' | 'playlist';
	id: string;
	title?: string;
	channelId?: string; // For videos
	channelTitle?: string; // For videos
	thumbnail?: string;
	selected: boolean;
	existingProfileIds: string[]; // Profiles this item is already in
}

export interface ChannelMetadata {
	id: string;
	title: string;
	description: string;
	thumbnail: string;
	customUrl?: string; // e.g. @handle
	stats?: {
		viewCount: number;
		subscriberCount: number;
		videoCount: number;
	};
}

export interface ImportItem {
	type: 'video' | 'channel' | 'playlist';
	id: string;
	title?: string;
	channelId?: string; // For videos
	channelTitle?: string; // For videos
	thumbnail?: string;
	selected: boolean;
	existingProfileIds: string[]; // Profiles this item is already in
}

export interface CastDevice {
	id: string;
	name: string;
	type: 'chromecast' | 'dlna' | 'vektor_pwa';
	url?: string;
}

export interface SearchResult {
	videos: VideoMetadata[];
	totalResults: number;
	nextPageToken?: string;
}

export type ApiRequestType = 'search' | 'videoDetails' | 'channelVideos' | 'validation';

export interface ApiRequestRecord {
	id: string;
	timestamp: number;
	type: ApiRequestType;
	endpoint: string;
	quotaCost: number;
	parameters: Record<string, string | number>;
	resultCount?: number;
	success: boolean;
	error?: string;
	responseTime?: number; // in milliseconds
	apiKey?: string; // The API key used for this request
}

export interface ApiRequestStats {
	totalRequests: number;
	totalQuotaUsed: number;
	requestsByType: Record<ApiRequestType, number>;
	quotaByType: Record<ApiRequestType, number>;
	averageResponseTime: number;
	successRate: number;
	requestsToday: number;
	quotaUsedToday: number;
}
