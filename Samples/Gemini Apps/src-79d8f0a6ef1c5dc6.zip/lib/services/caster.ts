// Multi-protocol casting service

import type { CastDevice, PathVideo } from '../types';

export class VektorCaster {
	private devices: CastDevice[] = [];
	private currentSession: any = null;

	/**
	 * Discover available cast devices
	 */
	async discoverDevices(): Promise<CastDevice[]> {
		const devices: CastDevice[] = [];

		// Try Chromecast
		if (this.isChromecastAvailable()) {
			const chromecastDevices = await this.discoverChromecast();
			devices.push(...chromecastDevices);
		}

		// Try DLNA (would require additional library)
		// const dlnaDevices = await this.discoverDLNA();
		// devices.push(...dlnaDevices);

		// Check for Vektor PWA receivers on local network
		// This would require mDNS/Bonjour discovery
		// const pwaDevices = await this.discoverPWAReceivers();
		// devices.push(...pwaDevices);

		this.devices = devices;
		return devices;
	}

	/**
	 * Cast video to a device
	 */
	async castVideo(device: CastDevice, video: PathVideo): Promise<void> {
		switch (device.type) {
			case 'chromecast':
				return this.castToChromecast(device, video);
			case 'dlna':
				return this.castToDLNA(device, video);
			case 'vektor_pwa':
				return this.castToPWA(device, video);
			default:
				throw new Error(`Unsupported device type: ${device.type}`);
		}
	}

	/**
	 * Stop current casting session
	 */
	async stopCasting(): Promise<void> {
		if (this.currentSession) {
			try {
				if (this.currentSession.stop) {
					await this.currentSession.stop();
				}
			} finally {
				this.currentSession = null;
			}
		}
	}

	/**
	 * Get list of discovered devices
	 */
	getDevices(): CastDevice[] {
		return this.devices;
	}

	/**
	 * Check if Chromecast is available
	 */
	private isChromecastAvailable(): boolean {
		return typeof window !== 'undefined' && !!(window as any).chrome?.cast;
	}

	/**
	 * Discover Chromecast devices
	 */
	private async discoverChromecast(): Promise<CastDevice[]> {
		return new Promise((resolve) => {
			const cast = (window as any).chrome?.cast;

			if (!cast) {
				resolve([]);
				return;
			}

			// Initialize Cast API
			const sessionRequest = new cast.SessionRequest(cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID);
			const apiConfig = new cast.ApiConfig(
				sessionRequest,
				() => {}, // session listener
				() => {} // receiver listener
			);

			cast.initialize(
				apiConfig,
				() => {
					// Get available receivers
					const context = cast.framework.CastContext.getInstance();
					const devices: CastDevice[] = [];

					// Note: Chrome Cast API doesn't provide direct device listing
					// Devices are shown in the native browser UI
					// We create a placeholder for the UI to trigger the browser's cast dialog
					if (context) {
						devices.push({
							id: 'chromecast',
							name: 'Cast to TV',
							type: 'chromecast'
						});
					}

					resolve(devices);
				},
				() => {
					resolve([]);
				}
			);
		});
	}

	/**
	 * Cast to Chromecast device
	 */
	private async castToChromecast(device: CastDevice, video: PathVideo): Promise<void> {
		const cast = (window as any).chrome?.cast;

		if (!cast) {
			throw new Error('Chromecast not available');
		}

		return new Promise((resolve, reject) => {
			const sessionRequest = new cast.SessionRequest(cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID);

			cast.requestSession(
				(session: any) => {
					this.currentSession = session;

					// Create media info
					let mediaUrl = '';
					if (video.source === 'youtube') {
						// For YouTube, we can use the direct URL
						// Chromecast will handle YouTube natively
						mediaUrl = `https://www.youtube.com/watch?v=${video.sourceId}`;
					}

					const mediaInfo = new cast.media.MediaInfo(mediaUrl, 'video/mp4');
					mediaInfo.metadata = new cast.media.GenericMediaMetadata();
					mediaInfo.metadata.title = video.title;

					const request = new cast.media.LoadRequest(mediaInfo);

					session.loadMedia(request, resolve, reject);
				},
				(error: any) => {
					reject(new Error(`Cast session failed: ${error.description}`));
				},
				sessionRequest
			);
		});
	}

	/**
	 * Cast to DLNA device (placeholder)
	 */
	private async castToDLNA(device: CastDevice, video: PathVideo): Promise<void> {
		// DLNA would require a server-side component or a third-party library
		// This is a placeholder for future implementation
		throw new Error('DLNA casting not yet implemented');
	}

	/**
	 * Cast to Vektor PWA receiver
	 */
	private async castToPWA(device: CastDevice, video: PathVideo): Promise<void> {
		if (!device.url) {
			throw new Error('PWA device URL not specified');
		}

		const response = await fetch(`${device.url}/api/play`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({
				video,
				source: video.source
			})
		});

		if (!response.ok) {
			throw new Error('Failed to cast to PWA receiver');
		}

		this.currentSession = { device, video };
	}

	/**
	 * Discover PWA receivers (placeholder)
	 */
	private async discoverPWAReceivers(): Promise<CastDevice[]> {
		// This would require mDNS/Bonjour discovery or WebRTC
		// Placeholder for future implementation
		return [];
	}
}

export const caster = new VektorCaster();
