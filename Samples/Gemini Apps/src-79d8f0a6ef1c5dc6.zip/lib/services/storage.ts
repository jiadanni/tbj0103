// IndexedDB storage service using localForage

import localforage from 'localforage';
import type { UserProfile, LearningPath, ApiConfig, ApiRequestRecord } from '../types';
import { STORAGE_KEYS, DEFAULT_PROFILE } from '../utils/constants';
import { generateId } from '../utils/helpers';
import {
	UserProfileSchema,
	LearningPathSchema,
	ApiConfigSchema,
	ExportDataSchema
} from '../schemas';
import { ValidationError, StorageError } from '../utils/errors';

// Configure localforage
localforage.config({
	name: 'Vektor',
	version: 1.0,
	storeName: 'vektor_store',
	description: 'Vektor app storage'
});

export class StorageService {
	// API Configuration
	async getApiConfig(): Promise<ApiConfig | null> {
		return await localforage.getItem(STORAGE_KEYS.API_CONFIG);
	}

	async setApiConfig(config: ApiConfig): Promise<void> {
		try {
			const validated = ApiConfigSchema.parse(config);
			await localforage.setItem(STORAGE_KEYS.API_CONFIG, validated);
		} catch (error) {
			throw new ValidationError('Invalid API configuration', error);
		}
	}

	// API Request History
	async getApiHistory(): Promise<ApiRequestRecord[]> {
		const history = await localforage.getItem<ApiRequestRecord[]>(STORAGE_KEYS.API_HISTORY);
		return history || [];
	}

	async setApiHistory(history: ApiRequestRecord[]): Promise<void> {
		await localforage.setItem(STORAGE_KEYS.API_HISTORY, history);
	}

	// Profiles
	async getProfiles(): Promise<UserProfile[]> {
		const profiles = await localforage.getItem<UserProfile[]>(STORAGE_KEYS.PROFILES);
		return profiles || [];
	}

	async getProfile(id: string): Promise<UserProfile | null> {
		const profiles = await this.getProfiles();
		return profiles.find((p) => p.id === id) || null;
	}

	async saveProfile(profile: UserProfile): Promise<void> {
		try {
			const validated = UserProfileSchema.parse(profile);
			const profiles = await this.getProfiles();
			const index = profiles.findIndex((p) => p.id === validated.id);

			if (index >= 0) {
				profiles[index] = validated;
			} else {
				profiles.push(validated);
			}

			await localforage.setItem(STORAGE_KEYS.PROFILES, profiles);
		} catch (error) {
			throw new ValidationError('Invalid profile data', error);
		}
	}

	async deleteProfile(id: string): Promise<void> {
		const profiles = await this.getProfiles();
		const filtered = profiles.filter((p) => p.id !== id);
		await localforage.setItem(STORAGE_KEYS.PROFILES, filtered);
	}

	async getActiveProfile(): Promise<UserProfile> {
		const activeId = await localforage.getItem<string>(STORAGE_KEYS.ACTIVE_PROFILE);

		if (activeId) {
			const profile = await this.getProfile(activeId);
			if (profile) return profile;
		}

		// Return or create default profile
		const profiles = await this.getProfiles();
		if (profiles.length > 0) {
			await this.setActiveProfile(profiles[0].id);
			return profiles[0];
		}

		const defaultProfile: UserProfile = {
			...DEFAULT_PROFILE,
			id: generateId()
		};

		await this.saveProfile(defaultProfile);
		await this.setActiveProfile(defaultProfile.id);
		return defaultProfile;
	}

	async setActiveProfile(id: string): Promise<void> {
		await localforage.setItem(STORAGE_KEYS.ACTIVE_PROFILE, id);
	}

	// Learning Paths
	async getLearningPaths(): Promise<LearningPath[]> {
		const paths = await localforage.getItem<LearningPath[]>(STORAGE_KEYS.LEARNING_PATHS);
		return paths || [];
	}

	async getLearningPath(id: string): Promise<LearningPath | null> {
		const paths = await this.getLearningPaths();
		return paths.find((p) => p.id === id) || null;
	}

	async saveLearningPath(path: LearningPath): Promise<void> {
		try {
			const validated = LearningPathSchema.parse(path);
			const paths = await this.getLearningPaths();
			const index = paths.findIndex((p) => p.id === validated.id);

			if (index >= 0) {
				paths[index] = validated;
			} else {
				paths.push(validated);
			}

			await localforage.setItem(STORAGE_KEYS.LEARNING_PATHS, paths);
		} catch (error) {
			throw new ValidationError('Invalid learning path data', error);
		}
	}

	async deleteLearningPath(id: string): Promise<void> {
		const paths = await this.getLearningPaths();
		const filtered = paths.filter((p) => p.id !== id);
		await localforage.setItem(STORAGE_KEYS.LEARNING_PATHS, filtered);
	}

	// Import/Export
	async exportAll(): Promise<string> {
		const data = {
			profiles: await this.getProfiles(),
			paths: await this.getLearningPaths(),
			settings: await localforage.getItem(STORAGE_KEYS.SETTINGS),
			version: '1.0'
		};

		return JSON.stringify(data, null, 2);
	}

	async importAll(jsonData: string): Promise<void> {
		try {
			const data = JSON.parse(jsonData);

			// Validate the entire import structure
			const validated = ExportDataSchema.parse(data);

			// Validate each profile individually
			if (validated.profiles) {
				const validatedProfiles = validated.profiles.map((p) => UserProfileSchema.parse(p));
				await localforage.setItem(STORAGE_KEYS.PROFILES, validatedProfiles);
			}

			// Validate each learning path individually
			if (validated.paths) {
				const validatedPaths = validated.paths.map((p) => LearningPathSchema.parse(p));
				await localforage.setItem(STORAGE_KEYS.LEARNING_PATHS, validatedPaths);
			}

			if (validated.settings) {
				await localforage.setItem(STORAGE_KEYS.SETTINGS, validated.settings);
			}
		} catch (error) {
			if (error instanceof SyntaxError) {
				throw new ValidationError('Invalid JSON format in import data');
			}
			throw new ValidationError('Invalid import data structure', error);
		}
	}

	async clearAll(): Promise<void> {
		await localforage.clear();
	}
}

export const storage = new StorageService();
