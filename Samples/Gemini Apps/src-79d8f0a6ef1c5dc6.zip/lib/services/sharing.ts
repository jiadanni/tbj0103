// Profile and learning path sharing service

import type { UserProfile, LearningPath } from '../types';
import { compressData, decompressData } from '../utils/helpers';

export class ProfileSharing {
	/**
	 * Export a profile to JSON (removes sensitive data)
	 */
	exportProfile(profile: UserProfile): string {
		const exportData = {
			name: profile.name,
			filters: profile.filters,
			sources: profile.sources,
			appearance: profile.appearance,
			version: '1.0',
			type: 'vektor-profile'
		};

		return JSON.stringify(exportData, null, 2);
	}

	/**
	 * Import a profile from JSON
	 */
	importProfile(jsonData: string): Omit<UserProfile, 'id'> {
		try {
			const data = JSON.parse(jsonData);

			if (data.type !== 'vektor-profile') {
				throw new Error('Invalid profile format');
			}

			return {
				name: data.name || 'Imported Profile',
				filters: data.filters,
				sources: data.sources || ['youtube'],
				appearance: data.appearance || {
					theme: 'auto',
					layout: 'grid'
				}
			};
		} catch (error) {
			throw new Error(`Failed to import profile: ${error}`);
		}
	}

	/**
	 * Export a learning path to JSON
	 */
	exportLearningPath(path: LearningPath): string {
		const exportData = {
			title: path.title,
			description: path.description,
			objectives: path.objectives,
			keywords: path.keywords,
			difficulty: path.difficulty,
			estimatedHours: path.estimatedHours,
			videos: path.videos,
			version: '1.0',
			type: 'vektor-learning-path'
		};

		return JSON.stringify(exportData, null, 2);
	}

	/**
	 * Import a learning path from JSON
	 */
	importLearningPath(jsonData: string): Omit<LearningPath, 'id'> {
		try {
			const data = JSON.parse(jsonData);

			if (data.type !== 'vektor-learning-path') {
				throw new Error('Invalid learning path format');
			}

			return {
				title: data.title || 'Imported Path',
				description: data.description || '',
				objectives: data.objectives || [],
				keywords: data.keywords || [],
				difficulty: data.difficulty || 'beginner',
				estimatedHours: data.estimatedHours || 0,
				videos: data.videos || [],
				progress: {
					completed: [],
					current: '',
					notes: {}
				}
			};
		} catch (error) {
			throw new Error(`Failed to import learning path: ${error}`);
		}
	}

	/**
	 * Generate a shareable URL for a learning path
	 */
	generateShareableLink(path: LearningPath): string {
		const compressed = compressData({
			title: path.title,
			description: path.description,
			videos: path.videos.slice(0, 20) // Limit to avoid URL length issues
		});

		const baseUrl =
			typeof window !== 'undefined' ? window.location.origin : 'https://vektor.app';

		return `${baseUrl}/path/${compressed}`;
	}

	/**
	 * Parse a shareable link
	 */
	parseShareableLink(url: string): Partial<LearningPath> | null {
		try {
			const urlObj = new URL(url);
			const pathParts = urlObj.pathname.split('/');

			if (pathParts[1] !== 'path' || !pathParts[2]) {
				return null;
			}

			const compressed = pathParts[2];
			const data = decompressData(compressed);

			if (!data) {
				return null;
			}

			return data;
		} catch (error) {
			console.error('Failed to parse shareable link:', error);
			return null;
		}
	}

	/**
	 * Download data as a file
	 */
	downloadAsFile(data: string, filename: string): void {
		const blob = new Blob([data], { type: 'application/json' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');

		link.href = url;
		link.download = filename;
		link.click();

		URL.revokeObjectURL(url);
	}

	/**
	 * Read file contents
	 */
	async readFile(file: File): Promise<string> {
		return new Promise((resolve, reject) => {
			const reader = new FileReader();

			reader.onload = (e) => {
				const content = e.target?.result as string;
				resolve(content);
			};

			reader.onerror = () => {
				reject(new Error('Failed to read file'));
			};

			reader.readAsText(file);
		});
	}
}

export const sharing = new ProfileSharing();
