import type { ImportItem, ChannelMetadata } from '../types';
import { YouTubeClient } from '../engines/youtube';

export interface ImportPreview {
    items: ImportItem[];
    totalCount: number;
    sources: ('file' | 'manual' | 'api')[];
}

/**
 * Service to handle importing data from various sources
 */
export class ImportService {
    constructor(private client: YouTubeClient) { }

    /**
     * Parse manual text input (URLs, IDs)
     */
    async parseManualInput(text: string): Promise<ImportItem[]> {
        const lines = text.split(/[\n,]+/).map(l => l.trim()).filter(l => l);
        const channelIds = new Set<string>();
        const videoIds = new Set<string>();

        for (const line of lines) {
            // Check for full URLs
            try {
                const url = new URL(line);
                if (url.hostname.includes('youtube.com') || url.hostname.includes('youtu.be')) {
                    // Channel URL
                    if (url.pathname.startsWith('/channel/')) {
                        channelIds.add(url.pathname.split('/')[2]);
                    }
                    // Handle URL (@username) - requires API search to resolve, skipping for now basic ID support
                    else if (url.pathname.startsWith('/@')) {
                        // TODO: Resolve handle to ID
                    }
                    // Video URL
                    else if (url.pathname === '/watch' && url.searchParams.get('v')) {
                        videoIds.add(url.searchParams.get('v')!);
                    } else if (url.hostname === 'youtu.be') {
                        videoIds.add(url.pathname.substring(1));
                    }
                }
            } catch {
                // Not a URL, check if ID format
                if (line.startsWith('UC') && line.length > 20) {
                    channelIds.add(line);
                } else if (line.length === 11) {
                    videoIds.add(line);
                }
            }
        }

        const items: ImportItem[] = [];

        // Fetch details for channels
        if (channelIds.size > 0) {
            const channels = await this.client.getChannelDetails(Array.from(channelIds));
            items.push(...channels.map(c => ({
                type: 'channel' as const,
                id: c.id,
                title: c.title,
                thumbnail: c.thumbnail,
                selected: true,
                existingProfileIds: []
            })));
        }

        // Fetch details for videos
        if (videoIds.size > 0) {
            const videos = await this.client.getVideoDetails(Array.from(videoIds).join(','));
            items.push(...videos.map(v => ({
                type: 'video' as const,
                id: v.id,
                title: v.title,
                channelId: v.channelId,
                channelTitle: v.channelTitle,
                thumbnail: v.thumbnail,
                selected: true,
                existingProfileIds: []
            })));
        }

        return items;
    }

    /**
     * Parse Google Takeout CSV/JSON
     */
    async parseTakeout(file: File): Promise<ImportItem[]> {
        const text = await file.text();
        const items: ImportItem[] = [];

        // Simple CSV detection (Subscriptions)
        if (file.name.endsWith('.csv')) {
            // Takeout format: "Channel Id","Channel Url","Channel Title"
            const lines = text.split('\n');
            const ids = new Set<string>();

            for (let i = 1; i < lines.length; i++) { // Skip header
                const cols = lines[i].split(',');
                if (cols.length >= 3) {
                    const id = cols[0].replace(/"/g, '').trim();
                    if (id.startsWith('UC')) ids.add(id);
                }
            }

            if (ids.size > 0) {
                // We fetch details to ensure they still exist and get fresh avatars
                // Batch in chunks of 50
                const idArray = Array.from(ids);
                for (let i = 0; i < idArray.length; i += 50) {
                    const chunk = idArray.slice(i, i + 50);
                    const channels = await this.client.getChannelDetails(chunk);
                    items.push(...channels.map(c => ({
                        type: 'channel' as const,
                        id: c.id,
                        title: c.title,
                        thumbnail: c.thumbnail,
                        selected: true,
                        existingProfileIds: []
                    })));
                }
            }
        }

        // Likes JSON
        if (file.name.endsWith('.json')) {
            try {
                const data = JSON.parse(text);
                if (Array.isArray(data)) {
                    // Look for videoId or contentDetails.videoId
                    const videoIds = data
                        .map((item: any) => item.contentDetails?.videoId || item.snippet?.resourceId?.videoId)
                        .filter(id => typeof id === 'string');

                    // Batch fetch details
                    for (let i = 0; i < videoIds.length; i += 50) {
                        const chunk = videoIds.slice(i, i + 50).join(',');
                        const videos = await this.client.getVideoDetails(chunk);
                        items.push(...videos.map(v => ({
                            type: 'video' as const,
                            id: v.id,
                            title: v.title,
                            channelId: v.channelId,
                            channelTitle: v.channelTitle,
                            thumbnail: v.thumbnail,
                            selected: true,
                            existingProfileIds: []
                        })));
                    }
                }
            } catch (e) {
                console.error('Failed to parse JSON', e);
                throw new Error('Invalid JSON file');
            }
        }

        return items;
    }

    /**
     * Fetch from Connected API Account
     */
    async fetchFromApi(type: 'likes' | 'subscriptions'): Promise<ImportItem[]> {
        if (type === 'likes') {
            const res = await this.client.getLikedVideos(50); // Get most recent 50
            return res.videos.map(v => ({
                type: 'video' as const,
                id: v.id,
                title: v.title,
                channelId: v.channelId,
                channelTitle: v.channelTitle,
                thumbnail: v.thumbnail,
                selected: true,
                existingProfileIds: []
            }));
        }

        if (type === 'subscriptions') {
            const channels = await this.client.getSubscriptions(50);
            return channels.map(c => ({
                type: 'channel' as const,
                id: c.id,
                title: c.title,
                thumbnail: c.thumbnail,
                selected: true,
                existingProfileIds: []
            }));
        }

        return [];
    }
}
