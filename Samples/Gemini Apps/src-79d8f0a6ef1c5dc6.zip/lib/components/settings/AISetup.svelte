<script lang="ts">
	import { settings } from '$lib/stores/settings';
	import { AIService } from '$lib/engines/ai';
	import type { AIConfig } from '$lib/types';

	let enabled = false;
	let provider: AIConfig['provider'] = 'lm_studio';
	let endpoint = 'http://localhost:1234';
	let apiKey = '';
	let model = 'local-model';
	let validating = false;
	let isValid: boolean | null = null;

	$: if ($settings) {
		enabled = $settings.ai.enabled;
		provider = $settings.ai.provider;
		endpoint = $settings.ai.endpoint;
		apiKey = $settings.ai.apiKey || '';
		model = $settings.ai.model;
	}

	function handleProviderChange() {
		switch (provider) {
			case 'lm_studio':
				endpoint = 'http://localhost:1234';
				apiKey = '';
				break;
			case 'ollama':
				endpoint = 'http://localhost:11434';
				apiKey = '';
				break;
			case 'openrouter':
				endpoint = 'https://openrouter.ai/api/v1';
				break;
			case 'mcp':
				endpoint = 'http://localhost:3000';
				break;
		}
	}

	async function validateAndSave() {
		validating = true;
		isValid = null;

		try {
			const config: AIConfig = {
				enabled: true,
				provider,
				endpoint,
				apiKey: apiKey || undefined,
				model
			};

			const aiService = new AIService(config);
			isValid = await aiService.validateConfig();

			if (isValid) {
				await settings.updateAIConfig(config);
			}
		} catch (error) {
			isValid = false;
		} finally {
			validating = false;
		}
	}

	async function toggleEnabled() {
		enabled = !enabled;
		await settings.updateAIConfig({ enabled });
	}
</script>

<div class="space-y-6">
	<div>
		<h2 class="text-2xl font-bold mb-4">AI Integration (Optional)</h2>
		<p class="text-gray-600 dark:text-gray-400 mb-6">
			Enable AI-powered features like enhanced search and automatic learning path generation. Works
			with local LLMs (LM Studio, Ollama) or cloud services.
		</p>
	</div>

	<!-- Enable/Disable Toggle -->
	<div class="card">
		<div class="flex items-center justify-between">
			<div>
				<h3 class="text-lg font-semibold">Enable AI Features</h3>
				<p class="text-sm text-gray-600 dark:text-gray-400">
					Use AI to enhance your content discovery experience
				</p>
			</div>
			<button
				class="relative inline-flex h-6 w-11 items-center rounded-full transition-colors {enabled
					? 'bg-primary-600'
					: 'bg-gray-300 dark:bg-gray-600'}"
				on:click={toggleEnabled}
			>
				<span
					class="inline-block h-4 w-4 transform rounded-full bg-white transition-transform {enabled
						? 'translate-x-6'
						: 'translate-x-1'}"
				></span>
			</button>
		</div>
	</div>

	{#if enabled}
		<div class="card space-y-4">
			<h3 class="text-xl font-semibold">AI Provider Configuration</h3>

			<!-- Provider Selection -->
			<div>
				<label class="block text-sm font-medium mb-2">Provider</label>
				<select bind:value={provider} on:change={handleProviderChange} class="input">
					<option value="lm_studio">LM Studio (Local)</option>
					<option value="ollama">Ollama (Local)</option>
					<option value="openrouter">OpenRouter (Cloud)</option>
					<option value="mcp">MCP Server</option>
				</select>
			</div>

			<!-- Endpoint -->
			<div>
				<label class="block text-sm font-medium mb-2">Endpoint URL</label>
				<input type="text" bind:value={endpoint} class="input" placeholder="http://localhost:1234" />
			</div>

			<!-- API Key (for cloud services) -->
			{#if provider === 'openrouter' || provider === 'mcp'}
				<div>
					<label class="block text-sm font-medium mb-2">API Key</label>
					<input type="password" bind:value={apiKey} class="input" placeholder="Your API key" />
				</div>
			{/if}

			<!-- Model -->
			<div>
				<label class="block text-sm font-medium mb-2">Model</label>
				<input
					type="text"
					bind:value={model}
					class="input"
					placeholder="Model name (e.g., llama-3.1-8b)"
				/>
			</div>

			<!-- Validate Button -->
			<button class="btn btn-primary" on:click={validateAndSave} disabled={validating}>
				{#if validating}
					Validating...
				{:else}
					Validate & Save
				{/if}
			</button>

			{#if isValid === true}
				<div class="text-green-600 dark:text-green-400 text-sm">AI configuration is valid!</div>
			{:else if isValid === false}
				<div class="text-red-600 dark:text-red-400 text-sm">
					Could not connect to AI service. Please check your configuration.
				</div>
			{/if}
		</div>

		<!-- Setup Guides -->
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Setup Guides</h3>

			<details class="mb-4">
				<summary class="cursor-pointer text-sm text-primary-600 dark:text-primary-400">
					LM Studio Setup
				</summary>
				<div class="mt-2 text-sm text-gray-600 dark:text-gray-400 space-y-2">
					<ol class="list-decimal list-inside space-y-1">
						<li>Download and install LM Studio from <a
								href="https://lmstudio.ai"
								target="_blank"
								class="underline">lmstudio.ai</a
							></li>
						<li>Download a model (e.g., Llama 3.1 8B)</li>
						<li>Start the local server in LM Studio</li>
						<li>Use endpoint: http://localhost:1234</li>
					</ol>
				</div>
			</details>

			<details>
				<summary class="cursor-pointer text-sm text-primary-600 dark:text-primary-400">
					Ollama Setup
				</summary>
				<div class="mt-2 text-sm text-gray-600 dark:text-gray-400 space-y-2">
					<ol class="list-decimal list-inside space-y-1">
						<li>Install Ollama from <a href="https://ollama.ai" target="_blank" class="underline"
								>ollama.ai</a
							></li>
						<li>Run: <code class="bg-gray-200 dark:bg-gray-700 px-1 rounded">ollama pull llama2</code
							></li>
						<li>Start Ollama service</li>
						<li>Use endpoint: http://localhost:11434</li>
					</ol>
				</div>
			</details>
		</div>
	{/if}
</div>
