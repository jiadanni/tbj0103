<script lang="ts">
	export let rows: number = 5;
</script>

<div class="space-y-4 animate-pulse">
	{#each Array(rows) as _, i (i)}
		<div class="card">
			<div class="p-4 space-y-3">
				<div class="flex items-start gap-4">
					<!-- Number skeleton -->
					<div class="w-8 h-8 bg-gray-300 dark:bg-gray-700 rounded"></div>

					<div class="flex-1 space-y-2">
						<!-- Title skeleton -->
						<div class="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
						<!-- Duration skeleton -->
						<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-24"></div>
					</div>

					<!-- Buttons skeleton -->
					<div class="flex flex-col gap-2">
						<div class="w-20 h-8 bg-gray-300 dark:bg-gray-700 rounded"></div>
						<div class="w-20 h-8 bg-gray-300 dark:bg-gray-700 rounded"></div>
					</div>
				</div>
			</div>
		</div>
	{/each}
</div>
