<script lang="ts">
	import { onMount, onDestroy } from 'svelte';

	import { browser } from '$app/environment';

	export let fallback: string = 'Something went wrong. Please try again.';

	let error: Error | null = null;
	let errorInfo: any = null;

	function handleError(event: ErrorEvent) {
		event.preventDefault();
		error = event.error;
		console.error('Error caught by boundary:', error);
	}

	function handleUnhandledRejection(event: PromiseRejectionEvent) {
		event.preventDefault();
		error = new Error(event.reason?.message || 'Unhandled promise rejection');
		console.error('Unhandled rejection caught:', event.reason);
	}

	function reset() {
		error = null;
		errorInfo = null;
	}

	onMount(() => {
		if (browser) {
			window.addEventListener('error', handleError);
			window.addEventListener('unhandledrejection', handleUnhandledRejection);
		}
	});

	onDestroy(() => {
		if (browser) {
			window.removeEventListener('error', handleError);
			window.removeEventListener('unhandledrejection', handleUnhandledRejection);
		}
	});
</script>

{#if error}
	<div class="min-h-screen flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-900">
		<div class="max-w-2xl w-full">
			<div class="card border-2 border-red-500">
				<div class="text-center mb-6">
					<svg
						class="w-16 h-16 text-red-500 mx-auto mb-4"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
						/>
					</svg>
					<h1 class="text-2xl font-bold text-red-600 dark:text-red-400 mb-2">
						Oops! Something went wrong
					</h1>
					<p class="text-gray-600 dark:text-gray-400">
						{fallback}
					</p>
				</div>

				{#if error.message}
					<div class="mb-6">
						<h3 class="font-semibold mb-2">Error Details:</h3>
						<div class="p-4 bg-gray-100 dark:bg-gray-800 rounded font-mono text-sm overflow-x-auto">
							{error.message}
						</div>
					</div>
				{/if}

				{#if error.stack}
					<details class="mb-6">
						<summary class="cursor-pointer text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
							Show stack trace
						</summary>
						<div class="mt-2 p-4 bg-gray-100 dark:bg-gray-800 rounded font-mono text-xs overflow-x-auto">
							<pre>{error.stack}</pre>
						</div>
					</details>
				{/if}

				<div class="flex gap-4">
					<button class="btn btn-primary flex-1" on:click={reset}>
						Try Again
					</button>
					<button
						class="btn btn-secondary"
						on:click={() => window.location.reload()}
					>
						Reload Page
					</button>
				</div>

				<div class="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded">
					<h3 class="font-semibold mb-2 text-blue-800 dark:text-blue-300">
						💡 Troubleshooting Tips:
					</h3>
					<ul class="text-sm space-y-1 text-blue-700 dark:text-blue-300">
						<li>• Check if your API keys are configured correctly</li>
						<li>• Make sure you have an active internet connection</li>
						<li>• Try clearing your browser cache and data</li>
						<li>• Check the browser console for more details (F12)</li>
						<li>• If the problem persists, try exporting your data and clearing storage</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
{:else}
	<slot />
{/if}
