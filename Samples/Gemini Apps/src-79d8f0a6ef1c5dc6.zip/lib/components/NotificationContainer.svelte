<script lang="ts">
	import { notifications } from '$lib/stores/notifications';
	import ErrorToast from './ErrorToast.svelte';
</script>

<div class="fixed top-4 right-4 z-50 space-y-2">
	{#each $notifications as notification (notification.id)}
		<ErrorToast
			message={notification.message}
			type={notification.type}
			duration={notification.duration || 5000}
			onClose={() => notifications.dismiss(notification.id)}
		/>
	{/each}
</div>
