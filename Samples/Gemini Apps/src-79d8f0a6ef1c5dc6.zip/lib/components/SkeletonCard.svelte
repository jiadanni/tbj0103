<script lang="ts">
	export let count: number = 3;
</script>

<div class="grid gap-6 {count === 1 ? 'grid-cols-1' : count === 2 ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}">
	{#each Array(count) as _, i (i)}
		<div class="card animate-pulse">
			<!-- Thumbnail skeleton -->
			<div class="w-full h-48 bg-gray-300 dark:bg-gray-700 rounded-t-lg"></div>

			<div class="p-4 space-y-3">
				<!-- Title skeleton -->
				<div class="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
				<div class="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/2"></div>

				<!-- Channel skeleton -->
				<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-2/5"></div>

				<!-- Stats skeleton -->
				<div class="flex gap-4">
					<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-20"></div>
					<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-20"></div>
				</div>

				<!-- Description skeleton -->
				<div class="space-y-2">
					<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
					<div class="h-3 bg-gray-300 dark:bg-gray-700 rounded w-4/5"></div>
				</div>

				<!-- Button skeleton -->
				<div class="h-10 bg-gray-300 dark:bg-gray-700 rounded"></div>
			</div>
		</div>
	{/each}
</div>
