<script lang="ts">
	import { createEventDispatcher } from 'svelte';

	export let show = false;
	export let title = 'Confirm Action';
	export let message = 'Are you sure you want to proceed?';
	export let confirmText = 'Confirm';
	export let cancelText = 'Cancel';
	export let confirmClass = 'btn-primary';
	export let danger = false;

	const dispatch = createEventDispatcher();

	function handleConfirm() {
		dispatch('confirm');
		show = false;
	}

	function handleCancel() {
		dispatch('cancel');
		show = false;
	}

	function handleBackdropClick(e: MouseEvent) {
		if (e.target === e.currentTarget) {
			handleCancel();
		}
	}
</script>

{#if show}
	<div
		class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
		on:click={handleBackdropClick}
		on:keydown={(e) => e.key === 'Escape' && handleCancel()}
		role="button"
		tabindex="-1"
		aria-label="Close"
	>
		<div class="card max-w-md w-full">
			<div class="flex items-start gap-4 mb-6">
				{#if danger}
					<div class="flex-shrink-0">
						<svg
							class="w-12 h-12 text-red-500"
							fill="none"
							stroke="currentColor"
							viewBox="0 0 24 24"
						>
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								stroke-width="2"
								d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
							/>
						</svg>
					</div>
				{:else}
					<div class="flex-shrink-0">
						<svg
							class="w-12 h-12 text-blue-500"
							fill="none"
							stroke="currentColor"
							viewBox="0 0 24 24"
						>
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								stroke-width="2"
								d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
							/>
						</svg>
					</div>
				{/if}

				<div class="flex-1">
					<h2 class="text-xl font-bold mb-2">{title}</h2>
					<p class="text-gray-700 dark:text-gray-300">{message}</p>
				</div>
			</div>

			<div class="flex gap-3">
				<button class="btn btn-secondary flex-1" on:click={handleCancel}>
					{cancelText}
				</button>
				<button
					class="btn flex-1 {danger ? 'bg-red-600 hover:bg-red-700 text-white' : confirmClass}"
					on:click={handleConfirm}
				>
					{confirmText}
				</button>
			</div>
		</div>
	</div>
{/if}
