<script lang="ts">
	import { keyboardManager } from '$lib/utils/keyboard';
	import type { KeyboardShortcut } from '$lib/utils/keyboard';

	export let show = false;

	$: shortcuts = keyboardManager.getShortcuts();

	function close() {
		show = false;
	}

	function handleBackdropClick(e: MouseEvent) {
		if (e.target === e.currentTarget) {
			close();
		}
	}
</script>

{#if show}
	<div
		class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
		on:click={handleBackdropClick}
		on:keydown={(e) => e.key === 'Escape' && close()}
		role="button"
		tabindex="-1"
		aria-label="Close"
	>
		<div class="card max-w-2xl w-full max-h-[80vh] overflow-y-auto">
			<div class="flex items-center justify-between mb-6">
				<h2 class="text-2xl font-bold">Keyboard Shortcuts</h2>
				<button
					class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
					on:click={close}
				>
					<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M6 18L18 6M6 6l12 12"
						/>
					</svg>
				</button>
			</div>

			<div class="space-y-2">
				{#each shortcuts as shortcut}
					<div class="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700 last:border-0">
						<span class="text-gray-700 dark:text-gray-300">{shortcut.description}</span>
						<kbd class="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded font-mono text-sm">
							{keyboardManager.constructor.formatShortcut(shortcut)}
						</kbd>
					</div>
				{/each}

				{#if shortcuts.length === 0}
					<p class="text-gray-500 text-center py-8">No keyboard shortcuts registered</p>
				{/if}
			</div>

			<div class="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded">
				<p class="text-sm text-blue-800 dark:text-blue-300">
					<strong>Tip:</strong> Press <kbd class="px-2 py-1 bg-blue-100 dark:bg-blue-800 rounded text-xs">?</kbd>
					at any time to view this help
				</p>
			</div>
		</div>
	</div>
{/if}
