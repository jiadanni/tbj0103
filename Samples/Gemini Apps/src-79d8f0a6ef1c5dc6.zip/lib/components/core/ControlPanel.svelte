<script lang="ts">
	import { activeProfile } from '$lib/stores/profiles';
	import type { FormatType } from '$lib/types';

	const formatOptions: FormatType[] = ['tutorial', 'lecture', 'documentary', 'interview', 'vlog'];

	function handleDensityChange(e: Event) {
		const target = e.target as HTMLInputElement;
		if ($activeProfile) {
			$activeProfile.filters.density = parseFloat(target.value);
		}
	}

	function handlePaceChange(e: Event) {
		const target = e.target as HTMLInputElement;
		if ($activeProfile) {
			$activeProfile.filters.pace = parseFloat(target.value);
		}
	}

	function handleMaxDurationChange(e: Event) {
		const target = e.target as HTMLInputElement;
		if ($activeProfile) {
			$activeProfile.filters.maxDuration = parseInt(target.value);
		}
	}

	function handleFormatToggle(format: FormatType) {
		if ($activeProfile) {
			const formats = $activeProfile.filters.formats;
			const index = formats.indexOf(format);

			if (index >= 0) {
				formats.splice(index, 1);
			} else {
				formats.push(format);
			}

			$activeProfile.filters.formats = [...formats];
		}
	}
</script>

{#if $activeProfile}
	<div class="card space-y-4">
		<h3 class="font-semibold text-lg">Content Filters</h3>

		<!-- Density Slider -->
		<div>
			<label class="block text-sm font-medium mb-2">
				Content Density: {$activeProfile.filters.density.toFixed(2)}
			</label>
			<div class="flex items-center gap-2">
				<span class="text-xs text-gray-500">Light</span>
				<input
					type="range"
					min="0"
					max="1"
					step="0.01"
					value={$activeProfile.filters.density}
					on:input={handleDensityChange}
					class="flex-1"
				/>
				<span class="text-xs text-gray-500">Deep</span>
			</div>
		</div>

		<!-- Pace Slider -->
		<div>
			<label class="block text-sm font-medium mb-2">
				Content Pace: {$activeProfile.filters.pace.toFixed(2)}
			</label>
			<div class="flex items-center gap-2">
				<span class="text-xs text-gray-500">Slow</span>
				<input
					type="range"
					min="0"
					max="1"
					step="0.01"
					value={$activeProfile.filters.pace}
					on:input={handlePaceChange}
					class="flex-1"
				/>
				<span class="text-xs text-gray-500">Fast</span>
			</div>
		</div>

		<!-- Max Duration -->
		<div>
			<label class="block text-sm font-medium mb-2">
				Max Duration: {$activeProfile.filters.maxDuration === 0
					? 'Unlimited'
					: `${$activeProfile.filters.maxDuration} min`}
			</label>
			<input
				type="number"
				min="0"
				step="5"
				value={$activeProfile.filters.maxDuration}
				on:input={handleMaxDurationChange}
				class="input"
				placeholder="Minutes (0 = unlimited)"
			/>
		</div>

		<!-- Format Filters -->
		<div>
			<label class="block text-sm font-medium mb-2">Formats</label>
			<div class="flex flex-wrap gap-2">
				{#each formatOptions as format}
					<button
						class="px-3 py-1 rounded-full text-sm transition-colors {$activeProfile.filters
							.formats.includes(format)
							? 'bg-primary-600 text-white'
							: 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}"
						on:click={() => handleFormatToggle(format)}
					>
						{format}
					</button>
				{/each}
			</div>
		</div>

		<!-- Quality Threshold -->
		<div>
			<label class="block text-sm font-medium mb-2">
				Quality Threshold: {$activeProfile.filters.qualityThreshold.toFixed(2)}
			</label>
			<input
				type="range"
				min="0"
				max="1"
				step="0.01"
				bind:value={$activeProfile.filters.qualityThreshold}
				class="w-full"
			/>
		</div>
	</div>
{/if}
