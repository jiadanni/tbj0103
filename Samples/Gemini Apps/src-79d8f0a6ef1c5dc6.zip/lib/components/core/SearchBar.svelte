<script lang="ts">
	import { createEventDispatcher } from 'svelte';
	import { debounce } from '$lib/utils/helpers';

	export let placeholder: string = 'Search for videos...';
	export let value: string = '';
	export let enableAI: boolean = false;

	const dispatch = createEventDispatcher();

	let searchInput: HTMLInputElement;

	const handleSearch = debounce(() => {
		if (value.trim()) {
			dispatch('search', { query: value, useAI: enableAI });
		}
	}, 500);

	function handleSubmit(e: Event) {
		e.preventDefault();
		if (value.trim()) {
			dispatch('search', { query: value, useAI: enableAI });
		}
	}

	function handleClear() {
		value = '';
		searchInput.focus();
		dispatch('clear');
	}
</script>

<form on:submit={handleSubmit} class="w-full">
	<div class="relative">
		<div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
			<svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
				/>
			</svg>
		</div>

		<input
			bind:this={searchInput}
			bind:value
			on:input={handleSearch}
			type="text"
			class="input pl-12 pr-24"
			{placeholder}
		/>

		<div class="absolute inset-y-0 right-0 flex items-center pr-2 gap-2">
			{#if enableAI}
				<span
					class="text-xs bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-200 px-2 py-1 rounded"
				>
					AI
				</span>
			{/if}

			{#if value}
				<button
					type="button"
					on:click={handleClear}
					class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
				>
					<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M6 18L18 6M6 6l12 12"
						/>
					</svg>
				</button>
			{/if}
		</div>
	</div>
</form>
