<script lang="ts">
	import { onMount } from 'svelte';

	export let src: string;
	export let alt: string;
	export let className: string = '';
	export let placeholder: string = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 9"%3E%3Crect fill="%23e5e7eb" width="16" height="9"/%3E%3C/svg%3E';

	let imgElement: HTMLImageElement;
	let loaded = false;
	let error = false;
	let observer: IntersectionObserver;

	onMount(() => {
		// Only load image when it's near the viewport
		observer = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						loadImage();
						observer.disconnect();
					}
				});
			},
			{
				rootMargin: '50px' // Start loading 50px before entering viewport
			}
		);

		if (imgElement) {
			observer.observe(imgElement);
		}

		return () => {
			observer?.disconnect();
		};
	});

	function loadImage() {
		if (loaded || !src) return;

		const img = new Image();
		img.onload = () => {
			loaded = true;
			if (imgElement) {
				imgElement.src = src;
			}
		};
		img.onerror = () => {
			error = true;
		};
		img.src = src;
	}
</script>

<img
	bind:this={imgElement}
	src={placeholder}
	{alt}
	class={className}
	class:loaded
	class:error
	loading="lazy"
/>

<style>
	img {
		transition: opacity 0.3s ease-in-out;
		opacity: 0.5;
	}

	img.loaded {
		opacity: 1;
	}

	img.error {
		opacity: 0.3;
		filter: grayscale(100%);
	}
</style>
