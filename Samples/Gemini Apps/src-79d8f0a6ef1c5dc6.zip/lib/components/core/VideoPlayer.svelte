<script lang="ts">
	import { onMount, onDestroy } from 'svelte';
	import { browser } from '$app/environment';
	import { player } from '$lib/stores/player';
	import { playbackHistory } from '$lib/stores/playbackHistory';

	let playerContainer: HTMLDivElement;
	let youtubePlayer: any = null;
	let playerReady = false;
	let progressUpdateInterval: number | null = null;
	let currentVideoId: string | null = null;

	$: if ($player.currentVideo && playerReady) {
		loadVideo($player.currentVideo);
	}

	$: if (youtubePlayer && playerReady) {
		if ($player.isPlaying) {
			youtubePlayer.playVideo();
		} else {
			youtubePlayer.pauseVideo();
		}
	}

	$: if (youtubePlayer && playerReady) {
		youtubePlayer.setVolume($player.volume * 100);
	}

	$: if (youtubePlayer && playerReady) {
		youtubePlayer.setPlaybackRate($player.playbackRate);
	}

	onMount(() => {
		if (!browser) return;

		// Load YouTube IFrame API
		if (!(window as any).YT) {
			const tag = document.createElement('script');
			tag.src = 'https://www.youtube.com/iframe_api';
			const firstScriptTag = document.getElementsByTagName('script')[0];
			if (firstScriptTag && firstScriptTag.parentNode) {
				firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
			}

			(window as any).onYouTubeIframeAPIReady = initializePlayer;
		} else {
			initializePlayer();
		}
	});

	onDestroy(() => {
		if (youtubePlayer) {
			youtubePlayer.destroy();
		}
		stopProgressTracking();
	});

	function initializePlayer() {
		const YT = (window as any).YT;

		youtubePlayer = new YT.Player(playerContainer, {
			height: '100%',
			width: '100%',
			playerVars: {
				playsinline: 1,
				modestbranding: 1,
				rel: 0
			},
			events: {
				onReady: onPlayerReady,
				onStateChange: onPlayerStateChange
			}
		});
	}

	function onPlayerReady() {
		playerReady = true;
		if ($player.currentVideo) {
			loadVideo($player.currentVideo);
		}
	}

	function onPlayerStateChange(event: any) {
		const YT = (window as any).YT;

		switch (event.data) {
			case YT.PlayerState.PLAYING:
				if (!$player.isPlaying) {
					player.resume();
				}
				startProgressTracking();
				break;
			case YT.PlayerState.PAUSED:
				if ($player.isPlaying) {
					player.pause();
				}
				updateProgress();
				break;
			case YT.PlayerState.ENDED:
				updateProgress();
				stopProgressTracking();
				player.stop();
				break;
			case YT.PlayerState.CUED:
				// Video is loaded and ready to play
				if ($player.currentVideo && currentVideoId !== $player.currentVideo.id) {
					currentVideoId = $player.currentVideo.id;
					playbackHistory.incrementWatchCount($player.currentVideo.id);
				}
				break;
		}
	}

	function loadVideo(video: any) {
		if (!youtubePlayer || !playerReady) return;

		if (video.source === 'youtube') {
			youtubePlayer.loadVideoById(video.sourceId);
		}
	}

	function handlePlayPause() {
		if ($player.isPlaying) {
			player.pause();
		} else {
			player.resume();
		}
	}

	function handleStop() {
		player.stop();
	}

	function handleVolumeChange(e: Event) {
		const target = e.target as HTMLInputElement;
		player.setVolume(parseFloat(target.value));
	}

	function handlePlaybackRateChange(rate: number) {
		player.setPlaybackRate(rate);
	}

	function startProgressTracking() {
		if (progressUpdateInterval) return; // Already tracking

		progressUpdateInterval = window.setInterval(() => {
			updateProgress();
		}, 5000); // Update every 5 seconds
	}

	function stopProgressTracking() {
		if (progressUpdateInterval) {
			window.clearInterval(progressUpdateInterval);
			progressUpdateInterval = null;
		}
	}

	function updateProgress() {
		if (!youtubePlayer || !playerReady || !$player.currentVideo) return;

		try {
			const currentTime = youtubePlayer.getCurrentTime();
			const duration = youtubePlayer.getDuration();

			if (currentTime > 0 && duration > 0) {
				playbackHistory.updateProgress($player.currentVideo, currentTime, duration);
			}
		} catch (error) {
			console.error('Failed to update progress:', error);
		}
	}
</script>

{#if $player.currentVideo}
	<div class="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg z-50">
		<div class="max-w-7xl mx-auto">
			<!-- Video Container -->
			<div class="aspect-video bg-black">
				<div bind:this={playerContainer} class="w-full h-full"></div>
			</div>

			<!-- Controls -->
			<div class="p-4 space-y-3">
				<!-- Video Title -->
				<div class="flex items-center justify-between">
					<div class="flex-1 min-w-0 mr-4">
						<h3 class="font-semibold truncate">{$player.currentVideo.title}</h3>
						<p class="text-sm text-gray-600 dark:text-gray-400 truncate">
							{$player.currentVideo.channelTitle}
						</p>
					</div>
					<button
						class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
						on:click={handleStop}
						title="Close player"
					>
						<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								stroke-width="2"
								d="M6 18L18 6M6 6l12 12"
							/>
						</svg>
					</button>
				</div>

				<!-- Playback Controls -->
				<div class="flex items-center gap-4">
					<!-- Play/Pause -->
					<button class="btn btn-primary" on:click={handlePlayPause}>
						{#if $player.isPlaying}
							<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
								<path
									fill-rule="evenodd"
									d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
									clip-rule="evenodd"
								/>
							</svg>
						{:else}
							<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
								<path
									fill-rule="evenodd"
									d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"
									clip-rule="evenodd"
								/>
							</svg>
						{/if}
					</button>

					<!-- Volume Control -->
					<div class="flex items-center gap-2 flex-1 max-w-xs">
						<svg class="w-5 h-5 text-gray-600 dark:text-gray-400" fill="currentColor" viewBox="0 0 20 20">
							<path
								fill-rule="evenodd"
								d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z"
								clip-rule="evenodd"
							/>
						</svg>
						<input
							type="range"
							min="0"
							max="1"
							step="0.01"
							value={$player.volume}
							on:input={handleVolumeChange}
							class="flex-1"
						/>
						<span class="text-sm text-gray-600 dark:text-gray-400 w-10 text-right">
							{Math.round($player.volume * 100)}%
						</span>
					</div>

					<!-- Playback Speed -->
					<div class="flex items-center gap-2">
						<span class="text-sm text-gray-600 dark:text-gray-400">Speed:</span>
						<select
							class="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700"
							value={$player.playbackRate}
							on:change={(e) => handlePlaybackRateChange(parseFloat(e.currentTarget.value))}
						>
							<option value="0.25">0.25x</option>
							<option value="0.5">0.5x</option>
							<option value="0.75">0.75x</option>
							<option value="1">1x</option>
							<option value="1.25">1.25x</option>
							<option value="1.5">1.5x</option>
							<option value="1.75">1.75x</option>
							<option value="2">2x</option>
						</select>
					</div>

					<!-- Casting Status -->
					{#if $player.isCasting && $player.castDevice}
						<div class="flex items-center gap-2 text-sm text-primary-600 dark:text-primary-400">
							<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
								<path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
							</svg>
							<span>Casting to {$player.castDevice.name}</span>
						</div>
					{/if}
				</div>
			</div>
		</div>
	</div>

	<!-- Spacer to prevent content from being hidden behind fixed player -->
	<div class="h-96"></div>
{/if}
