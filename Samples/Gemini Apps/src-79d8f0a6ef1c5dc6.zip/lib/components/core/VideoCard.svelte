<script lang="ts">
	import type { VideoMetadata } from '$lib/types';
	import { formatDuration, formatNumber } from '$lib/utils/helpers';
	import { player } from '$lib/stores/player';
	import { watchLater } from '$lib/stores/watchLater';
	import LazyImage from './LazyImage.svelte';

	export let video: VideoMetadata;
	export let showStats: boolean = true;
	export let onRemoveFromWatchLater: (() => void) | undefined = undefined;

	$: inWatchLater = watchLater.has(video.id);

	function handlePlay() {
		player.play(video);
	}

	function handleAddToPath() {
		// This will be implemented when path builder is created
		console.log('Add to path:', video.id);
	}

	function handleWatchLater(e: Event) {
		e.stopPropagation();
		if (inWatchLater) {
			watchLater.remove(video.id);
			if (onRemoveFromWatchLater) {
				onRemoveFromWatchLater();
			}
		} else {
			watchLater.add(video);
		}
	}
</script>

<div class="card group hover:shadow-lg transition-shadow cursor-pointer">
	<div class="relative" on:click={handlePlay} on:keydown={handlePlay}>
		<LazyImage
			src={video.thumbnail}
			alt={video.title}
			className="w-full h-48 object-cover rounded-t-lg"
		/>
		<div
			class="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 text-sm rounded"
		>
			{formatDuration(video.duration)}
		</div>
		<div
			class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity flex items-center justify-center"
		>
			<svg
				class="w-16 h-16 text-white opacity-0 group-hover:opacity-100 transition-opacity"
				fill="currentColor"
				viewBox="0 0 20 20"
			>
				<path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
			</svg>
		</div>
	</div>

	<div class="p-4">
		<h3 class="font-semibold text-lg line-clamp-2 mb-2">{video.title}</h3>

		<p class="text-sm text-gray-600 dark:text-gray-400 mb-2">{video.channelTitle}</p>

		{#if showStats && video.stats}
			<div class="flex gap-4 text-sm text-gray-500 dark:text-gray-400 mb-3">
				<span>{formatNumber(video.stats.viewCount)} views</span>
				<span>{formatNumber(video.stats.likeCount)} likes</span>
			</div>
		{/if}

		<p class="text-sm text-gray-700 dark:text-gray-300 line-clamp-2 mb-3">
			{video.description}
		</p>

		<div class="flex gap-2">
			<button class="btn btn-primary flex-1" on:click={handlePlay}> Play </button>
			<button
				class="btn btn-secondary px-3"
				on:click={handleWatchLater}
				title={inWatchLater ? 'Remove from Watch Later' : 'Add to Watch Later'}
			>
				<svg class="w-5 h-5" fill={inWatchLater ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
					/>
				</svg>
			</button>
			<button
				class="btn btn-secondary px-3"
				on:click={handleAddToPath}
				title="Add to learning path"
			>
				<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M12 4v16m8-8H4"
					/>
				</svg>
			</button>
		</div>
	</div>
</div>
