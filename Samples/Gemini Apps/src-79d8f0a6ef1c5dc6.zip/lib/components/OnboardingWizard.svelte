<script lang="ts">
	import { createEventDispatcher } from 'svelte';

	const dispatch = createEventDispatcher();

	let step = 0;
	const totalSteps = 4;

	function nextStep() {
		if (step < totalSteps - 1) {
			step++;
		} else {
			complete();
		}
	}

	function prevStep() {
		if (step > 0) {
			step--;
		}
	}

	function complete() {
		dispatch('complete');
	}

	function skip() {
		dispatch('skip');
	}
</script>

<div class="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
	<div class="card max-w-3xl w-full">
		<!-- Progress Bar -->
		<div class="mb-8">
			<div class="flex items-center justify-between mb-2">
				<span class="text-sm text-gray-600 dark:text-gray-400">
					Step {step + 1} of {totalSteps}
				</span>
				<button
					class="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
					on:click={skip}
				>
					Skip Tutorial
				</button>
			</div>
			<div class="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-2">
				<div
					class="bg-primary-600 h-2 rounded-full transition-all duration-300"
					style="width: {((step + 1) / totalSteps) * 100}%"
				></div>
			</div>
		</div>

		<!-- Step Content -->
		<div class="min-h-[300px]">
			{#if step === 0}
				<div class="text-center">
					<div
						class="w-24 h-24 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-6"
					>
						<span class="text-white font-bold text-5xl">V</span>
					</div>
					<h2 class="text-3xl font-bold mb-4">Welcome to Vektor!</h2>
					<p class="text-lg text-gray-700 dark:text-gray-300 mb-6 max-w-xl mx-auto">
						Your open-source, privacy-first platform for intentional video content discovery.
					</p>
					<div class="grid md:grid-cols-3 gap-4 mt-8">
						<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div class="text-3xl mb-2">🔒</div>
							<h3 class="font-semibold mb-1">Privacy First</h3>
							<p class="text-sm text-gray-600 dark:text-gray-400">
								All data stays on your device. No tracking, no servers.
							</p>
						</div>
						<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div class="text-3xl mb-2">🎯</div>
							<h3 class="font-semibold mb-1">You're in Control</h3>
							<p class="text-sm text-gray-600 dark:text-gray-400">
								Custom filters, profiles, and learning paths.
							</p>
						</div>
						<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div class="text-3xl mb-2">💰</div>
							<h3 class="font-semibold mb-1">Zero Cost</h3>
							<p class="text-sm text-gray-600 dark:text-gray-400">
								Bring your own API keys. No subscriptions ever.
							</p>
						</div>
					</div>
				</div>
			{:else if step === 1}
				<div>
					<h2 class="text-2xl font-bold mb-4">Step 1: Get Your API Keys</h2>
					<p class="text-gray-700 dark:text-gray-300 mb-6">
						Vektor uses your own API keys to access video platforms. This means you control your
						data and there are no costs from us.
					</p>

					<div class="space-y-4">
						<div class="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
							<h3 class="font-semibold text-blue-800 dark:text-blue-300 mb-2">
								YouTube Data API v3
							</h3>
							<ol class="list-decimal list-inside space-y-2 text-sm text-blue-700 dark:text-blue-300">
								<li>Go to <a href="https://console.cloud.google.com" target="_blank" class="underline">Google Cloud Console</a></li>
								<li>Create a new project</li>
								<li>Enable YouTube Data API v3</li>
								<li>Create credentials (API Key)</li>
								<li>Copy the key - you'll add it in settings next</li>
							</ol>
						</div>

						<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<p class="text-sm text-gray-600 dark:text-gray-400">
								<strong>Note:</strong> The free tier gives you 10,000 quota units per day, which is
								enough for regular use. Vektor shows your quota usage so you can track it.
							</p>
						</div>
					</div>
				</div>
			{:else if step === 2}
				<div>
					<h2 class="text-2xl font-bold mb-4">Step 2: Create Your First Profile</h2>
					<p class="text-gray-700 dark:text-gray-300 mb-6">
						Profiles let you filter content based on your learning context. Create different
						profiles for different goals.
					</p>

					<div class="grid md:grid-cols-2 gap-4">
						<div class="p-4 border-2 border-primary-500 rounded-lg">
							<h3 class="font-semibold mb-2">Example: "Deep Learning"</h3>
							<ul class="text-sm space-y-1 text-gray-700 dark:text-gray-300">
								<li>• High density (in-depth content)</li>
								<li>• Slow pace (detailed explanations)</li>
								<li>• Long videos (20+ minutes)</li>
								<li>• Formats: lectures, tutorials</li>
							</ul>
						</div>

						<div class="p-4 border-2 border-gray-300 dark:border-gray-600 rounded-lg">
							<h3 class="font-semibold mb-2">Example: "Quick Tips"</h3>
							<ul class="text-sm space-y-1 text-gray-700 dark:text-gray-300">
								<li>• Low density (bite-sized)</li>
								<li>• Fast pace (to the point)</li>
								<li>• Short videos (&lt; 10 minutes)</li>
								<li>• Formats: tutorials, tips</li>
							</ul>
						</div>
					</div>

					<div class="mt-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
						<p class="text-sm text-yellow-800 dark:text-yellow-300">
							💡 <strong>Tip:</strong> You can switch between profiles anytime and create as many
							as you need.
						</p>
					</div>
				</div>
			{:else if step === 3}
				<div>
					<h2 class="text-2xl font-bold mb-4">Step 3: Build Learning Paths</h2>
					<p class="text-gray-700 dark:text-gray-300 mb-6">
						Organize videos into structured curricula. Track your progress, take notes, and learn
						systematically.
					</p>

					<div class="space-y-4">
						<div class="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div
								class="w-10 h-10 bg-primary-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold"
							>
								1
							</div>
							<div>
								<h3 class="font-semibold mb-1">Search & Add Videos</h3>
								<p class="text-sm text-gray-600 dark:text-gray-400">
									Find videos using search, then add them to your learning paths.
								</p>
							</div>
						</div>

						<div class="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div
								class="w-10 h-10 bg-primary-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold"
							>
								2
							</div>
							<div>
								<h3 class="font-semibold mb-1">Organize & Order</h3>
								<p class="text-sm text-gray-600 dark:text-gray-400">
									Arrange videos in the order you want to watch them.
								</p>
							</div>
						</div>

						<div class="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div
								class="w-10 h-10 bg-primary-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold"
							>
								3
							</div>
							<div>
								<h3 class="font-semibold mb-1">Track Progress</h3>
								<p class="text-sm text-gray-600 dark:text-gray-400">
									Mark videos as complete and take notes as you learn.
								</p>
							</div>
						</div>
					</div>

					<div class="mt-6 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
						<p class="text-sm text-green-800 dark:text-green-300">
							✨ <strong>Ready to start?</strong> Head to Settings → API Configuration to add your
							YouTube API key, then create your first profile!
						</p>
					</div>
				</div>
			{/if}
		</div>

		<!-- Navigation -->
		<div class="flex items-center justify-between mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
			{#if step > 0}
				<button class="btn btn-secondary" on:click={prevStep}> ← Back </button>
			{:else}
				<div></div>
			{/if}

			<button class="btn btn-primary" on:click={nextStep}>
				{step < totalSteps - 1 ? 'Next →' : "Let's Go! 🚀"}
			</button>
		</div>
	</div>
</div>
