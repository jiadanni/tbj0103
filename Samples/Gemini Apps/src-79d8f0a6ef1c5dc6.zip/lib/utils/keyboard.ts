// Keyboard shortcuts system

export type KeyboardShortcut = {
	key: string;
	ctrl?: boolean;
	shift?: boolean;
	alt?: boolean;
	meta?: boolean;
	description: string;
	action: () => void;
};

class KeyboardShortcutManager {
	private shortcuts: KeyboardShortcut[] = [];
	private enabled = true;

	constructor() {
		if (typeof window !== 'undefined') {
			window.addEventListener('keydown', this.handleKeyDown.bind(this));
		}
	}

	register(shortcut: KeyboardShortcut) {
		this.shortcuts.push(shortcut);
	}

	unregister(key: string) {
		this.shortcuts = this.shortcuts.filter((s) => s.key !== key);
	}

	clear() {
		this.shortcuts = [];
	}

	enable() {
		this.enabled = true;
	}

	disable() {
		this.enabled = false;
	}

	getShortcuts(): KeyboardShortcut[] {
		return this.shortcuts;
	}

	private handleKeyDown(event: KeyboardEvent) {
		if (!this.enabled) return;

		// Don't trigger shortcuts when typing in inputs
		const target = event.target as HTMLElement;
		if (
			target.tagName === 'INPUT' ||
			target.tagName === 'TEXTAREA' ||
			target.isContentEditable
		) {
			// Exception: Allow '/' to focus search only when NOT already in an input
			// This prevents the shortcut from triggering when typing in input fields
			return;
		}

		for (const shortcut of this.shortcuts) {
			if (this.matchesShortcut(event, shortcut)) {
				event.preventDefault();
				shortcut.action();
				break;
			}
		}
	}

	private matchesShortcut(event: KeyboardEvent, shortcut: KeyboardShortcut): boolean {
		if (event.key.toLowerCase() !== shortcut.key.toLowerCase()) {
			return false;
		}

		if (shortcut.ctrl && !event.ctrlKey) return false;
		if (shortcut.shift && !event.shiftKey) return false;
		if (shortcut.alt && !event.altKey) return false;
		if (shortcut.meta && !event.metaKey) return false;

		// Ensure modifiers that aren't specified are not pressed
		if (!shortcut.ctrl && event.ctrlKey) return false;
		if (!shortcut.shift && event.shiftKey) return false;
		if (!shortcut.alt && event.altKey) return false;
		if (!shortcut.meta && event.metaKey) return false;

		return true;
	}

	/**
	 * Format shortcut for display
	 */
	static formatShortcut(shortcut: KeyboardShortcut): string {
		const parts: string[] = [];

		if (shortcut.ctrl) parts.push('Ctrl');
		if (shortcut.alt) parts.push('Alt');
		if (shortcut.shift) parts.push('Shift');
		if (shortcut.meta) parts.push('⌘');

		parts.push(shortcut.key.toUpperCase());

		return parts.join(' + ');
	}
}

export const keyboardManager = new KeyboardShortcutManager();
