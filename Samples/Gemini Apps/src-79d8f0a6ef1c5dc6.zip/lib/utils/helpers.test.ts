import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
	generateId,
	formatDuration,
	parseDuration,
	formatNumber,
	debounce,
	validateApiKey,
	compressData,
	decompressData
} from './helpers';

describe('Helper Functions', () => {
	describe('generateId', () => {
		it('should generate a unique string ID', () => {
			const id1 = generateId();
			const id2 = generateId();

			expect(typeof id1).toBe('string');
			expect(typeof id2).toBe('string');
			expect(id1).not.toBe(id2);
		});

		it('should include timestamp and random component', () => {
			const id = generateId();
			const parts = id.split('-');

			expect(parts.length).toBeGreaterThanOrEqual(2);
			expect(parseInt(parts[0])).toBeGreaterThan(0);
		});
	});

	describe('formatDuration', () => {
		it('should format seconds only', () => {
			expect(formatDuration(45)).toBe('0:45');
			expect(formatDuration(5)).toBe('0:05');
		});

		it('should format minutes and seconds', () => {
			expect(formatDuration(125)).toBe('2:05');
			expect(formatDuration(601)).toBe('10:01');
		});

		it('should format hours, minutes, and seconds', () => {
			expect(formatDuration(3661)).toBe('1:01:01');
			expect(formatDuration(7200)).toBe('2:00:00');
			expect(formatDuration(3723)).toBe('1:02:03');
		});

		it('should handle zero duration', () => {
			expect(formatDuration(0)).toBe('0:00');
		});

		it('should pad single digit seconds and minutes', () => {
			expect(formatDuration(65)).toBe('1:05');
			expect(formatDuration(3605)).toBe('1:00:05');
		});
	});

	describe('parseDuration', () => {
		it('should parse ISO 8601 duration with all components', () => {
			expect(parseDuration('PT1H2M3S')).toBe(3723);
		});

		it('should parse hours only', () => {
			expect(parseDuration('PT2H')).toBe(7200);
		});

		it('should parse minutes only', () => {
			expect(parseDuration('PT15M')).toBe(900);
		});

		it('should parse seconds only', () => {
			expect(parseDuration('PT45S')).toBe(45);
		});

		it('should parse hours and minutes', () => {
			expect(parseDuration('PT1H30M')).toBe(5400);
		});

		it('should parse minutes and seconds', () => {
			expect(parseDuration('PT5M30S')).toBe(330);
		});

		it('should handle invalid duration format', () => {
			expect(parseDuration('invalid')).toBe(0);
			expect(parseDuration('')).toBe(0);
			expect(parseDuration('PT')).toBe(0);
		});
	});

	describe('formatNumber', () => {
		it('should format numbers under 1000 as-is', () => {
			expect(formatNumber(0)).toBe('0');
			expect(formatNumber(50)).toBe('50');
			expect(formatNumber(999)).toBe('999');
		});

		it('should format thousands with K suffix', () => {
			expect(formatNumber(1000)).toBe('1.0K');
			expect(formatNumber(1500)).toBe('1.5K');
			expect(formatNumber(12345)).toBe('12.3K');
			expect(formatNumber(999999)).toBe('1000.0K');
		});

		it('should format millions with M suffix', () => {
			expect(formatNumber(1000000)).toBe('1.0M');
			expect(formatNumber(1500000)).toBe('1.5M');
			expect(formatNumber(12345678)).toBe('12.3M');
		});

		it('should round to one decimal place', () => {
			expect(formatNumber(1234)).toBe('1.2K');
			expect(formatNumber(1267)).toBe('1.3K');
		});
	});

	describe('debounce', () => {
		beforeEach(() => {
			vi.useFakeTimers();
		});

		afterEach(() => {
			vi.restoreAllMocks();
		});

		it('should delay function execution', () => {
			const func = vi.fn();
			const debouncedFunc = debounce(func, 100);

			debouncedFunc();
			expect(func).not.toHaveBeenCalled();

			vi.advanceTimersByTime(100);
			expect(func).toHaveBeenCalledTimes(1);
		});

		it('should cancel previous calls', () => {
			const func = vi.fn();
			const debouncedFunc = debounce(func, 100);

			debouncedFunc();
			debouncedFunc();
			debouncedFunc();

			vi.advanceTimersByTime(100);
			expect(func).toHaveBeenCalledTimes(1);
		});

		it('should pass arguments correctly', () => {
			const func = vi.fn();
			const debouncedFunc = debounce(func, 100);

			debouncedFunc('arg1', 'arg2');
			vi.advanceTimersByTime(100);

			expect(func).toHaveBeenCalledWith('arg1', 'arg2');
		});

		it('should use latest arguments when called multiple times', () => {
			const func = vi.fn();
			const debouncedFunc = debounce(func, 100);

			debouncedFunc('first');
			debouncedFunc('second');
			debouncedFunc('third');

			vi.advanceTimersByTime(100);
			expect(func).toHaveBeenCalledWith('third');
		});
	});

	describe('validateApiKey', () => {
		describe('YouTube API keys', () => {
			it('should accept valid YouTube API keys', () => {
				const validKey = 'AIzaSyD1234567890123456789012345678';
				expect(validateApiKey(validKey, 'youtube')).toBe(true);
			});

			it('should reject short YouTube API keys', () => {
				expect(validateApiKey('short', 'youtube')).toBe(false);
				expect(validateApiKey('AIzaSy123', 'youtube')).toBe(false);
			});

			it('should accept keys 30 characters or longer', () => {
				const key30 = 'A'.repeat(30);
				expect(validateApiKey(key30, 'youtube')).toBe(true);
			});
		});

		describe('Vimeo API keys', () => {
			it('should accept valid Vimeo access tokens', () => {
				const validToken = 'a'.repeat(32);
				expect(validateApiKey(validToken, 'vimeo')).toBe(true);
			});

			it('should reject short Vimeo tokens', () => {
				expect(validateApiKey('short', 'vimeo')).toBe(false);
				expect(validateApiKey('a'.repeat(19), 'vimeo')).toBe(false);
			});

			it('should accept tokens 20 characters or longer', () => {
				const token20 = 'a'.repeat(20);
				expect(validateApiKey(token20, 'vimeo')).toBe(true);
			});
		});

		describe('Invalid inputs', () => {
			it('should reject empty strings', () => {
				expect(validateApiKey('', 'youtube')).toBe(false);
				expect(validateApiKey('', 'vimeo')).toBe(false);
			});

			it('should reject whitespace-only strings', () => {
				expect(validateApiKey('   ', 'youtube')).toBe(false);
				expect(validateApiKey('   ', 'vimeo')).toBe(false);
			});
		});
	});

	describe('compressData / decompressData', () => {
		it('should compress and decompress objects', () => {
			const data = {
				name: 'Test',
				value: 123,
				nested: { key: 'value' }
			};

			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toEqual(data);
		});

		it('should compress and decompress arrays', () => {
			const data = [1, 2, 3, 'four', { five: 5 }];

			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toEqual(data);
		});

		it('should compress and decompress strings', () => {
			const data = 'Hello, World!';

			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toBe(data);
		});

		it('should handle special characters', () => {
			const data = {
				text: 'Héllo Wørld! 你好 🌍'
			};

			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toEqual(data);
		});

		it('should return null for invalid compressed data', () => {
			const invalid = 'not-valid-base64';
			const result = decompressData(invalid);

			expect(result).toBeNull();
		});

		it('should produce compressed string', () => {
			const data = { test: 'data' };
			const compressed = compressData(data);

			expect(typeof compressed).toBe('string');
			expect(compressed.length).toBeGreaterThan(0);
		});

		it('should handle empty objects', () => {
			const data = {};
			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toEqual(data);
		});

		it('should handle null values', () => {
			const data = { value: null };
			const compressed = compressData(data);
			const decompressed = decompressData(compressed);

			expect(decompressed).toEqual(data);
		});
	});
});
