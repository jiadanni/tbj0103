// YouTube Client Factory with API logging

import { YouTubeClient } from '../engines/youtube';
import { apiHistory } from '../stores/apiHistory';

/**
 * Create a YouTube client with API request logging enabled
 */
export function createYouTubeClient(apiKeys: string | string[]): YouTubeClient {
    return new YouTubeClient(apiKeys, async (record) => {
        await apiHistory.addRequest(record);
    });
}
