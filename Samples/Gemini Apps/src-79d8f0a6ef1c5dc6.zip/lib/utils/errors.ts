// Error handling utilities

export class VektorError extends Error {
	constructor(
		message: string,
		public code: string,
		public details?: any
	) {
		super(message);
		this.name = 'VektorError';
	}
}

export class APIError extends VektorError {
	constructor(message: string, details?: any) {
		super(message, 'API_ERROR', details);
		this.name = 'APIError';
	}
}

export class StorageError extends VektorError {
	constructor(message: string, details?: any) {
		super(message, 'STORAGE_ERROR', details);
		this.name = 'StorageError';
	}
}

export class ValidationError extends VektorError {
	constructor(message: string, details?: any) {
		super(message, 'VALIDATION_ERROR', details);
		this.name = 'ValidationError';
	}
}

export class QuotaExceededError extends VektorError {
	constructor(
		public used: number,
		public limit: number
	) {
		super(`API quota exceeded: ${used}/${limit} units used`, 'QUOTA_EXCEEDED', {
			used,
			limit
		});
		this.name = 'QuotaExceededError';
	}
}

export class InvalidApiKeyError extends VektorError {
	constructor(service: string = 'API') {
		super(
			`Invalid ${service} API key. Please check your settings and ensure the key has proper permissions.`,
			'INVALID_API_KEY',
			{ service }
		);
		this.name = 'InvalidApiKeyError';
	}
}

export class NetworkError extends VektorError {
	constructor(message: string = 'Network request failed', details?: any) {
		super(message, 'NETWORK_ERROR', details);
		this.name = 'NetworkError';
	}
}

export class AuthError extends VektorError {
	constructor(message: string = 'Authentication failed', details?: any) {
		super(message, 'AUTH_ERROR', details);
		this.name = 'AuthError';
	}
}

export class RateLimitError extends VektorError {
	constructor(retryAfter?: number) {
		const message = retryAfter
			? `Rate limit exceeded. Please try again in ${retryAfter} seconds.`
			: 'Rate limit exceeded. Please try again later.';
		super(message, 'RATE_LIMIT', { retryAfter });
		this.name = 'RateLimitError';
	}
}

/**
 * Safely execute an async function with error handling
 */
export async function safeAsync<T>(
	fn: () => Promise<T>,
	fallback?: T,
	onError?: (error: Error) => void
): Promise<T | undefined> {
	try {
		return await fn();
	} catch (error) {
		const err = error instanceof Error ? error : new Error(String(error));
		console.error('Error in safeAsync:', err);

		if (onError) {
			onError(err);
		}

		return fallback;
	}
}

/**
 * Retry an async function with exponential backoff
 */
export async function retryAsync<T>(
	fn: () => Promise<T>,
	maxRetries: number = 3,
	delayMs: number = 1000
): Promise<T> {
	let lastError: Error;

	for (let i = 0; i <= maxRetries; i++) {
		try {
			return await fn();
		} catch (error) {
			lastError = error instanceof Error ? error : new Error(String(error));

			if (i < maxRetries) {
				// Exponential backoff
				const delay = delayMs * Math.pow(2, i);
				console.log(`Retry ${i + 1}/${maxRetries} after ${delay}ms...`);
				await new Promise((resolve) => setTimeout(resolve, delay));
			}
		}
	}

	throw lastError!;
}

/**
 * Handle API errors with user-friendly messages
 */
export function getErrorMessage(error: unknown): string {
	if (error instanceof VektorError) {
		return error.message;
	}

	if (error instanceof Error) {
		// Handle common API errors
		if (error.message.includes('API key')) {
			return 'Invalid or missing API key. Please check your settings.';
		}

		if (error.message.includes('quota')) {
			return 'API quota exceeded. Please try again tomorrow or upgrade your quota.';
		}

		if (error.message.includes('network') || error.message.includes('fetch')) {
			return 'Network error. Please check your internet connection.';
		}

		if (error.message.includes('not found') || error.message.includes('404')) {
			return 'Content not found. It may have been removed or is unavailable.';
		}

		if (error.message.includes('forbidden') || error.message.includes('403')) {
			return 'Access forbidden. Please check your API key permissions.';
		}

		if (error.message.includes('unauthorized') || error.message.includes('401')) {
			return 'Unauthorized. Please verify your API credentials.';
		}

		return error.message;
	}

	return 'An unexpected error occurred. Please try again.';
}

/**
 * Check if an error is retryable
 */
export function isRetryableError(error: unknown): boolean {
	if (!(error instanceof Error)) return false;

	const message = error.message.toLowerCase();

	// Network errors are retryable
	if (message.includes('network') || message.includes('fetch') || message.includes('timeout')) {
		return true;
	}

	// Rate limit errors are retryable (after delay)
	if (message.includes('rate limit') || message.includes('429')) {
		return true;
	}

	// Server errors (5xx) are retryable
	if (message.includes('500') || message.includes('502') || message.includes('503')) {
		return true;
	}

	return false;
}

/**
 * Log error for debugging
 */
export function logError(error: unknown, context?: string) {
	const timestamp = new Date().toISOString();
	const contextStr = context ? `[${context}]` : '';

	if (error instanceof Error) {
		console.error(`${timestamp} ${contextStr} ${error.name}: ${error.message}`);
		if (error.stack) {
			console.error(error.stack);
		}
	} else {
		console.error(`${timestamp} ${contextStr}`, error);
	}
}
