// Service Worker registration and management

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
	if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
		console.log('[SW] Service Workers not supported');
		return null;
	}

	try {
		const registration = await navigator.serviceWorker.register('/service-worker.js');

		console.log('[SW] Service Worker registered:', registration);

		// Check for updates periodically
		setInterval(() => {
			registration.update();
		}, 60 * 60 * 1000); // Check every hour

		// Handle updates
		registration.addEventListener('updatefound', () => {
			const newWorker = registration.installing;
			if (!newWorker) return;

			newWorker.addEventListener('statechange', () => {
				if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
					// New service worker available
					console.log('[SW] New version available');

					// Notify user about update
					if (confirm('A new version of Vektor is available. Reload to update?')) {
						newWorker.postMessage({ type: 'SKIP_WAITING' });
						window.location.reload();
					}
				}
			});
		});

		// Listen for controlling service worker change
		navigator.serviceWorker.addEventListener('controllerchange', () => {
			console.log('[SW] Controller changed');
		});

		return registration;
	} catch (error) {
		console.error('[SW] Registration failed:', error);
		return null;
	}
}

export async function unregisterServiceWorker(): Promise<boolean> {
	if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
		return false;
	}

	try {
		const registration = await navigator.serviceWorker.getRegistration();
		if (registration) {
			const success = await registration.unregister();
			console.log('[SW] Unregistered:', success);
			return success;
		}
		return false;
	} catch (error) {
		console.error('[SW] Unregistration failed:', error);
		return false;
	}
}

export async function checkForUpdates(): Promise<void> {
	if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
		return;
	}

	try {
		const registration = await navigator.serviceWorker.getRegistration();
		if (registration) {
			await registration.update();
			console.log('[SW] Checked for updates');
		}
	} catch (error) {
		console.error('[SW] Update check failed:', error);
	}
}
