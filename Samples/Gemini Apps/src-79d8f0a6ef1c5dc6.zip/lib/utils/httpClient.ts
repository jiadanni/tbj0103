// Lightweight HTTP client with in-memory GET caching and token-bucket rate limiting

type FetchOptions = RequestInit & { cacheTtlMs?: number };

interface CacheEntry {
    expiresAt: number;
    body: any;
}

const defaultTtl = 1000 * 60 * 5; // 5 minutes

// Simple in-memory cache for GET requests
const cache: Map<string, CacheEntry> = new Map();

// Token bucket limiter
let tokens = 10; // default burst
const refillRatePerSecond = 1; // tokens per second
const maxTokens = 10;

setInterval(() => {
    tokens = Math.min(maxTokens, tokens + refillRatePerSecond);
}, 1000);

function buildCacheKey(url: string, init?: RequestInit) {
    return `${url}|${init?.method || 'GET'}`;
}

export async function fetchWithCache(url: string, options: FetchOptions = {}): Promise<Response> {
    const method = (options.method || 'GET').toUpperCase();

    // Use cache only for GET
    if (method === 'GET') {
        const key = buildCacheKey(url, options);
        const entry = cache.get(key);
        const now = Date.now();
        if (entry && entry.expiresAt > now) {
            // Return a minimal Response-like object with json/text helpers
            const body = entry.body;
            return new Response(JSON.stringify(body), { status: 200 });
        }
    }

    // Wait for token if none available (simple backoff)
    const start = Date.now();
    while (tokens <= 0) {
        await new Promise((r) => setTimeout(r, 200));
        if (Date.now() - start > 10000) break; // avoid endless wait
    }
    if (tokens > 0) tokens -= 1;

    const resp = await fetch(url, options);

    // Cache GET JSON responses
    if (method === 'GET' && resp.ok) {
        try {
            const clone = resp.clone();
            const data = await clone.json();
            const key = buildCacheKey(url, options);
            const ttl = options.cacheTtlMs ?? defaultTtl;
            cache.set(key, { expiresAt: Date.now() + ttl, body: data });
        } catch {
            // ignore non-json responses
        }
    }

    return resp;
}

export function clearHttpCache() {
    cache.clear();
}
