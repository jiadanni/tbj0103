/**
 * Performance monitoring utilities for Vektor
 */

/**
 * Measure the time it takes to execute a function
 */
export function measurePerformance<T>(
	label: string,
	fn: () => T,
	logToConsole: boolean = false
): T {
	const start = performance.now();
	const result = fn();
	const duration = performance.now() - start;

	if (logToConsole) {
		console.log(`⏱️ ${label}: ${duration.toFixed(2)}ms`);
	}

	// Store in performance marks for later analysis
	performance.mark(`${label}-end`);
	performance.measure(label, `${label}-end`);

	return result;
}

/**
 * Debounce with leading edge option for better UX
 */
export function debounceWithLeading<T extends (...args: any[]) => any>(
	func: T,
	wait: number,
	leading: boolean = false
): (...args: Parameters<T>) => void {
	let timeout: ReturnType<typeof setTimeout> | null = null;
	let lastCallTime = 0;

	return (...args: Parameters<T>) => {
		const now = Date.now();

		// Leading edge: call immediately on first invocation
		if (leading && now - lastCallTime > wait) {
			func(...args);
			lastCallTime = now;
		}

		// Clear existing timeout
		if (timeout) {
			clearTimeout(timeout);
		}

		// Set new timeout for trailing edge
		timeout = setTimeout(() => {
			if (!leading || now - lastCallTime > wait) {
				func(...args);
			}
			lastCallTime = now;
			timeout = null;
		}, wait);
	};
}

/**
 * Throttle function calls to limit execution rate
 */
export function throttle<T extends (...args: any[]) => any>(
	func: T,
	limit: number
): (...args: Parameters<T>) => void {
	let inThrottle = false;
	let lastResult: any;

	return (...args: Parameters<T>) => {
		if (!inThrottle) {
			lastResult = func(...args);
			inThrottle = true;

			setTimeout(() => {
				inThrottle = false;
			}, limit);
		}

		return lastResult;
	};
}

/**
 * Request idle callback wrapper with fallback
 */
export function requestIdleCallback(
	callback: () => void,
	options?: { timeout?: number }
): number {
	if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
		return window.requestIdleCallback(callback, options);
	}

	// Fallback for browsers that don't support requestIdleCallback
	return setTimeout(callback, 1) as unknown as number;
}

/**
 * Cancel idle callback with fallback
 */
export function cancelIdleCallback(id: number): void {
	if (typeof window !== 'undefined' && 'cancelIdleCallback' in window) {
		window.cancelIdleCallback(id);
	} else {
		clearTimeout(id);
	}
}

/**
 * Batch DOM reads and writes for better performance
 */
export class DOMBatcher {
	private readQueue: Array<() => void> = [];
	private writeQueue: Array<() => void> = [];
	private scheduled = false;

	read(callback: () => void): void {
		this.readQueue.push(callback);
		this.schedule();
	}

	write(callback: () => void): void {
		this.writeQueue.push(callback);
		this.schedule();
	}

	private schedule(): void {
		if (this.scheduled) return;

		this.scheduled = true;
		requestAnimationFrame(() => {
			this.flush();
		});
	}

	private flush(): void {
		// Execute all reads first (prevents layout thrashing)
		while (this.readQueue.length) {
			const read = this.readQueue.shift();
			read?.();
		}

		// Then execute all writes
		while (this.writeQueue.length) {
			const write = this.writeQueue.shift();
			write?.();
		}

		this.scheduled = false;
	}
}

/**
 * Create a memoized version of a function
 */
export function memoize<T extends (...args: any[]) => any>(
	fn: T,
	maxCacheSize: number = 100
): T {
	const cache = new Map<string, ReturnType<T>>();

	return ((...args: Parameters<T>) => {
		const key = JSON.stringify(args);

		if (cache.has(key)) {
			return cache.get(key)!;
		}

		const result = fn(...args);

		// Implement LRU cache
		if (cache.size >= maxCacheSize) {
			const firstKey = cache.keys().next().value;
			cache.delete(firstKey);
		}

		cache.set(key, result);
		return result;
	}) as T;
}

/**
 * Get current performance metrics
 */
export function getPerformanceMetrics(): {
	navigation?: PerformanceNavigationTiming;
	resources: PerformanceResourceTiming[];
	measures: PerformanceMeasure[];
} {
	if (typeof window === 'undefined' || !window.performance) {
		return { resources: [], measures: [] };
	}

	const navigation = performance.getEntriesByType(
		'navigation'
	)[0] as PerformanceNavigationTiming;

	const resources = performance.getEntriesByType('resource') as PerformanceResourceTiming[];

	const measures = performance.getEntriesByType('measure') as PerformanceMeasure[];

	return {
		navigation,
		resources,
		measures
	};
}

/**
 * Log performance metrics to console
 */
export function logPerformanceMetrics(): void {
	const metrics = getPerformanceMetrics();

	console.group('📊 Performance Metrics');

	if (metrics.navigation) {
		const { domContentLoadedEventEnd, loadEventEnd, domContentLoadedEventStart, fetchStart } =
			metrics.navigation;

		console.log(
			`DOM Content Loaded: ${(domContentLoadedEventEnd - domContentLoadedEventStart).toFixed(2)}ms`
		);
		console.log(`Page Load: ${(loadEventEnd - fetchStart).toFixed(2)}ms`);
	}

	if (metrics.measures.length > 0) {
		console.group('Custom Measurements');
		metrics.measures.forEach((measure) => {
			console.log(`${measure.name}: ${measure.duration.toFixed(2)}ms`);
		});
		console.groupEnd();
	}

	console.groupEnd();
}
