// Utility helper functions

/**
 * Generates a unique identifier combining timestamp and random string
 * @returns A unique string ID
 * @example
 * const id = generateId(); // "1704067200000-k3j2h9d8a"
 */
export function generateId(): string {
	return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Formats duration in seconds to human-readable time string
 * @param seconds - Duration in seconds
 * @returns Formatted duration string (M:SS or H:MM:SS)
 * @example
 * formatDuration(125);   // "2:05"
 * formatDuration(3661);  // "1:01:01"
 */
export function formatDuration(seconds: number): string {
	const hours = Math.floor(seconds / 3600);
	const minutes = Math.floor((seconds % 3600) / 60);
	const secs = seconds % 60;

	if (hours > 0) {
		return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
	}
	return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Parses ISO 8601 duration format to seconds
 * @param isoDuration - ISO 8601 duration string (e.g., "PT1H30M45S")
 * @returns Total duration in seconds
 * @example
 * parseDuration("PT1H30M45S");  // 5445
 * parseDuration("PT15M");       // 900
 */
export function parseDuration(isoDuration: string): number {
	const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
	if (!match) return 0;

	const hours = parseInt(match[1] || '0');
	const minutes = parseInt(match[2] || '0');
	const seconds = parseInt(match[3] || '0');

	return hours * 3600 + minutes * 60 + seconds;
}

/**
 * Formats large numbers with K/M suffixes
 * @param num - Number to format
 * @returns Formatted string with suffix
 * @example
 * formatNumber(1234);      // "1.2K"
 * formatNumber(1500000);   // "1.5M"
 * formatNumber(999);       // "999"
 */
export function formatNumber(num: number): string {
	if (num >= 1000000) {
		return (num / 1000000).toFixed(1) + 'M';
	}
	if (num >= 1000) {
		return (num / 1000).toFixed(1) + 'K';
	}
	return num.toString();
}

/**
 * Creates a debounced version of a function that delays execution
 * @param func - Function to debounce
 * @param wait - Delay in milliseconds
 * @returns Debounced function
 * @example
 * const debouncedSearch = debounce(search, 300);
 * input.addEventListener('input', debouncedSearch);
 */
export function debounce<T extends (...args: any[]) => any>(
	func: T,
	wait: number
): (...args: Parameters<T>) => void {
	let timeout: ReturnType<typeof setTimeout>;
	return (...args: Parameters<T>) => {
		clearTimeout(timeout);
		timeout = setTimeout(() => func(...args), wait);
	};
}

/**
 * Validates API keys for different services
 * @param key - API key to validate
 * @param service - Service type ('youtube' or 'vimeo')
 * @returns True if key appears valid
 * @example
 * validateApiKey("AIzaSyD...", "youtube");  // true
 * validateApiKey("short", "youtube");       // false
 */
export function validateApiKey(key: string, service: 'youtube' | 'vimeo'): boolean {
	if (!key || key.trim() === '') return false;

	if (service === 'youtube') {
		// YouTube API keys are typically 39 characters
		return key.length >= 30;
	}

	if (service === 'vimeo') {
		// Vimeo access tokens vary in length
		return key.length >= 20;
	}

	return false;
}

/**
 * Compresses data to base64-encoded string for storage
 * @param data - Any JSON-serializable data
 * @returns Compressed base64 string
 * @example
 * const compressed = compressData({ name: "Test", value: 123 });
 */
export function compressData(data: any): string {
	const json = JSON.stringify(data);
	return btoa(encodeURIComponent(json));
}

/**
 * Decompresses base64-encoded string back to original data
 * @param compressed - Compressed base64 string
 * @returns Original data or null if invalid
 * @example
 * const data = decompressData(compressed);
 */
export function decompressData(compressed: string): any {
	try {
		const json = decodeURIComponent(atob(compressed));
		return JSON.parse(json);
	} catch (error) {
		console.error('Failed to decompress data:', error);
		return null;
	}
}
