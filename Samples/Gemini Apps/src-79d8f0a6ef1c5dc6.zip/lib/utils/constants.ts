// Application constants

export const APP_NAME = 'Vektor';
export const APP_VERSION = '0.1.0';

export const DEFAULT_QUOTA_LIMIT = 10000; // YouTube API default daily quota

export const DEFAULT_FILTERS: import('../types').ContentFilters = {
	density: 0.5,
	pace: 0.5,
	maxDuration: 0,
	formats: [],
	blockedKeywords: [],
	allowedChannels: [],
	qualityThreshold: 0
};

export const DEFAULT_PROFILE: Omit<import('../types').UserProfile, 'id'> = {
	name: 'Default Profile',
	filters: DEFAULT_FILTERS,
	sources: ['youtube'],
	appearance: {
		theme: 'auto',
		layout: 'grid'
	}
};

export const FORMAT_DETECTION_RULES = {
	tutorial: /how to|tutorial|guide|step by step|walkthrough/i,
	lecture: /lecture|course|class|university|professor/i,
	documentary: /documentary|explained|history of|story of/i,
	interview: /interview|conversation with|podcast|talk with/i,
	vlog: /vlog|day in life|my experience|daily/i
};

export const STORAGE_KEYS = {
	API_CONFIG: 'vektor_api_config',
	PROFILES: 'vektor_profiles',
	ACTIVE_PROFILE: 'vektor_active_profile',
	LEARNING_PATHS: 'vektor_learning_paths',
	SETTINGS: 'vektor_settings',
	API_HISTORY: 'vektor_api_history'
};
