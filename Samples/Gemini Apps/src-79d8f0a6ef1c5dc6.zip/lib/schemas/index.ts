// Zod schemas for data validation
import { z } from 'zod';

// Format types
export const FormatTypeSchema = z.enum([
	'tutorial',
	'lecture',
	'documentary',
	'interview',
	'vlog',
	'other'
]);

// Content Filters
export const ContentFiltersSchema = z.object({
	density: z.number().min(0).max(1),
	pace: z.number().min(0).max(1),
	maxDuration: z.number().min(0),
	formats: z.array(FormatTypeSchema),
	blockedKeywords: z.array(z.string()),
	allowedChannels: z.array(z.string()),
	qualityThreshold: z.number().min(0).max(1)
});

// User Profile
export const UserProfileSchema = z.object({
	id: z.string().min(1),
	name: z.string().min(1).max(100),
	filters: ContentFiltersSchema,
	sources: z.array(z.enum(['youtube', 'vimeo'])),
	appearance: z.object({
		theme: z.enum(['light', 'dark', 'auto']),
		layout: z.enum(['grid', 'list'])
	})
});

// Path Video
export const PathVideoSchema = z.object({
	id: z.string().min(1),
	source: z.enum(['youtube', 'vimeo']),
	sourceId: z.string().min(1),
	title: z.string().min(1),
	duration: z.number().min(0),
	order: z.number().min(0),
	required: z.boolean()
});

// Learning Path
export const LearningPathSchema = z.object({
	id: z.string().min(1),
	title: z.string().min(1).max(200),
	description: z.string().max(2000),
	objectives: z.array(z.string()),
	keywords: z.array(z.string()),
	difficulty: z.enum(['beginner', 'intermediate', 'advanced']),
	estimatedHours: z.number().min(0),
	videos: z.array(PathVideoSchema),
	progress: z.object({
		completed: z.array(z.string()),
		current: z.string(),
		notes: z.record(z.string(), z.string())
	})
});

// AI Config
export const AIConfigSchema = z.object({
	enabled: z.boolean(),
	provider: z.enum(['lm_studio', 'ollama', 'openrouter', 'mcp']),
	endpoint: z.string().url(),
	apiKey: z.string().optional(),
	model: z.string().min(1)
});

// API Config
export const ApiConfigSchema = z.object({
	youtube: z.object({
		apiKey: z.string().min(1),
		quotaUsed: z.number().min(0),
		quotaLimit: z.number().min(0)
	}),
	vimeo: z.object({
		accessToken: z.string()
	}),
	ai: AIConfigSchema
});

// Video Metadata
export const VideoMetadataSchema = z.object({
	id: z.string().min(1),
	source: z.enum(['youtube', 'vimeo']),
	sourceId: z.string().min(1),
	title: z.string().min(1),
	description: z.string(),
	duration: z.number().min(0),
	thumbnail: z.string().url(),
	channelId: z.string(),
	channelTitle: z.string(),
	publishedAt: z.string(),
	hasTranscript: z.boolean(),
	transcript: z
		.object({
			text: z.string(),
			wordCount: z.number().min(0)
		})
		.optional(),
	stats: z
		.object({
			viewCount: z.number().min(0),
			likeCount: z.number().min(0),
			commentCount: z.number().min(0)
		})
		.optional()
});

// Cast Device
export const CastDeviceSchema = z.object({
	id: z.string().min(1),
	name: z.string().min(1),
	type: z.enum(['chromecast', 'dlna', 'vektor_pwa']),
	url: z.string().url().optional()
});

// Search Result
export const SearchResultSchema = z.object({
	videos: z.array(VideoMetadataSchema),
	totalResults: z.number().min(0),
	nextPageToken: z.string().optional()
});

// Export/Import data structure
export const ExportDataSchema = z.object({
	profiles: z.array(UserProfileSchema).optional(),
	paths: z.array(LearningPathSchema).optional(),
	settings: z.any().optional(),
	version: z.string()
});

// Type exports for inference
export type ContentFilters = z.infer<typeof ContentFiltersSchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type PathVideo = z.infer<typeof PathVideoSchema>;
export type LearningPath = z.infer<typeof LearningPathSchema>;
export type AIConfig = z.infer<typeof AIConfigSchema>;
export type ApiConfig = z.infer<typeof ApiConfigSchema>;
export type VideoMetadata = z.infer<typeof VideoMetadataSchema>;
export type CastDevice = z.infer<typeof CastDeviceSchema>;
export type SearchResult = z.infer<typeof SearchResultSchema>;
export type ExportData = z.infer<typeof ExportDataSchema>;
