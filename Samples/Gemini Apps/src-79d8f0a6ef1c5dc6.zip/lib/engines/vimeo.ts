// Vimeo API client

import type { SearchResult, VideoMetadata } from '../types';
import {
	InvalidApiKeyError,
	NetworkError,
	QuotaExceededError,
	RateLimitError
} from '../utils/errors';
import { fetchWithCache } from '../utils/httpClient';

interface VimeoVideo {
	uri: string;
	name: string;
	description: string;
	duration: number;
	pictures?: {
		sizes?: Array<{ link: string }>;
	};
	stats?: {
		plays?: number;
	};
	metadata?: {
		connections?: {
			likes?: {
				total?: number;
			};
		};
	};
	user?: {
		uri?: string;
		name?: string;
	};
	release_time?: string;
	created_time?: string;
}

export class VimeoClient {
	private accessToken: string;
	private readonly BASE_URL = 'https://api.vimeo.com';

	constructor(accessToken: string) {
		this.accessToken = accessToken;
	}

	/**
	 * Search for videos
	 * @param query - Search query
	 * @param perPage - Results per page (default: 25)
	 * @param page - Page number for pagination
	 */
	async search(query: string, perPage: number = 25, page: number = 1): Promise<SearchResult> {
		const params = new URLSearchParams({
			query,
			per_page: perPage.toString(),
			page: page.toString()
		});

		try {
			const response = await fetchWithCache(`${this.BASE_URL}/videos?${params.toString()}`, {
				headers: this.getHeaders()
			});

			if (!response.ok) {
				await this.handleApiError(response);
			}

			const data = await response.json();
			const videos = (data.data as VimeoVideo[]).map((item) => this.transformVideo(item));

			// Vimeo pagination returns full URLs; extract the next page number if present
			let nextPageToken: string | undefined;
			if (data.paging?.next) {
				try {
					const nextUrl = new URL(data.paging.next);
					nextPageToken = nextUrl.searchParams.get('page') || undefined;
				} catch {
					nextPageToken = undefined;
				}
			}

			return {
				videos,
				totalResults: data.total ?? videos.length,
				nextPageToken
			};
		} catch (error) {
			if (error instanceof TypeError && error.message.includes('fetch')) {
				throw new NetworkError('Failed to connect to Vimeo API. Please check your internet connection.');
			}
			throw error;
		}
	}

	/**
	 * Get video by ID
	 */
	async getVideo(videoId: string): Promise<VideoMetadata | null> {
		try {
			const response = await fetchWithCache(`${this.BASE_URL}/videos/${videoId}`, {
				headers: this.getHeaders()
			});

			if (!response.ok) {
				await this.handleApiError(response);
			}

			const data = (await response.json()) as VimeoVideo;
			return this.transformVideo(data);
		} catch (error) {
			if (error instanceof TypeError && error.message.includes('fetch')) {
				throw new NetworkError('Failed to connect to Vimeo API. Please check your internet connection.');
			}
			throw error;
		}
	}

	/**
	 * Get channel videos (Vimeo user videos)
	 */
	async getChannelVideos(
		channelId: string,
		perPage: number = 25,
		page: number = 1
	): Promise<SearchResult> {
		const params = new URLSearchParams({
			per_page: perPage.toString(),
			page: page.toString()
		});

		try {
			const response = await fetchWithCache(
				`${this.BASE_URL}/users/${channelId}/videos?${params.toString()}`,
				{
					headers: this.getHeaders()
				}
			);

			if (!response.ok) {
				await this.handleApiError(response);
			}

			const data = await response.json();
			const videos = (data.data as VimeoVideo[]).map((item) => this.transformVideo(item));

			let nextPageToken: string | undefined;
			if (data.paging?.next) {
				try {
					const nextUrl = new URL(data.paging.next);
					nextPageToken = nextUrl.searchParams.get('page') || undefined;
				} catch {
					nextPageToken = undefined;
				}
			}

			return {
				videos,
				totalResults: data.total ?? videos.length,
				nextPageToken
			};
		} catch (error) {
			if (error instanceof TypeError && error.message.includes('fetch')) {
				throw new NetworkError('Failed to connect to Vimeo API. Please check your internet connection.');
			}
			throw error;
		}
	}

	/**
	 * Validate Vimeo access token
	 */
	async validateAccessToken(): Promise<boolean> {
		try {
			const response = await fetchWithCache(`${this.BASE_URL}/me`, {
				headers: this.getHeaders()
			});

			if (response.status === 401 || response.status === 403) {
				throw new InvalidApiKeyError('Vimeo');
			}

			return response.ok;
		} catch (error) {
			if (error instanceof InvalidApiKeyError) {
				throw error;
			}
			return false;
		}
	}

	/**
	 * Handle API errors with specific error types
	 */
	private async handleApiError(response: Response): Promise<never> {
		const status = response.status;
		let errorData: any = {};

		try {
			errorData = await response.json();
		} catch {
			// If JSON parsing fails, continue with status-based handling
		}

		const errorMessage =
			errorData?.error || errorData?.developer_message || response.statusText || 'Unknown error';

		if (status === 401 || status === 403) {
			throw new InvalidApiKeyError('Vimeo');
		}

		if (status === 429) {
			const retryAfter = response.headers.get('Retry-After');
			throw new RateLimitError(retryAfter ? parseInt(retryAfter) : undefined);
		}

		if (status === 503 || status === 500) {
			throw new NetworkError(
				`Vimeo API server error (${status}): ${errorMessage}. Please try again later.`
			);
		}

		// Vimeo rate limits can also show as 403 with specific headers
		const rateLimit = response.headers.get('X-RateLimit-Limit');
		const remaining = response.headers.get('X-RateLimit-Remaining');
		if (rateLimit && remaining === '0') {
			throw new QuotaExceededError(
				parseInt(rateLimit, 10) - parseInt(remaining || '0', 10),
				parseInt(rateLimit, 10)
			);
		}

		throw new NetworkError(`Vimeo API error (${status}): ${errorMessage}`);
	}

	private transformVideo(item: VimeoVideo): VideoMetadata {
		const videoId = item.uri?.split('/').pop() || '';
		const channelId = item.user?.uri?.split('/').pop() || '';

		const thumbnail =
			item.pictures?.sizes && item.pictures.sizes.length > 0
				? item.pictures.sizes[item.pictures.sizes.length - 1].link
				: '';

		return {
			id: videoId,
			source: 'vimeo',
			sourceId: videoId,
			title: item.name || 'Untitled Video',
			description: item.description || '',
			duration: item.duration || 0,
			thumbnail,
			channelId,
			channelTitle: item.user?.name || 'Unknown Creator',
			publishedAt: item.release_time || item.created_time || '',
			hasTranscript: false,
			stats: {
				viewCount: item.stats?.plays ?? 0,
				likeCount: item.metadata?.connections?.likes?.total ?? 0,
				commentCount: 0 // Vimeo API v3 requires extra scope; default to 0
			}
		};
	}

	private getHeaders(): Record<string, string> {
		return {
			Authorization: `Bearer ${this.accessToken}`,
			Accept: 'application/json'
		};
	}
}
