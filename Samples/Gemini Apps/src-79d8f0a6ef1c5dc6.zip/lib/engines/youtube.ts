// YouTube API client

import type { VideoMetadata, SearchResult, ApiRequestType, ChannelMetadata } from '../types';
import { parseDuration } from '../utils/helpers';
import {
	InvalidApiKeyError,
	QuotaExceededError,
	NetworkError,
	RateLimitError,
	AuthError
} from '../utils/errors';
import { fetchWithCache } from '../utils/httpClient';
import { settings } from '../stores/settings';
import { auth } from '../stores/auth';
import { get } from 'svelte/store';

// YouTube API Response Types - kept largely the same, added Channel types
interface YouTubeThumbnail {
	url: string;
	width: number;
	height: number;
}

interface YouTubeThumbnails {
	default?: YouTubeThumbnail;
	medium?: YouTubeThumbnail;
	high?: YouTubeThumbnail;
	standard?: YouTubeThumbnail;
	maxres?: YouTubeThumbnail;
}

interface YouTubeSnippet {
	publishedAt: string;
	channelId: string;
	title: string;
	description: string;
	thumbnails: YouTubeThumbnails;
	channelTitle: string;
	tags?: string[];
	categoryId?: string;
	liveBroadcastContent?: string;
	defaultLanguage?: string;
	localized?: {
		title: string;
		description: string;
	};
	defaultAudioLanguage?: string;
	// For Channels
	customUrl?: string;
}

interface YouTubeContentDetails {
	duration: string;
	dimension: string;
	definition: string;
	caption: string;
	licensedContent: boolean;
	projection: string;
}

interface YouTubeStatistics {
	viewCount?: string;
	likeCount?: string;
	dislikeCount?: string;
	favoriteCount?: string;
	commentCount?: string;
	// For Channels
	subscriberCount?: string;
	videoCount?: string;
}

interface YouTubeSearchItem {
	kind: string;
	etag: string;
	id: {
		kind: string;
		videoId: string;
	};
	snippet: YouTubeSnippet;
}

interface YouTubeVideoItem {
	kind: string;
	etag: string;
	id: string;
	snippet: YouTubeSnippet;
	contentDetails: YouTubeContentDetails;
	statistics: YouTubeStatistics;
}

interface YouTubeChannelItem {
	kind: string;
	etag: string;
	id: string;
	snippet: YouTubeSnippet;
	statistics: YouTubeStatistics;
}

interface YouTubePageInfo {
	totalResults: number;
	resultsPerPage: number;
}

interface YouTubeSearchResponse {
	kind: string;
	etag: string;
	nextPageToken?: string;
	prevPageToken?: string;
	regionCode?: string;
	pageInfo: YouTubePageInfo;
	items: YouTubeSearchItem[];
}

interface YouTubeVideosResponse {
	kind: string;
	etag: string;
	pageInfo: YouTubePageInfo;
	items: YouTubeVideoItem[];
}

interface YouTubeChannelsResponse {
	kind: string;
	etag: string;
	pageInfo: YouTubePageInfo;
	items: YouTubeChannelItem[];
}

interface YouTubeErrorDetail {
	message: string;
	domain: string;
	reason: string;
}

interface YouTubeErrorResponse {
	error?: {
		code: number;
		message: string;
		errors?: YouTubeErrorDetail[];
		status?: string;
	};
}

export class YouTubeClient {
	private apiKeys: string[];
	private activeKeyIndex: number;
	private quotaUsed: number = 0;
	private readonly BASE_URL = 'https://www.googleapis.com/youtube/v3';
	private onRequestLog?: (record: {
		timestamp: number;
		type: ApiRequestType;
		endpoint: string;
		quotaCost: number;
		parameters: Record<string, string | number>;
		resultCount?: number;
		success: boolean;
		error?: string;
		responseTime?: number;
		apiKey?: string;
	}) => void;

	constructor(
		apiKeys: string | string[],
		onRequestLog?: typeof YouTubeClient.prototype.onRequestLog
	) {
		this.apiKeys = Array.isArray(apiKeys) ? apiKeys : [apiKeys];
		// If we have settings store available, try to get the active index, otherwise default to 0
		const currentSettings = get(settings);
		this.activeKeyIndex = currentSettings?.youtube.activeKeyIndex || 0;
		this.onRequestLog = onRequestLog;
	}

	private get activeKey(): string {
		return this.apiKeys[this.activeKeyIndex] || '';
	}

	/**
	 * Log an API request
	 */
	private logRequest(
		type: ApiRequestType,
		endpoint: string,
		quotaCost: number,
		parameters: Record<string, string | number>,
		resultCount: number | undefined,
		success: boolean,
		error: string | undefined,
		responseTime: number | undefined
	) {
		if (this.onRequestLog) {
			this.onRequestLog({
				timestamp: Date.now(),
				type,
				endpoint,
				quotaCost,
				parameters,
				resultCount,
				success,
				error,
				responseTime,
				apiKey: this.apiKey
			});
		}
	}

	/**
	 * Internal fetch wrapper that handles:
	 * 1. OAuth Tokens (if user is logged in)
	 * 2. API Key Rotation (on 403 Quota Exceeded)
	 * 3. Logging
	 */
	private async fetchFromApi<T>(
		endpoint: string,
		params: URLSearchParams,
		requestType: ApiRequestType,
		quotaCost: number,
		requireOAuth: boolean = false
	): Promise<T> {
		const startTime = Date.now();
		const url = `${this.BASE_URL}/${endpoint}`;

		// OAuth Handling
		const authState = get(auth);
		const headers: Record<string, string> = {};

		if (authState.isAuthenticated && authState.accessToken) {
			headers['Authorization'] = `Bearer ${authState.accessToken}`;
		} else if (requireOAuth) {
			throw new AuthError('This feature requires you to connect your YouTube account.');
		} else {
			// Use API Key if not using OAuth
			params.set('key', this.activeKey);
		}

		let attempts = 0;
		const maxAttempts = requireOAuth ? 1 : this.apiKeys.length; // Don't rotate keys for OAuth, only for API Key calls

		while (attempts < maxAttempts) {
			attempts++;
			try {
				const response = await fetchWithCache(`${url}?${params}`, { headers });

				if (!response.ok) {
					await this.handleApiError(response);
				}

				const data: T = await response.json();

				// Success!
				this.quotaUsed += quotaCost;
				try { settings.updateQuota(this.quotaUsed); } catch { } // Fire and forget

				// Log success
				const responseTime = Date.now() - startTime;
				this.logRequest(requestType, url, quotaCost, Object.fromEntries(params), Array.isArray((data as any).items) ? (data as any).items.length : 1, true, undefined, responseTime);

				return data;

			} catch (error) {
				// If OAuth, fail immediately (cannot rotate user creds)
				if (requireOAuth) {
					this.logError(requestType, url, quotaCost, params, error, startTime);
					throw error;
				}

				// API Key Handling
				if (error instanceof QuotaExceededError) {
					console.warn(`Key at index ${this.activeKeyIndex} exhausted. Rotating...`);

					// Try to rotate via store
					const nextKey = await settings.rotateKey();
					if (nextKey) {
						this.activeKeyIndex = (this.activeKeyIndex + 1) % this.apiKeys.length;
						params.set('key', this.activeKey); // Update param with new key
						continue; // Retry loop
					} else {
						// No more keys or rotation failed
						this.logError(requestType, url, quotaCost, params, error, startTime);
						throw error;
					}
				}

				// If other error, log and throw
				this.logError(requestType, url, quotaCost, params, error, startTime);
				if (error instanceof TypeError && error.message.includes('fetch')) {
					throw new NetworkError('Failed to connect to YouTube API. Please check your internet connection.');
				}
				throw error;
			}
		}

		throw new NetworkError('Failed to complete request after retries');
	}

	private logError(
		type: ApiRequestType,
		endpoint: string,
		quotaCost: number,
		params: URLSearchParams,
		error: any,
		startTime: number
	) {
		this.logRequest(
			type,
			endpoint,
			quotaCost,
			Object.fromEntries(params),
			undefined,
			false,
			error instanceof Error ? error.message : 'Unknown error',
			Date.now() - startTime
		);
	}

	/**
	 * Search for videos
	 */
	async search(query: string, maxResults: number = 25, pageToken?: string): Promise<SearchResult> {
		const params = new URLSearchParams({
			part: 'snippet',
			q: query,
			type: 'video',
			maxResults: maxResults.toString()
		});
		if (pageToken) params.append('pageToken', pageToken);

		const data = await this.fetchFromApi<YouTubeSearchResponse>('search', params, 'search', 100);

		// Get video details for all results
		const videoIds = data.items.map((item) => item.id.videoId).join(',');
		const videos = videoIds ? await this.getVideoDetails(videoIds) : [];

		return {
			videos,
			totalResults: data.pageInfo.totalResults,
			nextPageToken: data.nextPageToken
		};
	}

	/**
	 * Get detailed video information
	 */
	async getVideoDetails(videoIds: string): Promise<VideoMetadata[]> {
		const params = new URLSearchParams({
			part: 'snippet,contentDetails,statistics',
			id: videoIds
		});

		const data = await this.fetchFromApi<YouTubeVideosResponse>('videos', params, 'videoDetails', 1);
		return data.items.map((item) => this.transformVideo(item));
	}

	/**
	 * Get Channel Details (Batch)
	 */
	async getChannelDetails(channelIds: string[]): Promise<ChannelMetadata[]> {
		if (channelIds.length === 0) return [];

		const params = new URLSearchParams({
			part: 'snippet,statistics',
			id: channelIds.join(',')
		});

		const data = await this.fetchFromApi<YouTubeChannelsResponse>('channels', params, 'channelVideos', 1); // Using 'channelVideos' as type for now or add new type

		return data.items.map(item => ({
			id: item.id,
			title: item.snippet.title,
			description: item.snippet.description,
			thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default?.url || '',
			customUrl: item.snippet.customUrl,
			stats: {
				viewCount: parseInt(item.statistics.viewCount || '0'),
				subscriberCount: parseInt(item.statistics.subscriberCount || '0'),
				videoCount: parseInt(item.statistics.videoCount || '0')
			}
		}));
	}

	/**
	 * Get Liked Videos (OAuth Required)
	 */
	async getLikedVideos(maxResults: number = 50, pageToken?: string): Promise<SearchResult> {
		const params = new URLSearchParams({
			part: 'snippet,contentDetails,statistics',
			myRating: 'like',
			maxResults: maxResults.toString()
		});
		if (pageToken) params.append('pageToken', pageToken);

		// Note: 'videos' endpoint with myRating=like returns Video resources directly, not SearchResults
		const data = await this.fetchFromApi<YouTubeVideosResponse>('videos', params, 'search', 1, true);
		const videos = data.items.map(item => this.transformVideo(item));

		return {
			videos,
			totalResults: data.pageInfo.totalResults,
			nextPageToken: undefined // Videos endpoint doesn't always handle pagination same as search for likes
		};
	}

	/**
	 * Get Subscriptions (OAuth Required)
	 */
	async getSubscriptions(maxResults: number = 50, pageToken?: string): Promise<ChannelMetadata[]> {
		const params = new URLSearchParams({
			part: 'snippet,contentDetails', // 'statistics' not available in subscriptions resource standard list
			mine: 'true',
			maxResults: maxResults.toString()
		});
		if (pageToken) params.append('pageToken', pageToken);

		// This returns Subscription resources, which contain "snippet.resourceId.channelId"
		// We technically need to fetch Channel details separately to get stats, but we can get title/thumb here.
		interface SubscriptionListResponse {
			items: {
				snippet: {
					title: string;
					description: string;
					thumbnails: YouTubeThumbnails;
					resourceId: { channelId: string };
				}
			}[]
		}

		const data = await this.fetchFromApi<SubscriptionListResponse>('subscriptions', params, 'channelVideos', 1, true);

		return data.items.map(item => ({
			id: item.snippet.resourceId.channelId,
			title: item.snippet.title,
			description: item.snippet.description,
			thumbnail: item.snippet.thumbnails.medium?.url || '',
			stats: { viewCount: 0, subscriberCount: 0, videoCount: 0 } // Cannot get stats from sub list directly
		}));
	}

	/**
	 * Get video by ID
	 */
	async getVideo(videoId: string): Promise<VideoMetadata | null> {
		const videos = await this.getVideoDetails(videoId);
		return videos[0] || null;
	}

	/**
	 * Get channel videos
	 */
	async getChannelVideos(
		channelId: string,
		maxResults: number = 25,
		pageToken?: string
	): Promise<SearchResult> {
		const params = new URLSearchParams({
			part: 'snippet',
			channelId: channelId,
			type: 'video',
			order: 'date',
			maxResults: maxResults.toString()
		});
		if (pageToken) params.append('pageToken', pageToken);

		const data = await this.fetchFromApi<YouTubeSearchResponse>('search', params, 'channelVideos', 100);

		const videoIds = data.items.map((item) => item.id.videoId).join(',');
		const videos = await this.getVideoDetails(videoIds);

		return {
			videos,
			totalResults: data.pageInfo.totalResults,
			nextPageToken: data.nextPageToken
		};
	}

	/**
	 * Validate API key
	 */
	async validateApiKey(): Promise<boolean> {
		// Simple test with current active key
		const params = new URLSearchParams({
			part: 'snippet',
			id: 'dQw4w9WgXcQ',
		});

		// Use raw fetch to avoid rotation logic interfering with specific validation
		const url = `${this.BASE_URL}/videos?part=snippet&id=dQw4w9WgXcQ&key=${this.activeKey}`;
		const startTime = Date.now();

		try {
			const response = await fetchWithCache(url);
			const success = response.ok;

			this.logRequest('validation', url, 1, { id: 'dQw4w9WgXcQ' }, success ? 1 : 0, success, success ? undefined : `HTTP ${response.status}`, Date.now() - startTime);

			if (!response.ok) {
				if (response.status === 400 || response.status === 403) {
					throw new InvalidApiKeyError('YouTube');
				}
			}
			return response.ok;
		} catch (error) {
			if (error instanceof InvalidApiKeyError) {
				throw error;
			}
			return false;
		}
	}

	/**
	 * Handle API errors with specific error types
	 */
	private async handleApiError(response: Response): Promise<never> {
		const status = response.status;
		let errorData: YouTubeErrorResponse = {};

		try {
			errorData = await response.json();
		} catch {
			// If JSON parsing fails, continue with status-based handling
		}

		// Extract error message from YouTube API response
		const errorMessage =
			errorData.error?.message || response.statusText || 'Unknown error';
		const errorReason = errorData.error?.errors?.[0]?.reason;

		// Handle specific error types
		if (status === 400 || status === 403) {
			if (errorReason === 'quotaExceeded' || errorMessage.toLowerCase().includes('quota')) {
				throw new QuotaExceededError(this.quotaUsed, 10000);
			}
			if (
				errorReason === 'keyInvalid' ||
				errorReason === 'invalidKey' ||
				errorMessage.toLowerCase().includes('api key')
			) {
				throw new InvalidApiKeyError('YouTube');
			}

			// OAuth Errors
			if (status === 403 && errorMessage.includes('insufficient')) { // insufficientPermissions
				throw new AuthError('Access denied. Please check your permissions.');
			}
		}

		if (status === 429) {
			const retryAfter = response.headers.get('Retry-After');
			throw new RateLimitError(retryAfter ? parseInt(retryAfter) : undefined);
		}

		if (status === 401) {
			throw new AuthError('Session expired. Please reconnect your account.');
		}

		if (status >= 500) {
			throw new NetworkError(
				`YouTube API server error (${status}): ${errorMessage}. Please try again later.`
			);
		}

		// Generic error for other cases
		throw new NetworkError(`YouTube API error (${status}): ${errorMessage}`);
	}

	/**
	 * Transform YouTube API response to VideoMetadata
	 */
	private transformVideo(item: YouTubeVideoItem): VideoMetadata {
		const { snippet, contentDetails, statistics } = item;

		return {
			id: item.id,
			source: 'youtube',
			sourceId: item.id,
			title: snippet.title,
			description: snippet.description,
			duration: parseDuration(contentDetails.duration),
			thumbnail: snippet.thumbnails.high?.url || snippet.thumbnails.default?.url || '',
			channelId: snippet.channelId,
			channelTitle: snippet.channelTitle,
			publishedAt: snippet.publishedAt,
			hasTranscript: false,
			stats: {
				viewCount: parseInt(statistics.viewCount || '0', 10),
				likeCount: parseInt(statistics.likeCount || '0', 10),
				commentCount: parseInt(statistics.commentCount || '0', 10)
			}
		};
	}

	/**
	 * Get current quota usage
	 */
	getQuotaUsed(): number {
		return this.quotaUsed;
	}

	/**
	 * Reset quota counter (call this daily)
	 */
	resetQuota(): void {
		this.quotaUsed = 0;
	}

	// Transcript method remains the same (OAuth required but handled via external services usually)
	async getTranscript(_videoId: string): Promise<{ text: string; wordCount: number } | null> {
		return null;
	}
}
