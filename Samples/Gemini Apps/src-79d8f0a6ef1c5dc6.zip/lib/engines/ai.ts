// AI integration layer for optional LLM features

import type { AIConfig, LearningPath, UserProfile } from '../types';
import { generateId } from '../utils/helpers';

export class AIService {
	private config: AIConfig;

	constructor(config: AIConfig) {
		this.config = config;
	}

	/**
	 * Check if AI is enabled
	 */
	isEnabled(): boolean {
		return this.config.enabled && !!this.config.endpoint;
	}

	/**
	 * Enhance search query based on user profile
	 */
	async enhanceSearch(query: string, profile: UserProfile): Promise<string[]> {
		if (!this.isEnabled()) {
			return [query];
		}

		try {
			const prompt = `
You are a search query optimizer for educational video content discovery.

Expand this search query to find relevant educational videos:
Original query: "${query}"

User preferences:
- Content density preference: ${profile.filters.density} (0=light, 1=deep/in-depth)
- Pace preference: ${profile.filters.pace} (0=slow, 1=fast)
- Preferred formats: ${profile.filters.formats.join(', ') || 'any'}

Generate 5 alternative search queries that would help find relevant content matching these preferences.
Return ONLY a JSON array of strings, no other text.

Example format: ["query 1", "query 2", "query 3", "query 4", "query 5"]
			`.trim();

			const result = await this.queryLLM(prompt, true);

			if (Array.isArray(result)) {
				return [query, ...result.slice(0, 5)];
			}

			return [query];
		} catch (error) {
			console.error('AI search enhancement failed:', error);
			return [query];
		}
	}

	/**
	 * Generate a learning path for a topic
	 */
	async generateLearningPath(topic: string, level: string): Promise<LearningPath | null> {
		if (!this.isEnabled()) {
			return null;
		}

		try {
			const prompt = `
You are an expert curriculum designer for self-directed learning.

Create a comprehensive learning path for the following topic:
Topic: "${topic}"
Level: ${level}

Generate a structured learning path with:
1. A clear title and description
2. 3-5 learning objectives
3. 8-12 video topics that should be watched in order
4. Difficulty rating
5. Estimated total hours

Return ONLY a JSON object in this exact format:
{
	"title": "string",
	"description": "string",
	"objectives": ["objective1", "objective2", ...],
	"difficulty": "beginner|intermediate|advanced",
	"estimatedHours": number,
	"videoTopics": [
		{
			"title": "video topic/title to search for",
			"order": number,
			"required": boolean
		},
		...
	]
}
			`.trim();

			const result = await this.queryLLM(prompt, true);

			if (!result || typeof result !== 'object') {
				return null;
			}

			// Transform AI response to LearningPath
			const path: LearningPath = {
				id: generateId(),
				title: result.title || `Learning Path: ${topic}`,
				description: result.description || '',
				objectives: result.objectives || [],
				keywords: [topic],
				difficulty: result.difficulty || level,
				estimatedHours: result.estimatedHours || 10,
				videos: [], // Videos will be populated by searching
				progress: {
					completed: [],
					current: '',
					notes: {}
				}
			};

			return path;
		} catch (error) {
			console.error('AI learning path generation failed:', error);
			return null;
		}
	}

	/**
	 * Analyze video content and suggest categorization
	 */
	async analyzeVideo(title: string, description: string): Promise<{
		format: string;
		difficulty: string;
		topics: string[];
		suggestedKeywords: string[];
	} | null> {
		if (!this.isEnabled()) {
			return null;
		}

		try {
			const prompt = `
Analyze this video and provide categorization:

Title: "${title}"
Description: "${description}"

Return ONLY a JSON object with:
{
	"format": "tutorial|lecture|documentary|interview|vlog|other",
	"difficulty": "beginner|intermediate|advanced",
	"topics": ["topic1", "topic2", ...],
	"suggestedKeywords": ["keyword1", "keyword2", ...]
}
			`.trim();

			return await this.queryLLM(prompt, true);
		} catch (error) {
			console.error('AI video analysis failed:', error);
			return null;
		}
	}

	/**
	 * Query the configured LLM
	 */
	private async queryLLM(prompt: string, expectJson: boolean = false): Promise<any> {
		const endpoint = this.getEndpoint();
		const headers: Record<string, string> = {
			'Content-Type': 'application/json'
		};

		if (this.config.apiKey) {
			headers['Authorization'] = `Bearer ${this.config.apiKey}`;
		}

		const body: any = {
			model: this.config.model,
			messages: [{ role: 'user', content: prompt }],
			temperature: 0.7,
			max_tokens: 1000
		};

		if (expectJson && this.supportsJsonMode()) {
			body.response_format = { type: 'json_object' };
		}

		const response = await fetch(endpoint, {
			method: 'POST',
			headers,
			body: JSON.stringify(body)
		});

		if (!response.ok) {
			throw new Error(`LLM API error: ${response.statusText}`);
		}

		const data = await response.json();
		const content = data.choices?.[0]?.message?.content || '';

		if (expectJson) {
			try {
				return JSON.parse(content);
			} catch {
				// Try to extract JSON from markdown code blocks
				const jsonMatch = content.match(/```json\n?([\s\S]*?)\n?```/);
				if (jsonMatch) {
					return JSON.parse(jsonMatch[1]);
				}
				// Try to parse as-is
				return JSON.parse(content);
			}
		}

		return content;
	}

	/**
	 * Get the correct API endpoint based on provider
	 */
	private getEndpoint(): string {
		const base = this.config.endpoint.replace(/\/$/, '');

		switch (this.config.provider) {
			case 'lm_studio':
			case 'ollama':
				return `${base}/v1/chat/completions`;
			case 'openrouter':
				return 'https://openrouter.ai/api/v1/chat/completions';
			case 'mcp':
				return `${base}/chat/completions`;
			default:
				return base;
		}
	}

	/**
	 * Check if provider supports JSON mode
	 */
	private supportsJsonMode(): boolean {
		return ['openrouter', 'lm_studio'].includes(this.config.provider);
	}

	/**
	 * Validate AI configuration
	 */
	async validateConfig(): Promise<boolean> {
		if (!this.config.enabled || !this.config.endpoint) {
			return false;
		}

		try {
			await this.queryLLM('Say "ok"', false);
			return true;
		} catch {
			return false;
		}
	}
}
