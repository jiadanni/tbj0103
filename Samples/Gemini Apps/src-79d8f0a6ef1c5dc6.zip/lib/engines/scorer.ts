// Content scoring engine with heuristics

import type { VideoMetadata, FormatType } from '../types';
import { FORMAT_DETECTION_RULES } from '../utils/constants';

export class ContentScorer {
	/**
	 * Calculate content density (0-1 scale)
	 * Higher density = more in-depth, longer content
	 */
	calculateDensity(video: VideoMetadata): number {
		// Base score from duration (20min = 1.0)
		const baseScore = Math.min(video.duration / 1200, 1);

		// Bonus for transcript availability
		const transcriptBonus = video.hasTranscript ? 0.3 : 0;

		// Bonus for detailed description
		const descriptionBonus = video.description.length > 500 ? 0.2 : 0;

		return Math.min(baseScore + transcriptBonus + descriptionBonus, 1);
	}

	/**
	 * Calculate content pace (0-1 scale)
	 * Based on words per minute if transcript available
	 */
	calculatePace(video: VideoMetadata): number {
		if (!video.transcript) return 0.5; // Default medium pace

		const wpm = (video.transcript.wordCount / video.duration) * 60;

		// 250 WPM = 1.0 (fast pace)
		// 150 WPM = 0.5 (medium pace)
		// 50 WPM = 0.2 (slow pace)
		return Math.min(wpm / 250, 1);
	}

	/**
	 * Detect video format based on title and description
	 */
	detectFormat(video: VideoMetadata): FormatType {
		const text = `${video.title} ${video.description}`.toLowerCase();

		for (const [format, pattern] of Object.entries(FORMAT_DETECTION_RULES)) {
			if (pattern.test(text)) {
				return format as FormatType;
			}
		}

		return 'other';
	}

	/**
	 * Calculate quality score (0-1 scale)
	 * Based on engagement metrics
	 */
	calculateQuality(video: VideoMetadata): number {
		if (!video.stats) return 0.5; // Default medium quality

		const { viewCount, likeCount, commentCount } = video.stats;

		if (viewCount === 0) return 0;

		// Like ratio (weighted 70%)
		const likeRatio = likeCount / viewCount;

		// Comment ratio (weighted 30%)
		const commentRatio = commentCount / viewCount;

		// Normalize to 0-1 scale
		return Math.min((likeRatio * 0.7 + commentRatio * 0.3) * 10, 1);
	}

	/**
	 * Calculate overall score for a video based on profile filters
	 */
	scoreVideo(video: VideoMetadata, filters: import('../types').ContentFilters): number {
		let score = 1.0;

		// Density matching
		const density = this.calculateDensity(video);
		const densityDiff = Math.abs(density - filters.density);
		score *= 1 - densityDiff * 0.3; // Max 30% penalty

		// Pace matching
		const pace = this.calculatePace(video);
		const paceDiff = Math.abs(pace - filters.pace);
		score *= 1 - paceDiff * 0.2; // Max 20% penalty

		// Duration filter
		if (filters.maxDuration > 0 && video.duration > filters.maxDuration * 60) {
			score *= 0.5; // 50% penalty for exceeding max duration
		}

		// Format filter
		if (filters.formats.length > 0) {
			const format = this.detectFormat(video);
			if (!filters.formats.includes(format)) {
				score *= 0.3; // Heavy penalty for wrong format
			}
		}

		// Quality threshold
		const quality = this.calculateQuality(video);
		if (quality < filters.qualityThreshold) {
			score *= 0.2; // Heavy penalty for low quality
		}

		// Blocked keywords
		const text = `${video.title} ${video.description}`.toLowerCase();
		for (const keyword of filters.blockedKeywords) {
			if (text.includes(keyword.toLowerCase())) {
				return 0; // Instant rejection
			}
		}

		// Allowed channels (whitelist)
		if (filters.allowedChannels.length > 0) {
			if (!filters.allowedChannels.includes(video.channelId)) {
				score *= 0.1; // Heavy penalty for non-whitelisted channels
			}
		}

		return Math.max(0, Math.min(1, score));
	}

	/**
	 * Sort videos by score
	 */
	rankVideos(
		videos: VideoMetadata[],
		filters: import('../types').ContentFilters
	): VideoMetadata[] {
		return videos
			.map((video) => ({
				video,
				score: this.scoreVideo(video, filters)
			}))
			.sort((a, b) => b.score - a.score)
			.map((item) => item.video);
	}
}

export const scorer = new ContentScorer();
