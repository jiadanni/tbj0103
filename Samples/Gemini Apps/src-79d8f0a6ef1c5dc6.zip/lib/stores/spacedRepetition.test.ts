import { describe, it, expect, beforeEach, vi } from 'vitest';
import { get } from 'svelte/store';
import { spacedRepetition, dueCardsCount, type ReviewCard, type ReviewQuality } from './spacedRepetition';

const mockVideo = {
	id: 'test-video-1',
	title: 'Test Video',
	description: 'Test description',
	thumbnail: 'https://example.com/thumb.jpg',
	channelTitle: 'Test Channel',
	channelId: 'test-channel',
	publishedAt: '2024-01-01',
	duration: 600,
	viewCount: 1000,
	likeCount: 100,
	tags: ['test'],
	categoryId: '27'
};

describe('Spaced Repetition Store', () => {
	beforeEach(() => {
		localStorage.clear();
		vi.clearAllMocks();
	});

	describe('addCard', () => {
		it('should add a new review card', () => {
			const card = spacedRepetition.addCard(mockVideo, 'test-path');

			expect(card.videoId).toBe('test-video-1');
			expect(card.pathId).toBe('test-path');
		});

		it('should initialize card with default SM-2 values', () => {
			const card = spacedRepetition.addCard(mockVideo);

			expect(card.easinessFactor).toBe(2.5);
			expect(card.interval).toBe(1);
			expect(card.repetitions).toBe(0);
		});
	});

	describe('reviewCard - SM-2 Algorithm', () => {
		it('should reset interval to 1 for quality < 3', () => {
			const card = spacedRepetition.addCard(mockVideo);
			spacedRepetition.reviewCard(card.id, 2);

			const dueCards = spacedRepetition.getDueCards();
			// Card should still exist (though not yet due for review)
			expect(dueCards.length).toBeGreaterThanOrEqual(0);
		});

		it('should handle quality values from 0 to 5', () => {
			const qualities: ReviewQuality[] = [0, 1, 2, 3, 4, 5];
			
			qualities.forEach((quality) => {
				const card = spacedRepetition.addCard({ ...mockVideo, id: `video-${quality}` });
				expect(() => spacedRepetition.reviewCard(card.id, quality)).not.toThrow();
			});
		});
	});

	describe('getDueCards', () => {
		it('should return an array', () => {
			const dueCards = spacedRepetition.getDueCards();
			expect(Array.isArray(dueCards)).toBe(true);
		});

		it('should sort cards by nextReview', () => {
			const dueCards = spacedRepetition.getDueCards();
			
			if (dueCards.length > 1) {
				for (let i = 0; i < dueCards.length - 1; i++) {
					expect(dueCards[i].nextReview).toBeLessThanOrEqual(dueCards[i + 1].nextReview);
				}
			}
		});
	});

	describe('dueCardsCount', () => {
		it('should be a number', () => {
			const count = get(dueCardsCount);
			expect(typeof count).toBe('number');
		});
	});

	describe('removeCard', () => {
		it('should remove a card', () => {
			const card = spacedRepetition.addCard(mockVideo);
			spacedRepetition.removeCard(card.id);
			
			const dueCards = spacedRepetition.getDueCards();
			expect(dueCards.find((c) => c.id === card.id)).toBeUndefined();
		});
	});

	describe('getStats', () => {
		it('should return statistics object', () => {
			const stats = spacedRepetition.getStats();

			expect(stats).toHaveProperty('totalCards');
			expect(stats).toHaveProperty('dueCards');
			expect(typeof stats.totalCards).toBe('number');
			expect(typeof stats.dueCards).toBe('number');
		});
	});

	describe('getCardsByPath', () => {
		it('should return cards for a specific path', () => {
			spacedRepetition.addCard(mockVideo, 'path-1');
			spacedRepetition.addCard({ ...mockVideo, id: 'video-2' }, 'path-2');

			const path1Cards = spacedRepetition.getCardsByPath('path-1');
			expect(Array.isArray(path1Cards)).toBe(true);
		});
	});

	describe('getUpcomingCards', () => {
		it('should return upcoming cards within specified days', () => {
			const upcomingCards = spacedRepetition.getUpcomingCards(7);
			expect(Array.isArray(upcomingCards)).toBe(true);
		});
	});
});
