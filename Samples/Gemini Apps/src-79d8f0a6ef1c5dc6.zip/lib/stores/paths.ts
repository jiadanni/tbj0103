// Learning paths store

import { writable, get } from 'svelte/store';
import type { LearningPath } from '../types';
import { storage } from '../services/storage';
import { generateId } from '../utils/helpers';

function createPathsStore() {
	const { subscribe, set, update } = writable<LearningPath[]>([]);

	return {
		subscribe,
		set,
		update,

		// Initialize from storage
		async init() {
			const paths = await storage.getLearningPaths();
			set(paths);
		},

		// Add a new path
		async add(path: Omit<LearningPath, 'id'>) {
			const newPath: LearningPath = {
				...path,
				id: generateId()
			};

			await storage.saveLearningPath(newPath);
			update((paths) => [...paths, newPath]);
			return newPath;
		},

		// Update a path
		async updatePath(id: string, updates: Partial<LearningPath>) {
			const paths = get({ subscribe });
			const index = paths.findIndex((p) => p.id === id);

			if (index >= 0) {
				const updated = { ...paths[index], ...updates };
				await storage.saveLearningPath(updated);
				set([...paths.slice(0, index), updated, ...paths.slice(index + 1)]);
			}
		},

		// Delete a path
		async delete(id: string) {
			await storage.deleteLearningPath(id);
			update((paths) => paths.filter((p) => p.id !== id));
		},

		// Mark video as completed
		async completeVideo(pathId: string, videoId: string) {
			const paths = get({ subscribe });
			const path = paths.find((p) => p.id === pathId);

			if (path && !path.progress.completed.includes(videoId)) {
				const updated = {
					...path,
					progress: {
						...path.progress,
						completed: [...path.progress.completed, videoId]
					}
				};

				await storage.saveLearningPath(updated);

				const index = paths.findIndex((p) => p.id === pathId);
				set([...paths.slice(0, index), updated, ...paths.slice(index + 1)]);
			}
		},

		// Set current video
		async setCurrentVideo(pathId: string, videoId: string) {
			const paths = get({ subscribe });
			const path = paths.find((p) => p.id === pathId);

			if (path) {
				const updated = {
					...path,
					progress: {
						...path.progress,
						current: videoId
					}
				};

				await storage.saveLearningPath(updated);

				const index = paths.findIndex((p) => p.id === pathId);
				set([...paths.slice(0, index), updated, ...paths.slice(index + 1)]);
			}
		},

		// Add note to video
		async addNote(pathId: string, videoId: string, note: string) {
			const paths = get({ subscribe });
			const path = paths.find((p) => p.id === pathId);

			if (path) {
				const updated = {
					...path,
					progress: {
						...path.progress,
						notes: {
							...path.progress.notes,
							[videoId]: note
						}
					}
				};

				await storage.saveLearningPath(updated);

				const index = paths.findIndex((p) => p.id === pathId);
				set([...paths.slice(0, index), updated, ...paths.slice(index + 1)]);
			}
		}
	};
}

export const paths = createPathsStore();
