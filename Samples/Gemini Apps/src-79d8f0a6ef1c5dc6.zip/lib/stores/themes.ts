// Custom theme management

import { writable, get } from 'svelte/store';

export interface Theme {
	id: string;
	name: string;
	description: string;
	colors: {
		primary: string;
		secondary: string;
		accent: string;
		background: string;
		surface: string;
		text: string;
		textSecondary: string;
		border: string;
		success: string;
		warning: string;
		error: string;
		info: string;
	};
	fonts: {
		heading: string;
		body: string;
		mono: string;
	};
	borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'xl';
	isCustom: boolean;
	createdAt: number;
}

const STORAGE_KEY = 'vektor_themes';
const ACTIVE_THEME_KEY = 'vektor_active_theme';

// Pre-defined themes
export const DEFAULT_THEMES: Theme[] = [
	{
		id: 'default',
		name: 'Default',
		description: 'Clean and modern default theme',
		colors: {
			primary: '#0ea5e9',
			secondary: '#64748b',
			accent: '#8b5cf6',
			background: '#ffffff',
			surface: '#f8fafc',
			text: '#1e293b',
			textSecondary: '#64748b',
			border: '#e2e8f0',
			success: '#10b981',
			warning: '#f59e0b',
			error: '#ef4444',
			info: '#3b82f6'
		},
		fonts: {
			heading: 'system-ui, -apple-system, sans-serif',
			body: 'system-ui, -apple-system, sans-serif',
			mono: 'ui-monospace, monospace'
		},
		borderRadius: 'md',
		isCustom: false,
		createdAt: Date.now()
	},
	{
		id: 'dark',
		name: 'Dark',
		description: 'Easy on the eyes dark theme',
		colors: {
			primary: '#3b82f6',
			secondary: '#6b7280',
			accent: '#8b5cf6',
			background: '#0f172a',
			surface: '#1e293b',
			text: '#f1f5f9',
			textSecondary: '#94a3b8',
			border: '#334155',
			success: '#10b981',
			warning: '#f59e0b',
			error: '#ef4444',
			info: '#3b82f6'
		},
		fonts: {
			heading: 'system-ui, -apple-system, sans-serif',
			body: 'system-ui, -apple-system, sans-serif',
			mono: 'ui-monospace, monospace'
		},
		borderRadius: 'md',
		isCustom: false,
		createdAt: Date.now()
	},
	{
		id: 'nord',
		name: 'Nord',
		description: 'Arctic, north-bluish color palette',
		colors: {
			primary: '#88c0d0',
			secondary: '#81a1c1',
			accent: '#b48ead',
			background: '#2e3440',
			surface: '#3b4252',
			text: '#eceff4',
			textSecondary: '#d8dee9',
			border: '#4c566a',
			success: '#a3be8c',
			warning: '#ebcb8b',
			error: '#bf616a',
			info: '#5e81ac'
		},
		fonts: {
			heading: 'system-ui, -apple-system, sans-serif',
			body: 'system-ui, -apple-system, sans-serif',
			mono: 'ui-monospace, monospace'
		},
		borderRadius: 'md',
		isCustom: false,
		createdAt: Date.now()
	},
	{
		id: 'solarized',
		name: 'Solarized',
		description: 'Precision colors for machines and people',
		colors: {
			primary: '#268bd2',
			secondary: '#657b83',
			accent: '#d33682',
			background: '#002b36',
			surface: '#073642',
			text: '#839496',
			textSecondary: '#586e75',
			border: '#073642',
			success: '#859900',
			warning: '#b58900',
			error: '#dc322f',
			info: '#268bd2'
		},
		fonts: {
			heading: 'system-ui, -apple-system, sans-serif',
			body: 'system-ui, -apple-system, sans-serif',
			mono: 'ui-monospace, monospace'
		},
		borderRadius: 'sm',
		isCustom: false,
		createdAt: Date.now()
	},
	{
		id: 'forest',
		name: 'Forest',
		description: 'Natural green tones',
		colors: {
			primary: '#059669',
			secondary: '#10b981',
			accent: '#34d399',
			background: '#064e3b',
			surface: '#065f46',
			text: '#d1fae5',
			textSecondary: '#a7f3d0',
			border: '#047857',
			success: '#10b981',
			warning: '#fbbf24',
			error: '#ef4444',
			info: '#3b82f6'
		},
		fonts: {
			heading: 'system-ui, -apple-system, sans-serif',
			body: 'system-ui, -apple-system, sans-serif',
			mono: 'ui-monospace, monospace'
		},
		borderRadius: 'lg',
		isCustom: false,
		createdAt: Date.now()
	}
];

function createThemesStore() {
	const { subscribe, set, update } = writable<Theme[]>([...DEFAULT_THEMES]);

	// Load custom themes from localStorage
	if (typeof window !== 'undefined') {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				const customThemes = JSON.parse(stored);
				set([...DEFAULT_THEMES, ...customThemes]);
			}
		} catch (error) {
			console.error('Failed to load themes:', error);
		}
	}

	function saveCustomThemes(themes: Theme[]) {
		if (typeof window !== 'undefined') {
			try {
				const customThemes = themes.filter((t) => t.isCustom);
				localStorage.setItem(STORAGE_KEY, JSON.stringify(customThemes));
			} catch (error) {
				console.error('Failed to save themes:', error);
			}
		}
	}

	return {
		subscribe,

		addTheme(theme: Theme) {
			update((themes) => {
				const updated = [...themes, theme];
				saveCustomThemes(updated);
				return updated;
			});
		},

		updateTheme(themeId: string, updates: Partial<Theme>) {
			update((themes) => {
				const updated = themes.map((t) => (t.id === themeId ? { ...t, ...updates } : t));
				saveCustomThemes(updated);
				return updated;
			});
		},

		deleteTheme(themeId: string) {
			update((themes) => {
				// Prevent deleting preset themes
				const theme = themes.find((t) => t.id === themeId);
				if (!theme || !theme.isCustom) return themes;

				const updated = themes.filter((t) => t.id !== themeId);
				saveCustomThemes(updated);
				return updated;
			});
		},

		getTheme(themeId: string): Theme | undefined {
			return get({ subscribe }).find((t) => t.id === themeId);
		}
	};
}

function createActiveThemeStore() {
	const { subscribe, set } = writable<Theme>(DEFAULT_THEMES[0]);

	// Load active theme
	if (typeof window !== 'undefined') {
		try {
			const activeThemeId = localStorage.getItem(ACTIVE_THEME_KEY);
			if (activeThemeId) {
				const theme = themes.getTheme(activeThemeId);
				if (theme) {
					set(theme);
					applyTheme(theme);
				}
			}
		} catch (error) {
			console.error('Failed to load active theme:', error);
		}
	}

	function applyTheme(theme: Theme) {
		if (typeof window === 'undefined') return;

		const root = document.documentElement;

		// Apply colors as CSS variables
		Object.entries(theme.colors).forEach(([key, value]) => {
			root.style.setProperty(`--color-${key}`, value);
		});

		// Apply fonts
		root.style.setProperty('--font-heading', theme.fonts.heading);
		root.style.setProperty('--font-body', theme.fonts.body);
		root.style.setProperty('--font-mono', theme.fonts.mono);

		// Apply border radius
		const radiusMap = {
			none: '0',
			sm: '0.125rem',
			md: '0.375rem',
			lg: '0.5rem',
			xl: '0.75rem'
		};
		root.style.setProperty('--border-radius', radiusMap[theme.borderRadius]);
	}

	return {
		subscribe,

		setTheme(themeId: string) {
			const theme = themes.getTheme(themeId);
			if (!theme) return;

			set(theme);
			applyTheme(theme);

			if (typeof window !== 'undefined') {
				localStorage.setItem(ACTIVE_THEME_KEY, themeId);
			}
		}
	};
}

export const themes = createThemesStore();
export const activeTheme = createActiveThemeStore();
