// Spaced Repetition System (SRS) using SM-2 algorithm

import { writable, get, derived } from 'svelte/store';
import type { VideoMetadata } from '../types';

export interface ReviewCard {
	id: string;
	videoId: string;
	video: VideoMetadata;
	pathId?: string; // Optional: associated learning path
	easinessFactor: number; // How easy the card is (1.3 - 2.5+)
	interval: number; // Days until next review
	repetitions: number; // Number of successful repetitions
	nextReview: number; // Timestamp of next review
	lastReview: number; // Timestamp of last review
	createdAt: number;
}

export type ReviewQuality = 0 | 1 | 2 | 3 | 4 | 5;
// 0: Complete blackout
// 1: Incorrect, but remembered something
// 2: Incorrect, but easy to recall
// 3: Correct, but difficult
// 4: Correct, with some hesitation
// 5: Perfect recall

const STORAGE_KEY = 'vektor_srs_cards';

function createSpacedRepetitionStore() {
	const { subscribe, set, update } = writable<Map<string, ReviewCard>>(new Map());

	// Load from localStorage
	if (typeof window !== 'undefined') {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				const data = JSON.parse(stored);
				const map = new Map<string, ReviewCard>();
				for (const [key, value] of Object.entries(data)) {
					map.set(key, value as ReviewCard);
				}
				set(map);
			}
		} catch (error) {
			console.error('Failed to load SRS cards:', error);
		}
	}

	function save(cards: Map<string, ReviewCard>) {
		if (typeof window !== 'undefined') {
			try {
				const obj = Object.fromEntries(cards);
				localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
			} catch (error) {
				console.error('Failed to save SRS cards:', error);
			}
		}
	}

	/**
	 * SM-2 Algorithm for calculating next review interval
	 */
	function calculateNextReview(
		card: ReviewCard,
		quality: ReviewQuality
	): Omit<ReviewCard, 'id' | 'videoId' | 'video' | 'pathId' | 'createdAt'> {
		let easinessFactor = card.easinessFactor;
		let interval = card.interval;
		let repetitions = card.repetitions;

		// Update easiness factor
		easinessFactor = Math.max(
			1.3,
			easinessFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
		);

		// Calculate interval based on quality
		if (quality < 3) {
			// Failed recall - reset
			repetitions = 0;
			interval = 1;
		} else {
			// Successful recall
			repetitions += 1;

			if (repetitions === 1) {
				interval = 1;
			} else if (repetitions === 2) {
				interval = 6;
			} else {
				interval = Math.round(interval * easinessFactor);
			}
		}

		const now = Date.now();
		const nextReview = now + interval * 24 * 60 * 60 * 1000; // Convert days to ms

		return {
			easinessFactor,
			interval,
			repetitions,
			nextReview,
			lastReview: now
		};
	}

	return {
		subscribe,

		/**
		 * Add a video to the SRS system
		 */
		addCard(video: VideoMetadata, pathId?: string): ReviewCard {
			const card: ReviewCard = {
				id: `${video.id}-${Date.now()}`,
				videoId: video.id,
				video,
				pathId,
				easinessFactor: 2.5,
				interval: 1,
				repetitions: 0,
				nextReview: Date.now() + 24 * 60 * 60 * 1000, // Tomorrow
				lastReview: Date.now(),
				createdAt: Date.now()
			};

			update((cards) => {
				cards.set(card.id, card);
				save(cards);
				return cards;
			});

			return card;
		},

		/**
		 * Review a card and update its schedule
		 */
		reviewCard(cardId: string, quality: ReviewQuality) {
			update((cards) => {
				const card = cards.get(cardId);
				if (!card) return cards;

				const updates = calculateNextReview(card, quality);
				const updatedCard = { ...card, ...updates };

				cards.set(cardId, updatedCard);
				save(cards);
				return cards;
			});
		},

		/**
		 * Get cards that are due for review
		 */
		getDueCards(): ReviewCard[] {
			const cards = get({ subscribe });
			const now = Date.now();
			return Array.from(cards.values())
				.filter((card) => card.nextReview <= now)
				.sort((a, b) => a.nextReview - b.nextReview);
		},

		/**
		 * Get all cards for a specific learning path
		 */
		getCardsByPath(pathId: string): ReviewCard[] {
			const cards = get({ subscribe });
			return Array.from(cards.values())
				.filter((card) => card.pathId === pathId)
				.sort((a, b) => a.nextReview - b.nextReview);
		},

		/**
		 * Get upcoming cards (due within next 7 days)
		 */
		getUpcomingCards(days: number = 7): ReviewCard[] {
			const cards = get({ subscribe });
			const now = Date.now();
			const future = now + days * 24 * 60 * 60 * 1000;
			return Array.from(cards.values())
				.filter((card) => card.nextReview > now && card.nextReview <= future)
				.sort((a, b) => a.nextReview - b.nextReview);
		},

		/**
		 * Remove a card from the system
		 */
		removeCard(cardId: string) {
			update((cards) => {
				cards.delete(cardId);
				save(cards);
				return cards;
			});
		},

		/**
		 * Get statistics
		 */
		getStats() {
			const cards = get({ subscribe });
			const now = Date.now();
			const allCards = Array.from(cards.values());

			return {
				totalCards: allCards.length,
				dueCards: allCards.filter((card) => card.nextReview <= now).length,
				upcomingCards: allCards.filter(
					(card) =>
						card.nextReview > now && card.nextReview <= now + 7 * 24 * 60 * 60 * 1000
				).length,
				averageEasiness:
					allCards.length > 0
						? allCards.reduce((sum, card) => sum + card.easinessFactor, 0) /
						  allCards.length
						: 0,
				averageInterval:
					allCards.length > 0
						? allCards.reduce((sum, card) => sum + card.interval, 0) / allCards.length
						: 0
			};
		},

		/**
		 * Reset a card's schedule
		 */
		resetCard(cardId: string) {
			update((cards) => {
				const card = cards.get(cardId);
				if (!card) return cards;

				const resetCard: ReviewCard = {
					...card,
					easinessFactor: 2.5,
					interval: 1,
					repetitions: 0,
					nextReview: Date.now() + 24 * 60 * 60 * 1000,
					lastReview: Date.now()
				};

				cards.set(cardId, resetCard);
				save(cards);
				return cards;
			});
		}
	};
}

export const spacedRepetition = createSpacedRepetitionStore();

// Derived store for due cards count
export const dueCardsCount = derived(spacedRepetition, ($srs) => {
	const now = Date.now();
	return Array.from($srs.values()).filter((card) => card.nextReview <= now).length;
});
