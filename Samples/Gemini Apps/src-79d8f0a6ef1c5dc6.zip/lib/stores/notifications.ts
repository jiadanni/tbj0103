// Toast notification store

import { writable } from 'svelte/store';

export interface Notification {
	id: string;
	message: string;
	type: 'error' | 'warning' | 'success' | 'info';
	duration?: number;
}

function createNotificationStore() {
	const { subscribe, update } = writable<Notification[]>([]);

	return {
		subscribe,

		show(message: string, type: Notification['type'] = 'info', duration: number = 5000) {
			const id = `${Date.now()}-${Math.random()}`;
			const notification: Notification = { id, message, type, duration };

			update((notifications) => [...notifications, notification]);

			if (duration > 0) {
				setTimeout(() => {
					this.dismiss(id);
				}, duration);
			}

			return id;
		},

		error(message: string, duration?: number) {
			return this.show(message, 'error', duration);
		},

		warning(message: string, duration?: number) {
			return this.show(message, 'warning', duration);
		},

		success(message: string, duration?: number) {
			return this.show(message, 'success', duration);
		},

		info(message: string, duration?: number) {
			return this.show(message, 'info', duration);
		},

		dismiss(id: string) {
			update((notifications) => notifications.filter((n) => n.id !== id));
		},

		clear() {
			update(() => []);
		}
	};
}

export const notifications = createNotificationStore();
