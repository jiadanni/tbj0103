// Confirmation dialog store

import { writable } from 'svelte/store';

export interface ConfirmOptions {
	title?: string;
	message: string;
	confirmText?: string;
	cancelText?: string;
	danger?: boolean;
}

interface ConfirmState extends ConfirmOptions {
	show: boolean;
	resolve?: (value: boolean) => void;
}

function createConfirmStore() {
	const { subscribe, set, update } = writable<ConfirmState>({
		show: false,
		message: ''
	});

	return {
		subscribe,

		/**
		 * Show confirmation dialog and return a promise
		 */
		confirm(options: ConfirmOptions): Promise<boolean> {
			return new Promise((resolve) => {
				set({
					show: true,
					...options,
					resolve
				});
			});
		},

		/**
		 * User confirmed the action
		 */
		handleConfirm() {
			update((state) => {
				state.resolve?.(true);
				return { ...state, show: false };
			});
		},

		/**
		 * User cancelled the action
		 */
		handleCancel() {
			update((state) => {
				state.resolve?.(false);
				return { ...state, show: false };
			});
		}
	};
}

export const confirm = createConfirmStore();

/**
 * Helper function to show confirmation dialog
 * Usage: const confirmed = await confirmAction('Delete this item?');
 */
export async function confirmAction(
	message: string,
	options?: Omit<ConfirmOptions, 'message'>
): Promise<boolean> {
	return confirm.confirm({ message, ...options });
}
