import { writable, get } from 'svelte/store';
import { browser } from '$app/environment';

export interface AuthState {
    clientId: string;
    accessToken: string | null;
    tokenExpiry: number | null;
    isAuthenticated: boolean;
    userEmail?: string;
    userName?: string;
    userAvatar?: string;
}

const STORAGE_KEY = 'vektor_auth';

function createAuthStore() {
    // Initial state from local storage or default
    const getInitialState = (): AuthState => {
        if (browser) {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored) {
                try {
                    const parsed = JSON.parse(stored);
                    // Check if token is expired (buffer of 5 minutes)
                    if (parsed.tokenExpiry && parsed.tokenExpiry > Date.now() + 300000) {
                        return { ...parsed, isAuthenticated: true };
                    }
                    // Token expired, clear it but keep clientId
                    return { ...parsed, accessToken: null, tokenExpiry: null, isAuthenticated: false };
                } catch (e) {
                    console.error('Failed to parse auth storage', e);
                }
            }
        }
        return {
            clientId: '',
            accessToken: null,
            tokenExpiry: null,
            isAuthenticated: false
        };
    };

    const { subscribe, set, update } = writable<AuthState>(getInitialState());

    return {
        subscribe,

        setClientId: (clientId: string) => {
            update(state => {
                const newState = { ...state, clientId };
                if (browser) localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
                return newState;
            });
        },

        setSession: (accessToken: string, expiresInSeconds: number) => {
            const expiry = Date.now() + (expiresInSeconds * 1000);
            update(state => {
                const newState = {
                    ...state,
                    accessToken,
                    tokenExpiry: expiry,
                    isAuthenticated: true
                };
                if (browser) localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
                return newState;
            });
        },

        setUserInfo: (name: string, email: string, avatar: string) => {
            update(state => {
                const newState = { ...state, userName: name, userEmail: email, userAvatar: avatar };
                if (browser) localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
                return newState;
            });
        },

        logout: () => {
            update(state => {
                // Keep Client ID for convenience
                const newState = {
                    ...state,
                    accessToken: null,
                    tokenExpiry: null,
                    isAuthenticated: false,
                    userEmail: undefined,
                    userName: undefined,
                    userAvatar: undefined
                };
                if (browser) localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
                return newState;
            });
        },

        // Helper to construct the Google OAuth URL
        getAuthUrl: (redirectUri: string) => {
            const state = get({ subscribe });
            if (!state.clientId) throw new Error('Client ID is missing');

            const scope = [
                'https://www.googleapis.com/auth/youtube.readonly'
            ].join(' ');

            const params = new URLSearchParams({
                client_id: state.clientId,
                redirect_uri: redirectUri,
                response_type: 'token',
                scope: scope,
                include_granted_scopes: 'true',
                state: 'pass-through-value'
            });

            return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
        }
    };
}

export const auth = createAuthStore();
