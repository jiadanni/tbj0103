// Recently viewed videos store

import { writable, get } from 'svelte/store';
import type { VideoMetadata } from '../types';

const MAX_HISTORY = 20;
const STORAGE_KEY = 'vektor_recently_viewed';

function createHistoryStore() {
	const { subscribe, set, update } = writable<VideoMetadata[]>([]);

	// Load from localStorage
	if (typeof window !== 'undefined') {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				set(JSON.parse(stored));
			}
		} catch (error) {
			console.error('Failed to load history:', error);
		}
	}

	function save(videos: VideoMetadata[]) {
		if (typeof window !== 'undefined') {
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify(videos));
			} catch (error) {
				console.error('Failed to save history:', error);
			}
		}
	}

	return {
		subscribe,

		/**
		 * Add a video to recently viewed
		 */
		addVideo(video: VideoMetadata) {
			update((history) => {
				// Remove if already exists
				const filtered = history.filter((v) => v.id !== video.id);

				// Add to beginning
				const updated = [video, ...filtered].slice(0, MAX_HISTORY);

				save(updated);
				return updated;
			});
		},

		/**
		 * Remove a video from history
		 */
		removeVideo(videoId: string) {
			update((history) => {
				const updated = history.filter((v) => v.id !== videoId);
				save(updated);
				return updated;
			});
		},

		/**
		 * Clear all history
		 */
		clear() {
			set([]);
			if (typeof window !== 'undefined') {
				localStorage.removeItem(STORAGE_KEY);
			}
		},

		/**
		 * Get recent videos (limited)
		 */
		getRecent(limit: number = 10): VideoMetadata[] {
			return get({ subscribe }).slice(0, limit);
		}
	};
}

export const recentlyViewed = createHistoryStore();
