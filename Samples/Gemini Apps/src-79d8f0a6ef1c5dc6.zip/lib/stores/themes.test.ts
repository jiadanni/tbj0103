import { describe, it, expect, beforeEach, vi } from 'vitest';
import { get } from 'svelte/store';
import { themes, activeTheme, DEFAULT_THEMES } from './themes';

describe('Themes Store', () => {
	beforeEach(() => {
		localStorage.clear();
		vi.clearAllMocks();
	});

	describe('DEFAULT_THEMES', () => {
		it('should have 5 preset themes', () => {
			expect(DEFAULT_THEMES).toHaveLength(5);
		});

		it('should include Default, Dark, Nord, Solarized, and Forest themes', () => {
			const themeNames = DEFAULT_THEMES.map((t) => t.name);
			expect(themeNames).toContain('Default');
			expect(themeNames).toContain('Dark');
			expect(themeNames).toContain('Nord');
			expect(themeNames).toContain('Solarized');
			expect(themeNames).toContain('Forest');
		});

		it('should have all themes marked as not custom', () => {
			DEFAULT_THEMES.forEach((theme) => {
				expect(theme.isCustom).toBe(false);
			});
		});

		it('should have all required color properties', () => {
			const requiredColors = [
				'primary',
				'secondary',
				'accent',
				'background',
				'surface',
				'text',
				'textSecondary',
				'border',
				'success',
				'warning',
				'error',
				'info'
			];

			DEFAULT_THEMES.forEach((theme) => {
				requiredColors.forEach((color) => {
					expect(theme.colors).toHaveProperty(color);
					expect(typeof theme.colors[color as keyof typeof theme.colors]).toBe('string');
				});
			});
		});
	});

	describe('themes store', () => {
		it('should initialize with DEFAULT_THEMES', () => {
			const allThemes = get(themes);
			expect(allThemes).toHaveLength(DEFAULT_THEMES.length);
		});

		it('should add a custom theme', () => {
			const customTheme = {
				id: 'custom-1',
				name: 'My Custom Theme',
				description: 'A custom theme',
				colors: DEFAULT_THEMES[0].colors,
				fonts: DEFAULT_THEMES[0].fonts,
				borderRadius: 'md' as const,
				isCustom: true,
				createdAt: Date.now()
			};

			themes.addTheme(customTheme);
			const allThemes = get(themes);

			expect(allThemes.length).toBeGreaterThan(DEFAULT_THEMES.length);
			expect(allThemes.find((t) => t.id === 'custom-1')).toBeDefined();
		});

		it('should update a custom theme', () => {
			const customTheme = {
				id: 'custom-1',
				name: 'Original Name',
				description: 'Original description',
				colors: DEFAULT_THEMES[0].colors,
				fonts: DEFAULT_THEMES[0].fonts,
				borderRadius: 'md' as const,
				isCustom: true,
				createdAt: Date.now()
			};

			themes.addTheme(customTheme);

			const updated = { ...customTheme, name: 'Updated Name' };
			themes.updateTheme('custom-1', updated);

			const allThemes = get(themes);
			const theme = allThemes.find((t) => t.id === 'custom-1');

			expect(theme?.name).toBe('Updated Name');
		});

		it('should delete a custom theme', () => {
			const customTheme = {
				id: 'custom-1',
				name: 'To Delete',
				description: 'Will be deleted',
				colors: DEFAULT_THEMES[0].colors,
				fonts: DEFAULT_THEMES[0].fonts,
				borderRadius: 'md' as const,
				isCustom: true,
				createdAt: Date.now()
			};

			themes.addTheme(customTheme);
			const beforeDelete = get(themes);
			expect(beforeDelete.find((t) => t.id === 'custom-1')).toBeDefined();

			themes.deleteTheme('custom-1');
			const afterDelete = get(themes);
			expect(afterDelete.find((t) => t.id === 'custom-1')).toBeUndefined();
		});

		it('should not delete a preset theme', () => {
			const originalLength = get(themes).length;
			themes.deleteTheme('default');

			expect(get(themes).length).toBe(originalLength);
		});
	});

	describe('activeTheme store', () => {
		it('should initialize with Default theme', () => {
			const active = get(activeTheme);
			expect(active.id).toBe('default');
			expect(active.name).toBe('Default');
		});

		it('should set active theme', () => {
			const darkTheme = DEFAULT_THEMES.find((t) => t.id === 'dark');
			if (darkTheme) {
				activeTheme.setTheme(darkTheme.id);
				const active = get(activeTheme);
				expect(active.id).toBe('dark');
			}
		});

		it('should not change if theme not found', () => {
			const before = get(activeTheme);
			activeTheme.setTheme('non-existent-theme');
			const after = get(activeTheme);
			expect(after.id).toBe(before.id);
		});
	});

	describe('Border Radius', () => {
		it('should support all border radius options', () => {
			const options = ['none', 'sm', 'md', 'lg', 'xl'];

			DEFAULT_THEMES.forEach((theme) => {
				expect(options).toContain(theme.borderRadius);
			});
		});
	});

	describe('Fonts', () => {
		it('should have heading, body, and mono fonts', () => {
			DEFAULT_THEMES.forEach((theme) => {
				expect(theme.fonts).toHaveProperty('heading');
				expect(theme.fonts).toHaveProperty('body');
				expect(theme.fonts).toHaveProperty('mono');
			});
		});
	});
});
