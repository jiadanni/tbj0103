// API Request History Store

import { writable, derived } from 'svelte/store';
import type { ApiRequestRecord, ApiRequestStats, ApiRequestType } from '../types';
import { storage } from '../services/storage';

// Create the store
function createApiHistoryStore() {
    const { subscribe, set, update } = writable<ApiRequestRecord[]>([]);

    return {
        subscribe,
        set,
        update,

        // Initialize from storage
        async init() {
            const history = await storage.getApiHistory();
            set(history || []);
        },

        // Add a new request record
        async addRequest(record: Omit<ApiRequestRecord, 'id'>) {
            const newRecord: ApiRequestRecord = {
                ...record,
                id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            };

            update((records) => {
                const updated = [newRecord, ...records];
                // Keep only last 1000 records to prevent storage bloat
                const trimmed = updated.slice(0, 1000);
                storage.setApiHistory(trimmed);
                return trimmed;
            });
        },

        // Clear all history
        async clear() {
            set([]);
            await storage.setApiHistory([]);
        },

        // Clear old records (older than specified days)
        async clearOld(days: number = 30) {
            const cutoffTime = Date.now() - days * 24 * 60 * 60 * 1000;
            update((records) => {
                const filtered = records.filter((r) => r.timestamp >= cutoffTime);
                storage.setApiHistory(filtered);
                return filtered;
            });
        },

        // Get records for a specific date range
        getRecordsInRange(startTime: number, endTime: number, records: ApiRequestRecord[]) {
            return records.filter((r) => r.timestamp >= startTime && r.timestamp <= endTime);
        },

        // Get records for today
        getTodayRecords(records: ApiRequestRecord[]) {
            const now = new Date();
            const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
            const endOfDay = startOfDay + 24 * 60 * 60 * 1000;
            return this.getRecordsInRange(startOfDay, endOfDay, records);
        }
    };
}

export const apiHistory = createApiHistoryStore();

// Derived stores for analytics
export const apiStats = derived(apiHistory, ($history): ApiRequestStats => {
    if ($history.length === 0) {
        return {
            totalRequests: 0,
            totalQuotaUsed: 0,
            requestsByType: {
                search: 0,
                videoDetails: 0,
                channelVideos: 0,
                validation: 0
            },
            quotaByType: {
                search: 0,
                videoDetails: 0,
                channelVideos: 0,
                validation: 0
            },
            averageResponseTime: 0,
            successRate: 0,
            requestsToday: 0,
            quotaUsedToday: 0
        };
    }

    // Get today's records
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const todayRecords = $history.filter((r) => r.timestamp >= startOfDay);

    // Calculate stats
    const requestsByType: Record<ApiRequestType, number> = {
        search: 0,
        videoDetails: 0,
        channelVideos: 0,
        validation: 0
    };

    const quotaByType: Record<ApiRequestType, number> = {
        search: 0,
        videoDetails: 0,
        channelVideos: 0,
        validation: 0
    };

    let totalQuotaUsed = 0;
    let totalResponseTime = 0;
    let responseTimes = 0;
    let successCount = 0;

    $history.forEach((record) => {
        requestsByType[record.type]++;
        quotaByType[record.type] += record.quotaCost;
        totalQuotaUsed += record.quotaCost;

        if (record.responseTime) {
            totalResponseTime += record.responseTime;
            responseTimes++;
        }

        if (record.success) {
            successCount++;
        }
    });

    const requestsToday = todayRecords.length;
    const quotaUsedToday = todayRecords.reduce((sum, r) => sum + r.quotaCost, 0);

    return {
        totalRequests: $history.length,
        totalQuotaUsed,
        requestsByType,
        quotaByType,
        averageResponseTime: responseTimes > 0 ? totalResponseTime / responseTimes : 0,
        successRate: ($history.length > 0 ? (successCount / $history.length) * 100 : 0),
        requestsToday,
        quotaUsedToday
    };
});

// Derived store for quota percentage today
export const quotaPercentageToday = derived(apiStats, ($stats) => {
    return ($stats.quotaUsedToday / 10000) * 100;
});
