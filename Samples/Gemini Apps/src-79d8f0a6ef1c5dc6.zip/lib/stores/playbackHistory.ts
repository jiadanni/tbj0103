// Playback history with progress tracking

import { writable, get } from 'svelte/store';
import type { VideoMetadata } from '../types';

export interface PlaybackRecord {
	video: VideoMetadata;
	progress: number; // 0-1 (percentage completed)
	duration: number; // Total video duration in seconds
	watchedDuration: number; // How much was watched in seconds
	completed: boolean; // Watched >= 90%
	watchCount: number; // Number of times watched
	lastWatched: number; // Timestamp
	firstWatched: number; // Timestamp
}

const STORAGE_KEY = 'vektor_playback_history';

function createPlaybackHistoryStore() {
	const { subscribe, set, update } = writable<Map<string, PlaybackRecord>>(new Map());

	// Load from localStorage
	if (typeof window !== 'undefined') {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				const data = JSON.parse(stored);
				const map = new Map<string, PlaybackRecord>();
				for (const [key, value] of Object.entries(data)) {
					map.set(key, value as PlaybackRecord);
				}
				set(map);
			}
		} catch (error) {
			console.error('Failed to load playback history:', error);
		}
	}

	function save(history: Map<string, PlaybackRecord>) {
		if (typeof window !== 'undefined') {
			try {
				const obj = Object.fromEntries(history);
				localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
			} catch (error) {
				console.error('Failed to save playback history:', error);
			}
		}
	}

	return {
		subscribe,

		/**
		 * Update playback progress for a video
		 */
		updateProgress(video: VideoMetadata, currentTime: number, duration: number) {
			update((history) => {
				const existing = history.get(video.id);
				const progress = duration > 0 ? currentTime / duration : 0;
				const completed = progress >= 0.9;
				const now = Date.now();

				const record: PlaybackRecord = {
					video,
					progress,
					duration,
					watchedDuration: currentTime,
					completed,
					watchCount: existing ? existing.watchCount : 0,
					lastWatched: now,
					firstWatched: existing?.firstWatched || now
				};

				history.set(video.id, record);
				save(history);
				return history;
			});
		},

		/**
		 * Increment watch count when video starts playing
		 */
		incrementWatchCount(videoId: string) {
			update((history) => {
				const existing = history.get(videoId);
				if (existing) {
					existing.watchCount += 1;
					existing.lastWatched = Date.now();
					history.set(videoId, existing);
					save(history);
				}
				return history;
			});
		},

		/**
		 * Get playback record for a video
		 */
		getRecord(videoId: string): PlaybackRecord | null {
			const history = get({ subscribe });
			return history.get(videoId) || null;
		},

		/**
		 * Get all completed videos
		 */
		getCompleted(): PlaybackRecord[] {
			const history = get({ subscribe });
			return Array.from(history.values())
				.filter((record) => record.completed)
				.sort((a, b) => b.lastWatched - a.lastWatched);
		},

		/**
		 * Get in-progress videos (started but not completed)
		 */
		getInProgress(): PlaybackRecord[] {
			const history = get({ subscribe });
			return Array.from(history.values())
				.filter((record) => !record.completed && record.progress > 0.05)
				.sort((a, b) => b.lastWatched - a.lastWatched);
		},

		/**
		 * Get watch history sorted by last watched
		 */
		getAll(): PlaybackRecord[] {
			const history = get({ subscribe });
			return Array.from(history.values()).sort((a, b) => b.lastWatched - a.lastWatched);
		},

		/**
		 * Get total watch time in seconds
		 */
		getTotalWatchTime(): number {
			const history = get({ subscribe });
			return Array.from(history.values()).reduce(
				(total, record) => total + record.watchedDuration,
				0
			);
		},

		/**
		 * Get stats
		 */
		getStats() {
			const history = get({ subscribe });
			const records = Array.from(history.values());

			return {
				totalVideos: records.length,
				completedVideos: records.filter((r) => r.completed).length,
				inProgressVideos: records.filter((r) => !r.completed && r.progress > 0.05).length,
				totalWatchTime: records.reduce((total, r) => total + r.watchedDuration, 0),
				totalWatches: records.reduce((total, r) => total + r.watchCount, 0)
			};
		},

		/**
		 * Clear all history
		 */
		clear() {
			set(new Map());
			if (typeof window !== 'undefined') {
				localStorage.removeItem(STORAGE_KEY);
			}
		},

		/**
		 * Remove a specific video from history
		 */
		remove(videoId: string) {
			update((history) => {
				history.delete(videoId);
				save(history);
				return history;
			});
		}
	};
}

export const playbackHistory = createPlaybackHistoryStore();
