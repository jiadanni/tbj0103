// Video player state store

import { writable, get } from 'svelte/store';
import type { VideoMetadata, CastDevice } from '../types';
import { recentlyViewed } from './history';

export interface PlayerState {
	currentVideo: VideoMetadata | null;
	isPlaying: boolean;
	isCasting: boolean;
	castDevice: CastDevice | null;
	volume: number;
	playbackRate: number;
}

function createPlayerStore() {
	const initialState: PlayerState = {
		currentVideo: null,
		isPlaying: false,
		isCasting: false,
		castDevice: null,
		volume: 1.0,
		playbackRate: 1.0
	};

	const { subscribe, set, update } = writable<PlayerState>(initialState);

	return {
		subscribe,
		set,
		update,

		// Play a video
		play(video: VideoMetadata) {
			// Add to recently viewed
			recentlyViewed.addVideo(video);

			update((state) => ({
				...state,
				currentVideo: video,
				isPlaying: true
			}));
		},

		// Pause playback
		pause() {
			update((state) => ({
				...state,
				isPlaying: false
			}));
		},

		// Resume playback
		resume() {
			update((state) => ({
				...state,
				isPlaying: true
			}));
		},

		// Stop playback
		stop() {
			update((state) => ({
				...state,
				currentVideo: null,
				isPlaying: false
			}));
		},

		// Start casting
		startCast(device: CastDevice) {
			update((state) => ({
				...state,
				isCasting: true,
				castDevice: device
			}));
		},

		// Stop casting
		stopCast() {
			update((state) => ({
				...state,
				isCasting: false,
				castDevice: null
			}));
		},

		// Set volume (0.0 - 1.0)
		setVolume(volume: number) {
			update((state) => ({
				...state,
				volume: Math.max(0, Math.min(1, volume))
			}));
		},

		// Set playback rate
		setPlaybackRate(rate: number) {
			update((state) => ({
				...state,
				playbackRate: rate
			}));
		},

		// Reset to initial state
		reset() {
			set(initialState);
		}
	};
}

export const player = createPlayerStore();
