// Watch Later queue store

import { writable, get } from 'svelte/store';
import type { VideoMetadata } from '../types';

const STORAGE_KEY = 'vektor_watch_later';

function createWatchLaterStore() {
	const { subscribe, set, update } = writable<VideoMetadata[]>([]);

	// Load from localStorage
	if (typeof window !== 'undefined') {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				set(JSON.parse(stored));
			}
		} catch (error) {
			console.error('Failed to load watch later queue:', error);
		}
	}

	function save(videos: VideoMetadata[]) {
		if (typeof window !== 'undefined') {
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify(videos));
			} catch (error) {
				console.error('Failed to save watch later queue:', error);
			}
		}
	}

	return {
		subscribe,

		/**
		 * Add a video to watch later
		 */
		add(video: VideoMetadata) {
			update((queue) => {
				// Don't add if already in queue
				if (queue.some((v) => v.id === video.id)) {
					return queue;
				}

				const updated = [...queue, video];
				save(updated);
				return updated;
			});
		},

		/**
		 * Remove a video from watch later
		 */
		remove(videoId: string) {
			update((queue) => {
				const updated = queue.filter((v) => v.id !== videoId);
				save(updated);
				return updated;
			});
		},

		/**
		 * Check if a video is in watch later
		 */
		has(videoId: string): boolean {
			return get({ subscribe }).some((v) => v.id === videoId);
		},

		/**
		 * Clear all videos from watch later
		 */
		clear() {
			set([]);
			if (typeof window !== 'undefined') {
				localStorage.removeItem(STORAGE_KEY);
			}
		},

		/**
		 * Get count of videos in queue
		 */
		count(): number {
			return get({ subscribe }).length;
		}
	};
}

export const watchLater = createWatchLaterStore();
