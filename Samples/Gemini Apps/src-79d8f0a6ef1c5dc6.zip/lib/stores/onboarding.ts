// Onboarding state store

import { writable } from 'svelte/store';

const STORAGE_KEY = 'vektor_onboarding_complete';

function createOnboardingStore() {
	const { subscribe, set } = writable(false);

	// Load from localStorage
	if (typeof window !== 'undefined') {
		try {
			const completed = localStorage.getItem(STORAGE_KEY) === 'true';
			set(completed);
		} catch (error) {
			console.error('Failed to load onboarding state:', error);
		}
	}

	return {
		subscribe,

		/**
		 * Mark onboarding as complete
		 */
		complete() {
			if (typeof window !== 'undefined') {
				try {
					localStorage.setItem(STORAGE_KEY, 'true');
				} catch (error) {
					console.error('Failed to save onboarding state:', error);
				}
			}
			set(true);
		},

		/**
		 * Reset onboarding (for testing)
		 */
		reset() {
			if (typeof window !== 'undefined') {
				localStorage.removeItem(STORAGE_KEY);
			}
			set(false);
		}
	};
}

export const onboardingComplete = createOnboardingStore();
