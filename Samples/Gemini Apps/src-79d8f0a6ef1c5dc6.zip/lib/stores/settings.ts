// Settings and API configuration store

import { writable, derived, get } from 'svelte/store';
import type { ApiConfig } from '../types';
import { storage } from '../services/storage';
import { DEFAULT_QUOTA_LIMIT } from '../utils/constants';

// Create the store
function createSettingsStore() {
	const { subscribe, set, update } = writable<ApiConfig | null>(null);

	return {
		subscribe,
		set,
		update,

		// Initialize from storage
		async init() {
			const config = await storage.getApiConfig();
			if (config) {
				// Migration: Single key to array
				if ((config.youtube as any).apiKey && !config.youtube.apiKeys) {
					config.youtube.apiKeys = [(config.youtube as any).apiKey];
					config.youtube.activeKeyIndex = 0;
					delete (config.youtube as any).apiKey;
				}

				// Ensure defaults
				if (!config.youtube.apiKeys) config.youtube.apiKeys = [];
				if (typeof config.youtube.activeKeyIndex !== 'number') config.youtube.activeKeyIndex = 0;

				set(config);
			} else {
				// Set default config
				const defaultConfig: ApiConfig = {
					youtube: {
						apiKeys: [],
						activeKeyIndex: 0,
						quotaUsed: 0,
						quotaLimit: DEFAULT_QUOTA_LIMIT
					},
					vimeo: {
						accessToken: ''
					},
					ai: {
						enabled: false,
						provider: 'lm_studio',
						endpoint: 'http://localhost:1234',
						model: 'local-model'
					}
				};
				set(defaultConfig);
			}
		},

		// Save to storage
		async save(config: ApiConfig) {
			await storage.setApiConfig(config);
			set(config);
		},

		// Add YouTube API key
		async addYouTubeKey(apiKey: string) {
			const config = get({ subscribe });
			if (config) {
				if (!config.youtube.apiKeys.includes(apiKey)) {
					config.youtube.apiKeys = [...config.youtube.apiKeys, apiKey];
					// If this is the first key, set it as active
					if (config.youtube.apiKeys.length === 1) {
						config.youtube.activeKeyIndex = 0;
					}
					await this.save(config);
				}
			}
		},

		// Remove YouTube API key
		async removeYouTubeKey(index: number) {
			const config = get({ subscribe });
			if (config) {
				const newKeys = [...config.youtube.apiKeys];
				newKeys.splice(index, 1);
				config.youtube.apiKeys = newKeys;

				// Adjust active index if needed
				if (config.youtube.activeKeyIndex >= newKeys.length) {
					config.youtube.activeKeyIndex = Math.max(0, newKeys.length - 1);
				}

				await this.save(config);
			}
		},

		// Rotate to next API key (on quota error)
		async rotateKey() {
			const config = get({ subscribe });
			if (config && config.youtube.apiKeys.length > 1) {
				const nextIndex = (config.youtube.activeKeyIndex + 1) % config.youtube.apiKeys.length;
				console.warn(`Rotating API key from index ${config.youtube.activeKeyIndex} to ${nextIndex}`);
				config.youtube.activeKeyIndex = nextIndex;
				await this.save(config);
				return config.youtube.apiKeys[nextIndex];
			}
			return null;
		},

		// Update Vimeo access token
		async updateVimeoToken(accessToken: string) {
			const config = get({ subscribe });
			if (config) {
				config.vimeo.accessToken = accessToken;
				await this.save(config);
			}
		},

		// Update AI config
		async updateAIConfig(aiConfig: Partial<import('../types').AIConfig>) {
			const config = get({ subscribe });
			if (config) {
				config.ai = { ...config.ai, ...aiConfig };
				await this.save(config);
			}
		},

		// Update quota usage
		async updateQuota(used: number) {
			const config = get({ subscribe });
			if (config) {
				config.youtube.quotaUsed = used;
				await this.save(config);
			}
		},

		// Reset quota (call daily)
		async resetQuota() {
			const config = get({ subscribe });
			if (config) {
				config.youtube.quotaUsed = 0;
				await this.save(config);
			}
		}
	};
}

export const settings = createSettingsStore();

// Derived stores
export const hasYouTubeKey = derived(settings, ($settings) => {
	return !!($settings?.youtube.apiKeys?.length && $settings.youtube.apiKeys[$settings.youtube.activeKeyIndex]);
});

export const hasVimeoToken = derived(settings, ($settings) => {
	return !!$settings?.vimeo.accessToken;
});

export const aiEnabled = derived(settings, ($settings) => {
	return $settings?.ai.enabled || false;
});

export const quotaPercentage = derived(settings, ($settings) => {
	if (!$settings) return 0;
	return ($settings.youtube.quotaUsed / $settings.youtube.quotaLimit) * 100;
});
