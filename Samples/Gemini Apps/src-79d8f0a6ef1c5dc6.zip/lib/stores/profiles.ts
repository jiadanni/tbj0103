// User profiles store

import { writable, derived, get } from 'svelte/store';
import type { UserProfile } from '../types';
import { storage } from '../services/storage';
import { generateId } from '../utils/helpers';
import { DEFAULT_PROFILE } from '../utils/constants';

// All profiles
function createProfilesStore() {
	const { subscribe, set, update } = writable<UserProfile[]>([]);

	return {
		subscribe,
		set,
		update,

		// Initialize from storage
		async init() {
			const profiles = await storage.getProfiles();
			set(profiles);
		},

		// Add a new profile
		async add(profile: Omit<UserProfile, 'id'>) {
			const newProfile: UserProfile = {
				...profile,
				id: generateId()
			};

			await storage.saveProfile(newProfile);
			update((profiles) => [...profiles, newProfile]);
			return newProfile;
		},

		// Update a profile
		async updateProfile(id: string, updates: Partial<UserProfile>) {
			const profiles = get({ subscribe });
			const index = profiles.findIndex((p) => p.id === id);

			if (index >= 0) {
				const updated = { ...profiles[index], ...updates };
				await storage.saveProfile(updated);
				set([...profiles.slice(0, index), updated, ...profiles.slice(index + 1)]);
			}
		},

		// Delete a profile
		async delete(id: string) {
			await storage.deleteProfile(id);
			update((profiles) => profiles.filter((p) => p.id !== id));
		},

		// Create default profile
		async createDefault() {
			const profile = await this.add(DEFAULT_PROFILE);
			return profile;
		}
	};
}

export const profiles = createProfilesStore();

// Active profile
function createActiveProfileStore() {
	const { subscribe, set } = writable<UserProfile | null>(null);

	return {
		subscribe,
		set,

		// Initialize from storage
		async init() {
			const profile = await storage.getActiveProfile();
			set(profile);
		},

		// Set active profile
		async setActive(id: string) {
			const profile = await storage.getProfile(id);
			if (profile) {
				await storage.setActiveProfile(id);
				set(profile);
			}
		},

		// Update active profile
		async update(updates: Partial<UserProfile>) {
			const current = get({ subscribe });
			if (current) {
				const updated = { ...current, ...updates };
				await storage.saveProfile(updated);
				set(updated);
			}
		}
	};
}

export const activeProfile = createActiveProfileStore();

// Derived stores
export const profileCount = derived(profiles, ($profiles) => $profiles.length);

export const profileNames = derived(profiles, ($profiles) =>
	$profiles.map((p) => ({ id: p.id, name: p.name }))
);
