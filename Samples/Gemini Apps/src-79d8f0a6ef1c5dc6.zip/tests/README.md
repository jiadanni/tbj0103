# Testing Guide

This directory contains the test setup and configuration for Vektor.

## Test Framework

We use [Vitest](https://vitest.dev/) as our test framework, which provides:
- Fast test execution with Vite-powered transforms
- Jest-compatible API
- Built-in TypeScript support
- Coverage reporting with v8

## Running Tests

```bash
# Run tests in watch mode
npm test

# Run tests once
npm run test:run

# Run tests with UI
npm run test:ui

# Generate coverage report
npm run test:coverage
```

## Test Structure

Tests are co-located with their source files using the `.test.ts` naming convention:

- `src/lib/stores/*.test.ts` - Store tests
- `src/lib/utils/*.test.ts` - Utility function tests
- `src/lib/components/*.test.ts` - Component tests

## Writing Tests

### Store Tests

Example testing a Svelte store:

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { get } from 'svelte/store';
import { myStore } from './myStore';

describe('My Store', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('should initialize with default value', () => {
    const value = get(myStore);
    expect(value).toBeDefined();
  });
});
```

### Utility Tests

Example testing utility functions:

```typescript
import { describe, it, expect } from 'vitest';
import { formatDuration } from './helpers';

describe('formatDuration', () => {
  it('should format seconds correctly', () => {
    expect(formatDuration(125)).toBe('2:05');
  });
});
```

## Test Coverage

Current test coverage includes:

- **Themes Store**: Theme management, active theme selection, CRUD operations
- **Spaced Repetition Store**: SM-2 algorithm, card management, scheduling
- **Utility Functions**: Duration formatting, number formatting, data compression, etc.

## Mocking

The test setup includes mocks for:

- `localStorage` - For testing client-side storage
- `window.matchMedia` - For responsive design tests
- `IntersectionObserver` - For visibility detection tests

These mocks are configured in `src/tests/setup.ts`.

## Configuration

Test configuration is in `vitest.config.ts`:

- Environment: jsdom (for DOM testing)
- Setup files: `src/tests/setup.ts`
- Coverage provider: v8
- Coverage output: text, json, html

## Best Practices

1. **Isolation**: Each test should be independent and not rely on other tests
2. **Clear naming**: Use descriptive test names that explain what is being tested
3. **Arrange-Act-Assert**: Structure tests with clear setup, execution, and validation phases
4. **Mock external dependencies**: Use mocks for localStorage, APIs, etc.
5. **Test edge cases**: Don't just test the happy path
6. **Keep tests simple**: Each test should verify one thing

## Future Improvements

- Component testing with @testing-library/svelte
- E2E testing with Playwright
- Visual regression testing
- Performance benchmarking
