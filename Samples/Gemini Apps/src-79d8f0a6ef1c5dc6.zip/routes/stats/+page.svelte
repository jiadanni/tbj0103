<script lang="ts">
	import { paths } from '$lib/stores/paths';
	import { playbackHistory } from '$lib/stores/playbackHistory';
	import { formatDuration } from '$lib/utils/helpers';

	// Stats aggregation
	$: pathsData = $paths;
	$: playbackStats = playbackHistory.getStats();
	$: allRecords = playbackHistory.getAll();

	// Path stats
	$: totalPaths = pathsData.length;
	$: activePaths = pathsData.filter(
		(p) => p.progress.current || p.progress.completed.length > 0
	).length;
	$: completedPaths = pathsData.filter(
		(p) => p.progress.completed.length === p.videos.length && p.videos.length > 0
	).length;
	$: totalPathVideos = pathsData.reduce((sum, p) => sum + p.videos.length, 0);
	$: completedPathVideos = pathsData.reduce(
		(sum, p) => sum + p.progress.completed.length,
		0
	);
	$: pathCompletionRate =
		totalPathVideos > 0 ? (completedPathVideos / totalPathVideos) * 100 : 0;

	// Watch time stats
	$: totalWatchTimeHours = playbackStats.totalWatchTime / 3600;
	$: avgVideoLength =
		allRecords.length > 0
			? allRecords.reduce((sum, r) => sum + r.duration, 0) / allRecords.length
			: 0;

	// Top watched videos
	$: topWatchedVideos = allRecords
		.sort((a, b) => b.watchCount - a.watchCount)
		.slice(0, 5);

	// Recent completions
	$: recentCompletions = playbackHistory
		.getCompleted()
		.slice(0, 5);

	// Learning velocity (videos per week)
	$: learningVelocity = (() => {
		const now = Date.now();
		const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;
		return allRecords.filter((r) => r.lastWatched >= oneWeekAgo).length;
	})();

	// Completion rate
	$: completionRate =
		playbackStats.totalVideos > 0
			? (playbackStats.completedVideos / playbackStats.totalVideos) * 100
			: 0;

	// Activity by day of week
	$: activityByDay = (() => {
		const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
		const counts = [0, 0, 0, 0, 0, 0, 0];

		allRecords.forEach((record) => {
			const day = new Date(record.lastWatched).getDay();
			counts[day]++;
		});

		const maxCount = Math.max(...counts, 1);

		return days.map((day, i) => ({
			day,
			count: counts[i],
			percentage: (counts[i] / maxCount) * 100
		}));
	})();

	function formatDate(timestamp: number): string {
		return new Date(timestamp).toLocaleDateString();
	}
</script>

<svelte:head>
	<title>Learning Stats - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<!-- Header -->
	<div>
		<h1 class="text-3xl font-bold mb-2">Learning Statistics</h1>
		<p class="text-gray-600 dark:text-gray-400">
			Track your progress and insights across all your learning activities
		</p>
	</div>

	<!-- Overview Stats -->
	<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
		<div class="card text-center">
			<div class="text-4xl font-bold text-primary-600 dark:text-primary-400 mb-2">
				{totalPaths}
			</div>
			<div class="text-sm text-gray-600 dark:text-gray-400">Learning Paths</div>
			<div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
				{activePaths} active
			</div>
		</div>

		<div class="card text-center">
			<div class="text-4xl font-bold text-green-600 dark:text-green-400 mb-2">
				{playbackStats.completedVideos}
			</div>
			<div class="text-sm text-gray-600 dark:text-gray-400">Videos Completed</div>
			<div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
				{Math.round(completionRate)}% completion rate
			</div>
		</div>

		<div class="card text-center">
			<div class="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2">
				{Math.round(totalWatchTimeHours)}h
			</div>
			<div class="text-sm text-gray-600 dark:text-gray-400">Total Watch Time</div>
			<div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
				~{Math.round(avgVideoLength / 60)}m avg
			</div>
		</div>

		<div class="card text-center">
			<div class="text-4xl font-bold text-purple-600 dark:text-purple-400 mb-2">
				{learningVelocity}
			</div>
			<div class="text-sm text-gray-600 dark:text-gray-400">Videos This Week</div>
			<div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
				Learning velocity
			</div>
		</div>
	</div>

	<!-- Path Progress -->
	{#if pathsData.length > 0}
		<div class="card">
			<h2 class="text-xl font-bold mb-4">Learning Path Progress</h2>

			<div class="space-y-4">
				{#each pathsData as path}
					{@const progress = (path.progress.completed.length / Math.max(path.videos.length, 1)) * 100}
					<div>
						<div class="flex items-center justify-between mb-2">
							<a
								href="/paths/{path.id}"
								class="font-semibold hover:text-primary-600 dark:hover:text-primary-400"
							>
								{path.title}
							</a>
							<span class="text-sm text-gray-600 dark:text-gray-400">
								{path.progress.completed.length} / {path.videos.length} videos
								({Math.round(progress)}%)
							</span>
						</div>
						<div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
							<div
								class="h-2 rounded-full transition-all {progress === 100
									? 'bg-green-600'
									: 'bg-primary-600'}"
								style="width: {progress}%"
							></div>
						</div>
					</div>
				{/each}
			</div>
		</div>
	{/if}

	<!-- Activity Heatmap -->
	{#if allRecords.length > 0}
		<div class="card">
			<h2 class="text-xl font-bold mb-4">Activity by Day of Week</h2>

			<div class="space-y-2">
				{#each activityByDay as { day, count, percentage }}
					<div class="flex items-center gap-4">
						<div class="w-12 text-sm font-medium text-gray-700 dark:text-gray-300">
							{day}
						</div>
						<div class="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-8 relative overflow-hidden">
							<div
								class="h-full bg-primary-600 dark:bg-primary-500 transition-all"
								style="width: {percentage}%"
							></div>
							<div
								class="absolute inset-0 flex items-center justify-start px-3 text-sm font-medium {percentage > 50 ? 'text-white' : 'text-gray-700 dark:text-gray-300'}"
							>
								{count} videos
							</div>
						</div>
					</div>
				{/each}
			</div>
		</div>
	{/if}

	<!-- Two Column Layout -->
	<div class="grid md:grid-cols-2 gap-6">
		<!-- Top Watched Videos -->
		{#if topWatchedVideos.length > 0}
			<div class="card">
				<h2 class="text-xl font-bold mb-4">Most Watched Videos</h2>

				<div class="space-y-3">
					{#each topWatchedVideos as record, index}
						<div class="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div
								class="flex-shrink-0 w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-sm"
							>
								{index + 1}
							</div>
							<div class="flex-1 min-w-0">
								<h3 class="font-medium text-sm line-clamp-2">{record.video.title}</h3>
								<p class="text-xs text-gray-600 dark:text-gray-400 mt-1">
									Watched {record.watchCount}x
								</p>
							</div>
						</div>
					{/each}
				</div>
			</div>
		{/if}

		<!-- Recent Completions -->
		{#if recentCompletions.length > 0}
			<div class="card">
				<h2 class="text-xl font-bold mb-4">Recent Completions</h2>

				<div class="space-y-3">
					{#each recentCompletions as record}
						<div class="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<div class="flex-shrink-0">
								<svg
									class="w-6 h-6 text-green-600 dark:text-green-400"
									fill="currentColor"
									viewBox="0 0 20 20"
								>
									<path
										fill-rule="evenodd"
										d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
										clip-rule="evenodd"
									/>
								</svg>
							</div>
							<div class="flex-1 min-w-0">
								<h3 class="font-medium text-sm line-clamp-2">{record.video.title}</h3>
								<p class="text-xs text-gray-600 dark:text-gray-400 mt-1">
									{formatDate(record.lastWatched)}
								</p>
							</div>
						</div>
					{/each}
				</div>
			</div>
		{/if}
	</div>

	<!-- Insights & Recommendations -->
	{#if playbackStats.totalVideos > 0}
		<div class="card bg-gradient-to-br from-primary-50 to-blue-50 dark:from-primary-900/20 dark:to-blue-900/20 border-primary-200 dark:border-primary-800">
			<h2 class="text-xl font-bold mb-4">Insights & Recommendations</h2>

			<div class="space-y-3 text-sm">
				{#if completionRate < 50}
					<div class="flex items-start gap-3">
						<span class="text-2xl">💡</span>
						<p>
							Your completion rate is {Math.round(completionRate)}%. Consider focusing on
							finishing videos you've started to improve your learning retention.
						</p>
					</div>
				{:else if completionRate >= 80}
					<div class="flex items-start gap-3">
						<span class="text-2xl">🎉</span>
						<p>
							Excellent! You have a {Math.round(completionRate)}% completion rate. You're doing
							great at following through with your learning goals!
						</p>
					</div>
				{/if}

				{#if learningVelocity === 0}
					<div class="flex items-start gap-3">
						<span class="text-2xl">📅</span>
						<p>
							You haven't watched any videos this week. Set aside some time for learning to
							maintain momentum!
						</p>
					</div>
				{:else if learningVelocity >= 7}
					<div class="flex items-start gap-3">
						<span class="text-2xl">🔥</span>
						<p>
							You're on fire! You've watched {learningVelocity} videos this week. Keep up the excellent
							learning pace!
						</p>
					</div>
				{/if}

				{#if pathsData.length > 0 && completedPaths === 0}
					<div class="flex items-start gap-3">
						<span class="text-2xl">🎯</span>
						<p>
							You have {totalPaths} learning path{totalPaths !== 1
								? 's'
								: ''} in progress. Try to complete one path fully to build structured knowledge!
						</p>
					</div>
				{:else if completedPaths > 0}
					<div class="flex items-start gap-3">
						<span class="text-2xl">✨</span>
						<p>
							Great job completing {completedPaths} learning path{completedPaths !== 1
								? 's'
								: ''}! Structured learning helps build comprehensive understanding.
						</p>
					</div>
				{/if}
			</div>
		</div>
	{/if}

	<!-- Empty State -->
	{#if playbackStats.totalVideos === 0 && totalPaths === 0}
		<div class="card text-center py-12">
			<svg
				class="w-24 h-24 text-gray-400 mx-auto mb-4"
				fill="none"
				stroke="currentColor"
				viewBox="0 0 24 24"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
				/>
			</svg>
			<h2 class="text-xl font-semibold mb-2">No Learning Data Yet</h2>
			<p class="text-gray-600 dark:text-gray-400 mb-4">
				Start watching videos and create learning paths to see your statistics here.
			</p>
			<div class="flex gap-3 justify-center">
				<a href="/" class="btn btn-primary"> Browse Videos </a>
				<a href="/paths/create" class="btn btn-secondary"> Create Learning Path </a>
			</div>
		</div>
	{/if}
</div>
