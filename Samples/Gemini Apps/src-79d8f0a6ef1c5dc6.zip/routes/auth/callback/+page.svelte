<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { auth } from '$lib/stores/auth';

	let status = 'Processing authentication...';
	let error = '';

	onMount(() => {
		// Google returns tokens in the URL hash for Implicit Flow
		const hash = window.location.hash.substring(1);
		const params = new URLSearchParams(hash);

		const accessToken = params.get('access_token');
		const expiresIn = params.get('expires_in');
		const errorParam = params.get('error');

		if (errorParam) {
			error = `Authentication failed: ${errorParam}`;
			status = 'Error';
			return;
		}

		if (accessToken) {
			const expiresSeconds = expiresIn ? parseInt(expiresIn) : 3600;

			auth.setSession(accessToken, expiresSeconds);
			status = 'Success! Redirecting...';

			// Short delay to show success
			setTimeout(() => {
				goto('/settings/api');
			}, 1000);
		} else {
			// Check legacy query params just in case
			const searchParams = new URLSearchParams(window.location.search);
			if (searchParams.get('error')) {
				error = `Authentication failed: ${searchParams.get('error')}`;
				status = 'Error';
			} else {
				error = 'No access token found in URL.';
				status = 'Error';
			}
		}
	});
</script>

<div class="min-h-[50vh] flex flex-col items-center justify-center p-4">
	<div class="card max-w-md w-full text-center">
		{#if error}
			<div
				class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4 text-red-600"
			>
				<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"
					><path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M6 18L18 6M6 6l12 12"
					></path></svg
				>
			</div>
			<h1 class="text-xl font-bold text-red-700 mb-2">Authentication Failed</h1>
			<p class="text-gray-600 dark:text-gray-400 mb-6">{error}</p>
			<a href="/settings/api" class="btn btn-secondary">Return to Settings</a>
		{:else}
			<div
				class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-primary-600 animate-pulse"
			>
				<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"
					><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"
					></path></svg
				>
			</div>
			<h1 class="text-xl font-bold mb-2">Connecting...</h1>
			<p class="text-gray-600 dark:text-gray-400">{status}</p>
		{/if}
	</div>
</div>
