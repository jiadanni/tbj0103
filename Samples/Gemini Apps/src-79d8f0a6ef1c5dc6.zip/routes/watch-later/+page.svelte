<script lang="ts">
	import { watchLater } from '$lib/stores/watchLater';
	import VideoCard from '$lib/components/core/VideoCard.svelte';
	import { confirm } from '$lib/stores/confirm';

	let queue = $watchLater;

	// Reactively update when watchLater changes
	$: queue = $watchLater;

	async function handleClearAll() {
		const confirmed = await confirm.confirm({
			title: 'Clear Watch Later Queue?',
			message:
				'This will remove all videos from your Watch Later queue. This action cannot be undone.',
			confirmText: 'Clear All',
			cancelText: 'Cancel',
			danger: true
		});

		if (confirmed) {
			watchLater.clear();
		}
	}
</script>

<svelte:head>
	<title>Watch Later - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<!-- Header -->
	<div class="flex items-center justify-between">
		<div>
			<h1 class="text-3xl font-bold mb-2">Watch Later</h1>
			<p class="text-gray-600 dark:text-gray-400">
				Videos you've saved to watch later ({queue.length} video{queue.length !== 1 ? 's' : ''})
			</p>
		</div>

		{#if queue.length > 0}
			<button class="btn btn-secondary" on:click={handleClearAll}> Clear All </button>
		{/if}
	</div>

	<!-- Queue -->
	{#if queue.length === 0}
		<div class="card text-center py-12">
			<svg
				class="w-24 h-24 text-gray-400 mx-auto mb-4"
				fill="none"
				stroke="currentColor"
				viewBox="0 0 24 24"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
				/>
			</svg>
			<h2 class="text-xl font-semibold mb-2">No videos in Watch Later</h2>
			<p class="text-gray-600 dark:text-gray-400 mb-4">
				Videos you add to Watch Later will appear here.
			</p>
			<a href="/" class="btn btn-primary inline-block"> Browse Videos </a>
		</div>
	{:else}
		<div class="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
			{#each queue as video (video.id)}
				<VideoCard
					{video}
					onRemoveFromWatchLater={() => {
						// Force reactivity by reassigning
						queue = $watchLater;
					}}
				/>
			{/each}
		</div>
	{/if}
</div>
