<script lang="ts">
	import { spacedRepetition, dueCardsCount, type ReviewCard, type ReviewQuality } from '$lib/stores/spacedRepetition';
	import { player } from '$lib/stores/player';
	import { formatDuration } from '$lib/utils/helpers';

	let dueCards: ReviewCard[] = [];
	let currentCardIndex = 0;
	let showAnswer = false;
	let reviewStats = {
		totalReviewed: 0,
		correct: 0,
		incorrect: 0
	};

	$: {
		dueCards = spacedRepetition.getDueCards();
	}

	$: currentCard = dueCards[currentCardIndex];
	$: progress = dueCards.length > 0 ? ((currentCardIndex + 1) / dueCards.length) * 100 : 0;
	$: remainingCards = dueCards.length - currentCardIndex;

	function handleReveal() {
		showAnswer = true;
	}

	function handleRating(quality: ReviewQuality) {
		if (!currentCard) return;

		spacedRepetition.reviewCard(currentCard.id, quality);

		// Update stats
		reviewStats.totalReviewed++;
		if (quality >= 3) {
			reviewStats.correct++;
		} else {
			reviewStats.incorrect++;
		}

		// Move to next card
		if (currentCardIndex < dueCards.length - 1) {
			currentCardIndex++;
			showAnswer = false;
		} else {
			// Done with all cards
			dueCards = spacedRepetition.getDueCards();
			currentCardIndex = 0;
			showAnswer = false;
		}
	}

	function handlePlayVideo() {
		if (currentCard) {
			player.play(currentCard.video);
		}
	}

	function handleSkip() {
		if (currentCardIndex < dueCards.length - 1) {
			currentCardIndex++;
			showAnswer = false;
		}
	}

	function formatNextReview(timestamp: number): string {
		const now = Date.now();
		const diff = timestamp - now;
		const days = Math.floor(diff / (24 * 60 * 60 * 1000));

		if (days < 1) return 'Less than a day';
		if (days === 1) return 'Tomorrow';
		if (days < 7) return `In ${days} days`;
		if (days < 30) return `In ${Math.floor(days / 7)} weeks`;
		if (days < 365) return `In ${Math.floor(days / 30)} months`;
		return `In ${Math.floor(days / 365)} years`;
	}
</script>

<svelte:head>
	<title>Review - Vektor</title>
</svelte:head>

<div class="space-y-6 max-w-4xl mx-auto">
	<!-- Header -->
	<div class="text-center">
		<h1 class="text-3xl font-bold mb-2">Spaced Repetition Review</h1>
		<p class="text-gray-600 dark:text-gray-400">
			Reinforce your learning through active recall
		</p>
	</div>

	{#if dueCards.length === 0}
		<!-- No due cards -->
		<div class="card text-center py-12">
			<svg
				class="w-24 h-24 text-green-500 mx-auto mb-4"
				fill="none"
				stroke="currentColor"
				viewBox="0 0 24 24"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
				/>
			</svg>
			<h2 class="text-2xl font-bold mb-2">All caught up!</h2>
			<p class="text-gray-600 dark:text-gray-400 mb-4">
				You have no cards due for review right now. Check back later!
			</p>

			{#if reviewStats.totalReviewed > 0}
				<div class="inline-block bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-4">
					<div class="text-sm text-gray-600 dark:text-gray-400 mb-2">Today's Session</div>
					<div class="grid grid-cols-3 gap-4 text-center">
						<div>
							<div class="text-2xl font-bold">{reviewStats.totalReviewed}</div>
							<div class="text-xs text-gray-500">Reviewed</div>
						</div>
						<div>
							<div class="text-2xl font-bold text-green-600">{reviewStats.correct}</div>
							<div class="text-xs text-gray-500">Correct</div>
						</div>
						<div>
							<div class="text-2xl font-bold text-red-600">{reviewStats.incorrect}</div>
							<div class="text-xs text-gray-500">Incorrect</div>
						</div>
					</div>
				</div>
			{/if}

			<div class="flex gap-3 justify-center">
				<a href="/paths" class="btn btn-primary"> Browse Learning Paths </a>
				<a href="/" class="btn btn-secondary"> Browse Videos </a>
			</div>
		</div>
	{:else if currentCard}
		<!-- Review Card -->
		<div class="space-y-4">
			<!-- Progress Bar -->
			<div class="card">
				<div class="flex items-center justify-between mb-2">
					<span class="text-sm font-medium">
						Card {currentCardIndex + 1} of {dueCards.length}
					</span>
					<span class="text-sm text-gray-600 dark:text-gray-400">
						{remainingCards} remaining
					</span>
				</div>
				<div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
					<div
						class="bg-primary-600 h-2 rounded-full transition-all"
						style="width: {progress}%"
					></div>
				</div>
			</div>

			<!-- Video Card -->
			<div class="card">
				<div class="flex gap-4">
					<img
						src={currentCard.video.thumbnail}
						alt={currentCard.video.title}
						class="w-48 h-28 object-cover rounded flex-shrink-0"
					/>
					<div class="flex-1">
						<h2 class="text-xl font-bold mb-2">{currentCard.video.title}</h2>
						<p class="text-sm text-gray-600 dark:text-gray-400 mb-3">
							{currentCard.video.channelTitle} • {formatDuration(currentCard.video.duration)}
						</p>

						<div class="flex gap-2">
							<button class="btn btn-primary btn-sm" on:click={handlePlayVideo}>
								<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
									<path
										d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"
									/>
								</svg>
								Play Video
							</button>
							<button class="btn btn-secondary btn-sm" on:click={handleSkip}>
								Skip
							</button>
						</div>
					</div>
				</div>
			</div>

			<!-- Review Question -->
			<div class="card bg-gradient-to-br from-primary-50 to-blue-50 dark:from-primary-900/20 dark:to-blue-900/20">
				<h3 class="text-lg font-semibold mb-3">Review Question</h3>
				<p class="text-lg mb-4">
					Can you recall the key concepts and main points from this video?
				</p>

				{#if !showAnswer}
					<button class="btn btn-primary" on:click={handleReveal}>
						Show Answer
					</button>
				{:else}
					<div class="space-y-4">
						<div class="bg-white dark:bg-gray-800 rounded-lg p-4">
							<h4 class="font-semibold mb-2">Video Description</h4>
							<p class="text-sm text-gray-700 dark:text-gray-300">
								{currentCard.video.description || 'No description available'}
							</p>
						</div>

						<div class="border-t border-gray-200 dark:border-gray-700 pt-4">
							<h4 class="font-semibold mb-3">Rate your recall:</h4>
							<div class="grid grid-cols-2 md:grid-cols-3 gap-2">
								<button
									class="btn btn-secondary text-left flex flex-col items-start hover:bg-red-100 dark:hover:bg-red-900/30"
									on:click={() => handleRating(0)}
								>
									<span class="font-bold">0 - Complete Blackout</span>
									<span class="text-xs">No memory at all</span>
								</button>
								<button
									class="btn btn-secondary text-left flex flex-col items-start hover:bg-orange-100 dark:hover:bg-orange-900/30"
									on:click={() => handleRating(1)}
								>
									<span class="font-bold">1 - Incorrect</span>
									<span class="text-xs">Remembered something</span>
								</button>
								<button
									class="btn btn-secondary text-left flex flex-col items-start hover:bg-yellow-100 dark:hover:bg-yellow-900/30"
									on:click={() => handleRating(2)}
								>
									<span class="font-bold">2 - Incorrect</span>
									<span class="text-xs">But easy to recall</span>
								</button>
								<button
									class="btn btn-secondary text-left flex flex-col items-start hover:bg-blue-100 dark:hover:bg-blue-900/30"
									on:click={() => handleRating(3)}
								>
									<span class="font-bold">3 - Correct</span>
									<span class="text-xs">With difficulty</span>
								</button>
								<button
									class="btn btn-secondary text-left flex flex-col items-start hover:bg-green-100 dark:hover:bg-green-900/30"
									on:click={() => handleRating(4)}
								>
									<span class="font-bold">4 - Correct</span>
									<span class="text-xs">With hesitation</span>
								</button>
								<button
									class="btn btn-primary text-left flex flex-col items-start"
									on:click={() => handleRating(5)}
								>
									<span class="font-bold">5 - Perfect!</span>
									<span class="text-xs">Easy recall</span>
								</button>
							</div>
						</div>
					</div>
				{/if}
			</div>

			<!-- Card Info -->
			<div class="card bg-gray-50 dark:bg-gray-800">
				<h4 class="font-semibold mb-2">Card Statistics</h4>
				<div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
					<div>
						<div class="text-gray-600 dark:text-gray-400">Repetitions</div>
						<div class="font-bold">{currentCard.repetitions}</div>
					</div>
					<div>
						<div class="text-gray-600 dark:text-gray-400">Easiness</div>
						<div class="font-bold">{currentCard.easinessFactor.toFixed(2)}</div>
					</div>
					<div>
						<div class="text-gray-600 dark:text-gray-400">Interval</div>
						<div class="font-bold">{currentCard.interval} days</div>
					</div>
					<div>
						<div class="text-gray-600 dark:text-gray-400">Next Review</div>
						<div class="font-bold">{formatNextReview(currentCard.nextReview)}</div>
					</div>
				</div>
			</div>
		</div>
	{/if}
</div>
