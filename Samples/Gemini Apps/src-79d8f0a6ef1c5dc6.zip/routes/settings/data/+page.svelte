<script lang="ts">
	import { storage } from '$lib/services/storage';
	import { sharing } from '$lib/services/sharing';
	import { profiles } from '$lib/stores/profiles';
	import { paths } from '$lib/stores/paths';

	let importing = false;
	let exporting = false;
	let fileInput: HTMLInputElement;

	async function exportAllData() {
		exporting = true;
		try {
			const data = await storage.exportAll();
			sharing.downloadAsFile(data, `vektor-backup-${new Date().toISOString().split('T')[0]}.json`);
		} catch (error) {
			alert('Export failed: ' + error);
		} finally {
			exporting = false;
		}
	}

	async function importAllData() {
		if (!fileInput.files?.length) return;

		importing = true;
		try {
			const file = fileInput.files[0];
			const content = await sharing.readFile(file);

			if (confirm('This will replace all your current data. Continue?')) {
				await storage.importAll(content);

				// Reload stores
				await profiles.init();
				await paths.init();

				alert('Data imported successfully! Refreshing page...');
				window.location.reload();
			}
		} catch (error) {
			alert('Import failed: ' + error);
		} finally {
			importing = false;
		}
	}

	async function exportProfiles() {
		try {
			const profilesData = await storage.getProfiles();
			const data = JSON.stringify({ profiles: profilesData, version: '1.0', type: 'vektor-profiles' }, null, 2);
			sharing.downloadAsFile(data, `vektor-profiles-${new Date().toISOString().split('T')[0]}.json`);
		} catch (error) {
			alert('Export failed: ' + error);
		}
	}

	async function exportPaths() {
		try {
			const pathsData = await storage.getLearningPaths();
			const data = JSON.stringify({ paths: pathsData, version: '1.0', type: 'vektor-paths' }, null, 2);
			sharing.downloadAsFile(data, `vektor-paths-${new Date().toISOString().split('T')[0]}.json`);
		} catch (error) {
			alert('Export failed: ' + error);
		}
	}

	async function clearAllData() {
		if (confirm('Are you sure you want to delete ALL data? This cannot be undone!')) {
			if (confirm('Really sure? This will delete all profiles, paths, and settings!')) {
				await storage.clearAll();
				alert('All data cleared. Refreshing page...');
				window.location.reload();
			}
		}
	}
</script>

<svelte:head>
	<title>Import/Export Data - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<div class="mb-6">
		<a href="/settings" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
			&larr; Back to Settings
		</a>
	</div>

	<h1 class="text-3xl font-bold">Data Management</h1>

	<p class="text-gray-600 dark:text-gray-400">
		Export your data for backup or to transfer to another device. Import previously exported data to restore your settings.
	</p>

	<!-- Full Backup/Restore -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Complete Backup</h2>
		<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
			Export or import all your data including profiles, learning paths, and settings.
		</p>

		<div class="flex flex-wrap gap-4">
			<button class="btn btn-primary" on:click={exportAllData} disabled={exporting}>
				{exporting ? 'Exporting...' : '📥 Export All Data'}
			</button>

			<div>
				<input
					type="file"
					bind:this={fileInput}
					accept=".json"
					class="hidden"
					on:change={importAllData}
				/>
				<button
					class="btn btn-secondary"
					on:click={() => fileInput.click()}
					disabled={importing}
				>
					{importing ? 'Importing...' : '📤 Import All Data'}
				</button>
			</div>
		</div>
	</div>

	<!-- Selective Export -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Selective Export</h2>
		<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
			Export only specific types of data.
		</p>

		<div class="grid md:grid-cols-2 gap-4">
			<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
				<h3 class="font-semibold mb-2">Profiles</h3>
				<p class="text-sm text-gray-600 dark:text-gray-400 mb-3">
					Export all your content profiles and their filter settings.
				</p>
				<button class="btn btn-primary w-full" on:click={exportProfiles}>
					Export Profiles
				</button>
			</div>

			<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
				<h3 class="font-semibold mb-2">Learning Paths</h3>
				<p class="text-sm text-gray-600 dark:text-gray-400 mb-3">
					Export all your learning paths with videos and progress.
				</p>
				<button class="btn btn-primary w-full" on:click={exportPaths}>
					Export Paths
				</button>
			</div>
		</div>
	</div>

	<!-- Storage Info -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Storage Information</h2>
		<div class="space-y-2 text-sm">
			<div class="flex justify-between">
				<span>Profiles:</span>
				<span class="font-semibold">{$profiles.length}</span>
			</div>
			<div class="flex justify-between">
				<span>Learning Paths:</span>
				<span class="font-semibold">{$paths.length}</span>
			</div>
			<div class="flex justify-between">
				<span>Total Videos in Paths:</span>
				<span class="font-semibold">
					{$paths.reduce((sum, path) => sum + path.videos.length, 0)}
				</span>
			</div>
		</div>
	</div>

	<!-- Danger Zone -->
	<div class="card border-2 border-red-500">
		<h2 class="text-xl font-semibold mb-4 text-red-600 dark:text-red-400">Danger Zone</h2>
		<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
			These actions are permanent and cannot be undone.
		</p>

		<button class="btn bg-red-600 hover:bg-red-700 text-white" on:click={clearAllData}>
			🗑️ Delete All Data
		</button>
	</div>

	<!-- Format Info -->
	<div class="card bg-blue-50 dark:bg-blue-900/20">
		<h3 class="font-semibold mb-2">💡 Data Format</h3>
		<p class="text-sm text-gray-700 dark:text-gray-300">
			All exported data is in JSON format and can be edited in any text editor. The data contains:
		</p>
		<ul class="list-disc list-inside text-sm text-gray-700 dark:text-gray-300 mt-2 space-y-1">
			<li>Profile configurations (filters, preferences)</li>
			<li>Learning path structures</li>
			<li>Progress tracking</li>
			<li>Notes and custom data</li>
		</ul>
		<p class="text-sm text-gray-700 dark:text-gray-300 mt-2">
			<strong>Note:</strong> API keys and sensitive data are NOT included in exports for security.
		</p>
	</div>
</div>
