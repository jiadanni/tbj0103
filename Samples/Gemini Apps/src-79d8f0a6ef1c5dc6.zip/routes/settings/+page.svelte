<script lang="ts">
	import { goto } from '$app/navigation';
</script>

<svelte:head>
	<title>Settings - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<h1 class="text-3xl font-bold">Settings</h1>

	<div class="grid gap-4 md:grid-cols-2">
		<!-- API Configuration -->
		<a href="/settings/api" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-primary-100 dark:bg-primary-900 rounded-lg">
					<svg
						class="w-6 h-6 text-primary-600 dark:text-primary-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors"
					>
						API Configuration
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Configure your YouTube and Vimeo API keys
					</p>
				</div>
			</div>
		</a>

		<!-- Themes -->
		<a href="/settings/themes" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-pink-100 dark:bg-pink-900 rounded-lg">
					<svg
						class="w-6 h-6 text-pink-600 dark:text-pink-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-pink-600 dark:group-hover:text-pink-400 transition-colors"
					>
						Themes
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Customize colors, fonts, and visual style
					</p>
				</div>
			</div>
		</a>

		<!-- AI Setup -->
		<a href="/settings/ai" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
					<svg
						class="w-6 h-6 text-purple-600 dark:text-purple-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors"
					>
						AI Integration
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Set up optional AI features with LM Studio or Ollama
					</p>
				</div>
			</div>
		</a>

		<!-- Content Import -->
		<a href="/settings/import" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
					<svg
						class="w-6 h-6 text-indigo-600 dark:text-indigo-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors"
					>
						Content Import
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Import subscriptions and likes from YouTube
					</p>
				</div>
			</div>
		</a>

		<!-- Backup & Restore -->
		<a href="/settings/data" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
					<svg
						class="w-6 h-6 text-green-600 dark:text-green-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors"
					>
						Backup & Restore
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Backup and restore your profiles and learning paths
					</p>
				</div>
			</div>
		</a>

		<!-- About -->
		<a href="/settings/about" class="card hover:shadow-lg transition-shadow cursor-pointer group">
			<div class="flex items-start space-x-4">
				<div class="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg">
					<svg
						class="w-6 h-6 text-gray-600 dark:text-gray-400"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
						/>
					</svg>
				</div>
				<div class="flex-1">
					<h3
						class="text-lg font-semibold group-hover:text-gray-600 dark:group-hover:text-gray-400 transition-colors"
					>
						About Vektor
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
						Version info and project details
					</p>
				</div>
			</div>
		</a>
	</div>
</div>
