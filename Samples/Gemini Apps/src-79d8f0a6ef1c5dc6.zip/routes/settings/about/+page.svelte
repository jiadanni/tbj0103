<script lang="ts">
	import { APP_NAME, APP_VERSION } from '$lib/utils/constants';
</script>

<svelte:head>
	<title>About - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<div class="mb-6">
		<a href="/settings" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
			&larr; Back to Settings
		</a>
	</div>

	<!-- App Info -->
	<div class="card text-center">
		<div class="w-20 h-20 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
			<span class="text-white font-bold text-4xl">V</span>
		</div>
		<h1 class="text-3xl font-bold mb-2">{APP_NAME}</h1>
		<p class="text-gray-600 dark:text-gray-400 mb-1">Version {APP_VERSION}</p>
		<p class="text-sm text-gray-500">Intentional Video Content Discovery</p>
	</div>

	<!-- Description -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">About Vektor</h2>
		<div class="space-y-4 text-gray-700 dark:text-gray-300">
			<p>
				Vektor is an open-source, client-side web application designed to help you discover and
				organize video content intentionally. Unlike algorithm-driven platforms, Vektor puts you in
				complete control of your learning journey.
			</p>
			<p>
				All processing happens in your browser. Your data never leaves your device unless you
				explicitly export it. You provide your own API keys, ensuring complete privacy and control.
			</p>
		</div>
	</div>

	<!-- Features -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Key Features</h2>
		<ul class="space-y-2 text-gray-700 dark:text-gray-300">
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>Privacy-First:</strong> All data stored locally, no tracking, no servers</span>
			</li>
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>BYO API Keys:</strong> You control your own YouTube/Vimeo access</span>
			</li>
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>Custom Profiles:</strong> Filter content by density, pace, and format</span>
			</li>
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>Learning Paths:</strong> Build structured curricula from videos</span>
			</li>
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>AI-Enhanced:</strong> Optional local LLM integration (LM Studio, Ollama)</span>
			</li>
			<li class="flex items-start gap-2">
				<span class="text-green-500 font-bold">✓</span>
				<span><strong>Zero Cost:</strong> No subscriptions, no hidden fees, completely free</span>
			</li>
		</ul>
	</div>

	<!-- Technology Stack -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Built With</h2>
		<div class="grid md:grid-cols-2 gap-4">
			<div>
				<h3 class="font-semibold mb-2 text-primary-600 dark:text-primary-400">Frontend</h3>
				<ul class="text-sm space-y-1 text-gray-700 dark:text-gray-300">
					<li>• SvelteKit (SSG mode)</li>
					<li>• TypeScript</li>
					<li>• Tailwind CSS</li>
					<li>• Vite</li>
				</ul>
			</div>
			<div>
				<h3 class="font-semibold mb-2 text-primary-600 dark:text-primary-400">Storage & APIs</h3>
				<ul class="text-sm space-y-1 text-gray-700 dark:text-gray-300">
					<li>• IndexedDB (localForage)</li>
					<li>• YouTube Data API v3</li>
					<li>• Vimeo API</li>
					<li>• Optional LLM integration</li>
				</ul>
			</div>
		</div>
	</div>

	<!-- License & Credits -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">License & Credits</h2>
		<p class="text-gray-700 dark:text-gray-300 mb-4">
			Vektor is released under the <strong>MIT License</strong>. You are free to use, modify, and
			distribute this software.
		</p>
		<p class="text-sm text-gray-600 dark:text-gray-400">
			Built with open-source tools and inspired by the need for intentional, focused learning in an
			age of algorithmic content feeds.
		</p>
	</div>

	<!-- Links -->
	<div class="card">
		<h2 class="text-xl font-semibold mb-4">Links & Resources</h2>
		<div class="flex flex-wrap gap-4">
			<a
				href="https://github.com/vektor/vektor"
				target="_blank"
				rel="noopener noreferrer"
				class="btn btn-primary"
			>
				📦 GitHub Repository
			</a>
			<a
				href="https://github.com/vektor/vektor/issues"
				target="_blank"
				rel="noopener noreferrer"
				class="btn btn-secondary"
			>
				🐛 Report Issue
			</a>
			<a
				href="https://github.com/vektor/vektor/discussions"
				target="_blank"
				rel="noopener noreferrer"
				class="btn btn-secondary"
			>
				💬 Discussions
			</a>
			<a
				href="https://github.com/vektor/vektor/wiki"
				target="_blank"
				rel="noopener noreferrer"
				class="btn btn-secondary"
			>
				📖 Documentation
			</a>
		</div>
	</div>

	<!-- Support -->
	<div class="card bg-primary-50 dark:bg-primary-900/20">
		<h2 class="text-xl font-semibold mb-4">Support Vektor</h2>
		<p class="text-gray-700 dark:text-gray-300 mb-4">
			Vektor is free and open-source. You can support the project by:
		</p>
		<ul class="space-y-2 text-gray-700 dark:text-gray-300">
			<li>⭐ Starring the repository on GitHub</li>
			<li>🐛 Reporting bugs and suggesting features</li>
			<li>🔧 Contributing code or documentation</li>
			<li>📢 Sharing Vektor with others</li>
			<li>💡 Creating and sharing learning path templates</li>
		</ul>
	</div>

	<!-- Privacy Statement -->
	<div class="card border-2 border-green-500">
		<h2 class="text-xl font-semibold mb-4 text-green-600 dark:text-green-400">
			Privacy Guarantee
		</h2>
		<p class="text-gray-700 dark:text-gray-300">
			Vektor is designed with privacy at its core:
		</p>
		<ul class="mt-4 space-y-2 text-sm text-gray-700 dark:text-gray-300">
			<li>✓ No data collection or telemetry</li>
			<li>✓ No tracking or analytics</li>
			<li>✓ No servers or backends</li>
			<li>✓ No accounts or authentication</li>
			<li>✓ All data stays on your device</li>
			<li>✓ You control all API keys</li>
		</ul>
		<p class="mt-4 text-sm text-gray-600 dark:text-gray-400">
			When you use Vektor, the only external connections are the API calls YOU make using YOUR keys
			to the video platforms you've configured. That's it.
		</p>
	</div>
</div>
