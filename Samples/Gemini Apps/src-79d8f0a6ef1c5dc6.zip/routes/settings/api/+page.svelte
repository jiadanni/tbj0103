<script lang="ts">
	import ApiConfig from '$lib/components/settings/ApiConfig.svelte';
</script>

<svelte:head>
	<title>API Configuration - Vektor</title>
</svelte:head>

<div class="mb-6">
	<a href="/settings" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
		&larr; Back to Settings
	</a>
</div>

<ApiConfig />
