<script lang="ts">
	import AISetup from '$lib/components/settings/AISetup.svelte';
</script>

<svelte:head>
	<title>AI Integration - Vektor</title>
</svelte:head>

<div class="mb-6">
	<a href="/settings" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
		&larr; Back to Settings
	</a>
</div>

<AISetup />
