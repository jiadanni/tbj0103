<script lang="ts">
	import { onMount } from 'svelte';
	import { settings } from '$lib/stores/settings';
	import { auth } from '$lib/stores/auth';
	import { profiles } from '$lib/stores/profiles';
	import { createYouTubeClient } from '$lib/utils/youtubeClient';
	import { ImportService } from '$lib/services/importer';
	import type { ImportItem } from '$lib/types';
	import SkeletonCard from '$lib/components/SkeletonCard.svelte';

	let activeTab: 'manual' | 'file' | 'oauth' = 'oauth';
	let manualInput = '';
	let files: FileList | null = null;

	let loading = false;
	let error = '';
	let status = '';

	// Import Staging
	let importedItems: ImportItem[] = [];
	let selectedProfileId = '';

	$: client = $settings?.youtube.apiKeys ? createYouTubeClient($settings.youtube.apiKeys) : null;
	$: importer = client ? new ImportService(client) : null;

	// Derived selected count
	$: selectedCount = importedItems.filter((i) => i.selected).length;

	async function handleManualParse() {
		if (!manualInput || !importer) return;
		loading = true;
		error = '';
		try {
			const items = await importer.parseManualInput(manualInput);
			importedItems = [...importedItems, ...items]; // Append
			status = `Found ${items.length} items.`;
			manualInput = ''; // Clear
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to parse input';
		} finally {
			loading = false;
		}
	}

	async function handleFileUpload() {
		if (!files || !files.length || !importer) return;
		loading = true;
		error = '';
		try {
			for (let i = 0; i < files.length; i++) {
				const items = await importer.parseTakeout(files[i]);
				importedItems = [...importedItems, ...items]; // Append
			}
			status = `Parsed ${files.length} files.`;
			files = null; // Clear
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to parse file';
		} finally {
			loading = false;
		}
	}

	async function handleApiFetch(type: 'likes' | 'subscriptions') {
		if (!importer || !$auth.isAuthenticated) return;
		loading = true;
		error = '';
		try {
			const items = await importer.fetchFromApi(type);
			importedItems = [...importedItems, ...items]; // Append
			status = `Fetched ${items.length} ${type}.`;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Fetch failed';
		} finally {
			loading = false;
		}
	}

	function toggleSelection(index: number) {
		importedItems[index].selected = !importedItems[index].selected;
	}

	function selectAll() {
		importedItems = importedItems.map((i) => ({ ...i, selected: true }));
	}

	function deselectAll() {
		importedItems = importedItems.map((i) => ({ ...i, selected: false }));
	}

	function removeItem(index: number) {
		importedItems.splice(index, 1);
		importedItems = importedItems;
	}

	async function saveToProfile() {
		if (!selectedProfileId) {
			error = 'Please select a profile.';
			return;
		}

		const toImport = importedItems.filter((i) => i.selected);
		if (toImport.length === 0) return;

		loading = true;
		try {
			// Get current profile filters
			const profile = $profiles.find((p) => p.id === selectedProfileId);
			if (!profile) throw new Error('Profile not found');

			// Add allowed channels
			const channelsToAdd = toImport
				.filter((i) => i.type === 'channel' || i.channelId) // Items that represent channels
				.map((i) => (i.type === 'channel' ? i.id : i.channelId!));

			// De-duplicate
			const uniqueChannels = [...new Set(channelsToAdd)];

			// Update profile
			const currentAllowed = profile.filters.allowedChannels || [];
			const newAllowed = [...new Set([...currentAllowed, ...uniqueChannels])];

			await profiles.updateProfile(selectedProfileId, {
				filters: {
					...profile.filters,
					allowedChannels: newAllowed
				}
			});

			status = `Successfully added ${uniqueChannels.length} channels to ${profile.name}!`;
			importedItems = []; // Clear
		} catch (e) {
			error = e instanceof Error ? e.message : 'Save failed';
		} finally {
			loading = false;
		}
	}
</script>

<div class="space-y-6">
	<div class="flex items-center justify-between">
		<div>
			<h2 class="text-2xl font-bold">Import Content</h2>
			<p class="text-gray-600 dark:text-gray-400">
				Add channels and videos to your profiles from external sources.
			</p>
		</div>
		<a href="/profiles" class="btn btn-secondary">Manage Profiles</a>
	</div>

	{#if !client}
		<div
			class="card bg-orange-50 dark:bg-orange-900 border-2 border-orange-200 dark:border-orange-800"
		>
			<h3 class="font-bold text-orange-800 dark:text-orange-200">API Key Required</h3>
			<p class="text-sm text-orange-700 dark:text-orange-300 mt-1">
				You need to configure at least one active API Key in General Settings to use the importer.
			</p>
		</div>
	{:else}
		<div class="card p-0 overflow-hidden">
			<!-- Tabs -->
			<div class="flex border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
				<button
					class="px-6 py-3 font-medium text-sm border-b-2 transition-colors {activeTab === 'oauth'
						? 'border-primary-600 text-primary-600'
						: 'border-transparent text-gray-500 hover:text-gray-700'}"
					on:click={() => (activeTab = 'oauth')}
				>
					Connected Account
				</button>
				<button
					class="px-6 py-3 font-medium text-sm border-b-2 transition-colors {activeTab === 'manual'
						? 'border-primary-600 text-primary-600'
						: 'border-transparent text-gray-500 hover:text-gray-700'}"
					on:click={() => (activeTab = 'manual')}
				>
					Manual Entry
				</button>
				<button
					class="px-6 py-3 font-medium text-sm border-b-2 transition-colors {activeTab === 'file'
						? 'border-primary-600 text-primary-600'
						: 'border-transparent text-gray-500 hover:text-gray-700'}"
					on:click={() => (activeTab = 'file')}
				>
					File Import
				</button>
			</div>

			<div class="p-6">
				<!-- OAuth Tab -->
				{#if activeTab === 'oauth'}
					<div class="space-y-4">
						{#if !$auth.isAuthenticated}
							<div class="text-center py-8">
								<p class="text-gray-600 mb-4">
									Connect your YouTube account to import Liked Videos and Subscriptions directly.
								</p>
								<a href="/settings/api" class="btn btn-primary">Connect Account</a>
							</div>
						{:else}
							<div class="grid sm:grid-cols-2 gap-4">
								<button
									class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-primary-500 hover:bg-primary-50 dark:hover:bg-primary-900/20 text-left transition-all group"
									on:click={() => handleApiFetch('subscriptions')}
									disabled={loading}
								>
									<h3 class="font-semibold group-hover:text-primary-600">Import Subscriptions</h3>
									<p class="text-xs text-gray-500 mt-1">Fetch channels you are subscribed to.</p>
								</button>
								<button
									class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-primary-500 hover:bg-primary-50 dark:hover:bg-primary-900/20 text-left transition-all group"
									on:click={() => handleApiFetch('likes')}
									disabled={loading}
								>
									<h3 class="font-semibold group-hover:text-primary-600">Import Liked Videos</h3>
									<p class="text-xs text-gray-500 mt-1">Fetch your most recent liked videos.</p>
								</button>
							</div>
						{/if}
					</div>
				{/if}

				<!-- Manual Tab -->
				{#if activeTab === 'manual'}
					<div class="space-y-4">
						<textarea
							bind:value={manualInput}
							class="input min-h-[150px] font-mono text-sm"
							placeholder="Paste YouTube URLs (Channels or Videos) or IDs here...&#10;One per line."
						></textarea>
						<div class="flex justify-between items-center">
							<span class="text-xs text-gray-500">Supports: Channel URLs, Video URLs, IDs</span>
							<button
								class="btn btn-primary"
								on:click={handleManualParse}
								disabled={!manualInput || loading}
							>
								{loading ? 'Processing...' : 'Analyze Input'}
							</button>
						</div>
					</div>
				{/if}

				<!-- File Tab -->
				{#if activeTab === 'file'}
					<div class="space-y-4">
						<div
							class="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center bg-gray-50 dark:bg-gray-800"
						>
							<input
								type="file"
								accept=".csv,.json"
								multiple
								class="hidden"
								id="file-upload"
								bind:files
								on:change={handleFileUpload}
							/>
							<label for="file-upload" class="cursor-pointer">
								<div class="text-gray-500 dark:text-gray-400 mb-2">
									<svg
										class="w-10 h-10 mx-auto"
										fill="none"
										stroke="currentColor"
										viewBox="0 0 24 24"
										><path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
										></path></svg
									>
								</div>
								<span class="text-primary-600 hover:underline">Click to upload</span> or drag files
								here
								<p class="text-xs text-gray-500 mt-2">
									Supports Google Takeout (subscriptions.csv, likes.json)
								</p>
							</label>
						</div>
					</div>
				{/if}
			</div>
		</div>

		{#if loading}
			<div class="card text-center py-8">
				<p>Loading...</p>
			</div>
		{/if}

		{#if error}
			<div class="card bg-red-50 text-red-700 border border-red-200">
				{error}
			</div>
		{/if}

		{#if status}
			<div class="card bg-green-50 text-green-700 border border-green-200">
				{status}
			</div>
		{/if}

		<!-- Staging Area -->
		{#if importedItems.length > 0}
			<div class="card">
				<div class="flex items-center justify-between mb-4">
					<div class="flex items-center gap-4">
						<h3 class="text-xl font-bold">Import Items ({selectedCount}/{importedItems.length})</h3>
						<div class="flex gap-2 text-sm">
							<button class="text-primary-600 hover:underline" on:click={selectAll}
								>Select All</button
							>
							<span class="text-gray-300">|</span>
							<button class="text-primary-600 hover:underline" on:click={deselectAll}
								>Deselect All</button
							>
						</div>
					</div>

					<div class="flex gap-2">
						<select bind:value={selectedProfileId} class="input py-1">
							<option value="">Select Profile...</option>
							{#each $profiles as profile}
								<option value={profile.id}>{profile.name}</option>
							{/each}
						</select>
						<button
							class="btn btn-primary"
							on:click={saveToProfile}
							disabled={!selectedProfileId || selectedCount === 0 || loading}
						>
							Import Selected
						</button>
					</div>
				</div>

				<div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 max-h-[500px] overflow-y-auto p-1">
					{#each importedItems as item, i}
						<div
							class="flex items-center gap-3 p-3 border rounded-lg {item.selected
								? 'border-primary-500 bg-primary-50 dark:bg-primary-900/10'
								: 'border-gray-200 dark:border-gray-700 opacity-60'} transition-all cursor-pointer"
							on:click={() => toggleSelection(i)}
						>
							<div
								class="w-5 h-5 flex-shrink-0 border-2 rounded {item.selected
									? 'bg-primary-500 border-primary-500'
									: 'border-gray-300'} flex items-center justify-center text-white text-xs"
							>
								{#if item.selected}✓{/if}
							</div>

							{#if item.thumbnail}
								<img
									src={item.thumbnail}
									alt=""
									class="w-10 h-10 rounded-full object-cover bg-gray-200"
								/>
							{/if}

							<div class="flex-1 min-w-0">
								<div class="font-medium truncate">{item.title || item.id}</div>
								<div class="text-xs text-gray-500 capitalize">{item.type}</div>
							</div>

							<button
								class="text-gray-400 hover:text-red-500 px-2"
								on:click|stopPropagation={() => removeItem(i)}>×</button
							>
						</div>
					{/each}
				</div>
			</div>
		{/if}
	{/if}
</div>
