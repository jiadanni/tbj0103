<script lang="ts">
	import { themes, activeTheme, DEFAULT_THEMES, type Theme } from '$lib/stores/themes';
	import { generateId } from '$lib/utils/helpers';
	import { confirm } from '$lib/stores/confirm';

	let selectedTheme: Theme | null = null;
	let isEditing = false;
	let editingTheme: Theme | null = null;

	$: customThemes = $themes.filter((t) => t.isCustom);
	$: presetThemes = DEFAULT_THEMES;

	function selectTheme(theme: Theme) {
		activeTheme.setTheme(theme.id);
	}

	function startCreatingTheme() {
		editingTheme = {
			id: generateId(),
			name: 'New Theme',
			description: '',
			colors: { ...$activeTheme.colors },
			fonts: { ...$activeTheme.fonts },
			borderRadius: $activeTheme.borderRadius,
			isCustom: true,
			createdAt: Date.now()
		};
		isEditing = true;
	}

	function startEditingTheme(theme: Theme) {
		if (!theme.isCustom) {
			// Duplicate preset theme for editing
			editingTheme = {
				...theme,
				id: generateId(),
				name: `${theme.name} (Copy)`,
				isCustom: true,
				createdAt: Date.now()
			};
		} else {
			editingTheme = { ...theme };
		}
		isEditing = true;
	}

	function saveTheme() {
		if (!editingTheme) return;
		const theme = editingTheme;

		if ($themes.find((t) => t.id === theme.id && !t.isCustom)) {
			// New theme
			themes.addTheme(theme);
		} else {
			// Update existing
			themes.updateTheme(theme.id, theme);
		}

		isEditing = false;
		editingTheme = null;
	}

	function cancelEditing() {
		isEditing = false;
		editingTheme = null;
	}

	async function deleteTheme(theme: Theme) {
		const confirmed = await confirm.confirm({
			title: 'Delete Theme?',
			message: `Are you sure you want to delete "${theme.name}"? This action cannot be undone.`,
			confirmText: 'Delete',
			cancelText: 'Cancel',
			danger: true
		});

		if (confirmed) {
			themes.deleteTheme(theme.id);
			if ($activeTheme.id === theme.id) {
				activeTheme.setTheme('default');
			}
		}
	}

	function previewTheme(theme: Theme) {
		activeTheme.setTheme(theme.id);
	}
</script>

<svelte:head>
	<title>Themes - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<!-- Header -->
	<div class="flex items-center justify-between">
		<div>
			<h1 class="text-3xl font-bold mb-2">Themes</h1>
			<p class="text-gray-600 dark:text-gray-400">Customize the look and feel of Vektor</p>
		</div>

		<button class="btn btn-primary" on:click={startCreatingTheme}> Create Custom Theme </button>
	</div>

	{#if isEditing && editingTheme}
		<!-- Theme Editor -->
		<div class="card">
			<h2 class="text-xl font-bold mb-4">
				{editingTheme.isCustom && $themes.find((t) => t.id === editingTheme.id)
					? 'Edit Theme'
					: 'Create Theme'}
			</h2>

			<div class="space-y-6">
				<!-- Basic Info -->
				<div class="space-y-4">
					<div>
						<label class="block text-sm font-medium mb-2" for="theme-name">Theme Name</label>
						<input
							id="theme-name"
							type="text"
							bind:value={editingTheme.name}
							class="input"
							placeholder="My Custom Theme"
						/>
					</div>

					<div>
						<label class="block text-sm font-medium mb-2" for="theme-description">Description</label
						>
						<textarea
							id="theme-description"
							bind:value={editingTheme.description}
							class="input"
							rows="2"
							placeholder="A brief description of your theme"
						/>
					</div>
				</div>

				<!-- Colors -->
				<div>
					<h3 class="text-lg font-semibold mb-3">Colors</h3>
					<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
						{#each Object.entries(editingTheme.colors) as [key, value]}
							<div>
								<span class="block text-sm font-medium mb-2 capitalize">
									{key.replace(/([A-Z])/g, ' $1').trim()}
								</span>
								<div class="flex gap-2">
									<input
										type="color"
										aria-label="{key} color"
										bind:value={editingTheme.colors[key]}
										class="w-12 h-10 rounded border border-gray-300 dark:border-gray-600 cursor-pointer"
									/>
									<input
										type="text"
										aria-label="{key} hex value"
										bind:value={editingTheme.colors[key]}
										class="input flex-1 font-mono text-sm"
										placeholder="#000000"
									/>
								</div>
							</div>
						{/each}
					</div>
				</div>

				<!-- Border Radius -->
				<div>
					<h3 class="text-lg font-semibold mb-3">Border Radius</h3>
					<div class="flex gap-2">
						{#each ['none', 'sm', 'md', 'lg', 'xl'] as radius}
							<button
								class="btn {editingTheme.borderRadius === radius ? 'btn-primary' : 'btn-secondary'}"
								on:click={() => (editingTheme.borderRadius = radius)}
							>
								{radius.toUpperCase()}
							</button>
						{/each}
					</div>
				</div>

				<!-- Actions -->
				<div class="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
					<button class="btn btn-primary" on:click={saveTheme}> Save Theme </button>
					<button
						class="btn btn-secondary"
						on:click={() => editingTheme && previewTheme(editingTheme)}
					>
						Preview
					</button>
					<button class="btn btn-secondary" on:click={cancelEditing}> Cancel </button>
				</div>
			</div>
		</div>
	{:else}
		<!-- Theme Gallery -->
		<div class="space-y-6">
			<!-- Preset Themes -->
			<div>
				<h2 class="text-xl font-bold mb-4">Preset Themes</h2>
				<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
					{#each presetThemes as theme}
						<div
							class="card cursor-pointer transition-all hover:shadow-lg {$activeTheme.id ===
							theme.id
								? 'ring-2 ring-primary-600'
								: ''}"
						>
							<!-- Theme Preview -->
							<div class="grid grid-cols-6 gap-1 mb-3 h-16 rounded overflow-hidden">
								<div class="col-span-2" style="background-color: {theme.colors.primary}"></div>
								<div class="col-span-2" style="background-color: {theme.colors.secondary}"></div>
								<div class="col-span-2" style="background-color: {theme.colors.accent}"></div>
								<div class="col-span-3" style="background-color: {theme.colors.background}"></div>
								<div class="col-span-3" style="background-color: {theme.colors.surface}"></div>
							</div>

							<h3 class="font-semibold text-lg mb-1">
								{theme.name}
								{#if $activeTheme.id === theme.id}
									<span class="text-primary-600 text-sm">(Active)</span>
								{/if}
							</h3>
							<p class="text-sm text-gray-600 dark:text-gray-400 mb-3">
								{theme.description}
							</p>

							<div class="flex gap-2">
								<button class="btn btn-primary flex-1" on:click={() => selectTheme(theme)}>
									{$activeTheme.id === theme.id ? 'Current' : 'Apply'}
								</button>
								<button
									class="btn btn-secondary"
									on:click={() => startEditingTheme(theme)}
									title="Customize"
								>
									<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="2"
											d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
										/>
									</svg>
								</button>
							</div>
						</div>
					{/each}
				</div>
			</div>

			<!-- Custom Themes -->
			{#if customThemes.length > 0}
				<div>
					<h2 class="text-xl font-bold mb-4">Custom Themes</h2>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
						{#each customThemes as theme}
							<div
								class="card cursor-pointer transition-all hover:shadow-lg {$activeTheme.id ===
								theme.id
									? 'ring-2 ring-primary-600'
									: ''}"
							>
								<!-- Theme Preview -->
								<div class="grid grid-cols-6 gap-1 mb-3 h-16 rounded overflow-hidden">
									<div class="col-span-2" style="background-color: {theme.colors.primary}"></div>
									<div class="col-span-2" style="background-color: {theme.colors.secondary}"></div>
									<div class="col-span-2" style="background-color: {theme.colors.accent}"></div>
									<div class="col-span-3" style="background-color: {theme.colors.background}"></div>
									<div class="col-span-3" style="background-color: {theme.colors.surface}"></div>
								</div>

								<h3 class="font-semibold text-lg mb-1">
									{theme.name}
									{#if $activeTheme.id === theme.id}
										<span class="text-primary-600 text-sm">(Active)</span>
									{/if}
								</h3>
								<p class="text-sm text-gray-600 dark:text-gray-400 mb-3">
									{theme.description || 'Custom theme'}
								</p>

								<div class="flex gap-2">
									<button class="btn btn-primary flex-1" on:click={() => selectTheme(theme)}>
										{$activeTheme.id === theme.id ? 'Current' : 'Apply'}
									</button>
									<button
										class="btn btn-secondary"
										on:click={() => startEditingTheme(theme)}
										title="Edit"
									>
										<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path
												stroke-linecap="round"
												stroke-linejoin="round"
												stroke-width="2"
												d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
											/>
										</svg>
									</button>
									<button
										class="btn btn-secondary"
										on:click={() => deleteTheme(theme)}
										title="Delete"
									>
										<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path
												stroke-linecap="round"
												stroke-linejoin="round"
												stroke-width="2"
												d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
											/>
										</svg>
									</button>
								</div>
							</div>
						{/each}
					</div>
				</div>
			{/if}
		</div>
	{/if}
</div>
