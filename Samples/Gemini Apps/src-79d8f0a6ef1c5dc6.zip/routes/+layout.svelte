<script lang="ts">
	import '../app.css';
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import { settings } from '$lib/stores/settings';
	import { profiles, activeProfile } from '$lib/stores/profiles';
	import { paths } from '$lib/stores/paths';
	import VideoPlayer from '$lib/components/core/VideoPlayer.svelte';
	import ErrorBoundary from '$lib/components/ErrorBoundary.svelte';
	import NotificationContainer from '$lib/components/NotificationContainer.svelte';
	import KeyboardShortcutsHelp from '$lib/components/KeyboardShortcutsHelp.svelte';
	import OnboardingWizard from '$lib/components/OnboardingWizard.svelte';
	import ConfirmDialog from '$lib/components/ConfirmDialog.svelte';
	import { keyboardManager } from '$lib/utils/keyboard';
	import { player } from '$lib/stores/player';
	import { onboardingComplete } from '$lib/stores/onboarding';
	import { confirm } from '$lib/stores/confirm';
	import { goto } from '$app/navigation';
	import { watchLater } from '$lib/stores/watchLater';
	import { registerServiceWorker } from '$lib/utils/serviceWorker';
	import { activeTheme } from '$lib/stores/themes';
	import { dueCardsCount } from '$lib/stores/spacedRepetition';
	import { apiHistory } from '$lib/stores/apiHistory';

	let mobileMenuOpen = false;
	let showKeyboardHelp = false;
	let showOnboarding = false;

	$: watchLaterCount = $watchLater.length;
	$: reviewCount = $dueCardsCount;

	$: if (!$onboardingComplete) {
		showOnboarding = true;
	}

	onMount(async () => {
		// Initialize stores
		await settings.init();
		await profiles.init();
		await activeProfile.init();
		await paths.init();
		await apiHistory.init();

		// Register service worker for PWA
		registerServiceWorker();

		// Register keyboard shortcuts
		keyboardManager.register({
			key: '?',
			shift: true,
			description: 'Show keyboard shortcuts',
			action: () => (showKeyboardHelp = !showKeyboardHelp)
		});

		keyboardManager.register({
			key: '/',
			description: 'Focus search',
			action: () => {
				const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
				searchInput?.focus();
			}
		});

		keyboardManager.register({
			key: 'Escape',
			description: 'Close player or dialog',
			action: () => {
				if (showKeyboardHelp) {
					showKeyboardHelp = false;
				} else {
					player.stop();
				}
			}
		});

		keyboardManager.register({
			key: ' ',
			description: 'Play / Pause video',
			action: () => {
				if ($player.currentVideo) {
					if ($player.isPlaying) {
						player.pause();
					} else {
						player.resume();
					}
				}
			}
		});

		keyboardManager.register({
			key: 'h',
			description: 'Go to Dashboard',
			action: () => goto('/')
		});

		keyboardManager.register({
			key: 'p',
			description: 'Go to Profiles',
			action: () => goto('/profiles')
		});

		keyboardManager.register({
			key: 'l',
			description: 'Go to Learning Paths',
			action: () => goto('/paths')
		});

		keyboardManager.register({
			key: 'w',
			description: 'Go to Watch Later',
			action: () => goto('/watch-later')
		});

		keyboardManager.register({
			key: 'v',
			description: 'Go to Review',
			action: () => goto('/review')
		});

		keyboardManager.register({
			key: 'r',
			description: 'Go to History',
			action: () => goto('/history')
		});

		keyboardManager.register({
			key: 't',
			description: 'Go to Stats',
			action: () => goto('/stats')
		});

		keyboardManager.register({
			key: 's',
			description: 'Go to Settings',
			action: () => goto('/settings')
		});
	});

	const navItems = [
		{ href: '/', label: 'Home', icon: 'home' },
		{ href: '/profiles', label: 'Profiles', icon: 'user' },
		{ href: '/paths', label: 'Learning Paths', icon: 'book' },
		{ href: '/watch-later', label: 'Watch Later', icon: 'clock', badge: true },
		{ href: '/review', label: 'Review', icon: 'brain', badge: true },
		{ href: '/history', label: 'History', icon: 'history' },
		{ href: '/api-history', label: 'API History', icon: 'api' },
		{ href: '/stats', label: 'Stats', icon: 'chart' },
		{ href: '/settings', label: 'Settings', icon: 'settings' }
	];

	function getIcon(icon: string): string {
		const icons: Record<string, string> = {
			home: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',
			user: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
			book: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253',
			clock: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
			brain:
				'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z',
			history: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
			api: 'M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
			chart:
				'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
			settings:
				'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z'
		};
		return icons[icon] || icons.home;
	}
</script>

<ErrorBoundary fallback="We're sorry, but something went wrong. Please try refreshing the page.">
	<div class="min-h-screen flex flex-col">
		<!-- Header -->
		<header class="bg-white dark:bg-gray-800 shadow-sm">
			<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
				<div class="flex justify-between items-center h-16">
					<!-- Logo -->
					<a href="/" class="flex items-center space-x-2">
						<div class="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
							<span class="text-white font-bold text-xl">V</span>
						</div>
						<span class="text-xl font-bold">Vektor</span>
					</a>

					<!-- Desktop Navigation -->
					<nav class="hidden md:flex space-x-1">
						{#each navItems as item}
							<a
								href={item.href}
								class="px-4 py-2 rounded-lg transition-colors relative {$page.url.pathname ===
								item.href
									? 'bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300'
									: 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}"
							>
								{item.label}
								{#if item.badge && item.href === '/watch-later' && watchLaterCount > 0}
									<span
										class="absolute -top-1 -right-1 bg-primary-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"
									>
										{watchLaterCount}
									</span>
								{:else if item.badge && item.href === '/review' && reviewCount > 0}
									<span
										class="absolute -top-1 -right-1 bg-purple-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"
									>
										{reviewCount}
									</span>
								{/if}
							</a>
						{/each}
					</nav>

					<!-- Mobile Menu Button -->
					<button class="md:hidden" on:click={() => (mobileMenuOpen = !mobileMenuOpen)}>
						<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								stroke-width="2"
								d={mobileMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'}
							/>
						</svg>
					</button>
				</div>
			</div>

			<!-- Mobile Navigation -->
			{#if mobileMenuOpen}
				<div class="md:hidden border-t border-gray-200 dark:border-gray-700">
					<nav class="px-4 py-2 space-y-1">
						{#each navItems as item}
							<a
								href={item.href}
								class="block px-4 py-2 rounded-lg transition-colors relative {$page.url.pathname ===
								item.href
									? 'bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300'
									: 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}"
								on:click={() => (mobileMenuOpen = false)}
							>
								{item.label}
								{#if item.badge && item.href === '/watch-later' && watchLaterCount > 0}
									<span
										class="ml-2 bg-primary-600 text-white text-xs font-bold rounded-full px-2 py-0.5"
									>
										{watchLaterCount}
									</span>
								{:else if item.badge && item.href === '/review' && reviewCount > 0}
									<span
										class="ml-2 bg-purple-600 text-white text-xs font-bold rounded-full px-2 py-0.5"
									>
										{reviewCount}
									</span>
								{/if}
							</a>
						{/each}
					</nav>
				</div>
			{/if}
		</header>

		<!-- Main Content -->
		<main class="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
			<slot />
		</main>

		<!-- Footer -->
		<footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-auto">
			<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
				<div class="text-center text-sm text-gray-600 dark:text-gray-400">
					<p>
						Vektor - Open source, client-side video content discovery.
						<a
							href="https://github.com/vektor/vektor"
							target="_blank"
							rel="noopener noreferrer"
							class="text-primary-600 dark:text-primary-400 hover:underline">GitHub</a
						>
					</p>
				</div>
			</div>
		</footer>

		<!-- Video Player (fixed at bottom) -->
		<VideoPlayer />

		<!-- Notifications -->
		<NotificationContainer />

		<!-- Keyboard Shortcuts Help -->
		<KeyboardShortcutsHelp bind:show={showKeyboardHelp} />

		<!-- Onboarding Wizard -->
		{#if showOnboarding}
			<OnboardingWizard
				on:complete={() => {
					onboardingComplete.complete();
					showOnboarding = false;
				}}
				on:skip={() => {
					onboardingComplete.complete();
					showOnboarding = false;
				}}
			/>
		{/if}

		<!-- Global Confirmation Dialog -->
		<ConfirmDialog
			bind:show={$confirm.show}
			title={$confirm.title || 'Confirm Action'}
			message={$confirm.message}
			confirmText={$confirm.confirmText || 'Confirm'}
			cancelText={$confirm.cancelText || 'Cancel'}
			danger={$confirm.danger || false}
			on:confirm={() => confirm.handleConfirm()}
			on:cancel={() => confirm.handleCancel()}
		/>
	</div>
</ErrorBoundary>
