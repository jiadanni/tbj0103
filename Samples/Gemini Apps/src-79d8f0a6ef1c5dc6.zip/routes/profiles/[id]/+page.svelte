<script lang="ts">
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import { onMount } from 'svelte';
	import { profiles, activeProfile } from '$lib/stores/profiles';
	import type { UserProfile, FormatType } from '$lib/types';
	import ControlPanel from '$lib/components/core/ControlPanel.svelte';

	let profile: UserProfile | null = null;
	let loading = true;
	let saving = false;

	$: profileId = $page.params.id;

	onMount(async () => {
		const found = $profiles.find((p) => p.id === profileId);
		if (found) {
			profile = JSON.parse(JSON.stringify(found)); // Deep copy
			loading = false;
		} else {
			goto('/profiles');
		}
	});

	async function saveChanges() {
		if (!profile) return;

		saving = true;
		try {
			await profiles.updateProfile(profile.id, profile);

			// Update active profile if this is the active one
			if ($activeProfile?.id === profile.id) {
				await activeProfile.setActive(profile.id);
			}

			goto('/profiles');
		} catch (error) {
			alert('Failed to save profile: ' + error);
		} finally {
			saving = false;
		}
	}

	function handleLayoutChange(layout: 'grid' | 'list') {
		if (profile) {
			profile.appearance.layout = layout;
		}
	}

	function handleThemeChange(theme: 'light' | 'dark' | 'auto') {
		if (profile) {
			profile.appearance.theme = theme;
		}
	}

	function addBlockedKeyword() {
		if (profile) {
			profile.filters.blockedKeywords = [...profile.filters.blockedKeywords, ''];
		}
	}

	function removeBlockedKeyword(index: number) {
		if (profile) {
			profile.filters.blockedKeywords = profile.filters.blockedKeywords.filter((_, i) => i !== index);
		}
	}

	function addAllowedChannel() {
		if (profile) {
			profile.filters.allowedChannels = [...profile.filters.allowedChannels, ''];
		}
	}

	function removeAllowedChannel(index: number) {
		if (profile) {
			profile.filters.allowedChannels = profile.filters.allowedChannels.filter((_, i) => i !== index);
		}
	}
</script>

<svelte:head>
	<title>Edit Profile - Vektor</title>
</svelte:head>

{#if loading}
	<div class="text-center py-12">
		<div class="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary-600 border-t-transparent"></div>
		<p class="mt-4 text-gray-600 dark:text-gray-400">Loading profile...</p>
	</div>
{:else if profile}
	<div class="space-y-6">
		<div class="mb-6">
			<a href="/profiles" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
				&larr; Back to Profiles
			</a>
		</div>

		<div class="flex items-center justify-between">
			<h1 class="text-3xl font-bold">Edit Profile</h1>
			<button class="btn btn-primary" on:click={saveChanges} disabled={saving}>
				{saving ? 'Saving...' : 'Save Changes'}
			</button>
		</div>

		<!-- Basic Info -->
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Basic Information</h3>
			<div>
				<label class="block text-sm font-medium mb-2">Profile Name</label>
				<input type="text" bind:value={profile.name} class="input" placeholder="Profile name" />
			</div>
		</div>

		<!-- Appearance -->
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Appearance</h3>
			<div class="space-y-4">
				<div>
					<label class="block text-sm font-medium mb-2">Theme</label>
					<div class="flex gap-2">
						<button
							class="btn {profile.appearance.theme === 'light' ? 'btn-primary' : 'btn-secondary'}"
							on:click={() => handleThemeChange('light')}
						>
							Light
						</button>
						<button
							class="btn {profile.appearance.theme === 'dark' ? 'btn-primary' : 'btn-secondary'}"
							on:click={() => handleThemeChange('dark')}
						>
							Dark
						</button>
						<button
							class="btn {profile.appearance.theme === 'auto' ? 'btn-primary' : 'btn-secondary'}"
							on:click={() => handleThemeChange('auto')}
						>
							Auto
						</button>
					</div>
				</div>

				<div>
					<label class="block text-sm font-medium mb-2">Layout</label>
					<div class="flex gap-2">
						<button
							class="btn {profile.appearance.layout === 'grid' ? 'btn-primary' : 'btn-secondary'}"
							on:click={() => handleLayoutChange('grid')}
						>
							Grid
						</button>
						<button
							class="btn {profile.appearance.layout === 'list' ? 'btn-primary' : 'btn-secondary'}"
							on:click={() => handleLayoutChange('list')}
						>
							List
						</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Content Filters -->
		<ControlPanel />

		<!-- Blocked Keywords -->
		<div class="card">
			<div class="flex items-center justify-between mb-4">
				<h3 class="text-lg font-semibold">Blocked Keywords</h3>
				<button class="btn btn-secondary text-sm" on:click={addBlockedKeyword}>+ Add</button>
			</div>
			<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
				Videos containing these keywords will be filtered out
			</p>
			<div class="space-y-2">
				{#each profile.filters.blockedKeywords as keyword, index}
					<div class="flex gap-2">
						<input
							type="text"
							bind:value={profile.filters.blockedKeywords[index]}
							class="input flex-1"
							placeholder="Keyword to block"
						/>
						<button
							class="btn btn-secondary px-3"
							on:click={() => removeBlockedKeyword(index)}
						>
							<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									stroke-width="2"
									d="M6 18L18 6M6 6l12 12"
								/>
							</svg>
						</button>
					</div>
				{/each}
				{#if profile.filters.blockedKeywords.length === 0}
					<p class="text-sm text-gray-500">No blocked keywords</p>
				{/if}
			</div>
		</div>

		<!-- Allowed Channels -->
		<div class="card">
			<div class="flex items-center justify-between mb-4">
				<h3 class="text-lg font-semibold">Allowed Channels (Whitelist)</h3>
				<button class="btn btn-secondary text-sm" on:click={addAllowedChannel}>+ Add</button>
			</div>
			<p class="text-sm text-gray-600 dark:text-gray-400 mb-4">
				Only show videos from these channel IDs (leave empty to allow all)
			</p>
			<div class="space-y-2">
				{#each profile.filters.allowedChannels as channel, index}
					<div class="flex gap-2">
						<input
							type="text"
							bind:value={profile.filters.allowedChannels[index]}
							class="input flex-1"
							placeholder="Channel ID"
						/>
						<button
							class="btn btn-secondary px-3"
							on:click={() => removeAllowedChannel(index)}
						>
							<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									stroke-width="2"
									d="M6 18L18 6M6 6l12 12"
								/>
							</svg>
						</button>
					</div>
				{/each}
				{#if profile.filters.allowedChannels.length === 0}
					<p class="text-sm text-gray-500">No channel whitelist (all channels allowed)</p>
				{/if}
			</div>
		</div>

		<!-- Actions -->
		<div class="flex gap-4">
			<button class="btn btn-primary flex-1" on:click={saveChanges} disabled={saving}>
				{saving ? 'Saving...' : 'Save Changes'}
			</button>
			<a href="/profiles" class="btn btn-secondary">Cancel</a>
		</div>
	</div>
{/if}
