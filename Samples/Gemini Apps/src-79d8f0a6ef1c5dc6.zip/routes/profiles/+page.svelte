<script lang="ts">
	import { profiles, activeProfile } from '$lib/stores/profiles';
	import { DEFAULT_PROFILE } from '$lib/utils/constants';
	import { generateId } from '$lib/utils/helpers';

	let showCreateForm = false;
	let newProfileName = '';

	async function createProfile() {
		if (newProfileName.trim()) {
			const profile = await profiles.add({
				...DEFAULT_PROFILE,
				name: newProfileName
			});

			newProfileName = '';
			showCreateForm = false;

			// Set as active
			await activeProfile.setActive(profile.id);
		}
	}

	async function setActive(id: string) {
		await activeProfile.setActive(id);
	}

	async function deleteProfile(id: string) {
		if (confirm('Are you sure you want to delete this profile?')) {
			await profiles.delete(id);
		}
	}
</script>

<svelte:head>
	<title>Profiles - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<div class="flex items-center justify-between">
		<h1 class="text-3xl font-bold">Content Profiles</h1>
		<button class="btn btn-primary" on:click={() => (showCreateForm = !showCreateForm)}>
			{showCreateForm ? 'Cancel' : '+ New Profile'}
		</button>
	</div>

	<p class="text-gray-600 dark:text-gray-400">
		Create different profiles for different learning contexts. Each profile has its own content
		filters and preferences.
	</p>

	<!-- Create Form -->
	{#if showCreateForm}
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Create New Profile</h3>
			<form on:submit|preventDefault={createProfile} class="space-y-4">
				<div>
					<label class="block text-sm font-medium mb-2">Profile Name</label>
					<input
						type="text"
						bind:value={newProfileName}
						class="input"
						placeholder="e.g., Deep Learning, Quick Tips, Creative Inspiration"
						required
					/>
				</div>
				<button type="submit" class="btn btn-primary"> Create Profile </button>
			</form>
		</div>
	{/if}

	<!-- Profiles List -->
	<div class="grid gap-4 md:grid-cols-2">
		{#each $profiles as profile (profile.id)}
			<div
				class="card {$activeProfile?.id === profile.id
					? 'ring-2 ring-primary-500'
					: ''} transition-all"
			>
				<div class="flex items-start justify-between mb-4">
					<div class="flex-1">
						<h3 class="text-xl font-semibold mb-1">{profile.name}</h3>
						{#if $activeProfile?.id === profile.id}
							<span
								class="inline-block px-2 py-1 text-xs bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 rounded"
							>
								Active
							</span>
						{/if}
					</div>
					<div class="flex gap-2">
						<a href="/profiles/{profile.id}" class="btn btn-secondary px-3">
							<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									stroke-width="2"
									d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
								/>
							</svg>
						</a>
					</div>
				</div>

				<div class="text-sm text-gray-600 dark:text-gray-400 space-y-1 mb-4">
					<p>Density: {profile.filters.density.toFixed(2)}</p>
					<p>Pace: {profile.filters.pace.toFixed(2)}</p>
					<p>
						Max Duration: {profile.filters.maxDuration === 0
							? 'Unlimited'
							: `${profile.filters.maxDuration} min`}
					</p>
					{#if profile.filters.formats.length > 0}
						<p>Formats: {profile.filters.formats.join(', ')}</p>
					{/if}
				</div>

				<div class="flex gap-2">
					{#if $activeProfile?.id !== profile.id}
						<button class="btn btn-primary flex-1" on:click={() => setActive(profile.id)}>
							Set Active
						</button>
					{/if}
					<button
						class="btn btn-secondary {$activeProfile?.id === profile.id ? 'flex-1' : ''}"
						on:click={() => deleteProfile(profile.id)}
					>
						Delete
					</button>
				</div>
			</div>
		{/each}
	</div>

	{#if $profiles.length === 0}
		<div class="text-center py-12 text-gray-600 dark:text-gray-400">
			<p>No profiles yet. Create your first profile to get started!</p>
		</div>
	{/if}
</div>
