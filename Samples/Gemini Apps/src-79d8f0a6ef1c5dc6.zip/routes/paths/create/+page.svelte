<script lang="ts">
	import { goto } from '$app/navigation';
	import { paths } from '$lib/stores/paths';
	import type { LearningPath } from '$lib/types';

	let title = '';
	let description = '';
	let difficulty: LearningPath['difficulty'] = 'beginner';
	let estimatedHours = 10;
	let objectives = [''];

	function addObjective() {
		objectives = [...objectives, ''];
	}

	function removeObjective(index: number) {
		objectives = objectives.filter((_, i) => i !== index);
	}

	async function createPath() {
		if (!title.trim()) {
			alert('Please enter a title');
			return;
		}

		const path = await paths.add({
			title: title.trim(),
			description: description.trim(),
			objectives: objectives.filter((o) => o.trim()),
			keywords: [],
			difficulty,
			estimatedHours,
			videos: [],
			progress: {
				completed: [],
				current: '',
				notes: {}
			}
		});

		goto(`/paths/${path.id}`);
	}
</script>

<svelte:head>
	<title>Create Learning Path - Vektor</title>
</svelte:head>

<div class="max-w-2xl mx-auto space-y-6">
	<div class="mb-6">
		<a href="/paths" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
			&larr; Back to Learning Paths
		</a>
	</div>

	<h1 class="text-3xl font-bold">Create Learning Path</h1>

	<form on:submit|preventDefault={createPath} class="space-y-6">
		<!-- Title -->
		<div class="card">
			<label class="block text-sm font-medium mb-2">Title *</label>
			<input
				type="text"
				bind:value={title}
				class="input"
				placeholder="e.g., Introduction to Machine Learning"
				required
			/>
		</div>

		<!-- Description -->
		<div class="card">
			<label class="block text-sm font-medium mb-2">Description</label>
			<textarea
				bind:value={description}
				class="input"
				rows="4"
				placeholder="Describe what this learning path covers..."
			></textarea>
		</div>

		<!-- Difficulty and Hours -->
		<div class="card grid md:grid-cols-2 gap-4">
			<div>
				<label class="block text-sm font-medium mb-2">Difficulty</label>
				<select bind:value={difficulty} class="input">
					<option value="beginner">Beginner</option>
					<option value="intermediate">Intermediate</option>
					<option value="advanced">Advanced</option>
				</select>
			</div>

			<div>
				<label class="block text-sm font-medium mb-2">Estimated Hours</label>
				<input type="number" bind:value={estimatedHours} class="input" min="1" step="1" />
			</div>
		</div>

		<!-- Objectives -->
		<div class="card">
			<div class="flex items-center justify-between mb-4">
				<label class="block text-sm font-medium">Learning Objectives</label>
				<button type="button" class="btn btn-secondary text-sm" on:click={addObjective}>
					+ Add
				</button>
			</div>

			<div class="space-y-2">
				{#each objectives as objective, index}
					<div class="flex gap-2">
						<input
							type="text"
							bind:value={objectives[index]}
							class="input flex-1"
							placeholder="What will you learn?"
						/>
						{#if objectives.length > 1}
							<button
								type="button"
								class="btn btn-secondary px-3"
								on:click={() => removeObjective(index)}
							>
								<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path
										stroke-linecap="round"
										stroke-linejoin="round"
										stroke-width="2"
										d="M6 18L18 6M6 6l12 12"
									/>
								</svg>
							</button>
						{/if}
					</div>
				{/each}
			</div>
		</div>

		<!-- Submit -->
		<div class="flex gap-4">
			<button type="submit" class="btn btn-primary flex-1"> Create Learning Path </button>
			<a href="/paths" class="btn btn-secondary"> Cancel </a>
		</div>
	</form>
</div>
