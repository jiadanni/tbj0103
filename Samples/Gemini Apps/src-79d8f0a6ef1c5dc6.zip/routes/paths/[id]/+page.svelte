<script lang="ts">
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import { onMount } from 'svelte';
	import { paths } from '$lib/stores/paths';
	import { player } from '$lib/stores/player';
	import { settings } from '$lib/stores/settings';
	import { createYouTubeClient } from '$lib/utils/youtubeClient';
	import type { LearningPath, PathVideo, VideoMetadata } from '$lib/types';
	import { formatDuration } from '$lib/utils/helpers';
	import { dndzone } from 'svelte-dnd-action';
	import { flip } from 'svelte/animate';

	let path: LearningPath | null = null;
	let loading = true;
	let currentNote = '';
	let editingNoteFor = '';
	let searchQuery = '';
	let searchResults: VideoMetadata[] = [];
	let searching = false;

	$: pathId = $page.params.id;
	$: currentVideo = path?.progress.current
		? path.videos.find((v) => v.id === path.progress.current)
		: null;
	$: progressPercentage = path ? (path.progress.completed.length / path.videos.length) * 100 : 0;

	onMount(async () => {
		const found = $paths.find((p) => p.id === pathId);
		if (found) {
			path = found;
			loading = false;
		} else {
			goto('/paths');
		}
	});

	async function playVideo(video: PathVideo) {
		if (!path) return;

		// Set as current
		await paths.setCurrentVideo(path.id, video.id);

		// Get full metadata and play
		if ($settings?.youtube.apiKey && video.source === 'youtube') {
			const client = createYouTubeClient($settings.youtube.apiKey);
			const metadata = await client.getVideo(video.sourceId);
			if (metadata) {
				player.play(metadata);
			}
		}
	}

	async function markComplete(videoId: string) {
		if (!path) return;
		await paths.completeVideo(path.id, videoId);
		// Reload path
		path = $paths.find((p) => p.id === pathId) || null;
	}

	async function saveNote(videoId: string) {
		if (!path || !currentNote.trim()) return;
		await paths.addNote(path.id, videoId, currentNote);
		currentNote = '';
		editingNoteFor = '';
		// Reload path
		path = $paths.find((p) => p.id === pathId) || null;
	}

	function startEditNote(videoId: string) {
		editingNoteFor = videoId;
		currentNote = path?.progress.notes[videoId] || '';
	}

	async function searchVideos() {
		if (!searchQuery.trim() || !$settings?.youtube.apiKey) return;

		searching = true;
		try {
			const client = createYouTubeClient($settings.youtube.apiKey);
			const result = await client.search(searchQuery, 10);
			searchResults = result.videos;
		} catch (error) {
			alert('Search failed: ' + error);
		} finally {
			searching = false;
		}
	}

	async function addVideoToPath(video: VideoMetadata) {
		if (!path) return;

		const newVideo: PathVideo = {
			id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
			source: video.source,
			sourceId: video.sourceId,
			title: video.title,
			duration: video.duration,
			order: path.videos.length,
			required: true
		};

		await paths.updatePath(path.id, {
			videos: [...path.videos, newVideo]
		});

		// Reload path
		path = $paths.find((p) => p.id === pathId) || null;
		searchQuery = '';
		searchResults = [];
	}

	async function removeVideo(videoId: string) {
		if (!path || !confirm('Remove this video from the path?')) return;

		await paths.updatePath(path.id, {
			videos: path.videos.filter((v) => v.id !== videoId)
		});

		// Reload path
		path = $paths.find((p) => p.id === pathId) || null;
	}

	function moveVideoUp(index: number) {
		if (!path || index === 0) return;
		const videos = [...path.videos];
		[videos[index - 1], videos[index]] = [videos[index], videos[index - 1]];
		videos.forEach((v, i) => (v.order = i));
		paths.updatePath(path.id, { videos });
	}

	function moveVideoDown(index: number) {
		if (!path || index === path.videos.length - 1) return;
		const videos = [...path.videos];
		[videos[index], videos[index + 1]] = [videos[index + 1], videos[index]];
		videos.forEach((v, i) => (v.order = i));
		paths.updatePath(path.id, { videos });
	}

	// Drag and drop handler
	function handleDndConsider(e: CustomEvent<any>) {
		if (!path) return;
		path = { ...path, videos: e.detail.items };
	}

	function handleDndFinalize(e: CustomEvent<any>) {
		if (!path) return;
		const videos = e.detail.items;
		videos.forEach((v: PathVideo, i: number) => (v.order = i));
		paths.updatePath(path.id, { videos });
		path = $paths.find((p) => p.id === pathId) || null;
	}
</script>

<svelte:head>
	<title>{path?.title || 'Learning Path'} - Vektor</title>
</svelte:head>

{#if loading}
	<div class="text-center py-12">
		<div
			class="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary-600 border-t-transparent"
		></div>
		<p class="mt-4 text-gray-600 dark:text-gray-400">Loading path...</p>
	</div>
{:else if path}
	<div class="space-y-6">
		<div class="mb-6">
			<a href="/paths" class="text-primary-600 dark:text-primary-400 hover:underline text-sm">
				&larr; Back to Learning Paths
			</a>
		</div>

		<!-- Header -->
		<div class="card">
			<h1 class="text-3xl font-bold mb-2">{path.title}</h1>
			<p class="text-gray-600 dark:text-gray-400 mb-4">{path.description}</p>

			<div class="flex flex-wrap gap-2 mb-4">
				<span class="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm capitalize">
					{path.difficulty}
				</span>
				<span class="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm">
					{path.estimatedHours}h estimated
				</span>
				<span class="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm">
					{path.videos.length} videos
				</span>
			</div>

			<!-- Progress -->
			<div class="space-y-2">
				<div class="flex items-center justify-between text-sm">
					<span class="font-medium">Progress</span>
					<span>{path.progress.completed.length} / {path.videos.length} completed</span>
				</div>
				<div class="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-3">
					<div
						class="bg-primary-600 h-3 rounded-full transition-all"
						style="width: {progressPercentage}%"
					></div>
				</div>
			</div>

			<!-- Objectives -->
			{#if path.objectives.length > 0}
				<div class="mt-4">
					<h3 class="font-semibold mb-2">Learning Objectives:</h3>
					<ul class="list-disc list-inside space-y-1 text-sm text-gray-700 dark:text-gray-300">
						{#each path.objectives as objective}
							<li>{objective}</li>
						{/each}
					</ul>
				</div>
			{/if}
		</div>

		<!-- Add Videos -->
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Add Videos to Path</h3>
			<div class="flex gap-2 mb-4">
				<input
					type="text"
					bind:value={searchQuery}
					class="input flex-1"
					placeholder="Search for videos to add..."
					on:keydown={(e) => e.key === 'Enter' && searchVideos()}
				/>
				<button class="btn btn-primary" on:click={searchVideos} disabled={searching}>
					{searching ? 'Searching...' : 'Search'}
				</button>
			</div>

			{#if searchResults.length > 0}
				<div class="space-y-2 max-h-96 overflow-y-auto">
					{#each searchResults as video}
						<div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
							<img src={video.thumbnail} alt={video.title} class="w-24 h-16 object-cover rounded" />
							<div class="flex-1 min-w-0">
								<h4 class="font-medium text-sm truncate">{video.title}</h4>
								<p class="text-xs text-gray-600 dark:text-gray-400">{video.channelTitle}</p>
							</div>
							<button class="btn btn-primary btn-sm" on:click={() => addVideoToPath(video)}>
								Add
							</button>
						</div>
					{/each}
				</div>
			{/if}
		</div>

		<!-- Videos List -->
		<div class="card">
			<h3 class="text-lg font-semibold mb-4">Videos ({path.videos.length})</h3>

			{#if path.videos.length === 0}
				<p class="text-gray-500 text-center py-8">No videos yet. Search and add videos above.</p>
			{:else}
				<div
					class="space-y-3"
					use:dndzone={{ items: path.videos, flipDurationMs: 200, dropTargetStyle: {} }}
					on:consider={handleDndConsider}
					on:finalize={handleDndFinalize}
				>
					{#each path.videos as video, index (video.id)}
						<div
							class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg cursor-move {path.progress.completed.includes(
								video.id
							)
								? 'bg-green-50 dark:bg-green-900/20'
								: path.progress.current === video.id
									? 'bg-primary-50 dark:bg-primary-900/20 ring-2 ring-primary-500'
									: 'bg-white dark:bg-gray-800'}"
							animate:flip={{ duration: 200 }}
						>
							<div class="flex items-start gap-3">
								<div class="flex-shrink-0 w-8 text-center font-semibold text-gray-500 cursor-grab">
									⋮⋮<br />#{index + 1}
								</div>

								<div class="flex-1 min-w-0">
									<h4 class="font-medium mb-1">{video.title}</h4>
									<p class="text-sm text-gray-600 dark:text-gray-400 mb-2">
										{formatDuration(video.duration)}
										{#if video.required}
											<span class="text-red-500">*</span>
										{/if}
									</p>

									<!-- Notes -->
									{#if path.progress.notes[video.id] && editingNoteFor !== video.id}
										<div class="mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded text-sm">
											<strong>Note:</strong>
											{path.progress.notes[video.id]}
										</div>
									{/if}

									{#if editingNoteFor === video.id}
										<div class="mt-2 space-y-2">
											<textarea
												bind:value={currentNote}
												class="input w-full"
												rows="3"
												placeholder="Add a note about this video..."
											></textarea>
											<div class="flex gap-2">
												<button class="btn btn-primary btn-sm" on:click={() => saveNote(video.id)}>
													Save Note
												</button>
												<button
													class="btn btn-secondary btn-sm"
													on:click={() => (editingNoteFor = '')}
												>
													Cancel
												</button>
											</div>
										</div>
									{/if}
								</div>

								<div class="flex flex-col gap-2">
									<button class="btn btn-primary btn-sm" on:click={() => playVideo(video)}>
										Play
									</button>

									{#if !path.progress.completed.includes(video.id)}
										<button
											class="btn btn-secondary btn-sm"
											on:click={() => markComplete(video.id)}
										>
											✓ Done
										</button>
									{/if}

									<button class="btn btn-secondary btn-sm" on:click={() => startEditNote(video.id)}>
										Note
									</button>

									<div class="flex gap-1">
										<button
											class="btn btn-secondary px-2 py-1 text-xs"
											on:click={() => moveVideoUp(index)}
											disabled={index === 0}
										>
											↑
										</button>
										<button
											class="btn btn-secondary px-2 py-1 text-xs"
											on:click={() => moveVideoDown(index)}
											disabled={index === path.videos.length - 1}
										>
											↓
										</button>
									</div>

									<button
										class="btn btn-secondary btn-sm text-red-600"
										on:click={() => removeVideo(video.id)}
									>
										×
									</button>
								</div>
							</div>
						</div>
					{/each}
				</div>
			{/if}
		</div>
	</div>
{/if}
