<script lang="ts">
	import { paths } from '$lib/stores/paths';

	function getProgressPercentage(path: any) {
		if (path.videos.length === 0) return 0;
		return (path.progress.completed.length / path.videos.length) * 100;
	}

	async function deletePath(id: string) {
		if (confirm('Are you sure you want to delete this learning path?')) {
			await paths.delete(id);
		}
	}
</script>

<svelte:head>
	<title>Learning Paths - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<div class="flex items-center justify-between">
		<h1 class="text-3xl font-bold">Learning Paths</h1>
		<a href="/paths/create" class="btn btn-primary"> + Create Path </a>
	</div>

	<p class="text-gray-600 dark:text-gray-400">
		Organize videos into structured learning paths. Track your progress and take notes as you learn.
	</p>

	<!-- Paths Grid -->
	<div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
		{#each $paths as path (path.id)}
			<a href="/paths/{path.id}" class="card hover:shadow-lg transition-shadow group">
				<div class="mb-4">
					<h3 class="text-xl font-semibold mb-2 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
						{path.title}
					</h3>
					<p class="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
						{path.description}
					</p>
				</div>

				<div class="space-y-2 mb-4">
					<div class="flex items-center justify-between text-sm">
						<span class="text-gray-600 dark:text-gray-400">Progress</span>
						<span class="font-semibold">
							{path.progress.completed.length} / {path.videos.length}
						</span>
					</div>
					<div class="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-2">
						<div
							class="bg-primary-600 h-2 rounded-full transition-all"
							style="width: {getProgressPercentage(path)}%"
						></div>
					</div>
				</div>

				<div class="flex flex-wrap gap-2 mb-4">
					<span
						class="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 rounded capitalize"
					>
						{path.difficulty}
					</span>
					<span class="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 rounded">
						{path.estimatedHours}h
					</span>
					{#if path.videos.length > 0}
						<span class="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 rounded">
							{path.videos.length} videos
						</span>
					{/if}
				</div>

				<div class="flex gap-2">
					<button class="btn btn-primary flex-1"> View </button>
					<button
						class="btn btn-secondary px-3"
						on:click|preventDefault={() => deletePath(path.id)}
					>
						<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								stroke-width="2"
								d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
							/>
						</svg>
					</button>
				</div>
			</a>
		{/each}
	</div>

	{#if $paths.length === 0}
		<div class="text-center py-12">
			<svg
				class="w-16 h-16 mx-auto text-gray-400 mb-4"
				fill="none"
				stroke="currentColor"
				viewBox="0 0 24 24"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
				/>
			</svg>
			<p class="text-gray-600 dark:text-gray-400 mb-4">No learning paths yet.</p>
			<a href="/paths/create" class="btn btn-primary"> Create Your First Path </a>
		</div>
	{/if}
</div>
