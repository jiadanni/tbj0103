<script lang="ts">
	import { apiHistory, apiStats, quotaPercentageToday } from '$lib/stores/apiHistory';
	import { onMount } from 'svelte';

	// Initialize store
	onMount(async () => {
		await apiHistory.init();
	});

	// Reactive stats
	// Reactive stats
	let selectedKey = 'all';

	$: allRecords = $apiHistory;
	$: uniqueKeys = Array.from(new Set(allRecords.map((r) => r.apiKey).filter((k): k is string => !!k)));
	
	$: filteredRecords = selectedKey === 'all' 
		? allRecords 
		: allRecords.filter((r) => r.apiKey === selectedKey);

	$: todayRecords = apiHistory.getTodayRecords(filteredRecords);
	
	// Calculate stats dynamically based on filtered records
	$: currentStats = (() => {
		const requestsByType: Record<string, number> = {
			search: 0,
			videoDetails: 0,
			channelVideos: 0,
			validation: 0
		};

		const quotaByType: Record<string, number> = {
			search: 0,
			videoDetails: 0,
			channelVideos: 0,
			validation: 0
		};

		let totalQuotaUsed = 0;
		let totalResponseTime = 0;
		let responseTimes = 0;
		let successCount = 0;

		filteredRecords.forEach((record) => {
			requestsByType[record.type] = (requestsByType[record.type] || 0) + 1;
			quotaByType[record.type] = (quotaByType[record.type] || 0) + record.quotaCost;
			totalQuotaUsed += record.quotaCost;

			if (record.responseTime) {
				totalResponseTime += record.responseTime;
				responseTimes++;
			}

			if (record.success) {
				successCount++;
			}
		});
		
		const todayFiltered = apiHistory.getTodayRecords(filteredRecords);
		const quotaUsedToday = todayFiltered.reduce((sum, r) => sum + r.quotaCost, 0);

		return {
			totalRequests: filteredRecords.length,
			totalQuotaUsed,
			requestsByType,
			quotaByType,
			averageResponseTime: responseTimes > 0 ? totalResponseTime / responseTimes : 0,
			successRate: (filteredRecords.length > 0 ? (successCount / filteredRecords.length) * 100 : 0),
			requestsToday: todayFiltered.length,
			quotaUsedToday
		};
	})();

	$: quotaPercent = (currentStats.quotaUsedToday / 10000) * 100;

	// Group records by date
	$: recordsByDate = (() => {
		const grouped = new Map<string, typeof filteredRecords>();
		filteredRecords.forEach((record) => {
			const date = new Date(record.timestamp).toLocaleDateString();
			if (!grouped.has(date)) {
				grouped.set(date, []);
			}
			grouped.get(date)!.push(record);
		});
		return Array.from(grouped.entries()).sort((a, b) => {
			return new Date(b[0]).getTime() - new Date(a[0]).getTime();
		});
	})();

	function formatTime(timestamp: number): string {
		return new Date(timestamp).toLocaleTimeString();
	}

	function formatDate(timestamp: number): string {
		return new Date(timestamp).toLocaleDateString();
	}

	function formatResponseTime(ms: number | undefined): string {
		if (!ms) return 'N/A';
		if (ms < 1000) return `${Math.round(ms)}ms`;
		return `${(ms / 1000).toFixed(2)}s`;
	}

	function getRequestTypeColor(type: string): string {
		const colors: Record<string, string> = {
			search: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
			videoDetails: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
			channelVideos: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
			validation: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
		};
		return colors[type] || 'bg-gray-100 text-gray-800';
	}

	function getRequestTypeLabel(type: string): string {
		const labels: Record<string, string> = {
			search: 'Search',
			videoDetails: 'Video Details',
			channelVideos: 'Channel Videos',
			validation: 'API Validation'
		};
		return labels[type] || type;
	}

	async function clearHistory() {
		if (confirm('Are you sure you want to clear all API request history?')) {
			await apiHistory.clear();
		}
	}

	async function clearOldRecords() {
		if (confirm('Clear records older than 30 days?')) {
			await apiHistory.clearOld(30);
		}
	}
</script>

<svelte:head>
	<title>API Request History - Vektor</title>
</svelte:head>

<div class="space-y-6">
	<!-- Header -->
	<div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
		<div>
			<h1 class="text-3xl font-bold mb-2">API Request History</h1>
			<p class="text-gray-600 dark:text-gray-400">
				Track your YouTube API usage and monitor quota consumption
			</p>
		</div>
		<div class="flex flex-wrap gap-2 items-center">
			{#if uniqueKeys.length > 0}
				<select 
					bind:value={selectedKey} 
					class="input py-1 text-sm min-w-[150px]"
				>
					<option value="all">All API Keys</option>
					{#each uniqueKeys as key}
						<option value={key}>
							{key.substring(0, 8)}...{key.substring(key.length - 4)}
						</option>
					{/each}
				</select>
			{/if}
			
			<button on:click={clearOldRecords} class="btn btn-secondary text-sm">
				Clear Old
			</button>
			<button on:click={clearHistory} class="btn btn-secondary text-sm">Clear All</button>
		</div>
	</div>

	<!-- Quota Overview -->
	<div
		class="card bg-gradient-to-br from-primary-50 to-blue-50 dark:from-primary-900/20 dark:to-blue-900/20 border-primary-200 dark:border-primary-800"
	>
		<h2 class="text-xl font-bold mb-4">Today's Quota Usage</h2>

		<div class="space-y-4">
			<div>
				<div class="flex items-center justify-between mb-2">
					<span class="text-sm font-medium">
					<span class="text-sm font-medium">
						{currentStats.quotaUsedToday.toLocaleString()} / 10,000 units
					</span>
					<span
						class="text-sm font-medium {quotaPercent > 80
							? 'text-red-600 dark:text-red-400'
							: quotaPercent > 50
								? 'text-yellow-600 dark:text-yellow-400'
								: 'text-green-600 dark:text-green-400'}"
					>
						{quotaPercent.toFixed(1)}%
					</span>
				</div>
				<div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4">
					<div
						class="h-4 rounded-full transition-all {quotaPercent > 80
							? 'bg-red-600'
							: quotaPercent > 50
								? 'bg-yellow-600'
								: 'bg-green-600'}"
						style="width: {Math.min(quotaPercent, 100)}%"
					></div>
				</div>
			</div>

			<div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
				<div class="text-center">
					<div class="text-2xl font-bold text-primary-600 dark:text-primary-400">
					<div class="text-2xl font-bold text-primary-600 dark:text-primary-400">
						{currentStats.requestsToday}
					</div>
					<div class="text-xs text-gray-600 dark:text-gray-400">Requests Today</div>
				</div>
				<div class="text-center">
					<div class="text-2xl font-bold text-blue-600 dark:text-blue-400">
					<div class="text-2xl font-bold text-blue-600 dark:text-blue-400">
						{currentStats.totalRequests}
					</div>
					<div class="text-xs text-gray-600 dark:text-gray-400">Total Requests</div>
				</div>
				<div class="text-center">
					<div class="text-2xl font-bold text-green-600 dark:text-green-400">
					<div class="text-2xl font-bold text-green-600 dark:text-green-400">
						{currentStats.successRate.toFixed(1)}%
					</div>
					<div class="text-xs text-gray-600 dark:text-gray-400">Success Rate</div>
				</div>
				<div class="text-center">
					<div class="text-2xl font-bold text-purple-600 dark:text-purple-400">
					<div class="text-2xl font-bold text-purple-600 dark:text-purple-400">
						{Math.round(currentStats.averageResponseTime)}ms
					</div>
					<div class="text-xs text-gray-600 dark:text-gray-400">Avg Response</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Stats by Request Type -->
	<div class="card">
		<h2 class="text-xl font-bold mb-4">Quota Usage by Request Type</h2>

		<div class="space-y-3">
			{#each Object.entries(currentStats.quotaByType) as [type, quota]}
				{@const count = currentStats.requestsByType[type]}
				{@const percentage = currentStats.totalQuotaUsed > 0 ? (quota / currentStats.totalQuotaUsed) * 100 : 0}
				<div>
					<div class="flex items-center justify-between mb-1">
						<span class="text-sm font-medium flex items-center gap-2">
							<span class="px-2 py-1 rounded text-xs {getRequestTypeColor(type)}">
								{getRequestTypeLabel(type)}
							</span>
							<span class="text-gray-600 dark:text-gray-400">
								{count} request{count !== 1 ? 's' : ''}
							</span>
						</span>
						<span class="text-sm font-medium">
							{quota.toLocaleString()} units
						</span>
					</div>
					<div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
						<div
							class="h-2 rounded-full bg-primary-600 transition-all"
							style="width: {percentage}%"
						></div>
					</div>
				</div>
			{/each}
		</div>
	</div>

	<!-- Request History -->
	<div class="card">
		<h2 class="text-xl font-bold mb-4">Request Log</h2>

		{#if allRecords.length === 0}
			<div class="text-center py-12">
				<svg
					class="w-16 h-16 text-gray-400 mx-auto mb-4"
					fill="none"
					stroke="currentColor"
					viewBox="0 0 24 24"
				>
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
					/>
				</svg>
				<h3 class="text-lg font-semibold mb-2">No API Requests Yet</h3>
				<p class="text-gray-600 dark:text-gray-400">
					Start searching for videos to see your API request history here.
				</p>
			</div>
		{:else}
			<div class="space-y-6">
				{#each recordsByDate as [date, records]}
					<div>
						<h3
							class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3 sticky top-0 bg-white dark:bg-gray-900 py-2"
						>
							{date}
						</h3>
						<div class="space-y-2">
							{#each records as record}
								<div
									class="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg {!record.success
										? 'border-l-4 border-red-500'
										: ''}"
								>
									<div class="flex-shrink-0 text-xs text-gray-500 dark:text-gray-400 w-16">
										<div>{formatTime(record.timestamp)}</div>
										{#if record.apiKey && selectedKey === 'all'}
											<div class="text-[10px] text-gray-400 font-mono mt-0.5" title={record.apiKey}>
												{record.apiKey.substring(0, 4)}...
											</div>
										{/if}
									</div>
									<div class="flex-1 min-w-0">
										<div class="flex items-center gap-2 mb-1">
											<span
												class="px-2 py-1 rounded text-xs font-medium {getRequestTypeColor(
													record.type
												)}"
											>
												{getRequestTypeLabel(record.type)}
											</span>
											{#if !record.success}
												<span
													class="px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
												>
													Failed
												</span>
											{/if}
											<span class="text-xs text-gray-500 dark:text-gray-400">
												{formatResponseTime(record.responseTime)}
											</span>
										</div>
										<div class="text-sm text-gray-700 dark:text-gray-300">
											{#if record.type === 'search'}
												Search: "{record.parameters.query}"
											{:else if record.type === 'videoDetails'}
												Video Details: {record.parameters.videoIds}
											{:else if record.type === 'channelVideos'}
												Channel: {record.parameters.channelId}
											{:else if record.type === 'validation'}
												API Key Validation
											{/if}
										</div>
										{#if record.error}
											<div class="text-xs text-red-600 dark:text-red-400 mt-1">
												Error: {record.error}
											</div>
										{/if}
										{#if record.resultCount !== undefined}
											<div class="text-xs text-gray-500 dark:text-gray-400 mt-1">
												{record.resultCount} result{record.resultCount !== 1 ? 's' : ''}
											</div>
										{/if}
									</div>
									<div class="flex-shrink-0 text-right">
										<div class="text-sm font-semibold text-gray-700 dark:text-gray-300">
											{record.quotaCost}
										</div>
										<div class="text-xs text-gray-500 dark:text-gray-400">units</div>
									</div>
								</div>
							{/each}
						</div>
					</div>
				{/each}
			</div>
		{/if}
	</div>
</div>
