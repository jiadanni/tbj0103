import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_actions.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_transaction_sheet.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart'; // [NEW]
import 'package:expense_stalker_mobile/src/widgets/update_payment_sheet.dart';

class PaymentsListItem {
  final PlannerItem? plannerItem;
  final PaymentEntry? standalonePayment;

  PaymentsListItem.fromPlannerItem(this.plannerItem) : standalonePayment = null;
  PaymentsListItem.fromStandalonePayment(this.standalonePayment) : plannerItem = null;

  bool get isPlannerItem => plannerItem != null;
  String get label => plannerItem?.label ?? standalonePayment!.label;
  int get amountMinorUnits => plannerItem?.amountMinorUnits ?? standalonePayment!.amountMinorUnits;
  PaymentType get type => plannerItem?.type ?? standalonePayment!.type;
  String? get category => plannerItem?.category ?? standalonePayment!.category;
  String? get company => plannerItem?.company ?? standalonePayment!.company;
  String? get notes => plannerItem?.notes ?? standalonePayment!.notes;
}

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  static const _pageSize = AppConstants.pageSizeDefault; // render 50 items at a time

  final ScrollController _scrollController = ScrollController();
  int _loadedCount = _pageSize;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final maxScroll = _scrollController.position.maxScrollExtent;
    final current = _scrollController.position.pixels;
    if (current >= (maxScroll - AppConstants.scrollThresholdNormal)) {
      setState(() {
        _loadedCount += _pageSize;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        return ListenableBuilder(
          listenable: settings,
          builder: (context, _) {
             // Filter items based on current settings
            final filteredItems = _filterItems(store.plannerItems, store.payments, settings);
            _sortItems(filteredItems, settings, store.payments);
            final showMore = filteredItems.length > _loadedCount;
            final displayCount = showMore ? _loadedCount : filteredItems.length;

            // Group items if grouping is enabled
            final groupedItems = _groupItems(filteredItems, settings, store.payments);

            return Stack(
              children: [
                SafeArea(
                  child: CustomScrollView(
                controller: _scrollController,
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    title: Text(Terminology.of(context).listTabLabel),
                    actions: [
                      IconButton(
                        tooltip: AppLocalizations.of(context)!.optionsTitle,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const OptionsScreen(),
                            ),
                          );
                        },
                        icon: const Icon(Icons.settings_outlined),
                      ),
                    ],
                  ),
                  // Filter chips
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Filter by:',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'Show Archived',
                                    style: Theme.of(context).textTheme.bodySmall,
                                  ),
                                  const SizedBox(width: 4),
                                  Transform.scale(
                                    scale: 0.7,
                                    child: Switch(
                                      value: settings.paymentsShowArchived,
                                      onChanged: (v) => settings.paymentsShowArchived = v,
                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 8,
                            runSpacing: 0,
                            children: [
                              _buildFilterChip(
                                context,
                                label: 'All',
                                selected: settings.paymentsFilterType == PaymentsFilterType.all,
                                onSelected: () => settings.paymentsFilterType = PaymentsFilterType.all,
                              ),
                                _buildFilterChip(
                                  context,
                                  label: settings.paymentsFilterType == PaymentsFilterType.category && settings.paymentsFilterCategory != null
                                      ? 'Category: ${settings.paymentsFilterCategory}'
                                      : 'Category',
                                  selected: settings.paymentsFilterType == PaymentsFilterType.category,
                                  onSelected: () {
                                    if (settings.paymentsFilterType == PaymentsFilterType.category) {
                                      // If already selected, show dialog to change category
                                      _showCategoryFilterDialog(context, settings, store);
                                    } else {
                                      // If switching to category, show dialog if no category set, else just switch
                                      if (settings.paymentsFilterCategory == null) {
                                        _showCategoryFilterDialog(context, settings, store);
                                      } else {
                                        settings.paymentsFilterType = PaymentsFilterType.category;
                                      }
                                    }
                                  },
                                ),
                                _buildFilterChip(
                                  context,
                                  label: 'Income',
                                  selected: settings.paymentsFilterType == PaymentsFilterType.income,
                                  onSelected: () => settings.paymentsFilterType = PaymentsFilterType.income,
                                ),
                              _buildFilterChip(
                                context,
                                label: 'Expenses',
                                selected: settings.paymentsFilterType == PaymentsFilterType.expenses,
                                onSelected: () => settings.paymentsFilterType = PaymentsFilterType.expenses,
                              ),
                              _buildFilterChip(
                                context,
                                label: 'Debt',
                                selected: settings.paymentsFilterType == PaymentsFilterType.debt,
                                onSelected: () => settings.paymentsFilterType = PaymentsFilterType.debt,
                              ),
                              _buildFilterChip(
                                context,
                                label: 'One-off',
                                selected: settings.paymentsFilterType == PaymentsFilterType.oneOff,
                                onSelected: () => settings.paymentsFilterType = PaymentsFilterType.oneOff,
                              ),
                              _buildFilterChip(
                                context,
                                label: 'Recurring',
                                selected: settings.paymentsFilterType == PaymentsFilterType.recurring,
                                onSelected: () => settings.paymentsFilterType = PaymentsFilterType.recurring,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Group by selector
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Group by:',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 8,
                            runSpacing: 0,
                            children: [
                              PaymentsGroupBy.category,
                              PaymentsGroupBy.type,
                              PaymentsGroupBy.company,
                              PaymentsGroupBy.dueDate,
                            ].map((group) {
                              final isSelected = settings.paymentsGroupBy == group;
                              return ChoiceChip(
                                label: Text(
                                  group == PaymentsGroupBy.dueDate ? 'Due Date' : group.name[0].toUpperCase() + group.name.substring(1),
                                  style: const TextStyle(fontSize: 12),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  settings.paymentsGroupBy = selected ? group : PaymentsGroupBy.none;
                                },
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SliverToBoxAdapter(child: Divider(height: 1)),
                  // Items list
                  if (filteredItems.isEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 32, 16, 32),
                        child: Center(
                          child: Text(
                            settings.paymentsFilterType != PaymentsFilterType.all
                                ? 'No items match the current filter'
                                : Terminology.of(context).noItemsMessage,
                          ),
                        ),
                      ),
                    )
                  else
                    _buildItemsList(context, groupedItems, displayCount, showMore, settings, store),
                  const SliverToBoxAdapter(child: SizedBox(height: AppConstants.appBarExtendedHeight)),
                ],
                  ),
                ),
                Positioned(
                  right: 16,
                  bottom: 16,
                  child: FloatingActionButton(
                    onPressed: () => _showAddMenu(context),
                    child: const Icon(Icons.add),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildFilterChip(
    BuildContext context, {
    required String label,
    required bool selected,
    required VoidCallback onSelected,
  }) {
    return FilterChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      selected: selected,
      onSelected: (_) => onSelected(),
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }

  List<PaymentsListItem> _filterItems(List<PlannerItem> items, List<PaymentEntry> payments, AppSettingsStore settings) {
    final plannerItems = items.where((item) {
      // Filter by archived status
      if (!settings.paymentsShowArchived && item.archived) {
        return false;
      }

      // Filter by type
      switch (settings.paymentsFilterType) {
        case PaymentsFilterType.all:
          return true;
        case PaymentsFilterType.income:
          return item.type == PaymentType.recurringIncome || item.type == PaymentType.oneOffIncome;
        case PaymentsFilterType.expenses:
          return item.type == PaymentType.recurring || item.type == PaymentType.oneOff;
        case PaymentsFilterType.debt:
          return item.type == PaymentType.debt;
        case PaymentsFilterType.oneOff:
          return item.type == PaymentType.oneOff || item.type == PaymentType.oneOffIncome;
        case PaymentsFilterType.recurring:
          return item.type == PaymentType.recurring || item.type == PaymentType.recurringIncome;
        case PaymentsFilterType.category:
          if (settings.paymentsFilterCategory == null) return true;
          return item.category == settings.paymentsFilterCategory;
      }
    }).map((item) => PaymentsListItem.fromPlannerItem(item));

    final standalonePayments = payments.where((p) => p.plannerItemId == null).where((p) {
       // Filter by type
      switch (settings.paymentsFilterType) {
        case PaymentsFilterType.all:
          return true;
        case PaymentsFilterType.income:
          return p.type.isIncomeType;
        case PaymentsFilterType.expenses:
          return !p.type.isIncomeType;
        case PaymentsFilterType.debt:
          return p.type == PaymentType.debt;
        case PaymentsFilterType.oneOff:
          return p.type == PaymentType.oneOff || p.type == PaymentType.oneOffIncome;
        case PaymentsFilterType.recurring:
          return p.type == PaymentType.recurring || p.type == PaymentType.recurringIncome;
        case PaymentsFilterType.category:
          if (settings.paymentsFilterCategory == null) return true;
          return p.category == settings.paymentsFilterCategory;
      }
    }).map((p) => PaymentsListItem.fromStandalonePayment(p));

    return [...plannerItems, ...standalonePayments];
  }

  void _sortItems(
    List<PaymentsListItem> items, 
    AppSettingsStore settings, 
    List<PaymentEntry> payments,
  ) {
    items.sort((a, b) {
      final dateA = _getItemDate(a, payments, settings);
      final dateB = _getItemDate(b, payments, settings);
      
      if (dateA == null && dateB == null) return 0;
      if (dateA == null) return 1; // Put nulls at end
      if (dateB == null) return -1;
      
      final comparison = dateA.compareTo(dateB);
      // Default to ascending (oldest to newest) unless reverse specified
      return settings.plannerSortOrder == PlannerSortOrder.reverseChronological
          ? -comparison
          : comparison; 
    });
  }

  DateTime? _getItemDate(
    PaymentsListItem item, 
    List<PaymentEntry> payments, 
    AppSettingsStore settings,
  ) {
    if (item.isPlannerItem) {
      if (item.plannerItem == null) return null;
      // Fallback to startDate if no next due date (e.g. ended one-off)
      return _nextDueDate(
        item: item.plannerItem!, 
        payments: payments, 
        settings: settings,
      ) ?? item.plannerItem!.startDate;
    } else {
      return item.standalonePayment?.date;
    }
  }

  Future<void> _showCategoryFilterDialog(
    BuildContext context,
    AppSettingsStore settings,
    ExpenseStore store,
  ) async {
    final suggestions = getCategorySuggestions(
      isIncome: false, // Show expenses by default or merge
      mode: CategoryPresetMode.both,
      userCategories: [
        ...store.currentAccount.customExpenseCategories,
        ...store.currentAccount.customIncomeCategories,
      ],
    );
    // Merge all potential categories
    final allCategories = <String>{
      ...incomeCategories,
      ...expenseCategories,
      ...store.currentAccount.customExpenseCategories,
      ...store.currentAccount.customIncomeCategories,
    }.toList()..sort();

    final selected = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Select Category'),
        children: [
           SimpleDialogOption(
            onPressed: () => Navigator.pop(context, ''), // Clear/All
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('All Categories (Clear Filter)', style: TextStyle(fontStyle: FontStyle.italic)),
            ),
          ),
          const Divider(),
          SizedBox(
            width: double.maxFinite,
            height: 300,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: allCategories.length,
              itemBuilder: (context, index) {
                final cat = allCategories[index];
                return SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, cat),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(cat),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );

    if (selected != null) {
      if (selected.isEmpty) {
         settings.paymentsFilterCategory = null;
         settings.paymentsFilterType = PaymentsFilterType.all;
      } else {
        settings.paymentsFilterCategory = selected;
        settings.paymentsFilterType = PaymentsFilterType.category;
      }
    }
  }

  Map<String, List<PaymentsListItem>> _groupItems(
    List<PaymentsListItem> items,
    AppSettingsStore settings,
    List<PaymentEntry> payments,
  ) {
    if (settings.paymentsGroupBy == PaymentsGroupBy.none) {
      return {'': items};
    }

    final Map<String, List<PaymentsListItem>> groups = {};

    for (final item in items) {
      String groupKey;
      switch (settings.paymentsGroupBy) {
        case PaymentsGroupBy.none:
          groupKey = '';
          break;
        case PaymentsGroupBy.category:
          groupKey = item.category ?? 'Uncategorized';
          break;
        case PaymentsGroupBy.type:
          groupKey = item.type.label;
          break;
        case PaymentsGroupBy.company:
          groupKey = item.company ?? 'No Company';
          break;
        case PaymentsGroupBy.dueDate:
          if (item.isPlannerItem) {
             final nextDue = _nextDueDate(item: item.plannerItem!, payments: payments, settings: settings);
             if (nextDue == null) {
               groupKey = 'No Due Date';
             } else {
               groupKey = _formatDueDate(nextDue);
             }
          } else {
             // Standalone payment
             groupKey = _formatDueDate(item.standalonePayment!.date);
          }
          break;
      }

      (groups[groupKey] ??= []).add(item);
    }

    return groups;
  }

  Widget _buildItemsList(
    BuildContext context,
    Map<String, List<PaymentsListItem>> groupedItems,
    int displayCount,
    bool showMore,
    AppSettingsStore settings,
    ExpenseStore store,
  ) {
    if (settings.paymentsGroupBy == PaymentsGroupBy.none) {
      // Flat list (no grouping)
      final items = groupedItems['']!;
      return SliverList.separated(
        itemCount: displayCount + (showMore ? 1 : 0),
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          if (showMore && index == displayCount) {
            return ListTile(
              title: const Center(child: Text('Show more...')),
              onTap: () => setState(() => _loadedCount += _pageSize),
            );
          }
          return _buildItemTile(context, items[index], settings, store);
        },
      );
    }

    // Grouped list
    final sortedGroups = groupedItems.keys.toList()..sort();
    final widgets = <Widget>[];
    int itemCount = 0;

    for (final groupKey in sortedGroups) {
      final groupItems = groupedItems[groupKey]!;
      
      // Add group header
      widgets.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: Text(
            groupKey,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );

      // Add items in this group
      for (int i = 0; i < groupItems.length && itemCount < displayCount; i++) {
        widgets.add(_buildItemTile(context, groupItems[i], settings, store));
        if (i < groupItems.length - 1 || sortedGroups.last != groupKey) {
          widgets.add(const Divider(height: 1));
        }
        itemCount++;
      }

      if (itemCount >= displayCount) break;
    }

    if (showMore) {
      widgets.add(ListTile(
        title: const Center(child: Text('Show more...')),
        onTap: () => setState(() => _loadedCount += _pageSize),
      ));
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) => widgets[index],
        childCount: widgets.length,
      ),
    );
  }

  Widget _buildItemTile(
    BuildContext context,
    PaymentsListItem listItem,
    AppSettingsStore settings,
    ExpenseStore store,
  ) {
    if (listItem.isPlannerItem) {
      final item = listItem.plannerItem!;
      final nextDue = _nextDueDate(
        item: item,
        payments: store.payments,
        settings: settings,
      );
      final dueLabel = nextDue != null ? _formatDueDate(nextDue) : null;
      final typeLabel = item.type == PaymentType.oneOff
          ? item.type.label
          : item.frequency != null
              ? '${item.frequency!.label} ${item.type.label}'
              : item.type.label;
      final trailing = Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            formatMoneyFromCents(
              item.amountMinorUnits,
              settings.currency,
              showCents: settings.showCents,
            ),
            style: TextStyle(
              color: item.amountMinorUnits < 0
                  ? settings.debitColor
                  : settings.creditColor,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ],
      );
      // Payments screen always uses full text display (no icons/acronyms)
      final tile = ListTile(
        dense: true,
        visualDensity: const VisualDensity(vertical: -4),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
        title: Text(
          item.label,
          style: item.archived
              ? TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  decoration: TextDecoration.lineThrough,
                )
              : null,
        ),
        subtitle: Text(
          [
            if (item.archived) Terminology.of(context).itemStatusLabel,
            typeLabel,
            if (item.type != PaymentType.debt && dueLabel != null) dueLabel,
            if (item.category != null && item.category!.isNotEmpty)
              item.category,
            if (item.company != null && item.company!.isNotEmpty)
              item.company,
            if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null)
              '${AppLocalizations.of(context)!.remainingBalance} ${formatMoneyFromCents(item.remainingBalanceMinorUnits!, item.balanceCurrency ?? settings.currency, showCents: settings.showCents)}',
            if (item.type == PaymentType.debt && item.calculateFinalPaymentDate() != null)
              '${AppLocalizations.of(context)!.estimatedRepaymentDate} ${_formatDate(item.calculateFinalPaymentDate()!)}',
            if (item.notes != null && item.notes!.isNotEmpty) item.notes,
          ].where((s) => s != null && s.isNotEmpty).cast<String>().join(' • '),
          style: item.archived
              ? TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                )
              : null,
        ),
        trailing: trailing,
        onTap: () => _showUpsertPlannerItemSheet(
          context,
          existing: item,
        ),
        onLongPress: () => _showPlannerItemActions(context, item),
      );

      final direction = _paymentDismissDirection(
        left: settings.paymentSwipeLeft,
        right: settings.paymentSwipeRight,
      );
      if (direction == null) return tile;

      return Dismissible(
        key: ValueKey(item.id),
        direction: direction,
        background: item.archived
            ? _resumeDismissBackground(context, alignLeft: true)
            : _paymentDismissBackground(
                context,
                action: settings.paymentSwipeRight,
                alignLeft: true,
              ) ,
        secondaryBackground: item.archived
            ? _resumeDismissBackground(context, alignLeft: false)
            : _paymentDismissBackground(
                context,
                action: settings.paymentSwipeLeft,
                alignLeft: false,
              ),
        confirmDismiss: (dismissDirection) async {
          final action = dismissDirection == DismissDirection.endToStart
              ? settings.paymentSwipeLeft
              : settings.paymentSwipeRight;
          return _handlePaymentSwipeAction(context, item, action);
        },
        child: tile,
      );
    } else {
      // Standalone payment
      final p = listItem.standalonePayment!;
      final trailing = Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            formatMoneyFromCents(
              p.amountMinorUnits,
              settings.currency,
              showCents: settings.showCents,
            ),
            style: TextStyle(
              color: p.amountMinorUnits < 0
                  ? settings.debitColor
                  : settings.creditColor,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ],
      );

      final tile = ListTile(
        dense: true,
        visualDensity: const VisualDensity(vertical: -4),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
        leading: const Icon(Icons.receipt_long_outlined, size: 18),
        title: Text(p.label),
        subtitle: Text(
          [
            p.type.label,
            _formatDueDate(p.date),
            if (p.category != null && p.category!.isNotEmpty) p.category,
            if (p.company != null && p.company!.isNotEmpty) p.company,
            if (p.notes != null && p.notes!.isNotEmpty) p.notes,
          ].where((s) => s != null && s.isNotEmpty).cast<String>().join(' • '),
        ),
        trailing: trailing,
        onTap: () => _showUpdatePaymentSheetStandalone(context, p),
        onLongPress: () => _showStandalonePaymentActions(context, p),
      );

      return Dismissible(
        key: ValueKey(p.id),
        direction: DismissDirection.horizontal,
         background: _paymentDismissBackground(
                context,
                action: PaymentSwipeAction.delete,
                alignLeft: true,
              ),
        secondaryBackground: _paymentDismissBackground(
                context,
                action: PaymentSwipeAction.delete,
                alignLeft: false,
              ),
        confirmDismiss: (direction) async {
          final confirmed = await _confirmDeleteStandalone(context, p);
          if (confirmed) {
            store.deletePayment(p.id);
            settings.currentBalanceCents -= p.amountMinorUnits;
          }
          return confirmed;
        },
        child: tile,
      );
    }
  }

  Future<void> _showPlannerItemActions(
    BuildContext context,
    PlannerItem item,
  ) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final action = await showModalBottomSheet<_PlannerItemAction>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Show debt details header for debt items
              if (item.type == PaymentType.debt && (item.remainingBalanceMinorUnits != null || item.calculateFinalPaymentDate() != null))
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        AppLocalizations.of(context)!.debtDetails,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: AppConstants.paddingSmall),
                      if (item.remainingBalanceMinorUnits != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                AppLocalizations.of(context)!.remainingBalance,
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              Text(
                                formatMoneyFromCents(item.remainingBalanceMinorUnits!, item.balanceCurrency ?? settings.currency, showCents: settings.showCents),
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  fontFeatures: const [FontFeature.tabularFigures()],
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (item.calculateFinalPaymentDate() != null)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              AppLocalizations.of(context)!.estimatedRepaymentDate,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            Text(
                              _formatDate(item.calculateFinalPaymentDate()!),
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              if (item.type == PaymentType.debt && (item.remainingBalanceMinorUnits != null || item.calculateFinalPaymentDate() != null))
                const Divider(height: 1),
              // Show category and company details if available
              if ((item.category != null && item.category!.isNotEmpty) || (item.company != null && item.company!.isNotEmpty))
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (item.category != null && item.category!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppLocalizations.of(context)!.category,
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                item.category ?? '',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (item.company != null && item.company!.isNotEmpty)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              AppLocalizations.of(context)!.company,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item.company!,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              if ((item.category != null && item.category!.isNotEmpty) || (item.company != null && item.company!.isNotEmpty))
                const Divider(height: 1),
              ListTile(
                leading: Icon(
                  item.archived ? Icons.play_arrow_outlined : Icons.stop_outlined,
                ),
                title: Text(item.archived
                    ? Terminology.of(context).unmarkActionLabel
                    : Terminology.of(context).markActionLabel),
                onTap: () => Navigator.pop(context, _PlannerItemAction.archive),
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: Text(AppLocalizations.of(context)!.delete),
                onTap: () => Navigator.pop(context, _PlannerItemAction.delete),
              ),
              const SizedBox(height: AppConstants.paddingSmall),
            ],
          ),
        );
      },
    );

    if (!context.mounted || action == null) return;

    switch (action) {
      case _PlannerItemAction.archive:
        store.setPlannerItemArchived(item.id, !item.archived);
        break;
      case _PlannerItemAction.delete:
        store.deletePlannerItem(item.id);
        break;
    }
  }

  Future<void> _showUpsertPlannerItemSheet(
    BuildContext context, {
    PlannerItem? existing,
  }) async {
    final store = ExpenseStoreScope.read(context);
    final isEdit = existing != null;
    final result = await showModalBottomSheet<PlannerItem>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpsertPlannerItemSheet(
        existing: existing,
        defaultStartDate: store.selectedMonth,
      ),
    );

    if (!context.mounted || result == null) return;
    store.upsertPlannerItem(result);
    
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isEdit ? 'Updated: ${result.label}' : 'Created: ${result.label}'),
          action: SnackBarAction(
            label: 'Undo',
            onPressed: () {
              if (isEdit) {
                // Restore the original item
                store.upsertPlannerItem(existing);
              } else {
                // Delete the newly created item
                store.deletePlannerItem(result.id);
              }
            },
          ),
        ),
      );
    }
  }

  Future<void> _showAddMenu(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final terminology = Terminology.of(context);
    
    // Capture the outer context for use after the menu is dismissed
    final outerContext = context;
    
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.calendar_month_outlined),
              title: Text(terminology.itemStatusLabel == 'Archived' ? 'Add Scheduled Item' : 'Add Item'),
              subtitle: const Text('Bills, income, or savings targets'),
              onTap: () {
                Navigator.pop(sheetContext);
                // Use outer context which remains valid after sheet is dismissed
                _showUpsertPlannerItemSheet(outerContext);
              },
            ),
            ListTile(
              leading: const Icon(Icons.receipt_long_outlined),
              title: const Text('Log Transaction'),
              subtitle: const Text('Quickly record an expense or income'),
              onTap: () {
                Navigator.pop(sheetContext);
                // Use outer context which remains valid after sheet is dismissed
                _showQuickTransactionSheet(outerContext);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _showQuickTransactionSheet(BuildContext context) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    
    final result = await showModalBottomSheet<PaymentEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => const QuickTransactionSheet(),
    );

    if (!context.mounted || result == null) return;
    
    // Save the payment
    store.upsertPayment(result);
    // Update balance
    settings.currentBalanceCents += result.amountMinorUnits;
    
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Transaction logged: ${result.label}'),
          action: SnackBarAction(
            label: 'Undo',
            onPressed: () {
              store.deletePayment(result.id);
              settings.currentBalanceCents -= result.amountMinorUnits;
            },
          ),
        ),
      );
    }
  }

  Future<void> _showUpdatePaymentSheetStandalone(BuildContext context, PaymentEntry payment) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final oldAmount = payment.amountMinorUnits;

    final result = await showModalBottomSheet<PaymentEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpdatePaymentSheet(
        payment: payment,
        title: 'Edit Transaction',
      ),
    );

    if (!context.mounted || result == null) return;

    store.upsertPayment(result);
    settings.currentBalanceCents = settings.currentBalanceCents - oldAmount + result.amountMinorUnits;
  }

  Future<void> _showStandalonePaymentActions(BuildContext context, PaymentEntry payment) async {
    final localizations = AppLocalizations.of(context)!;
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    final action = await showModalBottomSheet<_StandalonePaymentAction>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: Text(localizations.edit),
              onTap: () => Navigator.pop(context, _StandalonePaymentAction.edit),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: Text(localizations.delete),
              onTap: () => Navigator.pop(context, _StandalonePaymentAction.delete),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );

    if (!context.mounted || action == null) return;

    if (action == _StandalonePaymentAction.edit) {
      _showUpdatePaymentSheetStandalone(context, payment);
    } else if (action == _StandalonePaymentAction.delete) {
      final confirmed = await _confirmDeleteStandalone(context, payment);
      if (confirmed && context.mounted) {
        store.deletePayment(payment.id);
        settings.currentBalanceCents -= payment.amountMinorUnits;
      }
    }
  }

  Future<bool> _confirmDeleteStandalone(BuildContext context, PaymentEntry payment) async {
    final localizations = AppLocalizations.of(context)!;
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(localizations.delete),
            content: Text('Are you sure you want to delete this transaction: ${payment.label}?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(localizations.cancel),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.error,
                ),
                child: Text(localizations.delete),
              ),
            ],
          ),
        ) ??
        false;
  }
}

enum _StandalonePaymentAction { edit, delete }

/// Calculates the next due date for a recurring payment.
///
/// Takes into account:
/// - Whether the payment is already cleared for the current month
/// - One-off payments that have ended
/// - The actual day of month (adjusted for short months)
DateTime? _nextDueDate({
  required PlannerItem item,
  required List<PaymentEntry> payments,
  required AppSettingsStore settings,
}) {
  final now = DateTime.now();
  final today = DateTime.utc(now.year, now.month, now.day);
  final currentMonth = DateTime.utc(now.year, now.month, 1);

  // For one-off payments, they only appear in their start month
  if (item.type == PaymentType.oneOff || item.type == PaymentType.oneOffIncome) {
    final startMonth = DateTime.utc(item.startDate.year, item.startDate.month, 1);
    // If start month is before current month, no next due date
    if (startMonth.isBefore(currentMonth)) return null;
  }

  // Start from current month
  var checkMonth = currentMonth;

  // Check up to 13 months ahead (to handle edge cases)
  for (var i = 0; i < 13; i++) {
    // Check if item should appear in this month
    if (!item.shouldAppearInMonth(checkMonth)) {
      checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);
      continue;
    }

    // Calculate the effective day for this month
    final maxDay = DateUtils.getDaysInMonth(checkMonth.year, checkMonth.month);
    final effectiveDay = item.dayOfMonth <= maxDay ? item.dayOfMonth : maxDay;
    final dueDate = DateTime.utc(checkMonth.year, checkMonth.month, effectiveDay);

    // Check if this occurrence is cleared
    final isCleared = _isItemClearedForMonth(
      item: item,
      month: checkMonth,
      payments: payments,
      settings: settings,
    );

    // If not cleared and due date is today or in the future, this is the next due date
    if (!isCleared && !dueDate.isBefore(today)) {
      return dueDate;
    }

    // If not cleared but due date is in the past (overdue), still show it
    if (!isCleared && checkMonth.year == now.year && checkMonth.month == now.month) {
      return dueDate;
    }

    // Move to next month
    checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);
  }

  return null;
}

bool _isItemClearedForMonth({
  required PlannerItem item,
  required DateTime month,
  required List<PaymentEntry> payments,
  required AppSettingsStore settings,
}) {
  for (final payment in payments) {
    if (paymentMatchesPlannerItem(payment, item, month, settings)) {
      return true;
    }
  }
  return false;
}

String _formatDueDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

enum _PlannerItemAction { archive, delete }

DismissDirection? _paymentDismissDirection({
  required PaymentSwipeAction left,
  required PaymentSwipeAction right,
}) {
  final leftEnabled = left != PaymentSwipeAction.off;
  final rightEnabled = right != PaymentSwipeAction.off;
  if (leftEnabled && rightEnabled) return DismissDirection.horizontal;
  if (leftEnabled) return DismissDirection.endToStart;
  if (rightEnabled) return DismissDirection.startToEnd;
  return null;
}

Widget _resumeDismissBackground(
  BuildContext context, {
  required bool alignLeft,
}) {
  final bg = Theme.of(context).colorScheme.primaryContainer;
  final fg = Theme.of(context).colorScheme.onPrimaryContainer;
  const icon = Icons.play_arrow_outlined;
  final label = Terminology.of(context).unmarkActionLabel;

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Widget _paymentDismissBackground(
  BuildContext context, {
  required PaymentSwipeAction action,
  required bool alignLeft,
}) {
  final (bg, fg, label, icon) = switch (action) {
    PaymentSwipeAction.off => (
        Theme.of(context).colorScheme.surface,
        Theme.of(context).colorScheme.onSurface,
        '',
        Icons.block,
      ),
        PaymentSwipeAction.edit => (
        Theme.of(context).colorScheme.primaryContainer,
        Theme.of(context).colorScheme.onPrimaryContainer,
        AppLocalizations.of(context)!.edit,
        Icons.edit_outlined,
      ),
    PaymentSwipeAction.delete => (
        Theme.of(context).colorScheme.errorContainer,
        Theme.of(context).colorScheme.onErrorContainer,
        AppLocalizations.of(context)!.delete,
        Icons.delete_outline,
      ),
  };

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Future<bool> _handlePaymentSwipeAction(
  BuildContext context,
  PlannerItem item,
  PaymentSwipeAction action,
) async {
  final store = ExpenseStoreScope.read(context);

  // If item is ended, any swipe action resumes it
  if (item.archived) {
    store.setPlannerItemArchived(item.id, false);
    if (context.mounted) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.paymentResumed(item.label)),
          duration: AppConstants.snackBarShort,
          action: SnackBarAction(
            label: AppLocalizations.of(context)!.undo,
            onPressed: () => store.setPlannerItemArchived(item.id, true),
          ),
        ),
      );
    }
    return false;
  }

  // Normal behavior for non-archived items
  switch (action) {
    case PaymentSwipeAction.off:
      return false;
    case PaymentSwipeAction.edit:
      final result = await showModalBottomSheet<PlannerItem>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpsertPlannerItemSheet(
          existing: item,
          defaultStartDate: store.selectedMonth,
        ),
      );
      if (result != null) store.upsertPlannerItem(result);
      return false;
    case PaymentSwipeAction.delete:
      final confirmed = await _confirmDelete(context, item);
      if (confirmed) {
        store.deletePlannerItem(item.id);
      }
      return false;
  }
}

Future<bool> _confirmDelete(BuildContext context, PlannerItem item) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (context) {
      final theme = Theme.of(context);
      final scheme = theme.colorScheme;
      final l10n = AppLocalizations.of(context)!;
      final terminology = Terminology.of(context);

      return Dialog(
        insetPadding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingLarge - 4, // 20
          vertical: AppConstants.paddingLarge,
        ),
        backgroundColor: scheme.surfaceContainerHighest,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusDialog),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: AppConstants.dialogIconSize,
                    height: AppConstants.dialogIconSize,
                    decoration: BoxDecoration(
                      color: scheme.errorContainer,
                      borderRadius: BorderRadius.circular(AppConstants.radiusIconBox),
                    ),
                    child: Icon(Icons.delete_outline, color: scheme.onErrorContainer),
                  ),
                  const SizedBox(width: AppConstants.paddingNormal),
                  Expanded(
                    child: Text(
                      terminology.deleteTitle,
                      style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                l10n.deletePaymentConfirm(item.label),
                style: theme.textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: scheme.onSurface,
                        side: BorderSide(color: scheme.outlineVariant),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(l10n.cancel),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: FilledButton.styleFrom(
                        backgroundColor: scheme.error,
                        foregroundColor: scheme.onError,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text(l10n.delete),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
  return confirmed ?? false;
}

String _formatDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}
