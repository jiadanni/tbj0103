/**
 * Atlassian Configuration Module
 * Centralized configuration for JIRA and Confluence integration
 * 
 * @module api/atlassian/shared/atlassian-config
 */

/**
 * JIRA label mappings for common technical terms
 * Maps search terms to their variations in JIRA labels
 */
export const JIRA_LABEL_MAPPINGS = {
  // Technical terms
  'api': ['api', 'API', 'rest-api', 'api-issue'],
  'lti': ['lti', 'LTI', 'lti-tool', 'learning-tools'],
  'sso': ['sso', 'SSO', 'single-sign-on', 'authentication'],
  'oauth': ['oauth', 'OAuth', 'oauth2', 'authentication'],
  'saml': ['saml', 'SAML', 'saml2', 'authentication'],

  // Product areas
  'payment': ['payment', 'payments', 'billing', 'financial'],
  'grade': ['grade', 'grades', 'gradebook', 'grading'],
  'assignment': ['assignment', 'assignments', 'coursework'],
  'course': ['course', 'courses', 'curriculum'],
  'user': ['user', 'users', 'account', 'profile'],

  // Issue types
  'error': ['error', 'errors', 'bug', 'issue'],
  'crash': ['crash', 'crashes', 'failure', 'down'],
  'timeout': ['timeout', 'timeouts', 'slow', 'performance'],
  'login': ['login', 'signin', 'auth', 'access'],

  // Technical components
  'database': ['database', 'db', 'sql', 'data'],
  'server': ['server', 'backend', 'api', 'service'],
  'client': ['client', 'frontend', 'ui', 'browser'],
  'sync': ['sync', 'synchronization', 'integration', 'import'],
};

/**
 * Product Family to JIRA Project Key mappings
 */
export const JIRA_PROJECT_MAPPINGS = {
  'canvas': 'CNVS',
  'mastery': 'MCE',
  'credentials': 'MCE',
  'impact': 'IMP',
  'elevate': 'EAX',
  'learn platform': 'LRN',
};

/**
 * Product Family to Confluence Space mappings
 */
export const CONFLUENCE_SPACE_MAPPINGS = {
  'canvas': ['CANVAS3'],             // Canvas searches across all spaces (no specific restriction)
  'mastery': ['AS', 'MASTERY'],        // Mastery Connect -> AS space (try common alternatives)
  'mastery connect': ['AS', 'MASTERY'], // Alternative naming
  'credentials': ['AS', 'MASTERY'],    // Credentials also part of Mastery -> AS space
  'impact': ['IS', 'IP'],         // Impact -> IS space (try common alternatives)
  'elevate': ['COMP'],            // Elevate searches across all spaces (no dedicated space)
  'learn platform': ['CS', 'LEARNPLATFORM', 'LP', 'LPE'], // LearnPlatform -> CS space (try common alternatives)
  'learnplatform': ['CS', 'LEARNPLATFORM', 'LP', 'LPE'],  // Alternative naming
};

/**
 * Component-specific Confluence space mappings
 */
export const CONFLUENCE_COMPONENT_MAPPINGS = {
  'mastery': ['AS'],
  'credential': ['AS'],
  'impact': ['IS'],
  'learn': ['CS'],
  'platform': ['CS'],
};

/**
 * Generate label variations for JIRA label matching
 * @param {string} term - Search term
 * @returns {string[]} Array of label variations
 */
export function generateLabelVariations(term) {
  const variations = new Set();
  const lowerTerm = term.toLowerCase();

  // Add the original term
  variations.add(term);
  variations.add(lowerTerm);

  // Add mapped variations
  if (JIRA_LABEL_MAPPINGS[lowerTerm]) {
    JIRA_LABEL_MAPPINGS[lowerTerm].forEach(variation => variations.add(variation));
  }

  // Add common formatting variations
  variations.add(lowerTerm.replace(/\s+/g, '-')); // Space to hyphen: "api error" -> "api-error"
  variations.add(lowerTerm.replace(/\s+/g, '_')); // Space to underscore: "api error" -> "api_error"

  return Array.from(variations);
}

/**
 * Map Salesforce Product Family to JIRA Project Key
 * @param {string} productFamily - Product family name
 * @param {string} fallbackProjectKey - Fallback project key if no mapping found
 * @returns {Promise<string|null>} JIRA project key
 */
export async function getJiraProjectFromProductFamily(productFamily, fallbackProjectKey = null) {
  if (!productFamily) {
    return fallbackProjectKey;
  }

  const productLower = productFamily.toLowerCase();

  // Try to load overrides from storage
  try {
    const { jiraProjectMappingsOverride } = await chrome.storage.local.get('jiraProjectMappingsOverride');
    const mappings = { ...JIRA_PROJECT_MAPPINGS, ...jiraProjectMappingsOverride };

    // Check for exact matches
    if (mappings[productLower]) {
      return mappings[productLower];
    }

    // Check for partial matches
    for (const [product, projectId] of Object.entries(mappings)) {
      if (productLower.includes(product) || product.includes(productLower)) {
        return projectId;
      }
    }
  } catch (err) {
    console.warn('Failed to load JIRA project mapping overrides', err);
  }

  return fallbackProjectKey;
}

/**
 * Map product family to appropriate Confluence spaces
 * @param {string} productFamily - Product family name
 * @param {string} productComponent - Product component name (optional)
 * @returns {Promise<string[]>} Array of Confluence space IDs
 */
export async function getConfluenceSpacesFromProductFamily(productFamily, productComponent = null) {
  if (!productFamily) {
    return [];
  }

  const productLower = productFamily.toLowerCase();

  // Try to load overrides from storage
  try {
    const { confluenceSpaceMappingsOverride, confluenceComponentMappingsOverride } =
      await chrome.storage.local.get(['confluenceSpaceMappingsOverride', 'confluenceComponentMappingsOverride']);

    const spaceMappings = { ...CONFLUENCE_SPACE_MAPPINGS, ...confluenceSpaceMappingsOverride };
    const componentMappings = { ...CONFLUENCE_COMPONENT_MAPPINGS, ...confluenceComponentMappingsOverride };

    // Check for exact matches first
    if (spaceMappings[productLower]) {
      return spaceMappings[productLower];
    }

    // Check for partial matches
    for (const [product, spaceIds] of Object.entries(spaceMappings)) {
      if (productLower.includes(product) || product.includes(productLower)) {
        return spaceIds;
      }
    }

    // If we have a product component, try to map that as well
    if (productComponent) {
      const componentLower = productComponent.toLowerCase();

      for (const [component, spaceIds] of Object.entries(componentMappings)) {
        if (componentLower.includes(component)) {
          return spaceIds;
        }
      }
    }
  } catch (err) {
    console.warn('Failed to load Confluence space mapping overrides', err);
  }

  return []; // Return empty array to search all spaces
}
