/**
 * Atlassian Service Module
 * Orchestrates JIRA and Confluence API interactions
 */

import { ErrorMessages } from '../utils/user-notifications.js';
import { handleError, ErrorStrategy } from '../utils/error-handler.js';
import { rateLimiters } from '../utils/rate-limiter.js';
import { orchestratedSearch } from '../utils/search-orchestrator.js';
import { addFallbackJiraExplanations, addFallbackConfluenceExplanations } from './atlassian/shared/atlassian-explanations.js';
import { getJiraTicketsTraditional, getJiraTicketsWithAI } from './atlassian/jira/jira-client.js';
import { getConfluencePagesTraditional, getConfluencePagesWithAI } from './atlassian/confluence/confluence-client.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';
import { ATLASSIAN_TIMEOUT_MS } from '../config/constants.js';
import { validateAtlassianUrl } from '../../security-utils.js';

const logger = createLogger('AtlassianService');

async function fetchWithTimeout(url, options = {}, timeout = ATLASSIAN_TIMEOUT_MS) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const resp = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return resp;
  } catch (err) {
    clearTimeout(id);
    if (err.name === 'AbortError') {
      logger.debug('Atlassian request timed out', 'fetchWithTimeout', err);
      const abortErr = new Error('Request timed out');
      abortErr.name = 'AbortError';
      throw abortErr;
    }
    logger.warn('Atlassian fetch failed', 'fetchWithTimeout', err);
    throw err;
  }
}

/**
 * Test connection to Atlassian (JIRA/Confluence)
 */
export async function testAtlassianConnection(atlassianToken, atlassianBaseUrl, atlassianEmail) {
  if (!atlassianToken) {
    const error = new Error('Atlassian token is required');
    error.details = { timestamp: new Date().toISOString() };
    return Result.failure(error);
  }

  if (!atlassianBaseUrl) {
    const error = new Error('Atlassian base URL is required');
    error.details = { timestamp: new Date().toISOString() };
    return Result.failure(error);
  }

  if (!atlassianEmail) {
    const error = new Error('Atlassian email is required for Basic Authentication');
    error.details = { timestamp: new Date().toISOString() };
    return Result.failure(error);
  }

  // URL should already be normalized from settings, but validate for safety
  const baseUrlValidation = validateAtlassianUrl(atlassianBaseUrl);
  if (!baseUrlValidation.valid) {
    const error = new Error(baseUrlValidation.error || 'Invalid Atlassian URL');
    error.details = { timestamp: new Date().toISOString() };
    return Result.failure(error);
  }
  const normalizedBaseUrl = baseUrlValidation.normalized;
  const testUrl = `${normalizedBaseUrl}/rest/api/3/myself`;
  let lastError = null;

  const authMethod = { type: 'Basic', header: `Basic ${btoa(`${atlassianEmail}:${atlassianToken}`)}`, description: 'Basic auth (API token as password)' };

  try {
    const startTime = performance.now();
    const response = await rateLimiters.atlassian.executeWithBackoff(
      async () => {
        return await fetchWithTimeout(testUrl, {
          method: 'GET',
          headers: {
            'Authorization': authMethod.header,
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        }, ATLASSIAN_TIMEOUT_MS);
      },
      `atlassian-test-${atlassianBaseUrl}-${authMethod.type}`
    );

    if (response.ok) {
      const responseTime = Math.round(performance.now() - startTime);
      const userData = await response.json();

      return Result.success({
        user: userData.displayName || userData.name || 'Unknown User',
        email: userData.emailAddress || 'Not available',
        status: 'Connected',
        authMethod: authMethod.type,
        responseTime: `${responseTime}ms`,
        instance: atlassianBaseUrl,
        timestamp: new Date().toISOString()
      });
    } else {
      lastError = new Error(`HTTP ${response.status}: ${response.statusText} (${authMethod.type} auth)`);
      lastError.status = response.status;
    }
  } catch (error) {
    logger.warn('Atlassian connection attempt failed', 'testAtlassianConnection', error);
    lastError = error;
  }

  if (lastError) {
    if (lastError.status === 401 || lastError.status === 403) {
      handleError(lastError, {
        strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
        context: 'Atlassian Connection Test',
        operation: 'testAtlassianConnection',
        userMessage: ErrorMessages.API_AUTH_FAILED
      });
    } else if (lastError.name !== 'AbortError') {
      handleError(lastError, {
        strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
        context: 'Atlassian Connection Test',
        operation: 'testAtlassianConnection'
      });
    }
  }

  return Result.failure(
    lastError || new Error('Failed to connect to Atlassian')
  );
}

/**
 * Search for related Jira tickets using direct JIRA REST API
 * Orchestrates between AI-enhanced and traditional search
 */
export async function getJiraTickets(caseId, caseData = {}, isManualFetch = false) {
  return orchestratedSearch({
    serviceName: 'JIRA',
    settingKey: 'jira',
    aiSearchFn: () => getJiraTicketsWithAI(caseId, caseData, isManualFetch),
    traditionalSearchFn: () => getJiraTicketsTraditional(caseId, caseData, isManualFetch),
    fallbackEnhancer: addFallbackJiraExplanations,
    caseData,
    isManualFetch
  });
}

/**
 * Get Confluence pages related to case
 * Orchestrates between AI-enhanced and traditional search
 */
export async function getConfluencePages(caseData = {}, isManualFetch = false) {
  return orchestratedSearch({
    serviceName: 'Confluence',
    settingKey: 'confluence',
    aiSearchFn: () => getConfluencePagesWithAI(caseData, isManualFetch),
    traditionalSearchFn: () => getConfluencePagesTraditional(caseData, isManualFetch),
    fallbackEnhancer: addFallbackConfluenceExplanations,
    caseData,
    isManualFetch
  });
}
