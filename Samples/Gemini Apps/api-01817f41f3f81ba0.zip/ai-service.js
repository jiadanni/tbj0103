/**
 * AI Service Module
 * Handles all AI API operations including authentication, requests, and AI-powered features
 *
 * @module ai-service
 */

import { getApiEndpoint, ensureHostPermissionForUrl } from '../../security-utils.js';
import { CACHE_TTL, responseCache, setCache, scheduleCachePersist } from '../cache/cache-manager.js';
import { generateEmailSignature } from '../utils/email-helpers.js';
import { rateLimiters } from '../utils/rate-limiter.js';
import { showInfo, ErrorMessages } from '../utils/user-notifications.js';
import { handleError, ErrorStrategy } from '../utils/error-handler.js';
import { buildSolutionPrompt, buildImprovementPrompt, buildSpellCheckPrompt } from './prompts/prompt-templates.js';
import { getAiParameters, buildPromptMutation, buildMutationVariables } from './prompts/prompt-builders.js';
import {
  AI_REQUEST_TIMEOUT_MS,
  MAX_API_RETRIES,
  AUTH_FAILURE_THRESHOLD as AUTH_THRESHOLD,
  AUTH_FAILURE_WINDOW_MS as AUTH_WINDOW_MS
} from '../config/constants.js';
import { decrypt } from '../security/crypto-utils.js';
import { createLogger } from '../utils/logger.js';
import { Result } from '../utils/result.js';

// Import synchronization
import { Mutex } from '../utils/synchronization.js';

const logger = createLogger('AiService');
const authStateMutex = new Mutex();

// Token cache to avoid repeated decryption (cleared on token change)
let cachedToken = null;
let cachedTokenEncrypted = null;

/**
 * Generate a simple hash of a token for tracking purposes (not cryptographically secure)
 * @param {string} token - Token to hash
 * @returns {Promise<string>} Hash of the token
 */
async function hashToken(token) {
  if (!token) return '';
  const encoder = new TextEncoder();
  const data = encoder.encode(token);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
}

/**
 * Get the currently active AI model from settings
 * @returns {Promise<string>} Active AI model ID
 */
export async function getActiveAiModel() {
  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');

  if (!advancedAiSettings?.models) {
    throw new Error('No AI models configured. Please configure at least one model in the extension settings.');
  }

  const activeModelNum = advancedAiSettings.activeModel || 1;
  const modelKey = `model${activeModelNum}`;
  const activeModel = advancedAiSettings.models[modelKey];

  if (!activeModel || !activeModel.trim()) {
    throw new Error(`Active model (${modelKey}) is not configured. Please set up your AI model in the extension settings.`);
  }

  return activeModel.trim();
}

const REQUEST_TIMEOUT = AI_REQUEST_TIMEOUT_MS;
const MAX_RETRIES = MAX_API_RETRIES;
const AUTH_FAILURE_THRESHOLD = AUTH_THRESHOLD;
const AUTH_FAILURE_WINDOW_MS = AUTH_WINDOW_MS;
const AUTH_STATE_STORAGE_KEY = 'aiAuthFailureState';

// ============================================================================
// Auth Failure Tracking (Thread-Safe with Mutex)
// ============================================================================
// Design: Single atomic operations (incrementAuthFailure, resetAuthFailure) 
// that acquire the mutex and handle complete read-modify-write cycles.
// This prevents any possibility of race conditions.

/**
 * Increment auth failure count for a token atomically
 * Handles the complete read-check-increment-write cycle inside a single lock
 * @param {string} token - The token that failed
 * @returns {Promise<Object>} Updated failure state with count, timestamps, and shouldInvalidate flag
 */
async function incrementAuthFailure(token) {
  if (!token) {
    return { count: 0, shouldInvalidate: false, state: null };
  }

  return await authStateMutex.runExclusive(async () => {
    try {
      // Hash token INSIDE mutex to ensure atomicity
      const tokenHash = await hashToken(token);
      const failureKey = `aiTokenFailures_${tokenHash}`;
      const now = Date.now();

      // Read current state
      const stored = await chrome.storage.local.get(failureKey);
      const state = stored[failureKey] || { count: 0, firstFailureTime: null, lastFailureTime: null };

      // Check if window has expired (reset if older than window)
      if (state.firstFailureTime && (now - state.firstFailureTime) > AUTH_FAILURE_WINDOW_MS) {
        const resetState = { count: 0, firstFailureTime: null, lastFailureTime: null };
        await chrome.storage.local.set({ [failureKey]: resetState });
        return { count: 0, shouldInvalidate: false, state: resetState };
      }

      // Increment
      const updatedState = {
        firstFailureTime: state.count === 0 ? now : state.firstFailureTime,
        lastFailureTime: now,
        count: state.count + 1
      };

      // Write back
      await chrome.storage.local.set({ [failureKey]: updatedState });

      // Log and check if threshold exceeded
      logger.warn(`Auth failure ${updatedState.count}/${AUTH_FAILURE_THRESHOLD} for token hash ${tokenHash}`, 'ai-service', {
        count: updatedState.count
      });

      const shouldInvalidate = updatedState.count >= AUTH_FAILURE_THRESHOLD;

      return { count: updatedState.count, shouldInvalidate, state: updatedState };
    } catch (error) {
      logger.warn('Failed to increment auth failure state', 'ai-service', error);
      return { count: 0, shouldInvalidate: false, state: null };
    }
  });
}

/**
 * Track authentication failure and determine if token should be invalidated
 * Uses incrementAuthFailure for atomic read-modify-write of failure state
 * @param {Error} error - The authentication error
 * @param {string} failedToken - The token that failed authentication
 * @returns {Promise<boolean>} True if token should be invalidated
 */
async function shouldInvalidateToken(error, failedToken) {
  if (!failedToken) return false;

  // Use authStateMutex to ensure atomic check-increment-validate cycle
  return await authStateMutex.runExclusive(async () => {
    try {
      // Verify the token hasn't been rotated since the error
      const currentData = await chrome.storage.local.get('aiServiceToken');
      const currentTokenEncrypted = currentData?.aiServiceToken;

      if (!currentTokenEncrypted) return false;

      // Use cache if available for same encrypted token
      let currentToken = null;
      if (cachedTokenEncrypted === currentTokenEncrypted && cachedToken) {
        currentToken = cachedToken;
      } else {
        try {
          currentToken = await decrypt(currentTokenEncrypted);
          // Update cache
          cachedTokenEncrypted = currentTokenEncrypted;
          cachedToken = currentToken;
        } catch (decryptError) {
          logger.warn('Failed to decrypt stored AI token for auth tracking', 'ai-service', decryptError);
          return false;
        }
      }

      if (!currentToken || currentToken !== failedToken) {
        return false;
      }

      // Hash token inside this atomic operation
      const tokenHash = await hashToken(failedToken);
      const failureKey = `aiTokenFailures_${tokenHash}`;
      const now = Date.now();

      // Read current failure state
      const stored = await chrome.storage.local.get(failureKey);
      const state = stored[failureKey] || { count: 0, firstFailureTime: null, lastFailureTime: null };

      // Check if window has expired
      if (state.firstFailureTime && (now - state.firstFailureTime) > AUTH_FAILURE_WINDOW_MS) {
        return false;
      }

      // Increment
      const updatedState = {
        firstFailureTime: state.count === 0 ? now : state.firstFailureTime,
        lastFailureTime: now,
        count: state.count + 1
      };

      // Write back
      await chrome.storage.local.set({ [failureKey]: updatedState });

      // Check if threshold exceeded
      if (updatedState.count >= AUTH_FAILURE_THRESHOLD) {
        logger.error('Token invalidated after repeated authentication failures', 'ai-service', {
          failureCount: updatedState.count,
          threshold: AUTH_FAILURE_THRESHOLD
        });
        return true;
      }

      logger.warn(`Auth failure ${updatedState.count}/${AUTH_FAILURE_THRESHOLD} for token`, 'ai-service');
      return false;
    } catch (error) {
      logger.warn('Failed to check token invalidation status', 'ai-service', error);
      return false;
    }
  });
}

/**
 * Reset auth failure tracking (call on successful auth)
 * Atomically clears the failure state for a token
 */
async function resetAuthFailure(token) {
  if (!token) return;

  return await authStateMutex.runExclusive(async () => {
    try {
      const tokenHash = await hashToken(token);
      const failureKey = `aiTokenFailures_${tokenHash}`;
      const stored = await chrome.storage.local.get(failureKey);
      const state = stored[failureKey];

      if (state && state.count > 0) {
        logger.info('Auth failure tracking reset after successful request', 'ai-service');
        await chrome.storage.local.remove(failureKey);
      }
    } catch (error) {
      logger.warn('Failed to reset auth failure tracking', 'ai-service', error);
    }
  });
}

/**
 * Check whether AI is enabled and a token is available
 * @returns {Promise<boolean>} True when AI can be used
 */
export async function hasValidAiServiceToken() {
  const { aiServiceToken, aiEnabled } = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
  const enabled = typeof aiEnabled === 'undefined' ? true : !!aiEnabled;
  return !!aiServiceToken && enabled;
}

/**
 * Get AI service authentication token from storage
 * @returns {Promise<string>} AI service token (decrypted)
 * @throws {Error} If token is not found or AI is disabled
 */
export async function getAuthToken() {
  try {
    const data = await chrome.storage.local.get(['aiServiceToken', 'aiEnabled']);
    const enabled = typeof data.aiEnabled === 'undefined' ? true : !!data.aiEnabled;
    if (!enabled) {
      throw new Error('AI disabled by user');
    }
    if (!data || !data.aiServiceToken) {
      throw new Error('No AI Service API token found');
    }
    
    // Use cached token if encrypted value hasn't changed
    if (cachedTokenEncrypted === data.aiServiceToken && cachedToken) {
      return cachedToken;
    }
    
    try {
      const token = await decrypt(data.aiServiceToken);
      // Update cache
      cachedTokenEncrypted = data.aiServiceToken;
      cachedToken = token;
      return token;
    } catch (decryptError) {
      const shouldReconfigure = decryptError.code === 'DECRYPT_FAILED' || decryptError.code === 'SESSION_KEY_MISMATCH';
      if (shouldReconfigure) {
        logger.error('Token decryption failed; user should reconfigure', 'ai-service', decryptError);
        throw new Error('Failed to decrypt AI Service API token. Please reconfigure your token in settings.');
      }
      throw decryptError;
    }
  } catch (error) {
    logger.error('Error retrieving AI Service API token:', 'ai-service', error);
    if (error.message.includes('decrypt')) {
      throw error; // Preserve specific decryption error message
    }
    throw new Error('Failed to retrieve AI Service API token. Please check your settings.');
  }
}

/**
 * Fetch with timeout and automatic retry
 * @param {string} url - URL to fetch
 * @param {Object} options - Fetch options
 * @param {number} retries - Number of retries remaining
 * @param {number} timeout - Timeout in milliseconds
 * @param {AbortSignal} externalSignal - External abort signal for cancellation
 * @returns {Promise<Response>} Fetch response
 */
async function fetchWithTimeoutAndRetry(url, options, retries = MAX_RETRIES, timeout = REQUEST_TIMEOUT, externalSignal = null) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  if (externalSignal) {
    if (externalSignal.aborted) {
      clearTimeout(id);
      throw new DOMException('Request cancelled by user', 'AbortError');
    }
    externalSignal.addEventListener('abort', () => {
      clearTimeout(id);
      controller.abort();
    }, { once: true });
  }

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    logger.debug('AI service request error', 'ai-service', error);
    clearTimeout(id);
    if (error.name === 'AbortError') {
      throw new DOMException('Request timed out. Please check your internet connection.', 'AbortError');
    }
    if (retries > 0) {
      logger.info(`Retrying request... (${retries} attempts left)`, 'contextual', { error: error.message });
      return fetchWithTimeoutAndRetry(url, options, retries - 1, timeout, externalSignal);
    }
    logger.error('AI service request failed after retries', 'fetchWithTimeoutAndRetry', error);
    throw error;
  }
}

/**
 * Extract operation name from GraphQL query
 * @param {string} query - GraphQL query/mutation
 * @returns {string} Operation name
 */
function getOperationName(query) {
  const match = query.match(/(query|mutation)\s+(\w+)/);
  return match ? match[2] : 'AnonymousOperation';
}

/**
 * Make a GraphQL API request to AI service
 * @param {string} query - GraphQL query or mutation
 * @param {Object} variables - Query variables
 * @param {string|null} token - Optional token (uses stored token if not provided)
 * @param {AbortSignal} signal - Optional abort signal for request cancellation
 * @returns {Promise<Result>} Standardized Result object containing API response data on success
 */
export async function makeApiRequest(query, variables = {}, token = null, signal = null) {
  let authToken;
  try {
    authToken = token || await getAuthToken();
  } catch (error) {
    return Result.failure(error);
  }

  const apiEndpoint = await getApiEndpoint();
  await ensureHostPermissionForUrl(apiEndpoint, false);
  const cacheKey = JSON.stringify({ query, variables });
  const now = Date.now();

  const cached = responseCache.get(cacheKey);
  if (cached && (now - cached.timestamp) < CACHE_TTL) {
    return Result.success(cached.data);
  }

  try {
    const response = await rateLimiters.ai.executeWithBackoff(
      async () => {
        return await fetchWithTimeoutAndRetry(apiEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': authToken,
            'X-Request-Source': 'salesforce-extension',
            'X-Request-ID': crypto.randomUUID()
          },
          body: JSON.stringify({
            query,
            variables,
            operationName: getOperationName(query)
          })
        }, MAX_RETRIES, REQUEST_TIMEOUT, signal);
      },
      'ai-service',
      signal
    );

    if (!response.ok) {
      const errorText = await response.text();
      const error = new Error(`API request failed: ${errorText}`);
      error.status = response.status;
      error.endpoint = apiEndpoint;
      throw error;
    }

    const data = await response.json();

    if (data.errors) {
      const errorMessages = data.errors.map(err => err.message).join('; ');
      const error = new Error(`GraphQL Error: ${errorMessages}`);
      error.status = response.status;
      throw error;
    }

    await setCache(cacheKey, data);

    resetAuthFailure(authToken).catch(err => {
      logger.warn('Failed to reset auth failure tracking', 'ai-service', err);
    });

    scheduleCachePersist();

    return Result.success(data);
  } catch (error) {
    logger.error('API Request Error:', 'contextual', {
      error: error.message,
      query: getOperationName(query),
      timestamp: new Date().toISOString()
    });

    const isAuthError = error.status === 401 || error.status === 403 ||
      error.message.includes('401') || error.message.includes('403');

    if (isAuthError) {
      const shouldInvalidate = await shouldInvalidateToken(error, authToken);
      if (shouldInvalidate) {
        logger.error('Token invalidated after repeated authentication failures', 'ai-service');
        responseCache.clear();
        // Clear token cache
        cachedToken = null;
        cachedTokenEncrypted = null;
        await chrome.storage.local.remove('aiServiceToken');

        handleError(error, {
          strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
          context: 'AI Service',
          operation: 'makeApiRequest:auth',
          userMessage: ErrorMessages.API_AUTH_FAILED
        });

        return Result.failure(new Error('Authentication failed repeatedly. Your AI Service API token has been cleared. Please update it in the extension settings.'));
      } else {
        handleError(error, {
          strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
          context: 'AI Service',
          operation: 'makeApiRequest:auth',
          userMessage: 'Authentication error. If this persists, please check your API token in settings.'
        });

        return Result.failure(new Error('Authentication failed. Please verify your AI Service API token is correct.'));
      }
    }

    if (error.name !== 'AbortError') {
      handleError(error, {
        strategy: ErrorStrategy.NOTIFY_AND_RETURN_NULL,
        context: 'AI Service',
        operation: `makeApiRequest:${getOperationName(query)}`
      });
    }

    return Result.failure(error);
  }
}

/**
 * Test AI service connection.
 * Used during setup and troubleshooting to verify API endpoint and token validity.
 * 
 * @param {string|null} [token=null] - Optional token for testing
 * @param {string|null} [testModel=null] - Optional specific model to test (overrides active model)
 * @returns {Promise<Result>} Standardized Result object with success status and model info
 */
export async function testConnection(token, testModel = null) {
  const apiEndpoint = await getApiEndpoint();
  await ensureHostPermissionForUrl(apiEndpoint, true);

  const model = testModel || await getActiveAiModel();
  const testMutation =
    'mutation TestConnection($model: String!, $prompt: String!) {' +
    '  answerPrompt(input: {' +
    '    model: $model' +
    '    prompt: $prompt' +
    '    temperature: 0.1' +
    '  })' +
    '}';

  const variables = {
    model: model,
    prompt: "Please respond with 'Connection successful' to test the API connection."
  };

  try {
    const startTime = performance.now();
    const result = await makeApiRequest(testMutation, variables, token);

    if (!result.ok) {
      return result;
    }

    const responseTime = Math.round(performance.now() - startTime);
    const apiEndpoint = await getApiEndpoint();

    return Result.success({
      message: result.value.data.answerPrompt || 'Connection successful',
      responseTime: `${responseTime}ms`,
      serverTimestamp: new Date().toISOString(),
      endpoint: apiEndpoint,
      testedModel: model
    });
  } catch (error) {
    logger.error('AI service connection test failed', 'testConnection', error);
    return Result.failure(error);
  }
}

// Test-only exports
export const __testOnly__authTracking = {
  incrementAuthFailure,
  resetAuthFailure,
  shouldInvalidateToken
};

/**
 * Suggest a solution based on case data and context.
 * Analyzes case details and provided context (like search results) to synthesize a resolution.
 * 
 * @param {Object} [caseData={}] - Salesforce case information
 * @param {string} [context=""] - Additional context (e.g., related Jira/Confluence results)
 * @returns {Promise<Result>} Standardized Result object containing the suggested solution text on success
 */
export async function suggestSolution(caseData = {}, context = "") {
  if (!caseData || Object.keys(caseData).length === 0) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs[0];
      if (activeTab && activeTab.id) {
        const response = await chrome.tabs.sendMessage(activeTab.id, { action: 'extractCaseData' });
        if (response?.success && response.data) {
          caseData = response.data || {};
        }
      }
    } catch (e) {
      logger.warn('suggestSolution: extraction fallback failed', 'ai-service', e);
      try {
        showInfo('AI could not extract case details automatically; using default prompt. Results may be less specific.');
      } catch (notifyErr) {
        logger.warn('Failed to notify user about extraction failure', 'ai-service', notifyErr);
      }
    }
  }

  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('caseSummary', advancedAiSettings);

  const prompt = buildSolutionPrompt(caseData, context);

  const mutation = buildPromptMutation('SuggestSolution', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;
    return Result.success(response.value.data.answerPrompt);
  } catch (error) {
    logger.error('Error in suggestSolution:', 'ai-service', error);
    return Result.failure(error);
  }
}

/**
 * Improve an existing solution with AI.
 * Enhances clarity, tone, and technical accuracy while maintaining the core message.
 * 
 * @param {string} currentSolution - Current solution text to improve
 * @param {Object} [caseData={}] - Case information for signature and context
 * @returns {Promise<Result>} Standardized Result object containing the improved solution and signature on success
 */
export async function improveSolution(currentSolution, caseData = {}) {
  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('improvement', advancedAiSettings);

  const prompt = buildImprovementPrompt(currentSolution, caseData);

  const mutation = buildPromptMutation('ImproveSolution', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;

    const improvedText = response.value.data.answerPrompt;

    const signature = generateEmailSignature(caseData);
    return Result.success(improvedText + signature);
  } catch (error) {
    logger.error('Error in improveSolution:', 'ai-service', error);
    return Result.failure(error);
  }
}

/**
 * Spellcheck and grammar check text using AI.
 * Focuses on professional support communication standards.
 * 
 * @param {string} text - Text to check and correct
 * @param {Object} [caseData={}] - Case information for signature and domain context
 * @returns {Promise<Result>} Standardized Result object containing the corrected text and signature on success
 */
export async function spellcheckText(text, caseData = {}) {
  const prompt = buildSpellCheckPrompt(text, caseData);

  const { advancedAiSettings } = await chrome.storage.local.get('advancedAiSettings');
  const model = await getActiveAiModel();
  const parameters = getAiParameters('spellcheck', advancedAiSettings);

  const mutation = buildPromptMutation('SpellcheckText', true);
  const variables = buildMutationVariables(model, prompt, parameters, true);

  try {
    const response = await makeApiRequest(mutation, variables);
    if (!response.ok) return response;

    const correctedText = response.value.data.answerPrompt;

    const signature = generateEmailSignature(caseData);
    return Result.success(correctedText + signature);
  } catch (error) {
    logger.error('Error in spellcheckText:', 'ai-service', error);
    return Result.failure(error);
  }
}
