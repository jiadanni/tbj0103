import 'package:flutter/material.dart';
import 'features/prayer_tracking/prayer_stats_page.dart';
import 'features/notifications/notification_service.dart';
import 'features/widget/prayer_widget_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'features/settings/settings_page.dart';
import 'features/quran/quran_page.dart';
import 'features/qibla/qibla_page.dart';
import 'features/calendar/calendar_page.dart';
import 'features/hajj/hajj_page.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'generated/app_localizations.dart';
import 'features/common_words/common_words_page.dart';
import 'features/duas/duas_page.dart';
import 'features/home/home_page.dart';
import 'di/service_locator.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.dark);
final ValueNotifier<BottomNavVisibility> bottomNavVisibilityNotifier =
    ValueNotifier(const BottomNavVisibility());

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  setupLocator();

  // Initialize notification service
  await NotificationService().initialize();

  // Initialize widget service
  await PrayerWidgetService.initialize();

  final prefs = await SharedPreferences.getInstance();
  final useDark = prefs.getBool('useAmoledTheme') ?? true;
  themeNotifier.value = useDark ? ThemeMode.dark : ThemeMode.light;
  bottomNavVisibilityNotifier.value = BottomNavVisibility.fromPrefs(prefs);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) {
        final lightColorScheme =
            ColorScheme.fromSeed(seedColor: Colors.deepPurple);
        final darkColorScheme = ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        );

        return MaterialApp(
          onGenerateTitle: (context) => AppLocalizations.of(context)!.appTitle,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: AppLocalizations.supportedLocales,
          theme: ThemeData(
            // This is the theme of your application.
            //
            // TRY THIS: Try running your application with "flutter run". You'll see
            // the application has a purple toolbar. Then, without quitting the app,
            // try changing the seedColor in the colorScheme below to Colors.green
            // and then invoke "hot reload" (save your changes or press the "hot
            // reload" button in a Flutter-supported IDE, or press "r" if you used
            // the command line to start the app).
            //
            // Notice that the counter didn't reset back to zero; the application
            // state is not lost during the reload. To reset the state, use hot
            // restart instead.
            //
            // This works for code too, not just values: Most code changes can be
            // tested with just a hot reload.
            colorScheme: lightColorScheme,
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              backgroundColor: lightColorScheme.surface,
              selectedItemColor: lightColorScheme.primary,
              unselectedItemColor:
                  lightColorScheme.onSurface.withOpacity(0.7),
              selectedIconTheme: IconThemeData(color: lightColorScheme.primary),
              unselectedIconTheme: IconThemeData(
                color: lightColorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ),
          darkTheme: ThemeData.dark().copyWith(
            scaffoldBackgroundColor: Colors.black,
            colorScheme: darkColorScheme,
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              backgroundColor: darkColorScheme.surface,
              selectedItemColor: darkColorScheme.primary,
              unselectedItemColor:
                  darkColorScheme.onSurface.withOpacity(0.7),
              selectedIconTheme: IconThemeData(color: darkColorScheme.primary),
              unselectedIconTheme: IconThemeData(
                color: darkColorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ),
          themeMode: mode,
          home: const AppScaffold(),
        );
      },
    );
  }
}

class AppScaffold extends StatefulWidget {
  const AppScaffold({super.key});

  @override
  State<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<BottomNavVisibility>(
      valueListenable: bottomNavVisibilityNotifier,
      builder: (_, visibility, __) {
        final navItems = _buildNavItems(context, visibility);
        final currentIndex =
            _currentIndex >= navItems.length ? 0 : _currentIndex;

        return Scaffold(
          body: navItems[currentIndex].page,
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: currentIndex,
            items: navItems.map((e) => e.item).toList(),
            onTap: (index) {
              setState(() => _currentIndex = index);
            },
          ),
        );
      },
    );
  }

  List<_NavItem> _buildNavItems(
      BuildContext context, BottomNavVisibility visibility) {
    final items = <_NavItem>[
      _NavItem(
        page: const MyHomePage(title: 'Immutable5'),
        item: BottomNavigationBarItem(
          icon: const Icon(Icons.home),
          label: AppLocalizations.of(context)!.home,
        ),
      ),
    ];

    if (visibility.showTrack) {
      items.add(
        _NavItem(
          page: const PrayerStatsPage(),
          item: const BottomNavigationBarItem(
            icon: Icon(Icons.check_circle),
            label: 'Track',
          ),
        ),
      );
    }

    if (visibility.showQibla) {
      items.add(
        _NavItem(
          page: const QiblaPage(),
          item: const BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: 'Qibla',
          ),
        ),
      );
    }

    if (visibility.showCalendar) {
      items.add(
        _NavItem(
          page: const CalendarPage(),
          item: BottomNavigationBarItem(
            icon: const Icon(Icons.calendar_today),
            label: AppLocalizations.of(context)!.calendar,
          ),
        ),
      );
    }

    if (visibility.showHajj) {
      items.add(
        _NavItem(
          page: const HajjPage(),
          item: BottomNavigationBarItem(
            icon: const Icon(Icons.directions_walk),
            label: AppLocalizations.of(context)!.hajj,
          ),
        ),
      );
    }

    if (visibility.showCommonWords) {
      items.add(
        _NavItem(
          page: const CommonWordsPage(),
          item: BottomNavigationBarItem(
            icon: const Icon(Icons.translate),
            label: AppLocalizations.of(context)!.commonWords,
          ),
        ),
      );
    }

    if (visibility.showDuas) {
      items.add(
        _NavItem(
          page: const DuasPage(),
          item: const BottomNavigationBarItem(
            icon: Icon(Icons.menu_book),
            label: 'Duas',
          ),
        ),
      );
    }

    if (visibility.showQuran) {
      items.add(
        _NavItem(
          page: const QuranPage(),
          item: BottomNavigationBarItem(
            icon: const Icon(Icons.book),
            label: AppLocalizations.of(context)!.quran,
          ),
        ),
      );
    }

    items.add(
      _NavItem(
        page: const SettingsPage(),
        item: BottomNavigationBarItem(
          icon: const Icon(Icons.settings),
          label: AppLocalizations.of(context)!.settings,
        ),
      ),
    );

    return items;
  }
}

class _NavItem {
  final Widget page;
  final BottomNavigationBarItem item;
  const _NavItem({required this.page, required this.item});
}

class BottomNavVisibility {
  final bool showTrack;
  final bool showQibla;
  final bool showCalendar;
  final bool showHajj;
  final bool showCommonWords;
  final bool showDuas;
  final bool showQuran;

  const BottomNavVisibility({
    this.showTrack = true,
    this.showQibla = true,
    this.showCalendar = true,
    this.showHajj = true,
    this.showCommonWords = true,
    this.showDuas = true,
    this.showQuran = true,
  });

  static const _keyTrack = 'nav_show_track';
  static const _keyQibla = 'nav_show_qibla';
  static const _keyCalendar = 'nav_show_calendar';
  static const _keyHajj = 'nav_show_hajj';
  static const _keyCommonWords = 'nav_show_common_words';
  static const _keyDuas = 'nav_show_duas';
  static const _keyQuran = 'nav_show_quran';

  factory BottomNavVisibility.fromPrefs(SharedPreferences prefs) {
    return BottomNavVisibility(
      showTrack: prefs.getBool(_keyTrack) ?? true,
      showQibla: prefs.getBool(_keyQibla) ?? true,
      showCalendar: prefs.getBool(_keyCalendar) ?? true,
      showHajj: prefs.getBool(_keyHajj) ?? true,
      showCommonWords: prefs.getBool(_keyCommonWords) ?? true,
      showDuas: prefs.getBool(_keyDuas) ?? true,
      showQuran: prefs.getBool(_keyQuran) ?? true,
    );
  }

  BottomNavVisibility copyWith({
    bool? showTrack,
    bool? showQibla,
    bool? showCalendar,
    bool? showHajj,
    bool? showCommonWords,
    bool? showDuas,
    bool? showQuran,
  }) {
    return BottomNavVisibility(
      showTrack: showTrack ?? this.showTrack,
      showQibla: showQibla ?? this.showQibla,
      showCalendar: showCalendar ?? this.showCalendar,
      showHajj: showHajj ?? this.showHajj,
      showCommonWords: showCommonWords ?? this.showCommonWords,
      showDuas: showDuas ?? this.showDuas,
      showQuran: showQuran ?? this.showQuran,
    );
  }

  Future<void> save(SharedPreferences prefs) async {
    await prefs.setBool(_keyTrack, showTrack);
    await prefs.setBool(_keyQibla, showQibla);
    await prefs.setBool(_keyCalendar, showCalendar);
    await prefs.setBool(_keyHajj, showHajj);
    await prefs.setBool(_keyCommonWords, showCommonWords);
    await prefs.setBool(_keyDuas, showDuas);
    await prefs.setBool(_keyQuran, showQuran);
  }
}
