// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get appTitle => 'Immutable5';

  @override
  String get home => 'Accueil';

  @override
  String get calendar => 'Calendrier';

  @override
  String get hajj => 'Hadj';

  @override
  String get settings => 'Paramètres';

  @override
  String get quran => 'Coran';

  @override
  String get hajjGuide => 'Guide du Hajj';

  @override
  String get completed => 'Terminé';

  @override
  String get selectTopic => 'Sélectionner un sujet';

  @override
  String get commonWords => 'Mots Courants';

  @override
  String get arabic => 'Arabe';

  @override
  String get transliteration => 'Translittération';

  @override
  String get english => 'Anglais';

  @override
  String get calculationMethod => 'Méthode de Calcul';

  @override
  String get selectCalculationMethod => 'Sélectionner Méthode de Calcul';

  @override
  String get madhab => 'Madhab';

  @override
  String get selectMadhab => 'Sélectionner Madhab';

  @override
  String get notifications => 'Notifications';

  @override
  String get amoledTheme => 'Thème Sombre AMOLED';

  @override
  String get amoledThemeSubtitle => 'Utiliser un fond noir véritable pour économiser la batterie';

  @override
  String get locationServicesDisabled => 'Les services de localisation sont désactivés. Veuillez activer les services de localisation.';

  @override
  String get locationPermissionDenied => 'Les autorisations de localisation sont refusées. Veuillez accorder l\'accès à la localisation.';

  @override
  String get locationPermissionPermanentlyDenied => 'Les autorisations de localisation sont définitivement refusées. Veuillez activer la localisation dans les paramètres de votre appareil.';

  @override
  String get usingCachedPrayerTimes => 'Utilisation des horaires de prière en cache (hors ligne)';

  @override
  String get refreshPrayerTimes => 'Actualiser les horaires de prière';

  @override
  String get nextPrayer => 'Prochaine Prière';

  @override
  String get loading => 'Chargement...';
}
