import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import '../../generated/app_localizations.dart';
import '../../di/service_locator.dart';
import '../home/home_controller.dart';
import '../quotes/quote_picker_service.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late final HomeController _controller;

  @override
  void initState() {
    super.initState();
    _controller = HomeController(
      quoteService: getIt<QuotePickerService>(),
      notificationPort: getIt<NotificationPort>(),
      widgetPort: getIt<WidgetUpdatePort>(),
      prayerFactory: getIt<PrayerTimesServiceFactory>(),
    );
    _controller.init();
  }

  @override
  void dispose() {
    _controller.disposeController();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final h = twoDigits(d.inHours);
    final m = twoDigits(d.inMinutes.remainder(60));
    final s = twoDigits(d.inSeconds.remainder(60));
    return "$h:$m:$s";
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final state = _controller.state;
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).colorScheme.inversePrimary,
            title: Text(widget.title),
            actions: [
              if (state.locationLoaded)
                IconButton(
                  icon: state.refreshing
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.refresh),
                  onPressed: state.refreshing ? null : _controller.refresh,
                  tooltip: AppLocalizations.of(context)!.refreshPrayerTimes,
                ),
            ],
          ),
          body: SafeArea(
            child: state.locationError != null && !state.usingCache
                ? Center(child: Text(state.locationError!))
                : state.loading
                    ? const Center(child: CircularProgressIndicator())
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (state.locationNotice != null)
                            _StatusBanner(
                              icon: state.locationPermissionIssue
                                  ? Icons.location_off_outlined
                                  : Icons.info_outline,
                              background: (state.locationPermissionIssue
                                      ? Colors.red
                                      : Colors.orange)
                                  .withOpacity(0.15),
                              foreground: state.locationPermissionIssue
                                  ? Colors.red
                                  : Colors.orange,
                              message: state.locationNotice!,
                              action: state.locationPermissionIssue
                                  ? TextButton(
                                      onPressed: _controller.refresh,
                                      child: Text(
                                        AppLocalizations.of(context)!
                                            .refreshPrayerTimes,
                                        style: TextStyle(
                                          color: state.locationPermissionIssue
                                              ? Colors.red
                                              : Colors.orange,
                                        ),
                                      ),
                                    )
                                  : null,
                            ),
                          if (state.usingCache)
                            Container(
                              color: Colors.orange.withOpacity(0.2),
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const Icon(
                                    Icons.cloud_off,
                                    size: 16,
                                    color: Colors.orange,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      state.locationError ??
                                          AppLocalizations.of(context)!
                                              .usingCachedPrayerTimes,
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          _HijriDateBanner(),
                          Padding(
                            padding: const EdgeInsets.all(24.0),
                            child: Column(
                              children: [
                                Text(
                                  state.nextPrayerName != null
                                      ? '${AppLocalizations.of(context)!.nextPrayer}: ${state.nextPrayerName}'
                                      : AppLocalizations.of(context)!.loading,
                                  style:
                                      Theme.of(context).textTheme.headlineSmall,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  state.nextPrayerTime != null
                                      ? _formatDuration(state.countdown)
                                      : '--:--:--',
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(24.0),
                            child: AnimatedSwitcher(
                              duration: const Duration(milliseconds: 500),
                              transitionBuilder: (child, anim) =>
                                  FadeTransition(
                                opacity: anim,
                                child: child,
                              ),
                              child: Card(
                                key: ValueKey<String>(state.quote ?? ''),
                                elevation: 4,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                margin: EdgeInsets.zero,
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Text(
                                    state.quote ?? '...',
                                    textAlign: TextAlign.center,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(
                                          fontStyle: FontStyle.italic,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
          ),
        );
      },
    );
  }
}

class _StatusBanner extends StatelessWidget {
  const _StatusBanner({
    required this.icon,
    required this.background,
    required this.foreground,
    required this.message,
    this.action,
  });

  final IconData icon;
  final Color background;
  final Color foreground;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: background,
      padding: const EdgeInsets.all(8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: foreground),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                fontSize: 12,
                color: foreground,
              ),
            ),
          ),
          if (action != null) action!,
        ],
      ),
    );
  }
}

class _HijriDateBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final hijri = HijriCalendar.now();
    final hijriDate = hijri.fullDate();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
      child: Text(
        hijriDate,
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}
