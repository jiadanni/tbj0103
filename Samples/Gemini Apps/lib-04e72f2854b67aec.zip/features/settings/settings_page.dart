import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../generated/app_localizations.dart';
import '../../main.dart';
import '../notifications/notification_service.dart';
import '../widget/widget_settings_page.dart';
import '../../services/battery_optimizer.dart';
import '../../services/cache_manager.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  static const _keyCalculationMethod = 'calculationMethod';
  static const _keyMadhab = 'madhab';
  static const _keyNotificationsEnabled = 'notificationsEnabled';
  static const _keyUseAmoledTheme = 'useAmoledTheme';
  static const List<String> _methods = [
    'Method 2 (University of Islamic Sciences)',
    'Method 4 (Islamic Society of North America)',
  ];
  static const List<String> _madhabs = ['Shafi', 'Hanafi', 'Maliki', 'Hanbali'];
  String _calculationMethod = _methods[0];
  String _madhab = 'Shafi';
  bool _notificationsEnabled = true;
  bool _useAmoledTheme = true;
  bool _batterySaverMode = false;
  bool _showTrack = true;
  bool _showQibla = true;
  bool _showCalendar = true;
  bool _showHajj = true;
  bool _showCommonWords = true;
  bool _showDuas = true;
  bool _showQuran = true;

  @override
  void initState() {
    super.initState();
    bottomNavVisibilityNotifier.addListener(_syncNavVisibility);
    _loadPrefs();
  }

  @override
  void dispose() {
    bottomNavVisibilityNotifier.removeListener(_syncNavVisibility);
    super.dispose();
  }

  void _syncNavVisibility() {
    final navVisibility = bottomNavVisibilityNotifier.value;
    if (!mounted) return;
    setState(() {
      _showTrack = navVisibility.showTrack;
      _showQibla = navVisibility.showQibla;
      _showCalendar = navVisibility.showCalendar;
      _showHajj = navVisibility.showHajj;
      _showCommonWords = navVisibility.showCommonWords;
      _showDuas = navVisibility.showDuas;
      _showQuran = navVisibility.showQuran;
    });
  }

  Future<void> _updateNavVisibility({
    bool? showTrack,
    bool? showQibla,
    bool? showCalendar,
    bool? showHajj,
    bool? showCommonWords,
    bool? showDuas,
    bool? showQuran,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final updated = bottomNavVisibilityNotifier.value.copyWith(
      showTrack: showTrack,
      showQibla: showQibla,
      showCalendar: showCalendar,
      showHajj: showHajj,
      showCommonWords: showCommonWords,
      showDuas: showDuas,
      showQuran: showQuran,
    );
    bottomNavVisibilityNotifier.value = updated;
    await updated.save(prefs);
    if (!mounted) return;
    setState(() {
      _showTrack = updated.showTrack;
      _showQibla = updated.showQibla;
      _showCalendar = updated.showCalendar;
      _showHajj = updated.showHajj;
      _showCommonWords = updated.showCommonWords;
      _showDuas = updated.showDuas;
      _showQuran = updated.showQuran;
    });
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final batteryOptimizer = BatteryOptimizer();
    await batteryOptimizer.initialize();

    if (!mounted) return;

    final navVisibility = BottomNavVisibility.fromPrefs(prefs);
    bottomNavVisibilityNotifier.value = navVisibility;

    setState(() {
      _calculationMethod = prefs.getString(_keyCalculationMethod) ?? _calculationMethod;
      _madhab = prefs.getString(_keyMadhab) ?? _madhab;
      _notificationsEnabled = prefs.getBool(_keyNotificationsEnabled) ?? _notificationsEnabled;
      _useAmoledTheme = prefs.getBool(_keyUseAmoledTheme) ?? _useAmoledTheme;
      _batterySaverMode = batteryOptimizer.isBatterySaverEnabled();
      _showTrack = navVisibility.showTrack;
      _showQibla = navVisibility.showQibla;
      _showCalendar = navVisibility.showCalendar;
      _showHajj = navVisibility.showHajj;
      _showCommonWords = navVisibility.showCommonWords;
      _showDuas = navVisibility.showDuas;
      _showQuran = navVisibility.showQuran;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.settings),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text(AppLocalizations.of(context)!.calculationMethod),
            subtitle: Text(_calculationMethod),
            onTap: () async {
              final choice = await showDialog<String>(
                context: context,
                builder: (_) => SimpleDialog(
                  title: Text(
                    AppLocalizations.of(context)!.selectCalculationMethod,
                  ),
                  children: _methods
                      .map(
                        (m) => RadioListTile(
                          title: Text(m),
                          value: m,
                          groupValue: _calculationMethod,
                          onChanged: (v) => Navigator.pop(context, v),
                        ),
                      )
                      .toList(),
                ),
              );
              if (choice != null) {
                final prefs = await SharedPreferences.getInstance();
                setState(() => _calculationMethod = choice);
                prefs.setString(_keyCalculationMethod, choice);
              }
            },
          ),
          ListTile(
            title: Text(AppLocalizations.of(context)!.madhab),
            subtitle: Text(_madhab),
            onTap: () async {
              final choice = await showDialog<String>(
                context: context,
                builder: (_) => SimpleDialog(
                  title: Text(AppLocalizations.of(context)!.selectMadhab),
                  children: _madhabs
                      .map(
                        (m) => RadioListTile(
                          title: Text(m),
                          value: m,
                          groupValue: _madhab,
                          onChanged: (v) => Navigator.pop(context, v),
                        ),
                      )
                      .toList(),
                ),
              );
              if (choice != null) {
                final prefs = await SharedPreferences.getInstance();
                setState(() => _madhab = choice);
                prefs.setString(_keyMadhab, choice);
              }
            },
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.notifications),
            subtitle: const Text('Get notified for each prayer time'),
            value: _notificationsEnabled,
            onChanged: (value) async {
              if (value) {
                // Request notification permissions when enabling
                final granted = await NotificationService().requestPermissions();
                if (!granted) {
                  // Show dialog explaining permissions are needed
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Notification permissions are required to enable prayer reminders',
                        ),
                      ),
                    );
                  }
                  return;
                }
              }

              final prefs = await SharedPreferences.getInstance();
              setState(() => _notificationsEnabled = value);
              await prefs.setBool(_keyNotificationsEnabled, value);

              // Cancel all notifications if disabled
              if (!value) {
                await NotificationService().cancelAllNotifications();
              }
            },
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.amoledTheme),
            subtitle: Text(AppLocalizations.of(context)!.amoledThemeSubtitle),
            value: _useAmoledTheme,
            onChanged: (value) async {
              final prefs = await SharedPreferences.getInstance();
              setState(() => _useAmoledTheme = value);
              await prefs.setBool(_keyUseAmoledTheme, value);
              // Update the global theme notifier
              themeNotifier.value = value ? ThemeMode.dark : ThemeMode.light;
            },
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text(
              'Bottom bar shortcuts',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
          ),
          SwitchListTile(
            title: const Text('Track tab'),
            subtitle: const Text('Show prayer tracking in the bottom bar'),
            value: _showTrack,
            onChanged: (value) => _updateNavVisibility(showTrack: value),
          ),
          SwitchListTile(
            title: const Text('Qibla tab'),
            subtitle: const Text('Show Qibla compass in the bottom bar'),
            value: _showQibla,
            onChanged: (value) => _updateNavVisibility(showQibla: value),
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.calendar),
            subtitle: const Text('Show calendar in the bottom bar'),
            value: _showCalendar,
            onChanged: (value) => _updateNavVisibility(showCalendar: value),
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.hajj),
            subtitle: const Text('Show Hajj guide in the bottom bar'),
            value: _showHajj,
            onChanged: (value) => _updateNavVisibility(showHajj: value),
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.commonWords),
            subtitle: const Text('Show Arabic common words list'),
            value: _showCommonWords,
            onChanged: (value) => _updateNavVisibility(showCommonWords: value),
          ),
          SwitchListTile(
            title: const Text('Duas'),
            subtitle: const Text('Show Duas collection in the bottom bar'),
            value: _showDuas,
            onChanged: (value) => _updateNavVisibility(showDuas: value),
          ),
          SwitchListTile(
            title: Text(AppLocalizations.of(context)!.quran),
            subtitle: const Text('Show Quran in the bottom bar'),
            value: _showQuran,
            onChanged: (value) => _updateNavVisibility(showQuran: value),
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Battery Saver Mode'),
            subtitle: const Text('Reduce battery usage by limiting background updates'),
            value: _batterySaverMode,
            secondary: const Icon(Icons.battery_saver),
            onChanged: (value) async {
              final batteryOptimizer = BatteryOptimizer();
              await batteryOptimizer.setBatterySaverMode(value);
              setState(() => _batterySaverMode = value);

              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      value
                          ? 'Battery saver enabled - Updates will be less frequent'
                          : 'Battery saver disabled - Normal update frequency',
                    ),
                    duration: const Duration(seconds: 3),
                  ),
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline),
            title: const Text('Clear Cache'),
            subtitle: const Text('Free up storage space'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () async {
              final cacheManager = CacheManager();
              final stats = await cacheManager.getStats();

              if (mounted) {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Clear Cache'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Cache Size: ${stats['totalSizeKB']} KB'),
                        Text('Items: ${stats['totalItems']}'),
                        Text('Expired: ${stats['expiredItems']}'),
                        const SizedBox(height: 16),
                        const Text('Clear all cached data?'),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () async {
                          await cacheManager.clearAll();
                          if (context.mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Cache cleared')),
                            );
                          }
                        },
                        child: const Text('Clear'),
                      ),
                    ],
                  ),
                );
              }
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.widgets),
            title: const Text('Widget Settings'),
            subtitle: const Text('Customize home screen widget'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const WidgetSettingsPage(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
