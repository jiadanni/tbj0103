import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models/dua.dart';

class DuasPage extends StatefulWidget {
  const DuasPage({super.key});

  @override
  State<DuasPage> createState() => _DuasPageState();
}

class _DuasPageState extends State<DuasPage> {
  List<Dua> _duas = [];
  List<Dua> _filteredDuas = [];
  List<String> _categories = ['All'];
  String _selectedCategory = 'All';
  bool _loading = true;
  final Set<String> _favorites = {};
  Dua? _selectedDua;

  @override
  void initState() {
    super.initState();
    _loadDuas();
  }

  Future<void> _loadDuas() async {
    try {
      final jsonString = await rootBundle.loadString('assets/duas.json');
      final duas = Dua.listFromJsonString(jsonString)
        ..sort((a, b) {
          final categoryComparison =
              a.categoryLabel.compareTo(b.categoryLabel);
          if (categoryComparison != 0) return categoryComparison;

          final aPriority = a.priority ?? 999;
          final bPriority = b.priority ?? 999;
          final priorityComparison = aPriority.compareTo(bPriority);
          if (priorityComparison != 0) return priorityComparison;

          return a.id.compareTo(b.id);
        });

      final categories = duas
          .map((d) => d.categoryLabel)
          .where((c) => c.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      setState(() {
        _duas = duas;
        _filteredDuas = duas;
        _categories = ['All', ...categories];
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
      });
    }
  }

  void _filterByCategory(String category) {
    setState(() {
      _selectedCategory = category;
      if (category == 'All') {
        _filteredDuas = _duas;
      } else {
        _filteredDuas =
            _duas.where((dua) => dua.categoryLabel == category).toList();
      }
    });
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (_favorites.contains(id)) {
        _favorites.remove(id);
      } else {
        _favorites.add(id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Duas'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                Column(
                  children: [
                    // Category Filter
                    Container(
                      height: 60,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        itemCount: _categories.length,
                        itemBuilder: (context, index) {
                          final category = _categories[index];
                          final isSelected = category == _selectedCategory;
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: FilterChip(
                              label: Text(category),
                              selected: isSelected,
                              onSelected: (selected) {
                                if (selected) {
                                  _filterByCategory(category);
                                } else {
                                  _filterByCategory('All');
                                }
                              },
                              selectedColor:
                                  Theme.of(context).colorScheme.primary,
                              labelStyle: TextStyle(
                                color: isSelected ? Colors.white : null,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const Divider(height: 1),

                    // Duas List
                    Expanded(
                      child: _filteredDuas.isEmpty
                          ? const Center(child: Text('No duas found'))
                          : ListView.builder(
                              itemCount: _filteredDuas.length,
                              itemBuilder: (context, index) {
                                final dua = _filteredDuas[index];
                                return _buildDuaCard(dua);
                              },
                            ),
                    ),
                  ],
                ),
                if (_selectedDua != null)
                  _DuaDetailSheet(
                    dua: _selectedDua!,
                    onClose: () => setState(() => _selectedDua = null),
                  ),
              ],
            ),
    );
  }

  Widget _buildDuaCard(Dua dua) {
    final isFavorite = _favorites.contains(dua.id);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header with category and favorite
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(dua.categoryLabel),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    dua.categoryLabel,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    isFavorite ? Icons.bookmark : Icons.bookmark_border,
                    color: isFavorite ? Colors.amber : null,
                  ),
                  onPressed: () => _toggleFavorite(dua.id),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Occasion
            if ((dua.occasion ?? dua.benefits ?? '').isNotEmpty)
              Text(
                dua.occasion ?? dua.benefits ?? '',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
              ),
            const SizedBox(height: 12),

            // Arabic Text
            Text(
              dua.arabic,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 24,
                fontFamily: 'Amiri',
                height: 2,
              ),
            ),
            const SizedBox(height: 12),

            // Transliteration
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                dua.transliteration,
                style: TextStyle(
                  fontSize: 14,
                  fontStyle: FontStyle.italic,
                  color: Colors.grey[800],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Translation
            Text(
              dua.translationEn,
              style: const TextStyle(
                fontSize: 15,
                height: 1.5,
              ),
            ),

            // Copy Button
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                icon: const Icon(Icons.copy, size: 16),
                label: const Text('Copy'),
                onPressed: () {
                  Clipboard.setData(ClipboardData(
                    text: dua.shareText,
                  ));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Dua copied to clipboard'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => setState(() => _selectedDua = dua),
                child: const Text('More details'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getCategoryColor(String category) {
    final colors = Colors.primaries;
    return colors[category.hashCode.abs() % colors.length].shade400;
  }
}

String prettyLabel(String value) {
  final clean = value.replaceAll('_', ' ').trim();
  if (clean.isEmpty) return value;
  return clean
      .split(' ')
      .map((word) =>
          word.isEmpty ? '' : '${word[0].toUpperCase()}${word.substring(1)}')
      .join(' ');
}

class _DuaDetailSheet extends StatelessWidget {
  const _DuaDetailSheet({
    required this.dua,
    required this.onClose,
  });

  final Dua dua;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final tags = dua.tags.toSet().toList();
    final timeWindows =
        (dua.displayContext?.timeWindows ?? const <String>[]).toSet().toList();

    return Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      child: Material(
        elevation: 12,
        color: Theme.of(context).colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Details',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: onClose,
                    )
                  ],
                ),
                const SizedBox(height: 8),
                if (tags.isNotEmpty) ...[
                  Text(
                    'Tags',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: tags
                        .map(
                          (tag) => Chip(
                            label: Text(prettyLabel(tag)),
                            labelStyle: const TextStyle(fontSize: 12),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 12),
                ],
                if (timeWindows.isNotEmpty) ...[
                  Text(
                    'Contexts',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: timeWindows
                        .map(
                          (window) => Chip(
                            label: Text(prettyLabel(window)),
                            labelStyle: const TextStyle(fontSize: 12),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 12),
                ],
                if (dua.notes?.isNotEmpty ?? false) ...[
                  Text(
                    'Notes',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    dua.notes!,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 12),
                ],
                if (dua.authenticity != null &&
                    dua.authenticity!.grade.isNotEmpty) ...[
                  Text(
                    'Authenticity',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    prettyLabel(dua.authenticity!.grade),
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
