import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';

/// A page displaying a combined Gregorian and Hijri calendar.
class CalendarPage extends StatefulWidget {
  const CalendarPage({Key? key}) : super(key: key);

  @override
  _CalendarPageState createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  bool _hijriPrimary = false;

  Color get _mandatoryFastColor => Colors.redAccent.withOpacity(0.3);
  Color get _optionalFastColor => Colors.orangeAccent.withOpacity(0.3);
  List<int> get _whiteDays => const [13, 14, 15];

  @override
  void initState() {
    super.initState();
    _loadPreference();
  }

  Future<void> _loadPreference() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _hijriPrimary = prefs.getBool('calendar_hijri_primary') ?? false;
    });
  }

  Future<void> _setHijriPrimary(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('calendar_hijri_primary', value);
    setState(() {
      _hijriPrimary = value;
    });
  }

  String _gregorianMonthYear(DateTime day) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[day.month - 1]} ${day.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calendar'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SwitchListTile(
              title: const Text('Use Islamic date as primary'),
              subtitle:
                  const Text('Show Hijri day/month prominently in the calendar'),
              value: _hijriPrimary,
              onChanged: _setHijriPrimary,
              dense: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 4.0),
            ),
            const SizedBox(height: 4),
            _buildLegend(context),
            const SizedBox(height: 8),
            Expanded(
              child: TableCalendar(
                firstDay: DateTime.now().subtract(const Duration(days: 365)),
                lastDay: DateTime.now().add(const Duration(days: 365)),
                focusedDay: _focusedDay,
                headerStyle: const HeaderStyle(
                  formatButtonVisible: false,
                ),
                calendarBuilders: CalendarBuilders(
                  headerTitleBuilder: (context, day) {
                    final hijri = HijriCalendar.fromDate(day);
                    final primary = _hijriPrimary
                        ? '${hijri.longMonthName} ${hijri.hYear}'
                        : _gregorianMonthYear(day);
                    final secondary = _hijriPrimary
                        ? _gregorianMonthYear(day)
                        : '${hijri.longMonthName} ${hijri.hYear}';
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          primary,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          secondary,
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: Colors.grey[600]),
                        ),
                      ],
                    );
                  },
                  defaultBuilder: (context, date, focusedDay) {
                    final hijri = HijriCalendar.fromDate(date);
                    final isMandatoryFast = hijri.hMonth == 9;
                    final isOptionalFast = _whiteDays.contains(hijri.hDay);
                    Color? bg;
                    if (isMandatoryFast) {
                      bg = _mandatoryFastColor;
                    } else if (isOptionalFast) {
                      bg = _optionalFastColor;
                    }
                    return Container(
                      decoration: bg != null
                          ? BoxDecoration(color: bg, shape: BoxShape.circle)
                          : null,
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                              '${_hijriPrimary ? hijri.hDay : date.day}',
                              style: const TextStyle(fontSize: 16)),
                          const SizedBox(height: 2),
                          Text(
                              '${_hijriPrimary ? date.day : hijri.hDay}',
                              style: const TextStyle(fontSize: 10)),
                        ],
                      ),
                    );
                  },
                ),
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                onDaySelected: (selected, focused) {
                  setState(() {
                    _selectedDay = selected;
                    _focusedDay = focused;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegend(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Highlights',
          style: Theme.of(context)
              .textTheme
              .bodyMedium
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 12,
          runSpacing: 8,
          children: [
            _legendChip(color: _mandatoryFastColor, label: 'Ramadan'),
            _legendChip(
                color: _optionalFastColor,
                label: 'Ayyam al-Bid (13-15)'),
          ],
        ),
      ],
    );
  }

  Widget _legendChip({required Color color, required String label}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}
