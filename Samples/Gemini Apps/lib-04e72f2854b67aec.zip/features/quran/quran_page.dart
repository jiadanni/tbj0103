import 'package:flutter/material.dart';
import 'quran_text_service.dart';

/// A structured Qur'an reader with chapter navigation.
class QuranPage extends StatefulWidget {
  const QuranPage({Key? key}) : super(key: key);

  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage> {
  final QuranTextService _service = QuranTextService();
  final ScrollController _scrollController = ScrollController();
  final Map<int, GlobalKey> _chapterKeys = {};

  List<QuranChapter> _chapters = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final chapters = await _service.getChapters();
    if (!mounted) return;
    setState(() {
      _chapterKeys.clear();
      _chapters = List.of(chapters)..sort((a, b) => a.number.compareTo(b.number));
      _loading = false;
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _openChapterPicker() {
    if (_loading) return;
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: ListView.separated(
            itemCount: _chapters.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, index) {
              final chapter = _chapters[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor:
                      Theme.of(context).colorScheme.primaryContainer,
                  foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
                  child: Text(chapter.number.toString()),
                ),
                title: Text(chapter.title),
                subtitle: Text(chapter.transliteration),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  _scrollToChapter(chapter);
                },
              );
            },
          ),
        );
      },
    );
  }

  Future<void> _scrollToChapter(QuranChapter chapter) async {
    final index = _chapters.indexWhere((c) => c.number == chapter.number);
    final key = _chapterKeys[chapter.number];
    if (key?.currentContext != null) {
      await Scrollable.ensureVisible(
        key!.currentContext!,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
        alignment: 0.05,
      );
      return;
    }

    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;
    final avgExtent = _chapters.isNotEmpty && position.hasPixels
        ? position.maxScrollExtent / _chapters.length
        : 600.0;
    final chapterIndex = index >= 0 ? index : (chapter.number - 1);
    final estimatedOffset =
        (avgExtent * chapterIndex).clamp(0.0, position.maxScrollExtent);

    await _scrollController.animateTo(
      estimatedOffset,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeInOut,
    );

    // Try again after scrolling now that more items are built.
    await Future.delayed(const Duration(milliseconds: 16));
    if (key?.currentContext != null) {
      await Scrollable.ensureVisible(
        key!.currentContext!,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
        alignment: 0.05,
      );
    }
  }

  Widget _buildQuickJump() {
    if (_loading) return const SizedBox.shrink();
    return SizedBox(
      height: 60,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        itemCount: _chapters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, index) {
          final chapter = _chapters[index];
          return ActionChip(
            label: Text('${chapter.number}. ${chapter.title}'),
            onPressed: () => _scrollToChapter(chapter),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Qur'an"),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book_outlined),
            onPressed: _openChapterPicker,
            tooltip: 'Browse chapters',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildQuickJump(),
                const Divider(height: 1),
                Expanded(
                  child: Scrollbar(
                    controller: _scrollController,
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(16),
                      cacheExtent: 2000,
                      itemCount: _chapters.length,
                      itemBuilder: (context, index) {
                        final chapter = _chapters[index];
                        final key = _chapterKeys.putIfAbsent(
                          chapter.number,
                          () => GlobalKey(),
                        );
                        return _ChapterCard(
                          key: ValueKey('chapter_${chapter.number}'),
                          chapter: chapter,
                          theme: theme,
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _ChapterCard extends StatelessWidget {
  const _ChapterCard({
    super.key,
    required this.chapter,
    required this.theme,
  });

  final QuranChapter chapter;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Card(
        elevation: 1,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    backgroundColor: theme.colorScheme.primaryContainer,
                    foregroundColor: theme.colorScheme.onPrimaryContainer,
                    child: Text(chapter.number.toString()),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          chapter.title,
                          style: theme.textTheme.titleMedium,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          chapter.transliteration,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ListView.separated(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: chapter.verses.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, verseIndex) => SelectableText(
                  chapter.verses[verseIndex],
                  style: theme.textTheme.bodyMedium,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
