import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/export/export_screen.dart';
import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/features/options/categories_screen.dart';
import 'package:expense_stalker_mobile/src/features/options/currencies_screen.dart';

class OptionsScreen extends StatefulWidget {
  const OptionsScreen({
    super.key,
    this.authService,
  });

  final AuthService? authService;

  @override
  State<OptionsScreen> createState() => _OptionsScreenState();
}

class _OptionsScreenState extends State<OptionsScreen> {
  late final AuthService _authService;
  bool _authReady = false;
  bool _authEnabled = false;
  bool _biometricsEnabled = false;
  bool _biometricsAvailable = false;
  bool _hasPin = false;
  int _delayBeforeAuthSeconds = 0;
  bool _preventScreenshots = false;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  AccountId? _selectedAccountId;

  @override
  void initState() {
    super.initState();
    _authService = widget.authService ?? AuthService();
    _loadAuthSettings();
    // Initialize selected account after first frame when store is available
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        final store = ExpenseStoreScope.read(context);
        setState(() {
          _selectedAccountId = store.currentAccount.id;
        });
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadAuthSettings() async {
    await _authService.initialize();
    final authEnabled = await _authService.isAuthEnabled();
    final biometricsAvailable = await _authService.isBiometricAvailable();
    final biometricsEnabled = await _authService.useBiometrics();
    bool hasPin = false;
    try {
      hasPin = await _authService.hasPIN();
    } catch (_) {
      // Secure storage not available: treat as no PIN configured
      hasPin = false;
    }
    final delayBeforeAuthSeconds = await _authService.getDelayBeforeAuthSeconds();
    final preventScreenshots = await _authService.preventScreenshots();
    if (!mounted) return;
    setState(() {
      _authReady = true;
      _authEnabled = authEnabled;
      _biometricsAvailable = biometricsAvailable;
      _biometricsEnabled = biometricsEnabled;
      _hasPin = hasPin;
      _delayBeforeAuthSeconds = delayBeforeAuthSeconds;
      _preventScreenshots = preventScreenshots;
    });
  }

  Future<void> _setAuthEnabled(BuildContext context, bool enabled) async {
    if (!_authReady) return;
    final l10n = AppLocalizations.of(context)!;

    if (enabled && !_hasPin) {
      // Enabling auth requires setting up a PIN first
      final didSet = await _showPinSetupDialog(
        context,
        title: l10n.setSecurityPIN,
      );
      if (!didSet) return;
    } else if (!enabled && _hasPin) {
      // Disabling auth requires verifying the current PIN first
      final verified = await _showPinVerifyDialog(context);
      if (!verified) return;
    }

    await _authService.setAuthEnabled(enabled);
    if (!mounted) return;
    // If disabling authentication, the AuthService will remove the PIN.
    // Update local state to reflect the immediate removal so the UI updates
    // (disable PIN edit button, biometric toggles, etc.).
    if (!enabled) {
      bool hasPinNow = false;
      try {
        hasPinNow = await _authService.hasPIN();
      } catch (_) {
        hasPinNow = false;
      }
      setState(() {
        _authEnabled = enabled;
        _hasPin = hasPinNow;
      });
    } else {
      setState(() => _authEnabled = enabled);
    }
    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(enabled ? l10n.authEnabled : l10n.authDisabled),
        duration: AppConstants.snackBarShort,
      ),
    );

    // If we disabled authentication and the PIN was removed, show confirmation
    if (!enabled && !_hasPin) {
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)?.pinRemoved ?? 'PIN removed'),
          duration: AppConstants.snackBarShort,
        ),
      );
    }
  }

  Future<void> _setBiometricsEnabled(bool enabled) async {
    await _authService.setUseBiometrics(enabled);
    if (!mounted) return;
    setState(() => _biometricsEnabled = enabled);
  }

  Future<void> _setDelayBeforeAuthSeconds(int seconds) async {
    await _authService.setDelayBeforeAuthSeconds(seconds);
    if (!mounted) return;
    setState(() => _delayBeforeAuthSeconds = seconds);
  }

  Future<void> _setPreventScreenshots(BuildContext context, bool enabled) async {
    if (!_authReady) return;
    final l10n = AppLocalizations.of(context)!;

    // Require authentication to be enabled and a PIN to be set before enabling screenshot protection
    if (!_authEnabled || !_hasPin) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(l10n.pinRequiredForScreenshotProtection),
          duration: AppConstants.snackBarNormal,
        ),
      );
      return;
    }

    // Always require authentication to change this security setting
    // Try biometrics first
    var authenticated = await _authService.authenticateWithBiometrics(
      reason: l10n.authenticateToChangeScreenshotSetting,
    );

    // Fall back to PIN if biometrics failed/unavailable
    if (!authenticated && mounted) {
      authenticated = await _showPinVerifyDialog(context);
    }

    if (!authenticated) return;

    await _authService.setPreventScreenshots(enabled);
    if (!mounted) return;
    setState(() => _preventScreenshots = enabled);

    // Notify the app to update the screenshot flag
    _ScreenshotProtectionNotifier.instance.notify(enabled);

    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          enabled
              ? l10n.screenshotProtectionEnabled
              : l10n.screenshotProtectionDisabled,
        ),
        duration: AppConstants.snackBarShort,
      ),
    );
  }


  Future<void> _changePin(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    if (!_hasPin) {
      await _showPinSetupDialog(
        context,
        title: l10n.setSecurityPIN,
      );
      return;
    }

    final verified = await _showPinVerifyDialog(context);
    if (!verified) return;
    await _showPinSetupDialog(
      context,
      title: l10n.changeSecurityPIN,
    );
  }

  Future<bool> _showPinSetupDialog(
    BuildContext context, {
    required String title,
  }) async {
    final l10n = AppLocalizations.of(context)!;
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => _PinSetupDialog(
        title: title,
        authService: _authService,
      ),
    );
    if (result == true && mounted) {
      final newHasPin = await _authService.hasPIN();
      setState(() => _hasPin = newHasPin);
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(l10n.pinChanged),
          duration: AppConstants.snackBarShort,
        ),
      );
      return true;
    }
    return false;
  }

  Future<bool> _showPinVerifyDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => _PinVerifyDialog(authService: _authService),
    );
    return result ?? false;
  }

  Future<int?> _showBalanceEditDialog(
    BuildContext context, {
    required int currentValueCents,
    required AppSettingsStore settings,
  }) async {
    return showDialog<int?>(
      context: context,
      builder: (context) => _BalanceEditDialog(
        currentValueCents: currentValueCents,
        settings: settings,
      ),
    );
  }

  String _secondsLabel(AppLocalizations l10n, int seconds) {
    if (seconds == 0) return l10n.off;
    if (seconds >= 60) {
      final minutes = seconds ~/ 60;
      return minutes == 1 ? '1 min' : '$minutes min';
    }
    if (seconds == 1) return '1 sec';
    return '$seconds sec';
  }

  Future<void> _showQuickAmountsEditDialog(BuildContext context) async {
    final settings = AppSettingsScope.read(context);
    final currentAmounts = settings.customQuickAddAmounts;

    // Controllers
    final controllers = currentAmounts.map((amount) {
      // Amount is in cents/minor units. format for display.
      // We'll format as whole number for editing if possible, or decimal if needed.
      // But typically these are round numbers.
      // Let's us formatMoney but remove symbol and separators for editing if simpler,
      // OR just parse double.
      final amountMajor = amount / 100.0; // Assuming cents for simplicity in edit
      // Remove trailing .0
      final text = amountMajor == amountMajor.truncateToDouble()
          ? amountMajor.truncate().toString()
          : amountMajor.toString();
      return TextEditingController(text: text);
    }).toList();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Quick Spending Amounts'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Set your 3 quick access amounts for spending envelopes.'),
            const SizedBox(height: 16),
            ...List.generate(3, (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: TextField(
                  controller: controllers[index],
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: 'Amount ${index + 1}',
                    border: const OutlineInputBorder(),
                    // prefixText: settings.currency.symbol, // Optional
                  ),
                ),
              );
            }),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final newAmounts = <int>[];
              for (final controller in controllers) {
                final text = controller.text.trim();
                // Simple parsing logic matching our standard standard
                // We multiply by 100 effectively by parsing as double then *100
                 // This matches how we loaded it: amount / 100.0
                final val = double.tryParse(text);
                if (val != null) {
                  newAmounts.add((val * 100).round());
                } else {
                  // Fallback to existing if invalid? Or 0?
                  newAmounts.add(currentAmounts[newAmounts.length]);
                }
              }
              
              settings.customQuickAddAmounts = newAmounts;
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    for (final c in controllers) {
      c.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        final palette = _OptionsPalette.of(context);
        final l10n = AppLocalizations.of(context)!;
        final delayOptions = <int>{
          0,
          5,
          15,
          30,
          60,
          120, // 2 min
          300, // 5 min
          600, // 10 min
          _delayBeforeAuthSeconds,
        }.toList()
          ..sort();

        final sections = [
          _SearchableSection(
            title: l10n.appearance,
            icon: Icons.palette,
            options: [
              _SearchableOption(
                keywords: [l10n.appearance, l10n.system, l10n.light, l10n.dark],
                widget: Padding(
                  padding: const EdgeInsets.all(12),
                  child: RadioGroup<ThemeMode>(
                    groupValue: settings.themeMode,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.themeMode = v;
                    },
                    child: Column(
                      children: [
                        RadioListTile<ThemeMode>(
                          value: ThemeMode.system,
                          title: Text(l10n.system),
                        ),
                        const SizedBox(height: 10),
                        RadioListTile<ThemeMode>(
                          value: ThemeMode.light,
                          title: Text(l10n.light),
                        ),
                        const SizedBox(height: 10),
                        RadioListTile<ThemeMode>(
                          value: ThemeMode.dark,
                          title: Text(l10n.dark),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.textSize,
                  l10n.textSizeSubtitle,
                  l10n.textSizeSmall,
                  l10n.textSizeDefault,
                  l10n.textSizeLarge,
                  l10n.textSizeExtraLarge
                ],
                widget: _OptionsTile(
                  icon: Icons.text_fields,
                  title: l10n.textSize,
                  subtitle: l10n.textSizeSubtitle,
                  trailing: _OptionsDropdown<TextScalePreset>(
                    value: settings.textScalePreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.textScalePreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: TextScalePreset.small,
                        child: Text(l10n.textSizeSmall),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.normal,
                        child: Text(l10n.textSizeDefault),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.large,
                        child: Text(l10n.textSizeLarge),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.extraLarge,
                        child: Text(l10n.textSizeExtraLarge),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.fontFamily,
                  l10n.fontFamilySubtitle,
                  l10n.system,
                  l10n.fontMonospace
                ],
                widget: _OptionsTile(
                  icon: Icons.font_download,
                  title: l10n.fontFamily,
                  subtitle: l10n.fontFamilySubtitle,
                  trailing: _OptionsDropdown<FontPreset>(
                    value: settings.fontPreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.fontPreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: FontPreset.system,
                        child: Text(l10n.system),
                      ),
                      DropdownMenuItem(
                        value: FontPreset.monospace,
                        child: Text(l10n.fontMonospace),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.appTheme,
                  l10n.appThemeSubtitle,
                  l10n.appThemeClassic,
                  l10n.appThemeOcean,
                  l10n.appThemeSunset,
                  l10n.appThemeMonochrome,
                  l10n.appThemeForest,
                ],
                widget: _OptionsTile(
                  icon: Icons.format_paint,
                  title: l10n.appTheme,
                  subtitle: l10n.appThemeSubtitle,
                  trailing: _OptionsDropdown<AppThemePreset>(
                    value: settings.appThemePreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.appThemePreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: AppThemePreset.monochrome,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.monochrome),
                            const SizedBox(width: 8),
                            Text(l10n.appThemeMonochrome),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.classic,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.classic),
                            const SizedBox(width: 8),
                            Text(l10n.appThemeClassic),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.ocean,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.ocean),
                            const SizedBox(width: 8),
                            Text(l10n.appThemeOcean),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.sunset,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.sunset),
                            const SizedBox(width: 8),
                            Text(l10n.appThemeSunset),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.forest,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.forest),
                            const SizedBox(width: 8),
                            Text(l10n.appThemeForest),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.berry,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.berry),
                            const SizedBox(width: 8),
                            const Text('Berry'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.lavender,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.lavender),
                            const SizedBox(width: 8),
                            const Text('Lavender'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.midnight,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.midnight),
                            const SizedBox(width: 8),
                            const Text('Midnight'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.rose,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.rose),
                            const SizedBox(width: 8),
                            const Text('Rose'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: AppThemePreset.mint,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AppThemePreview(preset: AppThemePreset.mint),
                            const SizedBox(width: 8),
                            const Text('Mint'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.colorPreset,
                  l10n.colorPresetSubtitle,
                  l10n.colorPresetClassic,
                  l10n.colorPresetOcean,
                  l10n.colorPresetSunset,
                  l10n.colorPresetMonochrome,
                  l10n.colorPresetForest,
                  l10n.colorPresetCustom
                ],
                widget: _OptionsTile(
                  icon: Icons.palette,
                  title: l10n.colorPreset,
                  subtitle: l10n.colorPresetSubtitle,
                  trailing: _OptionsDropdown<ColorPreset>(
                    value: settings.colorPreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.colorPreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: ColorPreset.classic,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.classic),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetClassic),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.ocean,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.ocean),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetOcean),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.sunset,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.sunset),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetSunset),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.monochrome,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.monochrome),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetMonochrome),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.forest,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.forest),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetForest),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.berry,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.berry),
                            const SizedBox(width: 8),
                            const Text('Berry'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.lavender,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.lavender),
                            const SizedBox(width: 8),
                            const Text('Lavender'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.earth,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.earth),
                            const SizedBox(width: 8),
                            const Text('Earth'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.mint,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.mint),
                            const SizedBox(width: 8),
                            const Text('Mint'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.warm,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.warm),
                            const SizedBox(width: 8),
                            const Text('Warm'),
                          ],
                        ),
                      ),
                      DropdownMenuItem(
                        value: ColorPreset.custom,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _ColorPresetPreview(
                                preset: ColorPreset.custom),
                            const SizedBox(width: 8),
                            Text(l10n.colorPresetCustom),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.debitColor],
                widget: _OptionsTile(
                  icon: Icons.remove_circle,
                  iconColor: settings.debitColor,
                  title: l10n.debitColor,
                  trailing: _ColorSwatch(
                    color: settings.debitColor,
                    onTap: () => _showColorPicker(
                      context,
                      settings.debitColor,
                      (color) => settings.debitColor = color,
                      l10n.debitColor,
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.creditColor],
                widget: _OptionsTile(
                  icon: Icons.add_circle,
                  iconColor: settings.creditColor,
                  title: l10n.creditColor,
                  trailing: _ColorSwatch(
                    color: settings.creditColor,
                    onTap: () => _showColorPicker(
                      context,
                      settings.creditColor,
                      (color) => settings.creditColor = color,
                      l10n.creditColor,
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.neutralColor],
                widget: _OptionsTile(
                  icon: Icons.adjust,
                  iconColor: settings.neutralColor,
                  title: l10n.neutralColor,
                  trailing: _ColorSwatch(
                    color: settings.neutralColor,
                    onTap: () => _showColorPicker(
                      context,
                      settings.neutralColor,
                      (color) => settings.neutralColor = color,
                      l10n.neutralColor,
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.terminologyPreset,
                  l10n.terminologyPresetSubtitle,
                  l10n.terminologyDefault,
                  l10n.terminologyBills,
                  l10n.terminologyBudget
                ],
                widget: _OptionsTile(
                  icon: Icons.label_outline,
                  title: l10n.terminologyPreset,
                  subtitle: l10n.terminologyPresetSubtitle,
                  trailing: _OptionsDropdown<TerminologyPreset>(
                    value: settings.terminologyPreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.terminologyPreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: TerminologyPreset.defaultTerms,
                        child: Text(l10n.terminologyDefault),
                      ),
                      DropdownMenuItem(
                        value: TerminologyPreset.bills,
                        child: Text(l10n.terminologyBills),
                      ),
                      DropdownMenuItem(
                        value: TerminologyPreset.budget,
                        child: Text(l10n.terminologyBudget),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: l10n.planner,
            icon: Icons.event_note,
            options: [
              _SearchableOption(
                keywords: [
                  l10n.planner,
                  l10n.dayAsNumber,
                  l10n.dayAsOrdinal
                ],
                widget: Padding(
                  padding: const EdgeInsets.all(12),
                  child: RadioGroup<DayFormat>(
                    groupValue: settings.dayFormat,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.dayFormat = v;
                    },
                    child: Column(
                      children: [
                        RadioListTile<DayFormat>(
                          value: DayFormat.number,
                          title: Text(l10n.dayAsNumber),
                          subtitle: Text(l10n.dayAsNumberExample),
                        ),
                        const SizedBox(height: 10),
                        RadioListTile<DayFormat>(
                          value: DayFormat.ordinal,
                          title: Text(l10n.dayAsOrdinal),
                          subtitle: Text(l10n.dayAsOrdinalExample),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.categoryPresetTitle,
                  l10n.categoryPresetDefault,
                  l10n.categoryPresetCustom,
                  l10n.categoryPresetBoth
                ],
                widget: _OptionsTile(
                  icon: Icons.category,
                  title: l10n.categoryPresetTitle,
                  trailing: _OptionsDropdown<CategoryPresetMode>(
                    value: settings.categoryPresetMode,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.categoryPresetMode = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: CategoryPresetMode.defaultPresets,
                        child: Text(l10n.categoryPresetDefault),
                      ),
                      DropdownMenuItem(
                        value: CategoryPresetMode.customOnly,
                        child: Text(l10n.categoryPresetCustom),
                      ),
                      DropdownMenuItem(
                        value: CategoryPresetMode.both,
                        child: Text(l10n.categoryPresetBoth),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.categories, 'Manage Categories', 'Custom', 'Default'],
                widget: _OptionsTile(
                  icon: Icons.category_outlined,
                  title: 'Manage Categories',
                  subtitle: 'Add or edit custom expense and income types',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const CategoriesScreen(),
                      ),
                    );
                  },
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.groupByDate, l10n.groupByDateSubtitle],
                widget: _OptionsTile(
                  icon: Icons.calendar_view_day,
                  title: l10n.groupByDate,
                  subtitle: l10n.groupByDateSubtitle,
                  trailing: Switch(
                    value: settings.plannerGroupByDate,
                    onChanged: (value) => settings.plannerGroupByDate = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.groupByTheme, l10n.groupByThemeSubtitle],
                widget: _OptionsTile(
                  icon: Icons.style,
                  title: l10n.groupByTheme,
                  subtitle: l10n.groupByThemeSubtitle,
                  trailing: Switch(
                    value: settings.plannerGroupByTheme,
                    onChanged: (value) => settings.plannerGroupByTheme = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.showPaymentOrigin,
                  l10n.showPaymentOriginSubtitle
                ],
                widget: _OptionsTile(
                  icon: Icons.business,
                  title: l10n.showPaymentOrigin,
                  subtitle: l10n.showPaymentOriginSubtitle,
                  trailing: Switch(
                    value: settings.plannerShowPaymentOrigin,
                    onChanged: (value) =>
                        settings.plannerShowPaymentOrigin = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.monthTotalsDisplayTitle,
                  l10n.monthTotalsShowClearedRow,
                  l10n.monthTotalsIncludeCleared
                ],
                widget: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        l10n.monthTotalsDisplayTitle,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 6),
                      CheckboxListTile(
                        value: settings.monthTotalsDisplayMode ==
                            MonthTotalsDisplayMode.showClearedRow,
                        onChanged: (value) {
                          settings.monthTotalsDisplayMode = value == true
                              ? MonthTotalsDisplayMode.showClearedRow
                              : MonthTotalsDisplayMode.includeCleared;
                        },
                        title: Text(l10n.monthTotalsShowClearedRow),
                        subtitle: Text(l10n.monthTotalsIncludeCleared),
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.plannerTapAction,
                  l10n.plannerTapActionMenu,
                  l10n.plannerTapActionArchive
                ],
                widget: _OptionsTile(
                  icon: Icons.touch_app,
                  title: l10n.plannerTapAction,
                  subtitle: settings.plannerTapAction == PlannerTapAction.menu
                      ? l10n.plannerTapActionMenu
                      : l10n.plannerTapActionArchive,
                  trailing: Switch(
                    value: settings.plannerTapAction == PlannerTapAction.menu,
                    onChanged: (value) => settings.plannerTapAction = value
                        ? PlannerTapAction.menu
                        : PlannerTapAction.archive,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),

              _SearchableOption(
                keywords: ['Quick Spending', 'Amounts', 'Spending Envelope'],
                widget: _OptionsTile(
                  icon: Icons.payments_outlined,
                  title: 'Quick Spending Amounts',
                  subtitle: settings.customQuickAddAmounts
                      .map((a) => formatMoney(a, settings.currency, showDecimals: false))
                      .join(', '),
                  onTap: () => _showQuickAmountsEditDialog(context),
                  trailing: const Icon(Icons.chevron_right),
                ),
              ),


            ],
          ),
          _SearchableSection(
            title: 'Payments & Scheduled',
            icon: Icons.payments_outlined,
            options: [
              _SearchableOption(
                keywords: [
                  'Month View Display',
                  'Single month card view',
                  'Full Name',
                  'Acronym'
                ],
                widget: _OptionsTile(
                  icon: Icons.view_agenda,
                  title: 'Month View Display',
                  subtitle: 'Single month card view',
                  trailing: _OptionsDropdown<MonthCardDisplayMode>(
                    value: settings.monthCardDisplayMode,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.monthCardDisplayMode = v;
                    },
                    items: const [
                      DropdownMenuItem(
                        value: MonthCardDisplayMode.full,
                        child: Text('Full Name'),
                      ),
                      DropdownMenuItem(
                        value: MonthCardDisplayMode.acronym,
                        child: Text('Acronym'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Multi-Month Display',
                  'Grid and sheet views',
                  'Automatic',
                  'Full Name',
                  'Acronym',
                  'Icon'
                ],
                widget: _OptionsTile(
                  icon: Icons.grid_view,
                  title: 'Multi-Month Display',
                  subtitle: 'Grid and sheet views',
                  trailing: _OptionsDropdown<MultiMonthDisplayMode>(
                    value: settings.multiMonthDisplayMode,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.multiMonthDisplayMode = v;
                    },
                    items: const [
                      DropdownMenuItem(
                        value: MultiMonthDisplayMode.automatic,
                        child: Text('Automatic'),
                      ),
                      DropdownMenuItem(
                        value: MultiMonthDisplayMode.full,
                        child: Text('Full Name'),
                      ),
                      DropdownMenuItem(
                        value: MultiMonthDisplayMode.acronym,
                        child: Text('Acronym'),
                      ),
                      DropdownMenuItem(
                        value: MultiMonthDisplayMode.icon,
                        child: Text('Icon'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.swipeBetweenTabs,
                  l10n.swipeBetweenTabsSubtitle
                ],
                widget: _OptionsTile(
                  icon: Icons.swap_horiz,
                  title: l10n.swipeBetweenTabs,
                  subtitle: l10n.swipeBetweenTabsSubtitle,
                  trailing: Switch(
                    value: settings.enableTabSwipe,
                    onChanged: (value) => settings.enableTabSwipe = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: 'Data & Backup',
            icon: Icons.cloud_upload_outlined,
            options: [
              _SearchableOption(
                keywords: [
                  l10n.exportAndImportTitle,
                  l10n.saveYourData,
                  l10n.restoreYourData
                ],
                widget: _OptionsTile(
                  icon: Icons.import_export,
                  title: l10n.exportAndImportTitle,
                  subtitle: '${l10n.saveYourData} ${l10n.restoreYourData}',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const ExportScreen(),
                      ),
                    );
                  },
                ),
              ),
              _SearchableOption(
                keywords: ['Currencies', 'Exchange Rates', 'Frankfurter', 'Manual'],
                widget: _OptionsTile(
                  icon: Icons.currency_exchange_outlined,
                  title: 'Currencies & Rates',
                  subtitle: 'Configure enabled currencies and exchange rates',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const CurrenciesScreen(),
                      ),
                    );
                  },
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.regionPreset,
                  l10n.regionPresetDescription
                ],
                widget: _OptionsTile(
                  icon: Icons.public,
                  title: l10n.regionPreset,
                  subtitle: l10n.regionPresetDescription,
                  trailing: _OptionsDropdown<String>(
                    value: settings.regionPresetId,
                    onChanged: (value) {
                      if (value == null) return;
                      settings.regionPresetId = value;
                    },
                    items: settings.regionPresets
                        .map(
                          (preset) => DropdownMenuItem(
                            value: preset.id,
                            child: Text(preset.label),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.displayCurrency,
                  l10n.currency_eur,
                  l10n.currency_usd,
                  l10n.currency_gbp
                ],
                widget: _OptionsTile(
                  icon: Icons.currency_exchange,
                  title: l10n.displayCurrency,
                  trailing: _OptionsDropdown<AppCurrency>(
                    value: settings.currency,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.currency = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: AppCurrency.eur,
                        child: Text(l10n.currency_eur),
                      ),
                      DropdownMenuItem(
                        value: AppCurrency.usd,
                        child: Text(l10n.currency_usd),
                      ),
                      DropdownMenuItem(
                        value: AppCurrency.gbp,
                        child: Text(l10n.currency_gbp),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Show Cents',
                  'Display decimals in prices'
                ],
                widget: _OptionsTile(
                  icon: Icons.money_off,
                  title: 'Show Cents',
                  subtitle: 'Display decimals in prices',
                  trailing: Switch(
                    value: settings.showCents,
                    onChanged: (value) => settings.showCents = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Round Up To',
                  'Auto-round inputs up to nearest'
                ],
                widget: _OptionsTile(
                  icon: Icons.functions,
                  title: 'Round Up To',
                  subtitle: 'Auto-round inputs up to nearest...',
                  trailing: _OptionsDropdown<int>(
                    value: settings.roundingIncrement,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.roundingIncrement = v;
                    },
                    items: const [
                      DropdownMenuItem(
                        value: 0,
                        child: Text('None'),
                      ),
                      DropdownMenuItem(
                        value: 1,
                        child: Text('Nearest 1'),
                      ),
                      DropdownMenuItem(
                        value: 5,
                        child: Text('Nearest 5'),
                      ),
                      DropdownMenuItem(
                        value: 10,
                        child: Text('Nearest 10'),
                      ),
                      DropdownMenuItem(
                        value: 50,
                        child: Text('Nearest 50'),
                      ),
                      DropdownMenuItem(
                        value: 100,
                        child: Text('Nearest 100'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Money Pots Scope',
                  'Money Pots Storage',
                  'Global Money Pots',
                  'Account-Specific Money Pots'
                ],
                widget: _OptionsTile(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'Money Pots Scope',
                  subtitle: settings.moneyPotsScope == MoneyPotsScope.global
                      ? 'Shared across all accounts'
                      : 'Separate for each account',
                  trailing: _OptionsDropdown<MoneyPotsScope>(
                    value: settings.moneyPotsScope,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.moneyPotsScope = v;
                    },
                    items: const [
                      DropdownMenuItem(
                        value: MoneyPotsScope.global,
                        child: Text('Global'),
                      ),
                      DropdownMenuItem(
                        value: MoneyPotsScope.accountSpecific,
                        child: Text('Account-Specific'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: l10n.security,
            icon: Icons.lock_outline,
            options: [
              _SearchableOption(
                keywords: [
                  l10n.requireAuthentication,
                  l10n.requireAuthenticationSubtitle
                ],
                widget: _OptionsTile(
                  icon: Icons.shield_outlined,
                  title: l10n.requireAuthentication,
                  subtitle: l10n.requireAuthenticationSubtitle,
                  trailing: Switch(
                    value: _authEnabled,
                    onChanged: _authReady
                        ? (value) => _setAuthEnabled(context, value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.biometricAuthentication,
                  l10n.pinRequiredForBiometrics,
                  l10n.biometricAuthenticationSubtitle
                ],
                widget: _OptionsTile(
                  icon: Icons.fingerprint,
                  title: l10n.biometricAuthentication,
                  subtitle: !_hasPin
                      ? l10n.pinRequiredForBiometrics
                      : l10n.biometricAuthenticationSubtitle,
                  trailing: Switch(
                    // Biometrics requires: auth ready, auth enabled, biometrics available, AND a PIN set as fallback
                    value: _biometricsEnabled && _hasPin,
                    onChanged: _authReady &&
                            _authEnabled &&
                            _biometricsAvailable &&
                            _hasPin
                        ? (value) => _setBiometricsEnabled(value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.pin,
                  l10n.changeSecurityPIN,
                  l10n.setSecurityPIN
                ],
                widget: _OptionsTile(
                  icon: Icons.pin,
                  title: l10n.pin,
                  subtitle: _hasPin ? l10n.changeSecurityPIN : l10n.setSecurityPIN,
                  trailing: FilledButton(
                    // Only allow editing/setting PIN when authentication is enabled
                    onPressed: _authReady && _authEnabled
                        ? () => _changePin(context)
                        : null,
                    child: Text(l10n.edit),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n.authDelayBeforePrompt,
                  l10n.authDelayBeforePromptSubtitle
                ],
                widget: _OptionsTile(
                  icon: Icons.timelapse,
                  title: l10n.authDelayBeforePrompt,
                  subtitle: l10n.authDelayBeforePromptSubtitle,
                  trailing: _OptionsDropdown<int>(
                    value: _delayBeforeAuthSeconds,
                    onChanged: !_authReady || !_authEnabled
                        ? null
                        : (value) {
                            if (value == null) return;
                            _setDelayBeforeAuthSeconds(value);
                          },
                    items: delayOptions
                        .map(
                          (value) => DropdownMenuItem(
                            value: value,
                            child: Text(_secondsLabel(l10n, value)),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [l10n.preventScreenshots, l10n.preventScreenshotsSubtitle],
                widget: _OptionsTile(
                  icon: Icons.screenshot_outlined,
                  title: l10n.preventScreenshots,
                  subtitle: l10n.preventScreenshotsSubtitle,
                  trailing: Switch(
                    value: _preventScreenshots,
                    onChanged: _authReady
                        ? (value) => _setPreventScreenshots(context, value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
            ],
          ),
          // Account Settings section with account picker
          _SearchableSection(
            title: 'Account Settings',
            icon: Icons.account_circle_outlined,
            options: [
              _SearchableOption(
                keywords: ['Account', 'Select Account', 'Switch Account Settings'],
                widget: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Edit settings for:',
                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: palette.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 300),
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              color: palette.surfaceAlt,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: palette.border),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<AccountId>(
                                  value: _selectedAccountId,
                                  isExpanded: true,
                                  icon: Icon(Icons.expand_more, color: palette.textSecondary),
                                  dropdownColor: palette.surface,
                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: palette.textPrimary,
                                  ),
                                  onChanged: (AccountId? newId) {
                                    if (newId != null) {
                                      setState(() {
                                        _selectedAccountId = newId;
                                      });
                                    }
                                  },
                                  items: store.accounts.map((account) {
                                    final isCurrent = account.id == store.currentAccount.id;
                                    return DropdownMenuItem<AccountId>(
                                      value: account.id,
                                      child: Row(
                                        children: [
                                          Expanded(child: Text(account.name)),
                                          if (isCurrent)
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: palette.theme.withValues(alpha: 0.2),
                                                borderRadius: BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                'ACTIVE',
                                                style: TextStyle(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                  color: palette.theme,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Payday', 'Paycheck Day', 'Salary Day'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  return _OptionsTile(
                    icon: Icons.calendar_today,
                    title: 'Payday',
                    subtitle: selectedAccount?.paycheckDay != null
                        ? 'Day ${selectedAccount!.paycheckDay}'
                        : 'Not set',
                    trailing: _OptionsDropdown<int?>(
                      value: selectedAccount?.paycheckDay,
                      onChanged: (int? day) {
                        if (_selectedAccountId == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          paycheckDay: day,
                          clearPaycheckDay: day == null,
                        );
                      },
                      items: [
                        const DropdownMenuItem<int?>(
                          value: null,
                          child: Text('Not set'),
                        ),
                        ...List.generate(28, (i) => i + 1).map((day) =>
                          DropdownMenuItem<int?>(
                            value: day,
                            child: Text('$day'),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['Starting Balance', 'Current Balance', 'Initial Balance'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  final balanceCents = selectedAccount?.startingBalanceCents ?? 0;
                  return _OptionsTile(
                    icon: Icons.account_balance_wallet,
                    title: 'Starting Balance',
                    subtitle: formatMoneyFromCents(balanceCents, settings.currencySettings.currency, showCents: settings.showCents),
                    trailing: Icon(Icons.edit, color: palette.textSecondary, size: 20),
                    onTap: () async {
                      if (_selectedAccountId == null) return;
                      final result = await _showBalanceEditDialog(
                        context,
                        currentValueCents: balanceCents,
                        settings: settings,
                      );
                      if (result != null) {
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          startingBalanceCents: result,
                        );
                      }
                    },
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['View Period', 'Calendar', 'Paycheck Period'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  return _OptionsTile(
                    icon: Icons.date_range,
                    title: 'View Period Mode',
                    subtitle: selectedAccount?.viewPeriodMode == ViewPeriodMode.paycheck 
                        ? 'Paycheck Period'
                        : 'Calendar Month',
                    trailing: _OptionsDropdown<ViewPeriodMode>(
                      value: selectedAccount?.viewPeriodMode ?? ViewPeriodMode.calendar,
                      onChanged: (ViewPeriodMode? mode) {
                        if (_selectedAccountId == null || mode == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          viewPeriodMode: mode,
                        );
                      },
                      items: const [
                        DropdownMenuItem<ViewPeriodMode>(
                          value: ViewPeriodMode.calendar,
                          child: Text('Calendar'),
                        ),
                        DropdownMenuItem<ViewPeriodMode>(
                          value: ViewPeriodMode.paycheck,
                          child: Text('Paycheck'),
                        ),
                      ],
                    ),
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['Planner View', 'Month', 'Grid', 'Sheet'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  String subtitle;
                  switch (selectedAccount?.plannerViewMode) {
                    case PlannerViewMode.grid:
                      subtitle = 'Multi-month Grid';
                      break;
                    case PlannerViewMode.sheet:
                      subtitle = 'Spreadsheet';
                      break;
                    default:
                      subtitle = 'Single Month';
                  }
                  return _OptionsTile(
                    icon: Icons.view_module,
                    title: 'Planner View Mode',
                    subtitle: subtitle,
                    trailing: _OptionsDropdown<PlannerViewMode>(
                      value: selectedAccount?.plannerViewMode ?? PlannerViewMode.month,
                      onChanged: (PlannerViewMode? mode) {
                        if (_selectedAccountId == null || mode == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          plannerViewMode: mode,
                        );
                      },
                      items: const [
                        DropdownMenuItem<PlannerViewMode>(
                          value: PlannerViewMode.month,
                          child: Text('Month'),
                        ),
                        DropdownMenuItem<PlannerViewMode>(
                          value: PlannerViewMode.grid,
                          child: Text('Grid'),
                        ),
                        DropdownMenuItem<PlannerViewMode>(
                          value: PlannerViewMode.sheet,
                          child: Text('Sheet'),
                        ),
                      ],
                    ),
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['Business Day Adjust', 'Weekend', 'Paycheck'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  return _OptionsTile(
                    icon: Icons.work_outline,
                    title: 'Business Day Adjust',
                    subtitle: selectedAccount?.paycheckBusinessAdjust == true
                        ? 'Adjust if payday falls on weekend'
                        : 'Off',
                    trailing: Switch(
                      value: selectedAccount?.paycheckBusinessAdjust ?? false,
                      onChanged: (bool value) {
                        if (_selectedAccountId == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          paycheckBusinessAdjust: value,
                        );
                      },
                      activeTrackColor: palette.theme,
                    ),
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['Adjust Direction', 'Before', 'After', 'Paycheck'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  return _OptionsTile(
                    icon: Icons.swap_horiz,
                    title: 'Adjust Direction',
                    subtitle: selectedAccount?.paycheckBusinessAdjustDirection == PaycheckAdjustDirection.before 
                        ? 'Pay before weekend'
                        : 'Pay after weekend',
                    trailing: _OptionsDropdown<PaycheckAdjustDirection>(
                      value: selectedAccount?.paycheckBusinessAdjustDirection ?? PaycheckAdjustDirection.before,
                      onChanged: (PaycheckAdjustDirection? dir) {
                        if (_selectedAccountId == null || dir == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          paycheckBusinessAdjustDirection: dir,
                        );
                      },
                      items: const [
                        DropdownMenuItem<PaycheckAdjustDirection>(
                          value: PaycheckAdjustDirection.before,
                          child: Text('Before'),
                        ),
                        DropdownMenuItem<PaycheckAdjustDirection>(
                          value: PaycheckAdjustDirection.after,
                          child: Text('After'),
                        ),
                      ],
                    ),
                  );
                }),
              ),
              _SearchableOption(
                keywords: ['Future Balance', 'Zero Baseline', 'Projected', 'Starting Balance'],
                widget: Builder(builder: (context) {
                  final selectedAccount = _selectedAccountId != null
                      ? store.getAccountById(_selectedAccountId!)
                      : null;
                  final useZero = selectedAccount?.plannerUseZeroBaseline ?? false;
                  
                  return _OptionsTile(
                    icon: Icons.auto_graph,
                    title: 'Future Month Balance',
                    subtitle: useZero 
                        ? 'Start from zero (\$0)' 
                        : 'Use projected balance',
                    trailing: _OptionsDropdown<bool>(
                      value: useZero,
                      onChanged: (bool? val) {
                        if (_selectedAccountId == null || val == null) return;
                        store.updateAccountSettings(
                          _selectedAccountId!,
                          plannerUseZeroBaseline: val,
                        );
                      },
                      items: const [
                        DropdownMenuItem<bool>(
                          value: false,
                          child: Text('Projected Balance'),
                        ),
                        DropdownMenuItem<bool>(
                          value: true,
                          child: Text('Zero (\$0)'),
                        ),
                      ],
                    ),
                  );
                }),
              ),
            ],
          ),
        ];

        final filtered = <Widget>[];
        for (final section in sections) {
          final visibleOptions = section.getVisibleOptions(_searchQuery);
          if (visibleOptions.isNotEmpty) {
            filtered.add(
              _OptionsSection(
                title: section.title,
                icon: section.icon,
                padding: EdgeInsets.zero,
                child: Column(
                  children: _withDividers(
                    visibleOptions.map((o) => o.widget).toList(),
                    palette,
                  ),
                ),
              ),
            );
            filtered.add(const SizedBox(height: 20));
          }
        }

        return Scaffold(
          backgroundColor: palette.backgroundBottom,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: const BackButton(),
          ),
          body: Stack(
            children: [
              const _OptionsBackdrop(),
              SafeArea(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                  children: [
                    _OptionsHeader(
                      title: l10n.optionsTitle,
                    ),
                    const SizedBox(height: 16),
                    _SearchField(
                      controller: _searchController,
                      onChanged: (val) {
                        setState(() {
                          _searchQuery = val;
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    ...filtered,
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

String _appThemeLabel(AppLocalizations l10n, AppThemePreset preset) {
  switch (preset) {
    case AppThemePreset.classic:
      return l10n.appThemeClassic;
    case AppThemePreset.ocean:
      return l10n.appThemeOcean;
    case AppThemePreset.sunset:
      return l10n.appThemeSunset;
    case AppThemePreset.monochrome:
      return l10n.appThemeMonochrome;
    case AppThemePreset.forest:
      return l10n.appThemeForest;
    case AppThemePreset.berry:
      return 'Berry';
    case AppThemePreset.lavender:
      return 'Lavender';
    case AppThemePreset.midnight:
      return 'Midnight';
    case AppThemePreset.rose:
      return 'Rose';
    case AppThemePreset.mint:
      return 'Mint';
  }
}

List<Widget> _withDividers(List<Widget> children, _OptionsPalette palette) {
  final output = <Widget>[];
  for (var i = 0; i < children.length; i++) {
    if (i > 0) {
      output.add(
        Divider(
          height: 1,
          thickness: 1,
          indent: 64,
          color: palette.border,
        ),
      );
    }
    output.add(children[i]);
  }
  return output;
}

class _OptionsBackdrop extends StatelessWidget {
  const _OptionsBackdrop();

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [palette.backgroundTop, palette.backgroundBottom],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -80,
              left: -40,
              child: _GlowOrb(
                color: palette.glowPrimary,
                size: 220,
              ),
            ),
            Positioned(
              top: 240,
              right: -30,
              child: _GlowOrb(
                color: palette.glowSecondary,
                size: 160,
              ),
            ),
            Positioned(
              bottom: -120,
              right: -60,
              child: _GlowOrb(
                color: palette.glowMuted,
                size: 260,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  const _GlowOrb({
    required this.color,
    required this.size,
  });

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withValues(alpha: 0)],
          ),
        ),
      ),
    );
  }
}

class _OptionsHeader extends StatelessWidget {
  const _OptionsHeader({
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: textTheme.headlineSmall?.copyWith(
            color: palette.textPrimary,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.4,
          ),
        ),
        const SizedBox(height: 14),
        Container(
          width: 52,
          height: 4,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            gradient: LinearGradient(
              colors: [palette.theme, palette.themeSoft],
            ),
          ),
        ),
      ],
    );
  }
}

class _OptionsSection extends StatelessWidget {
  const _OptionsSection({
    required this.title,
    required this.icon,
    required this.child,
    this.padding = const EdgeInsets.symmetric(vertical: 6),
  });

  final String title;
  final IconData icon;
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    palette.surfaceAlt,
                    palette.surface,
                  ],
                ),
                border: Border.all(color: palette.border),
              ),
              child: Icon(
                icon,
                size: 16,
                color: palette.textSecondary,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: textTheme.titleSmall?.copyWith(
                color: palette.textSecondary,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        _OptionsSurface(
          padding: padding,
          child: child,
        ),
      ],
    );
  }
}

class _OptionsSurface extends StatelessWidget {
  const _OptionsSurface({
    required this.child,
    this.padding = const EdgeInsets.symmetric(vertical: 6),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppConstants.radiusSheetTop),
        border: Border.all(color: palette.border),
        gradient: LinearGradient(
          colors: [
            palette.surface,
            palette.surfaceAlt,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: palette.shadow,
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Padding(
        padding: padding,
        child: child,
      ),
    );
  }
}

class _OptionsTile extends StatelessWidget {
  const _OptionsTile({
    required this.title,
    this.subtitle,
    this.trailing,
    this.icon,
    this.iconColor,
    this.onTap,
  });

  final String title;
  final String? subtitle;
  final Widget? trailing;
  final IconData? icon;
  final Color? iconColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    final content = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (icon != null) ...[
            _OptionsLeadingIcon(icon: icon!, color: iconColor),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.titleSmall?.copyWith(
                    color: palette.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    subtitle!,
                    style: textTheme.bodySmall?.copyWith(
                      color: palette.textSecondary,
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );

    if (onTap == null) {
      return content;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
        onTap: onTap,
        child: content,
      ),
    );
  }
}

class _OptionsLeadingIcon extends StatelessWidget {
  const _OptionsLeadingIcon({
    required this.icon,
    this.color,
  });

  final IconData icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final iconColor = color ?? palette.textSecondary;

    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color?.withValues(alpha: 0.3) ?? palette.border),
        gradient: LinearGradient(
          colors: [
            color?.withValues(alpha: 0.15) ?? palette.surfaceAlt,
            color?.withValues(alpha: 0.05) ?? palette.surface,
          ],
        ),
      ),
      child: Icon(
        icon,
        size: 18,
        color: iconColor,
      ),
    );
  }
}

class _OptionsDropdown<T> extends StatelessWidget {
  const _OptionsDropdown({
    required this.value,
    required this.onChanged,
    required this.items,
  });

  final T value;
  final ValueChanged<T?>? onChanged;
  final List<DropdownMenuItem<T>> items;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return DecoratedBox(
      decoration: BoxDecoration(
        color: palette.surfaceAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: palette.border),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<T>(
            value: value,
            onChanged: onChanged,
            items: items,
            isDense: true,
            icon: Icon(
              Icons.expand_more,
              color: palette.textSecondary,
            ),
            dropdownColor: palette.surface,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: palette.textPrimary,
                ),
          ),
        ),
      ),
    );
  }
}

class _PinSetupDialog extends StatefulWidget {
  const _PinSetupDialog({
    required this.title,
    required this.authService,
  });

  final String title;
  final AuthService authService;

  @override
  State<_PinSetupDialog> createState() => _PinSetupDialogState();
}

class _PinSetupDialogState extends State<_PinSetupDialog> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmController = TextEditingController();
  String? _errorMessage;
  bool _isSaving = false;

  @override
  void dispose() {
    _pinController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_isSaving) return;
    final l10n = AppLocalizations.of(context)!;
    final pin = _pinController.text.trim();
    final confirm = _confirmController.text.trim();

    if (pin.length < AuthService.minPinLength) {
      setState(() => _errorMessage = l10n.pinTooShort);
      return;
    }
    if (pin != confirm) {
      setState(() => _errorMessage = l10n.pinsDoNotMatch);
      return;
    }

    setState(() {
      _isSaving = true;
      _errorMessage = null;
    });

    try {
      await widget.authService.setPIN(pin);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isSaving = false;
        _errorMessage = error is ArgumentError
            ? error.message.toString()
            : error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _pinController,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: AuthService.maxPinLength,
            decoration: InputDecoration(
              labelText: l10n.enterPIN,
              errorText: _errorMessage,
              counterText: '', // Hide character count
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _confirmController,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: AuthService.maxPinLength,
            decoration: InputDecoration(
              labelText: l10n.confirmPIN,
              errorText: _errorMessage,
              counterText: '', // Hide character count
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: _isSaving ? null : () => Navigator.pop(context, false),
          child: Text(l10n.cancel),
        ),
        FilledButton(
          onPressed: _isSaving ? null : _submit,
          child: Text(l10n.save),
        ),
      ],
    );
  }
}

class _PinVerifyDialog extends StatefulWidget {
  const _PinVerifyDialog({
    required this.authService,
  });

  final AuthService authService;

  @override
  State<_PinVerifyDialog> createState() => _PinVerifyDialogState();
}

class _PinVerifyDialogState extends State<_PinVerifyDialog> {
  final TextEditingController _pinController = TextEditingController();
  String? _errorMessage;
  bool _isVerifying = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_isVerifying) return;
    final l10n = AppLocalizations.of(context)!;
    final pin = _pinController.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorMessage = l10n.enterPIN);
      return;
    }

    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    final result = await widget.authService.verifyPIN(pin);
    if (!mounted) return;
    if (result == PinVerificationResult.success) {
      Navigator.pop(context, true);
      return;
    }

    setState(() {
      _isVerifying = false;
      _errorMessage = l10n.incorrectPIN;
      _pinController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return AlertDialog(
      title: Text(l10n.enterYourPIN),
      content: TextField(
        controller: _pinController,
        keyboardType: TextInputType.number,
        obscureText: true,
        maxLength: AuthService.maxPinLength,
        decoration: InputDecoration(
          labelText: l10n.pin,
          errorText: _errorMessage,
          counterText: '', // Hide character count
        ),
        onSubmitted: (_) => _verify(),
      ),
      actions: [
        TextButton(
          onPressed: _isVerifying ? null : () => Navigator.pop(context, false),
          child: Text(l10n.cancel),
        ),
        FilledButton(
          onPressed: _isVerifying ? null : _verify,
          child: Text(l10n.verify),
        ),
      ],
    );
  }
}

class RadioListTile<T> extends StatelessWidget {
  const RadioListTile({
    super.key,
    required this.value,
    this.title,
    this.subtitle,
  });

  final T value;
  final Widget? title;
  final Widget? subtitle;

  @override
  Widget build(BuildContext context) {
    final radioGroup = RadioGroup.maybeOf<T>(context);
    if (radioGroup == null) {
      throw StateError('RadioListTile must be used inside a RadioGroup');
    }
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;
    final selected = radioGroup!.groupValue == value;

    return Theme(
      data: Theme.of(context).copyWith(
        radioTheme: RadioThemeData(
          fillColor: WidgetStateProperty.resolveWith(
            (states) => states.contains(WidgetState.selected)
                ? palette.theme
                : palette.textSecondary,
          ),
        ),
      ),
      child: InkWell(
        onTap: () => radioGroup.onChanged(value),
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? palette.selection : palette.surfaceAlt,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? palette.selectionBorder : palette.border,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: palette.shadow,
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Radio<T>(
                value: value,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title != null)
                      DefaultTextStyle(
                        style: (textTheme.titleSmall ?? const TextStyle()).copyWith(
                          color: palette.textPrimary,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        child: title!,
                      ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 4),
                      DefaultTextStyle(
                        style: (textTheme.bodySmall ?? const TextStyle()).copyWith(
                          color: palette.textSecondary,
                        ),
                        child: subtitle!,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PaycheckDayField extends StatefulWidget {
  const _PaycheckDayField({
    required this.initialValue,
    required this.onChanged,
    this.onClearRequested,
  });

  final int? initialValue;
  final ValueChanged<int> onChanged;
  final Future<bool> Function()? onClearRequested;

  @override
  State<_PaycheckDayField> createState() => _PaycheckDayFieldState();
}

class _PaycheckDayFieldState extends State<_PaycheckDayField> {
  late TextEditingController _controller;
  final FocusNode _focusNode = FocusNode();
  int? _lastValidDay;
  bool _isHandlingClear = false;
  bool _isProgrammaticChange = false;

  @override
  void initState() {
    super.initState();
    _lastValidDay = widget.initialValue;
    _controller = TextEditingController(
      text: widget.initialValue != null ? '${widget.initialValue}' : '',
    );
    _focusNode.addListener(_handleFocusChange);
  }

  @override
  void didUpdateWidget(_PaycheckDayField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialValue != widget.initialValue) {
      _lastValidDay = widget.initialValue;
      _controller.text = widget.initialValue != null ? '${widget.initialValue}' : '';
    }
  }

  @override
  void dispose() {
    _focusNode.removeListener(_handleFocusChange);
    _focusNode.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _handleFocusChange() {
    if (!_focusNode.hasFocus) {
      _handleClearAttemptIfEmpty();
    }
  }

  void _handleClearAttemptIfEmpty() {
    if (_controller.text.trim().isNotEmpty) return;
    _handleClearAttempt();
  }

  Future<void> _handleClearAttempt() async {
    if (_isHandlingClear) return;
    _isHandlingClear = true;
    final allowClear = await (widget.onClearRequested?.call() ?? Future.value(false));
    if (!mounted) return;

    if (!allowClear) {
      _restoreLastValid();
    } else {
      _lastValidDay = null;
      _setText('');
    }
    _isHandlingClear = false;
  }

  void _restoreLastValid() {
    final text = _lastValidDay != null ? '$_lastValidDay' : '';
    _setText(text);
  }

  void _setText(String value) {
    _isProgrammaticChange = true;
    _controller.text = value;
    _controller.selection = TextSelection.fromPosition(
      TextPosition(offset: value.length),
    );
    _isProgrammaticChange = false;
  }

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: palette.border),
    );

    return TextField(
      decoration: InputDecoration(
        labelText: 'Payday (day of month)',
        hintText: 'Enter 1-31',
        helperText: r'Required to use Paycheck Period mode.' '\nExample: payday 25th means "January" period runs Dec 25 – Jan 24.',
        helperMaxLines: 3,
        border: border,
        enabledBorder: border,
        focusedBorder: border.copyWith(
          borderSide: BorderSide(color: palette.theme),
        ),
        filled: true,
        fillColor: palette.surfaceAlt,
      ),
      keyboardType: TextInputType.number,
      controller: _controller,
      focusNode: _focusNode,
      style: textTheme.bodyMedium?.copyWith(
        color: palette.textPrimary,
      ),
      onChanged: (value) {
        if (_isProgrammaticChange) return;
        if (value.trim().isEmpty) {
          return;
        }
        final day = int.tryParse(value);
        if (day != null && day >= 1 && day <= 31) {
          _lastValidDay = day;
          widget.onChanged(day);
        }
      },
    );
  }
}

class _OptionsPalette {
  const _OptionsPalette({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.surface,
    required this.surfaceAlt,
    required this.border,
    required this.theme,
    required this.themeSoft,
    required this.textPrimary,
    required this.textSecondary,
    required this.shadow,
    required this.glowPrimary,
    required this.glowSecondary,
    required this.glowMuted,
    required this.chip,
    required this.chipBorder,
    required this.selection,
    required this.selectionBorder,
  });

  final Color backgroundTop;
  final Color backgroundBottom;
  final Color surface;
  final Color surfaceAlt;
  final Color border;
  final Color theme;
  final Color themeSoft;
  final Color textPrimary;
  final Color textSecondary;
  final Color shadow;
  final Color glowPrimary;
  final Color glowSecondary;
  final Color glowMuted;
  final Color chip;
  final Color chipBorder;
  final Color selection;
  final Color selectionBorder;

  static _OptionsPalette of(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // All colors are now derived from the theme's ColorScheme
    // This ensures the Options screen reflects the selected app theme
    final backgroundTop = scheme.surface;
    final backgroundBottom = scheme.surfaceContainerLowest;
    final surface = scheme.surfaceContainerHigh;
    final surfaceAlt = scheme.surfaceContainerHighest;
    final border = isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.08);
    final primaryColor = scheme.primary;
    final themeSoft = scheme.primary.withValues(alpha: isDark ? 0.28 : 0.18);
    final textPrimary = scheme.onSurface;
    final textSecondary = scheme.onSurfaceVariant;
    final shadow = isDark ? Colors.black.withValues(alpha: 0.35) : Colors.black.withValues(alpha: 0.08);
    final glowPrimary = scheme.primary.withValues(alpha: isDark ? 0.35 : 0.2);
    final glowSecondary = scheme.tertiary.withValues(alpha: isDark ? 0.25 : 0.16);
    final glowMuted = scheme.secondary.withValues(alpha: isDark ? 0.2 : 0.12);
    final chip = scheme.surfaceContainerLow;
    final chipBorder = isDark ? Colors.white.withValues(alpha: 0.1) : Colors.black.withValues(alpha: 0.08);
    final selection = scheme.primary.withValues(alpha: isDark ? 0.18 : 0.12);
    final selectionBorder = scheme.primary.withValues(alpha: isDark ? 0.5 : 0.4);

    return _OptionsPalette(
      backgroundTop: backgroundTop,
      backgroundBottom: backgroundBottom,
      surface: surface,
      surfaceAlt: surfaceAlt,
      border: border,
      theme: primaryColor,
      themeSoft: themeSoft,
      textPrimary: textPrimary,
      textSecondary: textSecondary,
      shadow: shadow,
      glowPrimary: glowPrimary,
      glowSecondary: glowSecondary,
      glowMuted: glowMuted,
      chip: chip,
      chipBorder: chipBorder,
      selection: selection,
      selectionBorder: selectionBorder,
    );
  }
}

/// A small widget showing the two colors of a preset side by side.
class _ColorPresetPreview extends StatelessWidget {
  const _ColorPresetPreview({required this.preset});

  final ColorPreset preset;

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final colors = settings.presetColors[preset]!;
    // ignore: deprecated_member_use
    final debitColor = Color(colors.$1);
    // ignore: deprecated_member_use
    final creditColor = Color(colors.$2);
    // ignore: deprecated_member_use
    final neutralColor = Color(colors.$3);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 12,
          decoration: BoxDecoration(
            color: debitColor,
            borderRadius: const BorderRadius.horizontal(left: Radius.circular(4)),
          ),
        ),
        Container(
          width: 8,
          height: 12,
          color: neutralColor,
        ),
        Container(
          width: 8,
          height: 12,
          decoration: BoxDecoration(
            color: creditColor,
            borderRadius: const BorderRadius.horizontal(right: Radius.circular(4)),
          ),
        ),
      ],
    );
  }
}

class _AppThemePreview extends StatelessWidget {
  const _AppThemePreview({required this.preset});

  final AppThemePreset preset;

  @override
  Widget build(BuildContext context) {
    // Hardcoded mapping for UI preview to match what's in AppSettingsStore private map
    final color = switch (preset) {
      AppThemePreset.classic => Colors.indigo,
      AppThemePreset.ocean => Colors.teal,
      AppThemePreset.sunset => Colors.deepOrange,
      AppThemePreset.monochrome => Colors.blueGrey,
      AppThemePreset.forest => Colors.green,
      AppThemePreset.berry => const Color(0xFFE91E63),
      AppThemePreset.lavender => const Color(0xFF9C27B0),
      AppThemePreset.midnight => const Color(0xFF1565C0),
      AppThemePreset.rose => const Color(0xFFFF6F61),
      AppThemePreset.mint => const Color(0xFF26A69A),
    };

    return Container(
      width: 24,
      height: 12,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(AppConstants.radiusXSmall),
      ),
    );
  }
}

/// A tappable color swatch for displaying and editing a color.
class _ColorSwatch extends StatelessWidget {
  const _ColorSwatch({
    required this.color,
    required this.onTap,
  });

  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          border: Border.all(
            color: isDark
                ? Colors.white.withValues(alpha: 0.2)
                : Colors.black.withValues(alpha: 0.1),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Icon(
          Icons.edit,
          size: 16,
          color: _contrastColor(color),
        ),
      ),
    );
  }

  /// Returns white or black based on the luminance of the given color.
  Color _contrastColor(Color color) {
    final luminance = color.computeLuminance();
    return luminance > 0.5 ? Colors.black : Colors.white;
  }
}

/// Shows a color picker dialog.
void _showColorPicker(
  BuildContext context,
  Color currentColor,
  ValueChanged<Color> onColorChanged,
  String title,
) {
  showDialog(
    context: context,
    builder: (context) => _ColorPickerDialog(
      currentColor: currentColor,
      onColorChanged: onColorChanged,
      title: title,
    ),
  );
}

/// A simple color picker dialog with preset colors and HSL sliders.
class _ColorPickerDialog extends StatefulWidget {
  const _ColorPickerDialog({
    required this.currentColor,
    required this.onColorChanged,
    required this.title,
  });

  final Color currentColor;
  final ValueChanged<Color> onColorChanged;
  final String title;

  @override
  State<_ColorPickerDialog> createState() => _ColorPickerDialogState();
}

class _ColorPickerDialogState extends State<_ColorPickerDialog> {
  late HSVColor _hsvColor;

  // Preset colors for quick selection
  static const List<Color> _presetColors = [
    Color(0xFFE53935), // Red
    Color(0xFFD81B60), // Pink
    Color(0xFF8E24AA), // Purple
    Color(0xFF5E35B1), // Deep Purple
    Color(0xFF3949AB), // Indigo
    Color(0xFF1E88E5), // Blue
    Color(0xFF039BE5), // Light Blue
    Color(0xFF00ACC1), // Cyan
    Color(0xFF00897B), // Teal
    Color(0xFF43A047), // Green
    Color(0xFF7CB342), // Light Green
    Color(0xFFC0CA33), // Lime
    Color(0xFFFDD835), // Yellow
    Color(0xFFFFB300), // Amber
    Color(0xFFFB8C00), // Orange
    Color(0xFFF4511E), // Deep Orange
    Color(0xFF6D4C41), // Brown
    Color(0xFF757575), // Gray
  ];

  @override
  void initState() {
    super.initState();
    _hsvColor = HSVColor.fromColor(widget.currentColor);
  }

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final selectedColor = _hsvColor.toColor();

    return AlertDialog(
      backgroundColor: palette.surface,
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current color preview
            Center(
              child: Container(
                width: 80,
                height: 80,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: selectedColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: palette.border, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: selectedColor.withValues(alpha: 0.5),
                      blurRadius: 16,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
            // Preset colors grid
            Text(
              'Presets',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: palette.textSecondary,
                  ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _presetColors.map((color) {
                final isSelected = selectedColor.value == color.value;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _hsvColor = HSVColor.fromColor(color);
                    });
                  },
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isSelected ? Colors.white : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? const Icon(Icons.check, size: 18, color: Colors.white)
                        : null,
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            // HSL Sliders
            Text(
              'Custom',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: palette.textSecondary,
                  ),
            ),
            const SizedBox(height: 8),
            // Hue slider
            _buildSliderRow(
              'H',
              _hsvColor.hue,
              360,
              (v) => setState(() => _hsvColor = _hsvColor.withHue(v)),
              _buildHueGradient(),
            ),
            // Saturation slider
            _buildSliderRow(
              'S',
              _hsvColor.saturation * 100,
              100,
              (v) => setState(() => _hsvColor = _hsvColor.withSaturation(v / 100)),
              LinearGradient(
                colors: [
                  HSVColor.fromAHSV(1, _hsvColor.hue, 0, _hsvColor.value).toColor(),
                  HSVColor.fromAHSV(1, _hsvColor.hue, 1, _hsvColor.value).toColor(),
                ],
              ),
            ),
            // Value/Brightness slider
            _buildSliderRow(
              'V',
              _hsvColor.value * 100,
              100,
              (v) => setState(() => _hsvColor = _hsvColor.withValue(v / 100)),
              LinearGradient(
                colors: [
                  Colors.black,
                  HSVColor.fromAHSV(1, _hsvColor.hue, _hsvColor.saturation, 1).toColor(),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: () {
            widget.onColorChanged(selectedColor);
            Navigator.of(context).pop();
          },
          child: Text(AppLocalizations.of(context)!.save),
        ),
      ],
    );
  }

  Widget _buildSliderRow(
    String label,
    double value,
    double max,
    ValueChanged<double> onChanged,
    Gradient gradient,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 20,
            child: Text(
              label,
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 16,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
                trackShape: _GradientTrackShape(gradient: gradient),
              ),
              child: Slider(
                value: value,
                min: 0,
                max: max,
                onChanged: onChanged,
              ),
            ),
          ),
          SizedBox(
            width: 36,
            child: Text(
              value.toInt().toString(),
              style: Theme.of(context).textTheme.labelSmall,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Gradient _buildHueGradient() {
    return const LinearGradient(
      colors: [
        Color.fromARGB(255, 255, 0, 0),
        Color.fromARGB(255, 255, 255, 0),
        Color.fromARGB(255, 0, 255, 0),
        Color.fromARGB(255, 0, 255, 255),
        Color.fromARGB(255, 0, 0, 255),
        Color.fromARGB(255, 255, 0, 255),
        Color.fromARGB(255, 255, 0, 0),
      ],
    );
  }
}

/// Singleton notifier for screenshot protection state changes.
///
/// This allows the options screen to notify the app when the screenshot
/// protection setting changes, without tight coupling.
class _ScreenshotProtectionNotifier {
  _ScreenshotProtectionNotifier._();

  static final _ScreenshotProtectionNotifier instance = _ScreenshotProtectionNotifier._();

  final List<void Function(bool)> _listeners = [];

  void addListener(void Function(bool) listener) {
    _listeners.add(listener);
  }

  void removeListener(void Function(bool) listener) {
    _listeners.remove(listener);
  }

  void notify(bool enabled) {
    for (final listener in _listeners) {
      listener(enabled);
    }
  }
}

/// Public getter for screenshot protection notifier.
/// Used by app.dart to listen for changes.
// ignore: library_private_types_in_public_api
_ScreenshotProtectionNotifier get screenshotProtectionNotifier =>
    _ScreenshotProtectionNotifier.instance;

/// A custom slider track shape that renders a gradient background.
class _GradientTrackShape extends RoundedRectSliderTrackShape {
  const _GradientTrackShape({required this.gradient});

  final Gradient gradient;

  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required Offset thumbCenter,
    Offset? secondaryOffset,
    bool isDiscrete = false,
    bool isEnabled = false,
    double additionalActiveTrackHeight = 0,
  }) {
    final trackHeight = sliderTheme.trackHeight ?? 4;
    final trackLeft = offset.dx;
    final trackTop = offset.dy + (parentBox.size.height - trackHeight) / 2;
    final trackWidth = parentBox.size.width;

    final trackRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(trackLeft, trackTop, trackWidth, trackHeight),
      Radius.circular(trackHeight / 2),
    );

    final paint = Paint()
      ..shader = gradient.createShader(trackRect.outerRect);

    context.canvas.drawRRect(trackRect, paint);
  }
}

class _SearchableOption {
  final Widget widget;
  final List<String> keywords;

  const _SearchableOption({
    required this.widget,
    required this.keywords,
  });

  bool matches(String query) {
    if (query.isEmpty) return true;
    final lowerQuery = query.toLowerCase();
    return keywords.any((k) => k.toLowerCase().contains(lowerQuery));
  }
}

class _SearchableSection {
  final String title;
  final IconData icon;
  final List<_SearchableOption> options;

  const _SearchableSection({
    required this.title,
    required this.icon,
    required this.options,
  });

  List<_SearchableOption> getVisibleOptions(String query) {
    if (query.isEmpty) return options;
    return options.where((opt) => opt.matches(query)).toList();
  }
}

class _SearchField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  const _SearchField({
    required this.controller,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: 'Search settings...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: Theme.of(context)
              .colorScheme
              .surfaceContainerHighest
              .withOpacity(0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16),
        ),
      ),
    );
  }
}

class _BalanceEditDialog extends StatefulWidget {
  const _BalanceEditDialog({
    required this.currentValueCents,
    required this.settings,
  });

  final int currentValueCents;
  final AppSettingsStore settings;

  @override
  State<_BalanceEditDialog> createState() => _BalanceEditDialogState();
}

class _BalanceEditDialogState extends State<_BalanceEditDialog> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(
      text: (widget.currentValueCents / 100).toStringAsFixed(2),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Starting Balance'),
      content: TextField(
        controller: _controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        decoration: InputDecoration(
          prefixText: currencySymbol(widget.settings.currencySettings.currency),
          hintText: '0.00',
        ),
        autofocus: true,
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () {
            final text = _controller.text.replaceAll(',', '.');
            final parsed = double.tryParse(text);
            if (parsed != null) {
              Navigator.pop(context, (parsed * 100).round());
            } else {
              Navigator.pop(context);
            }
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}


