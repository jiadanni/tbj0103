import 'package:flutter/material.dart';


import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';

import 'package:expense_stalker_mobile/src/util/terminology.dart';

import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

import 'package:expense_stalker_mobile/src/widgets/upsert_planner_item_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/update_payment_sheet.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/planner_dates.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

/// Maximum number of days before or after the due date for fuzzy payment matching.
/// 
/// When a payment has no explicit link to a planner item, it can still be matched
/// if the label and amount match AND the payment date is within this window of
/// the expected due date. This prevents false matches across periods while allowing
/// for reasonable payment date variance.
const int kFuzzyMatchWindowDays = 5;

DismissDirection? dismissDirection({
  required PlannerSwipeAction left,
  required PlannerSwipeAction right,
}) {
  final leftEnabled = left != PlannerSwipeAction.off;
  final rightEnabled = right != PlannerSwipeAction.off;
  if (!leftEnabled && !rightEnabled) return null;
  if (leftEnabled && rightEnabled) return DismissDirection.horizontal;
  if (leftEnabled) return DismissDirection.endToStart;
  return DismissDirection.startToEnd;
}

Widget dismissBackground(
  BuildContext context, {
  required PlannerSwipeAction action,
  required bool alignLeft,
  bool isRecorded = false,
}) {
  if (action == PlannerSwipeAction.off) return const SizedBox.shrink();
  final isEdit = action == PlannerSwipeAction.edit;

  // For archive action, show different UI based on whether item is already recorded
  final bool isUnrecording = !isEdit && isRecorded;

  final bg = isEdit
      ? Theme.of(context).colorScheme.primaryContainer
      : isUnrecording
          ? Theme.of(context).colorScheme.tertiaryContainer
          : Theme.of(context).colorScheme.secondaryContainer;
  final fg = isEdit
      ? Theme.of(context).colorScheme.onPrimaryContainer
      : isUnrecording
          ? Theme.of(context).colorScheme.onTertiaryContainer
          : Theme.of(context).colorScheme.onSecondaryContainer;
  final terminology = Terminology.of(context);
  final label = isEdit
      ? AppLocalizations.of(context)!.edit
      : isUnrecording
          ? terminology.unmarkActionLabel
          : terminology.markActionLabel;
  final icon = isEdit
      ? Icons.edit_outlined
      : isUnrecording
          ? Icons.undo_outlined
          : Icons.check_circle_outline;
  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

enum _PlannerItemMenuAction { archive, editSeries, editPayment }

Future<bool> handleSwipeAction(
  BuildContext context,
  PlannerItem item,
  PlannerSwipeAction action,
) async {
  final store = ExpenseStoreScope.read(context);
  final settings = AppSettingsScope.read(context);
  switch (action) {
    case PlannerSwipeAction.off:
      return false;
    case PlannerSwipeAction.edit:
      final result = await showModalBottomSheet<PlannerItem>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpsertPlannerItemSheet(
          existing: item,
          defaultStartDate: store.selectedMonth,
        ),
      );
      if (result != null) store.upsertPlannerItem(result);
      return false;
    case PlannerSwipeAction.archive:
      final month = store.selectedMonth;
      // Get period info for proper payment filtering in paycheck mode
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      final existing = findPaymentForItemInMonth(
        item: item,
        payments: store.paymentsForMonth(month, periodInfo: periodInfo),
        month: month,
        settings: settings,
      );

      // If already recorded, allow unrecording (toggle behavior)
      if (existing != null) {
        store.deletePayment(existing.id);
        store.clearPlannerItemClearedTemporarily(item.id);
        settings.currentBalanceCents -= existing.amountMinorUnits;

        // Revert Money Pot balance if linked
        if (existing.moneyPotId != null) {
           final pot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
             (p) => p?.id == existing.moneyPotId,
             orElse: () => null,
           );
           if (pot != null) {
             final newBalance = pot.amountMinorUnits + existing.amountMinorUnits;
             await settings.updateMoneyPot(pot.copyWith(
               amountMinorUnits: newBalance,
             ));
             if (item.moneyPotId == existing.moneyPotId) {
                store.upsertPlannerItem(item.copyWith(remainingBalanceMinorUnits: newBalance));
             }
           }
        } else if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null) {
           // Direct PlannerItem Balance Revert (No Money Pot linked)
           final newBalance = item.remainingBalanceMinorUnits! + existing.amountMinorUnits;
           store.upsertPlannerItem(item.copyWith(remainingBalanceMinorUnits: newBalance));
        }

        if (context.mounted) {
          final messenger = ScaffoldMessenger.of(context);
          messenger.removeCurrentSnackBar();
          messenger.showSnackBar(
            SnackBar(
              content: Text(
                AppLocalizations.of(context)!.unrecordedLabel(item.label),
              ),
              duration: AppConstants.snackBarShort,
              action: SnackBarAction(
                label: AppLocalizations.of(context)!.undo,
                onPressed: () async {
                  settings.currentBalanceCents += existing.amountMinorUnits;
                  store.upsertPayment(existing);
                  store.markPlannerItemClearedTemporarily(item.id);
                  // Re-apply Money Pot reduction
                  if (existing.moneyPotId != null) {
                    final pot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
                      (p) => p?.id == existing.moneyPotId,
                      orElse: () => null,
                    );
                    if (pot != null) {
                      final newBalance = pot.amountMinorUnits - existing.amountMinorUnits;
                      await settings.updateMoneyPot(pot.copyWith(
                        amountMinorUnits: newBalance,
                      ));
                      if (item.moneyPotId == existing.moneyPotId) {
                         store.upsertPlannerItem(item.copyWith(remainingBalanceMinorUnits: newBalance));
                      }
                    }
                  } else if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null) {
                     // Direct PlannerItem Balance Revert (No Money Pot linked)
                     final newBalance = item.remainingBalanceMinorUnits! + existing.amountMinorUnits;
                     store.upsertPlannerItem(item.copyWith(remainingBalanceMinorUnits: newBalance));
                  }
                },
              ),
            ),
          );
        }
        return false;
      }

      // Calculate scheduled date for this period
      final effectiveDay = effectiveDayOfMonth(item.dayOfMonth, month);
      final scheduledDate = DateTime.utc(month.year, month.month, effectiveDay);

      final payment = PaymentEntry(
        id: newEntryId(),
        label: item.label,
        amountMinorUnits: item.amountMinorUnits,
        date: archiveDateForPeriod(periodInfo),  // actual date
        type: item.type,
        plannerItemId: item.id,
        scheduledDate: scheduledDate,             // scheduled date
        scheduledAmountMinorUnits: item.amountMinorUnits,   // scheduled amount
        moneyPotId: item.moneyPotId,              // inherit default pot from item
      );
      final confirmedPayment = await showModalBottomSheet<PaymentEntry>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) {
          final terminology = Terminology.of(context);
          return UpdatePaymentSheet(
            payment: payment,
            title: terminology.markActionLabel,
            confirmButtonLabel: terminology.markActionLabel,
            showMoneyPotSelector: false,
          );
        },
      );

      if (confirmedPayment == null) {
        return false;
      }

      store.upsertPayment(confirmedPayment);
      store.markPlannerItemClearedTemporarily(item.id);
      settings.currentBalanceCents += confirmedPayment.amountMinorUnits;
      
      // Apply Money Pot reduction (if confirmed payment has a linked pot)
      if (confirmedPayment.moneyPotId != null) {
        final pot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
          (p) => p?.id == confirmedPayment.moneyPotId,
          orElse: () => null,
        );
        if (pot != null) {
          final newBalance = pot.amountMinorUnits - confirmedPayment.amountMinorUnits;
          await settings.updateMoneyPot(pot.copyWith(
             amountMinorUnits: newBalance,
          ));

          // Sync PlannerItem to new Pot Balance
          if (item.moneyPotId == confirmedPayment.moneyPotId && item.type == PaymentType.debt) {
             // Auto-set paidOffDate when debt is fully paid
             final updatedItem = item.copyWith(
               remainingBalanceMinorUnits: newBalance,
               paidOffDate: newBalance <= 0 ? DateTime.now() : null,
             );
             store.upsertPlannerItem(updatedItem);
          }
        }
      } else if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null) {
          // Direct PlannerItem Balance Update (No Money Pot linked)
          final newBalance = item.remainingBalanceMinorUnits! - confirmedPayment.amountMinorUnits;
          // Auto-set paidOffDate when debt is fully paid
          final updatedItem = item.copyWith(
            remainingBalanceMinorUnits: newBalance,
            paidOffDate: newBalance <= 0 ? DateTime.now() : null,
          );
          store.upsertPlannerItem(updatedItem);
      }

      if (context.mounted) {
        final messenger = ScaffoldMessenger.of(context);
        messenger.removeCurrentSnackBar();
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              AppLocalizations.of(context)!.recordedLabel(item.label),
            ),
            duration: AppConstants.snackBarShort,
            action: SnackBarAction(
              label: AppLocalizations.of(context)!.undo,
              onPressed: () async {
                settings.currentBalanceCents -= confirmedPayment.amountMinorUnits;
                store.deletePayment(confirmedPayment.id);
                store.clearPlannerItemClearedTemporarily(item.id);
                // Revert Money Pot reduction
                if (confirmedPayment.moneyPotId != null) {
                    final pot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
                      (p) => p?.id == confirmedPayment.moneyPotId,
                      orElse: () => null,
                    );
                    if (pot != null) {
                      await settings.updateMoneyPot(pot.copyWith(
                        amountMinorUnits: pot.amountMinorUnits + confirmedPayment.amountMinorUnits,
                      ));
                    }
                }
              },
            ),
          ),
        );
      }
      return false;
  }
}

Future<void> showPlannerItemMenu({
  required BuildContext context,
  required PlannerItem item,
  required DateTime month,
  required Offset position,
  required bool canArchive,
}) async {
  final overlay = Overlay.of(context).context.findRenderObject() as RenderBox?;
  if (overlay == null) return;
  final store = ExpenseStoreScope.read(context);
  final settings = AppSettingsScope.read(context);
  final localizations = AppLocalizations.of(context)!;
  final theme = Theme.of(context);
  final textTheme = theme.textTheme;
  final effectiveDay = effectiveDayOfMonth(item.dayOfMonth, month);

  // Check if item is already paid to show "Edit Payment" option
  // Note: logic duplicated from handleSwipeAction to determine state
  final periodInfo = PaycheckService.getPeriodInfo(
    month,
    settings.viewPeriodMode,
    settings.paycheckDay,
    businessAdjust: settings.paycheckBusinessAdjust,
    adjustDirection: settings.paycheckBusinessAdjustDirection,
  );
  final existingPayment = findPaymentForItemInMonth(
    item: item,
    payments: store.paymentsForMonth(month, periodInfo: periodInfo),
    month: month,
    settings: settings,
  );
  final isPaid = existingPayment != null;


  // Format the full due date with month and year
  final dueDate = DateTime.utc(month.year, month.month, effectiveDay);
  final months = const <String>[
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  final formattedDate = '${formatDayOfMonth(effectiveDay, settings.dayFormat)} ${months[dueDate.month - 1]} ${dueDate.year}';
  final dueText = '${localizations.dueLabel} $formattedDate';

  final headerWidgets = <Widget>[
    Text(
      item.label,
      style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
    ),
    const SizedBox(height: 6),
    Text(
      formatMoneyFromCents(item.amountMinorUnits, settings.currency, showCents: settings.showCents),
      style: textTheme.bodyMedium?.copyWith(
        fontFeatures: const [FontFeature.tabularFigures()],
      ),
    ),
    const SizedBox(height: 6),
    Text(dueText, style: textTheme.bodySmall),
  ];
  if (item.frequency != null) {
    headerWidgets.add(
      Text(
        '${localizations.frequencyLabel} ${item.frequency!.label}',
        style: textTheme.bodySmall,
      ),
    );
  }
  // Show Actual vs Scheduled info if paid
  if (isPaid && existingPayment.amountMinorUnits != item.amountMinorUnits) {
     headerWidgets.add(const SizedBox(height: 6));
     headerWidgets.add(
      Text(
        'Actual: ${formatMoneyFromCents(existingPayment.amountMinorUnits, settings.currency, showCents: settings.showCents)}',
        style: textTheme.bodySmall?.copyWith(
          color: existingPayment.amountMinorUnits != item.amountMinorUnits 
              ? theme.colorScheme.error 
              : theme.colorScheme.primary,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  headerWidgets.add(
    Text(
      item.type.label,
      style: textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500),
    ),
  );
  final notes = item.notes?.trim();
  if (notes != null && notes.isNotEmpty) {
    headerWidgets.add(const SizedBox(height: 6));
    headerWidgets.add(
      Text(
        notes,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: textTheme.bodySmall?.copyWith(
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }

  final selection = await showMenu<_PlannerItemMenuAction>(
    context: context,
    position: RelativeRect.fromLTRB(
      position.dx,
      position.dy,
      overlay.size.width - position.dx,
      overlay.size.height - position.dy,
    ),
    items: [
      PopupMenuItem<_PlannerItemMenuAction>(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        enabled: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: headerWidgets,
        ),
      ),
      const PopupMenuDivider(),
      // Only show mark as paid option for current period (not future payments)
      // and NOT for spending envelopes (they use quick-spend flow)
      if (canArchive && item.type != PaymentType.spendingEnvelope)
        PopupMenuItem<_PlannerItemMenuAction>(
          value: _PlannerItemMenuAction.archive,
          child: Row(
            children: [
              Icon(isPaid ? Icons.undo_outlined : Icons.check_circle_outline, size: 20),
              const SizedBox(width: 12),
              Text(isPaid 
                  ? Terminology.of(context).unmarkActionLabel 
                  : Terminology.of(context).markActionLabel),
            ],
          ),
        ),
      // Only show "Edit Payment Details" for items that are paid AND in the current period
      // and NOT for spending envelopes
      if (isPaid && canArchive && item.type != PaymentType.spendingEnvelope)
        PopupMenuItem<_PlannerItemMenuAction>(
          value: _PlannerItemMenuAction.editPayment,
          child: Row(
            children: [
              const Icon(Icons.receipt_long_outlined, size: 20),
              const SizedBox(width: 12),
              Text(localizations.editPaymentDetails),
            ],
          ),
        ),
      PopupMenuItem<_PlannerItemMenuAction>(
        value: _PlannerItemMenuAction.editSeries,
        child: Row(
          children: [
            const Icon(Icons.edit_calendar_outlined, size: 20),
            const SizedBox(width: 12),
            // Use terminology preset for consistent labeling
            Text(isPaid ? Terminology.of(context).editItemTitle : localizations.edit),
          ],
        ),
      ),
    ],
  );

  if (!context.mounted || selection == null) return;

  if (selection == _PlannerItemMenuAction.editPayment && existingPayment != null) {
      final oldMoneyPotId = existingPayment.moneyPotId;
      final oldAmount = existingPayment.amountMinorUnits;

      final updated = await showModalBottomSheet<PaymentEntry>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpdatePaymentSheet(
          payment: existingPayment,
          confirmButtonLabel: 'Update',
        ),
      );
      
      if (updated != null && context.mounted) {
         // Balance update logic: remove old amount, add new amount
         settings.currentBalanceCents = settings.currentBalanceCents - existingPayment.amountMinorUnits + updated.amountMinorUnits;
         store.upsertPayment(updated);

         // Handle Money Pot updates
         // 1. If money pot changed or amount changed
         if (oldMoneyPotId != updated.moneyPotId || oldAmount != updated.amountMinorUnits) {
            
            // Revert old pot if existed
            if (oldMoneyPotId != null) {
               final oldPot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
                 (p) => p?.id == oldMoneyPotId,
                 orElse: () => null,
               );
               if (oldPot != null) {
                 // Revert: Add back the amount (since payment reduced it)
                 await settings.updateMoneyPot(oldPot.copyWith(
                   amountMinorUnits: oldPot.amountMinorUnits + oldAmount,
                 ));
               }
            }

            // Apply to new pot if exists
            if (updated.moneyPotId != null) {
               final newPot = settings.moneyPots.cast<MoneyPot?>().firstWhere(
                 (p) => p?.id == updated.moneyPotId,
                 orElse: () => null,
               );
               if (newPot != null) {
                 // Apply: Deduct the amount
                 final newBalance = newPot.amountMinorUnits - updated.amountMinorUnits;
                 await settings.updateMoneyPot(newPot.copyWith(
                   amountMinorUnits: newBalance,
                 ));
                 
                 // Sync PlannerItem (if linked to this new Payee/Pot)
                 if (item.moneyPotId == updated.moneyPotId && item.type == PaymentType.debt) {
                    // Auto-set paidOffDate when debt is fully paid
                    store.upsertPlannerItem(item.copyWith(
                      remainingBalanceMinorUnits: newBalance,
                      paidOffDate: newBalance <= 0 ? DateTime.now() : null,
                    ));
                 }
               }
            }
         } else if (item.type == PaymentType.debt && item.remainingBalanceMinorUnits != null) {
             // Direct Update (No Pot Change, but Amount might have changed)
             // If Pot IS linked, the block above handles it (via Pot update).
             // If Pot is NOT linked (item.moneyPotId == null), we must update manually.
             if (item.moneyPotId == null) {
                 final diff = updated.amountMinorUnits - oldAmount; // + if paid more (debt reduces more) or less?
                 // Debt Balance = OldBalance + OldPayment - NewPayment
                 // actually: Balance is remaining.
                 // Prev Balance = Current + OldPayment.
                 // New Balance = Prev Balance - NewPayment.
                 // New Balance = Current + OldPayment - NewPayment.
                 // New Balance = Current - (NewPayment - OldPayment).
                 // New Balance = Current - diff.

                 final newBalance = item.remainingBalanceMinorUnits! - diff;
                 // Auto-set paidOffDate when debt is fully paid
                 store.upsertPlannerItem(item.copyWith(
                   remainingBalanceMinorUnits: newBalance,
                   paidOffDate: newBalance <= 0 ? DateTime.now() : null,
                 ));
             }
         }
      }
      return;
  }

  final action = selection == _PlannerItemMenuAction.archive
      ? PlannerSwipeAction.archive
      : PlannerSwipeAction.edit;
  if (action == PlannerSwipeAction.archive && !canArchive) return;
  await handleSwipeAction(context, item, action);
}

/// Determines if a payment entry matches a planner item.
///
/// Matching logic (in priority order):
/// 1. **Explicit link**: Payment has plannerItemId matching item's id
/// 2. **Fuzzy match**: Payment has no plannerItemId, but matches label and amount,
///    AND payment date is within the period boundaries and within a reasonable
///    window of the item's due date (prevents matching across periods when there
///    are multiple identical items)
///
/// This prevents ambiguous matching when multiple items have the same label/amount.
bool paymentMatchesPlannerItem(
  PaymentEntry payment,
  PlannerItem item,
  DateTime month,
  AppSettingsStore settings, {
  PeriodInfo? precomputedPeriodInfo,
}) {
  // First, check if payment date is within the period boundaries
  // This applies to both explicit links and fuzzy matches
  final periodInfo = precomputedPeriodInfo ?? PaycheckService.getPeriodInfo(
    month,
    settings.viewPeriodMode,
    settings.paycheckDay,
    businessAdjust: settings.paycheckBusinessAdjust,
    adjustDirection: settings.paycheckBusinessAdjustDirection,
  );

  // Payment must be within period [start, end] (inclusive)
  if (payment.date.isBefore(periodInfo.start) ||
      payment.date.isAfter(periodInfo.end)) {
    return false;
  }

  // Priority 1: Explicit link (payment date already verified to be in period)
  if (payment.plannerItemId != null) {
    return payment.plannerItemId == item.id;
  }

  // Priority 2: Fuzzy match with temporal proximity
  // Only match if:
  // - Label and amount match
  // - Payment date is within ±5 days of the item's expected due date
  if (payment.label == item.label && payment.amountMinorUnits == item.amountMinorUnits) {
    // Calculate expected due date for the item.
    // In paycheck mode, the period can span two calendar months (e.g., Dec 25 - Jan 24).
    // We need to find the due date that falls within the period boundaries.
    final itemDay = item.dayOfMonth;

    // Try the reference month first
    final maxDayInMonth = DateUtils.getDaysInMonth(month.year, month.month);
    final dayInRefMonth = itemDay > maxDayInMonth ? maxDayInMonth : itemDay;
    final dueDateInRefMonth = DateTime.utc(month.year, month.month, dayInRefMonth);

    // Check if the due date in the reference month is within the period
    DateTime expectedDueDate;
    if (!dueDateInRefMonth.isBefore(periodInfo.start) &&
        !dueDateInRefMonth.isAfter(periodInfo.end)) {
      expectedDueDate = dueDateInRefMonth;
    } else {
      // The due date must be in the previous month (for paycheck mode)
      final prevMonth = DateTime.utc(month.year, month.month - 1);
      final maxDayInPrevMonth = DateUtils.getDaysInMonth(prevMonth.year, prevMonth.month);
      final dayInPrevMonth = itemDay > maxDayInPrevMonth ? maxDayInPrevMonth : itemDay;
      expectedDueDate = DateTime.utc(prevMonth.year, prevMonth.month, dayInPrevMonth);
    }

    // Allow ±kFuzzyMatchWindowDays window for fuzzy matching
    final daysDifference = (payment.date.difference(expectedDueDate).inDays)
        .abs();
    
    return daysDifference <= kFuzzyMatchWindowDays;
  }
  
  return false;
}

PaymentEntry? findPaymentForItemInMonth({
  required PlannerItem item,
  required List<PaymentEntry> payments,
  required DateTime month,
  required AppSettingsStore settings,
  PeriodInfo? periodInfo,
}) {
  for (final payment in payments) {
    if (paymentMatchesPlannerItem(payment, item, month, settings, precomputedPeriodInfo: periodInfo)) {
      return payment;
    }
  }
  return null;
}

/// Creates the archive date for a payment in the given period.
///
/// In calendar mode, uses today's date clamped to the reference month.
/// In paycheck mode, uses today's actual date since periods can span months.
/// This ensures the payment date falls within the period boundaries.
DateTime archiveDateForPeriod(PeriodInfo periodInfo) {
  final today = DateTime.now();
  final todayOnly = DateTime.utc(today.year, today.month, today.day);

  // If today is within the period, use today
  if (!todayOnly.isBefore(periodInfo.start) &&
      !todayOnly.isAfter(periodInfo.end)) {
    return todayOnly;
  }

  // If today is before the period start, use the period start
  if (todayOnly.isBefore(periodInfo.start)) {
    return periodInfo.start;
  }

  // If today is after the period end, use the period end
  return periodInfo.end;
}

/// Legacy function - prefer archiveDateForPeriod when period info is available.
@Deprecated('Use archiveDateForPeriod instead')
DateTime archiveDateForMonth(DateTime month) {
  final today = DateTime.now().day;
  final maxDay = DateUtils.getDaysInMonth(month.year, month.month);
  final day = today <= maxDay ? today : maxDay;
  return DateTime.utc(month.year, month.month, day);
}
