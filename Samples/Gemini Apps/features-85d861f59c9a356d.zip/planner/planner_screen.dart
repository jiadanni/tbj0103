import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart' as month_math;
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_helpers.dart';
import 'package:expense_stalker_mobile/src/features/planner/planner_screen_controller.dart';
import 'package:expense_stalker_mobile/src/features/planner/view_mode_builders.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/planner/quick_add_helpers.dart';
import 'package:expense_stalker_mobile/src/features/planner/widgets/grid_zoom_controls.dart';
import 'package:expense_stalker_mobile/src/widgets/account_selector.dart';


class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key, this.viewMode});

  final PlannerViewMode? viewMode;

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> with AutomaticKeepAliveClientMixin {
  // View mode is determined by widget parameter or persisted in AppSettingsStore
  double _lastScale = 1.0;
  bool _hasAdjustedForPaycheckMode = false;
  int _monthWindowSize = PlannerScreenController.monthWindowSize;
  bool _didScheduleInitialMonthSync = false;

  late PlannerScreenController _controller;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    
    final store = ExpenseStoreScope.read(context);
    final earliestMonth = _computeEarliestMonth(store);
    final effectiveSelectedMonth = store.selectedMonth.isBefore(earliestMonth)
        ? earliestMonth
        : store.selectedMonth;

    final initialOrigin = monthOnly(
      month_math.addMonths(
        earliestMonth,
        PlannerScreenController.monthOriginPage,
      ),
    );
    
    final initialPage = PlannerScreenController.monthOriginPage + 
        monthsBetween(initialOrigin, effectiveSelectedMonth);

    _controller = PlannerScreenController(
      monthOrigin: initialOrigin,
      pageController: PageController(initialPage: initialPage),
      sheetTransformController: TransformationController(),
      gridTransformController: TransformationController(),
    );

    // Schedule check for paycheck mode after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _checkAndAdjustForPaycheckMode();
    });
  }

  void _checkAndAdjustForPaycheckMode() {
    if (_hasAdjustedForPaycheckMode || !mounted) return;

    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    // If we're in paycheck mode and it's configured, ensure we're showing the current period
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      final now = DateTime.now();
      final correctMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        now,
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

      // Only update if different from current selected month
      if (store.selectedMonth.year != correctMonth.year ||
          store.selectedMonth.month != correctMonth.month) {
        store.setSelectedMonth(correctMonth);
      }
    }

    _hasAdjustedForPaycheckMode = true;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _setViewMode(AppSettingsStore settings, PlannerViewMode mode) {
    if (settings.plannerViewMode == mode) return;
    settings.plannerViewMode = mode;
    if (mode == PlannerViewMode.grid) {
      _controller.didInitGridTransform = false;
    } else if (mode == PlannerViewMode.sheet) {
      _controller.didInitSheetTransform = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    // Use widget.viewMode if provided (for fixed tabs), otherwise fallback to settings
    final viewMode = widget.viewMode ?? settings.plannerViewMode;

    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final earliestMonth = _computeEarliestMonth(store);
        final effectiveSelectedMonth = store.selectedMonth.isBefore(earliestMonth)
            ? earliestMonth
            : store.selectedMonth;
        final latestMonth = _computeLatestMonth(
          earliestMonth,
          effectiveSelectedMonth,
        );
        final monthWindowSize = monthsBetween(earliestMonth, latestMonth) + 1;
        _monthWindowSize = monthWindowSize;

        final nextOrigin = monthOnly(
          month_math.addMonths(
            earliestMonth,
            PlannerScreenController.monthOriginPage,
          ),
        );
        if (_controller.monthOrigin != nextOrigin) {
          _controller.monthOrigin = nextOrigin;
        }
        _ensureSelectedMonthWithinRange(store, earliestMonth);
        _syncMonthPageIfNeeded(effectiveSelectedMonth, monthWindowSize);
        return ListenableBuilder(
          listenable: settings,
          builder: (context, _) {
            final now = DateTime.now();

            final selectedMonth = effectiveSelectedMonth;
            final selectedMonthOnly = monthOnly(selectedMonth);


            // Determine current period reference month for paycheck mode
            final DateTime currentPeriodMonth;
            if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
                settings.isPaycheckModeConfigured) {
              currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
                now,
                settings.paycheckDay!,
                businessAdjust: settings.paycheckBusinessAdjust,
                adjustDirection: settings.paycheckBusinessAdjustDirection,
              );
            } else {
              currentPeriodMonth = monthOnly(now);
            }

            final isSelectedCurrentPeriod =
                selectedMonthOnly.year == currentPeriodMonth.year &&
                    selectedMonthOnly.month == currentPeriodMonth.month;

            return SafeArea(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Row 1: Account selector + Action Icons
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        AppConstants.paddingMedium,
                        AppConstants.paddingNormal,
                        AppConstants.paddingMedium,
                        0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Flexible(
                            child: AccountSelector(),
                          ),
                          Expanded(
                            child: Center(
                              child: Builder(
                                builder: (context) {
                                  if (viewMode == PlannerViewMode.grid) {
                                    return ListenableBuilder(
                                      listenable: _controller.gridTransformController,
                                      builder: (context, _) {
                                        final currentTargetMonths = _controller.gridTargetMonths;
                                        return GridZoomButtons(
                                          currentMonths: currentTargetMonths,
                                          onChanged: (value) {
                                            setState(() {
                                              _controller.jumpToGridMonths(
                                                targetMonths: value,
                                                monthsBeforeSelected: month_math.monthsBetween(earliestMonth, selectedMonth),
                                              );
                                            });
                                          },
                                        );
                                      },
                                    );
                                  } else if (viewMode == PlannerViewMode.sheet) {
                                    return ListenableBuilder(
                                      listenable: _controller.sheetTransformController,
                                      builder: (context, _) {
                                        final currentStage = _controller.sheetZoomStageForWidth(
                                          _controller.lastSheetViewportWidth ?? 0,
                                        );
                                        return SheetZoomButtons(
                                          currentStage: currentStage,
                                          onChanged: _controller.jumpToZoomStage,
                                        );
                                      },
                                    );
                                  }
                                  return const SizedBox.shrink();
                                },
                              ),
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Visibility toggle
                              if (isSelectedCurrentPeriod && viewMode != PlannerViewMode.sheet)
                                ListenableBuilder(
                                  listenable: settings,
                                  builder: (context, _) {
                                    final showCleared = settings.plannerShowClearedItems;
                                    final terminology = Terminology.of(context);
                                    return SizedBox(
                                      width: 48,
                                      height: 48,
                                      child: IconButton(
                                        tooltip: showCleared
                                            ? terminology.showPaidLabel
                                            : terminology.hidePaidLabel,
                                        onPressed: () =>
                                            settings.plannerShowClearedItems = !showCleared,
                                        icon: Icon(
                                          showCleared
                                              ? Icons.visibility
                                              : Icons.visibility_off,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              // Sort/Options menu
                              SizedBox(
                                width: 48,
                                height: 48,
                                child: PopupMenuButton<void>(
                                  tooltip: AppLocalizations.of(context)!.sortByDate,
                                  icon: const Icon(Icons.sort),
                                  itemBuilder: (context) {
                                    final l10n = AppLocalizations.of(context)!;
                                    return [
                                      PopupMenuItem<void>(
                                        onTap: () => showQuickSpendingFlow(context, store),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.payments_outlined, 
                                              color: Theme.of(context).colorScheme.primary,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 12),
                                            Text(
                                              'Quick Spending',
                                              style: Theme.of(context).textTheme.titleMedium,
                                            ),
                                          ],
                                        ),
                                      ),
                                      const PopupMenuDivider(),
                                      PopupMenuItem<void>(
                                        enabled: false,
                                        child: Text(
                                          l10n.sortByDate,
                                          style: Theme.of(context).textTheme.labelSmall,
                                        ),
                                      ),
                                      CheckedPopupMenuItem<void>(
                                        checked: settings.plannerDateSortMode == PlannerDateSortMode.scheduledDate,
                                        onTap: () => settings.plannerDateSortMode = PlannerDateSortMode.scheduledDate,
                                        child: Text(l10n.sortByScheduled),
                                      ),
                                      CheckedPopupMenuItem<void>(
                                        checked: settings.plannerDateSortMode == PlannerDateSortMode.actualDate,
                                        onTap: () => settings.plannerDateSortMode = PlannerDateSortMode.actualDate,
                                        child: Text(l10n.sortByActual),
                                      ),
                                      const PopupMenuDivider(),
                                      PopupMenuItem<void>(
                                        enabled: false,
                                        child: Text(
                                          l10n.chronological,
                                          style: Theme.of(context).textTheme.labelSmall,
                                        ),
                                      ),
                                      CheckedPopupMenuItem<void>(
                                        checked: settings.plannerSortOrder == PlannerSortOrder.chronological,
                                        onTap: () => settings.plannerSortOrder = PlannerSortOrder.chronological,
                                        child: Text(l10n.chronological),
                                      ),
                                      CheckedPopupMenuItem<void>(
                                        checked: settings.plannerSortOrder == PlannerSortOrder.reverseChronological,
                                        onTap: () => settings.plannerSortOrder = PlannerSortOrder.reverseChronological,
                                        child: Text(l10n.reverseChronological),
                                      ),
                                    ];
                                  },
                                ),
                              ),
                              // Quick Add button
                              if (isSelectedCurrentPeriod)
                                SizedBox(
                                  width: 48,
                                  height: 48,
                                  child: IconButton(
                                    tooltip: 'Quick Add',
                                    onPressed: () => showQuickAddFlow(context, store),
                                    icon: const Icon(Icons.flash_on),
                                  ),
                                ),
                              // Settings button
                              SizedBox(
                                width: 48,
                                height: 48,
                                child: IconButton(
                                  tooltip: AppLocalizations.of(context)!.optionsTitle,
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => const OptionsScreen(),
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.settings_outlined),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    Expanded(
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          if (viewMode == PlannerViewMode.month) {
                            return GestureDetector(
                              onScaleStart: (_) {
                                _lastScale = 1.0;
                              },
                              onScaleUpdate: (details) {
                                _lastScale = details.scale;
                              },
                              onScaleEnd: (_) {
                                if (_lastScale < AppConstants.pinchScaleThreshold) {
                                  _setViewMode(settings, PlannerViewMode.grid);
                                }
                                _lastScale = 1.0;
                              },
                              child: buildMonthView(
                                context: context,
                                pageController: _controller.pageController,
                                store: store,
                                settings: settings,
                                monthOrigin: _controller.monthOrigin,
                                monthOriginPage: PlannerScreenController.monthOriginPage,
                                monthWindowSize: _monthWindowSize,
                                onPinchOut: () {
                                  _setViewMode(settings, PlannerViewMode.grid);
                                },
                                onPageChanged: (index) {
                                  store.setSelectedMonth(
                                    monthForPage(
                                      _controller.monthOrigin,
                                      index,
                                      PlannerScreenController.monthOriginPage,
                                    ),
                                  );
                                },
                                paymentsBuilder: (month) => (month, periodInfo) =>
                                    store.paymentsForMonth(month, periodInfo: periodInfo),
                              ),
                            );
                          }

                          if (viewMode == PlannerViewMode.grid) {
                            _controller.lastGridViewportWidth = constraints.maxWidth;
                            _controller.lastGridViewportHeight = constraints.maxHeight;
                            _controller.ensureInitialGridTransform(
                              viewportWidth: constraints.maxWidth,
                              viewportHeight: constraints.maxHeight,
                              monthsBeforeSelected: month_math.monthsBetween(earliestMonth, selectedMonth),
                            );

                            final gridDimensions = _controller.gridDimensionsForViewport(
                              viewportWidth: constraints.maxWidth,
                              viewportHeight: constraints.maxHeight,
                            );

                            return buildGridView(
                              context: context,
                              gridTransformController: _controller.gridTransformController,
                              store: store,
                              settings: settings,
                              viewportWidth: constraints.maxWidth,
                              selectedMonth: selectedMonth,
                              gridColumns: gridDimensions.columns,
                              onInitGridTransform: () {},
                              onMonthTapped: (month) {
                                store.setSelectedMonth(month);
                                _setViewMode(settings, PlannerViewMode.month);
                                _jumpToSelectedMonth(store);
                              },
                              paymentsBuilder: (month) => (month, periodInfo) =>
                                  store.paymentsForMonth(month, periodInfo: periodInfo),
                            );
                          }

                          _controller.lastSheetViewportWidth = constraints.maxWidth;
                          // Compute months before selected to set initial scroll position
                          final monthsBefore = month_math.monthsBetween(earliestMonth, selectedMonth);

                          _controller.ensureInitialSheetTransform(
                            viewportWidth: constraints.maxWidth,
                            monthsBeforeSelected: monthsBefore,
                          );

                          final zoomStage = _controller.sheetZoomStageForWidth(
                            constraints.maxWidth,
                          );
                          final baseBalance = settings.plannerUseZeroBaseline
                              ? 0
                              : settings.currentBalanceCents;

                          return buildSheetView(
                            context: context,
                            sheetTransformController: _controller.sheetTransformController,
                            store: store,
                            settings: settings,
                            viewportWidth: constraints.maxWidth,
                            selectedMonth: selectedMonth,
                            zoomStage: zoomStage,
                            startingBalanceCents: baseBalance,
                            onInitSheetTransform: () {},
                            onMonthTapped: (month) {
                              store.setSelectedMonth(month);
                              _setViewMode(settings, PlannerViewMode.month);
                              _jumpToSelectedMonth(store);
                            },
                            paymentsBuilder: (month) => (month, periodInfo) =>
                                store.paymentsForMonth(month, periodInfo: periodInfo),
                          );
                        },
                      ),
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _jumpToSelectedMonth(ExpenseStore store) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _syncMonthPageIfNeeded(store.selectedMonth, _monthWindowSize);
    });
  }

  DateTime _computeEarliestMonth(ExpenseStore store) {
    final items = store.activePlannerItems;
    final nowMonth = monthOnly(DateTime.now());
    if (items.isEmpty) return nowMonth;
    var earliest = monthOnly(items.first.startDate);
    for (final item in items.skip(1)) {
      final start = monthOnly(item.startDate);
      if (start.isBefore(earliest)) earliest = start;
    }
    return earliest.isAfter(nowMonth) ? nowMonth : earliest;
  }

  DateTime _computeLatestMonth(DateTime earliestMonth, DateTime selectedMonth) {
    final nowMonth = monthOnly(DateTime.now());
    final base = _maxMonth(_maxMonth(nowMonth, selectedMonth), earliestMonth);
    return monthOnly(
      month_math.addMonths(base, PlannerScreenController.monthOriginPage),
    );
  }

  DateTime _maxMonth(DateTime a, DateTime b) {
    final aMonth = monthOnly(a);
    final bMonth = monthOnly(b);
    return aMonth.isAfter(bMonth) ? aMonth : bMonth;
  }

  void _ensureSelectedMonthWithinRange(
    ExpenseStore store,
    DateTime earliestMonth,
  ) {
    if (!store.selectedMonth.isBefore(earliestMonth)) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      store.setSelectedMonth(earliestMonth);
    });
  }

  void _syncMonthPageIfNeeded(DateTime selectedMonth, int monthWindowSize) {
    if (_controller.pageController.hasClients) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
      });
      return;
    }
    if (_didScheduleInitialMonthSync) return;
    _didScheduleInitialMonthSync = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _didScheduleInitialMonthSync = false;
      if (!mounted) return;
      _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
    });
  }

}
