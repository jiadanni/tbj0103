import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/planner_item.dart';
import 'package:expense_stalker_mobile/src/models/payment_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_amount_selector.dart';
import 'package:expense_stalker_mobile/src/features/planner/helpers/spending_envelope_service.dart';

/// Bottom sheet for quick-spending from a spending envelope.
/// 
/// Shows circular preset amount buttons and allows selecting an amount
/// to deduct from the envelope's budget for the current period.
class EnvelopeQuickSpendSheet extends StatelessWidget {
  const EnvelopeQuickSpendSheet({
    super.key,
    required this.envelope,
    required this.store,
    required this.month,
  });

  final PlannerItem envelope;
  final ExpenseStore store;
  final DateTime month;

  void _handleAmountSelected(BuildContext context, int amountCents) {
    // Expenses are negative
    final finalAmount = -amountCents.abs();
    
    final payment = PaymentEntry(
      id: newEntryId(),
      label: envelope.label,
      amountMinorUnits: finalAmount,
      date: dateOnly(DateTime.now()),
      type: PaymentType.spendingEnvelope,
      plannerItemId: envelope.id,
      category: envelope.category,
      company: envelope.company,
      moneyPotId: envelope.moneyPotId,
    );
    
    store.upsertPayment(payment);
    
    // Update balance
    final settings = AppSettingsScope.read(context);
    settings.currentBalanceCents += payment.amountMinorUnits;

    Navigator.pop(context);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Spent ${formatMoney(amountCents, settings.currency, showDecimals: settings.showCents)} from ${envelope.label}',
        ),
      ),
    );
  }

  void _showCustomAmountDialog(BuildContext context) {
    Navigator.pop(context);
    
    showDialog(
      context: context,
      builder: (ctx) => _CustomAmountDialog(
        envelope: envelope,
        store: store,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final amounts = settings.customQuickAddAmounts;
    final payments = store.paymentsForMonth(month);
    
    // Calculate current spending progress
    final period = SpendingEnvelopeService.getEnvelopePeriodDates(envelope, month);
    final spent = SpendingEnvelopeService.getSpentAmountForPeriod(envelope, payments, period);
    final target = envelope.amountMinorUnits.abs();
    final remaining = target - spent;
    final progress = target > 0 ? spent / target : 0.0;
    final isOverBudget = progress > 1.0;
    
    final progressColor = isOverBudget 
        ? Theme.of(context).colorScheme.error
        : (progress > 0.8 
            ? Colors.orange 
            : settings.debitColor);

    return Container(
      padding: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with envelope name
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              envelope.label,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          
          // Spending progress
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Progress bar
                SizedBox(
                  width: 80,
                  height: 8,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                      valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Spent / Target text
                Text(
                  '${formatMoneyFromCents(-spent, settings.currency, showCents: settings.showCents)} / ${formatMoneyFromCents(envelope.amountMinorUnits, settings.currency, showCents: settings.showCents)}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: progressColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          
          // Remaining amount
          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 16),
            child: Text(
              remaining >= 0 
                  ? '${formatMoneyFromCents(remaining, settings.currency, showCents: settings.showCents)} remaining'
                  : '${formatMoneyFromCents(-remaining, settings.currency, showCents: settings.showCents)} over budget',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: remaining >= 0 
                    ? Theme.of(context).colorScheme.onSurfaceVariant
                    : Theme.of(context).colorScheme.error,
              ),
            ),
          ),
          
          // Quick amount buttons
          QuickAmountSelector(
            amounts: amounts,
            onAmountSelected: (amount) => _handleAmountSelected(context, amount),
          ),
          
          const SizedBox(height: 16),
          
          // Custom amount fallback
          TextButton(
            onPressed: () => _showCustomAmountDialog(context),
            child: const Text('Enter Custom Amount'),
          ),
        ],
      ),
    );
  }
}

/// Dialog for entering a custom spending amount.
class _CustomAmountDialog extends StatefulWidget {
  const _CustomAmountDialog({
    required this.envelope,
    required this.store,
  });

  final PlannerItem envelope;
  final ExpenseStore store;

  @override
  State<_CustomAmountDialog> createState() => _CustomAmountDialogState();
}

class _CustomAmountDialogState extends State<_CustomAmountDialog> {
  late final TextEditingController _amountController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;
    
    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return;
    
    final settings = AppSettingsScope.read(context);
    final roundedCents = roundUpToIncrement(
      rawAmountCents, 
      settings.roundingIncrement * 100,
    );
    
    // Expenses are negative
    final finalAmountCents = -roundedCents;

    final payment = PaymentEntry(
      id: newEntryId(),
      label: widget.envelope.label,
      amountMinorUnits: finalAmountCents,
      date: dateOnly(DateTime.now()),
      type: PaymentType.spendingEnvelope,
      plannerItemId: widget.envelope.id,
      category: widget.envelope.category,
      company: widget.envelope.company,
      moneyPotId: widget.envelope.moneyPotId,
    );
    
    widget.store.upsertPayment(payment);
    settings.currentBalanceCents += payment.amountMinorUnits;
    
    if (mounted) {
      Navigator.pop(context);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Spent ${formatMoney(roundedCents, settings.currency, showDecimals: settings.showCents)} from ${widget.envelope.label}'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    
    return AlertDialog(
      title: Text('Spend from ${widget.envelope.label}'),
      content: TextField(
        controller: _amountController,
        focusNode: _focusNode,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(
          labelText: 'Amount',
          prefixText: '- ',
          border: OutlineInputBorder(),
        ),
        inputFormatters: [
          if (settings.showCents)
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
          else
            FilteringTextInputFormatter.digitsOnly,
        ],
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Spend'),
        ),
      ],
    );
  }
}
