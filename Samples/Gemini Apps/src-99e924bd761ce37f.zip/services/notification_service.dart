import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:intl/intl.dart';

/// Service for managing local push notifications.
///
/// Handles initialization, scheduling, cancellation, and content generation
/// for daily alerts, weekly alerts, and weekly summaries.
class NotificationService {
  static const String _channelId = 'expense_stalker_notifications';
  static const String _channelName = 'Expense Alerts';
  static const String _channelDescription =
      'Daily and weekly expense tracking notifications';

  // Notification IDs (must be unique)
  static const int _dailyAlertId = 1;
  static const int _weeklyAlertId = 2;
  static const int _weeklySummaryId = 3;

  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;
  AccountId? _lastAccountId;
  Timer? _rescheduleTimer;

  /// Initialize the notification service
  Future<void> initialize() async {
    if (_initialized) return;

    // Initialize timezone database
    tz.initializeTimeZones();
    try {
      final timezoneInfo = await FlutterTimezone.getLocalTimezone();
      final String currentTimeZone = timezoneInfo.identifier;
      tz.setLocalLocation(tz.getLocation(currentTimeZone));
    } catch (e) {
      // Fallback to UTC if detection fails or timezone not found
      tz.setLocalLocation(tz.getLocation('UTC'));
    }

    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const linuxSettings = LinuxInitializationSettings(
      defaultActionName: 'Open notification',
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
      linux: linuxSettings,
    );

    await _notificationsPlugin.initialize(
      settings: initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    // Create Android notification channel
    if (Platform.isAndroid) {
      await _createAndroidChannel();
    }

    _initialized = true;
  }

  /// Create Android notification channel
  Future<void> _createAndroidChannel() async {
    const androidChannel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.high,
      enableVibration: true,
      playSound: true,
    );

    await _notificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(androidChannel);
  }

  /// Callback for handling deep links when notification is tapped.
  /// Set this before initialization to handle navigation to specific screens.
  static void Function(String? payload)? onNotificationTapped;

  /// Handle notification tap
  void _onNotificationTap(NotificationResponse response) {
    final callback = onNotificationTapped;
    if (callback != null) {
      callback(response.payload);
    } else {
      // Log in debug mode if no handler is registered
      if (kDebugMode) {
        debugPrint(
          'Notification tapped but no handler registered: ${response.payload}',
        );
      }
    }
  }

  /// Request notification permissions (required for iOS and Android 13+)
  Future<bool> requestPermissions() async {
    if (Platform.isAndroid) {
      final androidPlugin =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      final granted = await androidPlugin?.requestNotificationsPermission();

      // On Android 14+ (API 34+), exact alarms require separate permission.
      // This opens the system settings page for the user to grant it.
      await androidPlugin?.requestExactAlarmsPermission();

      return granted ?? false;
    } else if (Platform.isIOS) {
      final iosPlugin =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>();
      final granted = await iosPlugin?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      return granted ?? false;
    }
    return true;
  }

  /// Resolve the appropriate Android schedule mode.
  ///
  /// On Android 14+ (API 34+), exact alarm permission must be granted
  /// separately. If not granted, falls back to inexact scheduling which
  /// may deliver notifications with a few minutes of drift.
  Future<AndroidScheduleMode> _resolveScheduleMode() async {
    if (Platform.isAndroid) {
      final androidPlugin =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      final canScheduleExact =
          await androidPlugin?.canScheduleExactNotifications() ?? false;
      if (!canScheduleExact) {
        if (kDebugMode) {
          debugPrint(
            'NotificationService: exact alarms not permitted, '
            'falling back to inexact scheduling',
          );
        }
        return AndroidScheduleMode.inexactAllowWhileIdle;
      }
    }
    return AndroidScheduleMode.exactAllowWhileIdle;
  }

  /// Schedule daily alert at specified time
  Future<void> scheduleDailyAlert(int hour, int minute) async {
    if (!_initialized) {
      throw StateError('NotificationService not initialized');
    }

    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );

    // If time has passed today, schedule for tomorrow
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    final scheduleMode = await _resolveScheduleMode();

    await _notificationsPlugin.zonedSchedule(
      id: _dailyAlertId,
      title: 'Daily Overview',
      body: 'Tap to see today\'s projected expenses and balance',
      scheduledDate: scheduledDate,
      notificationDetails: _notificationDetails(),
      androidScheduleMode: scheduleMode,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  /// Schedule weekly alert at start of week
  Future<void> scheduleWeeklyAlert(
    int weekStartDay,
    int hour,
    int minute,
  ) async {
    if (!_initialized) {
      throw StateError('NotificationService not initialized');
    }

    final nextWeekStart = _calculateNextWeekStart(weekStartDay, hour, minute);

    final scheduleMode = await _resolveScheduleMode();

    await _notificationsPlugin.zonedSchedule(
      id: _weeklyAlertId,
      title: 'New Week Starting',
      body: 'Time to plan your week\'s expenses',
      scheduledDate: nextWeekStart,
      notificationDetails: _notificationDetails(),
      androidScheduleMode: scheduleMode,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
    );
  }

  /// Schedule weekly summary at end of week
  Future<void> scheduleWeeklySummary(
    int weekStartDay,
    int hour,
    int minute,
  ) async {
    if (!_initialized) {
      throw StateError('NotificationService not initialized');
    }

    // End of week is one day before start of week
    final weekEndDay = weekStartDay == 1 ? 7 : weekStartDay - 1;
    final nextWeekEnd = _calculateNextWeekStart(weekEndDay, hour, minute);

    final scheduleMode = await _resolveScheduleMode();

    await _notificationsPlugin.zonedSchedule(
      id: _weeklySummaryId,
      title: 'Weekly Summary',
      body: 'Tap to see your week\'s spending overview',
      scheduledDate: nextWeekEnd,
      notificationDetails: _notificationDetails(),
      androidScheduleMode: scheduleMode,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
    );
  }

  /// Calculate next occurrence of a specific day of week at given time
  tz.TZDateTime _calculateNextWeekStart(int targetDay, int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    final currentDay = now.weekday; // 1=Monday, 7=Sunday

    var daysUntilTarget = targetDay - currentDay;
    if (daysUntilTarget <= 0) {
      daysUntilTarget += 7; // Move to next week
    }

    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day + daysUntilTarget,
      hour,
      minute,
    );

    // If we're on target day but time has passed, schedule for next week
    if (targetDay == currentDay) {
      final todayAtTime = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day,
        hour,
        minute,
      );
      if (todayAtTime.isBefore(now)) {
        scheduledDate = scheduledDate.add(const Duration(days: 7));
      } else {
        scheduledDate = todayAtTime;
      }
    }

    return scheduledDate;
  }

  /// Cancel daily alert
  Future<void> cancelDailyAlert() async {
    await _notificationsPlugin.cancel(id: _dailyAlertId);
  }

  /// Cancel weekly alert
  Future<void> cancelWeeklyAlert() async {
    await _notificationsPlugin.cancel(id: _weeklyAlertId);
  }

  /// Cancel weekly summary
  Future<void> cancelWeeklySummary() async {
    await _notificationsPlugin.cancel(id: _weeklySummaryId);
  }

  /// Cancel all notifications
  Future<void> cancelAllNotifications() async {
    await _notificationsPlugin.cancelAll();
  }

  /// Generate content for daily alert
  String generateDailyAlertContent(
    ExpenseStore store,
    AppSettingsStore settings,
  ) {
    final today = DateTime.now();

    // Get today's timeline items
    final todayItems = store.timelineItems.where((item) {
      if (!item.shouldAppearInMonth(today)) return false;

      // Calculate effective day of month for this month
      final maxDay = DateTime.utc(today.year, today.month + 1, 0).day;
      final effectiveDay = item.dayOfMonth <= maxDay ? item.dayOfMonth : maxDay;

      return effectiveDay == today.day;
    }).toList();

    // Calculate expenses and income
    double totalExpenses = 0;
    double totalIncome = 0;

    for (final item in todayItems) {
      if (item.isIncome) {
        totalIncome += item.amount;
      } else {
        totalExpenses += item.amount;
      }
    }

    // Calculate projected balance
    // Start with current balance (from pulses)
    double currentBalance = 0;
    for (final pulse in store.pulses) {
      if (pulse.isIncome) {
        currentBalance += pulse.amount;
      } else {
        currentBalance -= pulse.amount;
      }
    }

    // Add today's projected activity
    final projectedBalance = currentBalance + totalIncome - totalExpenses;

    final currencySymbol = settings.currency.symbol;
    final formatter = NumberFormat.currency(
      symbol: currencySymbol,
      decimalDigits: 2,
    );

    return 'Today: ${formatter.format(totalExpenses)} expenses, '
        '${formatter.format(totalIncome)} income | '
        'Projected balance: ${formatter.format(projectedBalance)}';
  }

  /// Generate content for weekly summary
  String generateWeeklySummaryContent(
    ExpenseStore store,
    AppSettingsStore settings,
  ) {
    final account = store.currentAccount;

    final weekStartDay = account.settings.weekStartDay;
    final today = DateTime.now();

    // Calculate week range
    final weekStart = getWeekStart(today, weekStartDay);
    final weekEnd = weekStart.add(const Duration(days: 7));

    // Get this week's pulses (paid items)
    final weekPulses = store.pulses.where((pulse) {
      final paidDate = pulse.paidDate;
      return paidDate.isAfter(weekStart.subtract(const Duration(seconds: 1))) &&
          paidDate.isBefore(weekEnd);
    }).toList();

    // Calculate totals
    double totalExpenses = 0;
    double totalIncome = 0;

    for (final pulse in weekPulses) {
      if (pulse.isIncome) {
        totalIncome += pulse.amount;
      } else {
        totalExpenses += pulse.amount;
      }
    }

    final balanceChange = totalIncome - totalExpenses;
    final currencySymbol = settings.currency.symbol;
    final formatter = NumberFormat.currency(
      symbol: currencySymbol,
      decimalDigits: 2,
    );

    return 'This week: ${formatter.format(totalExpenses)} spent, '
        '${formatter.format(totalIncome)} earned | '
        'Net: ${formatter.format(balanceChange)}';
  }

  /// Schedule notifications based on current settings
  Future<void> scheduleFromSettings(
    ExpenseStore store,
    AppSettingsStore settings,
  ) async {
    final account = store.currentAccount;

    final accountSettings = account.settings;

    // Cancel all first
    await cancelAllNotifications();

    // Only schedule if notifications are enabled
    if (!accountSettings.notificationsEnabled) {
      return;
    }

    // Schedule daily alert
    if (accountSettings.dailyAlertEnabled) {
      await scheduleDailyAlert(
        accountSettings.dailyAlertHour,
        accountSettings.dailyAlertMinute,
      );
    }

    // Schedule weekly alert
    if (accountSettings.weeklyAlertEnabled) {
      await scheduleWeeklyAlert(
        accountSettings.weekStartDay,
        accountSettings.weeklyAlertHour,
        accountSettings.weeklyAlertMinute,
      );
    }

    // Schedule weekly summary
    if (accountSettings.weeklySummaryEnabled) {
      await scheduleWeeklySummary(
        accountSettings.weekStartDay,
        accountSettings.weeklySummaryHour,
        accountSettings.weeklySummaryMinute,
      );
    }
  }

  /// Get notification details for all platforms
  NotificationDetails _notificationDetails() {
    const androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    return const NotificationDetails(android: androidDetails, iOS: iosDetails);
  }

  /// Listen to store changes and reschedule notifications automatically.
  void listen(ExpenseStore store, AppSettingsStore settings) {
    _lastAccountId = store.currentAccount.id;

    store.addListener(() {
      final currentId = store.currentAccount.id;
      if (_lastAccountId != currentId) {
        _lastAccountId = currentId;
        _rescheduleDebounced(store, settings);
      }
    });

    settings.addListener(() {
      _rescheduleDebounced(store, settings);
    });
  }

  void _rescheduleDebounced(ExpenseStore store, AppSettingsStore settings) {
    _rescheduleTimer?.cancel();
    _rescheduleTimer = Timer(const Duration(seconds: 1), () {
      if (_initialized) {
        scheduleFromSettings(store, settings);
      }
    });
  }

  void dispose() {
    _rescheduleTimer?.cancel();
  }
}
