import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

/// Service for smart categorization of imported transactions.
///
/// Learns from existing pulses and timeline items to suggest categories
/// for new imported transactions based on description patterns.
class CategorizationService {
  const CategorizationService._();

  /// Singleton instance.
  static const CategorizationService instance = CategorizationService._();

  /// Trains a categorization model from existing data.
  ///
  /// Analyzes pulses and timeline items to build a pattern-based model
  /// for suggesting categories on imported transactions.
  Future<CategorizationModel> trainFromExistingData(
    List<PulseEntry> pulses,
    List<TimelineItem> timelineItems,
  ) async {
    return compute(_trainModelIsolate, _TrainingParams(pulses, timelineItems));
  }

  static CategorizationModel _trainModelIsolate(_TrainingParams params) {
    final patterns = <String, CategoryPattern>{};
    final keywordPatterns = <String, Map<String, int>>{};

    // Learn from existing pulses
    for (final pulse in params.pulses) {
      if (pulse.category == null || pulse.category!.isEmpty) continue;

      final labelsToLearn = [
        pulse.label,
        if (pulse.origin != null && pulse.origin!.isNotEmpty) pulse.origin!,
      ];

      for (final label in labelsToLearn) {
        final normalized = _normalizeDescription(label);
        final keywords = _extractKeywords(label);

        // Exact pattern matching
        if (!patterns.containsKey(normalized)) {
          patterns[normalized] = CategoryPattern(
            pattern: normalized,
            category: pulse.category!,
            subcategory: pulse.subcategory,
            useCount: 1,
            originalLabels: [label],
          );
        } else {
          final existing = patterns[normalized]!;
          patterns[normalized] = existing.copyWith(
            useCount: existing.useCount + 1,
            originalLabels: [...existing.originalLabels, label],
          );
        }

        // Keyword-based matching
        for (final keyword in keywords) {
          keywordPatterns[keyword] ??= {};
          keywordPatterns[keyword]![pulse.category!] =
              (keywordPatterns[keyword]![pulse.category!] ?? 0) + 1;
        }
      }
    }

    // Learn from timeline items (weighted slightly higher as they're user-configured)
    for (final item in params.timelineItems) {
      if (item.category == null || item.category!.isEmpty) continue;

      final labelsToLearn = [
        item.label,
        if (item.origin != null && item.origin!.isNotEmpty) item.origin!,
        ...?(item.suggestedOrigins?.where((o) => o.isNotEmpty)),
      ];

      for (final label in labelsToLearn) {
        final normalized = _normalizeDescription(label);
        final keywords = _extractKeywords(label);

        // Exact pattern matching with higher weight
        if (!patterns.containsKey(normalized)) {
          patterns[normalized] = CategoryPattern(
            pattern: normalized,
            category: item.category!,
            subcategory: item.subcategory,
            useCount: 2, // Weight timeline items higher
            originalLabels: [label],
          );
        } else {
          final existing = patterns[normalized]!;
          // If categories match, increase count; otherwise, keep higher count
          if (existing.category == item.category) {
            patterns[normalized] = existing.copyWith(
              useCount: existing.useCount + 2,
              originalLabels: [...existing.originalLabels, label],
            );
          } else if (existing.useCount < 2) {
            // Timeline item takes precedence over single pulse
            patterns[normalized] = CategoryPattern(
              pattern: normalized,
              category: item.category!,
              subcategory: item.subcategory,
              useCount: 2,
              originalLabels: [label],
            );
          }
        }

        // Keyword-based matching with higher weight
        for (final keyword in keywords) {
          keywordPatterns[keyword] ??= {};
          keywordPatterns[keyword]![item.category!] =
              (keywordPatterns[keyword]![item.category!] ?? 0) + 2;
        }
      }
    }

    // Build keyword suggestions from collected data
    final keywordSuggestions = <String, CategorySuggestion>{};
    for (final entry in keywordPatterns.entries) {
      final keyword = entry.key;
      final categoryCounts = entry.value;

      if (categoryCounts.isEmpty) continue;

      // Find the most common category for this keyword
      final sortedCategories = categoryCounts.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));

      final topCategory = sortedCategories.first;
      final totalCount = categoryCounts.values.fold(0, (a, b) => a + b);
      final confidence = topCategory.value / totalCount;

      // Only include if confidence is reasonable
      if (confidence >= 0.5 && topCategory.value >= 2) {
        keywordSuggestions[keyword] = CategorySuggestion(
          category: topCategory.key,
          confidence:
              confidence * 0.7, // Keyword matches have lower base confidence
          matchType: MatchType.keyword,
        );
      }
    }

    debugLog(
      LogCategory.persistence,
      'Trained categorization model: ${patterns.length} patterns, ${keywordSuggestions.length} keywords',
    );

    return CategorizationModel(
      patterns: patterns,
      keywordSuggestions: keywordSuggestions,
    );
  }

  /// Suggests a category for a transaction description.
  ///
  /// Returns null if no confident suggestion can be made.
  CategorySuggestion? suggestCategory(
    String description,
    CategorizationModel model, {
    bool isInternalTransfer = false,
  }) {
    // 0. System rules (highest priority)
    if (isInternalTransfer) {
      return const CategorySuggestion(
        category: 'Internal Transfer',
        confidence: 1.0,
        matchType: MatchType.systemRule,
      );
    }

    final normalized = _normalizeDescription(description);
    final keywords = _extractKeywords(description);

    // 1. Try exact match first (highest confidence)
    if (model.patterns.containsKey(normalized)) {
      final pattern = model.patterns[normalized]!;
      return CategorySuggestion(
        category: pattern.category,
        subcategory: pattern.subcategory,
        confidence: 1.0,
        matchType: MatchType.exact,
      );
    }

    // 2. Try contains match (medium-high confidence)
    CategoryPattern? bestContainsMatch;
    int bestMatchLength = 0;

    for (final pattern in model.patterns.values) {
      // Check if description contains the pattern or vice versa
      if (normalized.contains(pattern.pattern) ||
          pattern.pattern.contains(normalized)) {
        // Prefer longer matches
        if (pattern.pattern.length > bestMatchLength) {
          bestMatchLength = pattern.pattern.length;
          bestContainsMatch = pattern;
        }
      }
    }

    if (bestContainsMatch != null && bestMatchLength >= 3) {
      return CategorySuggestion(
        category: bestContainsMatch.category,
        subcategory: bestContainsMatch.subcategory,
        confidence: 0.8,
        matchType: MatchType.fuzzy,
      );
    }

    // 3. Try keyword matching (lower confidence)
    final keywordMatches = <String, int>{};
    for (final keyword in keywords) {
      final suggestion = model.keywordSuggestions[keyword];
      if (suggestion != null) {
        keywordMatches[suggestion.category] =
            (keywordMatches[suggestion.category] ?? 0) + 1;
      }
    }

    if (keywordMatches.isNotEmpty) {
      final sortedMatches = keywordMatches.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));

      final topMatch = sortedMatches.first;
      // Calculate confidence based on keyword coverage
      final coverage = topMatch.value / keywords.length;

      // Accept single keyword matches with lower confidence threshold
      // Multiple keyword matches get higher confidence
      if (topMatch.value >= 2 || keywords.length <= 2 || coverage >= 0.3) {
        final baseConfidence = topMatch.value >= 2 ? 0.5 : 0.4;
        return CategorySuggestion(
          category: topMatch.key,
          confidence: (baseConfidence + coverage * 0.2).clamp(0.4, 0.7),
          matchType: topMatch.value >= 2 ? MatchType.keyword : MatchType.fuzzy,
        );
      }
    }

    // No confident suggestion
    return null;
  }

  /// Batch suggests categories for multiple descriptions.
  ///
  /// More efficient than calling [suggestCategory] repeatedly.
  Map<String, CategorySuggestion?> batchSuggestCategories(
    List<String> descriptions,
    CategorizationModel model,
  ) {
    final results = <String, CategorySuggestion?>{};
    for (final description in descriptions) {
      results[description] = suggestCategory(description, model);
    }
    return results;
  }

  /// Learns from a user's category correction.
  ///
  /// Updates the model to improve future suggestions.
  CategorizationModel learnFromCorrection(
    CategorizationModel model,
    String description,
    String category,
  ) {
    final normalized = _normalizeDescription(description);
    final newPatterns = Map<String, CategoryPattern>.from(model.patterns);

    if (newPatterns.containsKey(normalized)) {
      // Update existing pattern
      final existing = newPatterns[normalized]!;
      if (existing.category == category) {
        // Reinforce existing pattern
        newPatterns[normalized] = existing.copyWith(
          useCount: existing.useCount + 1,
        );
      } else {
        // Correction: user chose different category
        // If new category has higher count, keep it; otherwise increment new
        newPatterns[normalized] = CategoryPattern(
          pattern: normalized,
          category: category,
          useCount: existing.useCount + 2, // Corrections weighted higher
          originalLabels: [description, ...existing.originalLabels],
        );
      }
    } else {
      // New pattern
      newPatterns[normalized] = CategoryPattern(
        pattern: normalized,
        category: category,
        useCount: 1,
        originalLabels: [description],
      );
    }

    return CategorizationModel(
      patterns: newPatterns,
      keywordSuggestions: model.keywordSuggestions,
    );
  }

  static String _normalizeDescription(String description) {
    return description
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]'), '') // Remove special chars
        .replaceAll(RegExp(r'\s+'), ' ') // Normalize whitespace
        .trim();
  }

  static List<String> _extractKeywords(String description) {
    // Common stop words to exclude
    const stopWords = {
      'the',
      'a',
      'an',
      'and',
      'or',
      'but',
      'in',
      'on',
      'at',
      'to',
      'for',
      'of',
      'with',
      'by',
      'from',
      'is',
      'are',
      'was',
      'were',
      'be',
      'been',
      'this',
      'that',
      'it',
      'its',
      'payment',
      'purchase',
      'transaction',
      'card',
      'debit',
      'credit',
      'pos',
      'ach',
      'transfer',
    };

    return description
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]'), '')
        .split(RegExp(r'\s+'))
        .where((word) => word.length >= 3 && !stopWords.contains(word))
        .toList();
  }
}

/// A trained model for category suggestions.
class CategorizationModel extends Equatable {
  const CategorizationModel({
    required this.patterns,
    required this.keywordSuggestions,
  });

  /// Empty model with no patterns.
  const CategorizationModel.empty()
      : patterns = const {},
        keywordSuggestions = const {};

  /// Exact and fuzzy match patterns.
  final Map<String, CategoryPattern> patterns;

  /// Keyword-based suggestions.
  final Map<String, CategorySuggestion> keywordSuggestions;

  /// Returns true if the model has learned patterns.
  bool get hasPatterns => patterns.isNotEmpty || keywordSuggestions.isNotEmpty;

  /// Total number of patterns learned.
  int get patternCount => patterns.length;

  /// Total number of keyword patterns learned.
  int get keywordCount => keywordSuggestions.length;

  @override
  List<Object?> get props => [patterns, keywordSuggestions];
}

/// A pattern learned from existing data.
class CategoryPattern extends Equatable {
  const CategoryPattern({
    required this.pattern,
    required this.category,
    this.subcategory,
    required this.useCount,
    this.originalLabels = const [],
  });

  /// Normalized pattern string.
  final String pattern;

  /// Category associated with this pattern.
  final String category;

  /// Subcategory associated with this pattern.
  final String? subcategory;

  /// Number of times this pattern has been used.
  final int useCount;

  /// Original unmodified labels that matched this pattern.
  final List<String> originalLabels;

  CategoryPattern copyWith({
    String? pattern,
    String? category,
    String? subcategory,
    int? useCount,
    List<String>? originalLabels,
  }) {
    return CategoryPattern(
      pattern: pattern ?? this.pattern,
      category: category ?? this.category,
      subcategory: subcategory ?? this.subcategory,
      useCount: useCount ?? this.useCount,
      originalLabels: originalLabels ?? this.originalLabels,
    );
  }

  @override
  List<Object?> get props => [
        pattern,
        category,
        subcategory,
        useCount,
        originalLabels,
      ];
}

/// A suggested category with confidence score.
class CategorySuggestion extends Equatable {
  const CategorySuggestion({
    required this.category,
    this.subcategory,
    required this.confidence,
    required this.matchType,
  });

  /// Suggested category name.
  final String category;

  /// Suggested subcategory name.
  final String? subcategory;

  /// Confidence score from 0.0 to 1.0.
  final double confidence;

  /// Type of match that produced this suggestion.
  final MatchType matchType;

  /// Returns true if this is a high-confidence suggestion (>= 0.8).
  bool get isHighConfidence => confidence >= 0.8;

  /// Returns true if this is a medium-confidence suggestion (>= 0.5).
  bool get isMediumConfidence => confidence >= 0.5;

  @override
  List<Object?> get props => [category, subcategory, confidence, matchType];
}

/// Types of pattern matching used for categorization.
enum MatchType {
  /// Exact normalized string match.
  exact,

  /// Fuzzy/partial string match (contains).
  fuzzy,

  /// Keyword-based match.
  keyword,

  /// System rule (e.g. internal transfer).
  systemRule,

  /// No match found.
  none,
}

/// Parameters for training isolate.
class _TrainingParams {
  const _TrainingParams(this.pulses, this.timelineItems);

  final List<PulseEntry> pulses;
  final List<TimelineItem> timelineItems;
}
