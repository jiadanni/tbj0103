import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

/// Service responsible for importing expense data.
class ImportService {
  final ExpensePersistence _persistence;

  ImportService(this._persistence);

  /// Imports the provided [snapshot].
  ///
  /// Validates the snapshot and returns true if import was successful.
  Future<bool> importSnapshot(ExpenseSnapshot snapshot) async {
    try {
      if (!_persistence.validateSnapshot(snapshot)) return false;
      return true;
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to import snapshot',
        error: error,
        stackTrace: stackTrace,
      );
      return false;
    }
  }
}
