import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:csv/csv.dart';
import 'package:equatable/equatable.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/bank_profile.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';

/// Detected CSV format types.
enum CsvFormat {
  /// Known format from Expense Stalker export - supports full round-trip.
  expenseStalker,

  /// Common bank statement format with date, description, amount columns.
  bankStatement,

  /// Unknown format requiring manual column mapping.
  generic,

  /// Cannot parse - invalid or insufficient data.
  unknown,
}

extension CsvFormatExtension on CsvFormat {
  String get label {
    switch (this) {
      case CsvFormat.expenseStalker:
        return 'Expense Stalker Export';
      case CsvFormat.bankStatement:
        return 'Bank Statement';
      case CsvFormat.generic:
        return 'Generic CSV';
      case CsvFormat.unknown:
        return 'Unknown Format';
    }
  }

  bool get requiresMapping =>
      this == CsvFormat.bankStatement || this == CsvFormat.generic;
}

/// Result of parsing a CSV file for import.
class CsvImportResult extends Equatable {
  const CsvImportResult({
    required this.format,
    this.timelineItems = const [],
    this.pulses = const [],
    this.accountName,
    this.exportDate,
    this.startingBalanceCents,
    this.detectedFinalBalanceCents,
    this.paycheckDay,
    this.errors = const [],
    this.warnings = const [],
  });

  /// Detected format of the CSV file.
  final CsvFormat format;

  /// Parsed timeline items (only for Expense Stalker format).
  final List<TimelineItem> timelineItems;

  /// Parsed pulse entries.
  final List<PulseEntry> pulses;

  /// Account name from metadata (if available).
  final String? accountName;

  /// Export date from metadata (if available).
  final DateTime? exportDate;

  /// Starting balance from metadata (if available).
  final int? startingBalanceCents;

  /// Closing balance detected from the statements (if available).
  final int? detectedFinalBalanceCents;

  /// Paycheck day from metadata (if available).
  final int? paycheckDay;

  /// Parsing errors encountered.
  final List<String> errors;

  /// Non-fatal warnings encountered.
  final List<String> warnings;

  /// Returns true if parsing was successful (no errors).
  bool get isSuccess => errors.isEmpty;

  /// Total number of items parsed.
  int get totalItems => timelineItems.length + pulses.length;

  @override
  List<Object?> get props => [
        format,
        timelineItems,
        pulses,
        accountName,
        exportDate,
        startingBalanceCents,
        detectedFinalBalanceCents,
        paycheckDay,
        errors,
        warnings,
      ];
}

/// Configuration for column mapping in bank/generic CSV imports.
class CsvColumnMapping extends Equatable {
  const CsvColumnMapping({
    required this.dateColumnIndex,
    required this.descriptionColumnIndex,
    required this.amountColumnIndex,
    this.currencyColumnIndex,
    this.dateFormat = 'yyyy-MM-dd',
    this.decimalSeparator = '.',
    this.hasHeaderRow = true,
    this.amountMultiplier = 1.0,
    this.invertAmount = false,
    this.categoryColumnIndex,
    this.debitColumnIndex,
    this.creditColumnIndex,
    this.debitCreditIndicatorColumnIndex,
    this.balanceColumnIndex,
    this.memoColumnIndex,
    this.referenceColumnIndex,
    this.transactionCodeColumnIndex,
    this.metadataColumnIndex,
  });

  /// Index of the column containing the transaction date.
  final int dateColumnIndex;

  /// Index of the column containing the main description/payee.
  final int descriptionColumnIndex;

  /// Index of the column containing the transaction amount.
  final int amountColumnIndex;

  /// Index of the column containing the currency (optional).
  final int? currencyColumnIndex;

  /// Index of the column containing the category (optional).
  final int? categoryColumnIndex;

  /// Index of the column containing debit amount (optional).
  final int? debitColumnIndex;

  /// Index of the column containing credit amount (optional).
  final int? creditColumnIndex;

  /// Index of the column containing debit/credit indicator (optional).
  final int? debitCreditIndicatorColumnIndex;

  /// Index of the column containing balance (optional).
  final int? balanceColumnIndex;

  /// Index of the column containing memo (optional).
  final int? memoColumnIndex;

  /// Index of the column containing reference/counterparty info (optional).
  final int? referenceColumnIndex;

  /// Index of the column containing transaction code e.g. GT, OV (optional).
  final int? transactionCodeColumnIndex;

  /// Index of the column containing metadata/notifications (optional).
  final int? metadataColumnIndex;

  /// Format pattern for parsing the date column.
  final String dateFormat;

  /// Character used for decimal separation in amounts.
  final String decimalSeparator;

  /// Whether the CSV has a header row that should be skipped.
  final bool hasHeaderRow;

  /// Multiplier to convert amount to correct unit/sign.
  final double amountMultiplier;

  /// Whether to invert the sign of the amount.
  final bool invertAmount;

  /// Whether the mapping uses separate columns for debit and credit.
  bool get hasSeparateDebitCredit =>
      debitColumnIndex != null || creditColumnIndex != null;

  /// Whether the mapping uses a debit/credit indicator column.
  bool get hasDebitCreditIndicator => debitCreditIndicatorColumnIndex != null;

  CsvColumnMapping copyWith({
    int? dateColumnIndex,
    int? descriptionColumnIndex,
    int? amountColumnIndex,
    int? currencyColumnIndex,
    String? dateFormat,
    String? decimalSeparator,
    bool? hasHeaderRow,
    double? amountMultiplier,
    bool? invertAmount,
    int? categoryColumnIndex,
    int? debitColumnIndex,
    int? creditColumnIndex,
    int? debitCreditIndicatorColumnIndex,
    int? balanceColumnIndex,
    int? memoColumnIndex,
    int? referenceColumnIndex,
    int? transactionCodeColumnIndex,
    int? metadataColumnIndex,
  }) {
    return CsvColumnMapping(
      dateColumnIndex: dateColumnIndex ?? this.dateColumnIndex,
      descriptionColumnIndex:
          descriptionColumnIndex ?? this.descriptionColumnIndex,
      amountColumnIndex: amountColumnIndex ?? this.amountColumnIndex,
      currencyColumnIndex: currencyColumnIndex ?? this.currencyColumnIndex,
      dateFormat: dateFormat ?? this.dateFormat,
      decimalSeparator: decimalSeparator ?? this.decimalSeparator,
      hasHeaderRow: hasHeaderRow ?? this.hasHeaderRow,
      amountMultiplier: amountMultiplier ?? this.amountMultiplier,
      invertAmount: invertAmount ?? this.invertAmount,
      categoryColumnIndex: categoryColumnIndex ?? this.categoryColumnIndex,
      debitColumnIndex: debitColumnIndex ?? this.debitColumnIndex,
      creditColumnIndex: creditColumnIndex ?? this.creditColumnIndex,
      debitCreditIndicatorColumnIndex: debitCreditIndicatorColumnIndex ??
          this.debitCreditIndicatorColumnIndex,
      balanceColumnIndex: balanceColumnIndex ?? this.balanceColumnIndex,
      memoColumnIndex: memoColumnIndex ?? this.memoColumnIndex,
      referenceColumnIndex: referenceColumnIndex ?? this.referenceColumnIndex,
      transactionCodeColumnIndex:
          transactionCodeColumnIndex ?? this.transactionCodeColumnIndex,
      metadataColumnIndex: metadataColumnIndex ?? this.metadataColumnIndex,
    );
  }

  Map<String, dynamic> toJson() => {
        'dateColumnIndex': dateColumnIndex,
        'descriptionColumnIndex': descriptionColumnIndex,
        'amountColumnIndex': amountColumnIndex,
        'currencyColumnIndex': currencyColumnIndex,
        'dateFormat': dateFormat,
        'decimalSeparator': decimalSeparator,
        'hasHeaderRow': hasHeaderRow,
        'amountMultiplier': amountMultiplier,
        'invertAmount': invertAmount,
        'categoryColumnIndex': categoryColumnIndex,
        'debitColumnIndex': debitColumnIndex,
        'creditColumnIndex': creditColumnIndex,
        'debitCreditIndicatorColumnIndex': debitCreditIndicatorColumnIndex,
        'balanceColumnIndex': balanceColumnIndex,
        'memoColumnIndex': memoColumnIndex,
        'referenceColumnIndex': referenceColumnIndex,
        'transactionCodeColumnIndex': transactionCodeColumnIndex,
        'metadataColumnIndex': metadataColumnIndex,
      };

  factory CsvColumnMapping.fromJson(Map<String, dynamic> json) =>
      CsvColumnMapping(
        dateColumnIndex: json['dateColumnIndex'] as int,
        descriptionColumnIndex: json['descriptionColumnIndex'] as int,
        amountColumnIndex: json['amountColumnIndex'] as int,
        currencyColumnIndex: json['currencyColumnIndex'] as int?,
        dateFormat: json['dateFormat'] as String,
        decimalSeparator: json['decimalSeparator'] as String,
        hasHeaderRow: json['hasHeaderRow'] as bool,
        amountMultiplier: (json['amountMultiplier'] as num?)?.toDouble() ?? 1.0,
        invertAmount: json['invertAmount'] as bool? ?? false,
        categoryColumnIndex: json['categoryColumnIndex'] as int?,
        debitColumnIndex: json['debitColumnIndex'] as int?,
        creditColumnIndex: json['creditColumnIndex'] as int?,
        debitCreditIndicatorColumnIndex:
            json['debitCreditIndicatorColumnIndex'] as int?,
        balanceColumnIndex: json['balanceColumnIndex'] as int?,
        memoColumnIndex: json['memoColumnIndex'] as int?,
        referenceColumnIndex: json['referenceColumnIndex'] as int?,
        transactionCodeColumnIndex: json['transactionCodeColumnIndex'] as int?,
        metadataColumnIndex: json['metadataColumnIndex'] as int?,
      );

  @override
  List<Object?> get props => [
        dateColumnIndex,
        descriptionColumnIndex,
        amountColumnIndex,
        currencyColumnIndex,
        dateFormat,
        decimalSeparator,
        hasHeaderRow,
        amountMultiplier,
        invertAmount,
        categoryColumnIndex,
        debitColumnIndex,
        creditColumnIndex,
        debitCreditIndicatorColumnIndex,
        balanceColumnIndex,
        memoColumnIndex,
        referenceColumnIndex,
        transactionCodeColumnIndex,
        metadataColumnIndex,
      ];
}

/// Configuration for CSV import behavior.
class CsvImportConfig extends Equatable {
  const CsvImportConfig({
    required this.dateFormat,
    this.invertAmount = false,
    this.skipFirstRow = true,
    this.skipLastRow = false,
    this.defaultType = PulseType.oneOff,
    this.treatCreditsAsNegative = false,
    this.useEuropeanNumberFormat = false,
    this.startDate,
    this.endDate,
    this.ensurePositiveValues = false,
    this.currency,
  });

  /// Date format pattern (e.g., 'MM/dd/yyyy', 'yyyy-MM-dd').
  final String dateFormat;

  /// Whether to invert the sign of amounts (some banks use positive for debits).
  final bool invertAmount;

  /// Whether to skip the first row (header row).
  final bool skipFirstRow;

  /// Whether to skip the last row (sometimes contains totals).
  final bool skipLastRow;

  /// Default pulse type for imported transactions.
  final PulseType defaultType;

  /// Whether credits should be treated as negative amounts.
  final bool treatCreditsAsNegative;

  /// Whether to use European number format (comma as decimal, period as thousands).
  /// Example: "1.234,56" = 1234.56
  final bool useEuropeanNumberFormat;

  /// Optional start date: transactions before this date will be skipped.
  final DateTime? startDate;

  /// Optional end date: transactions after this date will be skipped.
  final DateTime? endDate;

  /// Whether to ensure all amounts are positive (useful if bank uses non-standard signs).
  final bool ensurePositiveValues;

  /// Target currency for the import.
  final AppCurrency? currency;

  @override
  List<Object?> get props => [
        dateFormat,
        invertAmount,
        skipFirstRow,
        skipLastRow,
        defaultType,
        treatCreditsAsNegative,
        useEuropeanNumberFormat,
        startDate,
        endDate,
        ensurePositiveValues,
        currency,
      ];
}

/// Service for importing CSV files into the expense tracker.
///
/// Supports three import scenarios:
/// 1. Round-trip import of Expense Stalker CSV exports
/// 2. Bank statement CSV import with column mapping
/// 3. Generic CSV import with custom configuration
class CsvImportService {
  const CsvImportService._();

  /// Singleton instance.
  static const CsvImportService instance = CsvImportService._();

  // ─────────────────────────────────────────────────────────────────────────
  // Format Detection
  // ─────────────────────────────────────────────────────────────────────────

  /// Detects the format of a CSV file from its content.
  ///
  /// Returns [CsvFormat.expenseStalker] for our own exports,
  /// [CsvFormat.bankStatement] for common bank formats,
  /// [CsvFormat.generic] for other formats, or
  /// [CsvFormat.unknown] if the content can't be parsed.
  CsvFormat detectFormat(String csvContent) {
    try {
      final lines = const LineSplitter().convert(csvContent);

      if (lines.length < 2) return CsvFormat.unknown;

      // Check for Expense Stalker metadata markers
      if (_isExpenseStalkerFormat(lines)) {
        return CsvFormat.expenseStalker;
      }

      // Check for common bank statement patterns
      if (_isBankStatementFormat(lines)) {
        return CsvFormat.bankStatement;
      }

      // If it has headers and data rows, treat as generic
      if (_hasValidCsvStructure(lines)) {
        return CsvFormat.generic;
      }

      return CsvFormat.unknown;
    } catch (e) {
      debugLog(
        LogCategory.persistence,
        'CSV format detection failed',
        error: e,
      );
      return CsvFormat.unknown;
    }
  }

  bool _isExpenseStalkerFormat(List<String> lines) {
    // Our exports start with "Account Name," metadata
    if (lines.isEmpty) return false;

    // Check for our specific metadata pattern
    final hasAccountName = lines.any((l) => l.startsWith('Account Name,'));
    final hasExportDate = lines.any((l) => l.startsWith('Export Date,'));

    // Check for our specific header patterns
    final hasTimelineHeader = lines.any(
      (l) => l.startsWith('Type,Id,Label,Amount,StartDate'),
    );
    final hasPulseHeader = lines.any(
      (l) => l.startsWith('Type,Id,Label,Amount,Date,Category'),
    );

    return hasAccountName &&
        hasExportDate &&
        (hasTimelineHeader || hasPulseHeader);
  }

  bool _isBankStatementFormat(List<String> lines) {
    if (lines.isEmpty) return false;

    final headerLine = lines.first.toLowerCase();

    // Common bank statement headers
    final hasDate = headerLine.contains('date') ||
        headerLine.contains('posted') ||
        headerLine.contains('transaction');
    final hasAmount = headerLine.contains('amount') ||
        headerLine.contains('debit') ||
        headerLine.contains('credit');
    final hasDescription = headerLine.contains('description') ||
        headerLine.contains('memo') ||
        headerLine.contains('payee') ||
        headerLine.contains('details');

    return hasDate && hasAmount && hasDescription;
  }

  bool _hasValidCsvStructure(List<String> lines) {
    if (lines.length < 2) return false;

    try {
      const converter = CsvToListConverter();
      final rows = converter.convert(lines.take(5).join('\n'));

      // Check we have consistent column count
      if (rows.isEmpty) return false;
      final columnCount = rows.first.length;
      return columnCount >= 2 && rows.every((row) => row.length == columnCount);
    } catch (e) {
      return false;
    }
  }

  /// Auto-detects column mapping from header row.
  ///
  /// Returns null if headers cannot be detected.
  CsvColumnMapping? detectColumnMapping(List<String> headers) {
    final normalizedHeaders =
        headers.map((h) => h.toLowerCase().trim()).toList();

    int? dateIndex;
    int? descriptionIndex;
    int? amountIndex;
    int? indicatorIndex;
    int? debitIndex;
    int? creditIndex;
    int? categoryIndex;
    int? balanceIndex;
    int? memoIndex;
    int? referenceIndex;
    int? codeIndex;
    int? metadataIndex;

    for (int i = 0; i < normalizedHeaders.length; i++) {
      final header = normalizedHeaders[i];

      // Date detection
      if (dateIndex == null &&
          (header.contains('date') ||
              header.contains('posted') ||
              header == 'when' ||
              header == 'datum')) {
        dateIndex = i;
      }

      // Amount detection (single column)
      if (amountIndex == null &&
          (header.contains('amount') ||
              header.contains('sum') ||
              header.contains('value') ||
              header == 'bedrag') &&
          !header.contains('debit') &&
          !header.contains('credit')) {
        amountIndex = i;
      }

      // ING style: single column "Debit/credit" with values "Debit" or "Credit"
      // or "Af Bij" (Dutch)
      if (indicatorIndex == null &&
          (header == 'debit/credit' ||
              header == 'debit / credit' ||
              header == 'af bij')) {
        indicatorIndex = i;
      }
      // Traditional style: separate debit and credit columns
      if (debitIndex == null &&
          (header == 'debit' || header == 'withdrawal' || header == 'af')) {
        debitIndex = i;
      }
      if (creditIndex == null &&
          (header == 'credit' || header == 'deposit' || header == 'bij')) {
        creditIndex = i;
      }

      // Description detection
      if (descriptionIndex == null &&
          (header.contains('description') ||
              header.contains('payee') ||
              header.contains('details') ||
              header == 'naam / omschrijving' ||
              (header.contains('name') && !header.contains('account')))) {
        descriptionIndex = i;
      }

      // Category detection
      if (categoryIndex == null &&
          (header.contains('category') || header == 'categorie')) {
        categoryIndex = i;
      }

      // Reference/Counterparty detection
      if (referenceIndex == null &&
          (header.contains('counterparty') ||
              header.contains('tegenrekening') ||
              header.contains('reference') ||
              (header.contains('account') && !header.contains('name')))) {
        referenceIndex = i;
      }

      // Transaction Code detection
      if (codeIndex == null &&
          (header == 'code' || header == 'trans code' || header == 'type')) {
        // Note: 'type' might overlap with category, but often banks use 'type' for code (GT, OV)
        // If category found 'type', we might want to prefer 'category' for category and 'type' for code?
        // Let's stick to safe defaults.
        codeIndex = i;
      }

      // Metadata/Notifications detection
      if (metadataIndex == null &&
          (header.contains('notification') ||
              header.contains('mededelingen') ||
              header.contains('communication') ||
              header.contains('payment reference'))) {
        metadataIndex = i;
      }

      // Balance detection
      if (balanceIndex == null &&
          (header.contains('balance') ||
              header.contains('running') ||
              header.contains('saldo'))) {
        balanceIndex = i;
      }

      // Memo detection
      if (memoIndex == null &&
          (header.contains('memo') || header.contains('note'))) {
        memoIndex = i;
      }
    }

    // Require at least date and (amount OR debit/credit OR indicator+amount) and description
    if (dateIndex == null || descriptionIndex == null) return null;
    if (amountIndex == null &&
        debitIndex == null &&
        creditIndex == null &&
        indicatorIndex == null) {
      return null;
    }

    return CsvColumnMapping(
      dateColumnIndex: dateIndex,
      // Use -1 as sentinel if no amount column found (e.g. when using separate debit/credit columns)
      amountColumnIndex: amountIndex ?? -1,
      descriptionColumnIndex: descriptionIndex,
      categoryColumnIndex: categoryIndex,
      debitColumnIndex: debitIndex,
      creditColumnIndex: creditIndex,
      debitCreditIndicatorColumnIndex: indicatorIndex,
      balanceColumnIndex: balanceIndex,
      memoColumnIndex: memoIndex,
      referenceColumnIndex: referenceIndex,
      transactionCodeColumnIndex: codeIndex,
      metadataColumnIndex: metadataIndex,
    );
  }

  /// Auto-detects date format from sample data.
  String? detectDateFormat(List<String> sampleDates) {
    // Common date formats to try
    const formats = [
      'yyyyMMdd', // Compact: 20241231 (ING Bank style)
      'yyyy-MM-dd', // ISO: 2024-01-15
      'MM/dd/yyyy', // US: 01/15/2024
      'dd/MM/yyyy', // UK/EU: 15/01/2024
      'M/d/yyyy', // US short: 1/15/2024
      'd/M/yyyy', // UK short: 15/1/2024
      'MM-dd-yyyy', // US dashed: 01-15-2024
      'dd-MM-yyyy', // UK dashed: 15-01-2024
      'yyyy/MM/dd', // ISO slashed: 2024/01/15
      'MMM dd, yyyy', // Long: Jan 15, 2024
      'dd MMM yyyy', // UK Long: 15 Jan 2024
    ];

    for (final format in formats) {
      if (_allDatesMatchFormat(sampleDates, format)) {
        // For ambiguous formats (US vs UK), analyze actual values to determine
        if (format == 'MM/dd/yyyy' || format == 'dd/MM/yyyy') {
          final detected = _detectUsVsUkFormat(sampleDates, '/');
          if (detected != null) return detected;
        }
        if (format == 'MM-dd-yyyy' || format == 'dd-MM-yyyy') {
          final detected = _detectUsVsUkFormat(sampleDates, '-');
          if (detected != null) {
            return detected.replaceAll('/', '-');
          }
        }
        return format;
      }
    }

    return null;
  }

  /// Analyzes date values to determine if US (MM/dd) or UK (dd/MM) format.
  /// Returns null if ambiguous (all values ≤ 12 in both positions).
  String? _detectUsVsUkFormat(List<String> dates, String separator) {
    bool firstPositionMustBeDay = false;
    bool secondPositionMustBeDay = false;

    for (final date in dates) {
      final parts = date.split(separator);
      if (parts.length >= 2) {
        final first = int.tryParse(parts[0]) ?? 0;
        final second = int.tryParse(parts[1]) ?? 0;

        // If value > 12, it must be a day (can't be a month)
        if (first > 12) firstPositionMustBeDay = true;
        if (second > 12) secondPositionMustBeDay = true;
      }
    }

    // Determine format based on which position contains day values
    if (firstPositionMustBeDay && !secondPositionMustBeDay) {
      return 'dd/MM/yyyy'; // UK format - day comes first
    }
    if (secondPositionMustBeDay && !firstPositionMustBeDay) {
      return 'MM/dd/yyyy'; // US format - month comes first
    }
    // Both or neither > 12: truly ambiguous, return null to use order in list
    return null;
  }

  bool _allDatesMatchFormat(List<String> dates, String format) {
    // Simple pattern matching - could be enhanced with intl package
    final pattern = _formatToRegex(format);
    return dates.every((date) => pattern.hasMatch(date.trim()));
  }

  RegExp _formatToRegex(String format) {
    // Convert date format pattern to regex using placeholders to avoid
    // single-character replacements corrupting previously replaced patterns
    // Placeholders must NOT contain any format characters (y, M, d)
    var pattern = format
        // First, replace multi-character patterns with placeholders
        .replaceAll('yyyy', '@@YEAR4@@')
        .replaceAll('MMM', '@@ABBREV@@')
        .replaceAll('MM', '@@TWO_N@@')
        .replaceAll('dd', '@@TWO_AY@@')
        // Then replace single-character patterns
        .replaceAll('M', '@@ONE_TWO_N@@')
        .replaceAll('d', '@@ONE_TWO_AY@@')
        // Handle comma-space in formats like "Jan 15, 2024"
        .replaceAll(', ', r',\s*')
        // Replace placeholders with actual regex patterns
        .replaceAll('@@YEAR4@@', r'\d{4}')
        .replaceAll(
          '@@ABBREV@@',
          r'[A-Za-z]+',
        ) // Was {3}, now + to support full names
        .replaceAll('@@TWO_N@@', r'\d{2}')
        .replaceAll('@@TWO_AY@@', r'\d{2}')
        .replaceAll('@@ONE_TWO_N@@', r'\d{1,2}')
        .replaceAll('@@ONE_TWO_AY@@', r'\d{1,2}');
    return RegExp('^$pattern\$');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Round-Trip Import (Expense Stalker Format)
  // ─────────────────────────────────────────────────────────────────────────

  /// Parses an Expense Stalker CSV export for round-trip editing.
  ///
  /// Runs parsing in an isolate to avoid blocking the UI thread.
  Future<CsvImportResult> parseExpenseStalkerCsv(String csvContent) async {
    return compute(_parseExpenseStalkerCsvIsolate, csvContent);
  }

  static CsvImportResult _parseExpenseStalkerCsvIsolate(String csvContent) {
    final lines = const LineSplitter().convert(csvContent);
    final errors = <String>[];
    final warnings = <String>[];

    // Parse metadata block
    String? accountName;
    DateTime? exportDate;
    int? startingBalanceCents;
    int? paycheckDay;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) {
        continue;
      }

      if (line.startsWith('Account Name,')) {
        accountName = line.substring('Account Name,'.length).trim();
      } else if (line.startsWith('Export Date,')) {
        try {
          exportDate = DateTime.parse(
            line.substring('Export Date,'.length).trim(),
          );
        } catch (e) {
          warnings.add('Could not parse export date');
        }
      } else if (line.startsWith('Starting Balance,')) {
        try {
          final balance = double.parse(
            line.substring('Starting Balance,'.length).trim(),
          );
          startingBalanceCents = (balance * 100).round();
        } catch (e) {
          warnings.add('Could not parse starting balance');
        }
      } else if (line.startsWith('Paycheck Day,')) {
        try {
          paycheckDay = int.parse(
            line.substring('Paycheck Day,'.length).trim(),
          );
        } catch (e) {
          warnings.add('Could not parse paycheck day');
        }
      }

      // Stop metadata parsing when we hit a data header
      if (line.startsWith('Type,Id,')) {
        break;
      }
    }

    // Find section start indices
    int? timelineHeaderIndex;
    int? pulseHeaderIndex;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];
      if (line.startsWith('Type,Id,Label,Amount,StartDate')) {
        timelineHeaderIndex = i;
      } else if (line.startsWith('Type,Id,Label,Amount,Date,Category')) {
        pulseHeaderIndex = i;
      }
    }

    // Parse timeline items
    final timelineItems = <TimelineItem>[];
    if (timelineHeaderIndex != null) {
      final endIndex = pulseHeaderIndex != null
          ? pulseHeaderIndex - 1 // Stop before pulse section
          : lines.length;

      for (int i = timelineHeaderIndex + 1; i < endIndex; i++) {
        final line = lines[i].trim();
        if (line.isEmpty || !line.startsWith('Timeline,')) continue;

        try {
          final item = _parseTimelineRow(line);
          if (item != null) {
            timelineItems.add(item);
          }
        } catch (e) {
          errors.add('Failed to parse timeline item at row ${i + 1}: $e');
        }
      }
    }

    // Parse pulse entries
    final pulses = <PulseEntry>[];
    if (pulseHeaderIndex != null) {
      for (int i = pulseHeaderIndex + 1; i < lines.length; i++) {
        final line = lines[i].trim();
        if (line.isEmpty || !line.startsWith('Pulse,')) continue;

        try {
          final pulse = _parsePulseRow(line);
          if (pulse != null) {
            pulses.add(pulse);
          }
        } catch (e) {
          errors.add('Failed to parse pulse at row ${i + 1}: $e');
        }
      }
    }

    return CsvImportResult(
      format: CsvFormat.expenseStalker,
      timelineItems: timelineItems,
      pulses: pulses,
      accountName: accountName,
      exportDate: exportDate,
      startingBalanceCents: startingBalanceCents,
      paycheckDay: paycheckDay,
      errors: errors,
      warnings: warnings,
    );
  }

  static TimelineItem? _parseTimelineRow(String csvRow) {
    const converter = CsvToListConverter();
    final rows = converter.convert(csvRow);
    if (rows.isEmpty || rows.first.length < 18) return null;

    final row = rows.first.map((e) => e.toString()).toList();

    // Expected columns:
    // 0: Type, 1: Id, 2: Label, 3: Amount, 4: StartDate, 5: Category, 6: Origin,
    // 7: PulseType, 8: Frequency, 9: DayOfMonth, 10: Priority, 11: IsSalary,
    // 12: UseAsPaycheckBoundary, 13: MoneyPotId, 14: Notes, 15: Archived,
    // 16: PausedDate, 17: AutoResumeDate

    if (row[0] != 'Timeline') return null;

    final amount = (double.tryParse(row[3]) ?? 0) * 100;

    // Helper to parse ISO dates and convert to local time (matches JSON import behavior)
    DateTime? parseIsoToLocal(String s) {
      if (s.isEmpty) return null;
      final parsed = DateTime.tryParse(s);
      return parsed?.toLocal();
    }

    return TimelineItem(
      id: TimelineItemId(row[1]),
      label: _unescapeCsvField(row[2]),
      amountMinorUnits: amount.round(),
      // Parse UTC ISO string and convert to local time for consistent behavior
      startDate: parseIsoToLocal(row[4]) ?? DateTime.now(),
      type: PulseType.values.byName(row[7]),
      category: row[5].isNotEmpty ? _unescapeCsvField(row[5]) : null,
      origin: row[6].isNotEmpty ? _unescapeCsvField(row[6]) : null,
      frequency:
          row[8].isNotEmpty ? RecurrenceFrequency.values.byName(row[8]) : null,
      dayOfMonth: int.tryParse(row[9]) ?? 1,
      priority:
          row[10].isNotEmpty ? ExpensePriority.values.byName(row[10]) : null,
      isSalary: row[11].toLowerCase() == 'true',
      useAsPaycheckBoundary: row[12].toLowerCase() == 'true',
      moneyPotId: row[13].isNotEmpty ? MoneyPotId(row[13]) : null,
      notes: row[14].isNotEmpty ? _unescapeCsvField(row[14]) : null,
      archived: row[15].toLowerCase() == 'true',
      pausedDate: parseIsoToLocal(row[16]),
      autoResumeDate: parseIsoToLocal(row[17]),
      subcategory: row.length > 18 && row[18].isNotEmpty
          ? _unescapeCsvField(row[18])
          : null,
      paidOffDate: row.length > 19 ? parseIsoToLocal(row[19]) : null,
      remainingBalanceMinorUnits: row.length > 20 && row[20].isNotEmpty
          ? ((double.tryParse(row[20]) ?? 0) * 100).round()
          : null,
      originalAmountMinorUnits: row.length > 21 && row[21].isNotEmpty
          ? ((double.tryParse(row[21]) ?? 0) * 100).round()
          : null,
      balanceCurrency: row.length > 22 && row[22].isNotEmpty
          ? decodeCurrency(row[22])
          : null,
      exchangeRate: row.length > 23 && row[23].isNotEmpty
          ? double.tryParse(row[23])
          : null,
    );
  }

  static PulseEntry? _parsePulseRow(String csvRow) {
    const converter = CsvToListConverter();
    final rows = converter.convert(csvRow);
    if (rows.isEmpty || rows.first.length < 17) return null;

    final row = rows.first.map((e) => e.toString()).toList();

    // Expected columns:
    // 0: Type, 1: Id, 2: Label, 3: Amount, 4: Date, 5: Category, 6: Origin,
    // 7: PulseType, 8: TimelineItemId, 9: IsStandalone, 10: ScheduledDate,
    // 11: ScheduledAmount, 12: AmountVariance, 13: DaysVariance, 14: Priority,
    // 15: MoneyPotId, 16: Notes

    if (row[0] != 'Pulse') return null;

    final amount = (double.tryParse(row[3]) ?? 0) * 100;
    final scheduledAmount =
        row[11].isNotEmpty ? (double.tryParse(row[11]) ?? 0) * 100 : null;

    // Helper to parse ISO dates and convert to local time (matches JSON import behavior)
    DateTime? parseIsoToLocal(String s) {
      if (s.isEmpty) return null;
      final parsed = DateTime.tryParse(s);
      return parsed?.toLocal();
    }

    return PulseEntry(
      id: EntryId(row[1]),
      label: _unescapeCsvField(row[2]),
      amountMinorUnits: amount.round(),
      // Parse UTC ISO string and convert to local time for consistent behavior
      date: parseIsoToLocal(row[4]) ?? DateTime.now(),
      type: PulseType.values.byName(row[7]),
      category: row[5].isNotEmpty ? _unescapeCsvField(row[5]) : null,
      origin: row[6].isNotEmpty ? _unescapeCsvField(row[6]) : null,
      timelineItemId: row[8].isNotEmpty ? TimelineItemId(row[8]) : null,
      scheduledDate: parseIsoToLocal(row[10]),
      scheduledAmountMinorUnits: scheduledAmount?.round(),
      priority:
          row[14].isNotEmpty ? ExpensePriority.values.byName(row[14]) : null,
      moneyPotId: row[15].isNotEmpty ? MoneyPotId(row[15]) : null,
      notes: row[16].isNotEmpty ? _unescapeCsvField(row[16]) : null,
      subcategory: row.length > 17 && row[17].isNotEmpty
          ? _unescapeCsvField(row[17])
          : null,
      isInternalTransfer:
          row.length > 18 ? row[18].toLowerCase() == 'true' : false,
      source: PulseSource.csvRoundTrip,
    );
  }

  static String _unescapeCsvField(String field) {
    // Remove leading single quote (formula injection protection)
    var result = field;
    if (result.startsWith("'")) {
      result = result.substring(1);
    }
    // Remove surrounding quotes and unescape double quotes
    if (result.startsWith('"') && result.endsWith('"')) {
      result = result.substring(1, result.length - 1);
      result = result.replaceAll('""', '"');
    }
    return result;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Bank Statement Import (Mapped Format)
  // ─────────────────────────────────────────────────────────────────────────

  /// Parses a bank statement CSV using the provided column mapping and config.
  ///
  /// Runs parsing in an isolate to avoid blocking the UI thread.
  Future<CsvImportResult> parseBankStatementCsv(
    String csvContent,
    CsvColumnMapping mapping,
    CsvImportConfig config, {
    TransferDetectionRules? transferRules,
  }) async {
    return compute(
      _parseBankStatementCsvIsolate,
      _BankStatementParseParams(
        csvContent,
        mapping,
        config,
        transferRules: transferRules,
      ),
    );
  }

  static CsvImportResult _parseBankStatementCsvIsolate(
    _BankStatementParseParams params,
  ) {
    final errors = <String>[];
    final warnings = <String>[];
    final pulses = <PulseEntry>[];

    try {
      final normalized = params.csvContent.replaceAll(RegExp(r'\r\n|\r'), '\n');
      const converter = CsvToListConverter(
        eol: '\n',
        shouldParseNumbers: false,
      );
      final rows = converter.convert(normalized);

      if (rows.isEmpty) {
        return const CsvImportResult(
          format: CsvFormat.bankStatement,
          errors: ['CSV file is empty'],
        );
      }

      // Determine row range
      int startRow = params.config.skipFirstRow ? 1 : 0;
      int endRow = params.config.skipLastRow ? rows.length - 1 : rows.length;

      for (int i = startRow; i < endRow; i++) {
        final row = rows[i].map((e) => e.toString()).toList();

        try {
          final pulse = _parseBankRow(
            row,
            params.mapping,
            params.config,
            rowNumber: i + 1,
            transferRules: params.transferRules,
          );
          if (pulse != null) {
            // Apply date range filter
            final normalizedDate = dateOnly(pulse.date);
            if (params.config.startDate != null &&
                normalizedDate.isBefore(dateOnly(params.config.startDate!))) {
              continue;
            }
            if (params.config.endDate != null &&
                normalizedDate.isAfter(dateOnly(params.config.endDate!))) {
              continue;
            }
            pulses.add(pulse);
          }
        } catch (e) {
          errors.add('Row ${i + 1}: $e');
        }
      }

      // Determine the detected final balance
      // We look at the first and last transaction to determine the sort order.
      int? finalBalance;
      if (pulses.isNotEmpty) {
        if (pulses.length >= 2) {
          final first = pulses.first;
          final last = pulses.last;

          // Use O(1) checks for common cases, or sort if needed
          if (!first.date.isBefore(last.date)) {
            // First row is latest or same day as last row
            finalBalance = first.runningBalanceCents;
          } else {
            // Last row is latest
            finalBalance = last.runningBalanceCents;
          }
        } else {
          finalBalance = pulses.first.runningBalanceCents;
        }
      }

      return CsvImportResult(
        format: CsvFormat.bankStatement,
        pulses: pulses,
        detectedFinalBalanceCents: finalBalance,
        errors: errors,
        warnings: warnings,
      );
    } catch (e, st) {
      ErrorTracker.instance.trackException(
        'csv_import',
        'Failed to parse bank statement CSV',
        e,
        st,
      );
      errors.add('Failed to parse CSV: $e');
    }

    return CsvImportResult(
      format: CsvFormat.bankStatement,
      pulses: pulses,
      errors: errors,
      warnings: warnings,
    );
  }

  static bool _isInternalTransfer({
    required List<String> row,
    required CsvColumnMapping mapping,
    TransferDetectionRules? rules,
  }) {
    if (rules == null) return false;

    // Extract fields
    final description = mapping.descriptionColumnIndex < row.length
        ? row[mapping.descriptionColumnIndex].toLowerCase()
        : '';

    // FIX(Issue #35): Also check metadata column for internal transfer patterns.
    // Many banks (especially ING Netherlands) put the descriptive text in a separate
    // "Notifications" or "Mededelingen" column rather than the main description.
    // Example: ING row has "NOTPROVIDED" in description but
    // "To Oranje spaarrekening R56600428 Afronding" in metadata column 8.
    final metadata = mapping.metadataColumnIndex != null &&
            row.length > mapping.metadataColumnIndex!
        ? row[mapping.metadataColumnIndex!].toLowerCase()
        : '';

    // Also check memo column as fallback
    final memo =
        mapping.memoColumnIndex != null && row.length > mapping.memoColumnIndex!
            ? row[mapping.memoColumnIndex!].toLowerCase()
            : '';

    // Combine all text sources for pattern matching
    final allText = '$description $metadata $memo';

    final counterparty = mapping.referenceColumnIndex != null &&
            row.length > mapping.referenceColumnIndex!
        ? row[mapping.referenceColumnIndex!].trim()
        : '';

    final code = mapping.transactionCodeColumnIndex != null &&
            row.length > mapping.transactionCodeColumnIndex!
        ? row[mapping.transactionCodeColumnIndex!].trim()
        : '';

    // Check 1: Description/metadata/memo matches internal account patterns
    // (e.g., "From savings", "To shared account")
    if (rules.internalAccountPatterns.isEmpty) return false;

    final hasInternalAccountKeywords = rules.internalAccountPatterns.any(
      (pattern) => allText.contains(pattern.toLowerCase()),
    );
    if (!hasInternalAccountKeywords) return false;

    // Check 2: Transaction code validation
    // If the bank provides specific codes for transfers (e.g., "TRF"), we verify it.
    if (rules.transferTypeCodes.isNotEmpty) {
      final matchesTransferCode = rules.transferTypeCodes.contains(code);
      if (!matchesTransferCode) return false;
    }

    // Check 3: Counterparty requirements
    // Some formats (like old Rabobank) only use internal descriptions when the
    // counterparty field is empty.
    if (rules.requireEmptyCounterparty && counterparty.isNotEmpty) {
      return false;
    }

    // Check 4: IBAN validation for detected transfers
    // If enabled, we ignore "internal" matches if the counterparty looks like
    // a card number (not an IBAN). Real internal account transfers usually
    // either have an empty counterparty column OR a valid IBAN.
    if (rules.excludeNonIBANCounterparty && counterparty.isNotEmpty) {
      // IBANs always start with 2 letters followed by 2 check digits (e.g., NL99)
      final looksLikeIBAN = RegExp(r'^[A-Z]{2}\d{2}').hasMatch(counterparty);
      if (!looksLikeIBAN) {
        // Detected as internal by text, but contains a non-IBAN counterparty
        // (likely a card transaction). Exclude it.
        return false;
      }
    }

    return true; // Passed all heuristic checks
  }

  static PulseEntry? _parseBankRow(
    List<String> row,
    CsvColumnMapping mapping,
    CsvImportConfig config, {
    required int rowNumber,
    TransferDetectionRules? transferRules,
  }) {
    // Validate row has enough columns
    final maxColumn = [
      mapping.dateColumnIndex,
      mapping.amountColumnIndex,
      mapping.descriptionColumnIndex,
      mapping.categoryColumnIndex,
      mapping.debitColumnIndex,
      mapping.creditColumnIndex,
      mapping.memoColumnIndex,
      mapping.debitCreditIndicatorColumnIndex,
      mapping.balanceColumnIndex,
      mapping.referenceColumnIndex,
      mapping.transactionCodeColumnIndex,
      mapping.metadataColumnIndex,
    ].whereType<int>().fold(0, (a, b) => a > b ? a : b);

    if (row.length <= maxColumn) {
      return null; // Skip incomplete rows
    }

    // Parse date
    final dateStr = row[mapping.dateColumnIndex].trim();
    if (dateStr.isEmpty) return null;

    final date = _parseDate(dateStr, config.dateFormat);
    if (date == null) {
      throw FormatException('Invalid date: $dateStr');
    }

    // Parse amount
    int amountMinorUnits;
    if (mapping.hasSeparateDebitCredit) {
      // Case 1: Separate debit/credit COLUMNS (e.g. Rabobank)
      final debit = mapping.debitColumnIndex != null
          ? _parseAmount(row[mapping.debitColumnIndex!])
          : 0;
      final credit = mapping.creditColumnIndex != null
          ? _parseAmount(row[mapping.creditColumnIndex!])
          : 0;

      // Credits are positive, debits are negative (expenses)
      if (config.treatCreditsAsNegative) {
        amountMinorUnits = debit - credit;
      } else {
        amountMinorUnits = credit - debit;
      }
    } else if (mapping.hasDebitCreditIndicator) {
      // Case 2: Amount column + indicator column (ING format)
      // The amount in CSV is always positive, indicator determines sign
      amountMinorUnits = _parseAmount(row[mapping.amountColumnIndex]);

      // Read indicator column to determine sign
      final indicator =
          row[mapping.debitCreditIndicatorColumnIndex!].trim().toLowerCase();

      // "Debit" = money OUT = negative (expense)
      // "Credit" = money IN = positive (income)
      // Also handle Dutch terms: "Af" (off/out) and "Bij" (to/in)
      if (indicator == 'debit' || indicator == 'af') {
        amountMinorUnits = -amountMinorUnits.abs();
      } else if (indicator == 'credit' || indicator == 'bij') {
        amountMinorUnits = amountMinorUnits.abs();
      }
      // If indicator doesn't match known values, keep the parsed sign

      if (config.invertAmount) {
        amountMinorUnits = -amountMinorUnits;
      }
    } else {
      // Case 3: Single signed amount column
      amountMinorUnits = _parseAmount(row[mapping.amountColumnIndex]);
      if (config.invertAmount) {
        amountMinorUnits = -amountMinorUnits;
      }
    }

    // Parse description
    final rawDescription = row[mapping.descriptionColumnIndex].trim();
    if (rawDescription.isEmpty) return null;

    final description = _cleanBankDescription(rawDescription);

    // Parse optional fields
    final category = mapping.categoryColumnIndex != null &&
            row.length > mapping.categoryColumnIndex!
        ? row[mapping.categoryColumnIndex!].trim()
        : null;
    final memo =
        mapping.memoColumnIndex != null && row.length > mapping.memoColumnIndex!
            ? row[mapping.memoColumnIndex!].trim()
            : null;

    final reference = mapping.referenceColumnIndex != null &&
            row.length > mapping.referenceColumnIndex!
        ? row[mapping.referenceColumnIndex!].trim()
        : null;

    final metadata = mapping.metadataColumnIndex != null &&
            row.length > mapping.metadataColumnIndex!
        ? row[mapping.metadataColumnIndex!].trim()
        : null;

    final runningBalance = mapping.balanceColumnIndex != null &&
            row.length > mapping.balanceColumnIndex!
        ? _parseAmount(row[mapping.balanceColumnIndex!])
        : null;

    // Detect internal transfer
    final isInternal = _isInternalTransfer(
      row: row,
      mapping: mapping,
      rules: transferRules,
    );

    // FIX(Issue #34): Determine pulse type based on amount sign AFTER sign normalization.
    // At this point, amountMinorUnits has been correctly signed by the debit/credit
    // indicator logic above (lines 1190-1217):
    // - Positive values = income (money IN / credits)
    // - Negative values = expenses (money OUT / debits)
    //
    // Previously, this code incorrectly classified positive amounts as income even
    // when they represented expenses (e.g., Dutch banks export debits as positive
    // with an "Af" indicator, which gets negated above).
    //
    // The fix: Only use oneOffIncome for actual positive values (true income).
    // For expenses (negative), use the config.defaultType (usually oneOff).
    final PulseType pulseType;
    if (amountMinorUnits > 0) {
      // Positive = income (credits, money received)
      pulseType = PulseType.oneOffIncome;
    } else if (amountMinorUnits < 0) {
      // Negative = expense (debits, money spent)
      // Use defaultType but ensure it's not an income type
      pulseType = config.defaultType.isIncomeType
          ? PulseType.oneOff
          : config.defaultType;
    } else {
      // Zero amount - use default
      pulseType = config.defaultType;
    }

    return PulseEntry(
      id: newEntryId(),
      label: description,
      amountMinorUnits: config.ensurePositiveValues
          ? amountMinorUnits.abs()
          : amountMinorUnits,
      date: date,
      type: pulseType,
      category: category?.isNotEmpty == true ? category : null,
      notes: memo?.isNotEmpty == true ? memo : null,
      source: PulseSource.bankImport,
      rawImportDescription: rawDescription,
      importReference: reference?.isNotEmpty == true ? reference : null,
      importMetadata: metadata?.isNotEmpty == true ? metadata : null,
      isInternalTransfer: isInternal,
      runningBalanceCents: runningBalance,
    );
  }

  static DateTime? _parseDate(String dateStr, String format) {
    // Handle yyyyMMdd format specially (no separators)
    if (format == 'yyyyMMdd' && dateStr.length == 8) {
      try {
        return DateTime(
          int.parse(dateStr.substring(0, 4)),
          int.parse(dateStr.substring(4, 6)),
          int.parse(dateStr.substring(6, 8)),
        );
      } catch (e) {
        // Ignore parse failure, try next format
        debugLog(
            LogCategory.persistence, 'Compact date parsing failed for $dateStr',
            error: e);
      }
    }

    // Try ISO format first (most reliable)
    try {
      return DateTime.parse(dateStr);
    } catch (_) {
      // Ignore parse failure, try next format
    }

    // Try format-specific parsing
    try {
      return parseDateWithFormat(dateStr, format);
    } catch (_) {
      // Ignore parse failure, try next format
    }

    // Try common formats as fallback
    const fallbackFormats = [
      'MM/dd/yyyy',
      'dd/MM/yyyy',
      'yyyy-MM-dd',
      'M/d/yyyy',
    ];

    for (final fmt in fallbackFormats) {
      try {
        return parseDateWithFormat(dateStr, fmt);
      } catch (_) {
        // Ignore parse failure, continue to next format
      }
    }

    return null;
  }

  /// Parse a date string using a specific format pattern.
  ///
  /// Supports patterns like:
  /// - `yyyy-MM-dd`, `MM/dd/yyyy`, `dd/MM/yyyy`
  /// - `yyyyMMdd` (no separators)
  /// - `M/d/yyyy`, `d/M/yyyy` (single digit month/day)
  /// - `dd MMM yyyy` (15 Jan 2024)
  static DateTime parseDateWithFormat(String dateStr, String format) {
    // Handle yyyyMMdd format specially (no separators)
    if (format == 'yyyyMMdd' && dateStr.length == 8) {
      return DateTime(
        int.parse(dateStr.substring(0, 4)),
        int.parse(dateStr.substring(4, 6)),
        int.parse(dateStr.substring(6, 8)),
      );
    }

    // Simple pattern-based parsing
    // This is a basic implementation - could be enhanced with intl package

    final parts = dateStr.split(RegExp(r'[/\-\s,\.]+'));
    if (parts.length < 3) throw const FormatException('Invalid date');

    int year, month, day;

    if (format.startsWith('yyyy')) {
      year = _parseDatePart(parts[0]);
      month = _parseDatePart(parts[1]);
      day = _parseDatePart(parts[2]);
    } else if (format.startsWith('MM') || format.startsWith('M')) {
      month = _parseDatePart(parts[0]);
      day = _parseDatePart(parts[1]);
      year = _parseDatePart(parts[2]);
    } else if (format.startsWith('dd') || format.startsWith('d')) {
      day = _parseDatePart(parts[0]);
      month = _parseDatePart(parts[1]);
      year = _parseDatePart(parts[2]);
    } else {
      throw FormatException('Unknown format: $format');
    }

    // Handle 2-digit years
    if (year < 100) {
      year += year > 50 ? 1900 : 2000;
    }

    return DateTime(year, month, day);
  }

  static int _parseDatePart(String part) {
    // Try numeric first
    final val = int.tryParse(part);
    if (val != null) return val;

    // Try month names
    final lower = part.toLowerCase();
    switch (lower) {
      case 'jan':
      case 'january':
        return 1;
      case 'feb':
      case 'february':
        return 2;
      case 'mar':
      case 'march':
        return 3;
      case 'apr':
      case 'april':
        return 4;
      case 'may':
        return 5;
      case 'jun':
      case 'june':
        return 6;
      case 'jul':
      case 'july':
        return 7;
      case 'aug':
      case 'august':
        return 8;
      case 'sep':
      case 'september':
        return 9;
      case 'oct':
      case 'october':
        return 10;
      case 'nov':
      case 'november':
        return 11;
      case 'dec':
      case 'december':
        return 12;
    }

    throw FormatException('Invalid date part: $part');
  }

  static int _parseAmount(String amountStr) {
    if (amountStr.isEmpty) return 0;

    // Remove currency symbols and whitespace
    var cleaned = amountStr.replaceAll(RegExp(r'[\$£€¥₹\s]'), '');

    // Handle parentheses for negative (accounting format)
    final isNegative = cleaned.startsWith('(') && cleaned.endsWith(')');
    if (isNegative) {
      cleaned = cleaned.substring(1, cleaned.length - 1);
    }

    // Handle explicit negative sign
    final hasNegativeSign = cleaned.startsWith('-');
    if (hasNegativeSign) {
      cleaned = cleaned.substring(1);
    }

    // Remove thousands separators (could be comma or period depending on locale)
    // Assume the last separator is decimal
    final parts = cleaned.split(RegExp(r'[.,]'));

    double value;
    if (parts.length == 1) {
      value = double.parse(parts[0]);
    } else if (parts.last.length == 2) {
      // Last part is decimal (e.g., "1,234.56" or "1.234,56")
      final wholePart = parts.sublist(0, parts.length - 1).join('');
      value = double.parse('$wholePart.${parts.last}');
    } else {
      // No decimal separator, just thousands (e.g., "1,234")
      value = double.parse(parts.join(''));
    }

    // Apply sign
    if (isNegative || hasNegativeSign) {
      value = -value;
    }

    return (value * 100).round();
  }

  static String _cleanBankDescription(String description) {
    // Remove common bank prefixes/suffixes
    var cleaned = description
        .replaceAll(
          RegExp(r'^(POS|ACH|DEBIT|CREDIT|TRANSFER)\s*', caseSensitive: false),
          '',
        )
        .replaceAll(
          RegExp(r'\s+\d{4,}$'),
          '',
        ) // Remove trailing numbers (card numbers, etc.)
        .replaceAll(RegExp(r'\s+\d{2}/\d{2}$'), '') // Remove trailing dates
        .trim();

    // Capitalize first letter of each word
    if (cleaned.isNotEmpty) {
      cleaned = cleaned.split(' ').map((word) {
        if (word.isEmpty) return word;
        return word[0].toUpperCase() + word.substring(1).toLowerCase();
      }).join(' ');
    }

    return cleaned.isEmpty ? description : cleaned;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Utility Methods
  // ─────────────────────────────────────────────────────────────────────────

  /// Parses CSV content and returns raw rows for preview.
  List<List<String>> parseRawCsv(String csvContent, {int maxRows = 10}) {
    try {
      // Normalize newlines to \n
      final normalized = csvContent.replaceAll(RegExp(r'\r\n|\r'), '\n');
      const converter = CsvToListConverter(
        eol: '\n',
        shouldParseNumbers: false,
      );
      final rows = converter.convert(normalized);

      return rows
          .take(maxRows)
          .map((row) => row.map((e) => e.toString()).toList())
          .toList();
    } catch (e) {
      debugLog(LogCategory.persistence, 'Failed to parse raw CSV', error: e);
      return [];
    }
  }

  /// Extracts header row from CSV content.
  List<String>? getHeaders(String csvContent) {
    try {
      // Normalize newlines to \n
      final normalized = csvContent.replaceAll(RegExp(r'\r\n|\r'), '\n');
      const converter = CsvToListConverter(
        eol: '\n',
        shouldParseNumbers: false,
      );
      final rows = converter.convert(normalized);

      if (rows.isEmpty) return null;
      return rows.first.map((e) => e.toString().trim()).toList();
    } catch (e) {
      return null;
    }
  }
}

/// Parameters for bank statement parsing isolate.
class _BankStatementParseParams {
  const _BankStatementParseParams(
    this.csvContent,
    this.mapping,
    this.config, {
    this.transferRules,
  });

  final String csvContent;
  final CsvColumnMapping mapping;
  final CsvImportConfig config;
  final TransferDetectionRules? transferRules;
}
