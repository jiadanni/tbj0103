import 'dart:async';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/util/async_queue.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/test_data_generator.dart';

/// Service responsible for account management operations like creation, deletion,
/// renaming, and switching.
///
/// This service handles the persistent side-effects of these operations.
class AccountService {
  final ExpensePersistence _persistence;
  final AsyncQueue _queue = AsyncQueue();

  AccountService(this._persistence);

  /// Creates a new account with the given [name].
  ///
  /// specific [testSize] can be provided to generate test data.
  /// Returns the updated list of accounts.
  Future<List<Account>> createAccount(
    List<Account> currentAccounts,
    String name, {
    TestDatasetSize? testSize,
    int? iconCodePoint,
  }) async {
    return _queue.enqueue(() async {
      final newAccount = Account.create(
        name: name,
        isTestData: testSize != null,
        iconCodePoint: iconCodePoint,
      );
      final updatedAccounts = List<Account>.from(currentAccounts)
        ..add(newAccount);

      await _persistence.saveAccounts(updatedAccounts);

      if (testSize != null) {
        final testData = TestDataGenerator.generate(size: testSize);
        final snapshot = ExpenseSnapshot(
          selectedMonth: monthOnly(DateTime.now()),
          timelineItems: testData.timelineItems,
          pulses: testData.pulses,
          moneyPots: testData.moneyPots,
          accountSettings: newAccount,
        );
        await _persistence.save(newAccount.id, snapshot);
      } else {
        await _persistence.save(
          newAccount.id,
          ExpenseSnapshot(
            selectedMonth: monthOnly(DateTime.now()),
            timelineItems: [],
            pulses: [],
            accountSettings: newAccount,
          ),
        );
      }

      return List.unmodifiable(updatedAccounts);
    });
  }

  /// Deletes the account with [accountId].
  ///
  /// Returns a record containing the updated list of accounts and a boolean
  /// indicating if the deleted account was the current one (triggering a switch).
  Future<({List<Account> accounts, bool wasCurrent})> deleteAccount(
    List<Account> currentAccounts,
    AccountId accountId,
    AccountId currentAccountId,
  ) async {
    return _queue.enqueue(() async {
      if (currentAccounts.length <= 1) {
        return (accounts: currentAccounts, wasCurrent: false);
      }

      final updatedAccounts =
          currentAccounts.where((a) => a.id != accountId).toList();
      await _persistence.saveAccounts(updatedAccounts);
      await _persistence.deleteAccountData(accountId);

      return (
        accounts: List<Account>.unmodifiable(updatedAccounts),
        wasCurrent: accountId == currentAccountId,
      );
    });
  }

  /// Updates the account with [accountId].
  ///
  /// Null values for [name] or [iconCodePoint] will be ignored (value kept as is).
  /// To clear the icon, codePoint should not be used (logic to be refined if clearing is needed,
  /// but currently we only support setting/changing).
  ///
  /// Returns the updated list of accounts.
  Future<List<Account>> updateAccount(
    List<Account> currentAccounts,
    AccountId accountId, {
    String? name,
    int? iconCodePoint,
  }) async {
    return _queue.enqueue(() async {
      final index = currentAccounts.indexWhere((a) => a.id == accountId);
      if (index < 0) return currentAccounts;

      final updatedAccount = currentAccounts[index].copyWith(
        name: name,
        iconCodePoint: iconCodePoint,
        lastModified: DateTime.now(),
      );

      final updatedAccounts = List<Account>.from(currentAccounts);
      updatedAccounts[index] = updatedAccount;

      await _persistence.saveAccounts(updatedAccounts);

      return List.unmodifiable(updatedAccounts);
    });
  }

  /// Loads the data for the target [accountId].
  ///
  /// Returns the loaded [ExpenseSnapshot] or null if loading failed/account doesn't exist.
  Future<ExpenseSnapshot?> loadAccountData(AccountId accountId) async {
    return _queue.enqueue(() async {
      return _persistence.load(accountId);
    });
  }
}
