import 'dart:convert';

import 'package:expense_stalker_mobile/src/models/bank_profile.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

/// Service for persisting and retrieving bank CSV import profiles.
class BankProfileService {
  BankProfileService(this._storage);

  final StorageProvider _storage;
  static const _userProfilesKey = 'bank_profiles';
  static const _recentProfilesKey = 'bank_profiles_recent';

  /// Load all user-saved profiles.
  Future<List<BankProfile>> loadUserProfiles() async {
    final json = await _storage.getString(_userProfilesKey);
    if (json == null) return [];

    try {
      final list = jsonDecode(json) as List<dynamic>;
      return list
          .map((e) => BankProfile.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Save a new or updated profile.
  Future<bool> saveProfile(BankProfile profile) async {
    final profiles = await loadUserProfiles();

    // Remove existing profile with same ID
    profiles.removeWhere((p) => p.id == profile.id);

    // Add updated profile
    profiles.add(profile);

    return _storage.setString(
      _userProfilesKey,
      jsonEncode(profiles.map((p) => p.toJson()).toList()),
    );
  }

  /// Delete a user profile by ID.
  Future<bool> deleteProfile(String profileId) async {
    final profiles = await loadUserProfiles();
    profiles.removeWhere((p) => p.id == profileId);

    if (profiles.isEmpty) {
      return _storage.remove(_userProfilesKey);
    }

    return _storage.setString(
      _userProfilesKey,
      jsonEncode(profiles.map((p) => p.toJson()).toList()),
    );
  }

  /// Mark a profile as recently used (updates lastUsed timestamp).
  Future<void> markUsed(String profileId) async {
    // Try user profiles first
    final userProfiles = await loadUserProfiles();
    final userIndex = userProfiles.indexWhere((p) => p.id == profileId);

    if (userIndex >= 0) {
      final updated = userProfiles[userIndex].copyWith(
        lastUsed: DateTime.now(),
      );
      userProfiles[userIndex] = updated;
      await _storage.setString(
        _userProfilesKey,
        jsonEncode(userProfiles.map((p) => p.toJson()).toList()),
      );
    }

    // Track in recent list
    await _updateRecentList(profileId);
  }

  Future<void> _updateRecentList(String profileId) async {
    final recentJson = await _storage.getString(_recentProfilesKey);
    List<String> recent = [];

    if (recentJson != null) {
      try {
        recent = (jsonDecode(recentJson) as List<dynamic>).cast<String>();
      } catch (_) {
        // Ignore parsing errors
      }
    }

    // Remove if already in list, add to front
    recent.remove(profileId);
    recent.insert(0, profileId);

    // Keep only last 10
    if (recent.length > 10) {
      recent = recent.sublist(0, 10);
    }

    await _storage.setString(_recentProfilesKey, jsonEncode(recent));
  }

  /// Get recently used profile IDs (most recent first).
  Future<List<String>> getRecentProfileIds() async {
    final recentJson = await _storage.getString(_recentProfilesKey);
    if (recentJson == null) return [];

    try {
      return (jsonDecode(recentJson) as List<dynamic>).cast<String>();
    } catch (_) {
      return [];
    }
  }

  /// Get all available profiles (user + community), sorted by recency.
  Future<List<BankProfile>> getAllProfiles() async {
    final userProfiles = await loadUserProfiles();
    final communityProfiles = CommunityBankProfiles.profiles;
    final recentIds = await getRecentProfileIds();

    final all = [...userProfiles, ...communityProfiles];

    // Sort by: recent first, then user profiles, then alphabetically
    all.sort((a, b) {
      final aRecentIndex = recentIds.indexOf(a.id);
      final bRecentIndex = recentIds.indexOf(b.id);

      // Both in recent list - sort by recent order
      if (aRecentIndex >= 0 && bRecentIndex >= 0) {
        return aRecentIndex.compareTo(bRecentIndex);
      }

      // Only one in recent list - that one comes first
      if (aRecentIndex >= 0) return -1;
      if (bRecentIndex >= 0) return 1;

      // Neither in recent - user profiles before community
      if (a.isBuiltIn != b.isBuiltIn) {
        return a.isBuiltIn ? 1 : -1;
      }

      // Same type - alphabetically
      return a.name.compareTo(b.name);
    });

    return all;
  }

  /// Find a profile by ID (searches both user and community).
  Future<BankProfile?> findById(String id) async {
    final userProfiles = await loadUserProfiles();
    final found = userProfiles.where((p) => p.id == id).firstOrNull;
    if (found != null) return found;

    return CommunityBankProfiles.profiles.where((p) => p.id == id).firstOrNull;
  }

  /// Try to auto-detect a bank from CSV headers.
  BankProfile? detectFromHeaders(List<String> headers) {
    return CommunityBankProfiles.detectFromHeaders(headers);
  }
}
