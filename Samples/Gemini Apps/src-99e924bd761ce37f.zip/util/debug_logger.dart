import 'dart:collection';
import 'dart:convert';

import 'package:flutter/foundation.dart';

/// Log categories for structured debug logging.
enum LogCategory {
  persistence('PERSIST'),
  state('STATE'),
  ui('UI'),
  network('NETWORK'),
  export('EXPORT');

  const LogCategory(this.prefix);
  final String prefix;
}

/// Represents a single log entry with full context.
class LogEntry {
  const LogEntry({
    required this.timestamp,
    required this.category,
    required this.message,
    this.error,
    this.stackTrace,
  });

  final DateTime timestamp;
  final LogCategory category;
  final String message;
  final String? error;
  final String? stackTrace;

  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toUtc().toIso8601String(),
      'category': category.prefix,
      'message': message,
      if (error != null) 'error': error,
      if (stackTrace != null) 'stackTrace': stackTrace,
    };
  }

  @override
  String toString() {
    final buffer = StringBuffer();
    buffer.write(
      '${timestamp.toIso8601String()} [${category.prefix}] $message',
    );
    if (error != null) buffer.write('\n  Error: $error');
    if (stackTrace != null) {
      final lines = stackTrace!.split('\n').take(5);
      for (final line in lines) {
        buffer.write('\n  $line');
      }
    }
    return buffer.toString();
  }
}

/// Persistent debug logger that maintains an in-memory log history.
///
/// Logs are captured in memory and can be exported for debugging/AI analysis.
/// The logger maintains a circular buffer to prevent unbounded memory growth.
class DebugLogger {
  DebugLogger._();

  static final DebugLogger instance = DebugLogger._();

  /// Maximum number of log entries to retain.
  static const int maxLogEntries = 500;

  final Queue<LogEntry> _logHistory = Queue<LogEntry>();

  /// Add a log entry.
  void log(
    LogCategory category,
    String message, {
    Object? error,
    StackTrace? stackTrace,
  }) {
    final entry = LogEntry(
      timestamp: DateTime.now(),
      category: category,
      message: message,
      error: error?.toString(),
      stackTrace: stackTrace?.toString(),
    );

    _logHistory.add(entry);

    // Trim if over capacity
    while (_logHistory.length > maxLogEntries) {
      _logHistory.removeFirst();
    }

    // Also print to console in debug mode
    if (kDebugMode) {
      debugPrint(entry.toString());
    }
  }

  /// Get all log entries.
  List<LogEntry> getLogHistory() {
    return List.unmodifiable(_logHistory.toList());
  }

  /// Getter for compliance with diagnostic dashboard.
  Iterable<LogEntry> get logHistory => _logHistory;

  /// Get log entries filtered by category.
  List<LogEntry> getLogsByCategory(LogCategory category) {
    return _logHistory.where((e) => e.category == category).toList();
  }

  /// Get log entries within a time range.
  List<LogEntry> getLogsByTimeRange(DateTime start, DateTime end) {
    return _logHistory.where((e) {
      return !e.timestamp.isBefore(start) && !e.timestamp.isAfter(end);
    }).toList();
  }

  /// Get recent log entries.
  List<LogEntry> getRecentLogs({int count = 100}) {
    final logs = _logHistory.toList();
    final start = (logs.length - count).clamp(0, logs.length);
    return logs.sublist(start);
  }

  /// Export all logs as JSON.
  Map<String, dynamic> toJson() {
    return {
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'totalEntries': _logHistory.length,
      'maxCapacity': maxLogEntries,
      'logs': _logHistory.map((e) => e.toJson()).toList(),
    };
  }

  /// Export logs as a formatted string (useful for plain text export).
  String toFormattedString() {
    final buffer = StringBuffer();
    buffer.writeln('=== Debug Log Export ===');
    buffer.writeln('Exported: ${DateTime.now().toIso8601String()}');
    buffer.writeln('Total Entries: ${_logHistory.length}');
    buffer.writeln('');

    for (final entry in _logHistory) {
      buffer.writeln(entry.toString());
      buffer.writeln('');
    }

    return buffer.toString();
  }

  /// Export logs as a JSON string.
  String toJsonString({bool pretty = false}) {
    if (pretty) {
      return const JsonEncoder.withIndent('  ').convert(toJson());
    }
    return jsonEncode(toJson());
  }

  /// Clear all log history.
  void clear() {
    _logHistory.clear();
  }

  /// Get statistics about logged entries.
  Map<String, int> getStatistics() {
    final stats = <String, int>{};
    for (final entry in _logHistory) {
      final key = entry.category.prefix;
      stats[key] = (stats[key] ?? 0) + 1;
    }
    return stats;
  }

  /// Get count of entries with errors.
  int get errorCount => _logHistory.where((e) => e.error != null).length;

  /// Get total log count.
  int get logCount => _logHistory.length;
}

/// Logs a debug message with optional error and stack trace.
///
/// This is the primary logging function - it logs to both the persistent
/// DebugLogger and the console (in debug mode).
///
/// Formatting includes:
/// - ISO 8601 timestamp
/// - Category prefix [PERSIST], [STATE], etc.
/// - Message
/// - Optional error object
/// - Optional stack trace (first 5 lines)
///
/// Example:
/// ```dart
/// debugLog(
///   LogCategory.persistence,
///   'Failed to save data',
///   error: exception,
///   stackTrace: stack,
/// );
/// ```
void debugLog(
  LogCategory category,
  String message, {
  Object? error,
  StackTrace? stackTrace,
}) {
  DebugLogger.instance.log(
    category,
    message,
    error: error,
    stackTrace: stackTrace,
  );
}
