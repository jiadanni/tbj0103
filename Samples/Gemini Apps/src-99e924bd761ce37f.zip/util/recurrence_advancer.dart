import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

/// Utility for advancing recurring TimelineItem start dates after archiving.
///
/// In calendar mode, when a recurring item is marked as paid, its start date
/// is advanced to the next occurrence. This effectively "moves it forward"
/// so it no longer appears in the current period.
///
/// ## Background
/// This logic was extracted from `timeline_actions.dart` to improve
/// readability and testability. The original implementation included an
/// 80+ line comment explaining the edge cases and design decisions.
///
/// ## Key Behaviors
/// - Only advances items in calendar mode (paycheck mode handles differently)
/// - Only applies to recurring types (recurring, recurringIncome, debt)
/// - Calculates next date based on the item's frequency
class RecurrenceAdvancer {
  /// Calculates the next start date for a recurring item after it has been
  /// archived in the current period.
  ///
  /// Returns `null` if the item should not be advanced (non-recurring type,
  /// not in calendar mode, etc.).
  ///
  /// The [scheduledDate] should be the date of the occurrence that was just
  /// archived, not the item's original start date.
  ///
  /// FIX(Issue #4): Added optional business day adjustment for weekly/biweekly
  /// items to prevent drift when payday adjustment settings are enabled.
  static DateTime? calculateNextStartDate({
    required TimelineItem item,
    required DateTime scheduledDate,
    required ViewPeriodMode viewPeriodMode,
    bool businessAdjust = false,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
  }) {
    // Only advance in calendar mode. Paycheck mode uses visual clearing.
    if (viewPeriodMode != ViewPeriodMode.calendar) return null;

    // Only advance recurring item types
    if (!_isRecurringType(item.type)) return null;

    return _advanceByFrequency(
      scheduledDate,
      item.frequency,
      businessAdjust: businessAdjust,
      adjustDirection: adjustDirection,
    );
  }

  /// Returns true if the pulse type represents a recurring item that should
  /// have its start date advanced after archiving.
  static bool _isRecurringType(PulseType type) {
    return type == PulseType.recurring ||
        type == PulseType.recurringIncome ||
        type == PulseType.debt;
  }

  /// Advances the given date by the specified frequency.
  ///
  /// Defaults to monthly if frequency is null (legacy items).
  ///
  /// FIX(Issue #4): For weekly/biweekly items, optionally apply business day
  /// adjustment to prevent drift when the user has payday adjustment enabled.
  static DateTime _advanceByFrequency(
    DateTime date,
    RecurrenceFrequency? frequency, {
    bool businessAdjust = false,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
  }) {
    final freq = frequency ?? RecurrenceFrequency.monthly;

    DateTime result;
    switch (freq) {
      case RecurrenceFrequency.weekly:
        result = date.add(const Duration(days: 7));
        break;
      case RecurrenceFrequency.biweekly:
        result = date.add(const Duration(days: 14));
        break;
      case RecurrenceFrequency.monthly:
        return month_math.addMonths(date, 1);
      case RecurrenceFrequency.quarterly:
        return month_math.addMonths(date, 3);
      case RecurrenceFrequency.yearly:
        return month_math.addMonths(date, 12);
    }

    // Apply business day adjustment for weekly/biweekly if enabled
    if (businessAdjust) {
      result = _applyBusinessAdjust(result, adjustDirection);
    }

    return result;
  }

  /// Adjusts a date to avoid weekends based on the specified direction.
  static DateTime _applyBusinessAdjust(
    DateTime d,
    PaycheckAdjustDirection adjustDirection,
  ) {
    // Saturday (6) -> move to Friday (before) or Monday (after)
    if (d.weekday == DateTime.saturday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 1))
          : d.add(const Duration(days: 2));
    }
    // Sunday (7) -> move to Friday (before) or Monday (after)
    if (d.weekday == DateTime.sunday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 2))
          : d.add(const Duration(days: 1));
    }
    return d;
  }
}
