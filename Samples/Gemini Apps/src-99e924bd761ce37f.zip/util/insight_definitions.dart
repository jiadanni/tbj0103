import 'package:expense_stalker_mobile/src/models/insight_definition.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';

/// Initial set of insight definitions migrated from InsightsCalculator.
final List<InsightDefinition> initialInsightDefinitions = [
  // 1. Top Spending Category
  InsightDefinition(
    id: 'top_spending_category',
    question: 'What do I spend the most on?',
    category: InsightCategory.spending,
    tier: InsightTier.core,
    minDataDays: 14,
    canGenerate: (context) => context.categorySpending.isNotEmpty,
    generate: (context) {
      final top = context.categorySpending.first;
      return SmartInsight(
        question: 'What do I spend the most on?',
        answer:
            '${top.category} — ${context.formatMoney(top.averageMonthlyMinorUnits)}/month average',
        icon: 'chartPie',
      );
    },
  ),

  // 2. Priority Breakdown
  InsightDefinition(
    id: 'priority_breakdown',
    question: 'How is my spending distributed?',
    category: InsightCategory.spending,
    tier: InsightTier.core,
    minDataDays: 30, // Needs reasonable data for breakdown
    canGenerate: (context) => context.priorityBreakdown.totalMinorUnits > 0,
    generate: (context) {
      final pb = context.priorityBreakdown;
      return SmartInsight(
        question: 'How is my spending distributed?',
        answer: '${pb.criticalPercentage.toStringAsFixed(0)}% essential, '
            '${pb.advisablePercentage.toStringAsFixed(0)}% important, '
            '${pb.optionalPercentage.toStringAsFixed(0)}% discretionary',
        icon: 'chartDonut',
      );
    },
  ),

  // 3. Daily Spending Average
  InsightDefinition(
    id: 'daily_spending_average',
    question: 'What is my daily spending average?',
    category: InsightCategory.spending,
    tier: InsightTier.core,
    minDataDays: 5,
    canGenerate: (context) => context.filteredPulses.isNotEmpty,
    generate: (context) {
      final expensePulses =
          context.filteredPulses.where((p) => !p.type.isIncomeType).toList();
      if (expensePulses.isEmpty) {
        // Fallback if no expenses but definition generated
        return const SmartInsight(
          question: 'Daily Average',
          answer: 'N/A',
          icon: 'calendar',
        );
      }

      final totalSpent = expensePulses.fold<int>(
        0,
        (sum, p) => sum + p.amountMinorUnits.abs(),
      );

      // Calculate day span
      int days = 1;
      if (context.filteredPulses.isNotEmpty) {
        final dates = context.filteredPulses.map((p) => p.date);
        final earliest = dates.reduce((a, b) => a.isBefore(b) ? a : b);
        final latest = dates.reduce((a, b) => a.isAfter(b) ? a : b);
        days = latest.difference(earliest).inDays + 1;
      }

      final dailyAvg = days > 0 ? totalSpent ~/ days : totalSpent;

      return SmartInsight(
        question: 'What is my daily spending average?',
        answer: '${context.formatMoney(dailyAvg)}/day',
        icon: 'calendar',
      );
    },
  ),

  // 4. Largest Single Expense
  InsightDefinition(
    id: 'largest_single_expense',
    question: 'What was my largest single expense?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 2,
    canGenerate: (context) =>
        context.filteredPulses.any((p) => !p.type.isIncomeType),
    generate: (context) {
      final expensePulses =
          context.filteredPulses.where((p) => !p.type.isIncomeType).toList();
      final largest = expensePulses.reduce(
        (curr, next) =>
            curr.amountMinorUnits.abs() > next.amountMinorUnits.abs()
                ? curr
                : next,
      );

      // Prefer label, fallback to category, then "Unknown"
      final label = largest.label.isNotEmpty
          ? largest.label
          : (largest.category ?? 'Unknown');

      return SmartInsight(
        question: 'What was my largest single expense?',
        answer:
            '$label — ${context.formatMoney(largest.amountMinorUnits.abs())}',
        icon: 'trophy',
      );
    },
  ),

  // --- Category Specific Insights ---

  // 5. Groceries
  InsightDefinition(
    id: 'monthly_groceries',
    question: "What's my average monthly grocery bill?",
    category: InsightCategory.spending,
    tier: InsightTier.core,
    minDataDays: 30, // Need a month to have an average
    canGenerate: (context) => context.hasCategory('grocer'),
    generate: (context) {
      // Find the specific category object to get the pre-calculated average
      final match = context.categorySpending
          .where((c) => c.category.toLowerCase().contains('grocer'))
          .first;
      return SmartInsight(
        question: "What's my average monthly grocery bill?",
        answer: context.formatMoney(match.averageMonthlyMinorUnits),
        icon: 'shoppingCart',
      );
    },
  ),

  // 6. Dining Out
  InsightDefinition(
    id: 'dining_out_spending',
    question: 'How much do I spend eating out?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 30,
    canGenerate: (context) =>
        context.hasCategory('dining') ||
        context.hasCategory('restaurant') ||
        context.hasCategory('food'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('dining') ||
            c.category.toLowerCase().contains('restaurant') ||
            c.category.toLowerCase().contains('food'),
      );
      return SmartInsight(
        question: 'How much do I spend eating out?',
        answer:
            '${context.formatMoney(match.averageMonthlyMinorUnits)}/month on average',
        icon: 'forkKnife',
      );
    },
  ),

  // 7. Subscriptions
  InsightDefinition(
    id: 'subscription_spending',
    question: 'How much do I spend on subscriptions?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 30,
    canGenerate: (context) => context.hasCategory('subscript'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) => c.category.toLowerCase().contains('subscript'),
      );
      return SmartInsight(
        question: 'How much do I spend on subscriptions?',
        answer:
            '${context.formatMoney(match.averageMonthlyMinorUnits)}/month (${context.formatMoney(match.averageMonthlyMinorUnits * 12)}/year)',
        icon: 'repeat',
      );
    },
  ),

  // 8. Transport
  InsightDefinition(
    id: 'transport_spending',
    question: 'How much do I spend on transport?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 30,
    canGenerate: (context) =>
        context.hasCategory('transport') ||
        context.hasCategory('fuel') ||
        context.hasCategory('car') ||
        context.hasCategory('taxi') ||
        context.hasCategory('uber') ||
        context.hasCategory('bus') ||
        context.hasCategory('train'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('transport') ||
            c.category.toLowerCase().contains('fuel') ||
            c.category.toLowerCase().contains('car') ||
            c.category.toLowerCase().contains('taxi') ||
            c.category.toLowerCase().contains('uber') ||
            c.category.toLowerCase().contains('bus') ||
            c.category.toLowerCase().contains('train'),
      );
      return SmartInsight(
        question: 'How much do I spend on transport?',
        answer:
            '${context.formatMoney(match.averageMonthlyMinorUnits)}/month on average',
        icon: 'car',
      );
    },
  ),

  // 9. Entertainment
  InsightDefinition(
    id: 'entertainment_spending',
    question: 'How much do I spend on entertainment?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 30,
    canGenerate: (context) =>
        context.hasCategory('entertain') ||
        context.hasCategory('movie') ||
        context.hasCategory('game') ||
        context.hasCategory('fun'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('entertain') ||
            c.category.toLowerCase().contains('movie') ||
            c.category.toLowerCase().contains('game') ||
            c.category.toLowerCase().contains('fun'),
      );
      return SmartInsight(
        question: 'How much do I spend on entertainment?',
        answer:
            '${context.formatMoney(match.averageMonthlyMinorUnits)}/month on average',
        icon: 'television',
      );
    },
  ),

  // 10. Utilities
  InsightDefinition(
    id: 'utilities_spending',
    question: 'What do I pay for bills & utilities?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 30,
    canGenerate: (context) =>
        context.hasCategory('utility') ||
        context.hasCategory('bill') ||
        context.hasCategory('electric') ||
        context.hasCategory('water') ||
        context.hasCategory('internet') ||
        context.hasCategory('phone'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('utility') ||
            c.category.toLowerCase().contains('bill') ||
            c.category.toLowerCase().contains('electric') ||
            c.category.toLowerCase().contains('water') ||
            c.category.toLowerCase().contains('internet') ||
            c.category.toLowerCase().contains('phone'),
      );
      return SmartInsight(
        question: 'What do I pay for bills & utilities?',
        answer:
            '${context.formatMoney(match.averageMonthlyMinorUnits)}/month on average',
        icon: 'lightning',
      );
    },
  ),

  // 11. Fitness
  InsightDefinition(
    id: 'fitness_spending',
    question: 'How much do I spend on fitness per year?',
    category: InsightCategory.spending,
    tier: InsightTier.extended,
    minDataDays: 60, // Fitness might be less frequent
    canGenerate: (context) =>
        context.hasCategory('fitness') || context.hasCategory('gym'),
    generate: (context) {
      final match = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('fitness') ||
            c.category.toLowerCase().contains('gym'),
      );
      final yearly = match.averageMonthlyMinorUnits * 12;
      return SmartInsight(
        question: 'How much do I spend on fitness per year?',
        answer:
            '≈ ${context.formatMoney(yearly)} (${context.formatMoney(match.averageMonthlyMinorUnits)}/month)',
        icon: 'barbell',
      );
    },
  ),

  // 12. Rent/Income Ratio
  InsightDefinition(
    id: 'rent_income_ratio',
    question: 'How much of my income goes to rent?',
    category: InsightCategory.spending,
    tier: InsightTier.core,
    minDataDays: 30,
    canGenerate: (context) {
      final hasHousing = context.hasCategory('housing') ||
          context.hasCategory('rent') ||
          context.categorySpending.any(
            (c) => c.category.toLowerCase() == 'housing',
          );
      if (!hasHousing) return false;

      final incomeTotal = context.filteredPulses
          .where((p) => p.type.isIncomeType)
          .fold<int>(0, (sum, p) => sum + p.amountMinorUnits.abs());

      return incomeTotal > 0;
    },
    generate: (context) {
      final housing = context.categorySpending.firstWhere(
        (c) =>
            c.category.toLowerCase().contains('housing') ||
            c.category.toLowerCase().contains('rent') ||
            c.category.toLowerCase() == 'housing',
      );

      final incomeTotal = context.filteredPulses
          .where((p) => p.type.isIncomeType)
          .fold<int>(0, (sum, p) => sum + p.amountMinorUnits.abs());

      // Helpers to calc month span if needed, but here we can just do raw ratio if we assume filteredPulses aligns with category averaging period
      // Actually categorySpending.averageMonthly is annualized/averaged.
      // Filtered pulses might be just this month.
      // To get average MONTHLY income, we should check the span of filteredPulses or use allPulses if filtered is just 1 month.
      // The original code calculated month span from pulses used.

      // Let's rely on standardizing to monthly average using filtered pulses span
      int monthSpan = 1;
      if (context.filteredPulses.isNotEmpty) {
        final dates = context.filteredPulses.map((p) => p.date);
        final earliest = dates.reduce((a, b) => a.isBefore(b) ? a : b);
        final latest = dates.reduce((a, b) => a.isAfter(b) ? a : b);
        monthSpan = (latest.year - earliest.year) * 12 +
            (latest.month - earliest.month) +
            1;
        monthSpan = monthSpan.clamp(1, 120);
      }

      final avgMonthlyIncome =
          monthSpan > 0 ? incomeTotal ~/ monthSpan : incomeTotal;

      double rentPercentage = 0;
      if (avgMonthlyIncome > 0) {
        rentPercentage =
            (housing.averageMonthlyMinorUnits / avgMonthlyIncome) * 100;
      }

      return SmartInsight(
        question: 'How much of my income goes to rent?',
        answer:
            '${rentPercentage.toStringAsFixed(1)}% (${context.formatMoney(housing.averageMonthlyMinorUnits)} of ${context.formatMoney(avgMonthlyIncome)})',
        icon: 'house',
      );
    },
  ),

  // --- Behavioral Insights ---

  // 13. Weekend Splurger
  InsightDefinition(
    id: 'weekend_spending',
    question: 'How much do I spend on weekends?',
    category: InsightCategory.behavioral,
    tier: InsightTier.advanced,
    minDataDays: 14,
    canGenerate: (context) =>
        context.filteredPulses.any((p) => !p.type.isIncomeType),
    generate: (context) {
      final expenses = context.filteredPulses.where(
        (p) => !p.type.isIncomeType,
      );
      int weekendTotal = 0;
      int allTotal = 0;

      for (final p in expenses) {
        final amount = p.amountMinorUnits.abs();
        allTotal += amount;
        if (p.date.weekday == DateTime.saturday ||
            p.date.weekday == DateTime.sunday) {
          weekendTotal += amount;
        }
      }

      if (allTotal == 0) {
        return const SmartInsight(
          question: 'Weekend Spending',
          answer: '0%',
          icon: 'calendar',
        );
      }

      final percentage = (weekendTotal / allTotal) * 100;
      return SmartInsight(
        question: 'How much do I spend on weekends?',
        answer:
            '${percentage.toStringAsFixed(0)}% of your spending (${context.formatMoney(weekendTotal)})',
        icon:
            'calendar', // Use a weekend icon if available, essentially calendar
      );
    },
  ),

  // --- Trend Insights ---

  // 14. Top Rising Category
  InsightDefinition(
    id: 'top_rising_trend',
    question: 'Which category is trending up?',
    category: InsightCategory.trends,
    tier: InsightTier.advanced,
    minDataDays: 60, // Need 2 months history
    canGenerate: (context) {
      // Check if there is enough history in allPulses
      return context.dataAgeDays >= 60;
    },
    generate: (context) {
      // Use existing calculator logic
      final trends = InsightsCalculator.calculateTrends(
        context.allPulses,
        context.timelineItems,
        context.settings.includeInternalTransfers,
        monthsPerPeriod: 1, // Compare last month to month before
      );

      final rising =
          trends.where((t) => t.direction == TrendDirection.up).firstOrNull;

      if (rising != null) {
        return SmartInsight(
          question: 'Which category is trending up?',
          answer:
              '${rising.category} is up ${rising.percentageChange.toStringAsFixed(0)}% compared to last month',
          icon: 'chartLineUp', // or trendingUp
        );
      }

      // Fallback if no rising trend found (should be filtered by canGenerate optimally, but for now fallback)
      return const SmartInsight(
        question: 'Spending Trends',
        answer: 'Your spending is stable.',
        icon: 'chartLine',
      );
    },
  ),

  // --- Alert Insights ---

  // 15. High Value Transactions
  InsightDefinition(
    id: 'high_value_alert',
    question: 'Any meaningful large expenses?',
    category: InsightCategory.alerts,
    tier: InsightTier.core,
    minDataDays: 2,
    canGenerate: (context) {
      // Threshold: > 1000.00 currency units (100000 minor units generally, but depends on currency)
      // For now hardcode 100000 (1000.00)
      return context.filteredPulses.any(
        (p) => p.amountMinorUnits.abs() > 100000 && !p.type.isIncomeType,
      );
    },
    generate: (context) {
      final highValue = context.filteredPulses
          .where(
            (p) => p.amountMinorUnits.abs() > 100000 && !p.type.isIncomeType,
          )
          .toList();

      return SmartInsight(
        question: 'Large Expenses Detected',
        answer:
            'You have ${highValue.length} transaction${highValue.length == 1 ? '' : 's'} over 1,000.00 this period.',
        icon: 'alertCircle', // or warning
      );
    },
  ),
];
