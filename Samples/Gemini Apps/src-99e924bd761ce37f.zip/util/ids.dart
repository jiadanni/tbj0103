import 'package:uuid/uuid.dart';

final _uuid = const Uuid();

extension type const AccountId(String value) implements String {}
extension type const TimelineItemId(String value) implements String {}
extension type const EntryId(String value) implements String {}
extension type const MoneyPotId(String value) implements String {}

String newIdRaw() => _uuid.v4();

AccountId newAccountId() => AccountId(_uuid.v4());
TimelineItemId newTimelineItemId() => TimelineItemId(_uuid.v4());
EntryId newEntryId() => EntryId(_uuid.v4());
MoneyPotId newMoneyPotId() => MoneyPotId(_uuid.v4());
