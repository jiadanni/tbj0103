import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// Severity levels for error reporting.
enum ErrorSeverity {
  /// Informational message, no action required.
  info,

  /// Warning that doesn't prevent functionality.
  warning,

  /// Error that affects functionality but app can continue.
  error,

  /// Critical error that may crash or corrupt data.
  critical,
}

class _StringStackTrace implements StackTrace {
  final String _trace;
  _StringStackTrace(this._trace);
  @override
  String toString() => _trace;
}

/// Error context for structured error tracking.
class ErrorContext {
  ErrorContext({
    required this.category,
    required this.message,
    required this.severity,
    this.error,
    this.stackTrace,
    this.userId,
    this.additionalData,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  final DateTime timestamp;
  final String category;
  final String message;
  final ErrorSeverity severity;
  final Object? error;
  final StackTrace? stackTrace;
  final String? userId;
  final Map<String, dynamic>? additionalData;

  /// Create from JSON.
  factory ErrorContext.fromJson(Map<String, dynamic> json) {
    return ErrorContext(
      category: json['category'] as String,
      message: json['message'] as String,
      severity: ErrorSeverity.values.firstWhere(
        (e) => e.name == json['severity'],
        orElse: () => ErrorSeverity.error,
      ),
      error: json['error'],
      stackTrace: json['stackTrace'] != null
          ? _StringStackTrace(json['stackTrace'] as String)
          : null,
      userId: json['userId'] as String?,
      additionalData: json['additionalData'] as Map<String, dynamic>?,
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'] as String)
          : null,
    );
  }

  /// Convert to JSON for persistence or analytics.
  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toUtc().toIso8601String(),
      'category': category,
      'message': message,
      'severity': severity.name,
      'error': error?.toString(),
      'stackTrace': stackTrace?.toString(),
      'userId': userId,
      'additionalData': additionalData,
    };
  }

  /// Convert to a JSON string for display.
  String toJsonString({bool pretty = false}) {
    if (pretty) {
      return const JsonEncoder.withIndent('  ').convert(toJson());
    }
    return jsonEncode(toJson());
  }

  @override
  String toString() {
    final buffer = StringBuffer();
    buffer.writeln('[$category] ${severity.name.toUpperCase()}: $message');
    if (error != null) buffer.writeln('Error: $error');
    if (additionalData != null && additionalData!.isNotEmpty) {
      buffer.writeln('Context: $additionalData');
    }
    return buffer.toString();
  }
}

/// Central error tracking and logging service.
///
/// Provides:
/// - Structured error logging with context
/// - Error aggregation and statistics
/// - Integration points for analytics/crash reporting
/// - Error history for debugging
class ErrorTracker {
  ErrorTracker._();

  static final ErrorTracker instance = ErrorTracker._();

  final List<ErrorContext> _errorHistory = [];
  static const int _maxHistorySize = 100;
  static const String _crashReportFileName = 'crash_report.json';

  /// Track an error with full context.
  ///
  /// Example:
  /// ```dart
  /// ErrorTracker.instance.trackError(
  ///   ErrorContext(
  ///     category: 'authentication',
  ///     message: 'Failed to verify PIN',
  ///     severity: ErrorSeverity.error,
  ///     error: exception,
  ///     stackTrace: stack,
  ///     additionalData: {'attemptCount': 3},
  ///   ),
  /// );
  /// ```
  void trackError(ErrorContext context) {
    // Add to history
    _errorHistory.add(context);
    if (_errorHistory.length > _maxHistorySize) {
      _errorHistory.removeAt(0);
    }

    // Log to console in debug mode
    if (kDebugMode) {
      _logToConsole(context);
    }

    // Persist critical errors (crashes)
    if (context.severity == ErrorSeverity.critical) {
      saveCrashReport(context);
    }

    // Privacy-focused design: Instead of automatically sending errors to
    // third-party services (Firebase Crashlytics, Sentry), this app uses
    // user-initiated debug export via toJson()/toJsonString()/toFormattedString().
    // Users control when and what data leaves their device.
  }

  /// Track an error from an exception and stack trace.
  void trackException(
    String category,
    String message,
    Object error,
    StackTrace stackTrace, {
    ErrorSeverity severity = ErrorSeverity.error,
    Map<String, dynamic>? additionalData,
  }) {
    trackError(
      ErrorContext(
        category: category,
        message: message,
        severity: severity,
        error: error,
        stackTrace: stackTrace,
        additionalData: additionalData,
      ),
    );
  }

  /// Get recent error history.
  List<ErrorContext> getRecentErrors({int? limit}) {
    if (limit == null) return List.unmodifiable(_errorHistory);
    final start = (_errorHistory.length - limit).clamp(0, _errorHistory.length);
    return List.unmodifiable(_errorHistory.sublist(start));
  }

  /// Get error statistics grouped by category.
  Map<String, int> getErrorStatistics() {
    final stats = <String, int>{};
    for (final error in _errorHistory) {
      stats[error.category] = (stats[error.category] ?? 0) + 1;
    }
    return stats;
  }

  /// Get errors by severity.
  List<ErrorContext> getErrorsBySeverity(ErrorSeverity severity) {
    return _errorHistory.where((e) => e.severity == severity).toList();
  }

  /// Get critical errors that need immediate attention.
  List<ErrorContext> getCriticalErrors() {
    return getErrorsBySeverity(ErrorSeverity.critical);
  }

  /// Clear error history (useful for testing or after fixing issues).
  void clearHistory() {
    _errorHistory.clear();
  }

  /// Get total error count.
  int get errorCount => _errorHistory.length;

  /// Check if there are any critical errors.
  bool get hasCriticalErrors =>
      _errorHistory.any((e) => e.severity == ErrorSeverity.critical);

  /// Export all errors as JSON for debugging/AI analysis.
  Map<String, dynamic> toJson() {
    final severityCounts = <String, int>{};
    for (final error in _errorHistory) {
      final key = error.severity.name;
      severityCounts[key] = (severityCounts[key] ?? 0) + 1;
    }

    return {
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'totalErrors': errorCount,
      'maxCapacity': _maxHistorySize,
      'hasCriticalErrors': hasCriticalErrors,
      'severityCounts': severityCounts,
      'categoryStatistics': getErrorStatistics(),
      'errors': _errorHistory.map((e) => e.toJson()).toList(),
    };
  }

  /// Export errors as a JSON string.
  String toJsonString({bool pretty = false}) {
    if (pretty) {
      return const JsonEncoder.withIndent('  ').convert(toJson());
    }
    return jsonEncode(toJson());
  }

  /// Export errors as a formatted text report.
  String toFormattedString() {
    final buffer = StringBuffer();
    buffer.writeln('=== Error Report ===');
    buffer.writeln('Exported: ${DateTime.now().toIso8601String()}');
    buffer.writeln('Total Errors: $errorCount');
    buffer.writeln('Has Critical Errors: $hasCriticalErrors');
    buffer.writeln('');
    buffer.writeln('--- Statistics by Category ---');
    for (final entry in getErrorStatistics().entries) {
      buffer.writeln('  ${entry.key}: ${entry.value}');
    }
    buffer.writeln('');
    buffer.writeln('--- Error Log ---');

    for (final error in _errorHistory) {
      buffer.writeln('');
      buffer.writeln(
        '[${error.timestamp.toIso8601String()}] ${error.severity.name.toUpperCase()}',
      );
      buffer.writeln('Category: ${error.category}');
      buffer.writeln('Message: ${error.message}');
      if (error.error != null) {
        buffer.writeln('Error: ${error.error}');
      }
      if (error.additionalData != null && error.additionalData!.isNotEmpty) {
        buffer.writeln('Context: ${error.additionalData}');
      }
      if (error.stackTrace != null) {
        buffer.writeln('Stack Trace (first 5 lines):');
        final lines = error.stackTrace.toString().split('\n').take(5);
        for (final line in lines) {
          buffer.writeln('  $line');
        }
      }
    }

    return buffer.toString();
  }

  void _logToConsole(ErrorContext context) {
    final timestamp = DateTime.now().toIso8601String();
    final severityIcon = _getSeverityIcon(context.severity);

    debugPrint('$timestamp $severityIcon ${context.toString()}');

    if (context.stackTrace != null) {
      final lines = context.stackTrace.toString().split('\n').take(5);
      for (final line in lines) {
        debugPrint('  $line');
      }
    }
  }

  String _getSeverityIcon(ErrorSeverity severity) {
    return switch (severity) {
      ErrorSeverity.info => 'ℹ️',
      ErrorSeverity.warning => '⚠️',
      ErrorSeverity.error => '❌',
      ErrorSeverity.critical => '🔥',
    };
  }

  // --- Persistence for Crash Reporting ---

  Future<File> _getCrashReportFile() async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/$_crashReportFileName');
  }

  /// Saves the given error context as a crash report.
  Future<void> saveCrashReport(ErrorContext context) async {
    try {
      final file = await _getCrashReportFile();
      final jsonStr = jsonEncode(context.toJson());
      await file.writeAsString(jsonStr);
    } catch (e, stack) {
      // If saving fails, we log it to console but can't really do much else
      // as we are likely already in a crash state.
      debugPrint('Failed to save crash report: $e');
      debugPrint(stack.toString());
    }
  }

  /// Loads the saved crash report if it exists.
  Future<ErrorContext?> loadCrashReport() async {
    try {
      final file = await _getCrashReportFile();
      if (await file.exists()) {
        final jsonStr = await file.readAsString();
        final jsonMap = jsonDecode(jsonStr) as Map<String, dynamic>;
        return ErrorContext.fromJson(jsonMap);
      }
    } catch (e, stack) {
      debugPrint('Failed to load crash report: $e');
      debugPrint(stack.toString());
      // If the file is corrupt, we might want to delete it so we don't try again?
      // For now, return null.
      try {
        await deleteCrashReport();
      } catch (_) {}
    }
    return null;
  }

  /// Deletes the saved crash report.
  Future<void> deleteCrashReport() async {
    try {
      final file = await _getCrashReportFile();
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      debugPrint('Failed to delete crash report: $e');
    }
  }
}

/// Extension for easier error tracking.
extension ErrorTrackingExtension on Object {
  /// Track this object as an error.
  void trackAsError(
    String category,
    String message, {
    StackTrace? stackTrace,
    ErrorSeverity severity = ErrorSeverity.error,
    Map<String, dynamic>? additionalData,
  }) {
    ErrorTracker.instance.trackException(
      category,
      message,
      this,
      stackTrace ?? StackTrace.current,
      severity: severity,
      additionalData: additionalData,
    );
  }
}
