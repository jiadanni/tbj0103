import 'package:flutter/material.dart';

/// Curated list of Material Icons suitable for account types
class AccountIcons {
  static const List<IconData> availableIcons = [
    Icons.account_balance_wallet, // Default wallet
    Icons.account_balance, // Bank
    Icons.savings, // Savings
    Icons.credit_card, // Credit card
    Icons.attach_money, // Money/Cash
    Icons.paid, // Paid/Income
    Icons.shopping_cart, // Shopping
    Icons.home, // Home/Household
    Icons.business, // Business
    Icons.work, // Work
    Icons.school, // Education
    Icons.local_hospital, // Medical
    Icons.directions_car, // Transportation/Car
    Icons.flight, // Travel
    Icons.restaurant, // Food/Dining
    Icons.sports_esports, // Entertainment/Gaming
    Icons.fitness_center, // Fitness/Health
    Icons.pets, // Pets
    Icons.child_care, // Children/Family
    Icons.phone_android, // Technology/Phone
    Icons.laptop, // Computer/Tech
    Icons.build, // Tools/Maintenance
    Icons.local_gas_station, // Gas/Fuel
    Icons.lightbulb, // Utilities
    Icons.water_drop, // Water/Utilities
    Icons.bolt, // Electric/Energy
    Icons.wifi, // Internet/Connectivity
    Icons.favorite, // Personal/Favorite
    Icons.star, // Premium/Special
    Icons.diamond, // Luxury/Premium
    Icons.science, // Test/Experimental
  ];

  /// Map of codePoints to IconData for efficient lookup (lazy initialized)
  static Map<int, IconData>? __iconMap;
  static Map<int, IconData> get _iconMap {
    return __iconMap ??= {
      for (var icon in availableIcons) icon.codePoint: icon,
    };
  }

  static IconData getIcon(int? codePoint, {bool isTestData = false}) {
    if (codePoint != null) {
      // Look up the icon from our predefined list instead of creating a new one
      return _iconMap[codePoint] ?? Icons.account_balance_wallet;
    }
    return isTestData ? Icons.science : Icons.account_balance_wallet;
  }

  static String getIconLabel(IconData icon) {
    // Map common icons to readable labels
    final labels = {
      Icons.account_balance_wallet.codePoint: 'Wallet',
      Icons.account_balance.codePoint: 'Bank',
      Icons.savings.codePoint: 'Savings',
      Icons.credit_card.codePoint: 'Credit Card',
      Icons.attach_money.codePoint: 'Cash',
      Icons.paid.codePoint: 'Income',
      Icons.shopping_cart.codePoint: 'Shopping',
      Icons.home.codePoint: 'Home',
      Icons.business.codePoint: 'Business',
      Icons.work.codePoint: 'Work',
      Icons.school.codePoint: 'Education',
      Icons.local_hospital.codePoint: 'Medical',
      Icons.directions_car.codePoint: 'Transportation',
      Icons.flight.codePoint: 'Travel',
      Icons.restaurant.codePoint: 'Dining',
      Icons.sports_esports.codePoint: 'Entertainment',
      Icons.fitness_center.codePoint: 'Fitness',
      Icons.pets.codePoint: 'Pets',
      Icons.child_care.codePoint: 'Family',
      Icons.phone_android.codePoint: 'Phone',
      Icons.laptop.codePoint: 'Computer',
      Icons.build.codePoint: 'Tools',
      Icons.local_gas_station.codePoint: 'Gas',
      Icons.lightbulb.codePoint: 'Utilities',
      Icons.water_drop.codePoint: 'Water',
      Icons.bolt.codePoint: 'Electric',
      Icons.wifi.codePoint: 'Internet',
      Icons.favorite.codePoint: 'Personal',
      Icons.star.codePoint: 'Special',
      Icons.diamond.codePoint: 'Premium',
      Icons.science.codePoint: 'Test',
    };

    return labels[icon.codePoint] ?? 'Custom';
  }
}
