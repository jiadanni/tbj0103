import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

/// Date range filter for insights calculations.
enum InsightsDateRange {
  currentPeriod('Current Period'),
  last3Periods('Last 3 Periods'),
  last6Periods('Last 6 Periods'),
  lastYear('Last Year'),
  allTime('All Time');

  const InsightsDateRange(this.label);
  final String label;

  /// Returns the display label based on period mode (calendar or paycheck).
  String labelForMode(bool isPaycheckMode) {
    if (!isPaycheckMode) {
      return switch (this) {
        InsightsDateRange.currentPeriod => 'This Month',
        InsightsDateRange.last3Periods => 'Last 3 Months',
        InsightsDateRange.last6Periods => 'Last 6 Months',
        InsightsDateRange.lastYear => 'Last Year',
        InsightsDateRange.allTime => 'All Time',
      };
    }
    return label;
  }
}

/// Result of category spending analysis.
class CategorySpending extends Equatable {
  const CategorySpending({
    required this.category,
    required this.totalMinorUnits,
    required this.averageMonthlyMinorUnits,
    required this.transactionCount,
    required this.priority,
  });

  final String category;
  final int totalMinorUnits;
  final int averageMonthlyMinorUnits;
  final int transactionCount;
  final ExpensePriority priority;

  @override
  List<Object?> get props => [
        category,
        totalMinorUnits,
        averageMonthlyMinorUnits,
        transactionCount,
        priority,
      ];
}

/// Result of priority breakdown analysis.
class PriorityBreakdown extends Equatable {
  const PriorityBreakdown({
    required this.criticalMinorUnits,
    required this.advisableMinorUnits,
    required this.optionalMinorUnits,
    required this.strategicMinorUnits,
    required this.frivolousMinorUnits,
    required this.criticalPercentage,
    required this.advisablePercentage,
    required this.optionalPercentage,
    required this.strategicPercentage,
    required this.frivolousPercentage,
    required this.totalMinorUnits,
  });

  final int criticalMinorUnits;
  final int advisableMinorUnits;
  final int optionalMinorUnits;
  final int strategicMinorUnits;
  final int frivolousMinorUnits;
  final double criticalPercentage;
  final double advisablePercentage;
  final double optionalPercentage;
  final double strategicPercentage;
  final double frivolousPercentage;

  final int totalMinorUnits;

  static const empty = PriorityBreakdown(
    criticalMinorUnits: 0,
    advisableMinorUnits: 0,
    optionalMinorUnits: 0,
    strategicMinorUnits: 0,
    frivolousMinorUnits: 0,
    criticalPercentage: 0,
    advisablePercentage: 0,
    optionalPercentage: 0,
    strategicPercentage: 0,
    frivolousPercentage: 0,
    totalMinorUnits: 0,
  );
  @override
  List<Object?> get props => [
        criticalMinorUnits,
        advisableMinorUnits,
        optionalMinorUnits,
        strategicMinorUnits,
        frivolousMinorUnits,
        criticalPercentage,
        advisablePercentage,
        optionalPercentage,
        strategicPercentage,
        frivolousPercentage,
        totalMinorUnits,
      ];
}

/// Direction of spending trend.
enum TrendDirection { up, down, stable }

/// Result of trend analysis.
class SpendingTrend {
  const SpendingTrend({
    required this.category,
    required this.currentPeriodMinorUnits,
    required this.previousPeriodMinorUnits,
    required this.percentageChange,
    required this.direction,
  });

  final String category;
  final int currentPeriodMinorUnits;
  final int previousPeriodMinorUnits;
  final double percentageChange;
  final TrendDirection direction;
}

/// Pre-generated insight question and answer.
class SmartInsight {
  const SmartInsight({
    required this.question,
    required this.answer,
    required this.icon,
    this.id,
    this.category, // Optional: for grouping in UI if needed
    this.tier, // Optional: for sorting/filtering in UI
  });

  final String question;
  final String answer;
  final String icon;
  final String? id;
  final String?
      category; // Using String to decouple from enum if needed, or import enum
  final String? tier; // Using String/Enum
}

/// Main analytics engine for calculating insights from pulse data.
class InsightsCalculator {
  const InsightsCalculator._();

  /// Filters pulses to the specified date range.
  ///
  /// If [viewMode] is [ViewPeriodMode.paycheck], uses paycheck periods.
  /// Otherwise, uses calendar months.
  static List<PulseEntry> filterByDateRange(
    List<PulseEntry> pulses,
    InsightsDateRange range, {
    ViewPeriodMode viewMode = ViewPeriodMode.calendar,
    int? paycheckDay,
    DateTime? referenceDate,
  }) {
    final now = referenceDate ?? DateTime.now();

    if (viewMode == ViewPeriodMode.paycheck && paycheckDay != null) {
      // Paycheck mode: calculate periods based on paycheck day
      final periodCount = switch (range) {
        InsightsDateRange.currentPeriod => 1,
        InsightsDateRange.last3Periods => 3,
        InsightsDateRange.last6Periods => 6,
        InsightsDateRange.lastYear => 13, // ~1 year of paycheck periods
        InsightsDateRange.allTime => 500, // Far back enough
      };

      // Get the cutoff period by going back periodCount periods
      DateTime referenceMonth = now;
      for (int i = 0; i < periodCount - 1; i++) {
        referenceMonth = DateTime(
          referenceMonth.year,
          referenceMonth.month - 1,
        );
      }

      final periodInfo = PaycheckService.getPeriodInfo(
        referenceMonth,
        ViewPeriodMode.paycheck,
        paycheckDay,
      );

      return pulses.where((p) => !p.date.isBefore(periodInfo.start)).toList();
    } else {
      // Calendar mode: traditional month-based filtering
      switch (range) {
        case InsightsDateRange.currentPeriod:
          // Filter to only the current month (not future months)
          final monthStart = DateTime(now.year, now.month, 1);
          final monthEnd = DateTime(now.year, now.month + 1, 0);
          final filtered = pulses
              .where(
                (p) =>
                    !p.date.isBefore(monthStart) && !p.date.isAfter(monthEnd),
              )
              .toList();
          return filtered;
        case InsightsDateRange.last3Periods:
          final cutoff = DateTime(now.year, now.month - 2, 1);
          return pulses.where((p) => !p.date.isBefore(cutoff)).toList();
        case InsightsDateRange.last6Periods:
          final cutoff = DateTime(now.year, now.month - 5, 1);
          return pulses.where((p) => !p.date.isBefore(cutoff)).toList();
        case InsightsDateRange.lastYear:
          final cutoff = DateTime(now.year - 1, now.month, 1);
          return pulses.where((p) => !p.date.isBefore(cutoff)).toList();
        case InsightsDateRange.allTime:
          return pulses;
      }
    }
  }

  /// Resolves the category for a pulse using the standard precedence:
  /// 1. Pulse's direct category
  /// 2. Linked TimelineItem's category
  /// 3. Label match against TimelineItems
  static String? resolveCategory(
    PulseEntry pulse,
    Map<String, TimelineItem> itemMap,
    Map<String, TimelineItem> labelToItemMap,
  ) {
    if (pulse.category != null) return pulse.category;

    if (pulse.timelineItemId != null) {
      final linked = itemMap[pulse.timelineItemId!.value];
      if (linked != null) return linked.category;
    }

    return labelToItemMap[pulse.label.toLowerCase()]?.category;
  }

  /// Represents priority data.
  static ExpensePriority _resolvePriority(
    PulseEntry pulse,
    Map<String, TimelineItem> itemMap,
    Map<String, TimelineItem> labelToItemMap,
  ) {
    if (pulse.priority != null) return pulse.priority!;

    // Check linked item
    if (pulse.timelineItemId != null) {
      final linked = itemMap[pulse.timelineItemId!.value];
      if (linked != null) return linked.effectivePriority;
    }

    // Check label match (legacy/unlinked)
    final matched = labelToItemMap[pulse.label.toLowerCase()];
    if (matched != null) return matched.effectivePriority;

    return getDefaultPriority(pulse.category, pulse.type);
  }

  /// Calculates spending by category with averages.
  static List<CategorySpending> calculateCategorySpending(
    List<PulseEntry> pulses,
    List<TimelineItem> timelineItems,
    bool includeInternalTransfers,
  ) {
    // Build lookup for timeline items
    final itemMap = {for (var i in timelineItems) i.id.value: i};
    final labelToItemMap = {
      for (var i in timelineItems) i.label.toLowerCase(): i,
    };

    final expensePulses = pulses
        .where((p) => !p.type.isIncomeType)
        .where((p) => includeInternalTransfers || !p.isInternalTransfer)
        .toList();
    final byCategory = <String, List<PulseEntry>>{};

    for (final pulse in expensePulses) {
      final resolvedCategory = resolveCategory(pulse, itemMap, labelToItemMap);

      final displayCategory = resolvedCategory ?? 'Uncategorized';
      (byCategory[displayCategory] ??= []).add(pulse);
    }

    // Calculate metrics
    final results = <CategorySpending>[];
    final monthSpan = _calculateMonthSpan(expensePulses);

    for (final entry in byCategory.entries) {
      final categoryPulses = entry.value;
      final total = categoryPulses.fold<int>(0, (sum, p) {
        final amount = p.transactionAmountMinorUnits ?? p.amountMinorUnits;
        return sum + amount.abs();
      });

      // Determine representative priority for the category list
      // We look for the most common priority among pulses in this category
      final priorityCounts = <ExpensePriority, int>{};
      for (final p in categoryPulses) {
        final priority = _resolvePriority(p, itemMap, labelToItemMap);
        priorityCounts[priority] = (priorityCounts[priority] ?? 0) + 1;
      }

      // Pick the priority with highest count, falling back to Advisable or generic default
      var bestPriority = ExpensePriority.advisable;
      var maxCount = -1;

      for (final pEntry in priorityCounts.entries) {
        if (pEntry.value > maxCount) {
          maxCount = pEntry.value;
          bestPriority = pEntry.key;
        }
      }

      // Edge case: if empty (shouldn't happen here), check default for category name
      if (categoryPulses.isEmpty) {
        bestPriority = getDefaultPriority(entry.key, PulseType.oneOff);
      }

      results.add(
        CategorySpending(
          category: entry.key,
          totalMinorUnits: total,
          averageMonthlyMinorUnits: monthSpan > 0 ? total ~/ monthSpan : total,
          transactionCount: categoryPulses.length,
          priority: bestPriority,
        ),
      );
    }

    // Sort by total spending descending
    results.sort((a, b) => b.totalMinorUnits.compareTo(a.totalMinorUnits));
    return results;
  }

  /// Calculates accurate priority breakdown directly from raw pulses and items.
  /// Accounts for overrides on individual transactions which may differ within a category.
  static PriorityBreakdown calculateAccuratePriorityBreakdown({
    required List<PulseEntry> pulses,
    required List<TimelineItem> timelineItems,
    required bool includeInternalTransfers,
  }) {
    // Build lookups
    final itemMap = {for (var i in timelineItems) i.id.value: i};
    final labelToItemMap = {
      for (var i in timelineItems) i.label.toLowerCase(): i,
    };

    int critical = 0;
    int advisable = 0;
    int optional = 0;
    int strategic = 0;
    int frivolous = 0;

    void addToBucket(ExpensePriority p, int amount) {
      switch (p) {
        case ExpensePriority.critical:
          critical += amount;
        case ExpensePriority.advisable:
          advisable += amount;
        case ExpensePriority.optional:
          optional += amount;
        case ExpensePriority.strategic:
          strategic += amount;
        case ExpensePriority.frivolous:
          frivolous += amount;
      }
    }

    // Process expenses only
    for (final pulse in pulses) {
      if (pulse.type.isIncomeType) continue;

      // Skip internal transfers (unless user wants to include them)
      if (!includeInternalTransfers && pulse.isInternalTransfer) {
        continue;
      }

      // Use transaction amount if available
      final amount =
          (pulse.transactionAmountMinorUnits ?? pulse.amountMinorUnits).abs();

      final priority = _resolvePriority(pulse, itemMap, labelToItemMap);
      addToBucket(priority, amount);
    }

    final total = critical + advisable + optional + strategic + frivolous;
    if (total == 0) return PriorityBreakdown.empty;

    return PriorityBreakdown(
      criticalMinorUnits: critical,
      advisableMinorUnits: advisable,
      optionalMinorUnits: optional,
      strategicMinorUnits: strategic,
      frivolousMinorUnits: frivolous,
      criticalPercentage: (critical / total) * 100,
      advisablePercentage: (advisable / total) * 100,
      optionalPercentage: (optional / total) * 100,
      strategicPercentage: (strategic / total) * 100,
      frivolousPercentage: (frivolous / total) * 100,
      totalMinorUnits: total,
    );
  }

  /// Calculates accurate priority breakdown from TimelineItems (for Current Period view).
  static PriorityBreakdown calculatePriorityBreakdownFromItems(
    List<TimelineItem> items,
    List<PulseEntry> pulses,
    DateTime referenceMonth,
    AppSettingsStore settings,
  ) {
    int critical = 0;
    int advisable = 0;
    int optional = 0;
    int strategic = 0;
    int frivolous = 0;

    void addToBucket(ExpensePriority p, int amount) {
      switch (p) {
        case ExpensePriority.critical:
          critical += amount;
        case ExpensePriority.advisable:
          advisable += amount;
        case ExpensePriority.optional:
          optional += amount;
        case ExpensePriority.strategic:
          strategic += amount;
        case ExpensePriority.frivolous:
          frivolous += amount;
      }
    }

    for (final item in items) {
      // to "Scheduled Items for this period".
      if (item.type.isIncomeType) continue;

      // Note: TimelineItems don't strictly have isInternalTransfer flag in the same way,
      // but envelopes shouldn't be transfers usually?
      // Actually TimelineItems might naturally be transfers effectively if they are linked to them.
      // But there's no explicit isInternalTransfer field on TimelineItem yet.
      // We'll rely on Pulse filtering for history, and for current period
      // we assume scheduled items are valid unless we add a flag to them too.
      // However, for consistency, if a timeline item IS a transfer (e.g. transfer to savings),
      // it should be excluded.
      // Since we don't have the flag on TimelineItem easily populated without checking category/type,
      // we might skip this for now or assume user relies on Pulse filtering for historical accuracy.
      // BETTER: Check if the item generates a transfer.
      // For now, let's leave it as is for TimelineItems unless there is a clear way to identify them.

      int amount;
      if (item.type == PulseType.spendingEnvelope) {
        final period = SpendingEnvelopeService.getEnvelopePeriodDates(
          item,
          referenceMonth,
          settings,
        );
        amount = SpendingEnvelopeService.getSpentAmountForPeriod(
          item,
          pulses,
          period,
        );
      } else {
        amount = item.amountMinorUnits.abs();
      }

      addToBucket(item.effectivePriority, amount);
    }

    final total = critical + advisable + optional + strategic + frivolous;
    if (total == 0) return PriorityBreakdown.empty;

    return PriorityBreakdown(
      criticalMinorUnits: critical,
      advisableMinorUnits: advisable,
      optionalMinorUnits: optional,
      strategicMinorUnits: strategic,
      frivolousMinorUnits: frivolous,
      criticalPercentage: (critical / total) * 100,
      advisablePercentage: (advisable / total) * 100,
      optionalPercentage: (optional / total) * 100,
      strategicPercentage: (strategic / total) * 100,
      frivolousPercentage: (frivolous / total) * 100,
      totalMinorUnits: total,
    );
  }

  /// Calculates spending by category from TimelineItems (scheduled items) for current period.
  ///
  /// This is used for the "Current Period" view where we want to show scheduled/projected
  /// amounts, not archived pulse data.
  static List<CategorySpending> calculateCategorySpendingFromItems(
    List<TimelineItem> items,
    List<PulseEntry> pulses,
    DateTime referenceMonth,
    ViewPeriodMode viewMode,
    int? paycheckDay,
    AppSettingsStore settings,
  ) {
    final periodInfo = PaycheckService.getPeriodInfo(
      referenceMonth,
      viewMode,
      paycheckDay,
    );

    // Filter items that appear in this period (same logic as MonthCard)
    final scheduledItems = items
        .where(
          (item) => PaycheckService.shouldItemAppearInPeriod(
            item,
            periodInfo,
            referenceMonth,
          ),
        )
        .where((item) => !item.type.isIncomeType) // Exclude income
        .toList();

    // Group by category
    final byCategory = <String, List<TimelineItem>>{};
    for (final item in scheduledItems) {
      final displayCategory = item.category ?? 'Uncategorized';

      (byCategory[displayCategory] ??= []).add(item);
    }

    // Calculate metrics
    final results = <CategorySpending>[];
    for (final entry in byCategory.entries) {
      final categoryItems = entry.value;
      int total = 0;
      int transactionCount = 0;

      for (final item in categoryItems) {
        if (item.type == PulseType.spendingEnvelope) {
          final period = SpendingEnvelopeService.getEnvelopePeriodDates(
            item,
            referenceMonth,
            settings,
          );
          total += SpendingEnvelopeService.getSpentAmountForPeriod(
            item,
            pulses,
            period,
          );
          transactionCount += SpendingEnvelopeService.getPulseCountForPeriod(
            item,
            pulses,
            period,
          );
        } else {
          total += item.amountMinorUnits.abs();
          transactionCount += 1;
        }
      }

      // Get priority from first item in category
      final priority = categoryItems.first.effectivePriority;

      results.add(
        CategorySpending(
          category: entry.key,
          totalMinorUnits: total,
          averageMonthlyMinorUnits:
              total, // For current period, total = monthly
          transactionCount: transactionCount,
          priority: priority,
        ),
      );
    }

    // Sort by total spending descending
    results.sort((a, b) => b.totalMinorUnits.compareTo(a.totalMinorUnits));
    return results;
  }

  /// Merges two lists of CategorySpending, combining amounts for matching categories.
  ///
  /// Used when combining current month (from TimelineItems) with historical months (from Pulses).
  static List<CategorySpending> mergeCategorySpending(
    List<CategorySpending> current,
    List<CategorySpending> historical,
  ) {
    final merged = <String, CategorySpending>{};

    // Add current month spending
    for (final cs in current) {
      merged[cs.category] = cs;
    }

    // Merge historical spending
    for (final hs in historical) {
      final existing = merged[hs.category];
      if (existing != null) {
        // Combine totals
        final totalMonths =
            1 + (hs.transactionCount > 0 ? 1 : 0); // Approximate
        merged[hs.category] = CategorySpending(
          category: hs.category,
          totalMinorUnits: existing.totalMinorUnits + hs.totalMinorUnits,
          averageMonthlyMinorUnits:
              (existing.totalMinorUnits + hs.totalMinorUnits) ~/ totalMonths,
          transactionCount: existing.transactionCount + hs.transactionCount,
          priority: existing.priority, // Keep current month's priority
        );
      } else {
        merged[hs.category] = hs;
      }
    }

    final results = merged.values.toList();
    results.sort((a, b) => b.totalMinorUnits.compareTo(a.totalMinorUnits));
    return results;
  }

  /// Calculates priority breakdown percentages.
  static PriorityBreakdown calculatePriorityBreakdown(
    List<CategorySpending> categorySpending,
  ) {
    int critical = 0;
    int advisable = 0;
    int optional = 0;
    int strategic = 0;
    int frivolous = 0;

    for (final cat in categorySpending) {
      final amount = cat.totalMinorUnits
          .abs(); // Use abs to handle potential negative values if any
      switch (cat.priority) {
        case ExpensePriority.critical:
          critical += amount;
        case ExpensePriority.advisable:
          advisable += amount;
        case ExpensePriority.optional:
          optional += amount;
        case ExpensePriority.strategic:
          strategic += amount;
        case ExpensePriority.frivolous:
          frivolous += amount;
      }
    }

    final total = critical + advisable + optional + strategic + frivolous;
    if (total == 0) return PriorityBreakdown.empty;

    return PriorityBreakdown(
      criticalMinorUnits: critical,
      advisableMinorUnits: advisable,
      optionalMinorUnits: optional,
      strategicMinorUnits: strategic,
      frivolousMinorUnits: frivolous,
      criticalPercentage: (critical / total) * 100,
      advisablePercentage: (advisable / total) * 100,
      optionalPercentage: (optional / total) * 100,
      strategicPercentage: (strategic / total) * 100,
      frivolousPercentage: (frivolous / total) * 100,
      totalMinorUnits: total,
    );
  }

  /// Calculates spending trends comparing current vs previous period.
  /// Expects allPulses to contain complete history; filters internally by date range.
  static List<SpendingTrend> calculateTrends(
    List<PulseEntry> allPulses,
    List<TimelineItem> timelineItems,
    bool includeInternalTransfers, {
    int monthsPerPeriod = 3,
  }) {
    final now = DateTime.now();
    final currentStart = DateTime(
      now.year,
      now.month - (monthsPerPeriod - 1),
      1,
    );
    final previousStart = DateTime(
      now.year,
      now.month - ((monthsPerPeriod * 2) - 1),
      1,
    );

    final currentPulses = allPulses.where(
      (p) =>
          !p.date.isBefore(currentStart) &&
          !p.type.isIncomeType &&
          (includeInternalTransfers || !p.isInternalTransfer),
    );

    final previousPulses = allPulses.where(
      (p) =>
          !p.date.isBefore(previousStart) &&
          p.date.isBefore(currentStart) &&
          !p.type.isIncomeType &&
          (includeInternalTransfers || !p.isInternalTransfer),
    );

    // Check if we have sufficient history to form a valid comparison.
    // If the user's earliest data point is within the current period (or later),
    // then the "previous period" is naturally empty or incomplete due to lack of usage history,
    // not necessarily lack of spending.
    if (allPulses.isNotEmpty) {
      final earliestDate =
          allPulses.map((p) => p.date).reduce((a, b) => a.isBefore(b) ? a : b);

      // If data started AFTER the current period began, we can't compare to previous period.
      if (earliestDate.isAfter(currentStart)) {
        return [];
      }
    } else {
      return [];
    }

    // Group by category (using full category resolution)
    final currentByCategory = _groupByCategory(currentPulses, timelineItems);
    final previousByCategory = _groupByCategory(previousPulses, timelineItems);

    final allCategories = {
      ...currentByCategory.keys,
      ...previousByCategory.keys,
    };
    final trends = <SpendingTrend>[];

    for (final category in allCategories) {
      final current = currentByCategory[category] ?? 0;
      final previous = previousByCategory[category] ?? 0;

      double percentChange = 0;
      TrendDirection direction = TrendDirection.stable;

      if (previous > 0) {
        percentChange = ((current - previous) / previous) * 100;
        if (percentChange > 5) {
          direction = TrendDirection.up;
        } else if (percentChange < -5) {
          direction = TrendDirection.down;
        }
      } else if (current > 0) {
        percentChange = 100;
        direction = TrendDirection.up;
      }

      // Only include significant trends
      if (percentChange.abs() > 10 || current > 0 || previous > 0) {
        trends.add(
          SpendingTrend(
            category: category,
            currentPeriodMinorUnits: current,
            previousPeriodMinorUnits: previous,
            percentageChange: percentChange,
            direction: direction,
          ),
        );
      }
    }

    // Sort by absolute percentage change
    trends.sort(
      (a, b) => b.percentageChange.abs().compareTo(a.percentageChange.abs()),
    );
    return trends.take(5).toList(); // Top 5 trends
  }

  /// Returns a unified list of transactions (recorded + projected) for the given range.
  ///
  /// This bridges the gap between summary stats (which use TimelineItems for current month)
  /// and the detailed list (which previously only used PulseEntries).
  static List<PulseEntry> getTransactionsForPeriod({
    required List<PulseEntry> pulses,
    required List<TimelineItem> timelineItems,
    required InsightsDateRange range,
    required ViewPeriodMode viewMode,
    required int? paycheckDay,
    required bool includeInternalTransfers,
  }) {
    final now = DateTime.now();

    // 1. Get recorded transactions filtered by range
    final recordedPulses = filterByDateRange(
      pulses,
      range,
      viewMode: viewMode,
      paycheckDay: paycheckDay,
    ).where((p) => includeInternalTransfers || !p.isInternalTransfer).toList();

    // 2. Determine if we need to project items (Current Period or close to it)
    // For simplicity, we project items if the range includes the current month/period.
    // In practice, we can just project for the specific current period if range overlaps it.

    // We only project for "Current Period" logic typically, but if user selects "Last 3 Months"
    // and one of them is current, we should project for that one.
    // However, existing logic treats "Current Period" uniquely as "Scheduled Items"
    // whereas "Last 3 Months" treats current month as part of history.
    // To match the summaries:
    // - Current Period summary = TimelineItems (Scheduled)
    // - Historical summary = Pulses (Recorded) + Current Month (Scheduled)

    // So we should ALWAYS project for the current period/month and merge it,
    // provided the date range encompasses it.

    final periodInfo = PaycheckService.getPeriodInfo(
      now,
      viewMode,
      paycheckDay,
    );

    // Check if current period is within the requested range
    bool includesCurrentPeriod = false;

    if (viewMode == ViewPeriodMode.paycheck && paycheckDay != null) {
      if (range == InsightsDateRange.currentPeriod) {
        includesCurrentPeriod = true;
      } else {
        // Check if start of current period is after the range cutoff
        final filteredIds = filterByDateRange(
          [
            PulseEntry(
              id: const EntryId('temp'),
              label: 'temp',
              amountMinorUnits: 0,
              date: periodInfo.start,
              type: PulseType.oneOff,
            ),
          ],
          range,
          viewMode: viewMode,
          paycheckDay: paycheckDay,
        );
        includesCurrentPeriod = filteredIds.isNotEmpty;
      }
    } else {
      // Calendar mode
      if (range == InsightsDateRange.currentPeriod) {
        includesCurrentPeriod = true;
      } else {
        final monthStart = DateTime(now.year, now.month, 1);
        final filteredIds = filterByDateRange(
          [
            PulseEntry(
              id: const EntryId('temp'),
              label: 'temp',
              amountMinorUnits: 0,
              date: monthStart,
              type: PulseType.oneOff,
            ),
          ],
          range,
          viewMode: viewMode,
        );
        includesCurrentPeriod = filteredIds.isNotEmpty;
      }
    }

    final projectedPulses = <PulseEntry>[];

    if (includesCurrentPeriod) {
      // Generate synthetic pulses from TimelineItems for the current period
      // (similar to MonthCard logic)
      final referenceMonth = viewMode == ViewPeriodMode.paycheck
          ? periodInfo.start
          : DateTime(now.year, now.month);

      for (final item in timelineItems) {
        if (!item.isIncome &&
            !item.archived &&
            PaycheckService.shouldItemAppearInPeriod(
              item,
              periodInfo,
              referenceMonth,
            )) {
          projectedPulses.add(
            _projectTimelineItemToPulse(item, referenceMonth),
          );
        }
      }
    }

    // Merge and sort
    // Note: If a TimelineItem has already been "paid" (recorded as a PulseEntry for this month),
    // we should ideally deduplicate.
    // BUT: The app's current model separates "Pulse" from "TimelineItem".
    // "Mark as Paid" creates a Pulse but keeps the TimelineItem (until next month).
    // In Month View, we hide the TimelineItem if it's "paid" (linked pulse exists).
    // We should do the same here.

    // Build set of timelineItemIds that have been paid in the current period
    final paidTimelineItemIds = <String>{};
    for (final p in recordedPulses) {
      if (p.timelineItemId != null) {
        // TODO: Strictly check if the pulse belongs to THIS period?
        // recordedPulses are already filtered by the range.
        paidTimelineItemIds.add(p.timelineItemId!.value);
      }
    }

    final finalProjected = projectedPulses.where((p) {
      if (p.timelineItemId == null) return true;
      return !paidTimelineItemIds.contains(p.timelineItemId!.value);
    }).toList();

    final all = [...recordedPulses, ...finalProjected];
    all.sort((a, b) => b.date.compareTo(a.date));

    return all;
  }

  static PulseEntry _projectTimelineItemToPulse(
    TimelineItem item,
    DateTime periodStart,
  ) {
    // Create a synthetic pulse
    // Date: Try to use dayOfMonth within the period
    var date = DateTime(periodStart.year, periodStart.month, item.dayOfMonth);
    // Handle invalid dates (e.g. Feb 30)
    if (date.month != periodStart.month) {
      date = DateTime(periodStart.year, periodStart.month + 1, 0);
    }

    // If we are in paycheck mode, ensuring the date falls physically within the period
    // is complex if strictly following dayOfMonth.
    // For insight lists, dayOfMonth is usually fine as an approximation.

    return PulseEntry(
      id: EntryId(
        'synthetic_${item.id.value}_${periodStart.millisecondsSinceEpoch}',
      ), // Temp ID
      label: item.label,
      amountMinorUnits: item.amountMinorUnits,
      date: date,
      type: item.type,
      timelineItemId: item.id,
      category: item.category,
      // Propagate other known fields if needed
    );
  }

  /// Deprecated: Use [InsightRegistry.generateInsights] instead.
  @Deprecated('Use InsightRegistry.generateInsights instead')
  static List<SmartInsight> generateSmartInsights(
    List<PulseEntry> pulses,
    List<TimelineItem> timelineItems,
    List<CategorySpending> categorySpending,
    PriorityBreakdown priorityBreakdown,
    String Function(int minorUnits) formatMoney,
  ) {
    // This method is now legacy and its logic has been moved to InsightRegistry.
    // We return an empty list here to avoid broken dead code,
    // but all callers should migrate to InsightRegistry.
    return const [];
  }

  // Helper: Calculate month span from pulse dates
  static int _calculateMonthSpan(List<PulseEntry> pulses) {
    if (pulses.isEmpty) return 1;
    final dates = pulses.map((p) => p.date);
    final earliest = dates.reduce((a, b) => a.isBefore(b) ? a : b);
    final latest = dates.reduce((a, b) => a.isAfter(b) ? a : b);
    final months = (latest.year - earliest.year) * 12 +
        (latest.month - earliest.month) +
        1;
    return months.clamp(1, 120); // Max 10 years
  }

  // Helper: Group pulses by category and sum amounts
  // Uses 3-level category resolution: pulse.category → linked item → label match
  static Map<String, int> _groupByCategory(
    Iterable<PulseEntry> pulses,
    List<TimelineItem> timelineItems,
  ) {
    // Build lookup maps for category resolution
    final itemMap = <String, TimelineItem>{};
    final labelToItemMap = <String, TimelineItem>{};
    for (final item in timelineItems) {
      itemMap[item.id.value] = item;
      labelToItemMap[item.label.toLowerCase()] = item;
    }

    final result = <String, int>{};
    for (final pulse in pulses) {
      // 3-level category resolution (same as calculateCategorySpending)
      final category = resolveCategory(pulse, itemMap, labelToItemMap);

      final displayCategory = category ?? 'Uncategorized';
      // Use transaction amount (actual debited/credited) if available,
      // otherwise fall back to entered amount
      final amount =
          pulse.transactionAmountMinorUnits ?? pulse.amountMinorUnits;
      result[displayCategory] = (result[displayCategory] ?? 0) + amount.abs();
    }
    return result;
  }
}
