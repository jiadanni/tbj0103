/// Computation tracing utilities for AI-assisted debug exports.
///
/// These functions run the same logic as the app's display code but capture
/// all intermediate values, making it trivial for AI to diagnose why an item
/// appears (or doesn't appear) in a particular month.
library;

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

// ─────────────────────────────────────────────────────────────────────────────
// Timeline Item Computation Traces
// ─────────────────────────────────────────────────────────────────────────────

/// Traces the `shouldAppearInMonth` computation for a timeline item.
///
/// Returns a detailed breakdown of every check performed, allowing AI to
/// understand exactly why an item does or doesn't appear in a given month.
Map<String, dynamic> traceMonthAppearance(
  TimelineItem item,
  DateTime month, {
  DateTime? referenceDate,
}) {
  final normalizedMonth = DateMath.toUtcMonth(month);
  final normalizedStart = DateMath.toUtcMonth(item.startDate);

  // Check: before start date?
  if (normalizedMonth.isBefore(normalizedStart)) {
    return {
      'shouldAppear': false,
      'reason': 'beforeStartDate',
      'computation': {
        'normalizedMonth': normalizedMonth.toIso8601String(),
        'normalizedStart': normalizedStart.toIso8601String(),
        'monthBeforeStart': true,
      },
    };
  }

  // Check: is this month explicitly skipped?
  if (item.skippedDates != null) {
    final isSkipped = item.skippedDates!.any(
      (d) => DateMath.toUtcMonth(d).isAtSameMomentAs(normalizedMonth),
    );
    if (isSkipped) {
      return {
        'shouldAppear': false,
        'reason': 'explicitlySkipped',
        'computation': {
          'normalizedMonth': normalizedMonth.toIso8601String(),
          'skippedDates': item.skippedDates!
              .map((d) => DateMath.toUtcMonth(d).toIso8601String())
              .toList(),
        },
      };
    }
  }

  // Check: pause window
  if (item.pausedDate != null) {
    final normalizedPaused = DateMath.toUtcMonth(item.pausedDate!);
    if (!normalizedMonth.isBefore(normalizedPaused)) {
      // We are in or after the paused month
      if (item.autoResumeDate != null) {
        final normalizedResume = DateMath.toUtcMonth(item.autoResumeDate!);
        if (normalizedMonth.isBefore(normalizedResume)) {
          return {
            'shouldAppear': false,
            'reason': 'pausedWithPendingResume',
            'computation': {
              'normalizedMonth': normalizedMonth.toIso8601String(),
              'pausedDate': normalizedPaused.toIso8601String(),
              'autoResumeDate': normalizedResume.toIso8601String(),
              'isPaused': true,
            },
          };
        }
        // Else: we have resumed, continue checks
      } else {
        // Paused indefinitely
        return {
          'shouldAppear': false,
          'reason': 'pausedIndefinitely',
          'computation': {
            'normalizedMonth': normalizedMonth.toIso8601String(),
            'pausedDate': normalizedPaused.toIso8601String(),
            'autoResumeDate': null,
            'isPaused': true,
          },
        };
      }
    }
  }

  // Check: one-off items only appear in their start month
  if (item.type == PulseType.oneOff || item.type == PulseType.oneOffIncome) {
    final sameMonth = normalizedMonth.year == normalizedStart.year &&
        normalizedMonth.month == normalizedStart.month;
    return {
      'shouldAppear': sameMonth,
      'reason': sameMonth ? 'oneOffMatchesStartMonth' : 'oneOffDifferentMonth',
      'computation': {
        'type': item.type.name,
        'normalizedMonth': normalizedMonth.toIso8601String(),
        'normalizedStart': normalizedStart.toIso8601String(),
        'sameMonth': sameMonth,
      },
    };
  }

  // Check: frequency recurrence
  final frequency = item.frequency;
  if (frequency != null) {
    final monthsSinceStart = month_math.monthsBetween(
      normalizedStart,
      normalizedMonth,
    );
    final bucket = _getBucket(frequency);
    final moduloResult = monthsSinceStart % bucket;

    if (moduloResult != 0) {
      return {
        'shouldAppear': false,
        'reason': 'recurrenceMismatch',
        'computation': {
          'frequency': frequency.name,
          'monthsSinceStart': monthsSinceStart,
          'bucket': bucket,
          'moduloResult': moduloResult,
          'expectedModulo': 0,
        },
      };
    }

    // Check: occurrence date must not be before actual start date
    final dayInMonth = _effectiveDayOfMonth(
      normalizedMonth.year,
      normalizedMonth.month,
      item.dayOfMonth,
    );
    final occurrenceDate = DateTime.utc(
      normalizedMonth.year,
      normalizedMonth.month,
      dayInMonth,
    );
    final actualStartDate = DateMath.toUtcDate(item.startDate);

    if (occurrenceDate.isBefore(actualStartDate)) {
      return {
        'shouldAppear': false,
        'reason': 'occurrenceBeforeStartDate',
        'computation': {
          'occurrenceDate': occurrenceDate.toIso8601String(),
          'actualStartDate': actualStartDate.toIso8601String(),
          'dayOfMonth': item.dayOfMonth,
          'effectiveDayInMonth': dayInMonth,
        },
      };
    }
  }

  // Check: debt item end date logic
  if (item.type == PulseType.debt) {
    // Check explicit paid off date
    if (item.paidOffDate != null) {
      final normalizedPaidOff = DateMath.toUtcMonth(item.paidOffDate!);
      if (normalizedMonth.isAfter(normalizedPaidOff)) {
        return {
          'shouldAppear': false,
          'reason': 'debtPaidOff',
          'computation': {
            'normalizedMonth': normalizedMonth.toIso8601String(),
            'paidOffDate': normalizedPaidOff.toIso8601String(),
            'monthAfterPaidOff': true,
          },
        };
      }
    }

    // Check remaining balance
    if (item.remainingBalanceMinorUnits != null &&
        item.remainingBalanceMinorUnits! <= 0) {
      return {
        'shouldAppear': false,
        'reason': 'debtBalanceZero',
        'computation': {
          'remainingBalanceMinorUnits': item.remainingBalanceMinorUnits,
        },
      };
    }

    // Check calculated final pulse date
    final calculatedFinalDate = item.calculateFinalPulseDate(
      fromDate: referenceDate,
    );
    if (calculatedFinalDate != null) {
      final normalizedFinalDate = DateMath.toUtcMonth(calculatedFinalDate);
      if (normalizedMonth.isAfter(normalizedFinalDate)) {
        return {
          'shouldAppear': false,
          'reason': 'debtProjectedPaidOff',
          'computation': {
            'normalizedMonth': normalizedMonth.toIso8601String(),
            'calculatedFinalDate': normalizedFinalDate.toIso8601String(),
            'monthAfterProjectedPayoff': true,
          },
        };
      }
    }
  }

  // All checks passed - item should appear
  final computation = <String, dynamic>{
    'normalizedMonth': normalizedMonth.toIso8601String(),
    'normalizedStart': normalizedStart.toIso8601String(),
  };

  if (frequency != null) {
    final monthsSinceStart = month_math.monthsBetween(
      normalizedStart,
      normalizedMonth,
    );
    final bucket = _getBucket(frequency);
    final dayInMonth = _effectiveDayOfMonth(
      normalizedMonth.year,
      normalizedMonth.month,
      item.dayOfMonth,
    );

    computation['frequency'] = frequency.name;
    computation['monthsSinceStart'] = monthsSinceStart;
    computation['bucket'] = bucket;
    computation['moduloResult'] = monthsSinceStart % bucket;
    computation['occurrenceDate'] = DateTime.utc(
      normalizedMonth.year,
      normalizedMonth.month,
      dayInMonth,
    ).toIso8601String();
  }

  if (item.pausedDate != null && item.autoResumeDate != null) {
    computation['isPaused'] = false;
    computation['resumedFrom'] = DateMath.toUtcMonth(
      item.autoResumeDate!,
    ).toIso8601String();
  }

  return {
    'shouldAppear': true,
    'reason': 'recurrenceMatch',
    'computation': computation,
  };
}

/// Traces all months for a timeline item within a projection range.
Map<String, dynamic> traceItemForMonths(
  TimelineItem item,
  List<DateTime> months,
  DateTime referenceDate,
) {
  final monthResults = <String, Map<String, dynamic>>{};

  for (final month in months) {
    final monthKey = _formatMonthKey(month);
    monthResults[monthKey] = traceMonthAppearance(
      item,
      month,
      referenceDate: referenceDate,
    );
  }

  return {
    'itemId': item.id.value,
    'itemLabel': item.label,
    'type': item.type.name,
    'frequency': item.frequency?.name,
    'startDate': item.startDate.toIso8601String().split('T').first,
    'dayOfMonth': item.dayOfMonth,
    'amountMinorUnits': item.amountMinorUnits,
    'archived': item.archived,
    'pausedDate': item.pausedDate?.toIso8601String().split('T').first,
    'autoResumeDate': item.autoResumeDate?.toIso8601String().split('T').first,
    'monthResults': monthResults,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Balance Computation Traces
// ─────────────────────────────────────────────────────────────────────────────

/// Traces balance computation for a range of months.
Map<String, dynamic> traceBalanceForMonths(
  List<TimelineItem> timelineItems,
  List<DateTime> months, {
  int startingBalance = 0,
  DateTime? referenceDate,
}) {
  final monthlyData = <String, Map<String, dynamic>>{};
  var runningBalance = startingBalance;

  for (final month in months) {
    final monthKey = _formatMonthKey(month);
    final itemsIncluded = <Map<String, dynamic>>[];
    var projectedIncome = 0;
    var projectedExpenses = 0;

    for (final item in timelineItems) {
      if (item.archived) continue;

      final shouldAppear = item.shouldAppearInMonth(
        month,
        referenceDate: referenceDate,
      );
      if (!shouldAppear) continue;

      final amount = item.getAmountForDate(month);

      if (item.isIncome) {
        projectedIncome += amount;
      } else {
        projectedExpenses += amount;
      }

      itemsIncluded.add({
        'id': item.id.value,
        'label': item.label,
        'amount': amount,
        'isIncome': item.isIncome,
      });
    }

    final netChange = projectedIncome + projectedExpenses;
    runningBalance += netChange;

    monthlyData[monthKey] = {
      'projectedIncome': projectedIncome,
      'projectedExpenses': projectedExpenses,
      'netChange': netChange,
      'endingBalance': runningBalance,
      'itemsIncluded': itemsIncluded,
    };
  }

  return {'startingBalance': startingBalance, 'months': monthlyData};
}

// ─────────────────────────────────────────────────────────────────────────────
// Debt Payoff Projection Traces
// ─────────────────────────────────────────────────────────────────────────────

/// Traces debt payoff projections for all debt items.
List<Map<String, dynamic>> traceDebtPayoffs(
  List<TimelineItem> timelineItems,
  DateTime referenceDate,
) {
  final results = <Map<String, dynamic>>[];

  for (final item in timelineItems) {
    if (item.type != PulseType.debt) continue;
    if (item.archived) continue;

    final computedFinalDate = item.calculateFinalPulseDate(
      fromDate: referenceDate,
    );

    // Calculate payments remaining
    int? paymentsRemaining;
    if (item.remainingBalanceMinorUnits != null &&
        item.remainingBalanceMinorUnits! > 0 &&
        item.amountMinorUnits != 0) {
      final effectivePayment = (item.exchangeRate != null &&
              item.exchangeRate! > 0 &&
              item.transactionAmountMinorUnits == null)
          ? (item.amountMinorUnits.abs() * item.exchangeRate!).round()
          : item.amountMinorUnits.abs();
      paymentsRemaining =
          (item.remainingBalanceMinorUnits! / effectivePayment).ceil();
    }

    results.add({
      'itemId': item.id.value,
      'itemLabel': item.label,
      'remainingBalance': item.remainingBalanceMinorUnits,
      'monthlyPayment': item.amountMinorUnits,
      'exchangeRate': item.exchangeRate,
      'balanceCurrency': item.balanceCurrency?.name,
      'computedFinalDate':
          computedFinalDate?.toIso8601String().split('T').first,
      'paymentsRemaining': paymentsRemaining,
      'computation': {
        'effectivePaymentAmount': (item.exchangeRate != null &&
                item.exchangeRate! > 0 &&
                item.transactionAmountMinorUnits == null)
            ? (item.amountMinorUnits.abs() * item.exchangeRate!).round()
            : item.amountMinorUnits.abs(),
        'fromDate': referenceDate.toIso8601String().split('T').first,
        'frequency': item.frequency?.name,
        'startDate': item.startDate.toIso8601String().split('T').first,
      },
    });
  }

  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Pulse Linkage Traces
// ─────────────────────────────────────────────────────────────────────────────

/// Traces pulse linkage state between pulses and timeline items.
Map<String, dynamic> tracePulseLinkage(
  List<TimelineItem> timelineItems,
  List<PulseEntry> pulses,
) {
  final timelineById = {for (final item in timelineItems) item.id: item};

  final linkedPulses = <Map<String, dynamic>>[];
  final orphanedPulses = <Map<String, dynamic>>[];
  var standalonePulses = 0;

  for (final pulse in pulses) {
    if (pulse.timelineItemId == null) {
      standalonePulses++;
      continue;
    }

    final linkedItem = timelineById[pulse.timelineItemId];

    if (linkedItem == null) {
      // Orphaned pulse - references a timeline item that doesn't exist
      orphanedPulses.add({
        'pulseId': pulse.id.value,
        'pulseLabel': pulse.label,
        'pulseDate': pulse.date.toIso8601String().split('T').first,
        'referencedTimelineId': pulse.timelineItemId?.value,
        'timelineExists': false,
      });
      continue;
    }

    // Calculate variances
    final amountMatch = pulse.scheduledAmountMinorUnits == null ||
        pulse.amountMinorUnits == pulse.scheduledAmountMinorUnits;
    final dateVariance = pulse.scheduledDate != null
        ? pulse.date.difference(pulse.scheduledDate!).inDays
        : null;

    linkedPulses.add({
      'pulseId': pulse.id.value,
      'pulseLabel': pulse.label,
      'pulseDate': pulse.date.toIso8601String().split('T').first,
      'pulseAmount': pulse.amountMinorUnits,
      'linkedTimelineId': linkedItem.id.value,
      'linkedTimelineLabel': linkedItem.label,
      'timelineAmount': linkedItem.amountMinorUnits,
      'amountMatch': amountMatch,
      'scheduledDate': pulse.scheduledDate?.toIso8601String().split('T').first,
      'scheduledAmount': pulse.scheduledAmountMinorUnits,
      'dateVariance': dateVariance,
      'amountVariance': pulse.scheduledAmountMinorUnits != null
          ? pulse.amountMinorUnits - pulse.scheduledAmountMinorUnits!
          : null,
    });
  }

  return {
    'linkedPulses': linkedPulses,
    'orphanedPulses': orphanedPulses,
    'standalonePulses': standalonePulses,
    'summary': {
      'totalPulses': pulses.length,
      'linkedCount': linkedPulses.length,
      'orphanedCount': orphanedPulses.length,
      'standaloneCount': standalonePulses,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Data Anomalies Traces
// ─────────────────────────────────────────────────────────────────────────────

/// Traces timeline items and pulses for data anomalies or legacy structures.
List<Map<String, dynamic>> traceDataAnomalies(
  List<TimelineItem> timelineItems,
) {
  final anomalies = <Map<String, dynamic>>[];

  for (final item in timelineItems) {
    if (item.type == PulseType.debt &&
        item.exchangeRate != null &&
        item.transactionAmountMinorUnits == null) {
      anomalies.add({
        'itemId': item.id.value,
        'itemLabel': item.label,
        'issueType': 'legacy_foreign_debt',
        'severity': 'warning',
        'description':
            'Item uses exchangeRate but lacks transactionAmountMinorUnits. Using legacy calculation.',
        'data': {
          'exchangeRate': item.exchangeRate,
          'amountMinorUnits': item.amountMinorUnits,
        },
      });
    }

    // You can add more anomaly checks here in the future
  }

  return anomalies;
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Entry Point
// ─────────────────────────────────────────────────────────────────────────────

/// Generates complete computation traces for the debug export.
///
/// This is the main entry point called by the export service.
Map<String, dynamic> traceComputations({
  required List<TimelineItem> timelineItems,
  required List<PulseEntry> pulses,
  required DateTime referenceDate,
  required int projectionMonths,
  int startingBalance = 0,
}) {
  // Generate month range: 3 months back + projectionMonths forward
  final startMonth = DateTime.utc(referenceDate.year, referenceDate.month - 3);
  final months = List.generate(
    projectionMonths,
    (i) => month_math.addMonths(startMonth, i),
  );

  // Only trace active (non-archived) timeline items
  final activeItems = timelineItems.where((t) => !t.archived).toList();

  return {
    'referenceDate': referenceDate.toIso8601String(),
    'projectionRange': {
      'start': _formatMonthKey(months.first),
      'end': _formatMonthKey(months.last),
      'monthCount': months.length,
    },
    'timelineItemComputations': activeItems
        .map((item) => traceItemForMonths(item, months, referenceDate))
        .toList(),
    'balanceComputations': traceBalanceForMonths(
      timelineItems,
      months,
      startingBalance: startingBalance,
      referenceDate: referenceDate,
    ),
    'debtProjections': traceDebtPayoffs(timelineItems, referenceDate),
    'pulseLinkage': tracePulseLinkage(timelineItems, pulses),
    'dataAnomalies': traceDataAnomalies(timelineItems),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Private Helpers
// ─────────────────────────────────────────────────────────────────────────────

int _getBucket(RecurrenceFrequency frequency) {
  return switch (frequency) {
    RecurrenceFrequency.weekly ||
    RecurrenceFrequency.biweekly ||
    RecurrenceFrequency.monthly =>
      1,
    RecurrenceFrequency.quarterly => 3,
    RecurrenceFrequency.yearly => 12,
  };
}

int _effectiveDayOfMonth(int year, int month, int dayOfMonth) {
  final maxDay = DateTime.utc(year, month + 1, 0).day;
  return dayOfMonth <= maxDay ? dayOfMonth : maxDay;
}

String _formatMonthKey(DateTime month) {
  return '${month.year}-${month.month.toString().padLeft(2, '0')}';
}
