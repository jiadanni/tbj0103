/// A sentinel object to distinguish between a null value and an omitted parameter
/// in a `copyWith` method.
const Object sentinel = Object();

/// A wrapper that represents a value that can be explicitly null.
///
/// Used in `copyWith` methods to distinguish between "not provided" (keep current)
/// and "explicitly null" (clear field).
///
/// Note: Alternatively, use the [sentinel] pattern which is more source-compatible.
class Optional<T> {
  const Optional(this.value);

  /// Helper to create an Optional with a value.
  const Optional.value(T value) : this(value);

  /// Helper to create an Optional representing null.
  const Optional.absent() : this(null);

  final T? value;
}
