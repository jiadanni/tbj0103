/// Normalized date utilities to prevent timezone-related bugs.
class DateMath {
  const DateMath._();

  /// Returns a normalized UTC DateTime at the start of the day (00:00:00).
  ///
  /// This treats the local year, month, and day as the "canonical" date
  /// and anchors it to UTC 00:00:00. This ensures that date-only comparisons
  /// are consistent regardless of the local timezone or daylight savings.
  static DateTime toUtcDate(DateTime date) {
    return DateTime.utc(date.year, date.month, date.day);
  }

  /// Returns a normalized UTC DateTime at the start of the month (1st day, 00:00:00 UTC).
  static DateTime toUtcMonth(DateTime date) {
    return DateTime.utc(date.year, date.month, 1);
  }

  /// Checks if [date] is within the range [start] and [end] inclusive.
  ///
  /// Normalizes all dates to UTC date-only before comparison.
  static bool isInRangeInclusive(DateTime date, DateTime start, DateTime end) {
    final d = toUtcDate(date);
    final s = toUtcDate(start);
    final e = toUtcDate(end);
    return !d.isBefore(s) && !d.isAfter(e);
  }
}
