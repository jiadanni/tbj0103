import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

/// Represents a single scheduled payment in a debt payoff schedule.
class PaymentScheduleEntry {
  const PaymentScheduleEntry({
    required this.paymentNumber,
    required this.date,
    required this.paymentAmount,
    required this.remainingBalanceAfter,
  });

  /// The payment number (1-indexed)
  final int paymentNumber;

  /// The scheduled date for this payment
  final DateTime date;

  /// The payment amount in minor units (cents)
  final int paymentAmount;

  /// The remaining balance after this payment in minor units
  final int remainingBalanceAfter;
}

/// Service for debt payoff and financial calculations.
/// Extracted from TimelineItem to allow for reuse and thorough testing.
class DebtCalculator {
  const DebtCalculator._();

  /// Maximum number of pulse before we consider the calculation unreasonable.
  /// 1200 pulse = 100 years of monthly pulse, which is a sensible upper bound.
  static const int maxReasonablePulses = 1200;

  /// Calculates the estimated final pulse date for debt items.
  ///
  /// Returns null if:
  /// - Item is not a debt type
  /// - No remaining balance is set
  /// - Pulse amount is zero or negative
  /// - No frequency is set
  /// - Calculated payoff exceeds 100 years (sanity check)
  static DateTime? calculateFinalPulseDate({
    required PulseType type,
    required int? remainingBalanceMinorUnits,
    required int amountMinorUnits,
    required RecurrenceFrequency? frequency,
    required DateTime startDate,
    double? exchangeRate,
    DateTime? fromDate,
    AppCurrency? balanceCurrency,
  }) {
    // Only applicable to debt items
    if (type != PulseType.debt) return null;

    // Need remaining balance to calculate
    if (remainingBalanceMinorUnits == null || remainingBalanceMinorUnits <= 0) {
      return null;
    }

    // Need non-zero pulse amount (use absolute value for expenses).
    final pulseAmount = amountMinorUnits.abs();
    // Apply exchange rate if provided and valid (> 0)
    final effectivePulseAmount = (exchangeRate != null && exchangeRate > 0)
        ? (pulseAmount * exchangeRate).round()
        : pulseAmount;

    if (effectivePulseAmount == 0) return null;

    // Need frequency for recurring debt
    if (frequency == null) return null;

    final anchor = fromDate ?? DateTime.now().toUtc();

    // Find the next scheduled pulse date on or after the anchor date
    DateTime baseDate;
    if (!startDate.isBefore(anchor)) {
      baseDate = startDate;
    } else {
      // startDate is in the past, find next occurrence
      switch (frequency) {
        case RecurrenceFrequency.weekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final weeksPassed = (daysDiff / 7.0).ceil();
          baseDate = startDate.add(
            Duration(days: (weeksPassed < 0 ? 0 : weeksPassed) * 7),
          );
          if (baseDate.isBefore(anchor)) {
            baseDate = baseDate.add(const Duration(days: 7));
          }
          break;

        case RecurrenceFrequency.biweekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final fortnightsPassed = (daysDiff / 14.0).ceil();
          baseDate = startDate.add(
            Duration(days: (fortnightsPassed < 0 ? 0 : fortnightsPassed) * 14),
          );
          if (baseDate.isBefore(anchor)) {
            baseDate = baseDate.add(const Duration(days: 14));
          }
          break;

        case RecurrenceFrequency.monthly:
        case RecurrenceFrequency.quarterly:
        case RecurrenceFrequency.yearly:
          final monthsPerPeriod = switch (frequency) {
            RecurrenceFrequency.monthly => 1,
            RecurrenceFrequency.quarterly => 3,
            RecurrenceFrequency.yearly => 12,
            _ => 1,
          };

          final monthsDiff = (anchor.year - startDate.year) * 12 +
              (anchor.month - startDate.month);

          var periodsPassed = (monthsDiff / monthsPerPeriod).floor();
          var candidate = month_math.addMonths(
            startDate,
            periodsPassed * monthsPerPeriod,
          );
          while (candidate.isBefore(anchor)) {
            periodsPassed++;
            candidate = month_math.addMonths(
              startDate,
              periodsPassed * monthsPerPeriod,
            );
          }
          baseDate = candidate;
          break;
      }
    }

    // Calculate number of pulse needed
    final pulseNeeded =
        (remainingBalanceMinorUnits / effectivePulseAmount).ceil();
    if (pulseNeeded <= 0) return baseDate;

    // Sanity check
    if (pulseNeeded > maxReasonablePulses) return null;

    final additionalPeriods = pulseNeeded - 1;

    switch (frequency) {
      case RecurrenceFrequency.weekly:
        return baseDate.add(Duration(days: additionalPeriods * 7));
      case RecurrenceFrequency.biweekly:
        return baseDate.add(Duration(days: additionalPeriods * 14));
      case RecurrenceFrequency.monthly:
        return month_math.addMonths(baseDate, additionalPeriods);
      case RecurrenceFrequency.quarterly:
        return month_math.addMonths(baseDate, additionalPeriods * 3);
      case RecurrenceFrequency.yearly:
        return month_math.addMonths(baseDate, additionalPeriods * 12);
    }
  }

  /// Calculates the complete payment schedule for a debt item.
  ///
  /// Returns a list of [PaymentScheduleEntry] objects representing each
  /// scheduled payment from now until the debt is paid off.
  ///
  /// Returns null if the schedule cannot be calculated (same conditions as
  /// calculateFinalPulseDate).
  static List<PaymentScheduleEntry>? calculatePaymentSchedule({
    required PulseType type,
    required int? remainingBalanceMinorUnits,
    required int amountMinorUnits,
    required RecurrenceFrequency? frequency,
    required DateTime startDate,
    double? exchangeRate,
    DateTime? fromDate,
    AppCurrency? balanceCurrency,
  }) {
    // Only applicable to debt items
    if (type != PulseType.debt) return null;

    // Need remaining balance to calculate
    if (remainingBalanceMinorUnits == null || remainingBalanceMinorUnits <= 0) {
      return null;
    }

    // Need non-zero pulse amount (use absolute value for expenses)
    final pulseAmount = amountMinorUnits.abs();

    // Apply exchange rate if provided and valid (> 0)
    final effectivePulseAmount = (exchangeRate != null && exchangeRate > 0)
        ? (pulseAmount * exchangeRate).round()
        : pulseAmount;

    if (effectivePulseAmount == 0) return null;

    if (frequency == null) return null;

    final anchor = fromDate ?? DateTime.now().toUtc();

    // Find the next scheduled pulse date on or after the anchor date
    DateTime baseDate;
    if (!startDate.isBefore(anchor)) {
      baseDate = startDate;
    } else {
      switch (frequency) {
        case RecurrenceFrequency.weekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final weeksPassed = (daysDiff / 7.0).ceil();
          baseDate = startDate.add(
            Duration(days: (weeksPassed < 0 ? 0 : weeksPassed) * 7),
          );
          if (baseDate.isBefore(anchor)) {
            baseDate = baseDate.add(const Duration(days: 7));
          }
          break;

        case RecurrenceFrequency.biweekly:
          final daysDiff = anchor.difference(startDate).inDays;
          final fortnightsPassed = (daysDiff / 14.0).ceil();
          baseDate = startDate.add(
            Duration(days: (fortnightsPassed < 0 ? 0 : fortnightsPassed) * 14),
          );
          if (baseDate.isBefore(anchor)) {
            baseDate = baseDate.add(const Duration(days: 14));
          }
          break;

        case RecurrenceFrequency.monthly:
        case RecurrenceFrequency.quarterly:
        case RecurrenceFrequency.yearly:
          final monthsPerPeriod = switch (frequency) {
            RecurrenceFrequency.monthly => 1,
            RecurrenceFrequency.quarterly => 3,
            RecurrenceFrequency.yearly => 12,
            _ => 1,
          };

          final monthsDiff = (anchor.year - startDate.year) * 12 +
              (anchor.month - startDate.month);

          var periodsPassed = (monthsDiff / monthsPerPeriod).floor();
          var candidate = month_math.addMonths(
            startDate,
            periodsPassed * monthsPerPeriod,
          );
          while (candidate.isBefore(anchor)) {
            periodsPassed++;
            candidate = month_math.addMonths(
              startDate,
              periodsPassed * monthsPerPeriod,
            );
          }
          baseDate = candidate;
          break;
      }
    }

    // Calculate number of pulses needed
    final pulseNeeded =
        (remainingBalanceMinorUnits / effectivePulseAmount).ceil();
    if (pulseNeeded <= 0) return [];

    // Sanity check
    if (pulseNeeded > maxReasonablePulses) return null;

    final schedule = <PaymentScheduleEntry>[];
    var currentBalance = remainingBalanceMinorUnits;
    var currentDate = baseDate;

    for (var i = 1; i <= pulseNeeded; i++) {
      // Calculate the actual payment for this instalment
      // The last payment may be less than the regular amount
      final actualPayment = currentBalance < effectivePulseAmount
          ? currentBalance
          : effectivePulseAmount;
      currentBalance -= actualPayment;

      schedule.add(
        PaymentScheduleEntry(
          paymentNumber: i,
          date: currentDate,
          paymentAmount: actualPayment,
          remainingBalanceAfter: currentBalance < 0 ? 0 : currentBalance,
        ),
      );

      if (currentBalance <= 0) break;

      // Advance to next payment date
      switch (frequency) {
        case RecurrenceFrequency.weekly:
          currentDate = currentDate.add(const Duration(days: 7));
          break;
        case RecurrenceFrequency.biweekly:
          currentDate = currentDate.add(const Duration(days: 14));
          break;
        case RecurrenceFrequency.monthly:
          currentDate = month_math.addMonths(currentDate, 1);
          break;
        case RecurrenceFrequency.quarterly:
          currentDate = month_math.addMonths(currentDate, 3);
          break;
        case RecurrenceFrequency.yearly:
          currentDate = month_math.addMonths(currentDate, 12);
          break;
      }
    }

    return schedule;
  }
}
