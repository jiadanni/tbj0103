import 'package:flutter/widgets.dart';

import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Provides user-configurable terminology based on the selected preset.
///
/// This helper resolves terminology strings based on [TerminologyPreset]:
/// - `defaultTerms`: "Scheduled", "Paid", "Mark Paid"
/// - `bills`: "Bills", "Paid", "Mark Paid"
/// - `budget`: "Budget", "Done", "Mark Done"
class Terminology {
  const Terminology._(
    this._l10n,
    this._preset, {
    this.customPulseLabel,
    this.customTimelineLabel,
  });

  final AppLocalizations _l10n;
  final TerminologyPreset _preset;
  final String? customPulseLabel;
  final String? customTimelineLabel;

  /// Creates a [Terminology] instance from the current context.
  factory Terminology.of(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.read(context);
    return Terminology._(
      l10n!,
      settings.terminologyPreset,
      customPulseLabel: settings.customPulseLabel,
      customTimelineLabel: settings.customTimelineLabel,
    );
  }

  /// The label for the timeline tab (e.g., "Timeline")
  String get timelineTabLabel => _l10n.timeline;

  /// The label for the insights tab
  String get insightsTabLabel => _l10n.insights;

  /// The label for the list tab (e.g., "Scheduled", "Bills", "Budget")
  String get pulseTabLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_listTab_default,
      TerminologyPreset.bills => _l10n.term_listTab_bills,
      TerminologyPreset.budget => _l10n.term_listTab_budget,
      TerminologyPreset.custom =>
        customPulseLabel ?? _l10n.term_listTab_default,
    };
  }

  /// The label for hiding paid items (e.g., "Hide paid items")
  String get hidePaidLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_hidePaid_default,
      TerminologyPreset.bills => _l10n.term_hidePaid_bills,
      TerminologyPreset.budget => _l10n.term_hidePaid_budget,
      TerminologyPreset.custom => _l10n.term_hidePaid_default,
    };
  }

  /// The label for showing paid items (e.g., "Show paid items")
  String get showPaidLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_showPaid_default,
      TerminologyPreset.bills => _l10n.term_showPaid_bills,
      TerminologyPreset.budget => _l10n.term_showPaid_budget,
      TerminologyPreset.custom => _l10n.term_showPaid_default,
    };
  }

  /// The status label for paid/done items (e.g., "Paid", "Done")
  String get itemStatusLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_itemStatus_default,
      TerminologyPreset.bills => _l10n.term_itemStatus_bills,
      TerminologyPreset.budget => _l10n.term_itemStatus_budget,
      TerminologyPreset.custom => _l10n.term_itemStatus_default,
    };
  }

  String get archiveActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_archiveAction_default,
      TerminologyPreset.bills => _l10n.term_archiveAction_bills,
      TerminologyPreset.budget => _l10n.term_archiveAction_budget,
      TerminologyPreset.custom => _l10n.term_archiveAction_default,
    };
  }

  String get unarchiveActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_unarchiveAction_default,
      TerminologyPreset.bills => _l10n.term_unarchiveAction_bills,
      TerminologyPreset.budget => _l10n.term_unarchiveAction_budget,
      TerminologyPreset.custom => _l10n.term_unarchiveAction_default,
    };
  }

  String get archivedStatusLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_archivedStatus_default,
      TerminologyPreset.bills => _l10n.term_archivedStatus_bills,
      TerminologyPreset.budget => _l10n.term_archivedStatus_budget,
      TerminologyPreset.custom => _l10n.term_archivedStatus_default,
    };
  }

  /// The action label for marking as paid (e.g., "Mark Paid", "Mark Done")
  String get markActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_markAction_default,
      TerminologyPreset.bills => _l10n.term_markAction_bills,
      TerminologyPreset.budget => _l10n.term_markAction_budget,
      TerminologyPreset.custom => _l10n.term_markAction_default,
    };
  }

  /// The action label for unmarking (e.g., "Unmark", "Undo")
  String get unmarkActionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_unmarkAction_default,
      TerminologyPreset.bills => _l10n.term_unmarkAction_bills,
      TerminologyPreset.budget => _l10n.term_unmarkAction_budget,
      TerminologyPreset.custom => _l10n.term_unmarkAction_default,
    };
  }

  /// The title for creating a new item (e.g., "New scheduled item")
  String get newItemTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_newItem_default,
      TerminologyPreset.bills => _l10n.term_newItem_bills,
      TerminologyPreset.budget => _l10n.term_newItem_budget,
      TerminologyPreset.custom => _l10n.term_newItem_custom(
          customTimelineLabel?.toLowerCase() ?? _l10n.term_activity_fallback,
        ),
    };
  }

  /// The title for editing an item (e.g., "Edit scheduled item")
  String get editItemTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_editItem_default,
      TerminologyPreset.bills => _l10n.term_editItem_bills,
      TerminologyPreset.budget => _l10n.term_editItem_budget,
      TerminologyPreset.custom => _l10n.term_editItem_custom(
          customTimelineLabel?.toLowerCase() ?? _l10n.term_activity_fallback,
        ),
    };
  }

  /// The title for the delete confirmation dialog
  String get deleteTitle {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_deleteTitle_default,
      TerminologyPreset.bills => _l10n.term_deleteTitle_bills,
      TerminologyPreset.budget => _l10n.term_deleteTitle_budget,
      TerminologyPreset.custom => _l10n.term_deleteTitle_custom(
          customTimelineLabel?.toLowerCase() ?? _l10n.term_activity_fallback,
        ),
    };
  }

  /// The empty state message when there are no items
  String get noItemsMessage {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => _l10n.term_noItems_default,
      TerminologyPreset.bills => _l10n.term_noItems_bills,
      TerminologyPreset.budget => _l10n.term_noItems_budget,
      TerminologyPreset.custom => _l10n.term_noItems_custom(
          customTimelineLabel?.toLowerCase() ?? _l10n.term_activity_fallback,
        ),
    };
  }

  /// The label for a recorded event (e.g., "Transaction", "Pulse", "Entry")
  String get transactionLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => 'Transaction',
      TerminologyPreset.bills => 'Transaction',
      TerminologyPreset.budget => 'Entry',
      TerminologyPreset.custom => customTimelineLabel ?? 'Transaction',
    };
  }

  /// The label for a budget bucket (e.g., "Budget", "Envelope")
  String get budgetLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => 'Envelope',
      TerminologyPreset.bills => 'Bill',
      TerminologyPreset.budget => 'Budget',
      TerminologyPreset.custom => 'Budget',
    };
  }

  /// The label for multiple budget buckets (e.g., "Budgets", "Envelopes")
  String get budgetsLabel {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => 'Envelopes',
      TerminologyPreset.bills => 'Bills',
      TerminologyPreset.budget => 'Budgets',
      TerminologyPreset.custom => 'Budgets',
    };
  }

  /// The label for financial pots (e.g., "Pots")
  String get potsLabel => 'Pots';

  /// The label for a single Pot
  String get potLabel => 'Pot';

  /// The label for income/credits
  String get creditsLabel => 'Credits';

  /// The label for expenses/debits
  String get debitsLabel => 'Debits';

  /// The label for income (e.g., "Income")
  String get incomeLabel => 'Income';

  /// The label for expense (e.g., "Expense")
  String get expenseLabel => 'Expense';

  /// The label for recurring items (e.g., "Recurring")
  String get recurringLabel => 'Recurring';

  /// The label for one-off items (e.g., "One-off")
  String get oneOffLabel => 'One-off';

  /// The label for planned items (e.g., "Planned")
  String get plannedLabel => 'Planned';

  /// The label for history (e.g., "History")
  String get historyLabel => 'History';

  /// The label for debt items (e.g., "Debt")
  String get debtLabel => 'Debt';

  /// The label for the starting period (e.g., "Start")
  String get startLabel => 'Start';

  /// The label for the Insights/Statistics summary
  String get insightsLabel => 'Statistics';

  /// The label for trends (e.g., "Trends")
  String get trendsLabel => 'Trends';

  /// The label for category spending (e.g., "Spending by Category")
  String get categorySpendingLabel => 'Spending by Category';

  /// The message when no transactions are found
  String get noTransactionsMessage => 'No transaction data yet';

  /// Action label for logging a transaction (e.g., "Log Transaction")
  String get logActionLabel => 'Log $transactionLabel';

  /// Label for quick spending (e.g., "Quick Spending")
  String get quickSpendLabel => 'Quick Spending';

  /// Label for 'Deduct [Budgets]' setting
  String get deductBudgetsLabel => 'Deduct $budgetsLabel';

  /// Subtitle for 'Deduct [Budgets]' setting
  String get deductBudgetsSubtitle =>
      'Default state for deducting ${budgetsLabel.toLowerCase()}';

  /// Label for '[Budget] Quick Spend' setting
  String get budgetQuickSpendLabel => '$budgetLabel Quick Spend';

  /// Subtitle for '[Budget] Quick Spend' setting
  String get budgetQuickSpendSubtitle =>
      'Set your 6 quick access amounts for spending ${budgetsLabel.toLowerCase()}';

  /// Returns a saved item message for snackbars.
  ///
  /// This is preset-aware, using the appropriate terminology for the item type.
  String savedItemMessage(String itemLabel) {
    return switch (_preset) {
      TerminologyPreset.defaultTerms => 'Scheduled item "$itemLabel" saved',
      TerminologyPreset.bills => 'Bill "$itemLabel" saved',
      TerminologyPreset.budget => 'Budget item "$itemLabel" saved',
      TerminologyPreset.custom =>
        '${customTimelineLabel ?? "Item"} "$itemLabel" saved',
    };
  }

  /// Returns the user-facing label for a pulse type.
  ///
  /// This is preset-aware, using [budgetLabel] for spending envelopes.
  String pulseTypeLabel(PulseType type) {
    return switch (type) {
      PulseType.recurring => 'Recurring Expense',
      PulseType.recurringIncome => 'Recurring Income',
      PulseType.debt => 'Debt Payment',
      PulseType.oneOff => 'One-time Expense',
      PulseType.oneOffIncome => 'One-time Income',
      PulseType.spendingEnvelope => 'Spending $budgetLabel',
    };
  }
}
