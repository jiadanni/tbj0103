import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';

/// Converts a pulse payment amount to the target balance currency.
///
/// This function handles the conversion chain for debt payments:
/// 1. If a Money Pot is provided, uses the pot's currency settings
/// 2. Otherwise falls back to the TimelineItem's balance currency
///
/// **Currency Priority:**
/// - MoneyPot.currency (if pot provided and has currency set)
/// - TimelineItem.balanceCurrency (fallback)
/// - App currency (no conversion needed)
///
/// **Example scenarios:**
/// - Debt in GBP, Pot in GBP: Payment €100 → £85 deducted from pot
/// - Debt in GBP, Pot in EUR (app): Payment €100 → €100 deducted from pot
/// - Debt in GBP, no pot: Payment €100 → £85 applied to debt balance
///
/// Parameters:
/// - [pulseAmountMinorUnits]: The payment amount in app currency (minor units)
/// - [item]: The timeline item containing fallback exchange rate configuration
/// - [pot]: Optional money pot with its own currency settings
/// - [entry]: Optional pulse entry with transaction currency details
/// - [exchangeRateOverride]: Optional rate override for historical conversions
///
/// Returns the amount in the target balance currency (minor units).
int convertPulseToBalanceCurrency(
  int pulseAmountMinorUnits,
  TimelineItem? item, {
  MoneyPot? pot,
  PulseEntry? entry,
  double? exchangeRateOverride,
}) {
  // Determine target currency and rate
  // Priority: Pot's currency > Item's balanceCurrency > App currency (no conversion)
  final AppCurrency? targetCurrency = pot?.currency ?? item?.balanceCurrency;
  final double? targetRate =
      exchangeRateOverride ?? pot?.exchangeRate ?? item?.exchangeRate;

  // If no target currency specified, no conversion needed (pot/debt is in app currency)
  if (targetCurrency == null) {
    return pulseAmountMinorUnits;
  }

  // Smart Conversion:
  // If we have the original transaction details, and the transaction was made in
  // the SAME currency as the target, we should use that amount directly.
  // This avoids double-conversion errors (Transaction -> App Ccy -> Target Ccy).
  if (entry != null &&
      entry.transactionCurrency != null &&
      entry.transactionCurrency == targetCurrency &&
      entry.transactionAmountMinorUnits != null) {
    return entry.transactionAmountMinorUnits!;
  }

  // Fallback: Convert from Settlement Amount (App Ccy) using the Exchange Rate
  if (targetRate == null || targetRate <= 0) {
    final label = pot?.name ?? item?.label ?? 'Unknown';
    debugPrint(
      'WARNING: "$label" has currency=$targetCurrency '
      'but no valid exchangeRate. Defaulting to 1:1 conversion. '
      'Please edit to set the correct exchange rate.',
    );
    return pulseAmountMinorUnits;
  }

  // Exchange rate is defined as: 1 [target currency] = X [app currency]
  // e.g., 1 GBP = 0.85 EUR means targetRate = 0.85
  // To convert FROM app currency TO target currency, we DIVIDE by the rate
  // e.g., €850 ÷ 0.85 = £1000
  return (pulseAmountMinorUnits / targetRate).round();
}

/// Validates that a debt with a foreign balance currency has a valid exchange rate.
/// Returns an error message if invalid, or null if valid.
String? validateDebtExchangeRate({
  required dynamic balanceCurrency,
  required double? exchangeRate,
}) {
  if (balanceCurrency != null && (exchangeRate == null || exchangeRate <= 0)) {
    return 'Exchange rate is required when debt is in a foreign currency';
  }
  return null;
}
