import 'package:meta/meta.dart';
import 'package:expense_stalker_mobile/src/models/insight_definition.dart';
import 'package:expense_stalker_mobile/src/models/insight_context.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';
import 'package:expense_stalker_mobile/src/util/insight_definitions.dart';

class InsightRegistry {
  const InsightRegistry._();

  static List<InsightDefinition> _definitions = initialInsightDefinitions;

  @visibleForTesting
  static void setDefinitions(List<InsightDefinition> defs) {
    _definitions = defs;
  }

  @visibleForTesting
  static void resetDefinitions() {
    _definitions = [];
  }

  /// Generates all valid insights for the current context, respecting settings.
  static List<SmartInsight> generateInsights(InsightContext context) {
    final dismissed = context.settings.dismissedInsightIds;
    final minDataOverride = context.settings.minDataDaysOverride;
    final age = context.dataAgeDays;

    return _definitions
        .where((d) => !dismissed.contains(d.id))
        .where((d) => age >= (minDataOverride ?? d.minDataDays))
        .where((d) => d.canGenerate(context))
        .map((d) {
      // Generate the base insight
      final insight = d.generate(context);
      // Return a copy (or new instance) with metadata attached
      return SmartInsight(
        question: insight.question,
        answer: insight.answer,
        icon: insight.icon,
        id: d.id,
        category: d.category.name,
        tier: d.tier.name,
      );
    }).toList();
  }

  /// Returns only core insights (for the main carousel).
  static List<SmartInsight> getCoreInsights(InsightContext context) {
    return generateInsights(
      context,
    ).where((i) => i.tier == InsightTier.core.name).toList();
  }

  /// Returns extended and advanced insights (for the "See More" list).
  static List<SmartInsight> getExtendedInsights(InsightContext context) {
    return generateInsights(
      context,
    ).where((i) => i.tier != InsightTier.core.name).toList();
  }
}
