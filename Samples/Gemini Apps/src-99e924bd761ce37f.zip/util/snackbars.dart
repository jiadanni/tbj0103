import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

void showActivitySavedSnackBar(BuildContext context, TimelineItem item) {
  final isIncome = item.type.isIncomeType;
  final colorScheme = Theme.of(context).colorScheme;
  final terminology = Terminology.of(context);

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          Icon(
            isIncome ? Icons.trending_up : Icons.trending_down,
            color: isIncome ? Colors.green : colorScheme.error,
          ),
          const SizedBox(width: 12),
          Text(terminology.savedItemMessage(item.label)),
        ],
      ),
      backgroundColor: colorScheme.surfaceContainerHighest,
      behavior: SnackBarBehavior.floating,
      duration: AppConstants.snackBarShort,
    ),
  );
}
