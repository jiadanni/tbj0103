import 'dart:math';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum TestDatasetSize {
  minimal(10),
  standard(50),
  large(300),
  stress(1000);

  final int pulseCount;
  const TestDatasetSize(this.pulseCount);
}

/// Result container for generated test data
class TestDataResult {
  final List<TimelineItem> timelineItems;
  final List<PulseEntry> pulses;
  final List<MoneyPot> moneyPots;

  const TestDataResult({
    required this.timelineItems,
    required this.pulses,
    required this.moneyPots,
  });
}

class TestDataGenerator {
  /// Categories aligned with insight definitions for proper triggers
  static const _expenseCategories = [
    'Groceries', // triggers monthly_groceries insight
    'Dining', // triggers dining_out_spending insight
    'Subscriptions', // triggers subscription_spending insight
    'Utilities', // triggers utilities_spending insight
    'Transportation', // triggers transport_spending insight
    'Entertainment', // triggers entertainment_spending insight
    'Gym/Fitness', // triggers fitness_spending insight
    'Housing', // triggers rent_income_ratio insight
    'Health',
    'Shopping',
    'Insurance',
  ];

  static const _incomeCategories = [
    'Salary',
    'Freelance',
    'Investment',
    'Refund',
  ];

  static const _origins = [
    'Albert Heijn', 'Jumbo', 'Lidl', // Groceries
    'KPN', 'Vattenfall', 'Eneco', // Utilities
    'NS', 'Shell', 'Uber', // Transport
    'Netflix', 'Spotify', 'Adobe', 'iCloud', // Subscriptions
    'HealthCity', 'Basic-Fit', // Gym
    'Amazon', 'Bol.com', // Shopping
    'Restaurant De Kas', 'Thuisbezorgd', // Dining
    'Pathé', 'Steam', // Entertainment
  ];

  static final _random = Random(42); // Fixed seed for reproducible results

  /// Generate comprehensive test data covering all app features.
  ///
  /// Returns [TestDataResult] containing timeline items, pulses, and money pots.
  static TestDataResult generate({
    required TestDatasetSize size,
    DateTime? endDate,
  }) {
    final timelineItems = <TimelineItem>[];
    final pulses = <PulseEntry>[];
    final moneyPots = <MoneyPot>[];
    final now = DateTime.now();
    final end = endDate ?? DateTime.utc(now.year, now.month);

    // Create money pots first so we can link them
    final savingsPot = MoneyPot.create(
      name: 'Emergency Fund',
      amountMinorUnits: 250000, // 2500.00
      type: MoneyPotType.savings,
    );
    moneyPots.add(savingsPot);

    final debtPotId = newMoneyPotId();
    final debtPot = MoneyPot(
      id: debtPotId,
      name: 'Student Loan Tracker',
      amountMinorUnits: 2000000, // 20000.00 remaining
      type: MoneyPotType.debt,
      isSystemManaged: true,
    );
    moneyPots.add(debtPot);

    // Foreign currency pot for multi-currency demo
    final foreignPot = MoneyPot.create(
      name: 'USD Savings',
      amountMinorUnits: 150000, // 1500.00 USD
      type: MoneyPotType.savings,
      currency: AppCurrency.usd,
      showInAppCurrency: true,
      exchangeRate: 0.92, // 1 USD = 0.92 EUR
    );
    moneyPots.add(foreignPot);

    // ========== CORE TIMELINE ITEMS (Full Feature Coverage) ==========

    // 1. Salary with paycheck boundary settings
    final salaryItem = TimelineItem(
      id: newTimelineItemId(),
      label: 'Monthly Salary',
      amountMinorUnits: 450000, // 4500.00
      dayOfMonth: 25,
      type: PulseType.recurringIncome,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      origin: 'Work',
      category: 'Salary',
      isSalary: true,
      useAsPaycheckBoundary: true,
      notes: 'Primary income source',
    );
    timelineItems.add(salaryItem);

    // 2. Rent/Housing (monthly, triggers rent_income_ratio)
    final rentItem = TimelineItem(
      id: newTimelineItemId(),
      label: 'Apartment Rent',
      amountMinorUnits: -150000, // -1500.00
      dayOfMonth: 1,
      type: PulseType.recurring,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      origin: 'Landlord',
      category: 'Housing',
      priority: ExpensePriority.critical,
      notes: 'Includes parking spot',
    );
    timelineItems.add(rentItem);

    // 3. Utilities - Electricity (monthly)
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Electricity',
        amountMinorUnits: -8500,
        dayOfMonth: 28,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'Vattenfall',
        category: 'Utilities',
      ),
    );

    // 4. Internet (monthly)
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Internet & Phone',
        amountMinorUnits: -5500,
        dayOfMonth: 15,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'KPN',
        category: 'Utilities',
      ),
    );

    // 5. Debt with Money Pot link
    final debtItem = TimelineItem(
      id: newTimelineItemId(),
      label: 'Student Loan Payment',
      amountMinorUnits: -50000, // -500.00 payment
      dayOfMonth: 28,
      type: PulseType.debt,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      remainingBalanceMinorUnits: 2000000,
      originalAmountMinorUnits: 3000000,
      category: 'Debt',
      moneyPotId: debtPotId,
    );
    timelineItems.add(debtItem);

    // 6. Groceries Spending Envelope with enhanced settings
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Groceries Budget',
        amountMinorUnits: -40000, // -400.00/month budget
        dayOfMonth: 1,
        type: PulseType.spendingEnvelope,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        category: 'Groceries',
        suggestedOrigins: const ['Albert Heijn', 'Jumbo', 'Lidl', 'Aldi'],
        quickAddAmounts: const [500, 1500, 2500, 5000], // 5, 15, 25, 50 euros
        useActualsForCurrentBalance: true,
        useActualsForFutureBalance: false,
      ),
    );

    // 7. Subscriptions (various frequencies)
    // Netflix - monthly
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Netflix',
        amountMinorUnits: -1599,
        dayOfMonth: 10,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'Netflix',
        category: 'Subscriptions',
        priority: ExpensePriority.optional,
      ),
    );

    // Spotify - monthly
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Spotify Family',
        amountMinorUnits: -1499,
        dayOfMonth: 5,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'Spotify',
        category: 'Subscriptions',
        priority: ExpensePriority.optional,
      ),
    );

    // Adobe Creative Cloud - YEARLY frequency demo
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Adobe Creative Cloud',
        amountMinorUnits: -59999, // -599.99/year
        dayOfMonth: 15,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 3, 1), // Started in March
        frequency: RecurrenceFrequency.yearly,
        origin: 'Adobe',
        category: 'Subscriptions',
        priority: ExpensePriority.strategic,
        notes: 'Essential for freelance work',
      ),
    );

    // 8. Gym - QUARTERLY frequency demo
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Gym Membership',
        amountMinorUnits: -8999, // -89.99/quarter
        dayOfMonth: 1,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.quarterly,
        origin: 'HealthCity',
        category: 'Gym/Fitness',
        priority: ExpensePriority.advisable,
      ),
    );

    // 9. Insurance - BIWEEKLY frequency demo
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Health Insurance',
        amountMinorUnits: -6500, // -65.00 biweekly
        dayOfMonth: 1, // Every 2 weeks from 1st
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.biweekly,
        origin: 'Zilveren Kruis',
        category: 'Insurance',
        priority: ExpensePriority.critical,
      ),
    );

    // 10. Paused item demo - Magazine subscription paused temporarily
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Magazine Subscription',
        amountMinorUnits: -1299,
        dayOfMonth: 20,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 1, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'The Economist',
        category: 'Subscriptions',
        pausedDate: DateTime.utc(2025, 6, 1), // Paused from June
        autoResumeDate: DateTime.utc(2025, 9, 1), // Resumes in September
        notes: 'Paused during summer vacation',
      ),
    );

    // 11. Item with skipped dates demo
    final cleaningItem = TimelineItem(
      id: newTimelineItemId(),
      label: 'House Cleaning',
      amountMinorUnits: -7500,
      dayOfMonth: 15,
      type: PulseType.recurring,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: RecurrenceFrequency.monthly,
      category: 'Housing',
      skippedDates: [
        DateTime.utc(2025, 4, 1), // Skipped April (vacation)
        DateTime.utc(2025, 8, 1), // Skipped August (vacation)
      ],
    );
    timelineItems.add(cleaningItem);

    // 12. Foreign currency transaction demo
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'US Software License',
        amountMinorUnits: -4600, // -46.00 EUR equivalent
        dayOfMonth: 1,
        type: PulseType.recurring,
        startDate: DateTime.utc(2025, 2, 1),
        frequency: RecurrenceFrequency.monthly,
        origin: 'JetBrains',
        category: 'Subscriptions',
        transactionCurrency: AppCurrency.usd,
        transactionAmountMinorUnits: 4999, // -49.99 USD
      ),
    );

    // 13. Freelance income (occasional)
    timelineItems.add(
      TimelineItem(
        id: newTimelineItemId(),
        label: 'Freelance Project',
        amountMinorUnits: 80000, // 800.00
        dayOfMonth: 15,
        type: PulseType.recurringIncome,
        startDate: DateTime.utc(2025, 2, 1),
        frequency: RecurrenceFrequency.quarterly,
        origin: 'Client Work',
        category: 'Freelance',
      ),
    );

    // ========== GENERATE RANDOM ITEMS TO FILL SIZE ==========

    final targetTimelineItems = (size.pulseCount / 8).clamp(15, 60).toInt();
    while (timelineItems.length < targetTimelineItems) {
      timelineItems.add(_generateRandomTimelineItem());
    }

    // ========== GENERATE PULSES ==========

    var currentMonth = DateTime.utc(end.year, end.month - 11);
    var generatedPulses = 0;

    while (generatedPulses < size.pulseCount && !currentMonth.isAfter(end)) {
      // Generate pulses from timeline items for this month
      for (final item in timelineItems) {
        if (item.shouldAppearInMonth(currentMonth)) {
          final isLastMonth =
              currentMonth.year == end.year && currentMonth.month == end.month;

          // Leave some unpaid in current month
          if (isLastMonth && _random.nextDouble() > 0.6) {
            continue;
          }

          final scheduledAmount = item.amountMinorUnits;
          final actualAmount = scheduledAmount + _randomVar(scheduledAmount);
          final scheduledDay = item.dayOfMonth;

          // Simulate some date variance
          final actualDay = scheduledDay + (_random.nextInt(5) - 2); // ±2 days
          final clampedDay = actualDay.clamp(1, 28);

          pulses.add(
            PulseEntry(
              id: newEntryId(),
              label: item.label,
              amountMinorUnits: actualAmount,
              date: DateTime.utc(
                currentMonth.year,
                currentMonth.month,
                clampedDay,
              ),
              type: item.type,
              timelineItemId: item.id,
              category: item.category,
              origin: item.origin,
              // Variance tracking
              scheduledDate: DateTime.utc(
                currentMonth.year,
                currentMonth.month,
                scheduledDay,
              ),
              scheduledAmountMinorUnits: scheduledAmount,
              // Copy multi-currency if present
              transactionCurrency: item.transactionCurrency,
              transactionAmountMinorUnits: item.transactionAmountMinorUnits,
              // Add notes occasionally
              notes: _random.nextDouble() < 0.1
                  ? 'Auto-generated sample pulse'
                  : null,
              // Sometimes override priority
              priority: _random.nextDouble() < 0.05
                  ? ExpensePriority.values[_random.nextInt(5)]
                  : null,
            ),
          );
          generatedPulses++;
        }
      }

      // Add random one-off pulses (ensure variety for insights)
      final weekendDays = _getWeekendDays(currentMonth);

      // Regular one-offs
      final oneOffsCount = _random.nextInt(5) + 3;
      for (var i = 0; i < oneOffsCount; i++) {
        final isIncome = _random.nextDouble() < 0.1;
        final category = isIncome
            ? _incomeCategories[_random.nextInt(_incomeCategories.length)]
            : _expenseCategories[_random.nextInt(_expenseCategories.length)];

        // Use some weekend days for behavioral insights
        int day;
        if (_random.nextDouble() < 0.3 && weekendDays.isNotEmpty) {
          day = weekendDays[_random.nextInt(weekendDays.length)];
        } else {
          day = _random.nextInt(28) + 1;
        }

        int amount;
        if (isIncome) {
          amount = _random.nextInt(50000) + 5000;
        } else {
          // Ensure some high-value transactions for alert insight
          if (_random.nextDouble() < 0.05) {
            amount = -(_random.nextInt(200000) + 100001); // > 1000.00
          } else {
            amount = -(_random.nextInt(15000) + 500);
          }
        }

        pulses.add(
          PulseEntry(
            id: newEntryId(),
            label: '$category purchase',
            amountMinorUnits: amount,
            date: DateTime.utc(currentMonth.year, currentMonth.month, day),
            type: isIncome ? PulseType.oneOffIncome : PulseType.oneOff,
            category: category,
            origin: _origins[_random.nextInt(_origins.length)],
          ),
        );
        generatedPulses++;
      }

      // Add some Dining expenses specifically to ensure insight triggers
      if (_random.nextDouble() < 0.7) {
        pulses.add(
          PulseEntry(
            id: newEntryId(),
            label: 'Dinner out',
            amountMinorUnits: -(_random.nextInt(5000) + 2000),
            date: DateTime.utc(
              currentMonth.year,
              currentMonth.month,
              weekendDays.isNotEmpty ? weekendDays.first : 15,
            ),
            type: PulseType.oneOff,
            category: 'Dining',
            origin: 'Restaurant De Kas',
          ),
        );
        generatedPulses++;
      }

      currentMonth = DateTime.utc(currentMonth.year, currentMonth.month + 1);
    }

    return TestDataResult(
      timelineItems: timelineItems,
      pulses: pulses,
      moneyPots: moneyPots,
    );
  }

  /// Legacy tuple-based API for backward compatibility
  @Deprecated(
    'Use generate() which returns TestDataResult including money pots',
  )
  static (List<TimelineItem>, List<PulseEntry>) generateLegacy({
    required TestDatasetSize size,
    DateTime? endDate,
  }) {
    final result = generate(size: size, endDate: endDate);
    return (result.timelineItems, result.pulses);
  }

  static int _randomVar(int amount) {
    if (amount.abs() < 1000) return 0;
    final variation = (amount.abs() * 0.05).toInt();
    if (variation == 0) return 0;
    return _random.nextInt(variation * 2) - variation;
  }

  static List<int> _getWeekendDays(DateTime month) {
    final days = <int>[];
    for (var d = 1; d <= 28; d++) {
      final date = DateTime.utc(month.year, month.month, d);
      if (date.weekday == DateTime.saturday ||
          date.weekday == DateTime.sunday) {
        days.add(d);
      }
    }
    return days;
  }

  static TimelineItem _generateRandomTimelineItem() {
    final isIncome = _random.nextDouble() < 0.15;
    final category = isIncome
        ? _incomeCategories[_random.nextInt(_incomeCategories.length)]
        : _expenseCategories[_random.nextInt(_expenseCategories.length)];

    // Pick a frequency with weighted distribution
    RecurrenceFrequency frequency;
    final freqRoll = _random.nextDouble();
    if (freqRoll < 0.7) {
      frequency = RecurrenceFrequency.monthly;
    } else if (freqRoll < 0.85) {
      frequency = RecurrenceFrequency.quarterly;
    } else if (freqRoll < 0.95) {
      frequency = RecurrenceFrequency.yearly;
    } else {
      frequency = RecurrenceFrequency.biweekly;
    }

    return TimelineItem(
      id: newTimelineItemId(),
      label: 'Regular $category',
      amountMinorUnits: isIncome
          ? (_random.nextInt(100000) + 10000)
          : -(_random.nextInt(50000) + 2000),
      dayOfMonth: _random.nextInt(28) + 1,
      type: isIncome ? PulseType.recurringIncome : PulseType.recurring,
      startDate: DateTime.utc(2025, 1, 1),
      frequency: frequency,
      category: category,
      origin: _origins[_random.nextInt(_origins.length)],
    );
  }
}
