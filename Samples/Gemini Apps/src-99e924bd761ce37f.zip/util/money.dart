import 'package:expense_stalker_mobile/src/models/currency.dart';

/// Maximum minor units supported (100 trillion).
/// Supports high-denomination currencies like VND where 100 billion VND
/// stored as minor units (with ratio 1) would be 100,000,000,000.
const int maxMinorUnits = 100000000000000; // 100 trillion

/// Safely adds two monetary values with overflow protection.
/// Clamps the result to [maxMinorUnits] to prevent integer overflow.
int safeAddBalance(int a, int b) {
  if (b > 0 && a > maxMinorUnits - b) return maxMinorUnits;
  if (b < 0 && a < -maxMinorUnits - b) return -maxMinorUnits;
  return a + b;
}

/// Formats a monetary amount from minor units to a display string.
///
/// Uses currency metadata to determine decimal places and subunit ratio.
/// For currencies with 2 decimal places (USD, EUR, GBP): 1250 → "$12.50"
/// For currencies with 0 decimal places (JPY, VND): 1250 → "¥1,250"
/// For currencies with 3 decimal places (KWD): 1250 → "KD 1.250"
///
/// [minorUnits] - Amount in smallest currency unit (e.g., cents for USD)
/// [currency] - The currency to format for
/// [showDecimals] - Whether to show decimal places (default: true)
String formatMoney(
  int minorUnits,
  AppCurrency currency, {
  bool showDecimals = true,
}) {
  final info = getCurrencyInfo(currency);
  final abs = minorUnits.abs();
  final sign = minorUnits < 0 ? '-' : '';
  final symbol = info.symbol;

  // For zero-decimal currencies, minor units ARE major units
  if (info.decimalDigits == 0 || !showDecimals) {
    final major = abs ~/ info.subunitRatio;
    final formatted = _formatWithGrouping(major, info.groupSeparator);
    return info.symbolPosition == SymbolPosition.before
        ? '$sign$symbol$formatted'
        : '$sign$formatted$symbol';
  }

  // For currencies with decimals
  final major = abs ~/ info.subunitRatio;
  final minor = abs % info.subunitRatio;
  final majorFormatted = _formatWithGrouping(major, info.groupSeparator);
  final minorFormatted = minor.toString().padLeft(info.decimalDigits, '0');

  final amount = '$majorFormatted${info.decimalSeparator}$minorFormatted';
  return info.symbolPosition == SymbolPosition.before
      ? '$sign$symbol$amount'
      : '$sign$amount$symbol';
}

/// Formats a number with thousand separators.
String _formatWithGrouping(int value, String separator) {
  final str = value.toString();
  if (str.length <= 3) return str;

  final buffer = StringBuffer();
  var count = 0;
  for (var i = str.length - 1; i >= 0; i--) {
    if (count > 0 && count % 3 == 0) {
      buffer.write(separator);
    }
    buffer.write(str[i]);
    count++;
  }
  return buffer.toString().split('').reversed.join();
}

/// Formats money without decimal places (whole units only).
String formatMoneyWhole(int minorUnits, AppCurrency currency) {
  return formatMoney(minorUnits, currency, showDecimals: false);
}

/// Parses a money string to minor units using currency metadata.
///
/// Handles:
/// - Currency symbols (€, $, £, etc.)
/// - Comma or period as decimal separator
/// - Thousand separators
///
/// Returns null if parsing fails or value exceeds bounds.
int? tryParseMoney(String input, AppCurrency currency) {
  final info = getCurrencyInfo(currency);
  return tryParseMoneyWithRatio(input, info.subunitRatio);
}

/// Parses a money string to minor units with a specific subunit ratio.
///
/// [subunitRatio] - How many minor units per major unit (100 for cents, 1 for yen)
int? tryParseMoneyWithRatio(String input, int subunitRatio) {
  final trimmed = input.trim();
  if (trimmed.isEmpty) return null;

  // Remove common currency symbols
  var normalized = trimmed
      .replaceAll('€', '')
      .replaceAll(r'$', '')
      .replaceAll('£', '')
      .replaceAll('¥', '')
      .replaceAll('₫', '')
      .replaceAll('₩', '')
      .replaceAll('₹', '')
      .replaceAll('R\$', '')
      .replaceAll('د.ك', '')
      .trim();

  // Handle thousand separators: remove them if they're clearly grouping
  // This is tricky because "," can be decimal or thousand separator
  // Heuristic: if there's both "," and ".", the last one is decimal
  final hasComma = normalized.contains(',');
  final hasPeriod = normalized.contains('.');

  if (hasComma && hasPeriod) {
    // Both present: last one is decimal separator
    final lastComma = normalized.lastIndexOf(',');
    final lastPeriod = normalized.lastIndexOf('.');
    if (lastComma > lastPeriod) {
      // Comma is decimal separator (European: 1.234,56)
      normalized = normalized.replaceAll('.', '').replaceAll(',', '.');
    } else {
      // Period is decimal separator (US: 1,234.56)
      normalized = normalized.replaceAll(',', '');
    }
  } else if (hasComma) {
    // Only comma: could be decimal (European) or thousand separator
    // If exactly 3 digits after comma, likely thousand separator
    // Otherwise, treat as decimal
    final parts = normalized.split(',');
    if (parts.length == 2 && parts[1].length == 3 && !parts[1].contains('.')) {
      // Likely thousand separator: 1,234
      normalized = normalized.replaceAll(',', '');
    } else {
      // Likely decimal separator: 12,50
      normalized = normalized.replaceAll(',', '.');
    }
  }
  // If only period, it's either decimal or thousand separator
  // double.tryParse handles "1234.56" correctly

  final value = double.tryParse(normalized);
  if (value == null) return null;

  // Calculate minor units
  final minorUnits = (value * subunitRatio).round();

  // Validate bounds
  if (minorUnits.abs() > maxMinorUnits) return null;

  return minorUnits;
}

/// Rounds [minorUnits] UP to the nearest [increment] (also in minor units).
/// Example: minorUnits=1200 ($12), increment=500 ($5). Result=1500 ($15).
int roundUpToIncrement(int minorUnits, int increment) {
  if (increment <= 1) return minorUnits;
  if (minorUnits == 0) return 0;

  // Round away from zero (conservative for expenses)
  final sign = minorUnits < 0 ? -1 : 1;
  final absv = minorUnits.abs();
  final remainder = absv % increment;
  if (remainder == 0) return minorUnits;

  return sign * (absv + (increment - remainder));
}

// =============================================================================
// Legacy API - Deprecated but maintained for backward compatibility
// =============================================================================

/// @Deprecated: Use [formatMoney] instead.
/// Formats money assuming 100 subunits per unit (cents).
String formatMoneyFromCents(
  int cents,
  AppCurrency currency, {
  bool showCents = true,
}) {
  return formatMoney(cents, currency, showDecimals: showCents);
}

/// @Deprecated: Use [formatMoneyWhole] instead.
String formatMoneyWholeFromCents(int cents, AppCurrency currency) {
  return formatMoneyWhole(cents, currency);
}

/// @Deprecated: Use [tryParseMoney] instead.
/// Parses money assuming 100 subunits per unit (cents).
int? tryParseMoneyToCents(String input) {
  return tryParseMoneyWithRatio(input, 100);
}

/// @Deprecated: Use [formatMoney] with AppCurrency.eur instead.
String formatEuroFromCents(int cents) => formatMoney(cents, AppCurrency.eur);

/// @Deprecated: Use [tryParseMoney] with AppCurrency.eur instead.
int? tryParseEuroToCents(String input) => tryParseMoneyToCents(input);
