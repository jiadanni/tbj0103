import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/lru_cache.dart';
import 'package:expense_stalker_mobile/src/util/account_icons.dart';

// Icon lookup cache: (label, type) -> IconData
// LRU cache with max 100 entries to prevent unbounded memory growth
final LruCache<(String, PulseType), IconData> _iconCache = LruCache(100);

/// Generate acronym from pulse label
String generateAcronym(String label) {
  final words = label
      .trim()
      .split(RegExp(r'[\s\-_]+'))
      .where((word) => word.isNotEmpty)
      .toList();

  if (words.isEmpty) return '??';
  if (words.length == 1) {
    // Single word: take first 2-3 letters
    return words[0].length <= 2
        ? words[0].toUpperCase()
        : words[0].substring(0, 2).toUpperCase();
  }

  // Multiple words: take first letter of each (max 3)
  return words.take(3).map((w) => w[0].toUpperCase()).join();
}

/// Get icon for pulse based on label keywords and pulse type
IconData getPulseIcon(
  String label, {
  required PulseType type,
  Map<String, int>? categoryIcons,
}) {
  if (categoryIcons != null && categoryIcons.containsKey(label)) {
    return AccountIcons.getIcon(categoryIcons[label]);
  }

  final cacheKey = (label, type);
  final cached = _iconCache.get(cacheKey);
  if (cached != null) return cached;

  final lower = label.toLowerCase();
  final isIncome = type.isIncomeType;

  IconData cacheAndReturn(IconData icon) {
    _iconCache.put(cacheKey, icon);
    return icon;
  }

  // Housing & Utilities
  if (lower.contains('rent') || lower.contains('mortgage')) {
    return cacheAndReturn(Icons.home);
  }
  if (lower.contains('electric') || lower.contains('power')) {
    return cacheAndReturn(Icons.bolt);
  }
  if (lower.contains('water')) {
    return cacheAndReturn(Icons.water_drop);
  }
  if (lower.contains('gas') || lower.contains('heating')) {
    return cacheAndReturn(Icons.local_fire_department);
  }
  if (lower.contains('internet') ||
      lower.contains('wifi') ||
      lower.contains('broadband')) {
    return cacheAndReturn(Icons.wifi);
  }
  if (lower.contains('phone') ||
      lower.contains('mobile') ||
      lower.contains('cellular')) {
    return cacheAndReturn(Icons.phone_android);
  }

  // Transportation
  if (lower.contains('car') ||
      lower.contains('vehicle') ||
      lower.contains('auto')) {
    return cacheAndReturn(Icons.directions_car);
  }
  if (lower.contains('fuel') ||
      lower.contains('gas') ||
      lower.contains('petrol')) {
    return cacheAndReturn(Icons.local_gas_station);
  }
  if (lower.contains('bike') || lower.contains('bicycle')) {
    return cacheAndReturn(Icons.pedal_bike);
  }
  if (lower.contains('train') ||
      lower.contains('metro') ||
      lower.contains('subway')) {
    return cacheAndReturn(Icons.train);
  }
  if (lower.contains('bus')) {
    return cacheAndReturn(Icons.directions_bus);
  }
  if (lower.contains('taxi') ||
      lower.contains('uber') ||
      lower.contains('lyft')) {
    return cacheAndReturn(Icons.local_taxi);
  }

  // Food & Groceries
  if (lower.contains('food') ||
      lower.contains('grocery') ||
      lower.contains('groceries') ||
      lower.contains('supermarket')) {
    return cacheAndReturn(Icons.shopping_cart);
  }
  if (lower.contains('restaurant') ||
      lower.contains('dining') ||
      lower.contains('meal')) {
    return cacheAndReturn(Icons.restaurant);
  }
  if (lower.contains('coffee') || lower.contains('cafe')) {
    return cacheAndReturn(Icons.coffee);
  }

  // Health & Fitness
  if (lower.contains('gym') ||
      lower.contains('fitness') ||
      lower.contains('sport')) {
    return cacheAndReturn(Icons.fitness_center);
  }
  if (lower.contains('doctor') ||
      lower.contains('medical') ||
      lower.contains('health')) {
    return cacheAndReturn(Icons.medical_services);
  }
  if (lower.contains('pharmacy') ||
      lower.contains('medicine') ||
      lower.contains('prescription')) {
    return cacheAndReturn(Icons.medication);
  }
  if (lower.contains('dental') || lower.contains('dentist')) {
    return cacheAndReturn(Icons.medication_liquid);
  }

  // Insurance
  if (lower.contains('insurance')) {
    return cacheAndReturn(Icons.shield);
  }

  // Entertainment & Subscriptions
  if (lower.contains('netflix') ||
      lower.contains('streaming') ||
      lower.contains('spotify')) {
    return cacheAndReturn(Icons.play_circle);
  }
  if (lower.contains('game') || lower.contains('gaming')) {
    return cacheAndReturn(Icons.sports_esports);
  }
  if (lower.contains('music')) {
    return cacheAndReturn(Icons.music_note);
  }
  if (lower.contains('movie') || lower.contains('cinema')) {
    return cacheAndReturn(Icons.movie);
  }

  // Shopping
  if (lower.contains('clothes') ||
      lower.contains('clothing') ||
      lower.contains('fashion')) {
    return cacheAndReturn(Icons.checkroom);
  }
  if (lower.contains('shopping')) {
    return cacheAndReturn(Icons.shopping_bag);
  }

  // Education
  if (lower.contains('school') ||
      lower.contains('tuition') ||
      lower.contains('education')) {
    return cacheAndReturn(Icons.school);
  }
  if (lower.contains('book')) {
    return cacheAndReturn(Icons.menu_book);
  }

  // Financial
  if (lower.contains('salary') ||
      lower.contains('wage') ||
      lower.contains('paycheck') ||
      lower.contains('income')) {
    return cacheAndReturn(Icons.account_balance_wallet);
  }
  if (lower.contains('loan') ||
      lower.contains('debt') ||
      lower.contains('credit')) {
    return cacheAndReturn(Icons.credit_card);
  }
  if (lower.contains('savings') || lower.contains('investment')) {
    return cacheAndReturn(Icons.savings);
  }
  if (lower.contains('tax')) {
    return cacheAndReturn(Icons.receipt_long);
  }
  if (lower.contains('bonus')) {
    return cacheAndReturn(Icons.card_giftcard);
  }

  // Personal Care
  if (lower.contains('haircut') ||
      lower.contains('salon') ||
      lower.contains('barber')) {
    return cacheAndReturn(Icons.content_cut);
  }

  // Pets
  if (lower.contains('pet') ||
      lower.contains('vet') ||
      lower.contains('dog') ||
      lower.contains('cat')) {
    return cacheAndReturn(Icons.pets);
  }

  // Travel
  if (lower.contains('travel') ||
      lower.contains('vacation') ||
      lower.contains('hotel')) {
    return cacheAndReturn(Icons.flight);
  }

  // Default icons based on pulse type
  if (isIncome) {
    // Income-specific default icons based on type
    if (type == PulseType.recurringIncome) {
      return cacheAndReturn(Icons.trending_up);
    } else if (type == PulseType.oneOffIncome) {
      return cacheAndReturn(Icons.attach_money);
    }
  }

  return cacheAndReturn(Icons.remove_circle_outline);
}
