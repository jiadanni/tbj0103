/// Input validation constants and utilities.
///
/// Defines maximum lengths and bounds for user input to prevent
/// UI breakage, memory issues, and overflow errors.
library;

import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';

/// Maximum length for item labels (e.g., timeline items, pulse entries).
///
/// Prevents UI text overflow and database bloat.
const int kMaxLabelLength = AppConstants.maxLabelLength;

/// Maximum length for notes fields.
///
/// Prevents memory exhaustion from extremely long text.
const int kMaxNotesLength = AppConstants.maxNotesLength;

/// Maximum amount in minor units.
///
/// Supports high-denomination currencies like VND (100 billion VND property).
/// Uses the global max from money.dart for consistency.
const int kMaxAmountMinorUnits = maxMinorUnits;

/// Minimum amount in minor units (at least 1 unit).
///
/// For currencies with subunits (USD, EUR), this is 1 cent.
/// For currencies without subunits (JPY, VND), this is 1 unit.
const int kMinAmountMinorUnits = 1;

/// @Deprecated: Use [kMaxAmountMinorUnits] instead.
const int kMaxAmountCents = 9999999;

/// @Deprecated: Use [kMinAmountMinorUnits] instead.
const int kMinAmountCents = 1;

/// Validates a label string.
///
/// Returns null if valid, or an error message if invalid.
String? validateLabel(String? label, String fieldName) {
  if (label == null || label.trim().isEmpty) {
    return '$fieldName is required';
  }
  if (label.length > kMaxLabelLength) {
    return '$fieldName must be $kMaxLabelLength characters or less';
  }
  return null;
}

/// Validates a notes string.
///
/// Returns null if valid, or an error message if invalid.
String? validateNotes(String? notes) {
  if (notes == null || notes.trim().isEmpty) {
    return null; // Notes are optional
  }
  if (notes.length > kMaxNotesLength) {
    return 'Notes must be $kMaxNotesLength characters or less';
  }
  return null;
}

/// Validates an amount in minor units.
///
/// Returns null if valid, or an error message if invalid.
/// Note: This validates the absolute amount - sign is handled by PulseType.
String? validateAmountMinorUnits(
  int? amountMinorUnits, {
  bool allowZero = false,
}) {
  if (amountMinorUnits == null) {
    return 'Amount is required';
  }
  // Check for negative amounts explicitly (amountMinorUnits should be positive;
  // the sign is determined by PulseType, not the amount value)
  if (amountMinorUnits < 0) {
    return 'Amount cannot be negative';
  }
  if (!allowZero && amountMinorUnits < kMinAmountMinorUnits) {
    return 'Amount must be greater than zero';
  }
  if (amountMinorUnits > kMaxAmountMinorUnits) {
    return 'Amount exceeds maximum allowed value';
  }
  return null;
}

/// @Deprecated: Use [validateAmountMinorUnits] instead.
String? validateAmountCents(int? amountMinorUnits, {bool allowZero = false}) {
  return validateAmountMinorUnits(amountMinorUnits, allowZero: allowZero);
}
