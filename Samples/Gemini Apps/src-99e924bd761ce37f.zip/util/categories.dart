/// Predefined category suggestions for expenses and income.
///
/// These are suggestions to help users organize their pulse.
/// Users can also enter custom categories freely.
library;

import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

/// Common expense categories
const expenseCategories = <String>[
  'Housing',
  'Utilities',
  'Groceries',
  'Dining',
  'Transportation',
  'Insurance',
  'Health',
  'Entertainment',
  'Shopping',
  'Education',
  'Personal Care',
  'Pet Care',
  'Gym/Fitness',
  'Subscriptions',
  'Office Supplies',
  'Gifts',
  'Travel',
  'Repairs',
  'Fuel',
  'Phone/Internet',
];

/// Common income categories
const incomeCategories = <String>[
  'Salary',
  'Freelance',
  'Bonus',
  'Investment',
  'Refund',
  'Gift',
  'Side Gig',
  'Dividend',
  'Rental',
  'Business',
];

/// Expense subcategory suggestions
const expenseSubcategories = <String, List<String>>{
  'Housing': [
    'Rent',
    'Mortgage',
    'Property Tax',
    'HOA',
    'Repairs',
    'Furniture',
  ],
  'Utilities': ['Electric', 'Water', 'Gas', 'Trash', 'Sewer'],
  'Groceries': ['Supermarket', 'Market', 'Costco', 'Convenience Store'],
  'Dining': ['Restaurant', 'Fast Food', 'Coffee', 'Delivery', 'Bar', 'Snacks'],
  'Transportation': [
    'Public Transit',
    'Taxi/Uber',
    'Auto Payment',
    'Parking',
    'Tolls',
  ],
  'Insurance': ['Health', 'Auto', 'Home', 'Life', 'Disability'],
  'Health': ['Doctor', 'Dentist', 'Pharmacy', 'Vision', 'Therapy'],
  'Entertainment': [
    'Movies',
    'Games',
    'Concerts',
    'Streaming',
    'Hobbies',
    'Events',
  ],
  'Shopping': ['Clothing', 'Electronics', 'Home Goods', 'Shoes', 'Accessories'],
  'Education': ['Tuition', 'Books', 'Courses', 'Supplies', 'Loan Payment'],
  'Personal Care': ['Haircuts', 'Cosmetics', 'Spa', 'Massage', 'Nails'],
  'Pet Care': ['Food', 'Vet', 'Toys', 'Grooming', 'Insurance'],
  'Gym/Fitness': ['Membership', 'Classes', 'Equipment', 'Supplements'],
  'Subscriptions': ['Streaming', 'Software', 'News', 'Music', 'Cloud Storage'],
  'Office Supplies': ['Paper', 'Ink', 'Pens', 'Equipment', 'Furniture'],
  'Gifts': ['Birthday', 'Holiday', 'Wedding', 'Baby', 'Charity'],
  'Travel': ['Flights', 'Hotel', 'Car Rental', 'Tours', 'Vacation'],
  'Repairs': ['Home', 'Auto', 'Appliance', 'Electronics'],
  'Fuel': ['Gas', 'Diesel', 'Electric Charging'],
  'Phone/Internet': ['Mobile', 'Broadband', 'Landline', 'Cable'],
};

/// Income subcategory suggestions
const incomeSubcategories = <String, List<String>>{
  'Salary': ['Paycheck', 'Advance', 'Reimbursement'],
  'Freelance': ['Contract', 'Project', 'Retainer', 'Upwork', 'Fiverr'],
  'Bonus': ['Performance', 'Holiday', 'Signing', 'Referral'],
  'Investment': ['Capital Gains', 'Interest', 'Crypto', 'Real Estate'],
  'Refund': ['Tax', 'Purchase', 'Deposit'],
  'Gift': ['Birthday', 'Holiday', 'Wedding'],
  'Side Gig': ['Uber/Lyft', 'DoorDash', 'Etsy', 'Consulting'],
  'Dividend': ['Stocks', 'Mutual Funds', 'ETFs'],
  'Rental': ['Apartment', 'House', 'Room', 'Garage'],
  'Business': ['Sales', 'Services', 'Licensing'],
};

/// Get category suggestions for a given pulse type
///
/// Returns appropriate category suggestions based on whether the pulse
/// is an income or expense type, and the current [CategoryPresetMode].
List<String> getCategorySuggestions({
  required bool isIncome,
  required CategoryPresetMode mode,
  List<String> userCategories = const [],
}) {
  final presets = isIncome ? incomeCategories : expenseCategories;

  switch (mode) {
    case CategoryPresetMode.defaultPresets:
      return presets;
    case CategoryPresetMode.customOnly:
      return userCategories;
    case CategoryPresetMode.both:
      // Merge and deduplicate
      final all = <String>{...presets, ...userCategories};
      return all.toList()..sort();
  }
}

/// Get subcategory suggestions for a given category
///
/// Returns appropriate subcategory suggestions based on whether the pulse
/// is an income or expense type.
List<String> getSubcategorySuggestions({
  required String category,
  required bool isIncome,
}) {
  final Map<String, List<String>> lookup =
      isIncome ? incomeSubcategories : expenseSubcategories;
  return lookup[category] ?? [];
}

/// Get all available categories
List<String> getAllCategories() {
  return [...expenseCategories, ...incomeCategories];
}

/// Check if a category is from a predefined list
bool isPredefinedCategory(String category) {
  return expenseCategories.contains(category) ||
      incomeCategories.contains(category);
}

/// Default priority mapping for expense categories.
///
/// Users can override these on a per-item basis via [TimelineItem.priority].
const Map<String, ExpensePriority> defaultCategoryPriorities = {
  // Critical - essential for living
  'Housing': ExpensePriority.critical,
  'Utilities': ExpensePriority.critical,
  'Insurance': ExpensePriority.critical,
  'Health': ExpensePriority.critical,
  'Phone/Internet': ExpensePriority.critical,

  // Advisable - important for financial health and daily life
  'Groceries': ExpensePriority.advisable,
  'Transportation': ExpensePriority.advisable,
  'Fuel': ExpensePriority.advisable,
  'Education': ExpensePriority.advisable,
  'Repairs': ExpensePriority.advisable,

  // Optional - discretionary spending
  'Entertainment': ExpensePriority.optional,
  'Shopping': ExpensePriority.optional,
  'Dining': ExpensePriority.optional,
  'Subscriptions': ExpensePriority.optional,
  'Gifts': ExpensePriority.optional,
  'Travel': ExpensePriority.optional,
  'Gym/Fitness': ExpensePriority.optional,
  'Personal Care': ExpensePriority.optional,
  'Pet Care': ExpensePriority.optional,
  'Office Supplies': ExpensePriority.optional,
};

/// Returns the default priority for a category and pulse type.
///
/// Priority logic:
/// - Debt items default to [ExpensePriority.advisable] (paying off debt is important)
/// - Income items default to [ExpensePriority.critical] (must track)
/// - Expense items use category mapping, defaulting to advisable if unknown
ExpensePriority getDefaultPriority(String? category, PulseType type) {
  // Debt items are advisable by default (paying off debt is important)
  if (type == PulseType.debt) return ExpensePriority.advisable;

  // Income items are critical to track
  if (type == PulseType.recurringIncome || type == PulseType.oneOffIncome) {
    return ExpensePriority.critical;
  }

  if (category == null) return ExpensePriority.advisable;
  return defaultCategoryPriorities[category] ?? ExpensePriority.advisable;
}
