import 'dart:convert';
import 'package:cryptography/cryptography.dart';

/// Utility for generating and validating data integrity checksums.
///
/// Uses SHA-256 to create a hash of the data content, which can be used
/// to detect corruption during import/export operations.
class ChecksumUtil {
  const ChecksumUtil._();

  /// Generates a SHA-256 checksum for the given data.
  ///
  /// The [data] map is first serialized to a canonical JSON string (sorted keys)
  /// before hashing to ensure consistent checksums regardless of key order.
  static Future<String> generateChecksum(Map<String, dynamic> data) async {
    // Create a canonical representation by sorting keys and encoding
    final canonicalJson = _canonicalEncode(data);
    final bytes = utf8.encode(canonicalJson);

    final algorithm = Sha256();
    final hash = await algorithm.hash(bytes);

    // Return as hex string
    return hash.bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// Validates a checksum against the provided data.
  ///
  /// Returns true if the checksum matches, false otherwise.
  static Future<bool> validateChecksum(
    Map<String, dynamic> data,
    String expectedChecksum,
  ) async {
    final actualChecksum = await generateChecksum(data);
    return actualChecksum == expectedChecksum;
  }

  /// Creates a canonical JSON string with sorted keys for consistent hashing.
  static String _canonicalEncode(dynamic value) {
    if (value is Map<String, dynamic>) {
      final sortedKeys = value.keys.toList()..sort();
      final pairs = sortedKeys.map((key) {
        final encodedValue = _canonicalEncode(value[key]);
        return '"${_escapeString(key)}":$encodedValue';
      }).join(',');
      return '{$pairs}';
    } else if (value is List) {
      final items = value.map(_canonicalEncode).join(',');
      return '[$items]';
    } else if (value is String) {
      return '"${_escapeString(value)}"';
    } else if (value is num || value is bool) {
      return value.toString();
    } else if (value == null) {
      return 'null';
    } else {
      // Fallback for other types
      return '"${_escapeString(value.toString())}"';
    }
  }

  /// Escapes special characters in JSON strings.
  static String _escapeString(String s) {
    return s
        .replaceAll('\\', '\\\\')
        .replaceAll('"', '\\"')
        .replaceAll('\n', '\\n')
        .replaceAll('\r', '\\r')
        .replaceAll('\t', '\\t');
  }
}
