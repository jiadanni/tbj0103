/// Application-wide constants for the Expense Stalker app
class AppConstants {
  // Animation Durations
  static const Duration animationFast = Duration(milliseconds: 150);
  static const Duration animationNormal = Duration(milliseconds: 200);
  static const Duration animationSlow = Duration(milliseconds: 300);
  static const Duration animationPageTransition = Duration(milliseconds: 400);

  // SnackBar Durations
  static const Duration snackBarShort = Duration(seconds: 2);
  static const Duration snackBarNormal = Duration(seconds: 3);
  static const Duration snackBarLong = Duration(seconds: 5);

  // Layout limits
  static const int maxLabelLength = 100;
  static const int maxNotesLength = 500;
  static const int maxAmountLength = 9;
  static const int maxBalanceLength = 10;
  static const int maxAccountNameLength = 20;
  static const int minAccountNameLength = 1;

  // Debounce
  static const Duration saveDebounceDuration = Duration(seconds: 2);

  // Spacing
  static const double paddingXSmall = 4.0;
  static const double paddingSmall = 7.0; // was 8
  static const double paddingNormal = 11.0; // was 12
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;

  // Border radius
  static const double radiusXSmall = 4.0;
  static const double radiusSmall = 8.0;
  static const double radiusMedium = 12.0;
  static const double radiusButton = 12.0;
  static const double radiusLarge = 16.0;
  static const double radiusXLarge = 20.0;
  static const double radiusIconBox = 14.0;
  static const double radiusSheetTop = 28.0;
  static const double radiusDialog = 28.0;
  static const double radiusHero = 24.0;
  static const double radiusInlineCard = 16.0;

  // Stagger animation
  static const Duration staggerItemDelay = Duration(milliseconds: 30);
  static const Duration staggerMaxDelay = Duration(milliseconds: 400);
  static const Duration staggerItemDuration = Duration(milliseconds: 250);

  // Interaction Thresholds
  static const double scrollThresholdNormal = 200.0;
  static const double pinchScaleThreshold = 0.92;
  static const double opacityPast = 0.62;

  // Specific Layout Heights/Sizes
  static const double appBarExtendedHeight = 96.0;
  static const double dialogIconSize = 44.0;
  static const int pageSizeDefault = 50;
  static const double buttonHeightPrimary = 56.0;
  static const double buttonHeightSecondary = 48.0;

  // Insights Auto-Scroll
  static const double autoScrollStep = 500.0;
  static const Duration autoScrollResumeDelay = Duration(seconds: 2);
  static const int infiniteScrollItemCount = 10000;

  // Balance Projection
  static const int defaultProjectionMonths = 12;
  static const int chartMaxMonths = 24;
  static const int loadMoreMonths = 12;

  AppConstants._();
}
