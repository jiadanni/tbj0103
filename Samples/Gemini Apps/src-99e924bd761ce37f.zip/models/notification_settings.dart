import 'package:equatable/equatable.dart';

/// Immutable model for notification preferences.
///
/// Stores all settings related to push notifications including daily alerts,
/// weekly alerts, weekly summaries, and week configuration.
class NotificationSettings extends Equatable {
  /// Master toggle for all notifications
  final bool notificationsEnabled;

  // Daily Alert Settings
  /// Whether daily alerts are enabled
  final bool dailyAlertEnabled;

  /// Hour for daily alert (0-23)
  final int dailyAlertHour;

  /// Minute for daily alert (0-59)
  final int dailyAlertMinute;

  // Weekly Alert Settings
  /// Whether weekly alerts are enabled (start of week reminder)
  final bool weeklyAlertEnabled;

  /// Hour for weekly alert (0-23)
  final int weeklyAlertHour;

  /// Minute for weekly alert (0-59)
  final int weeklyAlertMinute;

  // Weekly Summary Settings
  /// Whether weekly summaries are enabled (end of week summary)
  final bool weeklySummaryEnabled;

  /// Hour for weekly summary (0-23)
  final int weeklySummaryHour;

  /// Minute for weekly summary (0-59)
  final int weeklySummaryMinute;

  // Week Configuration
  /// First day of the week (1=Monday, 2=Tuesday, ..., 7=Sunday per ISO 8601)
  final int weekStartDay;

  const NotificationSettings({
    this.notificationsEnabled = false,
    this.dailyAlertEnabled = false,
    this.dailyAlertHour = 9,
    this.dailyAlertMinute = 0,
    this.weeklyAlertEnabled = false,
    this.weeklyAlertHour = 9,
    this.weeklyAlertMinute = 0,
    this.weeklySummaryEnabled = false,
    this.weeklySummaryHour = 18,
    this.weeklySummaryMinute = 0,
    this.weekStartDay = 1, // Monday by default (ISO 8601)
  })  : assert(dailyAlertHour >= 0 && dailyAlertHour <= 23),
        assert(dailyAlertMinute >= 0 && dailyAlertMinute <= 59),
        assert(weeklyAlertHour >= 0 && weeklyAlertHour <= 23),
        assert(weeklyAlertMinute >= 0 && weeklyAlertMinute <= 59),
        assert(weeklySummaryHour >= 0 && weeklySummaryHour <= 23),
        assert(weeklySummaryMinute >= 0 && weeklySummaryMinute <= 59),
        assert(weekStartDay >= 1 && weekStartDay <= 7);

  /// Create a copy with modified fields
  NotificationSettings copyWith({
    bool? notificationsEnabled,
    bool? dailyAlertEnabled,
    int? dailyAlertHour,
    int? dailyAlertMinute,
    bool? weeklyAlertEnabled,
    int? weeklyAlertHour,
    int? weeklyAlertMinute,
    bool? weeklySummaryEnabled,
    int? weeklySummaryHour,
    int? weeklySummaryMinute,
    int? weekStartDay,
  }) {
    return NotificationSettings(
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      dailyAlertEnabled: dailyAlertEnabled ?? this.dailyAlertEnabled,
      dailyAlertHour: dailyAlertHour ?? this.dailyAlertHour,
      dailyAlertMinute: dailyAlertMinute ?? this.dailyAlertMinute,
      weeklyAlertEnabled: weeklyAlertEnabled ?? this.weeklyAlertEnabled,
      weeklyAlertHour: weeklyAlertHour ?? this.weeklyAlertHour,
      weeklyAlertMinute: weeklyAlertMinute ?? this.weeklyAlertMinute,
      weeklySummaryEnabled: weeklySummaryEnabled ?? this.weeklySummaryEnabled,
      weeklySummaryHour: weeklySummaryHour ?? this.weeklySummaryHour,
      weeklySummaryMinute: weeklySummaryMinute ?? this.weeklySummaryMinute,
      weekStartDay: weekStartDay ?? this.weekStartDay,
    );
  }

  /// Convert to JSON for persistence
  Map<String, dynamic> toJson() {
    return {
      'notificationsEnabled': notificationsEnabled,
      'dailyAlertEnabled': dailyAlertEnabled,
      'dailyAlertHour': dailyAlertHour,
      'dailyAlertMinute': dailyAlertMinute,
      'weeklyAlertEnabled': weeklyAlertEnabled,
      'weeklyAlertHour': weeklyAlertHour,
      'weeklyAlertMinute': weeklyAlertMinute,
      'weeklySummaryEnabled': weeklySummaryEnabled,
      'weeklySummaryHour': weeklySummaryHour,
      'weeklySummaryMinute': weeklySummaryMinute,
      'weekStartDay': weekStartDay,
    };
  }

  /// Create from JSON
  factory NotificationSettings.fromJson(Map<String, dynamic> json) {
    return NotificationSettings(
      notificationsEnabled: json['notificationsEnabled'] as bool? ?? false,
      dailyAlertEnabled: json['dailyAlertEnabled'] as bool? ?? false,
      dailyAlertHour: json['dailyAlertHour'] as int? ?? 9,
      dailyAlertMinute: json['dailyAlertMinute'] as int? ?? 0,
      weeklyAlertEnabled: json['weeklyAlertEnabled'] as bool? ?? false,
      weeklyAlertHour: json['weeklyAlertHour'] as int? ?? 9,
      weeklyAlertMinute: json['weeklyAlertMinute'] as int? ?? 0,
      weeklySummaryEnabled: json['weeklySummaryEnabled'] as bool? ?? false,
      weeklySummaryHour: json['weeklySummaryHour'] as int? ?? 18,
      weeklySummaryMinute: json['weeklySummaryMinute'] as int? ?? 0,
      weekStartDay: json['weekStartDay'] as int? ?? 1,
    );
  }

  @override
  List<Object?> get props => [
        notificationsEnabled,
        dailyAlertEnabled,
        dailyAlertHour,
        dailyAlertMinute,
        weeklyAlertEnabled,
        weeklyAlertHour,
        weeklyAlertMinute,
        weeklySummaryEnabled,
        weeklySummaryHour,
        weeklySummaryMinute,
        weekStartDay,
      ];
}
