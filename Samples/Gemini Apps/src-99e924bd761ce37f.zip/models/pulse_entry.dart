import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

enum PulseType {
  recurring,
  recurringIncome,
  debt,
  oneOff,
  oneOffIncome,
  spendingEnvelope,
}

extension PulseTypeExtension on PulseType {
  /// Returns a basic label for this pulse type.
  ///
  /// Note: For preset-aware labels (e.g., "Spending Budget" vs "Spending Bill"),
  /// use [Terminology.pulseTypeLabel] instead.
  String get label {
    switch (this) {
      case PulseType.recurring:
        return 'Recurring Expense';
      case PulseType.recurringIncome:
        return 'Recurring Income';
      case PulseType.debt:
        return 'Debt Payment';
      case PulseType.oneOff:
        return 'One-time Expense';
      case PulseType.oneOffIncome:
        return 'One-time Income';
      case PulseType.spendingEnvelope:
        return 'Spending Envelope';
    }
  }

  /// Returns true if this pulse type represents income (positive cash flow)
  bool get isIncomeType {
    return this == PulseType.recurringIncome || this == PulseType.oneOffIncome;
  }
}

class PulseEntry extends Equatable {
  const PulseEntry({
    required this.id,
    required this.label,
    required this.amountMinorUnits,
    required this.date,
    required this.type,
    this.timelineItemId,
    this.notes,
    this.category,
    this.subcategory,
    this.origin,
    this.scheduledDate,
    this.scheduledAmountMinorUnits,
    this.moneyPotId,
    this.transactionCurrency,
    this.transactionAmountMinorUnits,
    this.exchangeRate,
    this.priority,
    this.source = PulseSource.manual,
    this.rawImportDescription,
    this.categorizationConfidence,
    this.importReference,
    this.importMetadata,
    this.transferPairId,
    this.isInternalTransfer = false,
    this.runningBalanceCents,
  });

  final EntryId id;
  final String label;
  final int amountMinorUnits;
  final DateTime date;
  final PulseType type;
  final TimelineItemId? timelineItemId;
  final String? notes;

  /// Running balance as reported by the bank at the time of this transaction.
  /// (Optional, only for bank imports).
  final int? runningBalanceCents;

  /// Whether this pulse represents income.
  bool get isIncome => type.isIncomeType;

  /// The date this pulse occurred (alias for date).
  DateTime get paidDate => date;

  /// The amount in major units (e.g., dollars).
  /// Note: This assumes a 100 subunit ratio (cents).
  double get amount => amountMinorUnits / 100.0;

  /// Optional priority override. If set, this takes precedence over the category's default priority.
  final ExpensePriority? priority;

  /// Returns the effective priority (explicit or derived from category).
  ExpensePriority get effectivePriority {
    if (priority != null) return priority!;
    // Fallback found in categories.dart, but we might not have access to that function here easily purely inside model unless we import it?
    // getDefaultPriority is in categories.dart.
    // I should check if I imported categories.dart. I did not.
    // Actually, models usually shouldn't depend on util/logic if possible, but here it's handy.
    // Or I can keep logic external.
    // TimelineItem has it. Let's see TimelineItem imports.
    // TimelineItem imports `package:expense_stalker_mobile/src/util/categories.dart`.
    // So I can do the same for PulseEntry.
    return getDefaultPriority(category, type);
  }

  /// Optional category for organizing pulse (e.g., "Groceries", "Utilities", "Salary").
  /// Can be used independently or derived from linked timeline item category.
  final String? category;

  /// Optional subcategory for more granular organization (e.g., "Rent", "Groceries").
  final String? subcategory;

  /// Optional origin/provider name (e.g., "Electric Co", "Comcast", "Acme Corp").
  /// Tracks the source or destination of the pulse.
  final String? origin;

  /// When pulse was originally scheduled (copied from TimelineItem).
  /// Null indicates no variance tracking (legacy or standalone pulse).
  final DateTime? scheduledDate;

  /// Expected amount in cents (copied from TimelineItem).
  /// Null indicates amount matched or legacy pulse.
  final int? scheduledAmountMinorUnits;

  /// ID of the Money Pot updated by this pulse.
  /// Used to reverse the balance update if the pulse is deleted.
  final MoneyPotId? moneyPotId;

  final AppCurrency? transactionCurrency;
  final int? transactionAmountMinorUnits;
  final double? exchangeRate;

  /// Source of this pulse entry (manual, timeline, import, etc.).
  /// Defaults to [PulseSource.manual] for backward compatibility.
  final PulseSource source;

  /// Original unmodified description from import source (for bank imports).
  /// Used for re-learning categorization patterns when user corrects category.
  final String? rawImportDescription;

  /// Confidence score for auto-assigned category (0.0-1.0).
  /// Only relevant for imported pulses with auto-categorization.
  final double? categorizationConfidence;

  /// External reference ID or counterparty account number from import.
  /// Separate from user notes to preserve bank data.
  final String? importReference;

  /// Additional metadata from import (e.g. notifications, remarks).
  final String? importMetadata;

  /// ID of the matching transfer pair (for debit/credit pairs).
  final String? transferPairId;

  /// Whether this is an internal transfer between own accounts.
  /// If true, this transaction may be excluded from spending analysis.
  final bool isInternalTransfer;

  /// Returns true if this pulse was imported from an external source.
  bool get isImported => source.isImported;

  /// Returns true if this pulse was generated from a timeline item.
  bool get isFromTimeline => source.isFromTimeline;

  PulseEntry copyWith({
    String? label,
    int? amountMinorUnits,
    DateTime? date,
    PulseType? type,
    Object? timelineItemId = sentinel,
    Object? notes = sentinel,
    Object? category = sentinel,
    Object? subcategory = sentinel,
    Object? origin = sentinel,
    Object? scheduledDate = sentinel,
    Object? scheduledAmountMinorUnits = sentinel,
    Object? moneyPotId = sentinel,
    Object? transactionCurrency = sentinel,
    Object? transactionAmountMinorUnits = sentinel,
    Object? exchangeRate = sentinel,
    Object? priority = sentinel,
    PulseSource? source,
    Object? rawImportDescription = sentinel,
    Object? categorizationConfidence = sentinel,
    Object? importReference = sentinel,
    Object? importMetadata = sentinel,
    Object? transferPairId = sentinel,
    bool? isInternalTransfer,
    Object? runningBalanceCents = sentinel,
  }) {
    return PulseEntry(
      id: id,
      label: label ?? this.label,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      date: date ?? this.date,
      type: type ?? this.type,
      timelineItemId: timelineItemId == sentinel
          ? this.timelineItemId
          : timelineItemId as TimelineItemId?,
      notes: notes == sentinel ? this.notes : notes as String?,
      category: category == sentinel ? this.category : category as String?,
      subcategory:
          subcategory == sentinel ? this.subcategory : subcategory as String?,
      origin: origin == sentinel ? this.origin : origin as String?,
      scheduledDate: scheduledDate == sentinel
          ? this.scheduledDate
          : scheduledDate as DateTime?,
      scheduledAmountMinorUnits: scheduledAmountMinorUnits == sentinel
          ? this.scheduledAmountMinorUnits
          : scheduledAmountMinorUnits as int?,
      moneyPotId:
          moneyPotId == sentinel ? this.moneyPotId : moneyPotId as MoneyPotId?,
      transactionCurrency: transactionCurrency == sentinel
          ? this.transactionCurrency
          : transactionCurrency as AppCurrency?,
      transactionAmountMinorUnits: transactionAmountMinorUnits == sentinel
          ? this.transactionAmountMinorUnits
          : transactionAmountMinorUnits as int?,
      exchangeRate: exchangeRate == sentinel
          ? this.exchangeRate
          : exchangeRate as double?,
      priority:
          priority == sentinel ? this.priority : priority as ExpensePriority?,
      source: source ?? this.source,
      rawImportDescription: rawImportDescription == sentinel
          ? this.rawImportDescription
          : rawImportDescription as String?,
      categorizationConfidence: categorizationConfidence == sentinel
          ? this.categorizationConfidence
          : categorizationConfidence as double?,
      importReference: importReference == sentinel
          ? this.importReference
          : importReference as String?,
      importMetadata: importMetadata == sentinel
          ? this.importMetadata
          : importMetadata as String?,
      transferPairId: transferPairId == sentinel
          ? this.transferPairId
          : transferPairId as String?,
      isInternalTransfer: isInternalTransfer ?? this.isInternalTransfer,
      runningBalanceCents: runningBalanceCents == sentinel
          ? this.runningBalanceCents
          : runningBalanceCents as int?,
    );
  }

  @override
  List<Object?> get props => [
        id,
        label,
        amountMinorUnits,
        date,
        type,
        timelineItemId,
        notes,
        category,
        subcategory,
        origin,
        scheduledDate,
        scheduledAmountMinorUnits,
        moneyPotId,
        transactionCurrency,
        transactionAmountMinorUnits,
        exchangeRate,
        priority,
        source,
        rawImportDescription,
        categorizationConfidence,
        importReference,
        importMetadata,
        transferPairId,
        isInternalTransfer,
        runningBalanceCents,
      ];
}
