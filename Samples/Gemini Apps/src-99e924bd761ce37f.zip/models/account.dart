// ignore_for_file: deprecated_member_use_from_same_package
import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/account_settings.dart';

class Account extends Equatable {
  final AccountId id;
  final String name;
  final DateTime createdAt;
  final DateTime lastModified;
  final bool isTestData;
  final int? iconCodePoint; // Material icon code point for custom icons

  // Encapsulated Settings
  final AccountSettings settings;

  // Money Pots (can be account-specific or global based on settings)
  final List<MoneyPot> moneyPots;

  // ============================================================================
  // DELEGATED GETTERS
  // These getters forward to AccountSettings for backward compatibility.
  // The Account class previously held these fields directly. After refactoring
  // to AccountSettings, these getters were retained to avoid breaking 100+
  // call sites across the codebase. Access via account.settings is preferred
  // for new code.
  // ============================================================================
  int? get paycheckDay => settings.paycheckDay;
  bool get paycheckBusinessAdjust => settings.paycheckBusinessAdjust;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection =>
      settings.paycheckBusinessAdjustDirection;
  bool get paycheckShowMonthInTimeline => settings.paycheckShowMonthInTimeline;
  int get startingBalanceCents => settings.startingBalanceCents;
  int? get currentBalanceCents => settings.currentBalanceCents;
  TimelineSortOrder get timelineSortOrder => settings.timelineSortOrder;
  TimelineDateSortMode get timelineDateSortMode =>
      settings.timelineDateSortMode;
  ViewPeriodMode get viewPeriodMode => settings.viewPeriodMode;
  TimelineViewMode get timelineViewMode => settings.timelineViewMode;
  bool get timelineShowClearedItems => settings.timelineShowClearedItems;
  bool get timelineShowSkippedItems => settings.timelineShowSkippedItems;
  bool get timelineGroupByDate => settings.timelineGroupByDate;
  bool get timelineGroupByTheme => settings.timelineGroupByTheme;
  bool get timelineSplitClearedAndPending =>
      settings.timelineSplitClearedAndPending; // [NEW]
  bool get timelineShowSubcategories =>
      settings.timelineShowSubcategories; // [NEW]
  bool getTimelineShowPulseOrigin(TimelineViewMode mode) {
    switch (mode) {
      case TimelineViewMode.sheet:
        return settings.timelineShowPulseOriginSheet;
      case TimelineViewMode.grid:
        return settings.timelineShowPulseOriginGrid;
      case TimelineViewMode.month:
        return settings.timelineShowPulseOriginMonth;
    }
  }

  MultiMonthDisplayMode getMultiMonthDisplayMode(TimelineViewMode mode) {
    switch (mode) {
      case TimelineViewMode.sheet:
        return settings.multiMonthDisplayModeSheet;
      case TimelineViewMode.grid:
        return settings.multiMonthDisplayModeGrid;
      case TimelineViewMode.month:
        return settings.multiMonthDisplayModeMonth;
    }
  }

  MultiMonthDisplayMode get multiMonthDisplayModeMonth =>
      settings.multiMonthDisplayModeMonth;
  MultiMonthDisplayMode get multiMonthDisplayModeSheet =>
      settings.multiMonthDisplayModeSheet;
  MultiMonthDisplayMode get multiMonthDisplayModeGrid =>
      settings.multiMonthDisplayModeGrid;
  bool get timelineShowPulseOriginMonth =>
      settings.timelineShowPulseOriginMonth;
  bool get timelineShowPulseOriginSheet =>
      settings.timelineShowPulseOriginSheet;
  bool get timelineShowPulseOriginGrid => settings.timelineShowPulseOriginGrid;
  MonthTotalsDisplayMode get monthTotalsDisplayMode =>
      settings.monthTotalsDisplayMode;
  MonthCardDisplayMode get monthCardDisplayMode =>
      settings.monthCardDisplayMode;

  @Deprecated('Use getMultiMonthDisplayMode(mode)')
  MultiMonthDisplayMode get multiMonthDisplayMode =>
      settings.multiMonthDisplayModeMonth;
  DayFormat get dayFormat => settings.dayFormat;
  TimelineSwipeAction get timelineSwipeLeft => settings.timelineSwipeLeft;
  TimelineSwipeAction get timelineSwipeRight => settings.timelineSwipeRight;
  TimelineTapAction get timelineTapAction => settings.timelineTapAction;
  PulseSwipeAction get pulseSwipeLeft => settings.pulseSwipeLeft;
  PulseSwipeAction get pulseSwipeRight => settings.pulseSwipeRight;
  PulseDisplayMode get pulseDisplayMode => settings.pulseDisplayMode;
  bool get enableTabSwipe => settings.enableTabSwipe;
  bool get timelineUseZeroBaseline => settings.timelineUseZeroBaseline;
  TerminologyPreset get terminologyPreset => settings.terminologyPreset;
  PulsesFilterType get pulseFilterType => settings.pulseFilterType;
  PulsesGroupBy get pulseGroupBy => settings.pulseGroupBy;
  bool get pulseShowArchived => settings.pulseShowArchived;
  CategoryPresetMode get categoryPresetMode => settings.categoryPresetMode;
  List<String> get customExpenseCategories => settings.customExpenseCategories;
  List<String> get customIncomeCategories => settings.customIncomeCategories;
  String? get moneyPotsSectionLabel => settings.moneyPotsSectionLabel;
  String? get customPulseLabel => settings.customPulseLabel;
  String? get customTimelineLabel => settings.customTimelineLabel;
  String? get customActivityLabel => settings.customActivityLabel;
  bool get balanceUpdatesDisabled => settings.balanceUpdatesDisabled;
  Map<String, List<String>> get customSubcategories =>
      settings.customSubcategories; // [NEW]
  Map<String, int> get categoryIcons => settings.categoryIcons;
  bool get includeInternalTransfers => settings.includeInternalTransfers;

  // Notification Settings
  bool get notificationsEnabled => settings.notificationsEnabled;
  bool get dailyAlertEnabled => settings.dailyAlertEnabled;
  int get dailyAlertHour => settings.dailyAlertHour;
  int get dailyAlertMinute => settings.dailyAlertMinute;
  bool get weeklyAlertEnabled => settings.weeklyAlertEnabled;
  int get weeklyAlertHour => settings.weeklyAlertHour;
  int get weeklyAlertMinute => settings.weeklyAlertMinute;
  bool get weeklySummaryEnabled => settings.weeklySummaryEnabled;
  int get weeklySummaryHour => settings.weeklySummaryHour;
  int get weeklySummaryMinute => settings.weeklySummaryMinute;
  int get weekStartDay => settings.weekStartDay;

  const Account({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.lastModified,
    this.isTestData = false,
    this.iconCodePoint,
    this.settings = const AccountSettings(),
    this.moneyPots = const [],
  });

  factory Account.create({
    required String name,
    AccountId? id,
    bool isTestData = false,
    int? iconCodePoint,
    // Flattened arguments for convenience (delegated to settings)
    int? paycheckDay,
    bool paycheckBusinessAdjust = false,
    PaycheckAdjustDirection paycheckBusinessAdjustDirection =
        PaycheckAdjustDirection.before,
    int startingBalanceCents = 0,
    int? currentBalanceCents,
    TimelineSortOrder timelineSortOrder = TimelineSortOrder.chronological,
    TimelineDateSortMode timelineDateSortMode =
        TimelineDateSortMode.scheduledDate,
    ViewPeriodMode viewPeriodMode = ViewPeriodMode.calendar,
    TimelineViewMode timelineViewMode = TimelineViewMode.month,
    bool timelineShowClearedItems = true,
    bool timelineShowSkippedItems = false,
    bool timelineGroupByDate = false,
    bool timelineGroupByTheme = false,
    bool timelineSplitClearedAndPending = false, // [NEW]
    bool timelineShowSubcategories = false, // [NEW]
    bool timelineShowPulseOrigin = false,
    bool? timelineShowPulseOriginMonth,
    bool? timelineShowPulseOriginSheet,
    bool? timelineShowPulseOriginGrid,
    MonthTotalsDisplayMode monthTotalsDisplayMode =
        MonthTotalsDisplayMode.includeCleared,
    MonthCardDisplayMode monthCardDisplayMode = MonthCardDisplayMode.full,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayModeMonth,
    MultiMonthDisplayMode? multiMonthDisplayModeSheet,
    MultiMonthDisplayMode? multiMonthDisplayModeGrid,
    DayFormat dayFormat = DayFormat.number,
    TimelineSwipeAction timelineSwipeLeft = TimelineSwipeAction.off,
    TimelineSwipeAction timelineSwipeRight = TimelineSwipeAction.off,
    TimelineTapAction timelineTapAction = TimelineTapAction.archive,
    PulseSwipeAction pulseSwipeLeft = PulseSwipeAction.off,
    PulseSwipeAction pulseSwipeRight = PulseSwipeAction.off,
    PulseDisplayMode pulseDisplayMode = PulseDisplayMode.automatic,
    bool enableTabSwipe = false,
    bool timelineUseZeroBaseline = false,
    TerminologyPreset terminologyPreset = TerminologyPreset.defaultTerms,
    PulsesFilterType pulseFilterType = PulsesFilterType.all,
    PulsesGroupBy pulseGroupBy = PulsesGroupBy.none,
    bool pulseShowArchived = false,
    CategoryPresetMode categoryPresetMode = CategoryPresetMode.defaultPresets,
    List<String> customExpenseCategories = const [],
    List<String> customIncomeCategories = const [],
    Map<String, List<String>> customSubcategories = const {}, // [NEW]
    List<MoneyPot> moneyPots = const [],
    String? moneyPotsSectionLabel,
    String? customPulseLabel,
    String? customTimelineLabel,
    bool balanceUpdatesDisabled = false,
    bool includeInternalTransfers = false,
  }) {
    final now = DateTime.now();
    return Account(
      id: id ?? newAccountId(),
      name: name,
      createdAt: now,
      lastModified: now,
      isTestData: isTestData,
      iconCodePoint: iconCodePoint,
      moneyPots: moneyPots,
      settings: AccountSettings(
        paycheckDay: paycheckDay,
        paycheckBusinessAdjust: paycheckBusinessAdjust,
        paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
        startingBalanceCents: startingBalanceCents,
        currentBalanceCents: currentBalanceCents ?? 0,
        timelineSortOrder: timelineSortOrder,
        timelineDateSortMode: timelineDateSortMode,
        viewPeriodMode: viewPeriodMode,
        timelineViewMode: timelineViewMode,
        timelineShowClearedItems: timelineShowClearedItems,
        timelineShowSkippedItems: timelineShowSkippedItems,
        timelineGroupByDate: timelineGroupByDate,
        timelineGroupByTheme: timelineGroupByTheme,
        timelineSplitClearedAndPending: timelineSplitClearedAndPending, // [NEW]
        timelineShowSubcategories: timelineShowSubcategories, // [NEW]
        timelineShowPulseOriginMonth:
            timelineShowPulseOriginMonth ?? timelineShowPulseOrigin,

        timelineShowPulseOriginSheet:
            timelineShowPulseOriginSheet ?? timelineShowPulseOrigin,
        timelineShowPulseOriginGrid:
            timelineShowPulseOriginGrid ?? timelineShowPulseOrigin,
        monthTotalsDisplayMode: monthTotalsDisplayMode,
        monthCardDisplayMode: monthCardDisplayMode,
        multiMonthDisplayModeMonth: multiMonthDisplayModeMonth ??
            multiMonthDisplayMode ??
            MultiMonthDisplayMode.automatic,
        multiMonthDisplayModeSheet: multiMonthDisplayModeSheet ??
            multiMonthDisplayMode ??
            MultiMonthDisplayMode.automatic,
        multiMonthDisplayModeGrid: multiMonthDisplayModeGrid ??
            multiMonthDisplayMode ??
            MultiMonthDisplayMode.automatic,
        dayFormat: dayFormat,
        timelineSwipeLeft: timelineSwipeLeft,
        timelineSwipeRight: timelineSwipeRight,
        timelineTapAction: timelineTapAction,
        pulseSwipeLeft: pulseSwipeLeft,
        pulseSwipeRight: pulseSwipeRight,
        pulseDisplayMode: pulseDisplayMode,
        enableTabSwipe: enableTabSwipe,
        timelineUseZeroBaseline: timelineUseZeroBaseline,
        terminologyPreset: terminologyPreset,
        pulseFilterType: pulseFilterType,
        pulseGroupBy: pulseGroupBy,
        pulseShowArchived: pulseShowArchived,
        categoryPresetMode: categoryPresetMode,
        customExpenseCategories: customExpenseCategories,
        customIncomeCategories: customIncomeCategories,
        customSubcategories: customSubcategories, // [NEW]
        moneyPotsSectionLabel: moneyPotsSectionLabel,
        customPulseLabel: customPulseLabel,
        customTimelineLabel: customTimelineLabel,
        balanceUpdatesDisabled: balanceUpdatesDisabled,
        includeInternalTransfers: includeInternalTransfers,
      ),
    );
  }

  Account copyWith({
    String? name,
    DateTime? lastModified,
    bool? isTestData,
    int? iconCodePoint,
    bool clearIcon = false,
    // Delegated to settings.copyWith
    int? paycheckDay,
    bool clearPaycheckDay = false,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    int? currentBalanceCents,
    bool clearCurrentBalanceCents = false,
    TimelineSortOrder? timelineSortOrder,
    TimelineDateSortMode? timelineDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    TimelineViewMode? timelineViewMode,
    bool? timelineShowClearedItems,
    bool? timelineShowSkippedItems,
    bool? timelineGroupByDate,
    bool? timelineGroupByTheme,
    bool? timelineSplitClearedAndPending, // [NEW]
    bool? timelineShowSubcategories, // [NEW]
    bool? timelineShowPulseOrigin,
    bool? timelineShowPulseOriginMonth,
    bool? timelineShowPulseOriginSheet,
    bool? timelineShowPulseOriginGrid,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayModeMonth,
    MultiMonthDisplayMode? multiMonthDisplayModeSheet,
    MultiMonthDisplayMode? multiMonthDisplayModeGrid,
    DayFormat? dayFormat,
    TimelineSwipeAction? timelineSwipeLeft,
    TimelineSwipeAction? timelineSwipeRight,
    TimelineTapAction? timelineTapAction,
    PulseSwipeAction? pulseSwipeLeft,
    PulseSwipeAction? pulseSwipeRight,
    PulseDisplayMode? pulseDisplayMode,
    bool? enableTabSwipe,
    bool? timelineUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PulsesFilterType? pulseFilterType,
    PulsesGroupBy? pulseGroupBy,
    bool? pulseShowArchived,
    CategoryPresetMode? categoryPresetMode,
    List<String>? customExpenseCategories,
    List<String>? customIncomeCategories,
    Map<String, List<String>>? customSubcategories, // [NEW]
    List<MoneyPot>? moneyPots,
    String? moneyPotsSectionLabel,
    bool clearMoneyPotsSectionLabel = false,
    String? customPulseLabel,
    String? customTimelineLabel,
    Map<String, int>? categoryIcons,
    bool? balanceUpdatesDisabled,
    bool? includeInternalTransfers,
    // Notification Settings
    bool? notificationsEnabled,
    bool? dailyAlertEnabled,
    int? dailyAlertHour,
    int? dailyAlertMinute,
    bool? weeklyAlertEnabled,
    int? weeklyAlertHour,
    int? weeklyAlertMinute,
    bool? weeklySummaryEnabled,
    int? weeklySummaryHour,
    int? weeklySummaryMinute,
    int? weekStartDay,
    Set<String>? dismissedInsightIds,
    Set<String>? pinnedInsightIds,
    // Direct settings override
    AccountSettings? settings,
  }) {
    // If a full settings object is provided, use it.
    // Otherwise, check if individual settings are updated and apply to current settings.
    final effectiveSettings = settings ??
        this.settings.copyWith(
              paycheckDay: paycheckDay,
              clearPaycheckDay: clearPaycheckDay,
              paycheckBusinessAdjust: paycheckBusinessAdjust,
              paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection,
              startingBalanceCents: startingBalanceCents,
              currentBalanceCents: currentBalanceCents,
              clearCurrentBalanceCents: clearCurrentBalanceCents,
              timelineSortOrder: timelineSortOrder,
              timelineDateSortMode: timelineDateSortMode,
              viewPeriodMode: viewPeriodMode,
              timelineViewMode: timelineViewMode,
              timelineShowClearedItems: timelineShowClearedItems,
              timelineShowSkippedItems: timelineShowSkippedItems,
              timelineGroupByDate: timelineGroupByDate,
              timelineGroupByTheme: timelineGroupByTheme,
              timelineSplitClearedAndPending:
                  timelineSplitClearedAndPending, // [NEW]
              timelineShowSubcategories: timelineShowSubcategories, // [NEW]
              timelineShowPulseOrigin: timelineShowPulseOrigin,

              timelineShowPulseOriginMonth: timelineShowPulseOriginMonth,
              timelineShowPulseOriginSheet: timelineShowPulseOriginSheet,
              timelineShowPulseOriginGrid: timelineShowPulseOriginGrid,
              monthTotalsDisplayMode: monthTotalsDisplayMode,
              monthCardDisplayMode: monthCardDisplayMode,
              multiMonthDisplayMode: multiMonthDisplayMode,
              multiMonthDisplayModeMonth: multiMonthDisplayModeMonth,
              multiMonthDisplayModeSheet: multiMonthDisplayModeSheet,
              multiMonthDisplayModeGrid: multiMonthDisplayModeGrid,
              dayFormat: dayFormat,
              timelineSwipeLeft: timelineSwipeLeft,
              timelineSwipeRight: timelineSwipeRight,
              timelineTapAction: timelineTapAction,
              pulseSwipeLeft: pulseSwipeLeft,
              pulseSwipeRight: pulseSwipeRight,
              pulseDisplayMode: pulseDisplayMode,
              enableTabSwipe: enableTabSwipe,
              timelineUseZeroBaseline: timelineUseZeroBaseline,
              terminologyPreset: terminologyPreset,
              pulseFilterType: pulseFilterType,
              pulseGroupBy: pulseGroupBy,
              pulseShowArchived: pulseShowArchived,
              categoryPresetMode: categoryPresetMode,
              customExpenseCategories: customExpenseCategories,
              customIncomeCategories: customIncomeCategories,
              customSubcategories: customSubcategories, // [NEW]
              moneyPotsSectionLabel: moneyPotsSectionLabel,
              clearMoneyPotsSectionLabel: clearMoneyPotsSectionLabel,
              customPulseLabel: customPulseLabel,
              customTimelineLabel: customTimelineLabel,
              categoryIcons: categoryIcons,
              balanceUpdatesDisabled: balanceUpdatesDisabled,
              includeInternalTransfers: includeInternalTransfers,
              notificationsEnabled: notificationsEnabled,
              dailyAlertEnabled: dailyAlertEnabled,
              dailyAlertHour: dailyAlertHour,
              dailyAlertMinute: dailyAlertMinute,
              weeklyAlertEnabled: weeklyAlertEnabled,
              weeklyAlertHour: weeklyAlertHour,
              weeklyAlertMinute: weeklyAlertMinute,
              weeklySummaryEnabled: weeklySummaryEnabled,
              weeklySummaryHour: weeklySummaryHour,
              weeklySummaryMinute: weeklySummaryMinute,
              weekStartDay: weekStartDay,
              dismissedInsightIds: dismissedInsightIds,
              pinnedInsightIds: pinnedInsightIds,
            );

    return Account(
      id: id,
      name: name ?? this.name,
      createdAt: createdAt,
      lastModified: lastModified ?? this.lastModified,
      isTestData: isTestData ?? this.isTestData,
      iconCodePoint: clearIcon ? null : (iconCodePoint ?? this.iconCodePoint),
      moneyPots: moneyPots ?? this.moneyPots,
      settings: effectiveSettings,
    );
  }

  /// Whether paycheck mode is configured for this account
  bool get isPaycheckModeConfigured => settings.isPaycheckModeConfigured;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'lastModified': lastModified.millisecondsSinceEpoch,
      'isTestData': isTestData,
      'iconCodePoint': iconCodePoint,
      'settings': settings.toJson(),
      'moneyPots': moneyPots.map((p) => p.toJson()).toList(),
    };
  }

  factory Account.fromJson(Map<String, dynamic> json) {
    // Determine if we are loading legacy (flat) JSON or new (nested) JSON
    final settingsJson = json['settings'];
    final AccountSettings settings;

    if (settingsJson is Map<String, dynamic>) {
      // New format
      settings = AccountSettings.fromJson(settingsJson);
    } else {
      // Legacy format: pass the whole JSON to AccountSettings.fromJson
      // This works because the legacy JSON has the fields at root, which the
      // AccountSettings.fromJson parser will look for.
      settings = AccountSettings.fromJson(json);
    }

    return Account(
      id: AccountId(json['id'] as String? ?? newIdRaw()),
      name: json['name'] as String? ?? 'Untitled Account',
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        json['createdAt'] as int? ?? DateTime.now().millisecondsSinceEpoch,
      ),
      lastModified: DateTime.fromMillisecondsSinceEpoch(
        json['lastModified'] as int? ?? DateTime.now().millisecondsSinceEpoch,
      ),
      isTestData: json['isTestData'] as bool? ?? false,
      iconCodePoint: json['iconCodePoint'] as int?,
      moneyPots: _parseMoneyPots(json['moneyPots']),
      settings: settings,
    );
  }

  static List<MoneyPot> _parseMoneyPots(dynamic value) {
    if (value is List) {
      return value
          .map((e) {
            try {
              return MoneyPot.fromJson(e as Map<String, dynamic>);
            } catch (_) {
              return null;
            }
          })
          .whereType<MoneyPot>()
          .toList();
    }
    return const [];
  }

  @override
  List<Object?> get props => [
        id,
        name,
        createdAt,
        lastModified,
        isTestData,
        iconCodePoint,
        settings,
        moneyPots,
        customPulseLabel,
        customTimelineLabel,
      ];
}
