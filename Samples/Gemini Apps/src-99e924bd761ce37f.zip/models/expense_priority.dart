/// Represents the financial priority/importance of an expense.
///
/// Used for insights analysis and budget recommendations.
/// Priority can be auto-assigned based on category or manually overridden.
enum ExpensePriority {
  /// Essential expenses that must be paid: housing, utilities, insurance, health.
  critical('Critical', 'Essential'),

  /// Important but not strictly essential: debt payments, education, transportation.
  advisable('Advisable', 'Important'),

  /// Discretionary spending: entertainment, subscriptions, dining, shopping.
  optional('Optional', 'Discretionary'),

  /// Smart investments or prevention: maintenance, software tools, bulk buying.
  strategic('Strategic', 'Smart'),

  /// Wasteful or impulse purchases: fees, overpriced luxury, unused subscriptions.
  frivolous('Frivolous', 'Waste');

  const ExpensePriority(this.label, this.shortLabel);

  /// Display label for the priority (e.g., "Critical").
  final String label;

  /// Short label for compact display (e.g., "Essential").
  final String shortLabel;
}
