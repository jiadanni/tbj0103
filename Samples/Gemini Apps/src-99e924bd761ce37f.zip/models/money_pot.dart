import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum MoneyPotType {
  savings,
  debt;

  String get id => name;
}

class MoneyPot extends Equatable {
  final MoneyPotId id;
  final String name;
  final int amountMinorUnits;
  final MoneyPotType type;
  final AppCurrency? currency;
  final List<AccountId>?
      accountIds; // null = global, non-empty = specific accounts
  /// Whether this pot is automatically managed by a linked debt item.
  /// System-managed pots cannot be manually edited.
  final bool isSystemManaged;

  /// converted to the app currency.
  final bool showInAppCurrency;

  /// Optional exchange rate for display conversion: app unit per 1 pot currency unit.
  final double? exchangeRate;

  @override
  List<Object?> get props => [
        id,
        name,
        amountMinorUnits,
        type,
        currency,
        accountIds,
        isSystemManaged,
        showInAppCurrency,
        exchangeRate,
      ];

  const MoneyPot({
    required this.id,
    required this.name,
    required this.amountMinorUnits,
    required this.type,
    this.currency,
    this.accountIds,
    this.isSystemManaged = false,
    this.showInAppCurrency = false,
    this.exchangeRate,
  });

  factory MoneyPot.create({
    required String name,
    required int amountMinorUnits,
    required MoneyPotType type,
    AppCurrency? currency,
    List<AccountId>? accountIds,
    bool isSystemManaged = false,
    bool showInAppCurrency = false,
    double? exchangeRate,
  }) {
    return MoneyPot(
      id: newMoneyPotId(),
      name: name,
      amountMinorUnits: amountMinorUnits,
      type: type,
      currency: currency,
      accountIds: accountIds,
      isSystemManaged: isSystemManaged,
      showInAppCurrency: showInAppCurrency,
      exchangeRate: exchangeRate,
    );
  }

  MoneyPot copyWith({
    String? name,
    int? amountMinorUnits,
    MoneyPotType? type,
    Optional<AppCurrency>? currency,
    Optional<List<AccountId>>? accountIds,
    bool? isSystemManaged,
    bool? showInAppCurrency,
    Optional<double>? exchangeRate,
  }) {
    return MoneyPot(
      id: id,
      name: name ?? this.name,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      type: type ?? this.type,
      currency: currency != null ? currency.value : this.currency,
      accountIds: accountIds != null ? accountIds.value : this.accountIds,
      isSystemManaged: isSystemManaged ?? this.isSystemManaged,
      showInAppCurrency: showInAppCurrency ?? this.showInAppCurrency,
      exchangeRate:
          exchangeRate != null ? exchangeRate.value : this.exchangeRate,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'amountMinorUnits': amountMinorUnits,
      'type': type.id,
      'currency': currency?.name,
      'accountIds': accountIds,
      'isSystemManaged': isSystemManaged,
      'showInAppCurrency': showInAppCurrency,
      'exchangeRate': exchangeRate,
    };
  }

  factory MoneyPot.fromJson(Map<String, dynamic> json) {
    return MoneyPot(
      id: MoneyPotId(json['id'] as String),
      name: json['name'] as String,
      amountMinorUnits: ((json['amountMinorUnits'] ??
              json['amountCents'] ??
              json['amount'] ??
              json['cents'] ??
              json['amount_minor_units'] ??
              0) as num)
          .toInt(),
      type: MoneyPotType.values.firstWhere(
        (e) => e.id == json['type'],
        orElse: () => MoneyPotType.savings,
      ),
      currency: decodeCurrency(json['currency']),
      accountIds: (json['accountIds'] as List?)
          ?.map((e) => AccountId(e as String))
          .toList(),
      isSystemManaged: json['isSystemManaged'] as bool? ?? false,
      showInAppCurrency: json['showInAppCurrency'] as bool? ?? false,
      exchangeRate: (json['exchangeRate'] as num?)?.toDouble(),
    );
  }
}
