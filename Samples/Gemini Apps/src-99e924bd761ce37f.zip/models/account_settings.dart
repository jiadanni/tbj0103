import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

class AccountSettings extends Equatable {
  // Paycheck Settings
  final int? paycheckDay;
  final bool paycheckBusinessAdjust;
  final PaycheckAdjustDirection paycheckBusinessAdjustDirection;
  final bool paycheckShowMonthInTimeline;

  // Balance Settings
  final int startingBalanceCents;
  final int? currentBalanceCents;

  // Timeline View Settings
  final TimelineSortOrder timelineSortOrder;
  final TimelineDateSortMode timelineDateSortMode;
  final ViewPeriodMode viewPeriodMode;
  final TimelineViewMode timelineViewMode;
  final bool timelineShowClearedItems;
  final bool timelineShowSkippedItems;
  final bool timelineGroupByDate;
  final bool timelineGroupByTheme;
  final bool timelineSplitClearedAndPending; // [NEW]
  final bool timelineShowSubcategories; // [NEW]
  final bool timelineShowPulseOriginMonth;

  final bool timelineShowPulseOriginSheet;
  final bool timelineShowPulseOriginGrid;

  // Display Modes
  final MonthTotalsDisplayMode monthTotalsDisplayMode;
  final MonthCardDisplayMode monthCardDisplayMode;
  final MultiMonthDisplayMode multiMonthDisplayModeMonth;
  final MultiMonthDisplayMode multiMonthDisplayModeSheet;
  final MultiMonthDisplayMode multiMonthDisplayModeGrid;
  final DayFormat dayFormat;

  // Interaction Settings
  final TimelineSwipeAction timelineSwipeLeft;
  final TimelineSwipeAction timelineSwipeRight;
  final TimelineTapAction timelineTapAction;
  final PulseSwipeAction pulseSwipeLeft;
  final PulseSwipeAction pulseSwipeRight;
  final PulseDisplayMode pulseDisplayMode;
  final bool enableTabSwipe;
  final bool timelineUseZeroBaseline;
  final bool balanceUpdatesDisabled;

  // Terminology & Categories
  final TerminologyPreset terminologyPreset;
  final PulsesFilterType pulseFilterType;
  final PulsesGroupBy pulseGroupBy;
  final bool pulseShowArchived;
  final CategoryPresetMode categoryPresetMode;
  final List<String> customExpenseCategories;
  final List<String> customIncomeCategories;
  final Map<String, List<String>> customSubcategories; // [NEW]
  final String? moneyPotsSectionLabel;
  final String? customPulseLabel;
  final String? customTimelineLabel;
  final Map<String, int> categoryIcons;

  // Notification Settings
  final bool notificationsEnabled;
  final bool dailyAlertEnabled;
  final int dailyAlertHour;
  final int dailyAlertMinute;
  final bool weeklyAlertEnabled;
  final int weeklyAlertHour;
  final int weeklyAlertMinute;
  final bool weeklySummaryEnabled;
  final int weeklySummaryHour;
  final int weeklySummaryMinute;
  final int weekStartDay;

  // Insight Settings
  final Set<String> dismissedInsightIds;
  final Set<String> pinnedInsightIds;
  final bool includeInternalTransfers;

  const AccountSettings({
    this.paycheckDay,
    this.paycheckBusinessAdjust = false,
    this.paycheckBusinessAdjustDirection = PaycheckAdjustDirection.before,
    this.startingBalanceCents = 0,
    this.currentBalanceCents,
    this.timelineSortOrder = TimelineSortOrder.chronological,
    this.timelineDateSortMode = TimelineDateSortMode.scheduledDate,
    this.viewPeriodMode = ViewPeriodMode.calendar,
    this.timelineViewMode = TimelineViewMode.month,
    this.timelineShowClearedItems = true,
    this.timelineShowSkippedItems = false,
    this.timelineGroupByDate = false,
    this.timelineGroupByTheme = false,
    this.timelineSplitClearedAndPending = false, // [NEW]
    this.timelineShowSubcategories = false, // [NEW]
    this.timelineShowPulseOriginMonth = false,
    this.timelineShowPulseOriginSheet = false,
    this.timelineShowPulseOriginGrid = false,
    this.monthTotalsDisplayMode = MonthTotalsDisplayMode.includeCleared,
    this.monthCardDisplayMode = MonthCardDisplayMode.full,
    this.multiMonthDisplayModeMonth = MultiMonthDisplayMode.automatic,
    this.multiMonthDisplayModeSheet = MultiMonthDisplayMode.automatic,
    this.multiMonthDisplayModeGrid = MultiMonthDisplayMode.automatic,
    this.dayFormat = DayFormat.number,
    this.timelineSwipeLeft = TimelineSwipeAction.off,
    this.timelineSwipeRight = TimelineSwipeAction.off,
    this.timelineTapAction = TimelineTapAction.archive,
    this.pulseSwipeLeft = PulseSwipeAction.off,
    this.pulseSwipeRight = PulseSwipeAction.off,
    this.pulseDisplayMode = PulseDisplayMode.automatic,
    this.enableTabSwipe = false,
    this.timelineUseZeroBaseline = false,
    this.terminologyPreset = TerminologyPreset.defaultTerms,
    this.pulseFilterType = PulsesFilterType.all,
    this.pulseGroupBy = PulsesGroupBy.none,
    this.pulseShowArchived = false,
    this.categoryPresetMode = CategoryPresetMode.defaultPresets,
    this.customExpenseCategories = const [],
    this.customIncomeCategories = const [],
    this.categoryIcons = const {},
    this.moneyPotsSectionLabel,
    this.customPulseLabel,
    this.customTimelineLabel,
    this.balanceUpdatesDisabled = false,
    this.notificationsEnabled = false,
    this.dailyAlertEnabled = false,
    this.dailyAlertHour = 9,
    this.dailyAlertMinute = 0,
    this.weeklyAlertEnabled = false,
    this.weeklyAlertHour = 9,
    this.weeklyAlertMinute = 0,
    this.weeklySummaryEnabled = false,
    this.weeklySummaryHour = 18,
    this.weeklySummaryMinute = 0,
    this.weekStartDay = 1,
    this.paycheckShowMonthInTimeline = false,
    this.customSubcategories = const {}, // [NEW]
    this.dismissedInsightIds = const {},
    this.pinnedInsightIds = const {},
    this.includeInternalTransfers = false,
  });

  /// Whether paycheck mode is configured for this account
  bool get isPaycheckModeConfigured => paycheckDay != null;

  // Backward compatibility
  @Deprecated('Use customTimelineLabel')
  String? get customActivityLabel => customTimelineLabel;

  AccountSettings copyWith({
    int? paycheckDay,
    bool clearPaycheckDay = false,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    int? currentBalanceCents,
    bool clearCurrentBalanceCents = false,
    TimelineSortOrder? timelineSortOrder,
    TimelineDateSortMode? timelineDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    TimelineViewMode? timelineViewMode,
    bool? timelineShowClearedItems,
    bool? timelineShowSkippedItems,
    bool? timelineGroupByDate,
    bool? timelineGroupByTheme,
    bool? timelineSplitClearedAndPending, // [NEW]
    bool? timelineShowSubcategories, // [NEW]
    // Support singular update for backward compatibility or bulk update
    bool? timelineShowPulseOrigin,

    // Or specific updates
    bool? timelineShowPulseOriginMonth,
    bool? timelineShowPulseOriginSheet,
    bool? timelineShowPulseOriginGrid,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayModeMonth,
    MultiMonthDisplayMode? multiMonthDisplayModeSheet,
    MultiMonthDisplayMode? multiMonthDisplayModeGrid,
    // Support singular update for backward compatibility
    MultiMonthDisplayMode? multiMonthDisplayMode,
    MultiMonthDisplayMode?
        multiMonthDisplayModeLegacy, // Alias for better clarity in mass updates
    DayFormat? dayFormat,
    TimelineSwipeAction? timelineSwipeLeft,
    TimelineSwipeAction? timelineSwipeRight,
    TimelineTapAction? timelineTapAction,
    PulseSwipeAction? pulseSwipeLeft,
    PulseSwipeAction? pulseSwipeRight,
    PulseDisplayMode? pulseDisplayMode,
    bool? enableTabSwipe,
    bool? timelineUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PulsesFilterType? pulseFilterType,
    PulsesGroupBy? pulseGroupBy,
    bool? pulseShowArchived,
    CategoryPresetMode? categoryPresetMode,
    List<String>? customExpenseCategories,
    List<String>? customIncomeCategories,
    Map<String, List<String>>? customSubcategories, // [NEW]
    String? moneyPotsSectionLabel,
    bool clearMoneyPotsSectionLabel = false,
    String? customPulseLabel,
    String? customTimelineLabel,
    Map<String, int>? categoryIcons,
    bool? balanceUpdatesDisabled,
    bool? notificationsEnabled,
    bool? dailyAlertEnabled,
    int? dailyAlertHour,
    int? dailyAlertMinute,
    bool? weeklyAlertEnabled,
    int? weeklyAlertHour,
    int? weeklyAlertMinute,
    bool? weeklySummaryEnabled,
    int? weeklySummaryHour,
    int? weeklySummaryMinute,
    bool? paycheckShowMonthInTimeline,
    int? weekStartDay,
    Set<String>? dismissedInsightIds,
    Set<String>? pinnedInsightIds,
    bool? includeInternalTransfers,
  }) {
    return AccountSettings(
      paycheckDay: clearPaycheckDay ? null : (paycheckDay ?? this.paycheckDay),
      paycheckBusinessAdjust:
          paycheckBusinessAdjust ?? this.paycheckBusinessAdjust,
      paycheckBusinessAdjustDirection: paycheckBusinessAdjustDirection ??
          this.paycheckBusinessAdjustDirection,
      startingBalanceCents: startingBalanceCents ?? this.startingBalanceCents,
      currentBalanceCents: clearCurrentBalanceCents
          ? null
          : (currentBalanceCents ?? this.currentBalanceCents),
      timelineSortOrder: timelineSortOrder ?? this.timelineSortOrder,
      timelineDateSortMode: timelineDateSortMode ?? this.timelineDateSortMode,
      viewPeriodMode: viewPeriodMode ?? this.viewPeriodMode,
      timelineViewMode: timelineViewMode ?? this.timelineViewMode,
      timelineShowClearedItems:
          timelineShowClearedItems ?? this.timelineShowClearedItems,
      timelineShowSkippedItems:
          timelineShowSkippedItems ?? this.timelineShowSkippedItems,
      timelineGroupByDate: timelineGroupByDate ?? this.timelineGroupByDate,
      timelineGroupByTheme: timelineGroupByTheme ?? this.timelineGroupByTheme,
      timelineSplitClearedAndPending: timelineSplitClearedAndPending ??
          this.timelineSplitClearedAndPending, // [NEW]
      timelineShowSubcategories:
          timelineShowSubcategories ?? this.timelineShowSubcategories, // [NEW]
      timelineShowPulseOriginMonth: timelineShowPulseOriginMonth ??
          (timelineShowPulseOrigin ?? this.timelineShowPulseOriginMonth),

      timelineShowPulseOriginSheet: timelineShowPulseOriginSheet ??
          (timelineShowPulseOrigin ?? this.timelineShowPulseOriginSheet),
      timelineShowPulseOriginGrid: timelineShowPulseOriginGrid ??
          (timelineShowPulseOrigin ?? this.timelineShowPulseOriginGrid),
      monthTotalsDisplayMode:
          monthTotalsDisplayMode ?? this.monthTotalsDisplayMode,
      monthCardDisplayMode: monthCardDisplayMode ?? this.monthCardDisplayMode,
      multiMonthDisplayModeMonth: multiMonthDisplayModeMonth ??
          (multiMonthDisplayMode ??
              multiMonthDisplayModeLegacy ??
              this.multiMonthDisplayModeMonth),
      multiMonthDisplayModeSheet: multiMonthDisplayModeSheet ??
          (multiMonthDisplayMode ??
              multiMonthDisplayModeLegacy ??
              this.multiMonthDisplayModeSheet),
      multiMonthDisplayModeGrid: multiMonthDisplayModeGrid ??
          (multiMonthDisplayMode ??
              multiMonthDisplayModeLegacy ??
              this.multiMonthDisplayModeGrid),
      dayFormat: dayFormat ?? this.dayFormat,
      timelineSwipeLeft: timelineSwipeLeft ?? this.timelineSwipeLeft,
      timelineSwipeRight: timelineSwipeRight ?? this.timelineSwipeRight,
      timelineTapAction: timelineTapAction ?? this.timelineTapAction,
      pulseSwipeLeft: pulseSwipeLeft ?? this.pulseSwipeLeft,
      pulseSwipeRight: pulseSwipeRight ?? this.pulseSwipeRight,
      pulseDisplayMode: pulseDisplayMode ?? this.pulseDisplayMode,
      enableTabSwipe: enableTabSwipe ?? this.enableTabSwipe,
      timelineUseZeroBaseline:
          timelineUseZeroBaseline ?? this.timelineUseZeroBaseline,
      terminologyPreset: terminologyPreset ?? this.terminologyPreset,
      pulseFilterType: pulseFilterType ?? this.pulseFilterType,
      pulseGroupBy: pulseGroupBy ?? this.pulseGroupBy,
      pulseShowArchived: pulseShowArchived ?? this.pulseShowArchived,
      categoryPresetMode: categoryPresetMode ?? this.categoryPresetMode,
      customExpenseCategories:
          customExpenseCategories ?? this.customExpenseCategories,
      customIncomeCategories:
          customIncomeCategories ?? this.customIncomeCategories,
      customSubcategories:
          customSubcategories ?? this.customSubcategories, // [NEW]
      moneyPotsSectionLabel: clearMoneyPotsSectionLabel
          ? null
          : (moneyPotsSectionLabel ?? this.moneyPotsSectionLabel),
      customPulseLabel: customPulseLabel ?? this.customPulseLabel,
      customTimelineLabel: customTimelineLabel ?? this.customTimelineLabel,
      categoryIcons: categoryIcons ?? this.categoryIcons,
      balanceUpdatesDisabled:
          balanceUpdatesDisabled ?? this.balanceUpdatesDisabled,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      dailyAlertEnabled: dailyAlertEnabled ?? this.dailyAlertEnabled,
      dailyAlertHour: dailyAlertHour ?? this.dailyAlertHour,
      dailyAlertMinute: dailyAlertMinute ?? this.dailyAlertMinute,
      weeklyAlertEnabled: weeklyAlertEnabled ?? this.weeklyAlertEnabled,
      weeklyAlertHour: weeklyAlertHour ?? this.weeklyAlertHour,
      weeklyAlertMinute: weeklyAlertMinute ?? this.weeklyAlertMinute,
      weeklySummaryEnabled: weeklySummaryEnabled ?? this.weeklySummaryEnabled,
      weeklySummaryHour: weeklySummaryHour ?? this.weeklySummaryHour,
      weeklySummaryMinute: weeklySummaryMinute ?? this.weeklySummaryMinute,
      paycheckShowMonthInTimeline:
          paycheckShowMonthInTimeline ?? this.paycheckShowMonthInTimeline,
      weekStartDay: weekStartDay ?? this.weekStartDay,
      dismissedInsightIds: dismissedInsightIds ?? this.dismissedInsightIds,
      pinnedInsightIds: pinnedInsightIds ?? this.pinnedInsightIds,
      includeInternalTransfers:
          includeInternalTransfers ?? this.includeInternalTransfers,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'paycheckDay': paycheckDay,
      'paycheckBusinessAdjust': paycheckBusinessAdjust,
      'paycheckBusinessAdjustDirection': paycheckBusinessAdjustDirection.name,
      'paycheckShowMonthInTimeline': paycheckShowMonthInTimeline,
      'startingBalanceCents': startingBalanceCents,
      'currentBalanceCents': currentBalanceCents,
      'timelineSortOrder': timelineSortOrder.name,
      'timelineDateSortMode': timelineDateSortMode.name,
      'viewPeriodMode': viewPeriodMode.name,
      'timelineViewMode': timelineViewMode.name,
      'timelineShowClearedItems': timelineShowClearedItems,
      'timelineShowSkippedItems': timelineShowSkippedItems,
      'timelineGroupByDate': timelineGroupByDate,
      'timelineGroupByTheme': timelineGroupByTheme,
      'timelineSplitClearedAndPending': timelineSplitClearedAndPending, // [NEW]
      'timelineShowSubcategories': timelineShowSubcategories, // [NEW]
      'timelineShowPulseOriginMonth': timelineShowPulseOriginMonth,

      'timelineShowPulseOriginSheet': timelineShowPulseOriginSheet,
      'timelineShowPulseOriginGrid': timelineShowPulseOriginGrid,
      'monthTotalsDisplayMode': monthTotalsDisplayMode.name,
      'monthCardDisplayMode': monthCardDisplayMode.name,
      'multiMonthDisplayModeMonth': multiMonthDisplayModeMonth.name,
      'multiMonthDisplayModeSheet': multiMonthDisplayModeSheet.name,
      'multiMonthDisplayModeGrid': multiMonthDisplayModeGrid.name,
      'dayFormat': dayFormat.name,
      'timelineSwipeLeft': timelineSwipeLeft.name,
      'timelineSwipeRight': timelineSwipeRight.name,
      'timelineTapAction': timelineTapAction.name,
      'pulseSwipeLeft': pulseSwipeLeft.name,
      'pulseSwipeRight': pulseSwipeRight.name,
      'pulseDisplayMode': pulseDisplayMode.name,
      'enableTabSwipe': enableTabSwipe,
      'timelineUseZeroBaseline': timelineUseZeroBaseline,
      'terminologyPreset': terminologyPreset.name,
      'pulseFilterType': pulseFilterType.name,
      'pulseGroupBy': pulseGroupBy.name,
      'pulseShowArchived': pulseShowArchived,
      'categoryPresetMode': categoryPresetMode.name,
      'customExpenseCategories': customExpenseCategories,
      'customIncomeCategories': customIncomeCategories,
      'customSubcategories': customSubcategories.map(
        (key, value) => MapEntry(key, value),
      ), // [NEW]
      'moneyPotsSectionLabel': moneyPotsSectionLabel,
      'customPulseLabel': customPulseLabel,
      'customActivityLabel': customTimelineLabel,
      'customTimelineLabel': customTimelineLabel,
      'categoryIcons': categoryIcons,
      'balanceUpdatesDisabled': balanceUpdatesDisabled,
      'notificationsEnabled': notificationsEnabled,
      'dailyAlertEnabled': dailyAlertEnabled,
      'dailyAlertHour': dailyAlertHour,
      'dailyAlertMinute': dailyAlertMinute,
      'weeklyAlertEnabled': weeklyAlertEnabled,
      'weeklyAlertHour': weeklyAlertHour,
      'weeklyAlertMinute': weeklyAlertMinute,
      'weeklySummaryEnabled': weeklySummaryEnabled,
      'weeklySummaryHour': weeklySummaryHour,
      'weeklySummaryMinute': weeklySummaryMinute,
      'weekStartDay': weekStartDay,
      'dismissedInsightIds': dismissedInsightIds.toList(),
      'pinnedInsightIds': pinnedInsightIds.toList(),
      'includeInternalTransfers': includeInternalTransfers,
    };
  }

  factory AccountSettings.fromJson(Map<String, dynamic> json) {
    return AccountSettings(
      paycheckDay: json['paycheckDay'] as int?,
      paycheckBusinessAdjust: json['paycheckBusinessAdjust'] as bool? ?? false,
      paycheckBusinessAdjustDirection: _parseAdjustDirection(
        json['paycheckBusinessAdjustDirection'],
      ),
      paycheckShowMonthInTimeline:
          json['paycheckShowMonthInTimeline'] as bool? ?? false,
      startingBalanceCents: ((json['startingBalanceCents'] ??
              json['startingBalance'] ??
              json['balanceCents'] ??
              json['balance'] ??
              0) as num)
          .toInt(),
      currentBalanceCents: json['currentBalanceCents'] as int?,
      timelineSortOrder: _parseEnum(
        TimelineSortOrder.values,
        json['timelineSortOrder'],
        TimelineSortOrder.chronological,
      ),
      timelineDateSortMode: _parseEnum(
        TimelineDateSortMode.values,
        json['timelineDateSortMode'],
        TimelineDateSortMode.scheduledDate,
      ),
      viewPeriodMode: _parseEnum(
        ViewPeriodMode.values,
        json['viewPeriodMode'],
        ViewPeriodMode.calendar,
      ),
      timelineViewMode: _parseEnum(
        TimelineViewMode.values,
        json['timelineViewMode'],
        TimelineViewMode.month,
      ),
      timelineShowClearedItems:
          json['timelineShowClearedItems'] as bool? ?? true,
      timelineShowSkippedItems:
          json['timelineShowSkippedItems'] as bool? ?? false,
      timelineGroupByDate: json['timelineGroupByDate'] as bool? ?? false,
      timelineGroupByTheme: json['timelineGroupByTheme'] as bool? ?? false,
      timelineSplitClearedAndPending:
          json['timelineSplitClearedAndPending'] as bool? ?? false, // [NEW]
      timelineShowSubcategories:
          json['timelineShowSubcategories'] as bool? ?? false, // [NEW]
      timelineShowPulseOriginMonth:
          json['timelineShowPulseOriginMonth'] as bool? ??
              json['timelineShowPulseOrigin'] as bool? ??
              false,

      timelineShowPulseOriginSheet:
          json['timelineShowPulseOriginSheet'] as bool? ??
              json['timelineShowPulseOrigin'] as bool? ??
              false,
      timelineShowPulseOriginGrid:
          json['timelineShowPulseOriginGrid'] as bool? ??
              json['timelineShowPulseOrigin'] as bool? ??
              false,
      monthTotalsDisplayMode: _parseEnum(
        MonthTotalsDisplayMode.values,
        json['monthTotalsDisplayMode'],
        MonthTotalsDisplayMode.includeCleared,
      ),
      monthCardDisplayMode: _parseEnum(
        MonthCardDisplayMode.values,
        json['monthCardDisplayMode'],
        MonthCardDisplayMode.full,
      ),
      multiMonthDisplayModeMonth: _parseEnum(
        MultiMonthDisplayMode.values,
        json['multiMonthDisplayModeMonth'],
        _parseEnum(
          MultiMonthDisplayMode.values,
          json['multiMonthDisplayMode'],
          MultiMonthDisplayMode.automatic,
        ),
      ),
      multiMonthDisplayModeSheet: _parseEnum(
        MultiMonthDisplayMode.values,
        json['multiMonthDisplayModeSheet'],
        _parseEnum(
          MultiMonthDisplayMode.values,
          json['multiMonthDisplayMode'],
          MultiMonthDisplayMode.automatic,
        ),
      ),
      multiMonthDisplayModeGrid: _parseEnum(
        MultiMonthDisplayMode.values,
        json['multiMonthDisplayModeGrid'],
        _parseEnum(
          MultiMonthDisplayMode.values,
          json['multiMonthDisplayMode'],
          MultiMonthDisplayMode.automatic,
        ),
      ),
      dayFormat: _parseEnum(
        DayFormat.values,
        json['dayFormat'],
        DayFormat.number,
      ),
      timelineSwipeLeft: _parseEnum(
        TimelineSwipeAction.values,
        json['timelineSwipeLeft'],
        TimelineSwipeAction.off,
      ),
      timelineSwipeRight: _parseEnum(
        TimelineSwipeAction.values,
        json['timelineSwipeRight'],
        TimelineSwipeAction.off,
      ),
      timelineTapAction: _parseEnum(
        TimelineTapAction.values,
        json['timelineTapAction'],
        TimelineTapAction.archive,
      ),
      pulseSwipeLeft: _parseEnum(
        PulseSwipeAction.values,
        json['pulseSwipeLeft'],
        PulseSwipeAction.off,
      ),
      pulseSwipeRight: _parseEnum(
        PulseSwipeAction.values,
        json['pulseSwipeRight'],
        PulseSwipeAction.off,
      ),
      pulseDisplayMode: _parseEnum(
        PulseDisplayMode.values,
        json['pulseDisplayMode'],
        PulseDisplayMode.automatic,
      ),
      enableTabSwipe: json['enableTabSwipe'] as bool? ?? false,
      timelineUseZeroBaseline:
          json['timelineUseZeroBaseline'] as bool? ?? false,
      terminologyPreset: _parseEnum(
        TerminologyPreset.values,
        json['terminologyPreset'],
        TerminologyPreset.defaultTerms,
      ),
      pulseFilterType: _parseEnum(
        PulsesFilterType.values,
        json['pulseFilterType'],
        PulsesFilterType.all,
      ),
      pulseGroupBy: _parseEnum(
        PulsesGroupBy.values,
        json['pulseGroupBy'],
        PulsesGroupBy.none,
      ),
      pulseShowArchived: json['pulseShowArchived'] as bool? ?? false,
      categoryPresetMode: _parseEnum(
        CategoryPresetMode.values,
        json['categoryPresetMode'],
        CategoryPresetMode.defaultPresets,
      ),
      customExpenseCategories: _parseList(json['customExpenseCategories']),
      customIncomeCategories: _parseList(json['customIncomeCategories']),
      customSubcategories:
          (json['customSubcategories'] as Map<String, dynamic>?)?.map(
                (key, value) => MapEntry(
                  key,
                  (value as List<dynamic>).map((e) => e as String).toList(),
                ),
              ) ??
              const {}, // [NEW]
      moneyPotsSectionLabel: json['moneyPotsSectionLabel'] as String?,
      customPulseLabel: json['customPulseLabel'] as String?,
      customTimelineLabel: json['customTimelineLabel'] as String? ??
          json['customActivityLabel'] as String?,
      categoryIcons: (json['categoryIcons'] as Map<String, dynamic>?)?.map(
            (k, v) => MapEntry(k, v as int),
          ) ??
          const {},
      balanceUpdatesDisabled: json['balanceUpdatesDisabled'] ?? false,
      notificationsEnabled: json['notificationsEnabled'] as bool? ?? false,
      dailyAlertEnabled: json['dailyAlertEnabled'] as bool? ?? false,
      dailyAlertHour: json['dailyAlertHour'] as int? ?? 9,
      dailyAlertMinute: json['dailyAlertMinute'] as int? ?? 0,
      weeklyAlertEnabled: json['weeklyAlertEnabled'] as bool? ?? false,
      weeklyAlertHour: json['weeklyAlertHour'] as int? ?? 9,
      weeklyAlertMinute: json['weeklyAlertMinute'] as int? ?? 0,
      weeklySummaryEnabled: json['weeklySummaryEnabled'] as bool? ?? false,
      weeklySummaryHour: json['weeklySummaryHour'] as int? ?? 18,
      weeklySummaryMinute: json['weeklySummaryMinute'] as int? ?? 0,
      weekStartDay: json['weekStartDay'] as int? ?? 1,
      dismissedInsightIds: (json['dismissedInsightIds'] as List?)
              ?.map((e) => e.toString())
              .toSet() ??
          const {},
      pinnedInsightIds: (json['pinnedInsightIds'] as List?)
              ?.map((e) => e.toString())
              .toSet() ??
          const {},
      includeInternalTransfers:
          json['includeInternalTransfers'] as bool? ?? false,
    );
  }

  static List<String> _parseList(dynamic value) {
    if (value is List) {
      return value.map((e) => e.toString()).toList();
    }
    return const [];
  }

  static T _parseEnum<T extends Enum>(
    List<T> values,
    dynamic value,
    T defaultValue,
  ) {
    if (value is String) {
      return values.firstWhere(
        (e) => e.name == value,
        orElse: () => defaultValue,
      );
    }
    return defaultValue;
  }

  static PaycheckAdjustDirection _parseAdjustDirection(dynamic value) {
    if (value == null) return PaycheckAdjustDirection.before;
    if (value is String) {
      return PaycheckAdjustDirection.values.firstWhere(
        (e) => e.name == value,
        orElse: () => PaycheckAdjustDirection.before,
      );
    }
    return PaycheckAdjustDirection.before;
  }

  @override
  List<Object?> get props => [
        paycheckDay,
        paycheckBusinessAdjust,
        paycheckBusinessAdjustDirection,
        paycheckShowMonthInTimeline,
        startingBalanceCents,
        currentBalanceCents,
        timelineSortOrder,
        timelineDateSortMode,
        viewPeriodMode,
        timelineViewMode,
        timelineShowClearedItems,
        timelineShowSkippedItems,
        timelineGroupByDate,
        timelineGroupByTheme,
        timelineSplitClearedAndPending,
        timelineShowPulseOriginMonth,
        timelineShowPulseOriginSheet,
        timelineShowPulseOriginGrid,
        monthTotalsDisplayMode,
        monthCardDisplayMode,
        multiMonthDisplayModeMonth,
        multiMonthDisplayModeSheet,
        multiMonthDisplayModeGrid,
        dayFormat,
        timelineSwipeLeft,
        timelineSwipeRight,
        timelineTapAction,
        pulseSwipeLeft,
        pulseSwipeRight,
        pulseDisplayMode,
        enableTabSwipe,
        timelineUseZeroBaseline,
        terminologyPreset,
        pulseFilterType,
        pulseGroupBy,
        pulseShowArchived,
        categoryPresetMode,
        customExpenseCategories,
        customIncomeCategories,
        categoryIcons,
        moneyPotsSectionLabel,
        customPulseLabel,
        customTimelineLabel,
        balanceUpdatesDisabled,
        notificationsEnabled,
        dailyAlertEnabled,
        dailyAlertHour,
        dailyAlertMinute,
        weeklyAlertEnabled,
        weeklyAlertHour,
        weeklyAlertMinute,
        weeklySummaryEnabled,
        weeklySummaryHour,
        weeklySummaryMinute,
        weekStartDay,
        dismissedInsightIds,
        pinnedInsightIds,
        includeInternalTransfers,
      ];
}
