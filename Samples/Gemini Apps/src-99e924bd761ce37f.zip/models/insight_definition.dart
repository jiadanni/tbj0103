import 'package:expense_stalker_mobile/src/models/insight_context.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

enum InsightCategory {
  spending, // Category breakdowns
  behavioral, // Habits & patterns
  trends, // Time-based analysis
  goals, // Projections & goals
  alerts, // Unusual activity
}

enum InsightTier {
  core, // Always in carousel (if data exists)
  extended, // In "See more" section
  advanced, // Requires significant data history
}

class InsightDefinition {
  const InsightDefinition({
    required this.id,
    required this.question,
    required this.category,
    required this.tier,
    required this.minDataDays,
    required this.canGenerate,
    required this.generate,
  });

  /// Unique identifier for this insight definition
  final String id;

  /// Display question (e.g. "What do I spend the most on?")
  final String question;

  /// Category for grouping in Discover view
  final InsightCategory category;

  /// Visibility tier
  final InsightTier tier;

  /// Minimum days of history required before this insight can trigger
  final int minDataDays;

  /// Condition to check if insight is relevant for the current context
  final bool Function(InsightContext) canGenerate;

  /// Generates the actual insight (answer/icon) using the context
  final SmartInsight Function(InsightContext) generate;
}
