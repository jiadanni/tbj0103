import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/util/debt_calculator.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/util/ids.dart';

enum RecurrenceFrequency {
  weekly('Weekly'),
  biweekly('Bi-weekly'),
  monthly('Monthly'),
  quarterly('Quarterly'),
  yearly('Yearly');

  const RecurrenceFrequency(this.label);
  final String label;
}

/// Represents a scheduled change in the amount of a timeline item.
class TimelineItemValueChange extends Equatable {
  const TimelineItemValueChange({
    required this.effectiveDate,
    required this.amountMinorUnits,
  });

  /// The date when this new amount becomes effective.
  final DateTime effectiveDate;

  /// The new amount in minor units (e.g., cents).
  final int amountMinorUnits;

  @override
  List<Object?> get props => [effectiveDate, amountMinorUnits];
}

class TimelineItem extends Equatable {
  const TimelineItem({
    required this.id,
    required this.label,
    required this.amountMinorUnits,
    required this.dayOfMonth,
    required this.type,
    required this.startDate,
    this.frequency,
    this.notes,
    this.archived = false,
    this.paidOffDate,
    this.remainingBalanceMinorUnits,
    this.originalAmountMinorUnits,
    this.category,
    this.subcategory,
    this.origin,
    this.priority,
    this.isSalary = false,
    this.useAsPaycheckBoundary = false,
    this.moneyPotId,
    this.balanceCurrency,
    this.exchangeRate,
    this.useActualsForCurrentBalance,
    this.useActualsForFutureBalance,
    this.suggestedOrigins,
    this.quickAddAmounts,
    this.pausedDate,
    this.autoResumeDate,
    this.skippedDates,
    this.transactionCurrency,
    this.transactionAmountMinorUnits,
    this.valueHistory,
  });

  final TimelineItemId id;
  final String label;

  /// The base amount in minor units.
  ///
  /// If [valueHistory] is present, this serves as the fallback or initial value
  /// before any scheduled changes.
  final int amountMinorUnits;

  final int dayOfMonth;
  final DateTime startDate;
  final String? notes;
  final PulseType type;

  /// Whether this item represents income.
  bool get isIncome => type.isIncomeType;

  /// The amount in major units (e.g., dollars).
  /// Note: This assumes a 100 subunit ratio (cents).
  double get amount => amountMinorUnits / 100.0;

  final RecurrenceFrequency? frequency;
  final bool archived;
  final DateTime? paidOffDate;
  final int? remainingBalanceMinorUnits;
  final int? originalAmountMinorUnits;

  /// Optional category for organizing items (e.g., "Housing", "Food", "Salary").
  /// Unified with PulseEntry category handling.
  final String? category;

  /// Optional subcategory for more granular organization (e.g., "Rent", "Groceries").
  final String? subcategory;

  /// Optional origin/provider name (e.g., "Electric Co", "Comcast", "Acme Corp").
  /// Tracks the source or destination of the pulse.
  final String? origin;

  /// Optional priority override for insights classification.
  ///
  /// If null, priority is derived from category via [getDefaultPriority].
  /// Users can override to customize how this item is classified in insights.
  final ExpensePriority? priority;

  /// Returns the effective priority (explicit or derived from category).
  ///
  /// Used by insights calculations to classify spending.
  ExpensePriority get effectivePriority =>
      priority ?? getDefaultPriority(category, type);

  /// Whether this income item is a primary salary source.
  /// Used to identify salary pulse and optionally sync paycheck period settings.
  /// Only meaningful for recurringIncome type items.
  final bool isSalary;

  /// Whether this salary defines a paycheck period boundary.
  /// Multiple salaries can be boundaries simultaneously (e.g., dual-income households).
  /// Only meaningful for recurringIncome type items marked as isSalary.
  final bool useAsPaycheckBoundary;

  /// ID of the Money Pot linked to this timeline item.
  /// If set, the item's remaining balance may be synced with the pot.
  final MoneyPotId? moneyPotId;

  /// Currency code for the remaining balance (e.g., usd, eur).
  /// If null, the balance is in the app's default currency.
  final AppCurrency? balanceCurrency;

  /// Exchange rate: how many balance currency units per 1 pulse currency unit.
  /// Example: If loan is in USD and you pay in EUR, rate of 1.08 means 1 EUR = 1.08 USD.
  /// Used in payoff calculations to convert pulse amounts.
  final double? exchangeRate;

  /// Whether to use the actual amount spent (sum of pulse) instead of the
  /// full envelope amount when calculating the starting balance for future months.
  ///
  /// If true:
  /// - Current month: Full amount is still deducted (to show remaining budget)
  /// - Future months: Only actual spent amount from previous months is deducted
  ///
  /// If false (default):
  /// - Full amount is always deducted (standard "set aside" logic)

  /// Whether to use actual spent amount instead of budget for CURRENT balance calculation.
  /// If null, uses global setting.
  final bool? useActualsForCurrentBalance;

  /// Whether to use actual spent amount instead of budget for FUTURE balance calculation.
  /// If null, uses global setting.
  final bool? useActualsForFutureBalance;

  /// List of suggested origins (payees/merchants) for this budget item.
  /// Used to provide autocomplete suggestions when adding payments.
  final List<String>? suggestedOrigins;

  /// Custom quick add amounts for spending envelopes.
  /// If null, global settings are used.
  final List<int>? quickAddAmounts;

  /// Date when this item was paused.
  /// If set, the item will not appear in months after or including this date,
  /// unless [autoResumeDate] is reached.
  final DateTime? pausedDate;

  /// Date when this item automatically resumes after being paused.
  /// Only relevant if [pausedDate] is set.
  /// If set, the item will appear again in months on or after this date.
  final DateTime? autoResumeDate;

  /// Specific dates (normalized to UTC month) that should be skipped.
  /// Used for "Skip this month" functionality.
  final List<DateTime>? skippedDates;

  /// Currency of the original transaction, if different from account currency
  final AppCurrency? transactionCurrency;

  /// Amount in the original transaction currency
  final int? transactionAmountMinorUnits;

  /// History of value changes (e.g. salary increases, variable budgets).
  /// Should be sorted by date.
  final List<TimelineItemValueChange>? valueHistory;

  TimelineItem copyWith({
    String? label,
    int? amountMinorUnits,
    int? dayOfMonth,
    DateTime? startDate,
    Optional<String>? notes,
    PulseType? type,
    Optional<RecurrenceFrequency>? frequency,
    bool? archived,
    Optional<DateTime>? paidOffDate,
    Optional<int>? remainingBalanceMinorUnits,
    Optional<int>? originalAmountMinorUnits,
    Optional<String>? category,
    Optional<String>? subcategory,
    Optional<String>? origin,
    Optional<ExpensePriority>? priority,
    Optional<List<String>>? suggestedOrigins,
    bool? isSalary,
    bool? useAsPaycheckBoundary,
    Optional<MoneyPotId>? moneyPotId,
    Optional<AppCurrency>? balanceCurrency,
    Optional<double>? exchangeRate,
    Optional<bool>? useActualsForCurrentBalance,
    Optional<bool>? useActualsForFutureBalance,
    Optional<List<int>>? quickAddAmounts,
    Optional<DateTime>? pausedDate,
    Optional<DateTime>? autoResumeDate,
    Optional<List<DateTime>>? skippedDates,
    Optional<AppCurrency>? transactionCurrency,
    Optional<int>? transactionAmountMinorUnits,
    Optional<List<TimelineItemValueChange>>? valueHistory,
  }) {
    return TimelineItem(
      id: id,
      label: label ?? this.label,
      amountMinorUnits: amountMinorUnits ?? this.amountMinorUnits,
      dayOfMonth: dayOfMonth ?? this.dayOfMonth,
      startDate: startDate ?? this.startDate,
      notes: notes != null ? notes.value : this.notes,
      type: type ?? this.type,
      frequency: frequency != null ? frequency.value : this.frequency,
      archived: archived ?? this.archived,
      paidOffDate: paidOffDate != null ? paidOffDate.value : this.paidOffDate,
      remainingBalanceMinorUnits: remainingBalanceMinorUnits != null
          ? remainingBalanceMinorUnits.value
          : this.remainingBalanceMinorUnits,
      originalAmountMinorUnits: originalAmountMinorUnits != null
          ? originalAmountMinorUnits.value
          : this.originalAmountMinorUnits,
      category: category != null ? category.value : this.category,
      subcategory: subcategory != null ? subcategory.value : this.subcategory,
      origin: origin != null ? origin.value : this.origin,
      priority: priority != null ? priority.value : this.priority,
      suggestedOrigins: suggestedOrigins != null
          ? suggestedOrigins.value
          : this.suggestedOrigins,
      isSalary: isSalary ?? this.isSalary,
      useAsPaycheckBoundary:
          useAsPaycheckBoundary ?? this.useAsPaycheckBoundary,
      moneyPotId: moneyPotId != null ? moneyPotId.value : this.moneyPotId,
      balanceCurrency: balanceCurrency != null
          ? balanceCurrency.value
          : this.balanceCurrency,
      exchangeRate:
          exchangeRate != null ? exchangeRate.value : this.exchangeRate,
      useActualsForCurrentBalance: useActualsForCurrentBalance != null
          ? useActualsForCurrentBalance.value
          : this.useActualsForCurrentBalance,
      useActualsForFutureBalance: useActualsForFutureBalance != null
          ? useActualsForFutureBalance.value
          : this.useActualsForFutureBalance,
      quickAddAmounts: quickAddAmounts != null
          ? quickAddAmounts.value
          : this.quickAddAmounts,
      pausedDate: pausedDate != null ? pausedDate.value : this.pausedDate,
      autoResumeDate:
          autoResumeDate != null ? autoResumeDate.value : this.autoResumeDate,
      skippedDates:
          skippedDates != null ? skippedDates.value : this.skippedDates,
      transactionCurrency: transactionCurrency != null
          ? transactionCurrency.value
          : this.transactionCurrency,
      transactionAmountMinorUnits: transactionAmountMinorUnits != null
          ? transactionAmountMinorUnits.value
          : this.transactionAmountMinorUnits,
      valueHistory:
          valueHistory != null ? valueHistory.value : this.valueHistory,
    );
  }

  @override
  List<Object?> get props => [
        id,
        label,
        amountMinorUnits,
        dayOfMonth,
        startDate,
        notes,
        type,
        frequency,
        archived,
        paidOffDate,
        remainingBalanceMinorUnits,
        originalAmountMinorUnits,
        category,
        subcategory,
        origin,
        priority,
        suggestedOrigins,
        isSalary,
        useAsPaycheckBoundary,
        moneyPotId,
        balanceCurrency,
        exchangeRate,
        useActualsForCurrentBalance,
        useActualsForFutureBalance,
        quickAddAmounts,
        pausedDate,
        autoResumeDate,
        skippedDates,
        transactionCurrency,
        transactionAmountMinorUnits,
        valueHistory,
      ];

  /// Returns the effective amount of this item for the given date.
  ///
  /// Checks [valueHistory] for any scheduled changes. If no changes apply
  /// (or history is empty), returns the base [amountMinorUnits].
  int getAmountForDate(DateTime date) {
    if (valueHistory == null || valueHistory!.isEmpty) {
      return amountMinorUnits;
    }

    // Sort history to be safe (though it should be stored sorted)
    // We want the latest change that is on or before the given date.
    // Using Month-granularity or Date-granularity?
    // Since TimelineItems usually recur on specific days, or we check "For Month".
    //
    // Requirement: "effective dates"
    // If I have a Salary Increase on Jan 1st, 2024.
    // getAmountForDate(Jan 1, 2024) -> New Amount.
    // getAmountForDate(Dec 31, 2023) -> Old Amount.
    //
    // Timeline Logic helper normally passes the 1st of the month (e.g. Feb 1).
    // If increase was Feb 15, does it apply to Feb payload?
    // - Recurring items happen on a specific dayOfMonth.
    // - If we are calculating balance for Feb, we look if the item appears in Feb.
    // - If it appears on Feb 15, we should check amount as of Feb 15.
    //
    // So caller should ideally pass the specific occurrence date.
    // But `calculateItemNetChangeForMonth` often iterates months.
    // We should probably normalize to the occurrence date in that month.

    // Normalize date to UTC day for comparison to be safe
    final compareDate = DateMath.toUtcDate(date);

    TimelineItemValueChange? effectiveChange;

    // Iterate through sorted history (assuming sorted ascending)
    final sortedHistory = List<TimelineItemValueChange>.from(valueHistory!)
      ..sort((a, b) => a.effectiveDate.compareTo(b.effectiveDate));

    for (final change in sortedHistory) {
      final changeDate = DateMath.toUtcDate(change.effectiveDate);
      if (changeDate.isAfter(compareDate)) {
        // This change is in the future relative to `date`
        break;
      }
      effectiveChange = change;
    }

    return effectiveChange?.amountMinorUnits ?? amountMinorUnits;
  }

  /// Determines if this timeline item should be displaye in a given month.
  ///
  /// Uses the `startDate` to determine when items should begin appearing.
  /// All items respect their start date - they won't appear before it.
  ///
  /// **Semantics by PulseType:**
  /// - `oneOff`: Only appears in the month matching startDate
  /// - `debt`: Appears from startDate onwards until paid off
  /// - `recurring`: Appears based on frequency starting from startDate:
  ///   - `monthly`: Every month
  ///   - `quarterly`: Every 3 months on calendar quarter months
  ///   - `yearly`: Once per year
  ///   - `weekly`/`biweekly`: Every month (sub-monthly scheduling not yet supported)
  /// Determines if the item is currently paused for the given month.
  bool isPausedForMonth(DateTime month) {
    if (pausedDate == null) return false;

    final normalizedMonth = DateMath.toUtcMonth(month);
    final normalizedPaused = DateMath.toUtcMonth(pausedDate!);

    // Not paused if month is before the pause start
    if (normalizedMonth.isBefore(normalizedPaused)) return false;

    if (autoResumeDate != null) {
      final normalizedResume = DateMath.toUtcMonth(autoResumeDate!);
      // Paused if we haven't reached the resume date yet
      return normalizedMonth.isBefore(normalizedResume);
    }

    return true; // Paused indefinitely
  }

  /// Determines if this item instance specifically has been skipped.
  bool isSkippedInMonth(DateTime month) {
    if (isPausedForMonth(month)) return true;
    if (skippedDates == null) return false;
    final normalizedMonth = DateMath.toUtcMonth(month);
    return skippedDates!.any(
      (d) => DateMath.toUtcMonth(d).isAtSameMomentAs(normalizedMonth),
    );
  }

  bool shouldAppearInMonth(
    DateTime month, {
    bool ignoreSkips = false,
    DateTime? referenceDate,
  }) {
    // Normalize to month-only for comparison (using UTC)
    final normalizedMonth = DateMath.toUtcMonth(month);
    final normalizedStart = DateMath.toUtcMonth(startDate);

    // Item shouldn't appear before its start date
    if (normalizedMonth.isBefore(normalizedStart)) {
      return false;
    }

    // Check strict skips
    if (!ignoreSkips && skippedDates != null) {
      if (skippedDates!.any(
        (d) => DateMath.toUtcMonth(d).isAtSameMomentAs(normalizedMonth),
      )) {
        return false;
      }
    }

    // Check pause window
    if (pausedDate != null) {
      final normalizedPaused = DateMath.toUtcMonth(pausedDate!);
      // If we are in or after the paused month...
      if (!normalizedMonth.isBefore(normalizedPaused)) {
        // ...check if we have resumed
        if (autoResumeDate != null) {
          final normalizedResume = DateMath.toUtcMonth(autoResumeDate!);
          // If we haven't reached the resume date yet, hide it UNLESS ignoreSkips is true
          if (normalizedMonth.isBefore(normalizedResume)) {
            return ignoreSkips;
          }
        } else {
          // No resume date -> Paused indefinitely UNLESS ignoreSkips is true
          return ignoreSkips;
        }
      }
    }

    // One-off items only appear in their start month
    if (type == PulseType.oneOff || type == PulseType.oneOffIncome) {
      return normalizedMonth.year == normalizedStart.year &&
          normalizedMonth.month == normalizedStart.month;
    }

    // Check frequency recurrence (if set)
    if (frequency != null) {
      final monthsSinceStart = month_math.monthsBetween(
        normalizedStart,
        normalizedMonth,
      );

      final bucket = switch (frequency!) {
        RecurrenceFrequency.weekly ||
        RecurrenceFrequency.biweekly ||
        RecurrenceFrequency.monthly =>
          1,
        RecurrenceFrequency.quarterly => 3,
        RecurrenceFrequency.yearly => 12,
      };

      if (monthsSinceStart % bucket != 0) return false;

      // Ensure the occurrence date in this month is not before the actual start date
      final dayInMonth = _effectiveDayOfMonth(
        normalizedMonth.year,
        normalizedMonth.month,
      );
      final occurrenceDate = DateTime.utc(
        normalizedMonth.year,
        normalizedMonth.month,
        dayInMonth,
      );
      if (occurrenceDate.isBefore(DateMath.toUtcDate(startDate))) {
        return false;
      }
    }

    // Debt items have additional end-date logic
    if (type == PulseType.debt) {
      if (paidOffDate != null) {
        final normalizedPaidOff = DateMath.toUtcMonth(paidOffDate!);
        return !normalizedMonth.isAfter(normalizedPaidOff);
      }

      if (remainingBalanceMinorUnits != null &&
          remainingBalanceMinorUnits! <= 0) {
        return false;
      }

      // If no manual paid off date, use calculated final pulse date
      // Use provided referenceDate or default to now (but ideally should be provided for consistency)
      final calculatedFinalDate = calculateFinalPulseDate(
        fromDate: referenceDate,
      );
      if (calculatedFinalDate != null) {
        final normalizedFinalDate = DateMath.toUtcMonth(calculatedFinalDate);
        return !normalizedMonth.isAfter(normalizedFinalDate);
      }
    }

    return true;
  }

  int _effectiveDayOfMonth(int year, int month) {
    final maxDay = DateTime.utc(year, month + 1, 0).day;
    return dayOfMonth <= maxDay ? dayOfMonth : maxDay;
  }

  /// Calculates the estimated final pulse date for debt items.
  ///
  /// Returns null if:
  /// - Item is not a debt type
  /// - No remaining balance is set
  /// - Pulse amount is zero or negative
  /// - No frequency is set
  /// - Calculated payoff exceeds 100 years (sanity check)
  ///
  /// The calculation assumes regular pulse of `amountMinorUnits` at the
  /// specified `frequency` starting from the next scheduled occurrence
  /// on or after `fromDate` (defaults to now).
  DateTime? calculateFinalPulseDate({DateTime? fromDate}) {
    return DebtCalculator.calculateFinalPulseDate(
      type: type,
      remainingBalanceMinorUnits: remainingBalanceMinorUnits,
      amountMinorUnits: amountMinorUnits,
      frequency: frequency,
      startDate: startDate,
      exchangeRate: exchangeRate,
      fromDate: fromDate,
    );
  }

  /// Returns the progress percentage (0-100) of debt pulse.
  ///
  /// Returns null if not applicable (not debt or no remaining balance set).
  /// Calculates progress as: (originalAmount - remainingBalance) / originalAmount * 100
  double? getDebtProgressPercentage() {
    if (type != PulseType.debt || remainingBalanceMinorUnits == null) {
      return null;
    }
    if (remainingBalanceMinorUnits! <= 0) return 100.0;

    // If originalAmountMinorUnits is not set, fall back to using remainingBalance as original
    final original = originalAmountMinorUnits ?? remainingBalanceMinorUnits!;
    if (original <= 0) return 0.0;

    final paid = original - remainingBalanceMinorUnits!;
    final percentage = (paid / original) * 100.0;

    // Clamp between 0 and 100
    return percentage.clamp(0.0, 100.0);
  }
}
