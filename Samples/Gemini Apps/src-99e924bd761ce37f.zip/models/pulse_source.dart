import 'package:equatable/equatable.dart';

/// Represents the origin/source of a pulse entry for tracking and filtering.
///
/// This enum enables tracking where each transaction originated, which is useful for:
/// - Filtering imported vs manually entered transactions
/// - Tracking round-trip CSV editing workflows
/// - Identifying bank statement imports for special handling
enum PulseSource {
  /// Manually created by user in the app.
  manual,

  /// Generated from a recurring timeline item payment.
  timeline,

  /// Imported from an Expense Stalker CSV export (round-trip editing).
  csvRoundTrip,

  /// Imported from a bank statement CSV with column mapping.
  bankImport,

  /// Imported from a generic CSV with custom mapping.
  csvMapped,
}

extension PulseSourceExtension on PulseSource {
  /// Human-readable label for this source.
  String get label {
    switch (this) {
      case PulseSource.manual:
        return 'Manual Entry';
      case PulseSource.timeline:
        return 'From Budget';
      case PulseSource.csvRoundTrip:
        return 'CSV Import (Round-trip)';
      case PulseSource.bankImport:
        return 'Bank Statement Import';
      case PulseSource.csvMapped:
        return 'CSV Import (Mapped)';
    }
  }

  /// Returns true if this source represents any type of import.
  bool get isImported =>
      this == PulseSource.csvRoundTrip ||
      this == PulseSource.bankImport ||
      this == PulseSource.csvMapped;

  /// Returns true if this is specifically a bank import (may need special handling).
  bool get isBankImport => this == PulseSource.bankImport;

  /// Returns true if this is a timeline-generated pulse.
  bool get isFromTimeline => this == PulseSource.timeline;

  /// Returns true if this is a manually created pulse.
  bool get isManual => this == PulseSource.manual;
}

/// Encapsulates categorization confidence scoring for imported pulses.
///
/// Used when auto-categorizing bank imports based on learned patterns.
class CategorizationConfidence extends Equatable {
  const CategorizationConfidence({required this.score, required this.matchType})
      : assert(
          score >= 0.0 && score <= 1.0,
          'Confidence score must be between 0.0 and 1.0',
        );

  /// Confidence score from 0.0 (no confidence) to 1.0 (certain match).
  final double score;

  /// Type of match that produced this confidence.
  final ConfidenceMatchType matchType;

  /// Returns true if this is a high-confidence match (>= 0.8).
  bool get isHighConfidence => score >= 0.8;

  /// Returns true if this is a medium-confidence match (>= 0.5).
  bool get isMediumConfidence => score >= 0.5;

  @override
  List<Object?> get props => [score, matchType];
}

/// Types of pattern matching used for categorization.
enum ConfidenceMatchType {
  /// Exact string match.
  exact,

  /// Fuzzy/partial string match.
  fuzzy,

  /// Pattern-based match (regex or keyword).
  pattern,

  /// No match found.
  none,
}
