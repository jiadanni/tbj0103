import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';
import 'package:expense_stalker_mobile/src/state/settings/insight_settings.dart';

/// Context object provided to [InsightDefinition.generate] and [canGenerate].
///
/// Contains all necessary data and helper methods to derive insights.
class InsightContext {
  const InsightContext({
    required this.allPulses,
    required this.filteredPulses,
    required this.timelineItems,
    required this.categorySpending,
    required this.priorityBreakdown,
    required this.currentDate,
    required this.formatMoney,
    required this.settings,
  });

  /// Full history of pulses (for trends/long-term analysis)
  final List<PulseEntry> allPulses;

  /// Pulses filtered to the current analysis period (e.g. current month)
  final List<PulseEntry> filteredPulses;

  /// Timeline items (budget/recurring expenses)
  final List<TimelineItem> timelineItems;

  /// Pre-calculated category breakdown for the current period
  final List<CategorySpending> categorySpending;

  /// Pre-calculated priority breakdown
  final PriorityBreakdown priorityBreakdown;

  /// Reference date for "now" (usually DateTime.now())
  final DateTime currentDate;

  /// Helper to format currency amounts
  final String Function(int) formatMoney;

  /// User settings for insights
  final InsightSettings settings;

  // --- Computed Helpers ---

  /// Total spending in the filtered period (excludes income)
  int get totalSpending {
    return filteredPulses
        .where((p) => !p.type.isIncomeType)
        .fold(0, (sum, p) => sum + p.amountMinorUnits.abs());
  }

  /// Approximate age of data history in days
  int get dataAgeDays {
    if (allPulses.isEmpty) return 0;
    final firstDate =
        allPulses.map((p) => p.date).reduce((a, b) => a.isBefore(b) ? a : b);
    return currentDate.difference(firstDate).inDays;
  }

  /// Returns true if there is any spending in the given category ID or label (case-insensitive)
  bool hasCategory(String categoryQuery) {
    final query = categoryQuery.toLowerCase();
    return categorySpending.any(
      (c) => c.category.toLowerCase().contains(query),
    );
  }

  /// Returns total spending for a category in the current period
  int categoryTotal(String categoryQuery) {
    final query = categoryQuery.toLowerCase();
    final match = categorySpending
        .where((c) => c.category.toLowerCase().contains(query))
        .firstOrNull;
    return match?.totalMinorUnits ?? 0;
  }

  /// Returns pulses in the current period matching the category
  List<PulseEntry> pulsesInCategory(String categoryQuery) {
    final query = categoryQuery.toLowerCase();
    return filteredPulses.where((p) {
      final cat = p.category?.toLowerCase() ?? '';
      return cat.contains(query);
    }).toList();
  }
}
