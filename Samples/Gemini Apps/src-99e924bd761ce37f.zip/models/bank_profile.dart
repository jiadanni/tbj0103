import 'package:equatable/equatable.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/services/csv_import_service.dart';

/// Rules for detecting internal transfers.
class TransferDetectionRules extends Equatable {
  const TransferDetectionRules({
    required this.internalAccountPatterns,
    this.requireEmptyCounterparty = false,
    this.transferTypeCodes = const [],
    this.excludeNonIBANCounterparty = false,
  });

  /// Patterns in description that indicate internal account names.
  /// Example: ["Credit", "Oranje", "spaarrekening", "Savings"]
  final List<String> internalAccountPatterns;

  /// If true, only flag as internal if counterparty is empty.
  final bool requireEmptyCounterparty;

  /// Transaction type codes that indicate transfers.
  /// Example: ["GT", "OV"] for ING
  final List<String> transferTypeCodes;

  /// If true, also flag transfers to non-IBAN counterparties (card numbers).
  /// This helps detect transfers to own credit cards.
  final bool excludeNonIBANCounterparty;

  @override
  List<Object?> get props => [
        internalAccountPatterns,
        requireEmptyCounterparty,
        transferTypeCodes,
        excludeNonIBANCounterparty,
      ];

  Map<String, dynamic> toJson() => {
        'internalAccountPatterns': internalAccountPatterns,
        'requireEmptyCounterparty': requireEmptyCounterparty,
        'transferTypeCodes': transferTypeCodes,
        'excludeNonIBANCounterparty': excludeNonIBANCounterparty,
      };

  factory TransferDetectionRules.fromJson(Map<String, dynamic> json) =>
      TransferDetectionRules(
        internalAccountPatterns:
            (json['internalAccountPatterns'] as List<dynamic>)
                .map((e) => e as String)
                .toList(),
        requireEmptyCounterparty:
            json['requireEmptyCounterparty'] as bool? ?? false,
        transferTypeCodes: (json['transferTypeCodes'] as List<dynamic>?)
                ?.map((e) => e as String)
                .toList() ??
            const [],
        excludeNonIBANCounterparty:
            json['excludeNonIBANCounterparty'] as bool? ?? false,
      );
}

/// A saved bank CSV format profile for quick re-import.
///
/// Stores the column mapping and import configuration so users
/// don't have to reconfigure for each import from the same bank.
class BankProfile extends Equatable {
  const BankProfile({
    required this.id,
    required this.name,
    required this.columnMapping,
    required this.importConfig,
    this.bankIdentifier,
    this.country,
    this.description,
    this.isBuiltIn = false,
    this.lastUsed,
    this.transferRules,
  });

  /// Unique identifier for this profile.
  final String id;

  /// User-friendly name (e.g., "ING Netherlands").
  final String name;

  /// Column mapping configuration.
  final CsvColumnMapping columnMapping;

  /// Import behavior configuration.
  final CsvImportConfig importConfig;

  /// Optional identifier to auto-detect this bank from CSV headers.
  final String? bankIdentifier;

  /// Country/region (e.g., "NL", "US", "UK").
  final String? country;

  /// Description of what this profile is for.
  final String? description;

  /// Whether this is a built-in community profile.
  final bool isBuiltIn;

  /// When this profile was last used.
  final DateTime? lastUsed;

  /// Optional rules for detecting internal transfers.
  final TransferDetectionRules? transferRules;

  BankProfile copyWith({
    String? id,
    String? name,
    CsvColumnMapping? columnMapping,
    CsvImportConfig? importConfig,
    String? bankIdentifier,
    String? country,
    String? description,
    bool? isBuiltIn,
    DateTime? lastUsed,
    TransferDetectionRules? transferRules,
  }) {
    return BankProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      columnMapping: columnMapping ?? this.columnMapping,
      importConfig: importConfig ?? this.importConfig,
      bankIdentifier: bankIdentifier ?? this.bankIdentifier,
      country: country ?? this.country,
      description: description ?? this.description,
      isBuiltIn: isBuiltIn ?? this.isBuiltIn,
      lastUsed: lastUsed ?? this.lastUsed,
      transferRules: transferRules ?? this.transferRules,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'columnMapping': _columnMappingToJson(columnMapping),
        'importConfig': _importConfigToJson(importConfig),
        if (bankIdentifier != null) 'bankIdentifier': bankIdentifier,
        if (country != null) 'country': country,
        if (description != null) 'description': description,
        'isBuiltIn': isBuiltIn,
        if (lastUsed != null) 'lastUsed': lastUsed!.toIso8601String(),
        if (transferRules != null) 'transferRules': transferRules!.toJson(),
      };

  factory BankProfile.fromJson(Map<String, dynamic> json) {
    return BankProfile(
      id: json['id'] as String,
      name: json['name'] as String,
      columnMapping: _columnMappingFromJson(
        json['columnMapping'] as Map<String, dynamic>,
      ),
      importConfig: _importConfigFromJson(
        json['importConfig'] as Map<String, dynamic>,
      ),
      bankIdentifier: json['bankIdentifier'] as String?,
      country: json['country'] as String?,
      description: json['description'] as String?,
      isBuiltIn: json['isBuiltIn'] as bool? ?? false,
      lastUsed: json['lastUsed'] != null
          ? DateTime.parse(json['lastUsed'] as String)
          : null,
      transferRules: json['transferRules'] != null
          ? TransferDetectionRules.fromJson(
              json['transferRules'] as Map<String, dynamic>,
            )
          : null,
    );
  }

  static Map<String, dynamic> _columnMappingToJson(CsvColumnMapping m) => {
        'dateColumnIndex': m.dateColumnIndex,
        'amountColumnIndex': m.amountColumnIndex,
        'descriptionColumnIndex': m.descriptionColumnIndex,
        if (m.categoryColumnIndex != null)
          'categoryColumnIndex': m.categoryColumnIndex,
        if (m.debitColumnIndex != null) 'debitColumnIndex': m.debitColumnIndex,
        if (m.creditColumnIndex != null)
          'creditColumnIndex': m.creditColumnIndex,
        if (m.debitCreditIndicatorColumnIndex != null)
          'debitCreditIndicatorColumnIndex': m.debitCreditIndicatorColumnIndex,
        if (m.balanceColumnIndex != null)
          'balanceColumnIndex': m.balanceColumnIndex,
        if (m.memoColumnIndex != null) 'memoColumnIndex': m.memoColumnIndex,
      };

  static CsvColumnMapping _columnMappingFromJson(Map<String, dynamic> json) {
    return CsvColumnMapping(
      dateColumnIndex: json['dateColumnIndex'] as int,
      amountColumnIndex: json['amountColumnIndex'] as int,
      descriptionColumnIndex: json['descriptionColumnIndex'] as int,
      categoryColumnIndex: json['categoryColumnIndex'] as int?,
      debitColumnIndex: json['debitColumnIndex'] as int?,
      creditColumnIndex: json['creditColumnIndex'] as int?,
      debitCreditIndicatorColumnIndex:
          json['debitCreditIndicatorColumnIndex'] as int?,
      balanceColumnIndex: json['balanceColumnIndex'] as int?,
      memoColumnIndex: json['memoColumnIndex'] as int?,
    );
  }

  static Map<String, dynamic> _importConfigToJson(CsvImportConfig c) => {
        'dateFormat': c.dateFormat,
        'invertAmount': c.invertAmount,
        'skipFirstRow': c.skipFirstRow,
        'skipLastRow': c.skipLastRow,
        'defaultType': c.defaultType.name,
        'treatCreditsAsNegative': c.treatCreditsAsNegative,
        'useEuropeanNumberFormat': c.useEuropeanNumberFormat,
      };

  static CsvImportConfig _importConfigFromJson(Map<String, dynamic> json) {
    return CsvImportConfig(
      dateFormat: json['dateFormat'] as String,
      invertAmount: json['invertAmount'] as bool? ?? false,
      skipFirstRow: json['skipFirstRow'] as bool? ?? true,
      skipLastRow: json['skipLastRow'] as bool? ?? false,
      defaultType: PulseType.values.firstWhere(
        (t) => t.name == json['defaultType'],
        orElse: () => PulseType.oneOff,
      ),
      treatCreditsAsNegative: json['treatCreditsAsNegative'] as bool? ?? false,
      useEuropeanNumberFormat:
          json['useEuropeanNumberFormat'] as bool? ?? false,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        columnMapping,
        importConfig,
        bankIdentifier,
        country,
        description,
        isBuiltIn,
        lastUsed,
        transferRules,
      ];
}

/// Pre-built community bank profiles for common banks.
class CommunityBankProfiles {
  CommunityBankProfiles._();

  static final List<BankProfile> profiles = [
    // Netherlands
    _ingNetherlands,
    _rabobankNetherlands,
    _abnAmroNetherlands,

    // United States
    _chaseUS,
    _bankOfAmerica,
    _wellsFargo,

    // United Kingdom
    _barclaysUK,
    _natwestUK,
    _hsbcUK,

    // Generic
    _genericUSFormat,
    _genericEUFormat,
  ];

  /// Try to auto-detect a bank profile from CSV headers.
  static BankProfile? detectFromHeaders(List<String> headers) {
    final headerStr = headers.join(',').toLowerCase();

    for (final profile in profiles) {
      if (profile.bankIdentifier != null &&
          headerStr.contains(profile.bankIdentifier!.toLowerCase())) {
        return profile;
      }
    }

    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Netherlands Banks
  // ─────────────────────────────────────────────────────────────────────────

  static final _ingNetherlands = const BankProfile(
    id: 'community_ing_nl',
    name: 'ING Bank',
    country: 'NL',
    description: 'ING Netherlands CSV export format',
    bankIdentifier: 'Debit/credit,Amount (EUR)',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 1,
      amountColumnIndex: 6,
      debitCreditIndicatorColumnIndex: 5,
      referenceColumnIndex: 3,
      transactionCodeColumnIndex: 4,
      metadataColumnIndex: 8,
    ),
    importConfig: CsvImportConfig(
      dateFormat: 'yyyyMMdd',
      useEuropeanNumberFormat: true,
    ),
    transferRules: TransferDetectionRules(
      internalAccountPatterns: [
        'Credit',
        'Oranje',
        'spaarrekening',
        'Afronding',
      ],
      requireEmptyCounterparty: false,
      transferTypeCodes: ['GT', 'OV'],
      excludeNonIBANCounterparty: true,
    ),
  );

  static final _rabobankNetherlands = const BankProfile(
    id: 'community_rabobank_nl',
    name: 'Rabobank',
    country: 'NL',
    description: 'Rabobank Netherlands CSV export format',
    bankIdentifier: 'IBAN/BBAN,Munt,BIC',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 4,
      descriptionColumnIndex: 19,
      amountColumnIndex: 6,
      transactionCodeColumnIndex: 14,
    ),
    importConfig: CsvImportConfig(
      dateFormat: 'yyyy-MM-dd',
      useEuropeanNumberFormat: true,
    ),
    transferRules: TransferDetectionRules(
      internalAccountPatterns: [
        'Rabobank',
        'Spaarrekening',
        'Bonusrenterekening',
        'Eigen rekening',
      ],
      requireEmptyCounterparty: false,
      transferTypeCodes: ['db', 'cb', 'id'],
    ),
  );

  static final _abnAmroNetherlands = const BankProfile(
    id: 'community_abnamro_nl',
    name: 'ABN AMRO',
    country: 'NL',
    description: 'ABN AMRO Netherlands CSV export format',
    bankIdentifier: 'Transactiedatum,Beginsaldo',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 7,
      amountColumnIndex: 6,
    ),
    importConfig: CsvImportConfig(
      dateFormat: 'yyyyMMdd',
      useEuropeanNumberFormat: true,
    ),
    transferRules: TransferDetectionRules(
      internalAccountPatterns: [
        'ABN AMRO',
        'Spaarrekening',
        'Privé Rekening',
        'Eigen rekening',
      ],
      requireEmptyCounterparty: false,
    ),
  );

  // ─────────────────────────────────────────────────────────────────────────
  // United States Banks
  // ─────────────────────────────────────────────────────────────────────────

  static final _chaseUS = const BankProfile(
    id: 'community_chase_us',
    name: 'Chase Bank',
    country: 'US',
    description: 'Chase Bank (US) CSV export format',
    bankIdentifier:
        'Transaction Date,Post Date,Description,Category,Type,Amount',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 2,
      amountColumnIndex: 5,
      categoryColumnIndex: 3,
    ),
    importConfig: CsvImportConfig(
      dateFormat: 'MM/dd/yyyy',
      invertAmount: true, // Chase shows debits as positive
    ),
  );

  static final _bankOfAmerica = const BankProfile(
    id: 'community_bofa_us',
    name: 'Bank of America',
    country: 'US',
    description: 'Bank of America CSV export format',
    bankIdentifier: 'Posted Date,Reference Number,Payee,Address',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 2,
      amountColumnIndex: 4,
    ),
    importConfig: CsvImportConfig(dateFormat: 'MM/dd/yyyy'),
  );

  static final _wellsFargo = const BankProfile(
    id: 'community_wellsfargo_us',
    name: 'Wells Fargo',
    country: 'US',
    description: 'Wells Fargo CSV export format',
    bankIdentifier: '"Date","Amount","*","Check"',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 4,
      amountColumnIndex: 1,
    ),
    importConfig: CsvImportConfig(dateFormat: 'MM/dd/yyyy'),
  );

  // ─────────────────────────────────────────────────────────────────────────
  // United Kingdom Banks
  // ─────────────────────────────────────────────────────────────────────────

  static final _barclaysUK = const BankProfile(
    id: 'community_barclays_uk',
    name: 'Barclays',
    country: 'UK',
    description: 'Barclays UK CSV export format',
    bankIdentifier: 'Number,Date,Account,Amount,Subcategory,Memo',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 1,
      descriptionColumnIndex: 5,
      amountColumnIndex: 3,
      categoryColumnIndex: 4,
    ),
    importConfig: CsvImportConfig(dateFormat: 'dd/MM/yyyy'),
  );

  static final _natwestUK = const BankProfile(
    id: 'community_natwest_uk',
    name: 'NatWest',
    country: 'UK',
    description: 'NatWest UK CSV export format',
    bankIdentifier: 'Date,Type,Description,Value,Balance,Account Name',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 2,
      amountColumnIndex: 3,
      balanceColumnIndex: 4,
    ),
    importConfig: CsvImportConfig(dateFormat: 'dd/MM/yyyy'),
  );

  static final _hsbcUK = const BankProfile(
    id: 'community_hsbc_uk',
    name: 'HSBC',
    country: 'UK',
    description: 'HSBC UK CSV export format',
    bankIdentifier: 'Date,Description,Amount',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 1,
      amountColumnIndex: 2,
    ),
    importConfig: CsvImportConfig(dateFormat: 'dd/MM/yyyy'),
  );

  // ─────────────────────────────────────────────────────────────────────────
  // Generic Formats
  // ─────────────────────────────────────────────────────────────────────────

  static final _genericUSFormat = const BankProfile(
    id: 'generic_us',
    name: 'Generic US Format',
    country: 'US',
    description: 'Generic US bank format (Date, Description, Amount)',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 1,
      amountColumnIndex: 2,
    ),
    importConfig: CsvImportConfig(dateFormat: 'MM/dd/yyyy'),
  );

  static final _genericEUFormat = const BankProfile(
    id: 'generic_eu',
    name: 'Generic EU Format',
    country: 'EU',
    description: 'Generic European bank format (Date, Description, Amount)',
    isBuiltIn: true,
    columnMapping: CsvColumnMapping(
      dateColumnIndex: 0,
      descriptionColumnIndex: 1,
      amountColumnIndex: 2,
    ),
    importConfig: CsvImportConfig(
      dateFormat: 'dd/MM/yyyy',
      useEuropeanNumberFormat: true,
    ),
  );
}
