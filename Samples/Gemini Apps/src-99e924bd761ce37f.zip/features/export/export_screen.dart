import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/features/export/csv_mapping_wizard.dart';
import 'package:expense_stalker_mobile/src/features/export/export_service.dart';
import 'package:expense_stalker_mobile/src/services/csv_import_service.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Screen for exporting and importing expense data.
///
/// Provides options to:
/// - Export all data as JSON (full backup)
/// - Export all data as CSV (for spreadsheet analysis)
/// - Import data from a JSON backup file
class ExportScreen extends StatefulWidget {
  const ExportScreen({super.key});

  @override
  State<ExportScreen> createState() => _ExportScreenState();
}

enum _ExportFormat { json, csv }

enum _JsonScope { currentAccount, allAccounts }

enum _CsvType { standard, grid, timelineOnly, pulsesOnly }

enum _ImportType { json, csv }

// Kept for backward compatibility with _activeExport tracking if needed,
// but simplified for the new UI logic.
enum _ActiveAction { export, import, settings }

class _ExportScreenState extends State<ExportScreen> {
  // Selection State
  _ExportFormat _exportFormat = _ExportFormat.json;
  _JsonScope _jsonScope = _JsonScope.currentAccount;
  _CsvType _csvType = _CsvType.standard;

  // Import State
  _ImportType? _detectedImportType;
  String? _selectedImportFilePath;
  String? _selectedImportFileName;

  DateTimeRange? _selectedDateRange;

  // Processing State
  _ActiveAction? _activeAction;

  String? _statusMessage;
  bool _isError = false;
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    _authService.initialize();
  }

  bool get _isLoading => _activeAction != null;

  void _showExportSnackBar(String message) {
    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// Returns true if [e] is a user-initiated cancellation (e.g. closing the
  /// native save dialog) and resets the loading state accordingly.
  bool _handleIfCancelled(dynamic e) {
    if (e is ExportCancelledException) {
      if (mounted) setState(() => _activeAction = null);
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final palette = _ExportPalette.of(context);
    final isDesktop = MediaQuery.of(context).size.width > 800;

    return Scaffold(
      backgroundColor: palette.backgroundBottom,
      // Always show a back button — on desktop there's no swipe-back gesture.
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const BackButton(),
      ),
      body: Stack(
        children: [
          const _ExportBackdrop(),
          SafeArea(
            child: isDesktop
                ? _buildDesktopLayout(context, palette, theme)
                : _buildMobileLayout(context, palette, theme),
          ),
        ],
      ),
    );
  }

  Widget _buildDesktopLayout(
      BuildContext context, _ExportPalette palette, ThemeData theme) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
      children: [
        _buildHeaderAndStatus(),
        const SizedBox(height: 24),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _buildExportSection(theme, palette)),
            const SizedBox(width: 24),
            Expanded(child: _buildImportSection(theme, palette)),
          ],
        ),
        const SizedBox(height: 32),
        const Divider(height: 1),
        const SizedBox(height: 24),
        _buildSettingsSection(theme, palette),
      ],
    );
  }

  Widget _buildMobileLayout(
      BuildContext context, _ExportPalette palette, ThemeData theme) {
    return DefaultTabController(
      length: 2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: _buildHeaderAndStatus(),
          ),
          const SizedBox(height: 16),
          TabBar(
            indicatorColor: palette.themeColor,
            labelColor: palette.themeColor,
            unselectedLabelColor: palette.textSecondary,
            tabs: const [
              Tab(text: 'Export'),
              Tab(text: 'Import'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    _buildExportSection(theme, palette),
                    const SizedBox(height: 32),
                    const Divider(height: 1),
                    const SizedBox(height: 24),
                    _buildSettingsSection(theme, palette),
                  ],
                ),
                ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    _buildImportSection(theme, palette),
                    const SizedBox(height: 32),
                    const Divider(height: 1),
                    const SizedBox(height: 24),
                    _buildSettingsSection(theme, palette),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderAndStatus() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _ExportHeader(
          title: AppLocalizations.of(context)?.exportAndImportTitle ??
              'Export & Import',
          subtitle:
              '${AppLocalizations.of(context)?.saveYourData ?? 'Save your data.'} '
              '${AppLocalizations.of(context)?.restoreYourData ?? 'Restore your data.'}',
        ),
        if (_statusMessage != null) ...[
          const SizedBox(height: 20),
          _ExportStatusBanner(message: _statusMessage!, isError: _isError),
        ],
      ],
    );
  }

  Widget _buildExportSection(ThemeData theme, _ExportPalette palette) {
    final isDesktop = MediaQuery.of(context).size.width > 800;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _ExportSectionTitle(
          title: 'Export Data',
          description: 'Select a format to save your data',
        ),
        const SizedBox(height: 16),
        // Enter key triggers export when focus is within this section.
        CallbackShortcuts(
          bindings: {
            const SingleActivator(LogicalKeyboardKey.enter): () {
              if (!_isLoading) _handleExport();
            },
          },
          child: _HoverCard(
            palette: palette,
            child: Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: palette.border),
              ),
              color: palette.surface,
              child: Column(
                children: [
                  if (isDesktop)
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                            child:
                                _buildExportFormatSelection(theme, palette)),
                        Container(
                            width: 1,
                            height: 200,
                            color: palette.border), // Vertical divider
                        Expanded(
                            child:
                                _buildExportScopeSelection(theme, palette)),
                      ],
                    )
                  else
                    Column(
                      children: [
                        _buildExportFormatSelection(theme, palette),
                        const Divider(height: 1),
                        _buildExportScopeSelection(theme, palette),
                      ],
                    ),

                  // Date Range Selection (Only for CSV)
                  if (_exportFormat == _ExportFormat.csv) ...[
                    const Divider(height: 1),
                    ListTile(
                      title: const Text('Date Range'),
                      subtitle: Text(
                        _selectedDateRange == null
                            ? 'All time'
                            : '${_formatDate(_selectedDateRange!.start)} - ${_formatDate(_selectedDateRange!.end)}',
                      ),
                      trailing: const Icon(Icons.calendar_today, size: 20),
                      onTap: _isLoading ? null : _pickDateRange,
                      dense: true,
                    ),
                    if (_selectedDateRange != null)
                      Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: _isLoading
                                ? null
                                : () =>
                                    setState(() => _selectedDateRange = null),
                            child: const Text('Reset to All Time'),
                          ),
                        ),
                      ),
                  ],

                  const SizedBox(height: 16),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: palette.themeColor,
                        ),
                        onPressed: _isLoading ? null : _handleExport,
                        icon: _activeAction == _ActiveAction.export
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.file_upload,
                                color: Colors.white),
                        label: Text(
                          _activeAction == _ActiveAction.export
                              ? 'Exporting...'
                              : 'Export Selected Data',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildExportFormatSelection(ThemeData theme, _ExportPalette palette) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: RadioGroup<_ExportFormat>(
        groupValue: _exportFormat,
        onChanged: (v) {
          if (!_isLoading && v != null) setState(() => _exportFormat = v);
        },
        child: Column(
          children: [
            RadioListTile<_ExportFormat>(
              title: const Text('JSON Backup'),
              subtitle: const Text('Full data backup for restoring later'),
              value: _ExportFormat.json,
              activeColor: palette.themeColor,
            ),
            RadioListTile<_ExportFormat>(
              title: const Text('CSV Spreadsheet'),
              subtitle: const Text('Export for Excel or analysis'),
              value: _ExportFormat.csv,
              activeColor: palette.themeColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExportScopeSelection(ThemeData theme, _ExportPalette palette) {
    if (_exportFormat == _ExportFormat.json) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Backup Scope',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: palette.textSecondary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            RadioGroup<_JsonScope>(
              groupValue: _jsonScope,
              onChanged: (v) {
                if (!_isLoading && v != null) setState(() => _jsonScope = v);
              },
              child: Column(
                children: [
                  RadioListTile<_JsonScope>(
                    title: const Text('Current Account Only'),
                    value: _JsonScope.currentAccount,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                  RadioListTile<_JsonScope>(
                    title: const Text('All Accounts (Full System Backup)'),
                    value: _JsonScope.allAccounts,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'CSV Type',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: palette.textSecondary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            RadioGroup<_CsvType>(
              groupValue: _csvType,
              onChanged: (v) {
                if (!_isLoading && v != null) setState(() => _csvType = v);
              },
              child: Column(
                children: [
                  RadioListTile<_CsvType>(
                    title: const Text('Standard Export'),
                    subtitle: const Text('Transactions & pulses list'),
                    value: _CsvType.standard,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                  RadioListTile<_CsvType>(
                    title: const Text('Grid View'),
                    subtitle: const Text('Multi-month spreadsheet layout'),
                    value: _CsvType.grid,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                  RadioListTile<_CsvType>(
                    title: const Text('Timeline Only'),
                    subtitle: const Text('Projected items without history'),
                    value: _CsvType.timelineOnly,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                  RadioListTile<_CsvType>(
                    title: const Text('History Only'),
                    subtitle: const Text('Paid transactions only'),
                    value: _CsvType.pulsesOnly,
                    activeColor: palette.themeColor,
                    dense: true,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildImportSection(ThemeData theme, _ExportPalette palette) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _ExportSectionTitle(
          title: 'Import Data',
          description: 'Restore data from backup or file',
        ),
        const SizedBox(height: 16),
        // Enter key triggers import when a file is selected and focus is here.
        CallbackShortcuts(
          bindings: {
            const SingleActivator(LogicalKeyboardKey.enter): () {
              if (!_isLoading &&
                  _selectedImportFilePath != null &&
                  _detectedImportType != null) {
                _handleImport();
              }
            },
          },
          child: _HoverCard(
            palette: palette,
            child: Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: palette.border),
              ),
              color: palette.surface,
              child: Column(
                children: [
                  // File Picker Zone
                  InkWell(
                    onTap: _isLoading ? null : _pickImportFile,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(12)),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: palette.surfaceAlt.withValues(alpha: 0.5),
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(12)),
                  ),
                  child: Column(
                    children: [
                      Icon(Icons.upload_file,
                          size: 48,
                          color: palette.themeColor.withValues(alpha: 0.7)),
                      const SizedBox(height: 12),
                      Text(
                        _selectedImportFileName ??
                            'Tap to select JSON or CSV file',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: _selectedImportFileName != null
                              ? palette.textPrimary
                              : palette.textSecondary,
                          fontWeight: _selectedImportFileName != null
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      if (_detectedImportType != null) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: palette.themeColor.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            _detectedImportType == _ImportType.json
                                ? 'Mode: Full Account Restore'
                                : 'Mode: Data Spreadsheet Import',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: palette.themeColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: palette.surfaceAlt,
                      foregroundColor: palette.textPrimary,
                    ),
                    onPressed: (_isLoading ||
                            _selectedImportFilePath == null ||
                            _detectedImportType == null)
                        ? null
                        : _handleImport,
                    icon: _activeAction == _ActiveAction.import
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: palette.textPrimary,
                            ),
                          )
                        : const Icon(Icons.download),
                    label: Text(
                      _activeAction == _ActiveAction.import
                          ? 'Importing...'
                          : 'Import Data',
                    ),
                  ),
                ),
              ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsSection(ThemeData theme, _ExportPalette palette) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _ExportSectionTitle(
          title: 'Settings Sync',
          description: 'Transfer app preferences between devices',
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _isLoading ? null : _exportSettings,
                icon: const Icon(Icons.settings_outlined, size: 18),
                label: const Text('Export Settings'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _isLoading ? null : _importSettings,
                icon: const Icon(Icons.settings_backup_restore, size: 18),
                label: const Text('Import Settings'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _handleExport() async {
    if (_exportFormat == _ExportFormat.json) {
      if (_jsonScope == _JsonScope.currentAccount) {
        await _exportJson();
      } else {
        await _exportAllJson();
      }
    } else {
      switch (_csvType) {
        case _CsvType.standard:
          await _exportCsv();
          break;
        case _CsvType.grid:
          await _exportGridCsv();
          break;
        case _CsvType.timelineOnly:
          await _exportTimelineOnlyCsv();
          break;
        case _CsvType.pulsesOnly:
          await _exportPulsesCsv();
          break;
      }
    }
  }

  Future<void> _pickImportFile() async {
    setState(() {
      _statusMessage = null;
      _isError = false;
    });

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json', 'csv', 'CSV'],
      allowMultiple: false,
    );

    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    if (file.path == null) return;

    final extension = file.extension?.toLowerCase();

    setState(() {
      _selectedImportFilePath = file.path;
      _selectedImportFileName = file.name;

      if (extension == 'json') {
        _detectedImportType = _ImportType.json;
      } else if (extension == 'csv') {
        _detectedImportType = _ImportType.csv;
      } else {
        _detectedImportType = null;
        _statusMessage =
            'Unrecognized file format. Please use a valid Backup JSON or CSV.';
        _isError = true;
      }
    });
  }

  Future<void> _handleImport() async {
    if (_detectedImportType == null || _selectedImportFilePath == null) return;

    switch (_detectedImportType!) {
      case _ImportType.json:
        await _importJson(filePath: _selectedImportFilePath);
        break;
      case _ImportType.csv:
        await _importCsv(filePath: _selectedImportFilePath);
        break;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final result = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 5),
      initialDateRange: _selectedDateRange,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: _ExportPalette.of(context).themeColor,
            ),
          ),
          child: child!,
        );
      },
    );

    if (result != null) {
      setState(() => _selectedDateRange = result);
    }
  }

  Future<bool> _authenticateForExport() async {
    final l10n = AppLocalizations.of(context);

    // If no PIN is set, no authentication required
    if (!await _authService.hasPIN()) {
      return true;
    }

    // Check if we should attempt biometrics (enabled in settings AND enrolled on device)
    final useBiometrics = await _authService.useBiometrics();
    final bioAvailable = await _authService.isBiometricAvailable();
    final bioTypes = await _authService.getAvailableBiometrics();
    final canUseBiometrics =
        useBiometrics && bioAvailable && bioTypes.isNotEmpty;

    if (canUseBiometrics) {
      // Attempt biometric auth
      final success = await _authService.authenticateWithBiometrics(
        reason: l10n?.authenticateToExport ?? 'Authenticate to Export',
      );

      // If biometrics failed or was cancelled, we assume the user wanted to
      // cancel the operation. We do NOT fallback to PIN here.
      if (!success && mounted) {
        setState(() {
          _statusMessage =
              l10n?.authenticationRequired ?? 'Authentication required';
          _isError = true;
        });
      }
      return success;
    }

    // Fall back to PIN dialog ONLY if biometrics were skipped (not enabled/available)
    if (!mounted) return false;
    final pinVerified = await _showPinVerifyDialog(context);
    if (!pinVerified && mounted) {
      setState(() {
        _statusMessage =
            l10n?.authenticationRequired ?? 'Authentication required';
        _isError = true;
      });
    }
    return pinVerified;
  }

  Future<bool> _showPinVerifyDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => _PinVerifyDialog(authService: _authService),
    );
    return result ?? false;
  }

  Future<void> _exportJson() async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      final currentAccountId = store.currentAccount.id;
      final relevantPots = settings.moneyPots
          .where(
            (p) =>
                p.accountIds == null ||
                p.accountIds!.isEmpty ||
                p.accountIds!.contains(currentAccountId),
          )
          .toList();

      final snapshot = store.createSnapshot(moneyPots: relevantPots);

      // Password prompt for encryption
      if (!mounted) return;
      final password = await showDialog<String>(
        context: context,
        builder: (context) => const _PasswordPromptDialog(
          title: 'Encrypt Backup?',
          message:
              'Protect your backup with AES-GCM encryption. Leave blank for unencrypted export.',
          confirmLabel: 'Export',
          isOptional: true,
        ),
      );

      if (password == null) {
        setState(() => _activeAction = null);
        return;
      }

      await ExportService.instance.exportJson(
        snapshot,
        password: password.isEmpty ? null : password,
        accountName: store.currentAccount.name,
      );

      if (mounted) {
        _showExportSnackBar(l10n?.jsonBackupReady ?? 'Backup ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.exportFailed(e.toString()) ?? 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportAllJson() async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      // We need to collect snapshots for ALL accounts
      // This is a bit inefficient as it requires loading each one
      // but backups are rare so it's fine.
      final accounts = store.accounts;
      final data = <String, ExpenseSnapshot>{};

      // Save current state first
      await store.saveNow();

      // For simplicity in this backup, we only backup the currently loaded account data
      // and whatever else is in persistence.
      // Actually, ExpensePersistence already handles multiple accounts.
      // We can iterate accounts and load snapshots.
      final persistence = store.persistence;

      for (final account in accounts) {
        final relevantPots = settings.moneyPots
            .where(
              (p) =>
                  p.accountIds == null ||
                  p.accountIds!.isEmpty ||
                  p.accountIds!.contains(account.id),
            )
            .toList();

        if (account.id == store.currentAccount.id) {
          data[account.id] = store.createSnapshot(moneyPots: relevantPots);
        } else {
          final snapshot = await persistence?.load(account.id);
          if (snapshot != null) {
            data[account.id] = ExpenseSnapshot(
              selectedMonth: snapshot.selectedMonth,
              timelineItems: snapshot.timelineItems,
              pulses: snapshot.pulses,
              accountSettings: snapshot.accountSettings,
              moneyPots: relevantPots,
            );
          }
        }
      }

      // Password prompt for encryption
      if (!mounted) return;
      final password = await showDialog<String>(
        context: context,
        builder: (context) => const _PasswordPromptDialog(
          title: 'Encrypt Full Backup?',
          message:
              'Protect your full backup (all accounts) with AES-GCM encryption. Leave blank for unencrypted export.',
          confirmLabel: 'Export All',
          isOptional: true,
        ),
      );

      if (password == null) {
        setState(() => _activeAction = null);
        return;
      }

      await ExportService.instance.exportAllAccountsJson(
        accounts,
        data,
        password: password.isEmpty ? null : password,
      );

      if (mounted) {
        _showExportSnackBar('Full backup ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage = 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportCsv() async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      final snapshot = store.createSnapshot();
      await ExportService.instance.exportCsv(
        snapshot,
        accountName: store.currentAccount.name,
        dateRange: _selectedDateRange,
      );

      if (mounted) {
        _showExportSnackBar(l10n?.csvExportReady ?? 'CSV ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.exportFailed(e.toString()) ?? 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportGridCsv() async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    if (!await _authenticateForExport()) return;
    if (!mounted) return;

    // Show month selection dialog
    final monthCount = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Select Number of Months'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_selectedDateRange != null)
              const Padding(
                padding: EdgeInsets.only(bottom: 16.0),
                child: Text(
                  'Note: Date range is selected. Grid will cover the selected range instead of a fixed number of months.',
                  style: TextStyle(fontStyle: FontStyle.italic, fontSize: 13),
                ),
              ),
            ListTile(
              title: const Text('3 months'),
              onTap: () => Navigator.pop(dialogContext, 3),
              enabled: _selectedDateRange == null,
            ),
            ListTile(
              title: const Text('6 months (recommended)'),
              onTap: () => Navigator.pop(dialogContext, 6),
              enabled: _selectedDateRange == null,
            ),
            ListTile(
              title: const Text('12 months'),
              onTap: () => Navigator.pop(dialogContext, 12),
              enabled: _selectedDateRange == null,
            ),
            ListTile(
              title: const Text('24 months'),
              onTap: () => Navigator.pop(dialogContext, 24),
              enabled: _selectedDateRange == null,
            ),
            if (_selectedDateRange != null)
              ListTile(
                title: const Text('Use Selected Date Range'),
                subtitle: Text(
                  '${_formatDate(_selectedDateRange!.start)} - ${_formatDate(_selectedDateRange!.end)}',
                ),
                onTap: () => Navigator.pop(
                  dialogContext,
                  0,
                ), // 0 to indicate range usage
                leading: const Icon(Icons.check, color: Colors.green),
              ),
          ],
        ),
      ),
    );

    if (monthCount == null) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      final snapshot = store.createSnapshot();
      await ExportService.instance.exportGridCsv(
        snapshot,
        monthCount: monthCount == 0
            ? 0
            : monthCount, // If 0, service should handle range if provided, but we pass range explicitly
        accountName: store.currentAccount.name,
        dateRange: _selectedDateRange,
      );

      if (mounted) {
        _showExportSnackBar('Grid CSV export ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.exportFailed(e.toString()) ?? 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportPulsesCsv() async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      final snapshot = store.createSnapshot();
      await ExportService.instance.exportCsv(
        snapshot,
        accountName: store.currentAccount.name,
        pulsesOnly: true,
        dateRange: _selectedDateRange,
      );

      if (mounted) {
        _showExportSnackBar('Pulses CSV export ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.exportFailed(e.toString()) ?? 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportTimelineOnlyCsv() async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.export;
      _statusMessage = null;
    });

    try {
      final snapshot = store.createSnapshot();
      await ExportService.instance.exportCsv(
        snapshot,
        accountName: store.currentAccount.name,
        timelineOnly: true,
        dateRange: _selectedDateRange,
      );

      if (mounted) {
        _showExportSnackBar('Timeline CSV export ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.exportFailed(e.toString()) ?? 'Export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _importJson({String? filePath}) async {
    final l10n = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    if (!await _authenticateForExport()) return;
    if (!mounted) return;

    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          AppLocalizations.of(dialogContext)?.importDialogTitle ??
              'Import Data',
        ),
        content: Text(
          AppLocalizations.of(dialogContext)?.importDialogMessage ??
              'Are you sure you want to import data? This may overwrite existing items.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(AppLocalizations.of(dialogContext)?.cancel ?? 'Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialogContext).colorScheme.error,
            ),
            child: Text(
              AppLocalizations.of(dialogContext)?.importAction ?? 'Import',
            ),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    setState(() {
      _activeAction = _ActiveAction.import;
      _statusMessage = null;
    });

    try {
      final result = await ExportService.instance.importJson(
        filePath: filePath,
        onPasswordRequired: () => showDialog<String>(
          context: context,
          builder: (context) => const _PasswordPromptDialog(
            title: 'Encrypted Backup',
            message:
                'This backup is encrypted. Please enter the password to unlock it.',
            confirmLabel: 'Unlock',
            isOptional: false,
            isForDecryption: true,
          ),
        ),
      );

      if (result == null || result.$1.isEmpty) {
        if (mounted) {
          setState(() {
            _activeAction = null;
            _statusMessage = l10n?.importCancelled ?? 'Import cancelled';
            _isError = false;
          });
        }
        return;
      }

      final (importedAccounts, importedData) = result;

      if (mounted) {
        // Ask user how to import
        final mode = await showDialog<_ImportMode>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Import Options'),
            content: Text(
              'Found ${importedAccounts.length} account(s) in backup. How would you like to import them?',
            ),
            actions: [
              TextButton(
                onPressed: () =>
                    Navigator.pop(dialogContext, _ImportMode.merge),
                child: const Text('Merge into Current'),
              ),
              FilledButton(
                onPressed: () =>
                    Navigator.pop(dialogContext, _ImportMode.createNew),
                child: const Text('Create New Account(s)'),
              ),
            ],
          ),
        );

        if (mode == null) {
          setState(() => _activeAction = null);
          return;
        }

        if (mode == _ImportMode.merge) {
          // Confirm overwrite with explicit account name
          if (!mounted) return;
          final currentAccountName = store.currentAccount.name;
          final confirmOverwrite = await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: Text('Overwrite "$currentAccountName"?'),
              content: Text(
                'This will merge imported data into "$currentAccountName". Existing items may be updated. This action cannot be undone.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  style: FilledButton.styleFrom(
                    backgroundColor: Theme.of(dialogContext).colorScheme.error,
                  ),
                  child: const Text('Overwrite'),
                ),
              ],
            ),
          );

          if (confirmOverwrite != true) {
            setState(() {
              _activeAction = null;
              _statusMessage = 'Import cancelled';
            });
            return;
          }

          // Merge first imported account into current
          final firstSnapshot = importedData[importedAccounts.first.id];
          if (firstSnapshot != null) {
            store.importSnapshot(firstSnapshot);

            // Import Money Pots
            for (final pot in firstSnapshot.moneyPots) {
              final existing = settings.moneyPots.cast<MoneyPot?>().firstWhere(
                    (p) => p?.id == pot.id,
                    orElse: () => null,
                  );

              if (existing != null) {
                // Pot exists. Ensure linked to current account.
                if (existing.accountIds != null &&
                    !existing.accountIds!.contains(store.currentAccount.id)) {
                  final newIds = [
                    ...existing.accountIds!,
                    store.currentAccount.id,
                  ];
                  settings.updateMoneyPot(
                    existing.copyWith(accountIds: Optional(newIds)),
                  );
                }
              } else {
                // New pot. Link to current account.
                final newPot = pot.copyWith(
                  accountIds: Optional([store.currentAccount.id]),
                );
                settings.addMoneyPot(newPot);
              }
            }
          }
        } else {
          // Create new accounts for each imported one
          for (final account in importedAccounts) {
            final snapshot = importedData[account.id];
            if (snapshot != null) {
              if (!mounted) break;
              final newAccountName = await showDialog<String>(
                context: context,
                barrierDismissible: false,
                builder: (dialogContext) => _NamePromptDialog(
                  title: 'Name Imported Account',
                  message:
                      'Enter a name for the account from "${account.name}".',
                  initialValue: account.name,
                ),
              );

              if (newAccountName == null) {
                // User cancelled the naming of this account, skip it
                continue;
              }

              await store.createAccount(newAccountName, testSize: null);
              // Find the newly created account and switch to it before importing
              // We use firstWhere instead of .last to be more robust if background updates happen
              final newAccount = store.accounts.firstWhere(
                (a) => a.name == newAccountName,
                orElse: () => store.accounts.last,
              );
              await store.switchAccount(newAccount.id);
              store.importSnapshot(snapshot);

              // Import Money Pots
              for (final pot in snapshot.moneyPots) {
                final existing = settings.moneyPots
                    .cast<MoneyPot?>()
                    .firstWhere((p) => p?.id == pot.id, orElse: () => null);

                // For new accounts, we might have ID collisions if the user imports
                // the same file multiple times creating multiple accounts.
                // However, MoneyPot IDs are UUIDs. If it's the SAME import file,
                // the MoneyPot is conceptually the same entity.
                // So we should LINK it to the new account, effectively sharing the pot.

                if (existing != null) {
                  // Pot exists. Ensure linked to NEW account.
                  if (existing.accountIds != null &&
                      !existing.accountIds!.contains(newAccount.id)) {
                    final newIds = [...existing.accountIds!, newAccount.id];
                    settings.updateMoneyPot(
                      existing.copyWith(accountIds: Optional(newIds)),
                    );
                  }
                } else {
                  // New pot. Link to NEW account.
                  final newPot = pot.copyWith(
                    accountIds: Optional([newAccount.id]),
                  );
                  settings.addMoneyPot(newPot);
                }
              }
            }
          }
        }

        _showExportSnackBar('Import successful!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage =
              l10n?.importFailed(e.toString()) ?? 'Import failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _exportSettings() async {
    final settings = AppSettingsScope.read(context);
    if (!await _authenticateForExport()) return;

    setState(() {
      _activeAction = _ActiveAction.settings;
      _statusMessage = null;
    });

    try {
      await ExportService.instance.exportSettingsJson(settings);

      if (mounted) {
        _showExportSnackBar('Settings export ready!');
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (_handleIfCancelled(e)) return;
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage = 'Settings export failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _importSettings() async {
    final settings = AppSettingsScope.read(context);
    if (!await _authenticateForExport()) return;
    if (!mounted) return;

    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Import Settings?'),
        content: const Text(
          'This will overwrite your current app settings (theme, colors, display preferences). Your account data will not be affected.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(AppLocalizations.of(dialogContext)!.cancel),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Import'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    setState(() {
      _activeAction = _ActiveAction.settings;
      _statusMessage = null;
    });

    try {
      final success = await ExportService.instance.importSettingsJson(settings);

      if (mounted) {
        if (success) {
          _showExportSnackBar('Settings imported successfully!');
        } else {
          _showExportSnackBar('Settings import cancelled');
        }
        setState(() {
          _activeAction = null;
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage = 'Settings import failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _importCsv({String? filePath}) async {
    if (!await _authenticateForExport()) return;
    if (!mounted) return;

    setState(() {
      _activeAction = _ActiveAction.import;
      _statusMessage = null;
    });

    try {
      String path;
      if (filePath != null) {
        path = filePath;
      } else {
        // Pick CSV file
        final result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['csv', 'CSV'],
        );

        if (result == null ||
            result.files.isEmpty ||
            result.files.single.path == null) {
          if (mounted) {
            setState(() {
              _activeAction = null;
              _statusMessage = 'Import cancelled';
              _isError = false;
            });
          }
          return;
        }
        path = result.files.single.path!;
      }

      final file = File(path);
      final content = await file.readAsString();

      // Detect format
      final format = CsvImportService.instance.detectFormat(content);

      if (!mounted) return;

      if (format == CsvFormat.expenseStalker) {
        // Round-trip import (simple flow)
        await _showRoundTripImportDialog(content);
      } else if (format == CsvFormat.bankStatement ||
          format == CsvFormat.generic) {
        // Bank import (requires column mapping)
        await _showBankImportDialog(content, format);
      } else {
        setState(() {
          _activeAction = null;
          _statusMessage =
              'Unrecognized CSV format. Please ensure the file is valid.';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
        return;
      }

      if (mounted) {
        setState(() {
          _activeAction = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _activeAction = null;
          _statusMessage = 'Import failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _showRoundTripImportDialog(String csvContent) async {
    final store = ExpenseStoreScope.read(context);

    // Parse CSV in background
    final result = await CsvImportService.instance.parseExpenseStalkerCsv(
      csvContent,
    );

    if (!mounted) return;

    if (!result.isSuccess) {
      setState(() {
        _statusMessage = 'Failed to parse CSV: ${result.errors.join(', ')}';
        _isError = true;
      });
      _showExportSnackBar(_statusMessage!);
      return;
    }

    // Show preview dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Import Expense Stalker CSV'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (result.accountName != null)
              Text('Account: ${result.accountName}'),
            if (result.exportDate != null)
              Text(
                'Export date: ${result.exportDate!.toLocal().toString().split(' ').first}',
              ),
            const SizedBox(height: 12),
            Text('Timeline Items: ${result.timelineItems.length}'),
            Text('Transactions: ${result.pulses.length}'),
            const SizedBox(height: 12),
            Text(
              'This will ADD ${result.totalItems} items to your current account. Existing items with the same ID will be updated.',
              style: Theme.of(dialogContext).textTheme.bodySmall,
            ),
            if (result.warnings.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'Warnings: ${result.warnings.join(', ')}',
                style: Theme.of(dialogContext).textTheme.bodySmall?.copyWith(
                      color: Theme.of(dialogContext).colorScheme.error,
                    ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Import'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    // Perform import
    try {
      for (final item in result.timelineItems) {
        store.upsertTimelineItem(item);
      }
      for (final pulse in result.pulses) {
        store.upsertPulse(pulse);
      }
      await store.saveNow();

      if (mounted) {
        _showExportSnackBar(
            'Imported ${result.totalItems} items successfully!');
        setState(() {
          _statusMessage = null;
          _isError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _statusMessage = 'Import failed: $e';
          _isError = true;
        });
        _showExportSnackBar(_statusMessage!);
      }
    }
  }

  Future<void> _showBankImportDialog(
    String csvContent,
    CsvFormat format,
  ) async {
    if (!mounted) return;

    final imported = await Navigator.push<int>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            CsvMappingWizard(csvContent: csvContent, format: format),
      ),
    );

    if (imported != null && imported > 0 && mounted) {
      _showExportSnackBar('Successfully imported $imported transactions');
    }
  }
}

enum _ImportMode { merge, createNew }

class _ExportHeader extends StatelessWidget {
  const _ExportHeader({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [palette.surface, palette.surfaceAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: palette.border),
        boxShadow: [
          BoxShadow(
            color: palette.shadow,
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: palette.themeColor.withValues(alpha: 0.06),
            blurRadius: 32,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Icon with gradient background
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  palette.themeColor.withValues(alpha: 0.2),
                  palette.themeColor.withValues(alpha: 0.08),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: palette.themeColor.withValues(alpha: 0.3),
              ),
              boxShadow: [
                BoxShadow(
                  color: palette.themeColor.withValues(alpha: 0.15),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(
              Icons.import_export_rounded,
              color: palette.themeColor,
              size: 26,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: palette.textPrimary,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: textTheme.bodySmall?.copyWith(
                    color: palette.textSecondary,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportSectionTitle extends StatelessWidget {
  const _ExportSectionTitle({required this.title, required this.description});

  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    // Choose icon based on title if not provided
    final displayIcon = _getIconForTitle(title);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [palette.surfaceAlt, palette.surface],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: palette.border),
          ),
          child: Icon(displayIcon, size: 16, color: palette.themeColor),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: palette.textPrimary,
                  letterSpacing: -0.2,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                description,
                style: textTheme.bodySmall?.copyWith(
                  color: palette.textSecondary,
                  height: 1.3,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  IconData _getIconForTitle(String title) {
    if (title.contains('Export') && title.contains('Account')) {
      return Icons.file_download_outlined;
    } else if (title.contains('Import') && title.contains('Account')) {
      return Icons.file_upload_outlined;
    } else if (title.contains('Settings')) {
      return Icons.tune_outlined;
    }
    return Icons.folder_outlined;
  }
}

class _ExportStatusBanner extends StatelessWidget {
  const _ExportStatusBanner({required this.message, required this.isError});

  final String message;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final palette = _ExportPalette.of(context);
    final color = isError ? palette.errorColor : palette.themeColor;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            color.withValues(alpha: 0.12),
            color.withValues(alpha: 0.06),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withValues(alpha: 0.15),
              border: Border.all(color: color.withValues(alpha: 0.3)),
            ),
            child: Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: color,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodySmall?.copyWith(
                color: palette.textPrimary,
                fontWeight: FontWeight.w500,
                height: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A Card that lifts its shadow slightly when the mouse hovers over it,
/// giving interactive sections a tactile desktop feel.
class _HoverCard extends StatefulWidget {
  const _HoverCard({required this.child, required this.palette});

  final Widget child;
  final _ExportPalette palette;

  @override
  State<_HoverCard> createState() => _HoverCardState();
}

class _HoverCardState extends State<_HoverCard> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.basic,
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: _hovered
              ? [
                  BoxShadow(
                    color: widget.palette.themeColor.withValues(alpha: 0.10),
                    blurRadius: 24,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: widget.child,
      ),
    );
  }
}

class _ExportBackdrop extends StatelessWidget {
  const _ExportBackdrop();

  @override
  Widget build(BuildContext context) {
    final palette = _ExportPalette.of(context);
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [palette.backgroundTop, palette.backgroundBottom],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -90,
              left: -40,
              child: _GlowOrb(color: palette.glowPrimary, size: 220),
            ),
            Positioned(
              top: 220,
              right: -50,
              child: _GlowOrb(color: palette.glowSecondary, size: 180),
            ),
            Positioned(
              bottom: -120,
              right: -30,
              child: _GlowOrb(color: palette.glowMuted, size: 260),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  const _GlowOrb({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
        ),
      ),
    );
  }
}

class _ExportPalette {
  const _ExportPalette({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.surface,
    required this.surfaceAlt,
    required this.border,
    required this.shadow,
    required this.textPrimary,
    required this.textSecondary,
    required this.themeColor,
    required this.errorColor,
    required this.glowPrimary,
    required this.glowSecondary,
    required this.glowMuted,
  });

  final Color backgroundTop;
  final Color backgroundBottom;
  final Color surface;
  final Color surfaceAlt;
  final Color border;
  final Color shadow;
  final Color textPrimary;
  final Color textSecondary;
  final Color themeColor;
  final Color errorColor;
  final Color glowPrimary;
  final Color glowSecondary;
  final Color glowMuted;

  static _ExportPalette of(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // All colors derived from the theme's ColorScheme for consistency
    final backgroundTop = scheme.surface;
    final backgroundBottom = scheme.surfaceContainerLowest;
    final surface = scheme.surfaceContainerHigh;
    final surfaceAlt = scheme.surfaceContainerHighest;
    final border = isDark
        ? Colors.white.withValues(alpha: 0.08)
        : Colors.black.withValues(alpha: 0.08);
    final shadow = isDark
        ? Colors.black.withValues(alpha: 0.35)
        : Colors.black.withValues(alpha: 0.08);
    final glowPrimary = scheme.primary.withValues(alpha: isDark ? 0.35 : 0.2);
    final glowSecondary = scheme.tertiary.withValues(
      alpha: isDark ? 0.25 : 0.16,
    );
    final glowMuted = scheme.secondary.withValues(alpha: isDark ? 0.2 : 0.12);

    return _ExportPalette(
      backgroundTop: backgroundTop,
      backgroundBottom: backgroundBottom,
      surface: surface,
      surfaceAlt: surfaceAlt,
      border: border,
      shadow: shadow,
      textPrimary: scheme.onSurface,
      textSecondary: scheme.onSurfaceVariant,
      themeColor: scheme.primary,
      errorColor: scheme.error,
      glowPrimary: glowPrimary,
      glowSecondary: glowSecondary,
      glowMuted: glowMuted,
    );
  }
}

/// PIN verification dialog for export/import authentication.
class _PinVerifyDialog extends StatefulWidget {
  const _PinVerifyDialog({required this.authService});

  final AuthService authService;

  @override
  State<_PinVerifyDialog> createState() => _PinVerifyDialogState();
}

class _PinVerifyDialogState extends State<_PinVerifyDialog> {
  final TextEditingController _pinController = TextEditingController();
  String? _errorMessage;
  bool _isVerifying = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_isVerifying) return;
    final l10n = AppLocalizations.of(context);
    final pin = _pinController.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorMessage = l10n?.enterPIN ?? 'Please enter your PIN');
      return;
    }

    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    final result = await widget.authService.verifyPIN(pin);
    if (!mounted) return;
    if (result == PinVerificationResult.success) {
      Navigator.pop(context, true);
      return;
    }

    setState(() {
      _isVerifying = false;
      _errorMessage = l10n?.incorrectPIN ?? 'Incorrect PIN';
      _pinController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return AlertDialog(
      title: Text(l10n?.enterYourPIN ?? 'Enter your PIN'),
      content: TextField(
        controller: _pinController,
        keyboardType: TextInputType.number,
        obscureText: true,
        maxLength: AuthService.maxPinLength,
        autofocus: true,
        decoration: InputDecoration(
          labelText: l10n?.pin ?? 'PIN',
          errorText: _errorMessage,
          counterText: '',
        ),
        onSubmitted: (_) => _verify(),
      ),
      actions: [
        TextButton(
          onPressed: _isVerifying ? null : () => Navigator.pop(context, false),
          child: Text(l10n?.cancel ?? 'Cancel'),
        ),
        FilledButton(
          onPressed: _isVerifying ? null : _verify,
          child: Text(l10n?.verify ?? 'Verify'),
        ),
      ],
    );
  }
}

/// Password prompt dialog for encrypted exports/imports.
class _PasswordPromptDialog extends StatefulWidget {
  const _PasswordPromptDialog({
    required this.title,
    required this.message,
    this.confirmLabel = 'OK',
    this.isOptional = false,
    this.isForDecryption = false,
  });

  final String title;
  final String message;
  final String confirmLabel;
  final bool isOptional;

  /// If true, skip password strength warnings (used for import/decrypt).
  final bool isForDecryption;

  @override
  State<_PasswordPromptDialog> createState() => _PasswordPromptDialogState();
}

class _PasswordPromptDialogState extends State<_PasswordPromptDialog> {
  final TextEditingController _controller = TextEditingController();
  bool _obscureText = true;
  _PasswordStrength _strength = _PasswordStrength.empty;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _updateStrength(String password) {
    setState(() {
      _strength = _calculateStrength(password);
    });
  }

  _PasswordStrength _calculateStrength(String password) {
    if (password.isEmpty) return _PasswordStrength.empty;

    final hasLetters = password.contains(RegExp(r'[a-zA-Z]'));
    final hasNumbers = password.contains(RegExp(r'[0-9]'));
    final hasSpecial = password.contains(RegExp(r'[!@#\$%^&*(),.?":{}|<>]'));
    final length = password.length;

    if (length < 8) return _PasswordStrength.weak;

    if (length >= 12 && hasLetters && hasNumbers && hasSpecial) {
      return _PasswordStrength.strong;
    }

    if (length >= 8 && (hasLetters || hasNumbers)) {
      return _PasswordStrength.medium;
    }

    return _PasswordStrength.weak;
  }

  Color _getStrengthColor(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
      case _PasswordStrength.weak:
        return Colors.red;
      case _PasswordStrength.medium:
        return Colors.orange;
      case _PasswordStrength.strong:
        return Colors.green;
    }
  }

  String _getStrengthLabel(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
        return '';
      case _PasswordStrength.weak:
        return 'Weak';
      case _PasswordStrength.medium:
        return 'Medium';
      case _PasswordStrength.strong:
        return 'Strong';
    }
  }

  String _getStrengthRecommendation(_PasswordStrength strength) {
    switch (strength) {
      case _PasswordStrength.empty:
        return '';
      case _PasswordStrength.weak:
        return '8+ characters recommended.';
      case _PasswordStrength.medium:
        return 'Add special characters for a stronger password.';
      case _PasswordStrength.strong:
        return 'Great password!';
    }
  }

  Future<void> _handleSubmit() async {
    final password = _controller.text;

    // If password is empty and isOptional, warn about unencrypted export
    if (password.isEmpty && widget.isOptional) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          icon: const Icon(
            Icons.warning_amber_rounded,
            color: Colors.orange,
            size: 48,
          ),
          title: const Text('Export Without Encryption?'),
          content: const Text(
            'Your backup will NOT be encrypted. Anyone who accesses this file can read your financial data.\n\n'
            'Are you sure you want to continue without password protection?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Go Back'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              style: FilledButton.styleFrom(backgroundColor: Colors.orange),
              child: const Text('Export Unencrypted'),
            ),
          ],
        ),
      );

      if (confirmed == true && mounted) {
        Navigator.pop(context, password);
      }
      return;
    }

    // If password is weak, warn user (only for encryption, not decryption)
    if (_strength == _PasswordStrength.weak && !widget.isForDecryption) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          icon: const Icon(Icons.security, color: Colors.red, size: 48),
          title: const Text('Weak Password'),
          content: const Text(
            'Your password is less than 8 characters, making it easier to crack.\n\n'
            'For better security, we recommend using 8+ characters with a mix of letters, numbers, and symbols.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Go Back'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Continue Anyway'),
            ),
          ],
        ),
      );

      if (confirmed == true && mounted) {
        Navigator.pop(context, password);
      }
      return;
    }

    // Medium or strong password - proceed without warning
    Navigator.pop(context, password);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final strengthColor = _getStrengthColor(_strength);

    return AlertDialog(
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.message),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              obscureText: _obscureText,
              autofocus: true,
              onChanged: _updateStrength,
              decoration: InputDecoration(
                labelText: 'Password',
                hintText: widget.isOptional ? '(Optional)' : null,
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureText ? Icons.visibility : Icons.visibility_off,
                  ),
                  onPressed: () => setState(() => _obscureText = !_obscureText),
                ),
              ),
              onSubmitted: (_) => _handleSubmit(),
            ),
            // Only show strength indicator for encryption, not decryption
            if (_strength != _PasswordStrength.empty &&
                !widget.isForDecryption) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: LinearProgressIndicator(
                      value: _strength.index / 3,
                      backgroundColor: strengthColor.withValues(alpha: 0.2),
                      color: strengthColor,
                      minHeight: 4,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    _getStrengthLabel(_strength),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: strengthColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                _getStrengthRecommendation(_strength),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: _handleSubmit,
          child: Text(widget.confirmLabel),
        ),
      ],
    );
  }
}

enum _PasswordStrength { empty, weak, medium, strong }

/// Dialog for prompting for a name (e.g. account name).
class _NamePromptDialog extends StatefulWidget {
  const _NamePromptDialog({
    required this.title,
    required this.message,
    this.initialValue = '',
  });

  final String title;
  final String message;
  final String initialValue;

  @override
  State<_NamePromptDialog> createState() => _NamePromptDialogState();
}

class _NamePromptDialogState extends State<_NamePromptDialog> {
  late final TextEditingController _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final value = _controller.text.trim();
    if (value.isEmpty) {
      setState(() => _error = 'Name cannot be empty');
      return;
    }

    // Check for duplicate names in store
    final store = ExpenseStoreScope.read(context);
    if (store.accounts.any((a) => a.name == value)) {
      setState(() => _error = 'An account with this name already exists');
      return;
    }

    Navigator.pop(context, value);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.message),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            autofocus: true,
            maxLength: AppConstants.maxAccountNameLength,
            decoration: InputDecoration(
              labelText: 'Account Name',
              errorText: _error,
              border: const OutlineInputBorder(),
              counterText: '',
            ),
            onChanged: (v) {
              if (_error != null) setState(() => _error = null);
            },
            onSubmitted: (_) => _submit(),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(onPressed: _submit, child: const Text('Create')),
      ],
    );
  }
}
