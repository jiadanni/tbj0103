import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import 'package:intl/intl.dart';
import 'package:expense_stalker_mobile/src/models/bank_profile.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/services/bank_profile_service.dart';
import 'package:expense_stalker_mobile/src/services/csv_import_service.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/services/categorization_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart' as categories;
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';

/// A multi-step wizard for mapping CSV columns and importing bank statements.
///
/// Flow:
/// 1. Column Mapping - select which columns map to date, amount, description
/// 2. Configuration - date format, amount handling, skip rows
/// 3. Categorization - apply smart categorization with review
/// 4. Review & Import - final preview before import
class CsvMappingWizard extends StatefulWidget {
  const CsvMappingWizard({
    super.key,
    required this.csvContent,
    required this.format,
  });

  final String csvContent;
  final CsvFormat format;

  @override
  State<CsvMappingWizard> createState() => _CsvMappingWizardState();
}

class _CsvMappingWizardState extends State<CsvMappingWizard> {
  late PageController _pageController;
  int _currentPage = 0;

  // Parsed CSV data
  List<List<String>>? _parsedRows;
  List<String>? _headers;

  // Wizard state
  CsvColumnMapping? _columnMapping;
  CsvImportConfig? _importConfig;
  List<_MappedPulse>? _mappedPulses;
  CategorizationModel? _categorizationModel;
  int? _detectedBalanceCents;
  bool _updateBalance = false;

  // Profile state
  BankProfileService? _profileService;
  List<BankProfile> _availableProfiles = [];
  BankProfile? _selectedProfile;
  BankProfile? _detectedProfile;

  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _parseInitialData();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _parseInitialData() async {
    try {
      final rows = CsvImportService.instance.parseRawCsv(
        widget.csvContent,
        maxRows: 100,
      );
      final headers = CsvImportService.instance.getHeaders(widget.csvContent);
      final autoMapping = headers != null
          ? CsvImportService.instance.detectColumnMapping(headers)
          : null;

      // Initialize profile service and load profiles
      final storage = await StorageProvider.create();
      final profileService = BankProfileService(storage);
      final profiles = await profileService.getAllProfiles();

      // Try to auto-detect bank from headers
      BankProfile? detected;
      if (headers != null) {
        detected = profileService.detectFromHeaders(headers);
      }

      // Train categorization model from existing data
      if (mounted) {
        final store = ExpenseStoreScope.read(context);
        final model = await CategorizationService.instance
            .trainFromExistingData(store.pulses, store.timelineItems);

        setState(() {
          _parsedRows = rows;
          _headers = headers;
          _columnMapping = autoMapping;
          _categorizationModel = model;
          _profileService = profileService;
          _availableProfiles = profiles;
          _detectedProfile = detected;
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  void _nextPage() {
    if (_currentPage < 4) {
      setState(() => _currentPage++);
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      setState(() => _currentPage--);
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  /// Apply a saved profile's column mapping and config.
  void _applyProfile(BankProfile profile) {
    setState(() {
      _selectedProfile = profile;
      _columnMapping = profile.columnMapping;
      _importConfig = profile.importConfig;
    });

    // Mark as used
    _profileService?.markUsed(profile.id);
  }

  /// Show dialog to save current configuration as a profile.
  Future<void> _showSaveProfileDialog() async {
    if (_columnMapping == null || _importConfig == null) return;

    final nameController = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Save as Profile'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(
            labelText: 'Profile Name',
            hintText: 'e.g., ING Netherlands',
            border: OutlineInputBorder(),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, nameController.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      final profile = BankProfile(
        id: 'user_${DateTime.now().millisecondsSinceEpoch}',
        name: result,
        columnMapping: _columnMapping!,
        importConfig: _importConfig!,
        lastUsed: DateTime.now(),
      );

      await _profileService?.saveProfile(profile);

      // Refresh profiles list
      final profiles = await _profileService?.getAllProfiles() ?? [];
      setState(() {
        _availableProfiles = profiles;
        _selectedProfile = profile;
      });

      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Profile "$result" saved')));
      }
    }
  }

  /// Show bottom sheet to select a profile.
  void _showProfileSelector() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _ProfileSelectorSheet(
        profiles: _availableProfiles,
        detectedProfile: _detectedProfile,
        selectedProfile: _selectedProfile,
        onSelect: (profile) {
          Navigator.pop(context);
          _applyProfile(profile);
        },
      ),
    );
  }

  Future<void> _performImport() async {
    if (_mappedPulses == null) return;

    final store = ExpenseStoreScope.read(context);
    final toImport = _mappedPulses!.where((m) => m.shouldImport).toList();

    try {
      store.transaction((transaction) {
        for (final mapped in toImport) {
          transaction.upsertPulse(mapped.pulse);
        }

        // Update Account Balance if requested
        final detectedBalance = _detectedBalanceCents;
        if (_updateBalance && detectedBalance != null) {
          final settings = AppSettingsScope.read(context);
          settings.currentBalanceCents = detectedBalance;
        }

        transaction.commit();
      });

      if (mounted) {
        Navigator.pop(context, toImport.length);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Import failed: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  Future<void> _handleCancel() async {
    final navigator = Navigator.of(context);
    if (await _showExitConfirmation()) {
      if (mounted) navigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;

        final navigator = Navigator.of(context);
        final shouldPop = await _showExitConfirmation();
        if (shouldPop && mounted) {
          navigator.pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.format.label),
          leading: IconButton(
            icon: Icon(_currentPage > 0 ? Icons.arrow_back : Icons.close),
            onPressed: () async {
              if (_currentPage > 0) {
                _previousPage();
              } else {
                final navigator = Navigator.of(context);
                if (await _showExitConfirmation()) {
                  if (mounted) navigator.pop();
                }
              }
            },
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4),
            child: LinearProgressIndicator(
              value: (_currentPage + 1) / 5,
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
            ),
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? _buildErrorState()
                : _buildWizardContent(),
      ),
    );
  }

  Future<bool> _showExitConfirmation() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Discard Import?'),
            content: const Text(
              'Your mapping and categorization progress will be lost.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Keep Working'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.error,
                ),
                child: const Text('Discard'),
              ),
            ],
          ),
        ) ??
        false;
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              'Failed to parse CSV',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              _error!,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWizardContent() {
    return Column(
      children: [
        // Profile banner (only on first page)
        if (_currentPage == 0) _buildProfileBanner(),
        Expanded(
          child: PageView(
            controller: _pageController,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _ColumnMappingPage(
                headers: _headers ?? [],
                sampleRows: _parsedRows?.skip(1).take(5).toList() ?? [],
                initialMapping: _columnMapping,
                onNext: (mapping) {
                  setState(() => _columnMapping = mapping);
                  _nextPage();
                },
              ),
              _ConfigurationPage(
                sampleDates: _getSampleDates(),
                sampleAmounts: _getSampleAmounts(),
                onCancel: _handleCancel,
                onNext: (config) async {
                  setState(() => _importConfig = config);
                  await _processWithConfig();
                  _nextPage();
                },
                onSaveProfile: (config) {
                  setState(() => _importConfig = config);
                  _showSaveProfileDialog();
                },
              ),
              _LinkCategorizePage(
                mappedPulses: _mappedPulses ?? [],
                unlinkedItems: _getUnlinkedItems(),
                paycheckDay: AppSettingsScope.read(context).paycheckDay,
                categorizationModel:
                    _categorizationModel ?? const CategorizationModel.empty(),
                onCancel: _handleCancel,
                onUpdate: (pulses) {
                  setState(() => _mappedPulses = pulses);
                },
                onNext: () => _nextPage(),
              ),
              _BalanceStepPage(
                detectedBalanceCents: _detectedBalanceCents,
                updateBalance: _updateBalance,
                onCancel: _handleCancel,
                onChanged: (v) => setState(() => _updateBalance = v),
                onBalanceChanged: (v) =>
                    setState(() => _detectedBalanceCents = v),
                onNext: () => _nextPage(),
              ),
              _ReviewPage(
                mappedPulses: _mappedPulses ?? [],
                onCancel: _handleCancel,
                onImport: _performImport,
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<TimelineItem> _getUnlinkedItems() {
    if (_importConfig == null) return [];

    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final allItems = store.activeTimelineItems;

    // Filter items to the date range of the import (with some buffer)
    final startDate =
        _importConfig!.startDate?.subtract(const Duration(days: 15)) ??
            DateTime.now().subtract(const Duration(days: 60));
    final endDate = _importConfig!.endDate?.add(const Duration(days: 15)) ??
        DateTime.now().add(const Duration(days: 30));

    final candidateItems = allItems.where((item) {
      // Items that START before our import end
      return !item.startDate.isAfter(endDate);
    }).toList();

    final result = <TimelineItem>[];

    // Iterate through months in the range
    var currentMonth = monthOnly(startDate);
    while (!currentMonth.isAfter(endDate)) {
      for (final item in candidateItems) {
        if (item.shouldAppearInMonth(currentMonth)) {
          if (item.isSalary) {
            // Salary items: only include if no existing pulse covers this period.
            // For salary items in paycheck mode, we compare by PAYCHECK PERIOD rather
            // than raw calendar month. A salary payment arriving Jan 21 (business-adjusted
            // from Jan 25) logically belongs to the February period (Jan 25 – Feb 24),
            // not the January period — so we must use the period reference month to
            // avoid treating it as "uncovered" when checking the February period.
            final storePulses = store.pulses.where((p) {
              if (p.timelineItemId != item.id) return false;

              if (settings.isPaycheckModeConfigured) {
                // Compare paycheck period months, not calendar months.
                final pulsePeriodMonth =
                    PaycheckService.getCurrentPaycheckPeriodMonth(
                  p.date,
                  settings.paycheckDay!,
                );
                return pulsePeriodMonth.year == currentMonth.year &&
                    pulsePeriodMonth.month == currentMonth.month;
              }

              // Default: compare raw calendar month.
              return p.date.year == currentMonth.year &&
                  p.date.month == currentMonth.month;
            });

            if (storePulses.isEmpty) {
              if (!result.any((r) => r.id == item.id)) {
                result.add(item);
              }
            }
          } else {
            // Non-salary items: always include (many-to-one linking is supported).
            if (!result.any((r) => r.id == item.id)) {
              result.add(item);
            }
          }
        }
      }
      currentMonth = DateTime.utc(currentMonth.year, currentMonth.month + 1);
    }

    return result;
  }

  Widget _buildProfileBanner() {
    final theme = Theme.of(context);

    // Show detected profile banner
    final detected = _detectedProfile;
    if (detected != null && _selectedProfile == null) {
      return Material(
        color: theme.colorScheme.primaryContainer,
        child: InkWell(
          onTap: () => _applyProfile(detected),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Icon(
                  Icons.auto_awesome,
                  size: 20,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Detected: ${detected.name}',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (detected.description != null)
                        Text(
                          detected.description!,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer
                                .withValues(alpha: 0.8),
                          ),
                        ),
                    ],
                  ),
                ),
                FilledButton.tonal(
                  onPressed: () => _applyProfile(detected),
                  child: const Text('Apply'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Show profile selector button or selected profile
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: OutlinedButton.icon(
        onPressed: _showProfileSelector,
        icon: Icon(
          _selectedProfile != null ? Icons.check_circle : Icons.folder_open,
          size: 18,
        ),
        label: Text(_selectedProfile?.name ?? 'Load Bank Profile'),
      ),
    );
  }

  List<String> _getSampleDates() {
    if (_parsedRows == null || _columnMapping == null) return [];

    final dateIndex = _columnMapping!.dateColumnIndex;
    return _parsedRows!
        .skip(1) // Skip header
        .take(5)
        .map((row) => row.length > dateIndex ? row[dateIndex] : '')
        .where((d) => d.isNotEmpty)
        .toList();
  }

  List<String> _getSampleAmounts() {
    if (_parsedRows == null || _columnMapping == null) return [];

    final m = _columnMapping;
    if (m == null) return [];
    final rows = _parsedRows!.skip(1).take(5); // Skip header, take 5

    final amounts = <String>[];

    for (final row in rows) {
      if (m.hasSeparateDebitCredit) {
        // Collect from both debit and credit columns if available
        if (m.debitColumnIndex != null && row.length > m.debitColumnIndex!) {
          final val = row[m.debitColumnIndex!];
          if (val.isNotEmpty) amounts.add(val);
        }
        if (m.creditColumnIndex != null && row.length > m.creditColumnIndex!) {
          final val = row[m.creditColumnIndex!];
          if (val.isNotEmpty) amounts.add(val);
        }
      } else {
        // Single amount column
        final amountColumnIndex = m.amountColumnIndex;
        if (row.length > amountColumnIndex) {
          final val = row[amountColumnIndex];
          if (val.isNotEmpty) amounts.add(val);
        }
      }
    }

    return amounts;
  }

  Future<void> _processWithConfig() async {
    if (_columnMapping == null || _importConfig == null) {
      return;
    }

    try {
      final result = await CsvImportService.instance.parseBankStatementCsv(
        widget.csvContent,
        _columnMapping!,
        _importConfig!,
        transferRules: _selectedProfile?.transferRules,
      );

      final pulses = <_MappedPulse>[];

      for (final pulse in result.pulses) {
        // Apply categorization
        CategorySuggestion? suggestion;

        if (_categorizationModel != null) {
          // Pass isInternalTransfer flag to suggestCategory
          suggestion = CategorizationService.instance.suggestCategory(
            pulse.label,
            _categorizationModel!,
            isInternalTransfer: pulse.isInternalTransfer,
          );
        }

        pulses.add(
          _MappedPulse(
            pulse: suggestion != null
                ? pulse.copyWith(
                    category: suggestion.category,
                    subcategory: suggestion.subcategory,
                    categorizationConfidence: suggestion.confidence,
                  )
                : pulse,
            suggestedCategory: suggestion?.category,
            confidence: suggestion?.confidence ?? 0.0,
            rawDescription: pulse.rawImportDescription ?? '',
          ),
        );
      }

      setState(() {
        _mappedPulses = pulses;
        _detectedBalanceCents = result.detectedFinalBalanceCents;
      });
    } catch (e) {
      // Handle fatal error
      debugPrint('Error processing CSV: $e');
    }
  }
}

/// How amounts are represented in the CSV.
enum _AmountMode {
  /// Single column with positive/negative values.
  single,

  /// Separate debit and credit columns.
  separate,

  /// Amount column + separate indicator column (e.g., ING Bank).
  indicator,
}

/// Page 1: Column Mapping
class _ColumnMappingPage extends StatefulWidget {
  const _ColumnMappingPage({
    required this.headers,
    required this.sampleRows,
    required this.initialMapping,
    required this.onNext,
  });

  final List<String> headers;
  final List<List<String>> sampleRows;
  final CsvColumnMapping? initialMapping;
  final void Function(CsvColumnMapping) onNext;

  @override
  State<_ColumnMappingPage> createState() => _ColumnMappingPageState();
}

class _ColumnMappingPageState extends State<_ColumnMappingPage> {
  late int? _dateColumn;
  late int? _amountColumn;
  late int? _descriptionColumn;
  late int? _debitColumn;
  late int? _creditColumn;
  late int? _indicatorColumn;
  late int? _categoryColumn;
  late int? _referenceColumn;
  late int? _transactionCodeColumn;
  late int? _metadataColumn;
  late _AmountMode _amountMode;

  @override
  void initState() {
    super.initState();
    final m = widget.initialMapping;
    _dateColumn = m?.dateColumnIndex;
    _amountColumn = m?.amountColumnIndex;
    _descriptionColumn = m?.descriptionColumnIndex;
    _debitColumn = m?.debitColumnIndex;
    _creditColumn = m?.creditColumnIndex;
    _indicatorColumn = m?.debitCreditIndicatorColumnIndex;
    _categoryColumn = m?.categoryColumnIndex;
    _referenceColumn = m?.referenceColumnIndex;
    _transactionCodeColumn = m?.transactionCodeColumnIndex;
    _metadataColumn = m?.metadataColumnIndex;

    // Determine initial amount mode
    if (m?.hasDebitCreditIndicator ?? false) {
      _amountMode = _AmountMode.indicator;
    } else if (m?.hasSeparateDebitCredit ?? false) {
      _amountMode = _AmountMode.separate;
    } else {
      _amountMode = _AmountMode.single;
    }
  }

  bool get _useSeparateDebitCredit => _amountMode == _AmountMode.separate;

  bool get _isValid {
    if (_dateColumn == null || _descriptionColumn == null) return false;
    switch (_amountMode) {
      case _AmountMode.single:
        return _amountColumn != null;
      case _AmountMode.separate:
        return _debitColumn != null || _creditColumn != null;
      case _AmountMode.indicator:
        return _amountColumn != null && _indicatorColumn != null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Map CSV Columns', style: theme.textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                'Select which columns contain the transaction data.',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 24),

              // Column mapping dropdowns
              _buildColumnDropdown(
                label: 'Date Column *',
                value: _dateColumn,
                onChanged: (v) => setState(() => _dateColumn = v),
                icon: Icons.calendar_today,
              ),
              const SizedBox(height: 16),
              _buildColumnDropdown(
                label: 'Description/Name Column *',
                value: _descriptionColumn,
                onChanged: (v) => setState(() => _descriptionColumn = v),
                icon: Icons.notes,
              ),
              const SizedBox(height: 24),
              Text('Amount Format', style: theme.textTheme.titleSmall),
              const SizedBox(height: 8),
              SegmentedButton<_AmountMode>(
                segments: const [
                  ButtonSegment(
                    value: _AmountMode.single,
                    label: Text('Single'),
                    tooltip: 'One column with +/- amounts',
                  ),
                  ButtonSegment(
                    value: _AmountMode.separate,
                    label: Text('Separate'),
                    tooltip: 'Separate debit/credit columns',
                  ),
                  ButtonSegment(
                    value: _AmountMode.indicator,
                    label: Text('Indicator'),
                    tooltip: 'Amount + Debit/Credit indicator',
                  ),
                ],
                selected: {_amountMode},
                onSelectionChanged: (v) =>
                    setState(() => _amountMode = v.first),
              ),
              const SizedBox(height: 16),

              if (_amountMode == _AmountMode.single) ...[
                _buildColumnDropdown(
                  label: 'Amount Column *',
                  value: _amountColumn,
                  onChanged: (v) => setState(() => _amountColumn = v),
                  icon: Icons.attach_money,
                ),
              ] else if (_amountMode == _AmountMode.separate) ...[
                _buildColumnDropdown(
                  label: 'Debit Column (expenses)',
                  value: _debitColumn,
                  onChanged: (v) => setState(() => _debitColumn = v),
                  icon: Icons.arrow_downward,
                ),
                const SizedBox(height: 16),
                _buildColumnDropdown(
                  label: 'Credit Column (income)',
                  value: _creditColumn,
                  onChanged: (v) => setState(() => _creditColumn = v),
                  icon: Icons.arrow_upward,
                ),
              ] else ...[
                _buildColumnDropdown(
                  label: 'Amount Column *',
                  value: _amountColumn,
                  onChanged: (v) => setState(() => _amountColumn = v),
                  icon: Icons.attach_money,
                ),
                const SizedBox(height: 16),
                _buildColumnDropdown(
                  label: 'Debit/Credit Indicator *',
                  value: _indicatorColumn,
                  onChanged: (v) => setState(() => _indicatorColumn = v),
                  icon: Icons.swap_vert,
                ),
              ],
              const SizedBox(height: 16),

              _buildColumnDropdown(
                label: 'Category Column (optional)',
                value: _categoryColumn,
                onChanged: (v) => setState(() => _categoryColumn = v),
                icon: Icons.category,
                allowNull: true,
              ),

              const SizedBox(height: 16),

              _buildColumnDropdown(
                label: 'Reference/Counterparty (optional)',
                value: _referenceColumn,
                onChanged: (v) => setState(() => _referenceColumn = v),
                icon: Icons.person_outline,
                allowNull: true,
              ),

              const SizedBox(height: 16),

              _buildColumnDropdown(
                label: 'Transaction Code (optional)',
                value: _transactionCodeColumn,
                onChanged: (v) => setState(() => _transactionCodeColumn = v),
                icon: Icons.code,
                allowNull: true,
              ),

              const SizedBox(height: 16),

              _buildColumnDropdown(
                label: 'Metadata/Notifications (optional)',
                value: _metadataColumn,
                onChanged: (v) => setState(() => _metadataColumn = v),
                icon: Icons.info_outline,
                allowNull: true,
              ),

              const SizedBox(height: 24),

              // Data preview
              if (widget.sampleRows.isNotEmpty) ...[
                Text('Data Preview', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                _buildDataPreview(),
              ],
            ],
          ),
        ),
        _buildBottomBar(
          onNext: _isValid
              ? () => widget.onNext(
                    CsvColumnMapping(
                      dateColumnIndex: _dateColumn!,
                      amountColumnIndex: _amountColumn ?? 0,
                      descriptionColumnIndex: _descriptionColumn!,
                      categoryColumnIndex: _categoryColumn,
                      debitColumnIndex:
                          _useSeparateDebitCredit ? _debitColumn : null,
                      creditColumnIndex:
                          _useSeparateDebitCredit ? _creditColumn : null,
                      debitCreditIndicatorColumnIndex:
                          _amountMode == _AmountMode.indicator
                              ? _indicatorColumn
                              : null,
                      referenceColumnIndex: _referenceColumn,
                      transactionCodeColumnIndex: _transactionCodeColumn,
                      metadataColumnIndex: _metadataColumn,
                    ),
                  )
              : null,
        ),
      ],
    );
  }

  Widget _buildColumnDropdown({
    required String label,
    required int? value,
    required void Function(int?) onChanged,
    required IconData icon,
    bool allowNull = false,
  }) {
    // Determine the subtitle/helper text showing the detected column name
    final detectedName = value != null && value < widget.headers.length
        ? widget.headers[value]
        : null;

    return DropdownButtonFormField<int?>(
      initialValue: value,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: const OutlineInputBorder(),
        helperText:
            detectedName != null ? 'Mapped to: $detectedName' : 'Select column',
      ),
      items: [
        if (allowNull)
          const DropdownMenuItem<int?>(value: null, child: Text('Not Mapped')),
        ...widget.headers.asMap().entries.map(
              (e) => DropdownMenuItem<int?>(
                value: e.key,
                child: Text('${e.key + 1}. ${e.value}'),
              ),
            ),
      ],
      onChanged: onChanged,
    );
  }

  Widget _buildDataPreview() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(8),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          dataRowMaxHeight: 48,
          columns: [
            for (int i = 0; i < widget.headers.length; i++)
              DataColumn(
                label: Text(
                  '${i + 1}. ${widget.headers[i]}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: _getColumnColor(i),
                  ),
                ),
              ),
          ],
          rows: widget.sampleRows.map((row) {
            return DataRow(
              cells: [
                for (int i = 0; i < widget.headers.length; i++)
                  DataCell(
                    Text(
                      i < row.length ? row[i] : '',
                      style: TextStyle(color: _getColumnColor(i)),
                    ),
                  ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Color? _getColumnColor(int index) {
    final theme = Theme.of(context);
    if (index == _dateColumn) return theme.colorScheme.primary;
    if (index == _descriptionColumn) return theme.colorScheme.secondary;
    if (index == _amountColumn) return theme.colorScheme.tertiary;
    if (index == _debitColumn) return theme.colorScheme.error;
    if (index == _creditColumn) {
      return theme.colorScheme.primary.withValues(alpha: 0.8);
    }
    if (index == _referenceColumn) return theme.colorScheme.outline;
    if (index == _transactionCodeColumn) {
      return theme.colorScheme.secondary.withValues(alpha: 0.8);
    }
    if (index == _metadataColumn) {
      return theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.5);
    }
    return null;
  }

  Widget _buildBottomBar({VoidCallback? onNext}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          const Spacer(),
          FilledButton(onPressed: onNext, child: const Text('Next')),
        ],
      ),
    );
  }
}

/// Page 2: Configuration
class _ConfigurationPage extends StatefulWidget {
  const _ConfigurationPage({
    required this.sampleDates,
    required this.sampleAmounts,
    required this.onCancel,
    required this.onNext,
    this.onSaveProfile,
  });

  final List<String> sampleDates;
  final List<String> sampleAmounts;
  final VoidCallback onCancel;
  final void Function(CsvImportConfig) onNext;
  final void Function(CsvImportConfig)? onSaveProfile;

  @override
  State<_ConfigurationPage> createState() => _ConfigurationPageState();
}

class _ConfigurationPageState extends State<_ConfigurationPage> {
  String _dateFormat = 'MM/dd/yyyy';
  String _customDateFormat = '';
  bool _useCustomDateFormat = false;
  final bool _invertAmount = false;
  final bool _skipFirstRow = true;
  final bool _skipLastRow = false;
  final bool _treatCreditsAsNegative = false;
  bool _useEuropeanNumberFormat = false;
  PulseType _defaultType = PulseType.oneOff;
  DateTime? _startDate;
  DateTime? _endDate;

  final _customDateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Auto-detect date format
    // Ignore the first row for detection as it's likely a header
    final datesToAnalyze = widget.sampleDates.length > 1
        ? widget.sampleDates.skip(1).toList()
        : widget.sampleDates;

    final detected = CsvImportService.instance.detectDateFormat(datesToAnalyze);
    if (detected != null) {
      _dateFormat = detected;
    }

    // Auto-detect European format if sample amounts contain European patterns
    _useEuropeanNumberFormat = _detectEuropeanFormat();

    // Default start date is left blank (null) to include all transactions by default,
    // unless the user explicitly filters them. This ensures consistency and avoids
    // missing transactions if the user expects a full import.
  }

  bool _detectEuropeanFormat() {
    // Check sample amounts for European format patterns like "1.234,56" or "1234,56"
    for (final amount in widget.sampleAmounts) {
      // Remove currency symbols and whitespace
      final cleaned = amount.replaceAll(RegExp(r'[\$£€¥₹\s]'), '');

      // Check for comma as decimal separator
      // Case 1: "123,45" (comma, no dots)
      if (cleaned.contains(',') && !cleaned.contains('.')) {
        return true;
      }

      // Case 2: "1.234,56" (dots and commas, comma appears last)
      if (cleaned.contains(',') && cleaned.contains('.')) {
        if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
          return true;
        }
      }
    }
    return false;
  }

  @override
  void dispose() {
    _customDateController.dispose();
    super.dispose();
  }

  String get _effectiveDateFormat =>
      _useCustomDateFormat ? _customDateFormat : _dateFormat;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Import Configuration', style: theme.textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                'Adjust how the data should be interpreted.',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 24),

              // Date format - preset or custom
              DropdownButtonFormField<String>(
                initialValue: _useCustomDateFormat ? 'custom' : _dateFormat,
                decoration: const InputDecoration(
                  labelText: 'Date Format',
                  prefixIcon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'yyyyMMdd',
                    child: Text('YYYYMMDD (20241231)'),
                  ),
                  DropdownMenuItem(
                    value: 'MM/dd/yyyy',
                    child: Text('MM/DD/YYYY (01/31/2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'dd/MM/yyyy',
                    child: Text('DD/MM/YYYY (31/01/2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'yyyy-MM-dd',
                    child: Text('YYYY-MM-DD (2024-01-31)'),
                  ),
                  DropdownMenuItem(
                    value: 'M/d/yyyy',
                    child: Text('M/D/YYYY (1/31/2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'd/M/yyyy',
                    child: Text('D/M/YYYY (31/1/2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'dd-MM-yyyy',
                    child: Text('DD-MM-YYYY (31-01-2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'MM-dd-yyyy',
                    child: Text('MM-DD-YYYY (01-31-2024)'),
                  ),
                  DropdownMenuItem(
                    value: 'yyyy/MM/dd',
                    child: Text('YYYY/MM/DD (2024/01/31)'),
                  ),
                  DropdownMenuItem(
                    value: 'custom',
                    child: Text('Custom format...'),
                  ),
                ],
                onChanged: (v) {
                  if (v == 'custom') {
                    setState(() => _useCustomDateFormat = true);
                  } else {
                    setState(() {
                      _useCustomDateFormat = false;
                      _dateFormat = v ?? 'MM/dd/yyyy';
                    });
                  }
                },
              ),

              // Custom date format input
              if (_useCustomDateFormat) ...[
                const SizedBox(height: 12),
                TextField(
                  controller: _customDateController,
                  decoration: InputDecoration(
                    labelText: 'Custom Date Pattern',
                    hintText: 'e.g., dd.MM.yyyy or yyyyMMdd',
                    prefixIcon: const Icon(Icons.edit),
                    border: const OutlineInputBorder(),
                    helperText: 'Use: yyyy=year, MM=month, dd=day',
                    helperMaxLines: 2,
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.help_outline),
                      onPressed: () => _showDateFormatHelp(context),
                    ),
                  ),
                  onChanged: (v) => setState(() => _customDateFormat = v),
                ),
              ],

              if (widget.sampleDates.isNotEmpty) ...[
                const SizedBox(height: 8),
                _DateFormatPreview(
                  sampleDates: widget.sampleDates.take(3).toList(),
                  dateFormat: _effectiveDateFormat,
                ),
              ],

              const SizedBox(height: 24),

              // Default transaction type
              DropdownButtonFormField<PulseType>(
                initialValue: _defaultType,
                decoration: const InputDecoration(
                  labelText: 'Default Transaction Type',
                  prefixIcon: Icon(Icons.category),
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                    value: PulseType.oneOff,
                    child: Text('One-time Expense'),
                  ),
                  DropdownMenuItem(
                    value: PulseType.recurring,
                    child: Text('Recurring Expense'),
                  ),
                ],
                onChanged: (v) =>
                    setState(() => _defaultType = v ?? PulseType.oneOff),
              ),

              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('European Number Format'),
                subtitle: const Text('Use comma as decimal (e.g., 1.234,56)'),
                value: _useEuropeanNumberFormat,
                onChanged: (v) => setState(() => _useEuropeanNumberFormat = v),
              ),
              const SizedBox(height: 16),
              ListTile(
                title: const Text('Import Start Date'),
                subtitle: Text(
                  _startDate == null
                      ? 'No start cutoff'
                      : 'Import transactions on or after ${_startDate!.year}-${_startDate!.month.toString().padLeft(2, '0')}-${_startDate!.day.toString().padLeft(2, '0')}',
                ),
                leading: const Icon(Icons.login),
                trailing: _startDate != null
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => setState(() => _startDate = null),
                      )
                    : null,
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _startDate ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) {
                    setState(() => _startDate = picked);
                  }
                },
              ),
              ListTile(
                title: const Text('Import End Date'),
                subtitle: Text(
                  _endDate == null
                      ? 'No end cutoff'
                      : 'Import transactions on or before ${_endDate!.year}-${_endDate!.month.toString().padLeft(2, '0')}-${_endDate!.day.toString().padLeft(2, '0')}',
                ),
                leading: const Icon(Icons.logout),
                trailing: _endDate != null
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => setState(() => _endDate = null),
                      )
                    : null,
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _endDate ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) {
                    setState(() => _endDate = picked);
                  }
                },
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
        _buildBottomBar(),
      ],
    );
  }

  CsvImportConfig _buildConfig() => CsvImportConfig(
        dateFormat: _effectiveDateFormat,
        invertAmount: _invertAmount,
        skipFirstRow: _skipFirstRow,
        skipLastRow: _skipLastRow,
        defaultType: _defaultType,
        treatCreditsAsNegative: _treatCreditsAsNegative,
        useEuropeanNumberFormat: _useEuropeanNumberFormat,
        startDate: _startDate,
        endDate: _endDate,
      );

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          TextButton(onPressed: widget.onCancel, child: const Text('Cancel')),
          const Spacer(),
          if (widget.onSaveProfile != null) ...[
            OutlinedButton.icon(
              onPressed: () => widget.onSaveProfile!(_buildConfig()),
              icon: const Icon(Icons.bookmark_add_outlined, size: 18),
              label: const Text('Save Profile'),
            ),
            const SizedBox(width: 8),
          ],
          FilledButton(
            onPressed: () => widget.onNext(_buildConfig()),
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }

  void _showDateFormatHelp(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Date Format Patterns'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Use these symbols to match your date format:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 12),
              _FormatHelpRow('yyyy', '4-digit year (2024)'),
              _FormatHelpRow('yy', '2-digit year (24)'),
              _FormatHelpRow('MM', 'Month with zero (01-12)'),
              _FormatHelpRow('M', 'Month without zero (1-12)'),
              _FormatHelpRow('dd', 'Day with zero (01-31)'),
              _FormatHelpRow('d', 'Day without zero (1-31)'),
              SizedBox(height: 16),
              Text('Examples:', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              _FormatHelpRow('dd.MM.yyyy', '31.12.2024'),
              _FormatHelpRow('yyyy/MM/dd', '2024/12/31'),
              _FormatHelpRow('d-M-yy', '31-12-24'),
              _FormatHelpRow('yyyyMMdd', '20241231'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

/// Row in date format help dialog.
class _FormatHelpRow extends StatelessWidget {
  const _FormatHelpRow(this.pattern, this.example);

  final String pattern;
  final String example;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(
              pattern,
              style: const TextStyle(fontFamily: 'monospace'),
            ),
          ),
          Text(
            '→ $example',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

/// Preview showing how dates will be parsed with the selected format.
class _DateFormatPreview extends StatelessWidget {
  const _DateFormatPreview({
    required this.sampleDates,
    required this.dateFormat,
  });

  final List<String> sampleDates;
  final String dateFormat;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.preview, size: 16, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Parse Preview',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            for (final sample in sampleDates) _buildPreviewRow(sample, theme),
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewRow(String rawDate, ThemeData theme) {
    final parsed = _tryParse(rawDate);
    final isValid = parsed != null;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Expanded(
            child: Text(
              rawDate,
              style: TextStyle(
                fontFamily: 'monospace',
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Icon(
            isValid ? Icons.check_circle : Icons.error,
            size: 16,
            color:
                isValid ? theme.colorScheme.primary : theme.colorScheme.error,
          ),
          const SizedBox(width: 4),
          Text(
            isValid ? _formatParsed(parsed) : 'Invalid',
            style: TextStyle(
              fontWeight: isValid ? FontWeight.w500 : FontWeight.normal,
              color: isValid
                  ? theme.colorScheme.onSurface
                  : theme.colorScheme.error,
            ),
          ),
        ],
      ),
    );
  }

  DateTime? _tryParse(String value) {
    try {
      // Use the same parsing logic as the import service
      return CsvImportService.parseDateWithFormat(value.trim(), dateFormat);
    } catch (_) {
      return null;
    }
  }

  String _formatParsed(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

/// Page 3: Categorization Review
class _LinkCategorizePage extends StatefulWidget {
  const _LinkCategorizePage({
    required this.mappedPulses,
    required this.unlinkedItems,
    required this.onCancel,
    required this.onUpdate,
    required this.onNext,
    required this.categorizationModel,
    this.paycheckDay,
  });

  final List<_MappedPulse> mappedPulses;
  final List<TimelineItem> unlinkedItems;
  final VoidCallback onCancel;
  final void Function(List<_MappedPulse>) onUpdate;
  final VoidCallback onNext;
  final CategorizationModel categorizationModel;

  /// Paycheck day of month (1–31), passed from settings. Used to prevent two
  /// salary payments landing in the same calendar month from both auto-linking
  /// to the same salary item when they belong to different paycheck periods.
  final int? paycheckDay;

  @override
  State<_LinkCategorizePage> createState() => _LinkCategorizePageState();
}

class _LinkCategorizePageState extends State<_LinkCategorizePage> {
  late List<_MappedPulse> _pulses;
  final Set<String> _expandedGroups = {};
  _SortMode _sortMode = _SortMode.byCount;
  _FilterMode _filterMode = _FilterMode.all;

  @override
  void initState() {
    super.initState();
    _pulses = List.from(widget.mappedPulses);
    _autoLink();
  }

  @override
  void didUpdateWidget(_LinkCategorizePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.mappedPulses != oldWidget.mappedPulses) {
      _pulses = List.from(widget.mappedPulses);
      _linkedSalaryPeriods.clear();
      _autoLink();
    }
  }

  // Tracks salary items that have already been linked for a specific paycheck
  // period during _autoLink, preventing a second salary credit (from an adjacent
  // period) that arrives in the same calendar month from stealing the same link.
  // Key format: "${itemId}_${refYear}_${refMonth}"
  final _linkedSalaryPeriods = <String>{};

  void _autoLink() {
    bool changed = false;
    for (int i = 0; i < _pulses.length; i++) {
      if (_pulses[i].linkedItemId != null) continue;

      final pulse = _pulses[i].pulse;
      TimelineItem? bestMatch;
      int bestDays = 11;
      String? bestPeriodKey;

      for (final item in widget.unlinkedItems) {
        final amountDiff =
            (item.amountMinorUnits - pulse.amountMinorUnits).abs();
        final threshold = (item.amountMinorUnits.abs() * 0.05).round().clamp(
              200,
              10000,
            );
        if (amountDiff > threshold) continue;

        if (item.isSalary && widget.paycheckDay != null) {
          final refMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
            pulse.date,
            widget.paycheckDay!,
          );
          final periodKey =
              '${item.id.value}_${refMonth.year}_${refMonth.month}';
          if (_linkedSalaryPeriods.contains(periodKey)) continue;

          final dist = _minDaysAcrossAdjacentMonths(
            item.dayOfMonth,
            pulse.date,
          );
          if (dist < bestDays) {
            bestDays = dist;
            bestMatch = item;
            bestPeriodKey = periodKey;
          }
        } else {
          final pulseYear = pulse.date.year;
          final pulseMonth = pulse.date.month;
          final maxDay = DateTime.utc(pulseYear, pulseMonth + 1, 0).day;
          final effectiveDay =
              item.dayOfMonth <= maxDay ? item.dayOfMonth : maxDay;
          final expectedDate = DateTime.utc(
            pulseYear,
            pulseMonth,
            effectiveDay,
          );
          final diff = expectedDate.difference(pulse.date).inDays.abs();
          if (diff < 8 && diff < bestDays) {
            bestDays = diff;
            bestMatch = item;
            bestPeriodKey = null;
          }
        }
      }

      if (bestMatch != null) {
        if (bestPeriodKey != null) {
          _linkedSalaryPeriods.add(bestPeriodKey);
        }
        _pulses[i] = _pulses[i].copyWith(
          linkedItemId: bestMatch.id,
          pulse: _pulses[i].pulse.copyWith(
                timelineItemId: bestMatch.id,
                category: bestMatch.category,
                origin: bestMatch.label,
              ),
        );
        changed = true;
      }
    }

    if (changed) {
      widget.onUpdate(_pulses);
    }
  }

  static int _minDaysAcrossAdjacentMonths(int dayOfMonth, DateTime date) {
    var min = 999;
    for (int monthOffset = -1; monthOffset <= 1; monthOffset++) {
      final candidateMonth = DateTime.utc(date.year, date.month + monthOffset);
      final daysInMonth = DateTime.utc(
        candidateMonth.year,
        candidateMonth.month + 1,
        0,
      ).day;
      final effectiveDay = dayOfMonth <= daysInMonth ? dayOfMonth : daysInMonth;
      final expected = DateTime.utc(
        candidateMonth.year,
        candidateMonth.month,
        effectiveDay,
      );
      final dist = expected.difference(date).inDays.abs();
      if (dist < min) min = dist;
    }
    return min;
  }

  void _linkGroup(_PulseGroup group, TimelineItem item) {
    setState(() {
      for (final i in group.indices) {
        _pulses[i] = _pulses[i].copyWith(
          linkedItemId: item.id,
          pulse: _pulses[i].pulse.copyWith(
            timelineItemId: item.id,
            category: item.category,
            origin: item.label,
          ),
        );
      }
    });
    widget.onUpdate(_pulses);
  }

  void _unlinkGroup(_PulseGroup group) {
    setState(() {
      for (final i in group.indices) {
        _pulses[i] = _pulses[i].copyWith(
          linkedItemId: null,
          pulse: _pulses[i].pulse.copyWith(timelineItemId: null),
        );
      }
    });
    widget.onUpdate(_pulses);
  }

  void _updateCategory(String groupKey, String? category) {
    setState(() {
      for (int i = 0; i < _pulses.length; i++) {
        if (_pulses[i].pulse.label.toLowerCase() == groupKey) {
          _pulses[i] = _pulses[i].copyWith(
            pulse: _pulses[i].pulse.copyWith(category: category),
            wasManuallyEdited: true,
          );
        }
      }
    });
    widget.onUpdate(_pulses);
  }

  void _toggleGroupImport(String groupKey) {
    setState(() {
      final allImported = _pulses
          .where((p) => p.pulse.label.toLowerCase() == groupKey)
          .every((p) => p.shouldImport);
      final newState = !allImported;
      for (int i = 0; i < _pulses.length; i++) {
        if (_pulses[i].pulse.label.toLowerCase() == groupKey) {
          _pulses[i] = _pulses[i].copyWith(shouldImport: newState);
        }
      }
    });
    widget.onUpdate(_pulses);
  }

  void _toggleSingleImport(int index) {
    setState(() {
      _pulses[index] = _pulses[index].copyWith(
        shouldImport: !_pulses[index].shouldImport,
      );
    });
    widget.onUpdate(_pulses);
  }

  TimelineItemId? _groupLinkedItemId(_PulseGroup group) {
    final first = _pulses[group.indices.first].linkedItemId;
    if (first == null) return null;
    // All must be linked to the same item for the group to show as linked
    for (final i in group.indices) {
      if (_pulses[i].linkedItemId != first) return null;
    }
    return first;
  }

  bool _groupHasAnyLink(_PulseGroup group) {
    return group.indices.any((i) => _pulses[i].linkedItemId != null);
  }

  List<_PulseGroup> _buildGroups() {
    final groupMap = <String, _PulseGroup>{};
    for (int i = 0; i < _pulses.length; i++) {
      final key = _pulses[i].pulse.label.toLowerCase();
      if (groupMap.containsKey(key)) {
        groupMap[key]!.indices.add(i);
      } else {
        groupMap[key] = _PulseGroup(
          displayLabel: _pulses[i].pulse.label,
          groupKey: key,
          indices: [i],
        );
      }
    }

    var groups = groupMap.values.toList();

    switch (_filterMode) {
      case _FilterMode.all:
        break;
      case _FilterMode.linked:
        groups = groups.where((g) => _groupHasAnyLink(g)).toList();
      case _FilterMode.unlinked:
        groups = groups
            .where((g) => g.indices.any((i) => _pulses[i].linkedItemId == null))
            .toList();
      case _FilterMode.categorized:
        groups = groups.where((g) => g.category(_pulses) != null).toList();
      case _FilterMode.uncategorized:
        groups = groups.where((g) => g.category(_pulses) == null).toList();
      case _FilterMode.transfers:
        groups = groups.where((g) => g.isTransferGroup(_pulses)).toList();
    }

    switch (_sortMode) {
      case _SortMode.byCount:
        groups.sort((a, b) => b.count.compareTo(a.count));
      case _SortMode.alphabetical:
        groups.sort(
          (a, b) => a.displayLabel.compareTo(b.displayLabel),
        );
      case _SortMode.byTotalAmount:
        groups.sort((a, b) => a
            .totalAmount(_pulses)
            .abs()
            .compareTo(b.totalAmount(_pulses).abs()));
        groups = groups.reversed.toList();
    }

    return groups;
  }

  void _autoCategorizeRemaining() {
    setState(() {
      for (int i = 0; i < _pulses.length; i++) {
        final mapped = _pulses[i];
        if (mapped.pulse.category == null && mapped.suggestedCategory != null) {
          _pulses[i] = mapped.copyWith(
            pulse: mapped.pulse.copyWith(category: mapped.suggestedCategory),
          );
        }
      }
    });
    widget.onUpdate(_pulses);
  }

  void _cycleSortMode() {
    setState(() {
      final values = _SortMode.values;
      _sortMode = values[(_sortMode.index + 1) % values.length];
    });
  }

  IconData _sortModeIcon() {
    switch (_sortMode) {
      case _SortMode.byCount:
        return Icons.sort;
      case _SortMode.alphabetical:
        return Icons.sort_by_alpha;
      case _SortMode.byTotalAmount:
        return Icons.attach_money;
    }
  }

  String _sortModeLabel() {
    switch (_sortMode) {
      case _SortMode.byCount:
        return 'By count';
      case _SortMode.alphabetical:
        return 'Alphabetical';
      case _SortMode.byTotalAmount:
        return 'By amount';
    }
  }

  String _filterLabel(_FilterMode mode) {
    switch (mode) {
      case _FilterMode.all:
        return 'All';
      case _FilterMode.linked:
        return 'Linked';
      case _FilterMode.unlinked:
        return 'Unlinked';
      case _FilterMode.categorized:
        return 'Categorized';
      case _FilterMode.uncategorized:
        return 'Uncategorized';
      case _FilterMode.transfers:
        return 'Transfers';
    }
  }

  void _showGroupItemPicker(_PulseGroup group) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                child: Text(
                  'Link "${group.displayLabel}" (${group.count}) to Scheduled Item',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
              const Divider(),
              if (widget.unlinkedItems.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32.0),
                  child: Center(
                    child: Text('No scheduled items available to link.'),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: widget.unlinkedItems.length,
                    itemBuilder: (context, index) {
                      final item = widget.unlinkedItems[index];
                      final linkCount = _pulses
                          .where((p) => p.linkedItemId == item.id)
                          .length;

                      return ListTile(
                        title: Text(item.label),
                        subtitle: Text(
                          '${AppSettingsScope.read(context).currencySettings.currency.symbol}${(item.amountMinorUnits / 100).toStringAsFixed(2)} • day ${item.dayOfMonth} monthly',
                        ),
                        trailing: linkCount > 0
                            ? Text(
                                '$linkCount linked',
                                style: TextStyle(
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              )
                            : null,
                        onTap: () {
                          Navigator.pop(context);
                          _linkGroup(group, item);
                        },
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final settings = AppSettingsScope.read(context);
    final currencySymbol = settings.currencySettings.currency.symbol;

    final linkedCount = _pulses.where((p) => p.linkedItemId != null).length;
    final categorized =
        _pulses.where((p) => p.shouldImport && p.pulse.category != null).length;
    final importCount = _pulses.where((p) => p.shouldImport).length;
    final groups = _buildGroups();

    return Column(
      children: [
        // Summary header
        Container(
          padding: const EdgeInsets.all(16),
          color: theme.colorScheme.surfaceContainerHighest,
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Link & Categorize',
                      style: theme.textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$importCount of ${_pulses.length} to import • '
                      '$linkedCount linked • '
                      '$categorized categorized • '
                      '${groups.length} groups',
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.auto_fix_high),
                tooltip: 'Auto-link',
                onPressed: () {
                  _linkedSalaryPeriods.clear();
                  _autoLink();
                  setState(() {});
                },
              ),
              IconButton(
                icon: const Icon(Icons.category),
                tooltip: 'Auto-categorize uncategorized',
                onPressed: _autoCategorizeRemaining,
              ),
              IconButton(
                icon: Icon(_sortModeIcon()),
                tooltip: 'Sort: ${_sortModeLabel()}',
                onPressed: _cycleSortMode,
              ),
            ],
          ),
        ),

        // Filter chips
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          color: theme.colorScheme.surfaceContainerHighest.withValues(
            alpha: 0.5,
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _FilterMode.values.map((mode) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(_filterLabel(mode)),
                    selected: _filterMode == mode,
                    onSelected: (_) => setState(() => _filterMode = mode),
                  ),
                );
              }).toList(),
            ),
          ),
        ),

        // Grouped transaction list
        Expanded(
          child: _pulses.isEmpty
              ? _buildEmptyState()
              : groups.isEmpty
                  ? Center(
                      child: Text(
                        'No matching groups',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: groups.length,
                      itemBuilder: (context, index) {
                        final group = groups[index];
                        return _buildGroupRow(
                          group,
                          theme,
                          currencySymbol,
                        );
                      },
                    ),
        ),

        _buildBottomBar(),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.receipt_long,
              size: 48,
              color: Theme.of(context).colorScheme.outline,
            ),
            const SizedBox(height: 16),
            const Text(
              'No transactions found to import.',
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            const Text(
              'Check your configuration settings or file content.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupRow(
    _PulseGroup group,
    ThemeData theme,
    String currencySymbol,
  ) {
    final isExpanded = _expandedGroups.contains(group.groupKey);
    final totalCents = group.totalAmount(_pulses);
    final isIncome = totalCents > 0;
    final allImported = group.allImported(_pulses);
    final anyImported = group.anyImported(_pulses);
    final cat = group.category(_pulses);
    final suggested = group.suggestedCategory(_pulses);
    final confidence = group.maxConfidence(_pulses);
    final groupLinkedId = _groupLinkedItemId(group);
    final hasAnyLink = _groupHasAnyLink(group);
    final linkedItem = groupLinkedId != null
        ? widget.unlinkedItems.firstWhereOrNull((i) => i.id == groupLinkedId)
        : null;

    return Column(
      children: [
        // Group header
        InkWell(
          onTap: () {
            setState(() {
              if (isExpanded) {
                _expandedGroups.remove(group.groupKey);
              } else {
                _expandedGroups.add(group.groupKey);
              }
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 8,
            ),
            decoration: BoxDecoration(
              color: isExpanded
                  ? theme.colorScheme.surfaceContainerHighest
                      .withValues(alpha: 0.3)
                  : null,
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outlineVariant
                      .withValues(alpha: 0.3),
                ),
              ),
            ),
            child: Row(
              children: [
                // Expand/collapse icon
                Icon(
                  isExpanded ? Icons.expand_more : Icons.chevron_right,
                  size: 20,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                const SizedBox(width: 4),
                // Link status icon
                Icon(
                  hasAnyLink ? Icons.link : Icons.link_off,
                  size: 16,
                  color: hasAnyLink
                      ? theme.colorScheme.primary
                      : theme.colorScheme.outline,
                ),
                const SizedBox(width: 4),
                // Confidence indicator
                _ConfidenceDot(
                  confidence: confidence,
                  hasCategory: cat != null,
                  isTransfer: group.isTransferGroup(_pulses),
                ),
                const SizedBox(width: 8),
                // Label + count
                Expanded(
                  child: Row(
                    children: [
                      Flexible(
                        child: Text(
                          group.displayLabel,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: allImported
                                ? null
                                : theme.colorScheme.onSurface
                                    .withValues(alpha: 0.5),
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 1,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.secondaryContainer,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${group.count}',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onSecondaryContainer,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Total amount
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text(
                    '${isIncome ? '+' : '-'}$currencySymbol${(totalCents.abs() / 100).toStringAsFixed(2)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: isIncome
                          ? theme.colorScheme.primary
                          : theme.colorScheme.error,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                // Category dropdown (read-only if linked)
                if (linkedItem != null)
                  SizedBox(
                    width: 110,
                    child: Text(
                      linkedItem.category ?? '—',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.primary,
                        fontStyle: FontStyle.italic,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                else
                  SizedBox(
                    width: 110,
                    child: _CategoryDropdown(
                      value: cat,
                      suggestedCategory: suggested,
                      onChanged: allImported || anyImported
                          ? (c) => _updateCategory(group.groupKey, c)
                          : null,
                    ),
                  ),
                // Link/unlink button
                if (hasAnyLink)
                  IconButton(
                    icon: const Icon(Icons.link_off, size: 18),
                    tooltip: 'Unlink',
                    onPressed: () => _unlinkGroup(group),
                    color: theme.colorScheme.error,
                    visualDensity: VisualDensity.compact,
                  )
                else if (widget.unlinkedItems.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.add_link, size: 18),
                    tooltip: 'Link',
                    onPressed: () => _showGroupItemPicker(group),
                    visualDensity: VisualDensity.compact,
                  )
                else
                  const SizedBox(width: 40),
                // Group checkbox
                Checkbox(
                  value: allImported
                      ? true
                      : anyImported
                          ? null
                          : false,
                  tristate: true,
                  onChanged: (_) => _toggleGroupImport(group.groupKey),
                ),
              ],
            ),
          ),
        ),
        // Expanded children
        if (isExpanded)
          ...group.indices.map((pulseIndex) {
            final mapped = _pulses[pulseIndex];
            final pulse = mapped.pulse;
            final pIsIncome = pulse.amountMinorUnits > 0;
            final pLinkedItem = mapped.linkedItemId != null
                ? widget.unlinkedItems
                    .firstWhereOrNull((i) => i.id == mapped.linkedItemId)
                : null;
            return Container(
              padding: const EdgeInsets.only(
                left: 48,
                right: 12,
                top: 4,
                bottom: 4,
              ),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest
                    .withValues(alpha: 0.15),
                border: Border(
                  bottom: BorderSide(
                    color: theme.colorScheme.outlineVariant
                        .withValues(alpha: 0.15),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Text(
                    DateFormat('dd/MM/yy').format(pulse.date),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: mapped.shouldImport
                          ? theme.colorScheme.onSurfaceVariant
                          : theme.colorScheme.onSurface
                              .withValues(alpha: 0.3),
                    ),
                  ),
                  if (pLinkedItem != null) ...[
                    const SizedBox(width: 8),
                    Icon(
                      Icons.link,
                      size: 12,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        pLinkedItem.label,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.primary,
                          fontSize: 11,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                  const Spacer(),
                  Text(
                    '${pIsIncome ? '+' : '-'}$currencySymbol${(pulse.amountMinorUnits.abs() / 100).toStringAsFixed(2)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: pIsIncome
                          ? theme.colorScheme.primary.withValues(
                              alpha: mapped.shouldImport ? 1.0 : 0.5,
                            )
                          : theme.colorScheme.error.withValues(
                              alpha: mapped.shouldImport ? 1.0 : 0.5,
                            ),
                      fontWeight: FontWeight.w500,
                      decoration: mapped.shouldImport
                          ? null
                          : TextDecoration.lineThrough,
                    ),
                  ),
                  Checkbox(
                    value: mapped.shouldImport,
                    onChanged: (_) => _toggleSingleImport(pulseIndex),
                    visualDensity: VisualDensity.compact,
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          TextButton(onPressed: widget.onCancel, child: const Text('Cancel')),
          const Spacer(),
          FilledButton(
            onPressed: _pulses.isNotEmpty ? widget.onNext : null,
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }
}

enum _SortMode { byCount, alphabetical, byTotalAmount }

enum _FilterMode { all, linked, unlinked, categorized, uncategorized, transfers }

class _PulseGroup {
  _PulseGroup({
    required this.displayLabel,
    required this.groupKey,
    required this.indices,
  });

  final String displayLabel;
  final String groupKey;
  final List<int> indices;

  int get count => indices.length;

  int totalAmount(List<_MappedPulse> pulses) =>
      indices.fold(0, (sum, i) => sum + pulses[i].pulse.amountMinorUnits);

  String? category(List<_MappedPulse> pulses) =>
      pulses[indices.first].pulse.category;

  String? suggestedCategory(List<_MappedPulse> pulses) =>
      pulses[indices.first].suggestedCategory;

  double maxConfidence(List<_MappedPulse> pulses) =>
      indices.fold(0.0, (max, i) {
        final c = pulses[i].confidence;
        return c > max ? c : max;
      });

  bool allImported(List<_MappedPulse> pulses) =>
      indices.every((i) => pulses[i].shouldImport);

  bool anyImported(List<_MappedPulse> pulses) =>
      indices.any((i) => pulses[i].shouldImport);

  bool get isTransfer => groupKey == 'notprovided';

  bool isTransferGroup(List<_MappedPulse> pulses) =>
      indices.any((i) => pulses[i].pulse.isInternalTransfer);
}

class _ConfidenceDot extends StatelessWidget {
  const _ConfidenceDot({
    required this.confidence,
    required this.hasCategory,
    required this.isTransfer,
  });

  final double confidence;
  final bool hasCategory;
  final bool isTransfer;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final Color color;
    final IconData icon;

    if (isTransfer) {
      color = theme.colorScheme.tertiary;
      icon = Icons.swap_horiz;
    } else if (hasCategory) {
      color = confidence >= 0.8
          ? theme.colorScheme.primary
          : theme.colorScheme.secondary;
      icon = Icons.check;
    } else {
      color = theme.colorScheme.surfaceContainerHighest;
      icon = Icons.add;
    }

    return CircleAvatar(
      radius: 12,
      backgroundColor: color,
      child: Icon(icon, size: 14, color: theme.colorScheme.onPrimary),
    );
  }
}

class _CategoryDropdown extends StatelessWidget {
  const _CategoryDropdown({
    required this.value,
    required this.suggestedCategory,
    required this.onChanged,
  });

  final String? value;
  final String? suggestedCategory;
  final void Function(String?)? onChanged;

  // Use the standard categories from categories.dart
  static List<String> get _categories => categories.getAllCategories();

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String?>(
      initialValue: value,
      isExpanded: true,
      decoration: const InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 8),
        border: OutlineInputBorder(),
        isDense: true,
      ),
      hint: suggestedCategory != null
          ? Text(
              suggestedCategory!,
              style: TextStyle(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: 0.6),
                fontStyle: FontStyle.italic,
              ),
            )
          : const Text('Select'),
      items: [
        const DropdownMenuItem<String?>(value: null, child: Text('None')),
        ..._categories.map(
          (cat) => DropdownMenuItem<String?>(value: cat, child: Text(cat)),
        ),
      ],
      onChanged: onChanged,
    );
  }
}

class _BalanceStepPage extends StatefulWidget {
  const _BalanceStepPage({
    required this.detectedBalanceCents,
    required this.updateBalance,
    required this.onCancel,
    required this.onChanged,
    required this.onBalanceChanged,
    required this.onNext,
  });

  final int? detectedBalanceCents;
  final bool updateBalance;
  final VoidCallback onCancel;
  final ValueChanged<bool> onChanged;
  final ValueChanged<int?> onBalanceChanged;
  final VoidCallback onNext;

  @override
  State<_BalanceStepPage> createState() => _BalanceStepPageState();
}

class _BalanceStepPageState extends State<_BalanceStepPage> {
  late TextEditingController _controller;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(
      text: widget.detectedBalanceCents != null
          ? (widget.detectedBalanceCents! / 100).toStringAsFixed(2)
          : '',
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onManualBalanceChanged(String value) {
    final amount = double.tryParse(value.replaceAll(',', '.'));
    if (amount != null) {
      widget.onBalanceChanged((amount * 100).round());
    } else {
      widget.onBalanceChanged(null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final settings = AppSettingsScope.of(context);
    final currentBalance = settings.currentBalanceCents;

    final hasDetectedBalance = widget.detectedBalanceCents != null;
    final balanceDiff =
        hasDetectedBalance ? widget.detectedBalanceCents! - currentBalance : 0;

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Icon(
                Icons.account_balance,
                size: 64,
                color: theme.colorScheme.primary,
              ),
              const SizedBox(height: 24),
              Text(
                'Verify Account Balance',
                style: theme.textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'We detected a closing balance in your statement. Would you like to update your account balance to match?',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              _BalanceComparisonCard(
                label: 'Current App Balance',
                amountCents: currentBalance,
                isPrimary: false,
              ),
              const SizedBox(height: 12),
              const Center(
                child: Icon(Icons.arrow_downward, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              if (_isEditing) ...[
                TextField(
                  controller: _controller,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Statement Closing Balance',
                    prefixText: AppSettingsScope.read(
                      context,
                    ).currencySettings.currency.symbol,
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.check),
                      onPressed: () => setState(() => _isEditing = false),
                    ),
                    border: const OutlineInputBorder(),
                  ),
                  onChanged: _onManualBalanceChanged,
                ),
              ] else ...[
                Stack(
                  children: [
                    _BalanceComparisonCard(
                      label: 'Statement Closing Balance',
                      amountCents: widget.detectedBalanceCents ?? 0,
                      isPrimary: true,
                      empty: !hasDetectedBalance,
                    ),
                    Positioned(
                      top: 4,
                      right: 4,
                      child: IconButton(
                        icon: const Icon(Icons.edit, size: 18),
                        onPressed: () => setState(() => _isEditing = true),
                        tooltip: 'Edit manually',
                      ),
                    ),
                  ],
                ),
              ],
              if (hasDetectedBalance && balanceDiff != 0) ...[
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondaryContainer.withValues(
                      alpha: 0.3,
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        balanceDiff > 0
                            ? Icons.trending_up
                            : Icons.trending_down,
                        color: balanceDiff > 0 ? Colors.green : Colors.red,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Updating will change your balance by ${AppSettingsScope.read(context).currencySettings.currency.symbol}${(balanceDiff.abs() / 100).toStringAsFixed(2)}',
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 32),
              SwitchListTile(
                title: const Text('Update account balance'),
                subtitle: const Text(
                  'Adjust your current account balance to match the statement closing balance.',
                ),
                value: widget.updateBalance && hasDetectedBalance,
                onChanged: hasDetectedBalance ? widget.onChanged : null,
                secondary: const Icon(Icons.sync),
              ),
            ],
          ),
        ),
        _buildBottomBar(context),
      ],
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          TextButton(onPressed: widget.onCancel, child: const Text('Cancel')),
          const Spacer(),
          FilledButton(onPressed: widget.onNext, child: const Text('Next')),
        ],
      ),
    );
  }
}

class _BalanceComparisonCard extends StatelessWidget {
  const _BalanceComparisonCard({
    required this.label,
    required this.amountCents,
    required this.isPrimary,
    this.empty = false,
  });

  final String label;
  final int amountCents;
  final bool isPrimary;
  final bool empty;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color =
        isPrimary ? theme.colorScheme.primary : theme.colorScheme.outline;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isPrimary
            ? theme.colorScheme.primaryContainer.withValues(alpha: 0.2)
            : theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: isPrimary ? 2 : 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: theme.textTheme.labelLarge?.copyWith(
              color: isPrimary ? color : null,
            ),
          ),
          Text(
            empty
                ? 'Not detected'
                : '${AppSettingsScope.read(context).currencySettings.currency.symbol}${(amountCents / 100).toStringAsFixed(2)}',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: empty
                  ? theme.colorScheme.error
                  : (isPrimary ? theme.colorScheme.onPrimaryContainer : null),
            ),
          ),
        ],
      ),
    );
  }
}

/// Page 4: Review & Import
class _ReviewPage extends StatelessWidget {
  const _ReviewPage({
    required this.mappedPulses,
    required this.onCancel,
    required this.onImport,
  });

  final List<_MappedPulse> mappedPulses;
  final VoidCallback onCancel;
  final VoidCallback onImport;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final importable = mappedPulses.where((p) => p.shouldImport).toList();
    final totalAmount = importable.fold<int>(
      0,
      (sum, p) => sum + p.pulse.amountMinorUnits,
    );
    final expenses =
        importable.where((p) => p.pulse.amountMinorUnits < 0).length;
    final income = importable.where((p) => p.pulse.amountMinorUnits > 0).length;
    final categorized =
        importable.where((p) => p.pulse.category != null).length;
    final skipped = mappedPulses.length - importable.length;

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Ready to Import', style: theme.textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                'Review your import before proceeding.',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 24),

              // Summary cards
              _SummaryCard(
                icon: Icons.receipt_long,
                label: 'Transactions',
                value: '${importable.length}',
                subtitle:
                    '$expenses expenses, $income income${skipped > 0 ? ' ($skipped skipped)' : ''}',
              ),
              const SizedBox(height: 12),

              _SummaryCard(
                icon: Icons.attach_money,
                label: 'Net Amount',
                value:
                    '${AppSettingsScope.read(context).currencySettings.currency.symbol}${(totalAmount.abs() / 100).toStringAsFixed(2)}',
                subtitle: totalAmount >= 0 ? 'Net income' : 'Net expense',
                valueColor:
                    totalAmount >= 0 ? Colors.green : theme.colorScheme.error,
              ),
              const SizedBox(height: 12),

              _SummaryCard(
                icon: Icons.category,
                label: 'Categorized',
                value: importable.isNotEmpty
                    ? '$categorized / ${importable.length}'
                    : '0',
                subtitle: importable.isNotEmpty
                    ? '${((categorized / importable.length) * 100).toStringAsFixed(0)}% complete'
                    : '0% complete',
              ),
              const SizedBox(height: 24),

              // Warning
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.errorContainer.withValues(
                    alpha: 0.3,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: theme.colorScheme.error.withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: theme.colorScheme.error),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Imported transactions will be added to your current account. This action cannot be undone.',
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        _buildBottomBar(context, importable),
      ],
    );
  }

  Widget _buildBottomBar(BuildContext context, List<_MappedPulse> importable) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          TextButton(onPressed: onCancel, child: const Text('Cancel')),
          const Spacer(),
          FilledButton.icon(
            onPressed: importable.isNotEmpty ? onImport : null,
            icon: const Icon(Icons.file_download),
            label: Text('Import ${importable.length} Transactions'),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.subtitle,
    this.valueColor,
  });

  final IconData icon;
  final String label;
  final String value;
  final String subtitle;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: theme.colorScheme.primary),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  value,
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: valueColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const _sentinel = Object();

/// Helper class to track mapped pulses with metadata
class _MappedPulse {
  const _MappedPulse({
    required this.pulse,
    this.suggestedCategory,
    this.confidence = 0.0,
    this.rawDescription = '',
    this.wasManuallyEdited = false,
    this.linkedItemId,
    this.shouldImport = true,
  });

  final PulseEntry pulse;
  final String? suggestedCategory;
  final double confidence;
  final String rawDescription;
  final bool wasManuallyEdited;
  final TimelineItemId? linkedItemId;
  final bool shouldImport;

  _MappedPulse copyWith({
    PulseEntry? pulse,
    String? suggestedCategory,
    double? confidence,
    String? rawDescription,
    bool? wasManuallyEdited,
    Object? linkedItemId = _sentinel,
    bool? shouldImport,
  }) {
    return _MappedPulse(
      pulse: pulse ?? this.pulse,
      suggestedCategory: suggestedCategory ?? this.suggestedCategory,
      confidence: confidence ?? this.confidence,
      rawDescription: rawDescription ?? this.rawDescription,
      wasManuallyEdited: wasManuallyEdited ?? this.wasManuallyEdited,
      linkedItemId: linkedItemId == _sentinel
          ? this.linkedItemId
          : linkedItemId as TimelineItemId?,
      shouldImport: shouldImport ?? this.shouldImport,
    );
  }
}

/// Bottom sheet for selecting a bank profile.
class _ProfileSelectorSheet extends StatelessWidget {
  const _ProfileSelectorSheet({
    required this.profiles,
    required this.onSelect,
    this.detectedProfile,
    this.selectedProfile,
  });

  final List<BankProfile> profiles;
  final BankProfile? detectedProfile;
  final BankProfile? selectedProfile;
  final void Function(BankProfile) onSelect;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Group profiles by country
    final userProfiles = profiles.where((p) => !p.isBuiltIn).toList();
    final communityProfiles = profiles.where((p) => p.isBuiltIn).toList();

    // Group community profiles by country
    final byCountry = <String, List<BankProfile>>{};
    for (final profile in communityProfiles) {
      final country = profile.country ?? 'Other';
      byCountry.putIfAbsent(country, () => []).add(profile);
    }

    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      minChildSize: 0.3,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Text('Bank Profiles', style: theme.textTheme.titleLarge),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              controller: scrollController,
              children: [
                // Detected profile (if any)
                if (detectedProfile != null) ...[
                  const _SectionHeader('Auto-Detected'),
                  _ProfileTile(
                    profile: detectedProfile!,
                    isSelected: selectedProfile?.id == detectedProfile!.id,
                    isDetected: true,
                    onTap: () => onSelect(detectedProfile!),
                  ),
                ],

                // User profiles
                if (userProfiles.isNotEmpty) ...[
                  const _SectionHeader('Your Profiles'),
                  for (final profile in userProfiles)
                    _ProfileTile(
                      profile: profile,
                      isSelected: selectedProfile?.id == profile.id,
                      onTap: () => onSelect(profile),
                    ),
                ],

                // Community profiles by country
                for (final entry in byCountry.entries) ...[
                  _SectionHeader(_getCountryName(entry.key)),
                  for (final profile in entry.value)
                    _ProfileTile(
                      profile: profile,
                      isSelected: selectedProfile?.id == profile.id,
                      onTap: () => onSelect(profile),
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getCountryName(String code) {
    switch (code) {
      case 'NL':
        return '🇳🇱 Netherlands';
      case 'US':
        return '🇺🇸 United States';
      case 'UK':
        return '🇬🇧 United Kingdom';
      case 'EU':
        return '🇪🇺 Europe (Generic)';
      default:
        return code;
    }
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({
    required this.profile,
    required this.onTap,
    this.isSelected = false,
    this.isDetected = false,
  });

  final BankProfile profile;
  final VoidCallback onTap;
  final bool isSelected;
  final bool isDetected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: isSelected
            ? theme.colorScheme.primary
            : theme.colorScheme.surfaceContainerHighest,
        child: Icon(
          isDetected
              ? Icons.auto_awesome
              : profile.isBuiltIn
                  ? Icons.public
                  : Icons.person,
          color: isSelected
              ? theme.colorScheme.onPrimary
              : theme.colorScheme.onSurfaceVariant,
          size: 20,
        ),
      ),
      title: Text(profile.name),
      subtitle: profile.description != null
          ? Text(
              profile.description!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            )
          : null,
      trailing: isSelected
          ? Icon(Icons.check, color: theme.colorScheme.primary)
          : null,
      onTap: onTap,
    );
  }
}
