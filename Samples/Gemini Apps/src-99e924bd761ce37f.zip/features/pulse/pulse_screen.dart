import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_actions.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item_sheet.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/pulse/pulse_filter_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/update_pulse_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/snackbars.dart';
import 'package:expense_stalker_mobile/src/widgets/payment_schedule_dialog.dart';

class PulsesListItem {
  final TimelineItem? timelineItem;
  final PulseEntry? standalonePulse;

  PulsesListItem.fromTimelineItem(this.timelineItem) : standalonePulse = null;
  PulsesListItem.fromStandalonePulse(this.standalonePulse)
      : timelineItem = null;

  bool get isTimelineItem => timelineItem != null;
  String get label => timelineItem?.label ?? standalonePulse?.label ?? '';
  int get amountMinorUnits =>
      timelineItem?.amountMinorUnits ?? standalonePulse?.amountMinorUnits ?? 0;
  PulseType get type =>
      timelineItem?.type ?? standalonePulse?.type ?? PulseType.oneOff;
  String? get category => timelineItem?.category ?? standalonePulse?.category;
  String? get origin {
    final item = timelineItem;
    final pulse = standalonePulse;
    if (item != null) return item.origin;
    if (pulse != null) return pulse.origin;
    return null;
  }

  String? get notes => timelineItem?.notes ?? standalonePulse?.notes;

  bool get archived => timelineItem?.archived ?? false;
  String get id => timelineItem?.id.value ?? standalonePulse?.id.value ?? '';

  int? get remainingBalanceMinorUnits =>
      timelineItem?.remainingBalanceMinorUnits;
  AppCurrency? get balanceCurrency => timelineItem?.balanceCurrency;
  DateTime? calculateFinalPulseDate() =>
      timelineItem?.calculateFinalPulseDate();
}

class PulseScreen extends StatefulWidget {
  const PulseScreen({super.key});

  @override
  State<PulseScreen> createState() => _PulseScreenState();
}

class _PulseScreenState extends State<PulseScreen> {
  static const _pageSize =
      AppConstants.pageSizeDefault; // render 50 items at a time

  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  int _loadedCount = _pageSize;
  Offset? _lastPointerPosition;

  // Memoization for expensive filtering/grouping operations
  List<PulsesListItem>? _cachedFilteredItems;
  ({
    String search,
    PulsesFilterType filterType,
    String? category,
    bool archived,
    int pulseHash,
    int itemsHash,
  })? _cachedFilterKey;
  Map<String, List<PulsesListItem>>? _cachedGroupedItems;
  ({Object filterKey, PulsesGroupBy groupBy})? _cachedGroupKey;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text.trim().toLowerCase();
      _loadedCount = _pageSize; // Reset pagination on filter change
    });
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final maxScroll = _scrollController.position.maxScrollExtent;
    final current = _scrollController.position.pixels;
    if (current >= (maxScroll - AppConstants.scrollThresholdNormal)) {
      setState(() {
        _loadedCount += _pageSize;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final settings = AppSettingsScope.of(context);
    return Scaffold(
      body: Builder(
        builder: (context) {
          // Generate cache key from filter state using hash instead of length
          // IMPORTANT: Hash the entire items, not just IDs, to detect edits
          final pulseHash = Object.hashAll(store.pulses);
          final itemsHash = Object.hashAll(store.timelineItems);
          final filterKey = (
            search: _searchQuery,
            filterType: settings.pulseFilterType,
            category: settings.pulseFilterCategory,
            archived: settings.pulseShowArchived,
            pulseHash: pulseHash,
            itemsHash: itemsHash,
          );

          // Build pulse lookup map once for efficient O(1) lookups
          final pulseLookupMap = buildPulseLookupMap(store.pulses);

          // Use cached filtered items if key matches
          List<PulsesListItem> filteredItems;
          if (_cachedFilteredItems != null && _cachedFilterKey == filterKey) {
            filteredItems = _cachedFilteredItems!;
          } else {
            filteredItems = _filterItems(
              store.timelineItems,
              store.pulses,
              settings,
            );
            _sortItems(filteredItems, settings, pulseLookupMap);
            _cachedFilteredItems = filteredItems;
            _cachedFilterKey = filterKey;
          }

          final showMore = filteredItems.length > _loadedCount;
          final displayCount = showMore ? _loadedCount : filteredItems.length;

          // Generate cache key for grouping (tuple-based instead of string concatenation)
          final groupKey = (
            filterKey: filterKey,
            groupBy: settings.pulseGroupBy,
          );

          // Use cached grouped items if key matches
          Map<String, List<PulsesListItem>> groupedItems;
          if (_cachedGroupedItems != null && _cachedGroupKey == groupKey) {
            groupedItems = _cachedGroupedItems!;
          } else {
            groupedItems = _groupItems(filteredItems, settings, pulseLookupMap);
            _cachedGroupedItems = groupedItems;
            _cachedGroupKey = groupKey;
          }

          return Stack(
            children: [
              Positioned.fill(
                child: SafeArea(
                  child: CustomScrollView(
                    controller: _scrollController,
                    slivers: [
                      SliverAppBar(
                        pinned: true,
                        floating: true,
                        title: _buildSearchBar(context),
                        actions: [
                          _buildFilterAction(context, settings, store),
                          IconButton(
                            tooltip:
                                AppLocalizations.of(context)?.optionsTitle ??
                                    'Options',
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const OptionsScreen(),
                                  fullscreenDialog:
                                      MediaQuery.sizeOf(context).width < 1024,
                                ),
                              );
                            },
                            icon: PhosphorIcon(PhosphorIcons.gear()),
                          ),
                        ],
                      ),
                      // Filter chips
                      SliverToBoxAdapter(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Active Filter Chips (only shown when filters are active)
                            _buildActiveFilterChips(context, settings),
                          ],
                        ),
                      ),

                      const SliverToBoxAdapter(child: Divider(height: 1)),
                      // Items list
                      if (filteredItems.isEmpty)
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(16, 32, 16, 32),
                            child: Center(
                              child: Text(
                                settings.pulseFilterType != PulsesFilterType.all
                                    ? 'No items match the current filter'
                                    : Terminology.of(context).noItemsMessage,
                              ),
                            ),
                          ),
                        )
                      else
                        _buildItemsList(
                          context,
                          groupedItems,
                          displayCount,
                          showMore,
                          settings,
                          store,
                          pulseLookupMap,
                        ),
                      // Extra height for FAB clearance (56 + 16 padding)
                      const SliverToBoxAdapter(
                        child: SizedBox(
                          height: AppConstants.appBarExtendedHeight + 72,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 16,
                bottom: 16,
                child: FloatingActionButton(
                  onPressed: () => _showAddMenu(context),
                  child: PhosphorIcon(PhosphorIcons.plus()),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<PulsesListItem> _filterItems(
    List<TimelineItem> items,
    List<PulseEntry> pulses,
    AppSettingsStore settings,
  ) {
    // Only include scheduled TimelineItems
    // Standalone pulses (orphaned history) appear in the Timeline view, not here
    final allItems = <PulsesListItem>[
      ...items.map((i) => PulsesListItem.fromTimelineItem(i)),
    ];

    if (allItems.isEmpty) return [];

    final filtered = allItems.where((item) {
      // 1. Filter by Search Query
      if (_searchQuery.isNotEmpty) {
        final matchesLabel = item.label.toLowerCase().contains(_searchQuery);
        final matchesCategory =
            item.category?.toLowerCase().contains(_searchQuery) ?? false;
        final matchesOrigin =
            item.origin?.toLowerCase().contains(_searchQuery) ?? false;
        final matchesNotes =
            item.notes?.toLowerCase().contains(_searchQuery) ?? false;

        if (!matchesLabel &&
            !matchesCategory &&
            !matchesOrigin &&
            !matchesNotes) {
          return false;
        }
      }

      // 2. Filter by Archived
      if (!settings.pulseShowArchived && item.archived) {
        return false;
      }

      // 3. Filter by Type
      switch (settings.pulseFilterType) {
        case PulsesFilterType.all:
          return true;
        case PulsesFilterType.category:
          if (settings.pulseFilterCategory == null) return true;
          return item.category == settings.pulseFilterCategory;
        case PulsesFilterType.income:
          return item.type.isIncomeType;
        case PulsesFilterType.expenses:
          return !item.type.isIncomeType && item.type != PulseType.debt;
        case PulsesFilterType.debt:
          return item.type == PulseType.debt;
        case PulsesFilterType.oneOff:
          return item.type == PulseType.oneOff ||
              item.type == PulseType.oneOffIncome;
        case PulsesFilterType.recurring:
          return item.type == PulseType.recurring ||
              item.type == PulseType.recurringIncome ||
              item.type == PulseType.spendingEnvelope;
        case PulsesFilterType.envelopes:
          return item.type == PulseType.spendingEnvelope;
      }
    }).toList();

    return filtered;
  }

  /// Counts how many filters are active (non-default values)
  int _activeFilterCount(AppSettingsStore settings) {
    int count = 0;
    if (settings.pulseFilterType != PulsesFilterType.all) count++;
    if (settings.pulseGroupBy != PulsesGroupBy.none) count++;
    if (settings.pulseShowArchived) count++;
    return count;
  }

  /// Builds independent search bar for AppBar
  Widget _buildSearchBar(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return SizedBox(
      height: 40,
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          hintText: 'Search...',
          prefixIcon: const Icon(Icons.search, size: 20),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, size: 18),
                  onPressed: () => _searchController.clear(),
                  visualDensity: VisualDensity.compact,
                )
              : null,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 8,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
            borderSide: BorderSide(color: colorScheme.outlineVariant),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
            borderSide: BorderSide(
              color: colorScheme.outlineVariant.withValues(alpha: 0.5),
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
            borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
          ),
          filled: true,
          fillColor: colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        ),
      ),
    );
  }

  /// Builds filter action button with badge
  Widget _buildFilterAction(
    BuildContext context,
    AppSettingsStore settings,
    ExpenseStore store,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final hasActiveFilters = _activeFilterCount(settings) > 0;

    return IconButton(
      onPressed: () => showPulseFilterSheet(
        context: context,
        settings: settings,
        store: store,
      ),
      icon: Badge(
        isLabelVisible: hasActiveFilters,
        backgroundColor: colorScheme.primary,
        smallSize: 8,
        child: PhosphorIcon(
          PhosphorIcons.funnel(),
          color: hasActiveFilters ? colorScheme.primary : null,
        ),
      ),
    );
  }

  /// Builds active filter chips shown below search bar
  Widget _buildActiveFilterChips(
    BuildContext context,
    AppSettingsStore settings,
  ) {
    final chips = <Widget>[];

    // Filter type chip
    if (settings.pulseFilterType != PulsesFilterType.all) {
      String label;
      switch (settings.pulseFilterType) {
        case PulsesFilterType.income:
          label = 'Income';
        case PulsesFilterType.expenses:
          label = 'Expenses';
        case PulsesFilterType.debt:
          label = 'Debt';
        case PulsesFilterType.recurring:
          label = 'Recurring';
        case PulsesFilterType.envelopes:
          label = 'Envelopes';
        case PulsesFilterType.oneOff:
          label = 'One-off';
        case PulsesFilterType.category:
          label = settings.pulseFilterCategory ?? 'Category';
        default:
          label = 'Filter';
      }
      chips.add(
        _buildDismissibleChip(
          context,
          label: label,
          onDismiss: () {
            settings.pulseFilterType = PulsesFilterType.all;
            settings.pulseFilterCategory = null;
          },
          isPrimary: true,
        ),
      );
    }

    // Group by chip
    if (settings.pulseGroupBy != PulsesGroupBy.none) {
      final groupLabel = switch (settings.pulseGroupBy) {
        PulsesGroupBy.category => 'By Category',
        PulsesGroupBy.type => 'By Type',
        PulsesGroupBy.origin => 'By Origin',
        PulsesGroupBy.dueDate => 'By Due Date',
        _ => 'Grouped',
      };
      chips.add(
        _buildDismissibleChip(
          context,
          label: groupLabel,
          onDismiss: () => settings.pulseGroupBy = PulsesGroupBy.none,
          isPrimary: false,
        ),
      );
    }

    // Show archived chip
    if (settings.pulseShowArchived) {
      chips.add(
        _buildDismissibleChip(
          context,
          label: 'Archived',
          onDismiss: () => settings.pulseShowArchived = false,
          isPrimary: false,
        ),
      );
    }

    if (chips.isEmpty) {
      return const SizedBox(height: 8);
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
      child: Wrap(spacing: 8, runSpacing: 6, children: chips),
    );
  }

  /// Builds a dismissible filter chip
  Widget _buildDismissibleChip(
    BuildContext context, {
    required String label,
    required VoidCallback onDismiss,
    required bool isPrimary,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.only(left: 10, right: 4, top: 4, bottom: 4),
      decoration: BoxDecoration(
        color: isPrimary
            ? colorScheme.primaryContainer.withValues(alpha: 0.6)
            : colorScheme.secondaryContainer.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isPrimary
              ? colorScheme.primary.withValues(alpha: 0.3)
              : colorScheme.secondary.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: isPrimary
                  ? colorScheme.onPrimaryContainer
                  : colorScheme.onSecondaryContainer,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 2),
          InkWell(
            onTap: onDismiss,
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: Icon(
                Icons.close,
                size: 14,
                color: isPrimary
                    ? colorScheme.onPrimaryContainer.withValues(alpha: 0.7)
                    : colorScheme.onSecondaryContainer.withValues(alpha: 0.7),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _sortItems(
    List<PulsesListItem> items,
    AppSettingsStore settings,
    Map<String, List<PulseEntry>> pulseLookupMap,
  ) {
    items.sort((a, b) {
      final dateA = _getItemDate(a, pulseLookupMap, settings);
      final dateB = _getItemDate(b, pulseLookupMap, settings);

      if (dateA == null && dateB == null) return 0;
      if (dateA == null) return 1; // Put nulls at end
      if (dateB == null) return -1;

      final comparison = dateA.compareTo(dateB);
      // Default to ascending (oldest to newest) unless reverse specified
      return settings.timelineSortOrder ==
              TimelineSortOrder.reverseChronological
          ? -comparison
          : comparison;
    });
  }

  DateTime? _getItemDate(
    PulsesListItem item,
    Map<String, List<PulseEntry>> pulseLookupMap,
    AppSettingsStore settings,
  ) {
    if (item.isTimelineItem) {
      final tItem = item.timelineItem;
      if (tItem == null) return null;
      // Fallback to startDate if no next due date (e.g. ended one-off)
      return _nextDueDate(
            item: tItem,
            pulseLookupMap: pulseLookupMap,
            settings: settings,
          ) ??
          tItem.startDate;
    } else {
      return item.standalonePulse?.date;
    }
  }

  Map<String, List<PulsesListItem>> _groupItems(
    List<PulsesListItem> items,
    AppSettingsStore settings,
    Map<String, List<PulseEntry>> pulseLookupMap,
  ) {
    if (settings.pulseGroupBy == PulsesGroupBy.none) {
      return {'': items};
    }

    final Map<String, List<PulsesListItem>> groups = {};

    for (final item in items) {
      String groupKey;
      switch (settings.pulseGroupBy) {
        case PulsesGroupBy.none:
          groupKey = '';
          break;
        case PulsesGroupBy.category:
          groupKey = item.category ?? 'Uncategorized';
          break;
        case PulsesGroupBy.type:
          groupKey = Terminology.of(context).pulseTypeLabel(item.type);
          break;
        case PulsesGroupBy.origin:
          groupKey = item.origin ?? 'No Origin';
          break;
        case PulsesGroupBy.dueDate:
          DateTime? date;
          if (item.isTimelineItem) {
            final tItem = item.timelineItem;
            if (tItem == null) {
              groupKey = '9999-12-31|No Due Date';
            } else {
              date = _nextDueDate(
                item: tItem,
                pulseLookupMap: pulseLookupMap,
                settings: settings,
              );
            }
          } else {
            // Standalone pulse
            date = item.standalonePulse?.date;
          }

          if (date == null) {
            groupKey = '9999-12-31|No Due Date';
          } else {
            // Use ISO-8601 sortable prefix
            final sortKey =
                '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
            groupKey = '$sortKey|${_formatDueDate(date)}';
          }
          break;
      }

      (groups[groupKey] ??= []).add(item);
    }

    return groups;
  }

  Widget _buildItemsList(
    BuildContext context,
    Map<String, List<PulsesListItem>> groupedItems,
    int displayCount,
    bool showMore,
    AppSettingsStore settings,
    ExpenseStore store,
    Map<String, List<PulseEntry>> pulseLookupMap,
  ) {
    if (settings.pulseGroupBy == PulsesGroupBy.none) {
      // Flat list (no grouping)
      final items = groupedItems['']!;
      return SliverList.separated(
        itemCount: displayCount + (showMore ? 1 : 0),
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          if (showMore && index == displayCount) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: TextButton(
                  onPressed: () => setState(() => _loadedCount += _pageSize),
                  child: Text(
                    AppLocalizations.of(context)?.showMore ?? 'Show More',
                  ),
                ),
              ),
            );
          }
          return _buildItemTile(
            context,
            items[index],
            settings,
            store,
            pulseLookupMap,
          );
        },
      );
    }

    // Grouped list
    final sortedGroups = groupedItems.keys.toList()..sort();
    final widgets = <Widget>[];
    int itemCount = 0;

    for (final fullKey in sortedGroups) {
      final groupKey = fullKey.contains('|') ? fullKey.split('|')[1] : fullKey;
      final groupItems = groupedItems[fullKey]!;

      // Add custom group header
      widgets.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
          child: Row(
            children: [
              Text(
                groupKey.toUpperCase(),
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.0,
                    ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Divider(
                  color: Theme.of(
                    context,
                  ).colorScheme.primary.withValues(alpha: 0.2),
                  thickness: 1,
                ),
              ),
            ],
          ),
        ),
      );

      // Add items in this group
      for (int i = 0; i < groupItems.length && itemCount < displayCount; i++) {
        widgets.add(
          _buildItemTile(
            context,
            groupItems[i],
            settings,
            store,
            pulseLookupMap,
          ),
        );
        // Removed Divider since tiles have bottom borders
        itemCount++;
      }

      if (itemCount >= displayCount) break;
    }

    if (showMore) {
      widgets.add(
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Center(
            child: TextButton(
              onPressed: () => setState(() => _loadedCount += _pageSize),
              child: Text(
                AppLocalizations.of(context)?.showMore ?? 'Show More',
              ),
            ),
          ),
        ),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) => widgets[index],
        childCount: widgets.length,
      ),
    );
  }

  Widget _buildItemTile(
    BuildContext context,
    PulsesListItem listItem,
    AppSettingsStore settings,
    ExpenseStore store,
    Map<String, List<PulseEntry>> pulseLookupMap,
  ) {
    if (listItem.isTimelineItem) {
      final item = listItem.timelineItem;
      if (item == null) return const SizedBox.shrink();
      final nextDue = _nextDueDate(
        item: item,
        pulseLookupMap: pulseLookupMap,
        settings: settings,
      );
      final l10n = AppLocalizations.of(context);
      final terminology = Terminology.of(context);
      final dueLabel = nextDue != null ? _formatDueDate(nextDue) : null;
      final pulseTypeText = terminology.pulseTypeLabel(item.type);
      final typeLabel = item.type == PulseType.oneOff
          ? pulseTypeText
          : item.frequency != null
              ? '${item.frequency!.label} $pulseTypeText'
              : pulseTypeText;

      final isDebit = item.amountMinorUnits < 0;
      final isPaused = item.isPausedForMonth(DateTime.now());
      final amountColor = (item.archived || isPaused)
          ? (isDebit ? settings.debitColor : settings.creditColor).withValues(
              alpha: 0.5,
            )
          : (isDebit ? settings.debitColor : settings.creditColor);

      // Calculate derived info strings
      // Build details spans
      final detailsSpans = <InlineSpan>[];
      final textStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            fontSize: 11,
            decoration:
                (item.archived || isPaused) ? TextDecoration.lineThrough : null,
          );
      final separator = TextSpan(text: ' • ', style: textStyle);

      void addText(String text) {
        if (detailsSpans.isNotEmpty) detailsSpans.add(separator);
        detailsSpans.add(TextSpan(text: text, style: textStyle));
      }

      if (item.archived) addText(Terminology.of(context).archivedStatusLabel);
      addText(typeLabel);
      if (item.category != null && item.category!.isNotEmpty) {
        addText(item.category!);
      }
      if (item.origin != null && item.origin!.isNotEmpty) addText(item.origin!);
      if (item.type == PulseType.debt &&
          item.remainingBalanceMinorUnits != null) {
        addText(
          '${l10n?.remainingBalance ?? 'Remaining Balance'} ${formatMoneyFromCents(item.remainingBalanceMinorUnits!, item.balanceCurrency ?? settings.currency, showCents: settings.showCents)}',
        );
      }

      if (item.type == PulseType.debt &&
          item.calculateFinalPulseDate() != null) {
        if (detailsSpans.isNotEmpty) detailsSpans.add(separator);
        final dateStr = _formatDate(item.calculateFinalPulseDate()!);
        final label = l10n?.estimatedRepulseDate ?? 'Est. Payoff';

        detailsSpans.add(
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) =>
                      PaymentScheduleDialog(item: item, settings: settings),
                );
              },
              child: Text(
                '$label $dateStr',
                style: textStyle?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        );
      }

      if (isPaused) addText('PAUSED');
      if (item.notes != null && item.notes!.isNotEmpty) addText(item.notes!);

      final tileContent = Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (event) => _lastPointerPosition = event.position,
        child: InkWell(
          onTap: () => _showUpsertTimelineItemSheet(context, existing: item),
          onLongPress: () async {
            final position = _lastPointerPosition ?? Offset.zero;
            await showTimelineItemMenu(
              context: context,
              item: item,
              month: nextDue ?? DateTime.now(),
              position: position,
              canArchive: true,
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(
                    context,
                  ).colorScheme.outlineVariant.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
            ),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 3,
                    decoration: BoxDecoration(
                      color: amountColor.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isPaused) ...[
                              PhosphorIcon(
                                PhosphorIcons.pauseCircle(),
                                size: 14,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant
                                    .withValues(alpha: 0.7),
                              ),
                              const SizedBox(width: 6),
                            ],
                            Flexible(
                              child: Text(
                                item.label,
                                style: Theme.of(context)
                                    .textTheme
                                    .titleSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                      color: (item.archived || isPaused)
                                          ? Theme.of(context)
                                              .colorScheme
                                              .onSurfaceVariant
                                              .withValues(alpha: 0.7)
                                          : Theme.of(
                                              context,
                                            ).colorScheme.onSurface,
                                      decoration: (item.archived || isPaused)
                                          ? TextDecoration.lineThrough
                                          : null,
                                    ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        if (detailsSpans.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text.rich(
                            TextSpan(children: detailsSpans),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // For foreign currency debt, convert to app currency for display
                      Builder(
                        builder: (context) {
                          int displayAmount = item.amountMinorUnits;
                          if (item.type == PulseType.debt &&
                              item.balanceCurrency != null &&
                              item.exchangeRate != null &&
                              item.exchangeRate! > 0 &&
                              item.transactionAmountMinorUnits == null) {
                            // Legacy item: amount is in loan currency, convert to app currency
                            // Exchange rate is: 1 [loan currency] = X [app currency]
                            displayAmount =
                                (item.amountMinorUnits * item.exchangeRate!)
                                    .round();
                          }
                          return Text(
                            formatMoneyFromCents(
                              displayAmount,
                              settings.currency,
                              showCents: settings.showCents,
                            ),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: amountColor,
                              fontFeatures: const [
                                FontFeature.tabularFigures(),
                              ],
                            ),
                          );
                        },
                      ),
                      if (dueLabel != null &&
                          item.type != PulseType.spendingEnvelope) ...[
                        const SizedBox(height: 4),
                        Text(
                          '${l10n?.dueLabel ?? 'Due'} $dueLabel',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onSurfaceVariant,
                                    fontSize: 11,
                                  ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      final direction = _pulseDismissDirection(
        left: settings.pulseSwipeLeft,
        right: settings.pulseSwipeRight,
      );
      if (direction == null) return tileContent;

      return Dismissible(
        key: ValueKey(item.id),
        direction: direction,
        background: item.archived
            ? _resumeDismissBackground(context, alignLeft: true)
            : _pulseDismissBackground(
                context,
                action: settings.pulseSwipeRight,
                alignLeft: true,
              ),
        secondaryBackground: item.archived
            ? _resumeDismissBackground(context, alignLeft: false)
            : _pulseDismissBackground(
                context,
                action: settings.pulseSwipeLeft,
                alignLeft: false,
              ),
        confirmDismiss: (dismissDirection) async {
          final action = dismissDirection == DismissDirection.endToStart
              ? settings.pulseSwipeLeft
              : settings.pulseSwipeRight;
          return _handlePulseSwipeAction(context, item, action);
        },
        child: tileContent,
      );
    } else {
      final p = listItem.standalonePulse;
      if (p == null) return const SizedBox.shrink();
      final isDebit = p.amountMinorUnits < 0;
      final amountColor = isDebit ? settings.debitColor : settings.creditColor;

      final tileContent = InkWell(
        onTap: () => _showUpdatePulseSheetStandalone(context, p),
        onLongPress: () => _showStandalonePulseActions(context, p),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: Theme.of(
                  context,
                ).colorScheme.outlineVariant.withValues(alpha: 0.3),
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 36,
                decoration: BoxDecoration(
                  color: amountColor.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.label.isEmpty ? 'Pulse' : p.label,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _formatDate(p.date),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                            fontSize: 11,
                          ),
                    ),
                  ],
                ),
              ),
              Text(
                formatMoneyFromCents(
                  p.amountMinorUnits,
                  settings.currency,
                  showCents: settings.showCents,
                ),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: amountColor,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
        ),
      );

      return Dismissible(
        key: ValueKey('pulse_${p.id}'),
        background: _pulseDismissBackground(
          context,
          action: PulseSwipeAction.delete,
          alignLeft: true,
        ),
        secondaryBackground: _pulseDismissBackground(
          context,
          action: PulseSwipeAction.delete,
          alignLeft: false,
        ),
        confirmDismiss: (direction) async {
          final confirmed = await _confirmDeleteStandalone(context, p);
          if (confirmed) {
            store.deletePulse(p.id);
            if (!settings.balanceUpdatesDisabled) {
              settings.currentBalanceCents -= p.amountMinorUnits;
            }
          }
          return confirmed;
        },
        child: tileContent,
      );
    }
  }

  Future<void> _showUpsertTimelineItemSheet(
    BuildContext context, {
    TimelineItem? existing,
  }) async {
    final store = ExpenseStoreScope.read(context);
    final result = await showModalBottomSheet<TimelineItem>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpsertTimelineItemSheet(
        existing: existing,
        defaultStartDate: store.selectedMonth,
        onDelete: existing == null
            ? null
            : () {
                // Deletion logic
                // Note: We use existing logic to prompt "Delete History?" or just delete item?
                // UpsertTimelineItemSheet confirms "delete this item?".
                // The callback is executed AFTER user confirms in the sheet.
                // So we just perform the delete here.

                // However, store.deleteTimelineItem has a keepHistory optional param.
                // If the user deletes from the Edit Sheet, do we assume they want to delete history too?
                // Or should we ask?
                // The sheet's confirmation dialog (UpsertTimelineItemSheet._confirmDelete) is generic.
                // Maybe we should launch the advanced delete dialog here?

                // Re-using _confirmDelete (the advanced one with history checkbox) might be weird
                // because the sheet is still open or just closing?
                // Actually, UpsertTimelineItemSheet closes itself when onDelete is called.

                // Let's use the advanced confirmation logic if history exists,
                // but the sheet is closed now.

                // Wait, UpsertTimelineItemSheet calls onDelete THEN pops. (Wait, let's checking UpsertTimelineItemSheet logic)
                // It calls `widget.onDelete?.call(); Navigator.pop(context);`
                // So we are still "in" the sheet build context but logic runs.

                // Ideally, we just delete the item. If the user wants granular control (delete history),
                // they usually go through the menu.
                // A simple "Delete" button on edit Usually implies "Delete this item".
                // We'll keep history by default to be safe? Or delete?
                // Most users expect "Delete" to nuke it.
                // Let's safe delete (keep history) for now or check if we can show the dialog?
                // Show dialog on top of sheet is possible.

                // Actually, simply calling store.deleteTimelineItem(id) deletes the *Future* definitions.
                store.deleteTimelineItem(existing.id);
              },
      ),
    );

    if (!context.mounted || result == null) return;
    store.upsertTimelineItem(result);
    if (context.mounted) {
      showActivitySavedSnackBar(context, result);
    }
  }

  Future<void> _showAddMenu(BuildContext context) async {
    _showUpsertTimelineItemSheet(context);
  }

  Future<void> _showUpdatePulseSheetStandalone(
    BuildContext context,
    PulseEntry pulse,
  ) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final oldAmount = pulse.amountMinorUnits;

    final result = await showModalBottomSheet<PulseEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpdatePulseSheet(
        pulse: pulse,
        title: 'Edit Transaction',
        onDelete: () {
          store.deletePulse(pulse.id);
          if (!settings.balanceUpdatesDisabled) {
            settings.currentBalanceCents -= pulse.amountMinorUnits;
          }
        },
      ),
    );

    if (!context.mounted || result == null) return;

    store.upsertPulse(result);
    if (!settings.balanceUpdatesDisabled) {
      settings.currentBalanceCents =
          settings.currentBalanceCents - oldAmount + result.amountMinorUnits;
    }
  }

  Future<void> _showStandalonePulseActions(
    BuildContext context,
    PulseEntry pulse,
  ) async {
    final localizations = AppLocalizations.of(context);
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    final action = await showModalBottomSheet<_StandalonePulseAction>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.pencilSimple()),
              title: Text(localizations?.edit ?? 'Edit'),
              onTap: () => Navigator.pop(context, _StandalonePulseAction.edit),
            ),
            ListTile(
              leading: PhosphorIcon(PhosphorIcons.trash()),
              title: Text(localizations?.delete ?? 'Delete'),
              onTap: () =>
                  Navigator.pop(context, _StandalonePulseAction.delete),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );

    if (!context.mounted || action == null) return;

    if (action == _StandalonePulseAction.edit) {
      _showUpdatePulseSheetStandalone(context, pulse);
    } else if (action == _StandalonePulseAction.delete) {
      final confirmed = await _confirmDeleteStandalone(context, pulse);
      if (confirmed && context.mounted) {
        store.deletePulse(pulse.id);
        if (!settings.balanceUpdatesDisabled) {
          settings.currentBalanceCents -= pulse.amountMinorUnits;
        }
      }
    }
  }

  Future<bool> _confirmDeleteStandalone(
    BuildContext context,
    PulseEntry pulse,
  ) async {
    final localizations = AppLocalizations.of(context);
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(localizations?.delete ?? 'Delete'),
            content: Text(
              'Are you sure you want to delete this transaction: ${pulse.label}?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(localizations?.cancel ?? 'Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.error,
                ),
                child: Text(localizations?.delete ?? 'Delete'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

enum _StandalonePulseAction { edit, delete }

DateTime? _nextDueDate({
  required TimelineItem item,
  required Map<String, List<PulseEntry>> pulseLookupMap,
  required AppSettingsStore settings,
}) {
  // Spending envelopes don't have specific "due dates" - they represent a monthly period
  if (item.type == PulseType.spendingEnvelope) return null;

  final now = DateTime.now();
  final today = DateTime.utc(now.year, now.month, now.day);

  // Determine current period reference month (paycheck-aware)
  final DateTime currentPeriodMonth;
  if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
      settings.isPaycheckModeConfigured) {
    currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      now,
      settings.paycheckDay!,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
  } else {
    currentPeriodMonth = monthOnly(now);
  }

  // For one-off items, check if they're still relevant
  if (item.type == PulseType.oneOff || item.type == PulseType.oneOffIncome) {
    final startMonthOfItem = monthOnly(item.startDate);
    // If the item's start month is before the current period, no next due date
    if (startMonthOfItem.isBefore(currentPeriodMonth)) return null;
  }

  // Start checking from up to 3 months ago to catch overdue items,
  // but never before the item's start date.
  // Exception: In Calendar Mode, we only care about Future/Current due dates (user request),
  // so we skip looking at months prior to the current one.
  final DateTime checkStartBound;
  if (settings.viewPeriodMode == ViewPeriodMode.calendar) {
    checkStartBound = currentPeriodMonth;
  } else {
    checkStartBound = DateTime.utc(now.year, now.month - 3, 1);
  }

  final startMonthOfItem = monthOnly(item.startDate);

  var checkMonth = checkStartBound.isBefore(startMonthOfItem)
      ? startMonthOfItem
      : checkStartBound;

  // Check up to 16 periods ahead (3 back + 13 forward)
  for (var i = 0; i < 16; i++) {
    // Get period info for this reference month
    final periodInfo = PaycheckService.getPeriodInfo(
      checkMonth,
      settings.viewPeriodMode,
      settings.paycheckDay,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );

    // Check if item should appear in this PERIOD (not just calendar month)
    if (!PaycheckService.shouldItemAppearInPeriod(
      item,
      periodInfo,
      checkMonth,
    )) {
      checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);
      continue;
    }

    // Calculate the effective due date
    // For paycheck mode, we need to determine if the item falls in the
    // tail of the period (previous month portion) or head (current month portion)
    DateTime dueDate;
    final itemDay = item.dayOfMonth;

    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      // Check if item's day falls in the "tail" portion (previous month, after paycheckDay)
      final prevMonth = DateTime.utc(checkMonth.year, checkMonth.month - 1);
      final daysInPrevMonth = DateTime.utc(
        prevMonth.year,
        prevMonth.month + 1,
        0,
      ).day;
      final effectiveDayPrev =
          itemDay > daysInPrevMonth ? daysInPrevMonth : itemDay;

      if (effectiveDayPrev >= periodInfo.start.day &&
          periodInfo.start.month == prevMonth.month &&
          item.shouldAppearInMonth(prevMonth)) {
        // Item falls in the tail portion (previous month)
        dueDate = DateTime.utc(
          prevMonth.year,
          prevMonth.month,
          effectiveDayPrev,
        );
      } else {
        // Item falls in the head portion (current month, before paycheckDay)
        final daysInMonth = DateTime.utc(
          checkMonth.year,
          checkMonth.month + 1,
          0,
        ).day;
        final effectiveDay = itemDay > daysInMonth ? daysInMonth : itemDay;
        dueDate = DateTime.utc(checkMonth.year, checkMonth.month, effectiveDay);
      }
    } else {
      // Calendar mode: standard calculation
      final maxDay = DateUtils.getDaysInMonth(
        checkMonth.year,
        checkMonth.month,
      );
      final effectiveDay = itemDay <= maxDay ? itemDay : maxDay;
      dueDate = DateTime.utc(checkMonth.year, checkMonth.month, effectiveDay);
    }

    // Check if this occurrence is cleared using O(1) lookup
    final isCleared = findPulseWithMap(
          item: item,
          pulseMap: pulseLookupMap,
          month: checkMonth,
          settings: settings,
          periodInfo: periodInfo,
        ) !=
        null;

    // If not cleared, this is a candidate for next due date
    if (!isCleared) {
      // Return it if it's today or in the future
      if (!dueDate.isBefore(today)) {
        return dueDate;
      }

      // If it's in the past (overdue), skip it and find the next upcoming due date
      // to avoid showing past dates in the Activity screen.
    }

    // Move to next period reference month
    checkMonth = DateTime.utc(checkMonth.year, checkMonth.month + 1, 1);

    // Safety break: don't search more than 13 months into the future from now
    if (checkMonth.isAfter(DateTime.utc(now.year, now.month + 13, 1))) {
      break;
    }
  }

  return null;
}

// Using findPulseWithMap from timeline_actions.dart for O(1) pulse lookups

String _formatDueDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

DismissDirection? _pulseDismissDirection({
  required PulseSwipeAction left,
  required PulseSwipeAction right,
}) {
  final leftEnabled = left != PulseSwipeAction.off;
  final rightEnabled = right != PulseSwipeAction.off;
  if (leftEnabled && rightEnabled) return DismissDirection.horizontal;
  if (leftEnabled) return DismissDirection.endToStart;
  if (rightEnabled) return DismissDirection.startToEnd;
  return null;
}

Widget _resumeDismissBackground(
  BuildContext context, {
  required bool alignLeft,
}) {
  final bg = Theme.of(context).colorScheme.primaryContainer;
  final fg = Theme.of(context).colorScheme.onPrimaryContainer;
  final icon = PhosphorIcons.play();
  final label = Terminology.of(context).unarchiveActionLabel;

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Widget _pulseDismissBackground(
  BuildContext context, {
  required PulseSwipeAction action,
  required bool alignLeft,
}) {
  final (bg, fg, label, icon) = switch (action) {
    PulseSwipeAction.off => (
        Theme.of(context).colorScheme.surface,
        Theme.of(context).colorScheme.onSurface,
        '',
        PhosphorIcons.prohibit(),
      ),
    PulseSwipeAction.edit => (
        Theme.of(context).colorScheme.primaryContainer,
        Theme.of(context).colorScheme.onPrimaryContainer,
        AppLocalizations.of(context)?.edit ?? 'Edit',
        PhosphorIcons.pencilSimple(),
      ),
    PulseSwipeAction.delete => (
        Theme.of(context).colorScheme.errorContainer,
        Theme.of(context).colorScheme.onErrorContainer,
        AppLocalizations.of(context)?.delete ?? 'Delete',
        PhosphorIcons.trash(),
      ),
  };

  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

Future<bool> _handlePulseSwipeAction(
  BuildContext context,
  TimelineItem item,
  PulseSwipeAction action,
) async {
  final store = ExpenseStoreScope.read(context);

  // If item is ended, any swipe action resumes it
  if (item.archived) {
    store.setTimelineItemArchived(item.id, false);
    if (context.mounted) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(
            AppLocalizations.of(context)?.pulseResumed(item.label) ??
                'Pulse resumed',
          ),
          duration: AppConstants.snackBarShort,
          action: SnackBarAction(
            label: AppLocalizations.of(context)?.undo ?? 'Undo',
            onPressed: () => store.setTimelineItemArchived(item.id, true),
          ),
        ),
      );
    }
    return false;
  }

  // Normal behavior for non-archived items
  switch (action) {
    case PulseSwipeAction.off:
      return false;
    case PulseSwipeAction.edit:
      final result = await showModalBottomSheet<TimelineItem>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpsertTimelineItemSheet(
          existing: item,
          defaultStartDate: store.selectedMonth,
        ),
      );
      if (result != null) store.upsertTimelineItem(result);
      return false;
    case PulseSwipeAction.delete:
      final (confirmed, deleteHistory) = await _confirmDelete(context, item);
      if (confirmed) {
        store.deleteTimelineItem(item.id, keepHistory: !deleteHistory);
      }
      return false;
  }
}

Future<(bool, bool)> _confirmDelete(
  BuildContext context,
  TimelineItem item,
) async {
  final store = ExpenseStoreScope.read(context);
  final hasHistory = store.pulses.any((p) => p.timelineItemId == item.id);
  bool deleteHistory = false;

  final confirmed = await showDialog<bool>(
    context: context,
    builder: (context) {
      final l10n = AppLocalizations.of(context);
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text(l10n?.delete ?? 'Delete'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Are you sure you want to delete "${item.label}"?'),
                if (hasHistory) ...[
                  const SizedBox(height: 16),
                  CheckboxListTile(
                    title: const Text('Delete transaction history'),
                    value: deleteHistory,
                    onChanged: (val) =>
                        setState(() => deleteHistory = val ?? false),
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(l10n?.cancel ?? 'Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.error,
                ),
                child: Text(l10n?.delete ?? 'Delete'),
              ),
            ],
          );
        },
      );
    },
  );

  return (confirmed ?? false, deleteHistory);
}

String _formatDate(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}
