import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/widgets/compact_chip.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Shows the compact filter bottom sheet for the Pulse screen.
Future<void> showPulseFilterSheet({
  required BuildContext context,
  required AppSettingsStore settings,
  required ExpenseStore store,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: Theme.of(context).colorScheme.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(AppConstants.radiusSheetTop),
      ),
    ),
    builder: (context) => PulseFilterSheet(settings: settings, store: store),
  );
}

class PulseFilterSheet extends StatefulWidget {
  final AppSettingsStore settings;
  final ExpenseStore store;

  const PulseFilterSheet({
    super.key,
    required this.settings,
    required this.store,
  });

  @override
  State<PulseFilterSheet> createState() => _PulseFilterSheetState();
}

class _PulseFilterSheetState extends State<PulseFilterSheet> {
  AppSettingsStore get settings => widget.settings;
  ExpenseStore get store => widget.store;

  int get activeFilterCount {
    int count = 0;
    if (settings.pulseFilterType != PulsesFilterType.all) count++;
    if (settings.pulseGroupBy != PulsesGroupBy.none) count++;
    if (settings.pulseShowArchived) count++;
    return count;
  }

  void _clearAllFilters() {
    setState(() {
      settings.pulseFilterType = PulsesFilterType.all;
      settings.pulseFilterCategory = null;
      settings.pulseGroupBy = PulsesGroupBy.none;
      settings.pulseShowArchived = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: AnimatedSize(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Compact Header
              _buildHeader(context, theme, colorScheme),
              const SizedBox(height: 16),

              // Filter Type Section
              _buildSectionRow(
                context,
                title: 'Type',
                theme: theme,
                trailing: settings.pulseShowArchived
                    ? _buildCompactArchivedChip(
                        context,
                        theme,
                        colorScheme,
                        l10n,
                      )
                    : _buildArchivedToggleButton(
                        context,
                        theme,
                        colorScheme,
                        l10n,
                      ),
              ),
              const SizedBox(height: 10),
              _buildFilterTypeChips(context, theme, colorScheme),

              // Category Selector (conditional)
              if (settings.pulseFilterType == PulsesFilterType.category) ...[
                const SizedBox(height: 12),
                _buildCategorySelector(context, theme, colorScheme),
              ],

              const SizedBox(height: 18),

              // Group By Section
              _buildSectionRow(context, title: 'Group by', theme: theme),
              const SizedBox(height: 10),
              _buildGroupByChips(context, theme, colorScheme),

              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Filter & Sort',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        if (activeFilterCount > 0)
          TextButton.icon(
            onPressed: _clearAllFilters,
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              visualDensity: VisualDensity.compact,
            ),
            icon: Icon(Icons.clear_all, size: 18, color: colorScheme.error),
            label: Text(
              'Clear',
              style: theme.textTheme.labelMedium?.copyWith(
                color: colorScheme.error,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildSectionRow(
    BuildContext context, {
    required String title,
    required ThemeData theme,
    Widget? trailing,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: theme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onSurfaceVariant,
            letterSpacing: 0.5,
          ),
        ),
        if (trailing != null) trailing,
      ],
    );
  }

  /// Compact toggle button for "Show Archived" (when not active)
  Widget _buildArchivedToggleButton(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
    AppLocalizations? l10n,
  ) {
    return InkWell(
      onTap: () => setState(() => settings.pulseShowArchived = true),
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.visibility_off_outlined,
              size: 14,
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
            ),
            const SizedBox(width: 4),
            Text(
              l10n?.showArchived ?? 'Show Archived',
              style: theme.textTheme.labelSmall?.copyWith(
                color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Compact chip shown when "Show Archived" is active
  Widget _buildCompactArchivedChip(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
    AppLocalizations? l10n,
  ) {
    return InkWell(
      onTap: () => setState(() => settings.pulseShowArchived = false),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: colorScheme.secondaryContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.visibility,
              size: 12,
              color: colorScheme.onSecondaryContainer,
            ),
            const SizedBox(width: 4),
            Text(
              'Archived',
              style: theme.textTheme.labelSmall?.copyWith(
                color: colorScheme.onSecondaryContainer,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 2),
            Icon(
              Icons.close,
              size: 12,
              color: colorScheme.onSecondaryContainer.withValues(alpha: 0.7),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTypeChips(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    final filterOptions = [
      (PulsesFilterType.all, 'All', PhosphorIcons.squaresFour()),
      (PulsesFilterType.income, 'Income', PhosphorIcons.arrowDown()),
      (PulsesFilterType.expenses, 'Expenses', PhosphorIcons.arrowUp()),
      (PulsesFilterType.debt, 'Debt', PhosphorIcons.scales()),
      (PulsesFilterType.recurring, 'Recurring', PhosphorIcons.repeat()),
      (PulsesFilterType.envelopes, 'Envelopes', PhosphorIcons.envelope()),
      (PulsesFilterType.oneOff, 'One-off', PhosphorIcons.lightning()),
      (PulsesFilterType.category, 'Category', PhosphorIcons.tag()),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: filterOptions.map((option) {
        final (type, label, icon) = option;
        final isSelected = settings.pulseFilterType == type;

        return CompactChip(
          label: label,
          icon: icon,
          isSelected: isSelected,
          usePrimaryColor: true,
          onTap: () {
            setState(() {
              if (type == PulsesFilterType.category) {
                settings.pulseFilterType = type;
              } else {
                settings.pulseFilterType =
                    isSelected ? PulsesFilterType.all : type;
              }
            });
          },
        );
      }).toList(),
    );
  }

  Widget _buildCategorySelector(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    final allCategories = <String>{
      ...incomeCategories,
      ...expenseCategories,
      ...store.currentAccount.customExpenseCategories,
      ...store.currentAccount.customIncomeCategories,
    }.toList()
      ..sort();

    final selectedCategory = settings.pulseFilterCategory;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select category:',
            style: theme.textTheme.labelSmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 120),
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 6,
                runSpacing: 6,
                children: allCategories.map((category) {
                  final isSelected = selectedCategory == category;
                  return CompactChip(
                    label: category,
                    isSelected: isSelected,
                    usePrimaryColor: false,
                    small: true,
                    onTap: () {
                      setState(() {
                        settings.pulseFilterCategory =
                            isSelected ? null : category;
                      });
                    },
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupByChips(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    final groupOptions = [
      (PulsesGroupBy.category, 'Category', PhosphorIcons.tag()),
      (PulsesGroupBy.type, 'Type', PhosphorIcons.listBullets()),
      (PulsesGroupBy.origin, 'Origin', PhosphorIcons.mapPin()),
      (PulsesGroupBy.dueDate, 'Due Date', PhosphorIcons.calendar()),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: groupOptions.map((option) {
        final (groupBy, label, icon) = option;
        final isSelected = settings.pulseGroupBy == groupBy;

        return CompactChip(
          label: label,
          icon: icon,
          isSelected: isSelected,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.pulseGroupBy = isSelected ? PulsesGroupBy.none : groupBy;
            });
          },
        );
      }).toList(),
    );
  }
}
