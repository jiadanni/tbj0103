import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import '../../../util/insights_calculator.dart';
import 'smart_question_card.dart';

class ScrollingInsightsList extends StatefulWidget {
  const ScrollingInsightsList({
    super.key,
    required this.insights,
    this.speed = 30.0, // Pixels per second
    this.onDismissed,
  });

  final List<SmartInsight> insights;
  final double speed;
  final Function(SmartInsight)? onDismissed;

  @override
  State<ScrollingInsightsList> createState() => _ScrollingInsightsListState();
}

class _ScrollingInsightsListState extends State<ScrollingInsightsList> {
  late ScrollController _scrollController;
  Timer? _resumeTimer;
  bool _isUserScrolling = false;
  final Set<String> _expandedIds = {};
  bool _isAutoScrolling = false;
  static const double _scrollStep = AppConstants.autoScrollStep;
  static const Duration _resumeDelay = AppConstants.autoScrollResumeDelay;

  @override
  void initState() {
    super.initState();
    // Start in the "middle" so user can scroll up
    _scrollController = ScrollController(initialScrollOffset: 0);
    WidgetsBinding.instance.addPostFrameCallback((_) => _startAutoScroll());
  }

  void _startAutoScroll() {
    if (!mounted || _isUserScrolling || widget.insights.isEmpty) return;
    if (!_scrollController.hasClients) return;

    _isAutoScrolling = true;

    // Animate a bit further down
    final currentFn = _scrollController.offset;
    final target = currentFn + _scrollStep;
    // time = distance / speed
    final duration = Duration(
      milliseconds: ((_scrollStep / widget.speed) * 1000).round(),
    );

    _scrollController
        .animateTo(target, duration: duration, curve: Curves.linear)
        .then((_) {
      if (mounted && _isAutoScrolling) {
        _startAutoScroll();
      }
    });
  }

  void _stopAutoScroll() {
    _isAutoScrolling = false;
    // We don't need to "stop" the animation abruptly as `animateTo` will complete,
    // but the recursive call is guarded by `_isAutoScrolling` & `_isUserScrolling`.
    // However, if we want to stop 'now', we can jump to current offset.
    // But that might cancel momentum.
    // Usually UserScrollNotification handles the "stop".
  }

  @override
  void dispose() {
    _stopAutoScroll();
    _scrollController.dispose();
    _resumeTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.insights.isEmpty) {
      return const Center(child: Text('No insights available yet'));
    }

    final theme = Theme.of(context);

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) {
        // Stop auto-scroll immediately on any touch to prevent gesture conflicts
        if (_isAutoScrolling) {
          _isAutoScrolling = false;
          _resumeTimer?.cancel();
          // Use jumpTo to stop active animation without interfering with tap
          if (_scrollController.hasClients) {
            _scrollController.jumpTo(_scrollController.offset);
          }
        }
      },
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is UserScrollNotification) {
            if (notification.direction != ScrollDirection.idle) {
              _isUserScrolling = true;
              _isAutoScrolling = false;
              _resumeTimer?.cancel();
            } else {
              // User stopped dragging
              _isUserScrolling = false;
              _resumeTimer = Timer(_resumeDelay, _startAutoScroll);
            }
          }
          return false;
        },
        child: ListView.builder(
          controller: _scrollController,
          // Limit to a large but finite number to avoid infinite loop crashes
          // while still providing infinite-like scrolling experience.
          itemCount: widget.insights.isEmpty
              ? 0
              : AppConstants.infiniteScrollItemCount,
          physics: const BouncingScrollPhysics(),
          itemBuilder: (context, index) {
            final adjustedIndex = index % widget.insights.length;
            final insight = widget.insights[adjustedIndex];

            final isLastInGroup = adjustedIndex == widget.insights.length - 1;

            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Dismissible(
                  key: Key(
                    'insight_${insight.id ?? insight.question}_$index',
                  ), // Unique key for every instance
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: theme.colorScheme.errorContainer,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: Icon(
                      Icons.delete_outline,
                      color: theme.colorScheme.onErrorContainer,
                    ),
                  ),
                  confirmDismiss: (_) async {
                    // Since it's infinite, removing an item is tricky visually.
                    // We'll just callback and let parent rebuild us with one less item.
                    // But we need to return false to prevent internal list removal animation failure on infinite lists?
                    // Actually, if we return true, it tries to remove index.
                    // Let's just return false and trigger the callback.
                    widget.onDismissed?.call(insight);
                    return false;
                  },
                  child: SmartQuestionCard(
                    insight: insight,
                    isExpanded: _expandedIds.contains(
                      insight.id ?? insight.question,
                    ),
                    onTap: () {
                      // Tap also pauses auto-scroll? Usually handled by touch, but let's be safe
                      // But expanding might change height, so keep scrolling logic simple?
                      // Let's toggle expansion
                      setState(() {
                        final id = insight.id ?? insight.question;
                        if (_expandedIds.contains(id)) {
                          _expandedIds.remove(id);
                        } else {
                          _expandedIds.add(id);
                        }
                      });
                    },
                  ),
                ),
                if (!isLastInGroup)
                  const Divider(height: 1, indent: 68)
                else
                  // Visual separator between cycles
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 4,
                          height: 4,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: theme.colorScheme.outlineVariant,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 4,
                          height: 4,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: theme.colorScheme.outlineVariant,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 4,
                          height: 4,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: theme.colorScheme.outlineVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
