import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/insight_context.dart';
import 'package:expense_stalker_mobile/src/util/insight_registry.dart';
import 'scrolling_insights_list.dart';

class InsightsDiscoverSheet extends StatefulWidget {
  const InsightsDiscoverSheet({super.key, required this.contextData});

  final InsightContext contextData;

  @override
  State<InsightsDiscoverSheet> createState() => _InsightsDiscoverSheetState();
}

class _InsightsDiscoverSheetState extends State<InsightsDiscoverSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    // Start animation after a brief delay to allow sheet to settle
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) _entryController.forward();
    });
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final allInsights = InsightRegistry.generateInsights(widget.contextData);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle/Header - Static, no animation
          Center(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: theme.colorScheme.onSurfaceVariant.withValues(
                  alpha: 0.3,
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Discover Insights',
                        style: theme.textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Based on your spending habits',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),
          const Divider(),
          Flexible(
            child: allInsights.isEmpty
                ? Center(
                    child: Text(
                      'No insights available right now.',
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  )
                : AnimatedBuilder(
                    animation: _entryController,
                    builder: (context, child) {
                      return FadeTransition(
                        opacity: _entryController,
                        child: child,
                      );
                    },
                    child: ScrollingInsightsList(
                      insights: allInsights,
                      speed: 25.0, // Adjust speed as needed
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
