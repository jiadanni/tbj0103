import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

/// Horizontal chip selector for date range filtering.
class DateRangeSelector extends StatelessWidget {
  const DateRangeSelector({
    super.key,
    required this.selectedRange,
    required this.onRangeChanged,
    this.isPaycheckMode = false,
  });

  final InsightsDateRange selectedRange;
  final ValueChanged<InsightsDateRange> onRangeChanged;
  final bool isPaycheckMode;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: InsightsDateRange.values.map((range) {
          final isSelected = range == selectedRange;
          final label = range.labelForMode(isPaycheckMode);
          return Padding(
            padding: const EdgeInsets.only(right: 8, bottom: 12),
            child: ChoiceChip(
              label: Text(label),
              selected: isSelected,
              onSelected: (_) => onRangeChanged(range),
            ),
          );
        }).toList(),
      ),
    );
  }
}
