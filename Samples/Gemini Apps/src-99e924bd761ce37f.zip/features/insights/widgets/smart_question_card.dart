import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

/// Displays a pre-generated Q&A insight card with tappable answer bubble.
class SmartQuestionCard extends StatefulWidget {
  const SmartQuestionCard({
    super.key,
    required this.insight,
    required this.isExpanded,
    required this.onTap,
  });

  final SmartInsight insight;
  final bool isExpanded;
  final VoidCallback onTap;

  @override
  State<SmartQuestionCard> createState() => _SmartQuestionCardState();
}

class _SmartQuestionCardState extends State<SmartQuestionCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    if (widget.isExpanded) {
      _animationController.forward();
    }
  }

  @override
  void didUpdateWidget(SmartQuestionCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isExpanded != oldWidget.isExpanded) {
      if (widget.isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Use a CurvedAnimation for smoother expanding/collapsing
    final curvedAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.fastOutSlowIn,
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Question Row - Always visible and tappable
          GestureDetector(
            onTap: widget.onTap,
            behavior: HitTestBehavior.opaque,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: widget.isExpanded
                        ? theme.colorScheme.primaryContainer
                        : theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _iconFromName(widget.insight.icon),
                    color: widget.isExpanded
                        ? theme.colorScheme.onPrimaryContainer
                        : theme.colorScheme.primary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      widget.insight.question,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: theme.colorScheme.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Answer Area - SizeTransition for height, then Fade/Slide for content
          SizeTransition(
            sizeFactor: curvedAnimation,
            axisAlignment: -1.0, // Expand from top
            child: Padding(
              padding: const EdgeInsets.only(left: 56, top: 8),
              child: FadeTransition(
                opacity: curvedAnimation,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, -0.2), // Slide down slightly
                    end: Offset.zero,
                  ).animate(curvedAnimation),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        left: BorderSide(
                          color: theme.colorScheme.primary.withValues(
                            alpha: 0.5,
                          ),
                          width: 2,
                        ),
                      ),
                    ),
                    padding: const EdgeInsets.only(left: 12, top: 4, bottom: 8),
                    child: Text(
                      widget.insight.answer,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.6,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _iconFromName(String name) {
    return switch (name) {
      'chartPie' => PhosphorIcons.chartPie(),
      'barbell' => PhosphorIcons.barbell(),
      'shoppingCart' => PhosphorIcons.shoppingCart(),
      'house' => PhosphorIcons.house(),
      'chartDonut' => PhosphorIcons.chartDonut(),
      'repeat' => PhosphorIcons.repeat(),
      'forkKnife' => PhosphorIcons.forkKnife(),
      'car' => PhosphorIcons.car(),
      'television' => PhosphorIcons.television(),
      'lightning' => PhosphorIcons.lightning(),
      'calendar' => PhosphorIcons.calendar(),
      'trophy' => PhosphorIcons.trophy(),
      'chartLineUp' => PhosphorIcons.chartLineUp(),
      'chartLine' => PhosphorIcons.chartLine(),
      'alertCircle' => PhosphorIcons.warningCircle(),
      'warning' => PhosphorIcons.warning(),
      _ => PhosphorIcons.lightbulb(),
    };
  }
}
