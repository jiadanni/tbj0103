import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

/// Displays category spending with average amount and priority indicator.
class CategorySpendingCard extends StatelessWidget {
  const CategorySpendingCard({
    super.key,
    required this.spending,
    required this.formatMoney,
    this.onTap,
  });

  final CategorySpending spending;
  final String Function(int) formatMoney;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final priorityColor = switch (spending.priority) {
      ExpensePriority.critical => theme.colorScheme.error,
      ExpensePriority.advisable => theme.colorScheme.primary,
      ExpensePriority.strategic => theme.colorScheme.secondary,
      ExpensePriority.optional => theme.colorScheme.tertiary,
      ExpensePriority.frivolous => theme.colorScheme.errorContainer,
    };

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            // Priority indicator
            Container(
              width: 4,
              height: 36,
              decoration: BoxDecoration(
                color: priorityColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    spending.category,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '${spending.transactionCount} transaction${spending.transactionCount == 1 ? '' : 's'}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  formatMoney(spending.averageMonthlyMinorUnits),
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  '/month avg',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
