import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/util/insights_calculator.dart';

/// Displays a spending trend card with percentage change.
class TrendAnalysisCard extends StatelessWidget {
  const TrendAnalysisCard({
    super.key,
    required this.trend,
    required this.formatMoney,
    this.onTap,
  });

  final SpendingTrend trend;
  final String Function(int) formatMoney;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isUp = trend.direction == TrendDirection.up;
    final isDown = trend.direction == TrendDirection.down;

    final trendColor = isUp
        ? Colors.red.shade600
        : isDown
            ? Colors.green.shade600
            : theme.colorScheme.onSurfaceVariant;

    final trendIcon = isUp
        ? PhosphorIcons.trendUp()
        : isDown
            ? PhosphorIcons.trendDown()
            : PhosphorIcons.minus();

    // TrendTile style
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: trendColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(trendIcon, color: trendColor, size: 18),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    trend.category,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '${formatMoney(trend.currentPeriodMinorUnits)} vs ${formatMoney(trend.previousPeriodMinorUnits)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              '${isUp ? '+' : ''}${trend.percentageChange.toStringAsFixed(0)}%',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: trendColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
