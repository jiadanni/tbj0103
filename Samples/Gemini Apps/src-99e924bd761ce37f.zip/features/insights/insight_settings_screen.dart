import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/insight_definitions.dart';
import 'package:expense_stalker_mobile/src/models/insight_definition.dart';

class InsightSettingsScreen extends StatelessWidget {
  const InsightSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final theme = Theme.of(context);
    final insightsSettings = settings.insightSettings;

    return ListenableBuilder(
      listenable: insightsSettings,
      builder: (context, _) {
        final dismissedIds = insightsSettings.dismissedInsightIds;

        return Scaffold(
          appBar: AppBar(title: const Text('Insight Settings')),
          body: ListView(
            children: [
              SwitchListTile(
                title: const Text('Show Behavioral Insights'),
                subtitle: const Text(
                  'Insights about your spending habits and patterns.',
                ),
                value: insightsSettings.showBehavioralInsights,
                onChanged: (v) => insightsSettings.showBehavioralInsights = v,
              ),
              SwitchListTile(
                title: const Text('Include Internal Transfers'),
                subtitle: const Text(
                  'Show transfers between own accounts in spending reports. '
                  'Turn off for cleaner spending analysis (recommended).',
                ),
                value: insightsSettings.includeInternalTransfers,
                onChanged: (v) => insightsSettings.includeInternalTransfers = v,
              ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  'DISMISSED INSIGHTS',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (dismissedIds.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text('No insights have been dismissed.'),
                )
              else
                ...dismissedIds.map((id) {
                  // Find the definition manually to avoid complex type casting issues in release builds
                  InsightDefinition? definition;
                  for (final d in initialInsightDefinitions) {
                    if (d.id == id) {
                      definition = d;
                      break;
                    }
                  }
                  final question =
                      definition?.question ?? 'Unknown dismissed insight';

                  return ListTile(
                    title: Text(question),
                    subtitle: Text('ID: $id'),
                    trailing: TextButton(
                      onPressed: () => insightsSettings.restoreInsight(id),
                      child: const Text('Restore'),
                    ),
                  );
                }),
              const Divider(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  'DEVELOPER TOOLS',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: theme.colorScheme.error,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                title: const Text('Minimum Data Days Override'),
                subtitle: Text(
                  insightsSettings.minDataDaysOverride == null
                      ? 'Currently: Using dynamic thresholds'
                      : 'Currently: Forced to ${insightsSettings.minDataDaysOverride} days',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: () => insightsSettings.minDataDaysOverride = 0,
                      child: const Text('Force 0'),
                    ),
                    TextButton(
                      onPressed: () =>
                          insightsSettings.minDataDaysOverride = null,
                      child: const Text('Reset'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'Lowering this value will show "advanced" insights even if you don\'t have much data yet. Use for testing only.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
