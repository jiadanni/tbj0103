import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' as vector;

import 'package:expense_stalker_mobile/src/models/timeline_item.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_dates.dart';

import 'package:expense_stalker_mobile/src/features/timeline/month_card.dart';
import 'package:expense_stalker_mobile/src/features/timeline/multi_month_grid.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/envelope_logic.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_balance.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_sheet.dart';

/// Computes the earliest month from timeline items' start dates.
/// Returns the current month if no items exist.
DateTime _earliestItemMonth(List<TimelineItem> items) {
  final nowMonth = monthOnly(DateTime.now());
  if (items.isEmpty) return nowMonth;
  var earliest = monthOnly(items.first.startDate);
  for (final item in items.skip(1)) {
    final start = monthOnly(item.startDate);
    if (start.isBefore(earliest)) earliest = start;
  }
  return earliest;
}

/// Computes the starting balance for a future month by chaining from current period.
/// Returns null for past/current periods.
int? _computeStartBalanceForMonth({
  required DateTime targetMonth,
  required DateTime currentPeriodMonth,
  required int currentBalanceCents,
  required List<TimelineItem> items,
  required Function(DateTime, PeriodInfo) Function(DateTime) pulseBuilder,
  required AppSettingsStore settings,
}) {
  return startBalanceCentsForMonth(
    month: targetMonth,
    currentBalanceCents: currentBalanceCents,
    useZeroBaseline: settings.timelineUseZeroBaseline,
    currentPeriodMonth: currentPeriodMonth,
    plannedTotalForMonth: (m) {
      final periodInfo = PaycheckService.getPeriodInfo(
        m,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
        includeMonth: settings.paycheckShowMonthInTimeline,
      );

      final pulses = pulseBuilder(m)(m, periodInfo);

      final isCurrentPeriod = m.year == currentPeriodMonth.year &&
          m.month == currentPeriodMonth.month;

      return calculateTotalNetChangeForPeriod(
        month: m,
        items: items,
        pulses: pulses,
        periodInfo: periodInfo,
        isCurrentPeriod: isCurrentPeriod,
        settings: settings,
      );
    },
  );
}

/// Builds the month view (single month with PageView).
Widget buildMonthView({
  required BuildContext context,
  required PageController pageController,
  required ExpenseStore store,
  required List<TimelineItem> items,
  required AppSettingsStore settings,
  required TimelineSortOrder sortOrder,
  required DateTime monthOrigin,
  required int monthOriginPage,
  required int monthWindowSize,
  required bool showClearedItems,
  required VoidCallback onPinchOut,
  required Function(int) onPageChanged,
  required Function(DateTime, PeriodInfo) Function(DateTime) pulseBuilder,
}) {
  final now = DateTime.now();
  final showClearedPreference = showClearedItems;

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth =
      (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
              settings.isPaycheckModeConfigured)
          ? PaycheckService.getCurrentPaycheckPeriodMonth(
              now,
              settings.paycheckDay!,
              businessAdjust: settings.paycheckBusinessAdjust,
              adjustDirection: settings.paycheckBusinessAdjustDirection,
            )
          : monthOnly(now);

  double lastScale = 1.0;

  // Compute a single hash for all items to reuse across all month cards (avoid redundant recomputation)
  // Use Object.hashAll to ensure ANY change to an item (including startDate, frequency, etc.) invalidates the key
  final itemsHash = Object.hashAll(items);

  return GestureDetector(
    onScaleStart: (_) {
      lastScale = 1.0;
    },
    onScaleUpdate: (details) {
      lastScale = details.scale;
    },
    onScaleEnd: (_) {
      if (lastScale < 0.92) {
        onPinchOut();
      }
    },
    child: PageView.builder(
      controller: pageController,
      onPageChanged: onPageChanged,
      itemCount: monthWindowSize,
      itemBuilder: (context, index) {
        final month = monthForPage(monthOrigin, index, monthOriginPage);

        final showClearedForCard = showClearedPreference;
        final periodInfo = PaycheckService.getPeriodInfo(
          month,
          settings.viewPeriodMode,
          settings.paycheckDay,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
          includeMonth: settings.paycheckShowMonthInTimeline,
        );
        final pulse = pulseBuilder(month)(month, periodInfo);

        // Precompute starting balance for future months
        // This ensures correct cleared state handling across periods
        final precomputedBalance = _computeStartBalanceForMonth(
          targetMonth: month,
          currentPeriodMonth: currentPeriodMonth,
          currentBalanceCents: settings.currentBalanceCents,
          items: items,
          pulseBuilder: pulseBuilder,
          settings: settings,
        );

        return Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: MonthCard(
            // Key based on pulse count AND reused items hash to force rebuild when either changes
            key: ValueKey(
              '${month.year}-${month.month}-${pulse.length}-$itemsHash',
            ),
            month: month,
            items: items,
            pulses: pulse,
            recentlyClearedItemIds: store.recentlyClearedTimelineItemIds,
            swipeLeft: settings.timelineSwipeLeft,
            swipeRight: settings.timelineSwipeRight,
            settings: settings,
            showCleared: showClearedForCard,
            sortOrder: sortOrder,
            dateSortMode: settings.timelineDateSortMode,
            displayMode: monthCardDisplayModeToPulseMode(
              settings.monthCardDisplayMode,
            ),
            precomputedStartBalanceCents: precomputedBalance,
            onJumpToMonth: (picked) {
              store.setSelectedMonth(picked);
            },
          ),
        );
      },
    ),
  );
}

/// Builds the grid view (multi-month grid with zoom).
Widget buildGridView({
  required BuildContext context,
  required TransformationController gridTransformController,
  required ExpenseStore store,
  required List<TimelineItem> items,
  required AppSettingsStore settings,
  required TimelineSortOrder sortOrder,
  required double viewportWidth,
  required DateTime selectedMonth,
  required int gridColumns,
  required bool showClearedItems,
  required VoidCallback onInitGridTransform,
  required Function(ScaleEndDetails) onSnap,
  required Function(DateTime) onMonthTapped,
  required Function(DateTime, PeriodInfo) Function(DateTime) pulseBuilder,
}) {
  final now = DateTime.now();
  // Start from earliest timeline item, show up to 24 months after selected
  final earliestMonth = _earliestItemMonth(items);
  final monthsBefore = monthsBetween(earliestMonth, selectedMonth);
  final gridMonths = monthRange(selectedMonth, before: monthsBefore, after: 24);
  final baseBalance =
      settings.timelineUseZeroBaseline ? 0 : settings.currentBalanceCents;

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth =
      (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
              settings.isPaycheckModeConfigured)
          ? PaycheckService.getCurrentPaycheckPeriodMonth(
              now,
              settings.paycheckDay!,
              businessAdjust: settings.paycheckBusinessAdjust,
              adjustDirection: settings.paycheckBusinessAdjustDirection,
            )
          : monthOnly(now);

  return ClipRect(
    child: ListenableBuilder(
      listenable: gridTransformController,
      builder: (context, _) {
        return InteractiveViewer(
          transformationController: gridTransformController,
          minScale: 0.3,
          maxScale: 2.0,
          constrained: false,
          boundaryMargin: EdgeInsets.zero,
          onInteractionEnd: (details) {
            // Snap to nearest row boundary when interaction ends
            onSnap(details);
          },
          child: MultiMonthGrid(
            months: gridMonths,
            items: items,
            pulseForMonth: (month) {
              final periodInfo = PaycheckService.getPeriodInfo(
                month,
                settings.viewPeriodMode,
                settings.paycheckDay,
                businessAdjust: settings.paycheckBusinessAdjust,
                adjustDirection: settings.paycheckBusinessAdjustDirection,
                includeMonth: settings.paycheckShowMonthInTimeline,
              );
              return pulseBuilder(month)(month, periodInfo);
            },
            currency: settings.currencySettings.currency,
            currentMonth: currentPeriodMonth,
            showClearedForCurrentMonth: showClearedItems,
            recentlyClearedItemIds: store.recentlyClearedTimelineItemIds,
            sortOrder: sortOrder,
            dateSortMode: settings.timelineDateSortMode,
            dayFormat: settings.dayFormat,
            columnsPerRow: gridColumns,
            startingBalanceCents: baseBalance,
            settings: settings,
            displayMode: multiMonthDisplayModeToPulseMode(
              settings.getMultiMonthDisplayMode(TimelineViewMode.grid),
            ),
            onMonthTapped: onMonthTapped,
          ),
        );
      },
    ),
  );
}

/// Builds the sheet view (horizontal spreadsheet-style).
Widget buildSheetView({
  required BuildContext context,
  required TransformationController sheetTransformController,
  required ExpenseStore store,
  required List<TimelineItem> items,
  required AppSettingsStore settings,
  required TimelineSortOrder sortOrder,
  required double viewportWidth,
  required DateTime selectedMonth,
  required GridZoomStage zoomStage,
  required int startingBalanceCents,
  required bool showClearedItems,
  required VoidCallback onInitSheetTransform,
  required Function(ScaleEndDetails) onSnap,
  required Function(DateTime) onMonthTapped,
  required Function(DateTime, PeriodInfo) Function(DateTime) pulseBuilder,
}) {
  final now = DateTime.now();
  // Start from earliest timeline item, show up to 36 months after selected
  final earliestMonth = _earliestItemMonth(items);
  final monthsBefore = monthsBetween(earliestMonth, selectedMonth);
  final sheetMonths = monthRange(
    selectedMonth,
    before: monthsBefore,
    after: 36,
  );

  // Determine current period reference month for paycheck mode
  final DateTime currentPeriodMonth =
      (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
              settings.isPaycheckModeConfigured)
          ? PaycheckService.getCurrentPaycheckPeriodMonth(
              now,
              settings.paycheckDay!,
              businessAdjust: settings.paycheckBusinessAdjust,
              adjustDirection: settings.paycheckBusinessAdjustDirection,
            )
          : monthOnly(now);

  // No longer needed here, will be built inside LayoutBuilder
  // final footerRow = ...
  // final headerRow = ...
  // final timelineSheet = ...

  return LayoutBuilder(
    builder: (context, constraints) {
      final headerHeight = SheetHeaderRow.getHeaderHeight(zoomStage, settings);
      final footerHeight = SheetFooterRow.getFooterHeight(zoomStage, settings);

      // Calculate remaining height for the scrollable list
      // Ensure we have at least some space if constraints are weird
      final availableHeight = constraints.maxHeight;
      final listHeight = (availableHeight - headerHeight - footerHeight).clamp(
        100.0,
        double.infinity,
      );

      // Reconstruct TimelineSheet here to use the dynamic viewport height

      return ClipRect(
        child: ListenableBuilder(
          listenable: sheetTransformController,
          builder: (context, _) {
            final tValue = sheetTransformController.value;
            final scaleX = tValue.getMaxScaleOnAxis();
            final transX = tValue.getTranslation().x;

            return Stack(
              children: [
                InteractiveViewer(
                  transformationController: sheetTransformController,
                  minScale: 0.28,
                  maxScale: 2.5,
                  constrained: false,
                  panEnabled: true,
                  panAxis: PanAxis.horizontal,
                  scaleEnabled: true,
                  boundaryMargin: EdgeInsets.symmetric(
                    horizontal: sheetMonths.length *
                        TimelineSheet.getColumnWidth(settings),
                    vertical: 0,
                  ),
                  onInteractionEnd: (details) {
                    onSnap(details);
                  },
                  child: ListenableBuilder(
                    listenable: settings,
                    builder: (context, _) {
                      final hHeight = SheetHeaderRow.getHeaderHeight(
                        zoomStage,
                        settings,
                      );
                      final fHeight = SheetFooterRow.getFooterHeight(
                        zoomStage,
                        settings,
                      );

                      final tSheet = TimelineSheet(
                        months: sheetMonths,
                        items: items,
                        pulseForMonth: (month) {
                          final periodInfo = PaycheckService.getPeriodInfo(
                            month,
                            settings.viewPeriodMode,
                            settings.paycheckDay,
                            businessAdjust: settings.paycheckBusinessAdjust,
                            adjustDirection:
                                settings.paycheckBusinessAdjustDirection,
                            includeMonth: settings.paycheckShowMonthInTimeline,
                          );
                          return pulseBuilder(month)(month, periodInfo);
                        },
                        currency: settings.currencySettings.currency,
                        currentMonth: currentPeriodMonth,
                        showClearedForCurrentMonth: showClearedItems,
                        recentlyClearedItemIds:
                            store.recentlyClearedTimelineItemIds,
                        startingBalanceCents: startingBalanceCents,
                        zoomStage: zoomStage,
                        sortOrder: sortOrder,
                        dayFormat: settings.dayFormat,
                        displayMode: effectiveSheetDisplayMode(
                          multiMonthDisplayModeToPulseMode(
                            settings.getMultiMonthDisplayMode(
                              TimelineViewMode.sheet,
                            ),
                          ),
                          zoomStage,
                        ),
                        settings: settings,
                        onMonthTapped: onMonthTapped,
                        showFooters: false,
                        showHeaders: false,
                        viewportHeight: listHeight,
                      );

                      return Column(
                        children: [
                          SizedBox(height: hHeight),
                          tSheet,
                          SizedBox(height: fHeight),
                        ],
                      );
                    },
                  ),
                ),

                // Fixed header at top
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  child: ListenableBuilder(
                    listenable: settings,
                    builder: (context, _) {
                      final hHeight = SheetHeaderRow.getHeaderHeight(
                        zoomStage,
                        settings,
                      );
                      return SizedBox(
                        height: hHeight,
                        child: Transform(
                          transform: Matrix4.identity()
                            ..setTranslationRaw(transX, 0.0, 0.0)
                            ..scaleByVector3(
                              vector.Vector3(scaleX, scaleX, 1.0),
                            ),
                          alignment: Alignment.topLeft,
                          child: OverflowBox(
                            alignment: Alignment.topLeft,
                            minWidth: 0,
                            maxWidth: sheetMonths.length *
                                TimelineSheet.getColumnWidth(settings),
                            minHeight: hHeight,
                            maxHeight: hHeight,
                            child: SheetHeaderRow(
                              months: sheetMonths,
                              zoomStage: zoomStage,
                              settings: settings,
                              onMonthTapped: onMonthTapped,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // Fixed footer at bottom
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: ListenableBuilder(
                    listenable: settings,
                    builder: (context, _) {
                      final fHeight = SheetFooterRow.getFooterHeight(
                        zoomStage,
                        settings,
                      );
                      return SizedBox(
                        height: fHeight,
                        child: Transform(
                          transform: Matrix4.identity()
                            ..setTranslationRaw(transX, 0.0, 0.0)
                            ..scaleByVector3(
                              vector.Vector3(scaleX, scaleX, 1.0),
                            ),
                          alignment: Alignment.topLeft,
                          child: OverflowBox(
                            alignment: Alignment.topLeft,
                            minWidth: 0,
                            maxWidth: sheetMonths.length *
                                TimelineSheet.getColumnWidth(settings),
                            minHeight: fHeight,
                            maxHeight: fHeight,
                            child: SheetFooterRow(
                              months: sheetMonths,
                              items: items,
                              pulseForMonth: (month) {
                                final periodInfo =
                                    PaycheckService.getPeriodInfo(
                                  month,
                                  settings.viewPeriodMode,
                                  settings.paycheckDay,
                                  businessAdjust:
                                      settings.paycheckBusinessAdjust,
                                  adjustDirection:
                                      settings.paycheckBusinessAdjustDirection,
                                  includeMonth:
                                      settings.paycheckShowMonthInTimeline,
                                );
                                return pulseBuilder(month)(month, periodInfo);
                              },
                              currency: settings.currencySettings.currency,
                              currentMonth: currentPeriodMonth,
                              startingBalanceCents: startingBalanceCents,
                              zoomStage: zoomStage,
                              settings: settings,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      );
    },
  );
}

/// Returns the effective display mode based on zoom stage and user preference.
/// Used for sheet view which adjusts display based on zoom level.
PulseDisplayMode effectiveSheetDisplayMode(
  PulseDisplayMode preference,
  GridZoomStage stage,
) {
  if (preference != PulseDisplayMode.automatic) return preference;
  return switch (stage) {
    GridZoomStage.twoMonths => PulseDisplayMode.full,
    GridZoomStage.fourMonths => PulseDisplayMode.acronym,
    GridZoomStage.sixMonths => PulseDisplayMode.icon,
  };
}

/// Converts MonthCardDisplayMode to PulseDisplayMode.
/// Month card only supports full and acronym (no icon option).
PulseDisplayMode monthCardDisplayModeToPulseMode(MonthCardDisplayMode mode) {
  return switch (mode) {
    MonthCardDisplayMode.full => PulseDisplayMode.full,
    MonthCardDisplayMode.acronym => PulseDisplayMode.acronym,
  };
}

/// Converts MultiMonthDisplayMode to PulseDisplayMode.
PulseDisplayMode multiMonthDisplayModeToPulseMode(MultiMonthDisplayMode mode) {
  return switch (mode) {
    MultiMonthDisplayMode.automatic => PulseDisplayMode.automatic,
    MultiMonthDisplayMode.full => PulseDisplayMode.full,
    MultiMonthDisplayMode.acronym => PulseDisplayMode.acronym,
    MultiMonthDisplayMode.icon => PulseDisplayMode.icon,
  };
}
