import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';

/// A compact inline editor that expands below a timeline item row.
///
/// Provides quick-edit for amount and day, plus "Mark Paid" and
/// "Edit Full" actions. Auto-saves on dismiss.
class InlineTimelineEditor extends StatefulWidget {
  const InlineTimelineEditor({
    super.key,
    required this.item,
    required this.pulse,
    required this.isCurrentPeriod,
    required this.onDismiss,
    required this.onEditFull,
    required this.onMarkPaid,
  });

  final TimelineItem item;
  final PulseEntry? pulse;
  final bool isCurrentPeriod;
  final VoidCallback onDismiss;
  final VoidCallback onEditFull;
  final VoidCallback onMarkPaid;

  @override
  State<InlineTimelineEditor> createState() => _InlineTimelineEditorState();
}

class _InlineTimelineEditorState extends State<InlineTimelineEditor>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;

  late final TextEditingController _amountController;
  late final TextEditingController _dayController;
  final _amountFocusNode = FocusNode();
  final _dayFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      duration: AppConstants.animationSlow,
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeOutCubic,
    );
    _animController.forward();

    // Initialize controllers from item data
    final amountStr = formatMinorUnitsForEdit(widget.item.amountMinorUnits);
    _amountController = TextEditingController(text: amountStr);
    _dayController = TextEditingController(
      text: widget.item.dayOfMonth.toString(),
    );
  }

  @override
  void deactivate() {
    // Save changes while context is still valid (before dispose)
    _saveIfChanged();
    super.deactivate();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _dayController.dispose();
    _amountFocusNode.dispose();
    _dayFocusNode.dispose();
    _animController.dispose();
    super.dispose();
  }

  void _saveIfChanged() {
    if (!mounted) return;
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    final newAmount = parseAmountToMinorUnits(
      _amountController.text,
      showCents: settings.showCents,
    );
    final newDay = int.tryParse(_dayController.text);

    if (newAmount == null || newDay == null || newDay < 1 || newDay > 31) {
      return;
    }

    final changed = newAmount != widget.item.amountMinorUnits ||
        newDay != widget.item.dayOfMonth;

    if (changed) {
      store.upsertTimelineItem(
        widget.item.copyWith(amountMinorUnits: newAmount, dayOfMonth: newDay),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final settings = AppSettingsScope.of(context);
    final isCleared = widget.pulse != null;

    return FadeTransition(
      opacity: _fadeAnimation,
      child: AnimatedSize(
        duration: AppConstants.animationSlow,
        curve: Curves.easeOutCubic,
        child: Container(
          margin: const EdgeInsets.only(top: 4, bottom: 8, left: 4, right: 4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(AppConstants.radiusInlineCard),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Amount + Day inline fields
              Row(
                children: [
                  // Amount
                  Expanded(
                    flex: 2,
                    child: UpsertTimelineItemStyle.labeledField(
                      context: context,
                      label: 'Amount',
                      child: TextField(
                        controller: _amountController,
                        focusNode: _amountFocusNode,
                        style: TextStyle(
                          color: colorScheme.onSurface,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          prefixText: '${currencySymbol(settings.currency)} ',
                          prefixStyle: TextStyle(
                            color: colorScheme.onSurfaceVariant,
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.outlineVariant,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.outlineVariant,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.primary,
                              width: 1.5,
                            ),
                          ),
                          filled: true,
                          fillColor: colorScheme.surfaceContainerHighest,
                          isDense: true,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                        ),
                        keyboardType: TextInputType.numberWithOptions(
                          decimal: settings.showCents,
                        ),
                        inputFormatters: [
                          if (settings.showCents)
                            FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d{0,2}'),
                            )
                          else
                            FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(
                            AppConstants.maxAmountLength,
                          ),
                        ],
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Day
                  SizedBox(
                    width: 64,
                    child: UpsertTimelineItemStyle.labeledField(
                      context: context,
                      label: 'Day',
                      child: TextField(
                        controller: _dayController,
                        focusNode: _dayFocusNode,
                        style: TextStyle(
                          color: colorScheme.onSurface,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.outlineVariant,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.outlineVariant,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall,
                            ),
                            borderSide: BorderSide(
                              color: colorScheme.primary,
                              width: 1.5,
                            ),
                          ),
                          filled: true,
                          fillColor: colorScheme.surfaceContainerHighest,
                          isDense: true,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 10,
                          ),
                        ),
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(2),
                        ],
                        textInputAction: TextInputAction.done,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Action buttons
              Row(
                children: [
                  // Mark Paid / Unpaid
                  if (widget.isCurrentPeriod)
                    Expanded(
                      child: _ActionButton(
                        label: isCleared ? 'Undo Paid' : 'Mark Paid',
                        icon: isCleared
                            ? Icons.undo_rounded
                            : Icons.check_circle_outline,
                        color: isCleared
                            ? colorScheme.onSurfaceVariant
                            : colorScheme.primary,
                        onTap: widget.onMarkPaid,
                      ),
                    ),
                  if (widget.isCurrentPeriod) const SizedBox(width: 8),
                  // Edit Full
                  Expanded(
                    child: _ActionButton(
                      label: 'Edit Full',
                      icon: Icons.open_in_new_rounded,
                      color: colorScheme.onSurfaceVariant,
                      onTap: widget.onEditFull,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(
              color: colorScheme.outlineVariant.withValues(alpha: 0.5),
            ),
            borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: color,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Parse a minor units amount string for editing (convert from cents to display format).
String formatMinorUnitsForEdit(int minorUnits) {
  if (minorUnits == 0) return '';
  final abs = minorUnits.abs();
  final dollars = abs ~/ 100;
  final cents = abs % 100;
  if (cents == 0) return dollars.toString();
  return '$dollars.${cents.toString().padLeft(2, '0')}';
}

/// Parse user-entered amount string to minor units (cents).
int? parseAmountToMinorUnits(String text, {required bool showCents}) {
  if (text.trim().isEmpty) return null;
  final value = double.tryParse(text.trim());
  if (value == null || value < 0) return null;
  if (showCents) {
    return (value * 100).round();
  }
  return value.toInt() * 100;
}
