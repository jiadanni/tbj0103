import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/widgets/compact_chip.dart';

class TimelineFilterSheet extends StatefulWidget {
  final AppSettingsStore settings;

  const TimelineFilterSheet({super.key, required this.settings});

  @override
  State<TimelineFilterSheet> createState() => _TimelineFilterSheetState();
}

class _TimelineFilterSheetState extends State<TimelineFilterSheet> {
  AppSettingsStore get settings => widget.settings;

  int get activeFilterCount {
    int count = 0;
    // Check if sort order is default (chronological usually default? or maybe check if changed)
    // Actually for sort, we might not count it as a "filter" to clear, but let's see Pulse logic.
    // Pulse counts non-default values.
    // Assuming chronological is default.
    if (settings.timelineSortOrder != TimelineSortOrder.chronological) count++;

    // Check filters
    if (!settings.timelineShowClearedItems) {
      count++; // Hidden cleared items is a change from "Show All"
    }
    if (!settings.timelineShowIncome) count++;
    if (!settings.timelineShowExpense) count++;
    if (settings.timelineShowSkippedItems) count++;
    if (settings.timelineSplitClearedAndPending) count++; // [NEW]
    if (settings.timelineShowSubcategories) count++; // [NEW]

    return count;
  }

  void _clearAllFilters() {
    setState(() {
      settings.timelineSortOrder = TimelineSortOrder.chronological;
      settings.timelineShowClearedItems = true;
      settings.timelineShowIncome = true;
      settings.timelineShowExpense = true;
      settings.timelineShowSkippedItems = false;
      settings.timelineSplitClearedAndPending = false; // [NEW]
      settings.timelineShowSubcategories = false; // [NEW]
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: AnimatedSize(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              _buildHeader(context, theme, colorScheme),
              const SizedBox(height: 16),

              // Sort Section
              _buildSectionRow(
                context,
                title: l10n?.sortByDate ?? 'Sort by Date',
                theme: theme,
              ),
              const SizedBox(height: 10),
              _buildSortChips(context, theme, colorScheme),

              const SizedBox(height: 18),

              // Filter Section
              _buildSectionRow(context, title: 'Show', theme: theme),
              const SizedBox(height: 10),
              _buildFilterChips(context, theme, colorScheme),

              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Filter & Sort',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        if (activeFilterCount > 0)
          TextButton.icon(
            onPressed: _clearAllFilters,
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              visualDensity: VisualDensity.compact,
            ),
            icon: Icon(Icons.clear_all, size: 18, color: colorScheme.error),
            label: Text(
              'Reset',
              style: theme.textTheme.labelMedium?.copyWith(
                color: colorScheme.error,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildSectionRow(
    BuildContext context, {
    required String title,
    required ThemeData theme,
  }) {
    return Text(
      title,
      style: theme.textTheme.labelMedium?.copyWith(
        fontWeight: FontWeight.w600,
        color: theme.colorScheme.onSurfaceVariant,
        letterSpacing: 0.5,
      ),
    );
  }

  Widget _buildSortChips(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    final sortOptions = [
      (
        TimelineSortOrder.chronological,
        'Oldest First',
        PhosphorIcons.sortAscending(),
      ),
      (
        TimelineSortOrder.reverseChronological,
        'Newest First',
        PhosphorIcons.sortDescending(),
      ),
      (TimelineSortOrder.nameAscending, 'Name A-Z', PhosphorIcons.textAa()),
      (
        TimelineSortOrder.nameDescending,
        'Name Z-A',
        PhosphorIcons.textAa(),
      ), // Same icon, just reversed order
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: sortOptions.map((option) {
        final (order, label, icon) = option;
        final isSelected = settings.timelineSortOrder == order;

        return CompactChip(
          label: label,
          icon: icon,
          isSelected: isSelected,
          usePrimaryColor: true, // Sort is primary
          onTap: () {
            setState(() {
              settings.timelineSortOrder = order;
            });
          },
        );
      }).toList(),
    );
  }

  Widget _buildFilterChips(
    BuildContext context,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        CompactChip(
          label: 'Cleared Items',
          icon: PhosphorIcons.checkCircle(),
          isSelected: settings.timelineShowClearedItems,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineShowClearedItems =
                  !settings.timelineShowClearedItems;
            });
          },
        ),
        CompactChip(
          label: 'Income',
          icon: PhosphorIcons.arrowDownLeft(),
          isSelected: settings.timelineShowIncome,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineShowIncome = !settings.timelineShowIncome;
            });
          },
        ),
        CompactChip(
          label: 'Expenses',
          icon: PhosphorIcons.arrowUpRight(),
          isSelected: settings.timelineShowExpense,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineShowExpense = !settings.timelineShowExpense;
            });
          },
        ),
        CompactChip(
          label: 'Skipped Items',
          icon: PhosphorIcons.prohibit(),
          isSelected: settings.timelineShowSkippedItems,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineShowSkippedItems =
                  !settings.timelineShowSkippedItems;
            });
          },
        ),
        CompactChip(
          label: 'Split Cleared',
          icon: PhosphorIcons.listDashes(),
          isSelected: settings.timelineSplitClearedAndPending,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineSplitClearedAndPending =
                  !settings.timelineSplitClearedAndPending;
            });
          },
        ),
        CompactChip(
          label: 'Subcategories',
          icon: PhosphorIcons.treeStructure(),
          isSelected: settings.timelineShowSubcategories,
          usePrimaryColor: false,
          onTap: () {
            setState(() {
              settings.timelineShowSubcategories =
                  !settings.timelineShowSubcategories;
            });
          },
        ),
      ],
    );
  }
}
