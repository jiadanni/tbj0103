import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_screen_controller.dart';
import 'package:expense_stalker_mobile/src/widgets/account_selector.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/quick_spending_helpers.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_transaction_sheet.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

class TimelineAppBar extends StatelessWidget {
  final TimelineViewMode viewMode;
  final DateTime earliestMonth;
  final DateTime selectedMonth;
  final bool isSelectedCurrentPeriod;
  final TimelineScreenController controller;
  final Function(TimelineViewMode) onViewModeChanged;
  final VoidCallback onFilterPressed;
  final VoidCallback? onShareSnapshot;
  final bool hasActiveFilters;

  const TimelineAppBar({
    super.key,
    required this.viewMode,
    required this.earliestMonth,
    required this.selectedMonth,
    required this.isSelectedCurrentPeriod,
    required this.controller,
    required this.onViewModeChanged,
    required this.onFilterPressed,
    this.onShareSnapshot,
    required this.hasActiveFilters,
  });

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final settings = AppSettingsScope.of(context);
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingMedium,
        AppConstants.paddingNormal,
        AppConstants.paddingMedium,
        0,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Expanded(
            flex: 1,
            child: Align(
              alignment: Alignment.centerLeft,
              child: AccountSelector(),
            ),
          ),
          Expanded(
            child: Center(
              child: SegmentedButton<TimelineViewMode>(
                showSelectedIcon: false,
                style: SegmentedButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  // Use theme-aware colors for better integration
                  backgroundColor: Colors.transparent,
                  foregroundColor: colorScheme.onSurfaceVariant,
                  selectedBackgroundColor: colorScheme.primaryContainer,
                  selectedForegroundColor: colorScheme.onPrimaryContainer,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusMedium,
                    ),
                  ),
                ),
                segments: [
                  ButtonSegment<TimelineViewMode>(
                    value: TimelineViewMode.month,
                    icon: PhosphorIcon(PhosphorIcons.calendar(), size: 18),
                  ),
                  ButtonSegment<TimelineViewMode>(
                    value: TimelineViewMode.grid,
                    icon: PhosphorIcon(PhosphorIcons.squaresFour(), size: 18),
                  ),
                  ButtonSegment<TimelineViewMode>(
                    value: TimelineViewMode.sheet,
                    icon: PhosphorIcon(PhosphorIcons.table(), size: 18),
                  ),
                ],
                selected: {viewMode},
                onSelectionChanged: (Set<TimelineViewMode> selection) {
                  if (selection.isNotEmpty) {
                    onViewModeChanged(selection.first);
                  }
                },
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Filter Button
                  IconButton(
                    tooltip: 'Filter & Sort',
                    splashRadius: 24,
                    visualDensity: VisualDensity.compact,
                    onPressed: onFilterPressed,
                    icon: Stack(
                      alignment: Alignment.topRight,
                      children: [
                        PhosphorIcon(PhosphorIcons.funnel()),
                        // Show indicator if filters are active (not default)
                        if (hasActiveFilters)
                          Container(
                            margin: const EdgeInsets.only(top: 2, right: 2),
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: colorScheme.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                  ),
                  // Consolidated menu with all timeline actions
                  PopupMenuButton<void>(
                    tooltip:
                        '${Terminology.of(context).timelineTabLabel} Options',
                    splashRadius: 24,
                    icon: PhosphorIcon(PhosphorIcons.dotsThreeVertical()),
                    itemBuilder: (context) {
                      return [
                        // Quick Transaction (Log)
                        PopupMenuItem<void>(
                          onTap: () async {
                            final result =
                                await showModalBottomSheet<PulseEntry>(
                              context: context,
                              isScrollControlled: true,
                              backgroundColor: Colors.transparent,
                              builder: (context) =>
                                  const QuickTransactionSheet(),
                            );

                            if (result != null && context.mounted) {
                              store.upsertPulse(result);

                              // Only update balance if transaction date is today or in the past
                              // Future-dated transactions remain pending and don't affect current balance
                              final now = DateTime.now();
                              final today = DateTime(
                                now.year,
                                now.month,
                                now.day,
                              );
                              final txDate = DateTime(
                                result.date.year,
                                result.date.month,
                                result.date.day,
                              );
                              final isFutureTransaction = txDate.isAfter(today);

                              if (!isFutureTransaction &&
                                  !settings.balanceUpdatesDisabled) {
                                settings.currentBalanceCents +=
                                    result.amountMinorUnits;
                              }

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    isFutureTransaction
                                        ? 'Scheduled ${result.label} for ${result.date.month}/${result.date.day}'
                                        : AppLocalizations.of(
                                            context,
                                          )!
                                            .recordedLabel(result.label),
                                  ),
                                ),
                              );
                            }
                          },
                          child: Row(
                            children: [
                              PhosphorIcon(
                                PhosphorIcons.plusCircle(),
                                color: colorScheme.primary,
                                size: 20,
                              ),
                              const SizedBox(width: 12),
                              Text(Terminology.of(context).logActionLabel),
                            ],
                          ),
                        ),

                        // Share Snapshot (Only for Sheet View currently)
                        if (viewMode == TimelineViewMode.sheet)
                          PopupMenuItem<void>(
                            onTap: onShareSnapshot,
                            child: Row(
                              children: [
                                PhosphorIcon(
                                  PhosphorIcons.camera(),
                                  size: 20,
                                ),
                                const SizedBox(width: 12),
                                const Text('Share Snapshot'),
                              ],
                            ),
                          ),

                        const PopupMenuDivider(),
                        // Quick Spending
                        PopupMenuItem<void>(
                          onTap: () => showQuickSpendingFlow(context, store),
                          child: Row(
                            children: [
                              PhosphorIcon(
                                PhosphorIcons.wallet(),
                                color: colorScheme.primary,
                                size: 20,
                              ),
                              const SizedBox(width: 12),
                              Text(Terminology.of(context).quickSpendLabel),
                            ],
                          ),
                        ),
                      ];
                    },
                  ),
                  // Settings button
                  IconButton(
                    tooltip: AppLocalizations.of(context)!.optionsTitle,
                    splashRadius: 24,
                    visualDensity: VisualDensity.compact,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const OptionsScreen(),
                          fullscreenDialog:
                              MediaQuery.sizeOf(context).width < 1024,
                        ),
                      );
                    },
                    icon: PhosphorIcon(PhosphorIcons.gear()),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
