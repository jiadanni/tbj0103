import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/features/timeline/timeline_helpers.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_screen_controller.dart';
import 'package:expense_stalker_mobile/src/features/timeline/widgets/timeline_app_bar.dart';
import 'package:expense_stalker_mobile/src/features/timeline/widgets/timeline_body.dart';
// import 'package:expense_stalker_mobile/src/features/timeline/timeline_filter_state.dart'; // Removed
import 'package:expense_stalker_mobile/src/features/timeline/widgets/timeline_filter_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/screenshot_helper.dart';

class TimelineScreen extends StatefulWidget {
  const TimelineScreen({super.key});

  @override
  State<TimelineScreen> createState() => _TimelineScreenState();
}

class _TimelineScreenState extends State<TimelineScreen>
    with AutomaticKeepAliveClientMixin, TickerProviderStateMixin {
  // View mode is determined by widget parameter or persisted in AppSettingsStore
  bool _hasAdjustedForPaycheckMode = false;
  int _monthWindowSize = TimelineScreenController.monthWindowSize;
  bool _didScheduleInitialMonthSync = false;

  late TimelineScreenController _controller;

  // Cached earliest month to avoid redundant computation
  DateTime? _cachedEarliestMonth;
  int _cachedTimelineItemsHash = 0;
  int _cachedPulsesHash = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();

    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);

    // Filter state is now managed directly via settings store.

    // Filter state is now managed directly via settings store.

    // Initial compute using potentially filtered items if we wanted to be 100% consistent,
    // but here we can just use active items as a baseline or filter them.
    // Let's filter them to be consistent with build method.
    final items = store.activeTimelineItems;
    final filteredItems = _filterItems(items, settings);
    final earliestMonth = _computeEarliestMonthCached(filteredItems);
    final effectiveSelectedMonth = store.selectedMonth.isBefore(earliestMonth)
        ? earliestMonth
        : store.selectedMonth;

    final initialOrigin = monthOnly(
      month_math.addMonths(
        earliestMonth,
        TimelineScreenController.monthOriginPage,
      ),
    );

    final initialPage = TimelineScreenController.monthOriginPage +
        monthsBetween(initialOrigin, effectiveSelectedMonth);

    _controller = TimelineScreenController(
      monthOrigin: initialOrigin,
      pageController: PageController(initialPage: initialPage),
      sheetTransformController: TransformationController(),
      gridTransformController: TransformationController(),
      vsync: this,
    );

    // Schedule check for paycheck mode after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _checkAndAdjustForPaycheckMode();
    });
  }

  void _checkAndAdjustForPaycheckMode() {
    if (_hasAdjustedForPaycheckMode || !mounted) return;

    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    // If we're in paycheck mode and it's configured, ensure we're showing the current period
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      final now = DateTime.now();
      final correctMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        now,
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

      // Only update if different from current selected month
      if (store.selectedMonth.year != correctMonth.year ||
          store.selectedMonth.month != correctMonth.month) {
        store.setSelectedMonth(correctMonth);
      }
    }

    _hasAdjustedForPaycheckMode = true;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onFilterPressed() {
    final settings = AppSettingsScope.read(context);
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => TimelineFilterSheet(settings: settings),
      backgroundColor: Theme.of(context).colorScheme.surface,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
    );
  }

  List<TimelineItem> _filterItems(
    List<TimelineItem> items,
    AppSettingsStore settings,
  ) {
    if (settings.timelineShowIncome && settings.timelineShowExpense) {
      return items;
    }

    return items.where((item) {
      if (item.type == PulseType.spendingEnvelope) return true;

      final isExpense = item.amountMinorUnits < 0;
      final isIncome = item.amountMinorUnits >=
          0; // Note: Assuming 0 is income or handle as needed, usually income.

      if (isIncome && !settings.timelineShowIncome) return false;
      if (isExpense && !settings.timelineShowExpense) return false;

      return true;
    }).toList();
  }

  bool _hasActiveFilters(AppSettingsStore settings) {
    return !settings.timelineShowIncome ||
        !settings.timelineShowExpense ||
        !settings.timelineShowClearedItems ||
        settings.timelineShowSkippedItems;
  }

  void _setViewMode(AppSettingsStore settings, TimelineViewMode mode) {
    if (settings.timelineViewMode == mode) return;
    settings.timelineViewMode = mode;
    if (mode == TimelineViewMode.grid) {
      _controller.didInitGridTransform = false;
    } else if (mode == TimelineViewMode.sheet) {
      _controller.didInitSheetTransform = false;
    }
  }

  Future<void> _onShareSnapshot(
    BuildContext context,
    ExpenseStore store,
    AppSettingsStore settings,
    List<TimelineItem> items,
    DateTime earliestMonth,
    DateTime selectedMonth,
  ) async {
    final messenger = ScaffoldMessenger.of(context);
    // Show loading indicator or feedback?
    // Share sheet usually takes a moment.

    final monthsBefore = monthsBetween(earliestMonth, selectedMonth);
    // Capture a generous range, e.g., 36 months forward (matches sheet view logic)
    final sheetMonths = monthRange(
      selectedMonth,
      before: monthsBefore,
      after: 36,
    );

    final now = DateTime.now();
    final DateTime currentPeriodMonth;
    if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
        settings.isPaycheckModeConfigured) {
      currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        now,
        settings.paycheckDay!,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
    } else {
      currentPeriodMonth = monthOnly(now);
    }

    final startBalance =
        settings.timelineUseZeroBaseline ? 0 : settings.currentBalanceCents;

    // Construct the full-content widget
    // We wrap in a container with background color to ensure it looks good
    final widget = Container(
      color: Theme.of(context).colorScheme.surface,
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              'Timeline Snapshot',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
          Flexible(
            child: TimelineSheet(
              months: sheetMonths,
              items: items,
              pulseForMonth: (month) {
                final periodInfo = PaycheckService.getPeriodInfo(
                  month,
                  settings.viewPeriodMode,
                  settings.paycheckDay,
                  businessAdjust: settings.paycheckBusinessAdjust,
                  adjustDirection: settings.paycheckBusinessAdjustDirection,
                  includeMonth: settings.paycheckShowMonthInTimeline,
                );
                return store.pulseForMonth(month, periodInfo: periodInfo);
              },
              currency: settings.currencySettings.currency,
              currentMonth: currentPeriodMonth,
              showClearedForCurrentMonth: settings.timelineShowClearedItems,
              recentlyClearedItemIds: store.recentlyClearedTimelineItemIds,
              startingBalanceCents: startBalance,
              zoomStage: GridZoomStage.twoMonths, // High detail for snapshot
              sortOrder: settings.timelineSortOrder,
              dayFormat: settings.dayFormat,
              displayMode:
                  settings.getTimelineShowPulseOrigin(TimelineViewMode.sheet)
                      ? PulseDisplayMode.full
                      : PulseDisplayMode.automatic,
              settings: settings,
              showFooters: true,
              showHeaders: true,
              viewportHeight: null, // Natural height for full capture
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text(
              'Generated by Expense Stalker',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.outline,
                  ),
            ),
          ),
        ],
      ),
    );

    try {
      await ScreenshotHelper.captureAndShareWidget(
        context,
        widget: widget,
        imageName: 'timeline_snapshot_${DateTime.now().millisecondsSinceEpoch}',
        subject: 'Expense Stalker Timeline Snapshot',
      );
    } catch (e) {
      if (mounted) {
        messenger.showSnackBar(
          SnackBar(content: Text('Failed to share snapshot: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.of(
      context,
    ); // Use .of() to listen for changes
    // Read view mode from settings (no longer passed via widget parameter)
    final viewMode = settings.timelineViewMode;

    // Use selective listening on selectedMonth to avoid full rebuild on every store change
    return ValueListenableBuilder<DateTime>(
      valueListenable: store.selectedMonthNotifier,
      builder: (context, __, ___) {
        return ValueListenableBuilder<List<TimelineItem>>(
          valueListenable: store.activeTimelineItemsNotifier,
          builder: (context, __, ___) {
            final filteredItems = _filterItems(
              store.activeTimelineItems,
              settings,
            );

            // Recompute logic depending on active items and month
            // Use filteredItems so the timeline starts at the first VISIBLE item
            final earliestMonth = _computeEarliestMonthCached(filteredItems);

            final effectiveSelectedMonth =
                store.selectedMonth.isBefore(earliestMonth)
                    ? earliestMonth
                    : store.selectedMonth;
            final latestMonth = _computeLatestMonth(
              earliestMonth,
              effectiveSelectedMonth,
            );
            final monthWindowSize =
                monthsBetween(earliestMonth, latestMonth) + 1;
            _monthWindowSize = monthWindowSize;
            final nextOrigin = monthOnly(
              month_math.addMonths(
                earliestMonth,
                TimelineScreenController.monthOriginPage,
              ),
            );
            if (_controller.monthOrigin != nextOrigin) {
              _controller.monthOrigin = nextOrigin;
            }
            _ensureSelectedMonthWithinRange(store, earliestMonth);
            _syncMonthPageIfNeeded(effectiveSelectedMonth, monthWindowSize);

            final now = DateTime.now();
            final selectedMonth = effectiveSelectedMonth;
            final selectedMonthOnly = monthOnly(selectedMonth);

            // Determine current period reference month for paycheck mode
            final DateTime currentPeriodMonth;
            if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
                settings.isPaycheckModeConfigured) {
              currentPeriodMonth =
                  PaycheckService.getCurrentPaycheckPeriodMonth(
                now,
                settings.paycheckDay!,
                businessAdjust: settings.paycheckBusinessAdjust,
                adjustDirection: settings.paycheckBusinessAdjustDirection,
              );
            } else {
              currentPeriodMonth = monthOnly(now);
            }

            final isSelectedCurrentPeriod =
                selectedMonthOnly.year == currentPeriodMonth.year &&
                    selectedMonthOnly.month == currentPeriodMonth.month;

            return ValueListenableBuilder<List<PulseEntry>>(
              valueListenable: store.pulseNotifier,
              builder: (context, __, ___) {
                return SafeArea(
                  top: true,
                  bottom: false,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TimelineAppBar(
                        viewMode: viewMode,
                        earliestMonth: earliestMonth,
                        selectedMonth: selectedMonth,
                        isSelectedCurrentPeriod: isSelectedCurrentPeriod,
                        controller: _controller,
                        onViewModeChanged: (mode) =>
                            _setViewMode(settings, mode),
                        onFilterPressed: _onFilterPressed,
                        onShareSnapshot: () => _onShareSnapshot(
                          context,
                          store,
                          settings,
                          filteredItems,
                          earliestMonth,
                          selectedMonth,
                        ),
                        hasActiveFilters: _hasActiveFilters(settings),
                      ),
                      // Wrap body with SafeArea only for bottom to prevent issues
                      // But the body itself handles scrolling, so it might need its own padding
                      TimelineBody(
                        viewMode: viewMode,
                        earliestMonth: earliestMonth,
                        selectedMonth: selectedMonth,
                        controller: _controller,
                        onViewModeChanged: (mode) =>
                            _setViewMode(settings, mode),
                        onJumpToSelectedMonth: () =>
                            _jumpToSelectedMonth(store),
                        items: filteredItems,
                        sortOrder: settings.timelineSortOrder,
                        showCleared: settings.timelineShowClearedItems,
                        settings: settings,
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  /// Cached version of _computeEarliestMonth to avoid redundant iteration.
  /// Invalidates cache when timelineItems or pulses content changes.
  ///
  /// IMPORTANT: This now considers BOTH timeline items AND pulses to determine
  /// the earliest month. This ensures imported bank transactions (orphaned pulses)
  /// are visible in the timeline even if there are no scheduled items in those months.
  DateTime _computeEarliestMonthCached(List<TimelineItem> items) {
    final store = ExpenseStoreScope.read(context);
    final pulses = store.pulses;

    // Invalidate cache if items or pulses changed
    final itemsHash = Object.hashAll(items);
    final pulsesHash = Object.hashAll(pulses.map((p) => p.id));
    if (itemsHash != _cachedTimelineItemsHash ||
        pulsesHash != _cachedPulsesHash) {
      _cachedTimelineItemsHash = itemsHash;
      _cachedPulsesHash = pulsesHash;
      _cachedEarliestMonth = null;
    }

    // Return cached value if available
    if (_cachedEarliestMonth != null) {
      return _cachedEarliestMonth!;
    }

    // Compute and cache
    final nowMonth = monthOnly(DateTime.now());

    // Start with current month as default
    var earliest = nowMonth;

    // Check timeline items
    for (final item in items) {
      final start = monthOnly(item.startDate);
      if (start.isBefore(earliest)) earliest = start;
    }

    // Also check pulses (especially important for imported bank transactions)
    for (final pulse in pulses) {
      final pulseMonth = monthOnly(pulse.date);
      if (pulseMonth.isBefore(earliest)) earliest = pulseMonth;
    }

    _cachedEarliestMonth = earliest;
    return _cachedEarliestMonth!;
  }

  void _jumpToSelectedMonth(ExpenseStore store) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _syncMonthPageIfNeeded(store.selectedMonth, _monthWindowSize);
    });
  }

  DateTime _computeLatestMonth(DateTime earliestMonth, DateTime selectedMonth) {
    final nowMonth = monthOnly(DateTime.now());
    final base = _maxMonth(_maxMonth(nowMonth, selectedMonth), earliestMonth);
    return monthOnly(
      month_math.addMonths(base, TimelineScreenController.monthOriginPage),
    );
  }

  DateTime _maxMonth(DateTime a, DateTime b) {
    final aMonth = monthOnly(a);
    final bMonth = monthOnly(b);
    return aMonth.isAfter(bMonth) ? aMonth : bMonth;
  }

  void _ensureSelectedMonthWithinRange(
    ExpenseStore store,
    DateTime earliestMonth,
  ) {
    if (!store.selectedMonth.isBefore(earliestMonth)) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      store.setSelectedMonth(earliestMonth);
    });
  }

  void _syncMonthPageIfNeeded(DateTime selectedMonth, int monthWindowSize) {
    if (_controller.pageController.hasClients) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
      });
      return;
    }
    if (_didScheduleInitialMonthSync) return;
    _didScheduleInitialMonthSync = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _didScheduleInitialMonthSync = false;
      if (!mounted) return;
      _controller.syncMonthPageIfNeeded(selectedMonth, monthWindowSize);
    });
  }
}
