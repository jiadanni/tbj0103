import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';

/// Maximum and minimum balance bounds to prevent overflow.
/// Uses conservative bounds that work safely with 64-bit integers.
const int _maxBalance = maxMinorUnits;
const int _minBalance = -maxMinorUnits;

/// Safely adds two balance values with overflow protection.
/// Clamps the result to prevent integer overflow.
int _safeAddBalance(int a, int b) {
  // Check for overflow before adding
  if (b > 0 && a > _maxBalance - b) return _maxBalance;
  if (b < 0 && a < _minBalance - b) return _minBalance;
  return a + b;
}

/// Calculates the starting balance for a future month/period.
///
/// For future periods, the starting balance is the previous period's end balance.
/// This is calculated by starting with the current period's balance and adding all
/// planned items from the current period through the period before the target.
///
/// Parameters:
/// - [month]: The future month/period reference to predict (returns null for past or current)
/// - [currentBalanceCents]: The user's current balance for the current period
/// - [useZeroBaseline]: If true, show $0 as the starting balance instead of the
///   calculated previous period's end balance (useful for showing savings potential)
/// - [plannedTotalForMonth]: Sum of planned items for a given month/period
/// - [currentPeriodMonth]: The reference month for the current period (handles paycheck mode)
///
/// Returns null if the month is in the past or is the current period.
int? startBalanceCentsForMonth({
  required DateTime month,
  required int currentBalanceCents,
  required bool useZeroBaseline,
  required int Function(DateTime month) plannedTotalForMonth,
  DateTime? currentPeriodMonth,
}) {
  // Use provided current period month, or fall back to calendar month
  final now = currentPeriodMonth != null
      ? monthOnly(currentPeriodMonth)
      : monthOnly(DateTime.now());
  final m = monthOnly(month);

  // Don't calculate for past months or the current month/period
  if (m.isBefore(now) || m.isAtSameMomentAs(now)) return null;

  // If useZeroBaseline is true, show 0 instead of the previous period's end balance
  if (useZeroBaseline) return 0;

  // Calculate the previous period's end balance
  // Start with the current period's balance
  var previousPeriodEndBalance = currentBalanceCents;
  var cursor = now;

  // Sum all planned items from current period through the period before the target
  // Use safe addition to prevent overflow on multi-year projections
  while (cursor.isBefore(m)) {
    previousPeriodEndBalance = _safeAddBalance(
      previousPeriodEndBalance,
      plannedTotalForMonth(cursor),
    );
    cursor = monthOnly(month_math.addMonths(cursor, 1));
  }

  return previousPeriodEndBalance;
}

/// Shows balance edit dialog for the current period.
///
/// For the current period, directly opens the edit balance dialog.
/// The zero baseline toggle is only available for future months via header tap.
Future<void> showBalanceActions(
  BuildContext context,
  AppSettingsStore settings,
) async {
  await showEditBalanceDialog(context, settings);
}

Future<void> showEditBalanceDialog(
  BuildContext context,
  AppSettingsStore settings,
) async {
  final result = await showDialog<EditBalanceResult>(
    context: context,
    builder: (context) => EditBalanceDialog(
      initialCents: settings.currentBalanceCents,
      currency: settings.currencySettings.currency,
      initialUpdatesDisabled: settings.balanceUpdatesDisabled,
    ),
  );
  if (!context.mounted) return;
  if (result != null) {
    if (settings.currentBalanceCents != result.cents) {
      settings.currentBalanceCents = result.cents;
    }
    if (settings.balanceUpdatesDisabled != result.disabled) {
      settings.balanceUpdatesDisabled = result.disabled;
    }
  }
}

class EditBalanceResult {
  final int cents;
  final bool disabled;
  const EditBalanceResult(this.cents, this.disabled);
}

class EditBalanceDialog extends StatefulWidget {
  const EditBalanceDialog({
    super.key,
    required this.initialCents,
    required this.currency,
    required this.initialUpdatesDisabled,
  });

  final int initialCents;
  final AppCurrency currency;
  final bool initialUpdatesDisabled;

  @override
  State<EditBalanceDialog> createState() => _EditBalanceDialogState();
}

class _EditBalanceDialogState extends State<EditBalanceDialog> {
  late final TextEditingController _controller;
  late bool _updatesDisabled;

  @override
  void initState() {
    super.initState();
    // Format initial value based on currency decimals
    // We want the raw number for editing (e.g. "12.50" or "1000")
    // formatMoney returns symbol + formatted number (e.g. "$12.50")
    // For editing, we just want the number part, so we do a quick calculation here
    // leveraging the currency info.
    final info = getCurrencyInfo(widget.currency);
    final amount = widget.initialCents / info.subunitRatio;
    _controller = TextEditingController(
      text: amount.toStringAsFixed(info.decimalDigits),
    );
    _updatesDisabled = widget.initialUpdatesDisabled;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    // tryParseMoney handles parsing number strings (with or without symbols)
    // using the correct subunit ratio for the currency
    final cents = tryParseMoney(_controller.text, widget.currency);
    if (cents != null) {
      Navigator.pop(context, EditBalanceResult(cents, _updatesDisabled));
    } else {
      Navigator.pop(context, null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(AppLocalizations.of(context)!.currentBalance),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _controller,
            keyboardType: const TextInputType.numberWithOptions(
              signed: true,
              decimal: true,
            ),
            autofocus: true,
            decoration: UpsertTimelineItemStyle.compactInput(
              context,
              AppLocalizations.of(context)!.currentBalance,
              prefixText: getCurrencyInfo(widget.currency).symbolPosition ==
                      SymbolPosition.before
                  ? getCurrencyInfo(widget.currency).symbol
                  : null,
              suffixText: getCurrencyInfo(widget.currency).symbolPosition ==
                      SymbolPosition.after
                  ? getCurrencyInfo(widget.currency).symbol
                  : null,
              helperText: 'Update the starting balance for calculation.',
            ),
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 16),
          SwitchListTile(
            value: !_updatesDisabled,
            onChanged: (value) => setState(() => _updatesDisabled = !value),
            title: const Text('Auto-update balance'),
            subtitle: const Text('Allow archiving to change account balance'),
            contentPadding: EdgeInsets.zero,
            dense: true,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, null),
          child: Text(AppLocalizations.of(context)!.cancel),
        ),
        FilledButton(
          onPressed: _submit,
          child: Text(AppLocalizations.of(context)!.save),
        ),
      ],
    );
  }
}
