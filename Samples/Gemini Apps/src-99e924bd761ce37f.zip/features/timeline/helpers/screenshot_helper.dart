import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Helper class to capture a widget as an image, saving it to a file,
/// and sharing it.
class ScreenshotHelper {
  /// Captures a widget that is not currently in the widget tree (or is, but we want a full render)
  /// by inserting it into the overlay, waiting for it to render, capturing the image,
  /// and then removing it.
  static Future<void> captureAndShareWidget(
    BuildContext context, {
    required Widget widget,
    required String imageName,
    String? subject,
    String? text,
  }) async {
    // FIX(Issue #36): Use maybeOf to safely handle missing overlay ancestor.
    final overlayState = Overlay.maybeOf(context);
    if (overlayState == null) {
      debugPrint('ScreenshotHelper: No Overlay ancestor found');
      return;
    }
    final GlobalKey boundaryKey = GlobalKey();

    // We create an entry that positions the widget off-screen but allows it to layout fully
    // We wrap it in a SingleChildScrollView with physics NeverScrollableScrollPhysics inside a ConstrainedBox
    // to allow it to expand as much as needed vertically, but constrain width to the screen width.
    // Actually, for scrolling content, we want it to layout with unbounded height.
    // Capture pixelRatio before async operations
    final logicalWidth = MediaQuery.of(context).size.width;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    final entry = OverlayEntry(
      builder: (context) {
        return Positioned(
          left: logicalWidth, // Off-screen to the right
          top: 0,
          child: Material(
            type: MaterialType.transparency,
            child: RepaintBoundary(
              key: boundaryKey,
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: logicalWidth,
                  // Height is unbounded, allowing the widget to size itself fully
                ),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Theme(
                    data: Theme.of(context),
                    child: MediaQuery(
                      data: MediaQuery.of(context), // Inherit media query
                      child: widget,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );

    overlayState.insert(entry);

    try {
      // Wait for layout and paint
      // A small delay is usually necessary for the frame to be scheduled and painted
      await Future.delayed(const Duration(milliseconds: 100));

      final RenderRepaintBoundary? boundary = boundaryKey.currentContext
          ?.findRenderObject() as RenderRepaintBoundary?;

      if (boundary == null) {
        throw Exception('Measurement failed: Boundary not found');
      }

      // Ensure paint is settled
      if (boundary.debugNeedsPaint) {
        await Future.delayed(const Duration(milliseconds: 50));
      }

      // Convert to image
      // pixelRatio ensures high quality capture matching device density
      final ui.Image image = await boundary.toImage(pixelRatio: pixelRatio);
      final ByteData? byteData = await image.toByteData(
        format: ui.ImageByteFormat.png,
      );

      if (byteData == null) throw Exception('Failed to capture image data');

      final Uint8List pngBytes = byteData.buffer.asUint8List();

      // Save to temporary file
      final directory = await getTemporaryDirectory();
      final imagePath = '${directory.path}/$imageName.png';
      final imageFile = File(imagePath);
      await imageFile.writeAsBytes(pngBytes);

      // Share using share_plus
      final xFile = XFile(imagePath);
      // ignore: deprecated_member_use
      await Share.shareXFiles([xFile], text: text, subject: subject);
    } catch (e) {
      debugPrint('Screenshot Error: $e');
      // Rethrow so the caller knows it failed
      rethrow;
    } finally {
      // Always remove the overlay entry
      entry.remove();
    }
  }
}
