import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/timeline_actions.dart';

/// Calculates projected money pot balances across a list of months.
///
/// For past and current months, it uses the current balance from [initialPots].
/// For future months, it projects forward by deducting planned payments for linked debt items.
///
/// The projection shows what the pot balance will be AT THE START of each period,
/// after accounting for all payments in previous periods.
List<List<MoneyPot>> projectMoneyPotBalances({
  required List<MoneyPot> initialPots,
  required List<DateTime> months,
  required List<TimelineItem> items,
  required List<PulseEntry> Function(DateTime) pulseForMonth,
  required AppSettingsStore settings,
  required DateTime currentMonth,
}) {
  final projections = <List<MoneyPot>>[];
  final normalizedCurrent = monthOnly(currentMonth);

  var runningPots = initialPots;

  for (var i = 0; i < months.length; i++) {
    final month = months[i];
    final normalizedMonth = monthOnly(month);

    if (normalizedMonth.isBefore(normalizedCurrent)) {
      // Past months: show current balance (historical state not tracked)
      projections.add(initialPots);
      continue;
    }

    if (normalizedMonth.isAtSameMomentAs(normalizedCurrent)) {
      // Current month: show current balance (already reflects any paid items)
      projections.add(initialPots);

      // BUT, we need to apply pending payments from this month to the running total
      // so that next month starts with the correct projected balance.
      runningPots = _calculatePeriodPots(
        initialPots,
        month,
        items,
        pulseForMonth,
        settings,
      );
      continue;
    }

    // Future months:
    // 1. First, calculate deductions for THIS month (payments happening in this period)
    // 2. Show the result as the projected balance for this period
    final projectedPots = _calculatePeriodPots(
      runningPots,
      month,
      items,
      pulseForMonth,
      settings,
    );
    projections.add(projectedPots);
    runningPots = projectedPots;
  }

  return projections;
}

/// Calculates pot balances after deducting payments that occur in the given period.
///
/// For future months, this deducts all planned (not yet paid) debt payments
/// that should occur in this period.
List<MoneyPot> _calculatePeriodPots(
  List<MoneyPot> startingPots,
  DateTime month,
  List<TimelineItem> items,
  List<PulseEntry> Function(DateTime) pulseForMonth,
  AppSettingsStore settings,
) {
  final resultPots = <MoneyPot>[];
  final monthPulses = pulseForMonth(month);
  final pulseMap = buildPulseLookupMap(monthPulses);

  final periodInfo = PaycheckService.getPeriodInfo(
    month,
    settings.viewPeriodMode,
    settings.paycheckDay,
    businessAdjust: settings.paycheckBusinessAdjust,
    adjustDirection: settings.paycheckBusinessAdjustDirection,
  );

  for (final pot in startingPots) {
    if (pot.type != MoneyPotType.debt) {
      resultPots.add(pot);
      continue;
    }

    // Find debt items linked to this pot that should appear in this period
    final linkedItems = items
        .where(
          (i) =>
              i.moneyPotId == pot.id &&
              PaycheckService.shouldItemAppearInPeriod(i, periodInfo, month),
        )
        .toList();

    var potBalance = pot.amountMinorUnits;

    for (final item in linkedItems) {
      // Check if already paid (should be false for future months)
      final isPaid = findPulseWithMap(
            item: item,
            pulseMap: pulseMap,
            month: month,
            settings: settings,
            periodInfo: periodInfo,
          ) !=
          null;

      // Deduct if not paid and not skipped
      if (!isPaid && !item.isSkippedInMonth(month)) {
        // For debt items, amountMinorUnits may be in the loan currency (legacy items
        // where transactionAmountMinorUnits is null) or in the app currency (new convention
        // where transactionAmountMinorUnits is set). If the pot is in the same currency
        // as the debt, use the amount directly. If they differ, we'd need conversion
        // (but typically debt pot matches debt currency).
        final int deductionAmount;
        if (item.balanceCurrency != null &&
            pot.currency == item.balanceCurrency) {
          // Same currency - use amount directly (no conversion needed)
          deductionAmount = item.amountMinorUnits;
        } else if (item.balanceCurrency == null) {
          // Debt is in app currency - use amount directly
          deductionAmount = item.amountMinorUnits;
        } else {
          // Different currencies - would need conversion
          // For now, use the amount as-is (this case is rare)
          deductionAmount = item.amountMinorUnits;
        }
        // Debt amount is signed negative, so adding it reduces the pot balance
        potBalance += deductionAmount;
      }
    }

    resultPots.add(pot.copyWith(amountMinorUnits: potBalance));
  }

  return resultPots;
}
