import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';

List<TimelineItem> orderedTimelineItems(
  Iterable<TimelineItem> items,
  TimelineSortOrder order, {
  TimelineDateSortMode dateSortMode = TimelineDateSortMode.scheduledDate,
  ViewPeriodMode viewMode = ViewPeriodMode.calendar,
  PeriodInfo? periodInfo,
  DateTime? Function(TimelineItem)? actualDateProvider,
}) {
  final sorted = items.toList(growable: false);

  // For name-based sorting, sort primarily by label
  if (order == TimelineSortOrder.nameAscending ||
      order == TimelineSortOrder.nameDescending) {
    sorted.sort((a, b) {
      final cmp = a.label.toLowerCase().compareTo(b.label.toLowerCase());
      return order == TimelineSortOrder.nameAscending ? cmp : -cmp;
    });
    return sorted;
  }

  // For date-based sorting (chronological/reverseChronological)
  sorted.sort((a, b) {
    int dayA = a.dayOfMonth;
    int dayB = b.dayOfMonth;

    // Use actual pulse date for cleared items if available,
    // regardless of dateSortMode (ensures date changes on Mark page affect order)
    if (actualDateProvider != null) {
      final dateA = actualDateProvider(a);
      final dateB = actualDateProvider(b);
      if (dateA != null) dayA = dateA.day;
      if (dateB != null) dayB = dateB.day;
    }

    final cmp = daySortValue(
      dayA,
      viewMode: viewMode,
      periodInfo: periodInfo,
    ).compareTo(daySortValue(dayB, viewMode: viewMode, periodInfo: periodInfo));
    final ordered = order == TimelineSortOrder.chronological ? cmp : -cmp;
    if (ordered != 0) return ordered;
    return a.label.compareTo(b.label);
  });
  return sorted;
}

int dayOfMonthValue(TimelineItem item) => item.dayOfMonth;

int daySortValue(
  int day, {
  required ViewPeriodMode viewMode,
  PeriodInfo? periodInfo,
}) {
  if (viewMode != ViewPeriodMode.paycheck || periodInfo == null) {
    return day;
  }

  final startDay = periodInfo.start.day;
  final daysInStartMonth = DateTime.utc(
    periodInfo.start.year,
    periodInfo.start.month + 1,
    0,
  ).day;

  if (day >= startDay) {
    return day - startDay;
  }
  return (daysInStartMonth - startDay + 1) + day;
}
