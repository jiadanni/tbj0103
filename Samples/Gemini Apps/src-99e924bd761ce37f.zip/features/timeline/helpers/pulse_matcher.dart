import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_helpers.dart';

/// Efficient pulse lookup helper that caches pulse-to-timeline-item mapping.
///
/// Provides O(1) lookups instead of O(n) linear search through all pulse.
/// Handles the complex matching logic from [pulseMatchesTimelineItem] in one place.
class PulseMatcher {
  PulseMatcher({
    required List<PulseEntry> pulses,
    required DateTime month,
    required AppSettingsStore settings,
  }) {
    _buildLookupMap(pulses, settings);
  }

  /// Maps timeline item ID to its most recent matching pulse.
  /// Only includes pulse that match via [pulseMatchesTimelineItem].
  late final Map<String, PulseEntry> _pulseByItemId;

  /// Builds the lookup map from pulse list.
  /// Handles the matching logic and keeps the most recent pulse for each item.
  void _buildLookupMap(List<PulseEntry> pulses, AppSettingsStore settings) {
    _pulseByItemId = {};

    for (final pulse in pulses) {
      final itemId = pulse.timelineItemId;
      if (itemId == null) continue;

      // Note: We assume pulseMatchesTimelineItem is called separately if needed.
      // For optimization, we store all pulse by item ID here.
      // The caller should filter items appropriately before using this matcher.

      final existing = _pulseByItemId[itemId];
      if (existing == null || pulse.date.isAfter(existing.date)) {
        // Keep the most recent pulse for this item
        _pulseByItemId[itemId] = pulse;
      }
    }
  }

  /// Get the most recent pulse for a timeline item.
  /// Returns null if no pulse exists for this item.
  PulseEntry? pulseFor(TimelineItem item) => _pulseByItemId[item.id];

  /// Get the cleared date for a timeline item.
  /// Returns null if item has no matching pulse.
  DateTime? clearedDateFor(TimelineItem item) => _pulseByItemId[item.id]?.date;

  /// Check if a timeline item has been cleared (has a pulse).
  bool isCleared(TimelineItem item) => _pulseByItemId.containsKey(item.id);

  /// Get all cleared timeline item IDs.
  Set<String> get clearedItemIds => _pulseByItemId.keys.toSet();

  /// Get the count of cleared items.
  int get clearedCount => _pulseByItemId.length;
}
