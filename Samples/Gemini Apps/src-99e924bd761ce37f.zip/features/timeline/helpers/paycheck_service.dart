import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

/// Contains information about a viewing period (calendar month or paycheck period)
class PeriodInfo {
  const PeriodInfo({
    required this.start,
    required this.end,
    required this.label,
    this.adjustedPayday,
    this.rawPayday,
  });

  /// The start date of the period (inclusive)
  final DateTime start;

  /// The end date of the period (inclusive)
  final DateTime end;

  /// The formatted label for display (e.g., "Jan 2025" or "Dec 25 – Jan 24")
  final String label;

  /// The actual date the salary will be paid (if different from scheduled)
  final DateTime? adjustedPayday;

  /// The scheduled payday (boundary start)
  final DateTime? rawPayday;

  bool get hasPaydayAdjustment =>
      adjustedPayday != null &&
      rawPayday != null &&
      adjustedPayday != rawPayday;

  /// Whether [date] falls within this period (inclusive of both [start] and [end]).
  ///
  /// The period is treated as a half-open interval `[start, end+1day)` so that
  /// dates on the last day of the period are included regardless of time component.
  bool containsDate(DateTime date) {
    final periodEndExclusive = end.add(const Duration(days: 1));
    return !date.isBefore(start) && date.isBefore(periodEndExclusive);
  }
}

/// Service for calculating paycheck periods and adjusting dates based on business days.
class PaycheckService {
  /// Gets period information (start, end, label) based on view mode.
  ///
  /// For calendar mode: returns the full calendar month.
  /// For paycheck mode: returns period from paycheckDay of previous month to paycheckDay-1 of referenceMonth.
  ///
  /// Example: referenceMonth = Jan 2025, paycheckDay = 25
  /// Result: start = Dec 25, 2024, end = Jan 24, 2025, label = "Dec 25 – Jan 24"
  /// The period is named by its ending month (January in this case).
  static PeriodInfo getPeriodInfo(
    DateTime referenceMonth,
    ViewPeriodMode mode,
    int? paycheckDay, {
    bool businessAdjust = true,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
    bool includeMonth = false,
  }) {
    final normalized = DateTime.utc(referenceMonth.year, referenceMonth.month);

    if (mode == ViewPeriodMode.calendar) {
      // Calendar month: 1st to last day of month
      final start = DateTime.utc(normalized.year, normalized.month, 1);
      final end = DateTime.utc(
        normalized.year,
        normalized.month + 1,
        0,
      ); // Last day of month
      return PeriodInfo(start: start, end: end, label: _monthLabel(normalized));
    }

    // Paycheck mode
    final day = paycheckDay ?? 1;

    // Helper to compute the payday for any given month
    DateTime getPaydayForMonth(DateTime month, {bool applyAdjustment = false}) {
      final daysInMonth = DateTime.utc(month.year, month.month + 1, 0).day;
      final clampedDay = day.clamp(1, daysInMonth);
      var payday = DateTime.utc(month.year, month.month, clampedDay);
      if (applyAdjustment && businessAdjust) {
        return applyBusinessAdjust(payday, businessAdjust, adjustDirection);
      }
      return payday;
    }

    // Calculate start: the raw payday from the PREVIOUS month
    // Boundaries are FIXED, so we don't apply business adjustment to start/end
    final prevMonth = DateTime.utc(normalized.year, normalized.month - 1);
    final start = getPaydayForMonth(prevMonth, applyAdjustment: false);

    // Calculate end: day before the raw payday of THIS month
    DateTime end;
    if (day == 1) {
      // Special case for payday on 1st: period ends on last day of previous month
      end = DateTime.utc(
        normalized.year,
        normalized.month,
        0,
      ); // Day 0 = last day of prev month
    } else {
      // Normal case: end is day before the START of the NEXT period
      final nextPeriodStart = getPaydayForMonth(
        normalized,
        applyAdjustment: false,
      );
      end = nextPeriodStart.subtract(const Duration(days: 1));
    }

    // Calculate payday info for the UI indicator (for the START of this period)
    // We want to know if the salary payment for this period (which happens at start)
    // was adjusted.
    final rawPayday = start;
    final adjustedPayday = getPaydayForMonth(prevMonth, applyAdjustment: true);

    // Format label: "Dec 25 – Jan 24" or "Dec 25 '25 – Jan 24 '26" if spanning years
    final monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final fullMonthNames = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    final startMonthName = monthNames[start.month - 1];
    final endMonthName = monthNames[end.month - 1];

    // Include year if the period spans different years
    String dateRange;
    if (start.year != end.year) {
      final startYear = start.year.toString().substring(2); // Last 2 digits
      final endYear = end.year.toString().substring(2); // Last 2 digits
      dateRange =
          '$startMonthName ${start.day} \'$startYear – $endMonthName ${end.day} \'$endYear';
    } else {
      dateRange = '$startMonthName ${start.day} – $endMonthName ${end.day}';
    }

    final String label;
    if (includeMonth) {
      final refMonthName = fullMonthNames[normalized.month - 1];
      label = '$refMonthName: $dateRange';
    } else {
      label = dateRange;
    }

    return PeriodInfo(
      start: start,
      end: end,
      label: label,
      rawPayday: rawPayday,
      adjustedPayday: adjustedPayday,
    );
  }

  /// Returns the reference month that contains the given date in paycheck mode.
  ///
  /// In paycheck mode, a period spans from paycheckDay of one month to paycheckDay-1 of the next month.
  /// The period is named by its ending month.
  ///
  /// Example: paycheckDay = 25
  /// - Jan 15, 2025 is in period "Dec 25 – Jan 24" → reference month is Jan 2025
  /// - Jan 27, 2025 is in period "Jan 25 – Feb 24" → reference month is Feb 2025
  static DateTime getCurrentPaycheckPeriodMonth(
    DateTime date,
    int paycheckDay, {
    bool businessAdjust = true,
    PaycheckAdjustDirection adjustDirection = PaycheckAdjustDirection.after,
  }) {
    final normalized = dateOnly(date);
    final day = paycheckDay.clamp(1, 31);

    // Calculate the payday for the current month
    final currentMonth = DateTime.utc(normalized.year, normalized.month);
    final daysInCurrentMonth = DateTime.utc(
      currentMonth.year,
      currentMonth.month + 1,
      0,
    ).day;
    final paydayDay = day.clamp(1, daysInCurrentMonth);
    var currentPayday = DateTime.utc(
      currentMonth.year,
      currentMonth.month,
      paydayDay,
    );
    // Boundary check uses RAW payday, so NO business adjustment here
    // currentPayday = applyBusinessAdjust(currentPayday, businessAdjust, adjustDirection);

    // If we're on or after the payday, we're in the period ending next month
    if (!normalized.isBefore(currentPayday)) {
      return month_math.addMonths(currentMonth, 1);
    }

    // Otherwise, we're in the period ending this month
    return currentMonth;
  }

  /// Determines if a recurring timeline item effectively falls within the given period info.
  ///
  /// This handles split-month periods (Paycheck Mode) where an item might recur in the reference month
  /// but fall outside the period boundaries, or recur in the previous month and fall inside.
  static bool shouldItemAppearInPeriod(
    TimelineItem item,
    PeriodInfo periodInfo,
    DateTime referenceMonth, {
    bool ignoreSkips = false,
  }) {
    // 0. Special handling for virtual orphan items
    if (item.id.value.startsWith('virtual_')) {
      final itemDate = dateOnly(item.startDate);
      return periodInfo.containsDate(itemDate);
    }

    // For Monthly, Quarterly, Yearly items, the occurrence is usually on a single day per month.
    // We can use an optimized check for these (checking if that day falls in the period).
    // However, for Weekly/Biweekly, we must check if ANY occurrence falls in the period.
    // And even for Monthly, checking against start/end dates is safer than checking day components
    // because start/end might be adjusted.

    // Iterate through potential occurrence months.
    // The period typically spans two months: StartMonth and EndMonth.
    // Check if the item appears in either month, and if so, check if the specific occurrence date
    // is within [start, end].

    final start = dateOnly(periodInfo.start);
    final end = dateOnly(periodInfo.end);

    // Check Start Month
    final startMonth = DateTime.utc(start.year, start.month);
    if (item.shouldAppearInMonth(startMonth, ignoreSkips: ignoreSkips)) {
      // Item appears in Start Month. Does the occurrence date fall within [start, end]?
      if (_hasOccurrenceInPeriod(item, startMonth, start, end)) return true;
    }

    // Check End Month (if different from Start Month)
    if (start.year != end.year || start.month != end.month) {
      final endMonth = DateTime.utc(end.year, end.month);
      if (item.shouldAppearInMonth(endMonth, ignoreSkips: ignoreSkips)) {
        if (_hasOccurrenceInPeriod(item, endMonth, start, end)) return true;
      }
    }

    return false;
  }

  static bool _hasOccurrenceInPeriod(TimelineItem item, DateTime month,
      DateTime periodStart, DateTime periodEnd) {
    // Calculate occurrences in this month.
    // For Monthly/Quarterly/Yearly/OneOff: Single occurrence.
    // For Weekly/Biweekly: Multiple occurrences.

    if (item.frequency == RecurrenceFrequency.weekly ||
        item.frequency == RecurrenceFrequency.biweekly) {
      // Calculate all occurrences in this month
      // Start from the first occurrence in this month
      // We need to find the first occurrence >= month start.
      // Or just iterate from item.startDate.
      // Optimally: Find first occurrence on or after max(monthStart, periodStart).

      final searchStart = periodStart.isAfter(month) ? periodStart : month;

      var current = item.startDate;
      // Fast forward to searchStart
      // We calculate the number of full intervals passed using floor,
      // then add one interval to ensure we land on or after searchStart if needed.
      final daysDiff = searchStart.difference(current).inDays;
      if (daysDiff > 0) {
        final interval = item.frequency == RecurrenceFrequency.weekly ? 7 : 14;
        // Use integer division (floor) to get base number of periods
        final periods = (daysDiff / interval).floor();
        current = current.add(Duration(days: periods * interval));

        // If we haven't reached searchStart yet, move one more step
        // (This handles the case where the previous step landed exactly on searchStart correctly
        // because we only add if we are STRICTLY before searchStart... wait.)
        // Actually, if we landed exactly on searchStart, `isBefore` will be false.
        // So we only advance if we are strictly before.
        if (dateOnly(current).isBefore(searchStart)) {
          current = current.add(Duration(days: interval));
        }
      }

      // Check occurrences until we pass periodEnd or end of month
      final monthEnd = DateTime.utc(month.year, month.month + 1, 0);
      final limit = periodEnd.isBefore(monthEnd) ? periodEnd : monthEnd;

      while (!dateOnly(current).isAfter(limit)) {
        if (!dateOnly(current).isBefore(periodStart)) {
          return true;
        }
        current = current.add(Duration(
            days: item.frequency == RecurrenceFrequency.weekly ? 7 : 14));
      }
      return false;
    } else {
      // Monthly/Quarterly/Yearly/OneOff
      // Occurrence is on dayOfMonth (clamped).
      final daysInMonth = DateTime.utc(month.year, month.month + 1, 0).day;
      final day = item.dayOfMonth > daysInMonth ? daysInMonth : item.dayOfMonth;
      final occurrence = DateTime.utc(month.year, month.month, day);

      return !occurrence.isBefore(periodStart) &&
          !occurrence.isAfter(periodEnd);
    }
  }

  static DateTime applyBusinessAdjust(
    DateTime d,
    bool businessAdjust,
    PaycheckAdjustDirection adjustDirection,
  ) {
    if (!businessAdjust) return d;
    // If Saturday (6) or Sunday (7), move before or after
    if (d.weekday == DateTime.saturday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 1))
          : d.add(const Duration(days: 2));
    }
    if (d.weekday == DateTime.sunday) {
      return adjustDirection == PaycheckAdjustDirection.before
          ? d.subtract(const Duration(days: 2))
          : d.add(const Duration(days: 1));
    }
    return d;
  }

  static String _monthLabel(DateTime month) {
    const names = <String>[
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${names[month.month - 1]} ${month.year}';
  }
}
