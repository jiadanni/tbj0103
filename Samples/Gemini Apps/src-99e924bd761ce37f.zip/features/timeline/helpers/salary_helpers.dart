import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Checks if an item should prompt for paycheck day sync when marked as salary
bool shouldOfferPaycheckDaySync(TimelineItem item, AppSettingsStore settings) {
  // Only offer for recurring income items being marked as salary
  if (item.type != PulseType.recurringIncome) return false;

  // Offer if paycheckDay is not set or differs from item's day
  return settings.paycheckDay == null ||
      settings.paycheckDay != item.dayOfMonth;
}

/// Syncs the paycheckDay setting from a salary item
void syncPaycheckDayFromSalary(
  TimelineItem salaryItem,
  AppSettingsStore settings,
) {
  settings.paycheckDay = salaryItem.dayOfMonth;
}

/// Returns all timeline items marked as salary
List<TimelineItem> getSalaryItems(List<TimelineItem> items) {
  return items.where((item) => item.isSalary).toList();
}

/// Returns the primary (first) salary item if any exist
TimelineItem? getPrimarySalaryItem(List<TimelineItem> items) {
  try {
    return getSalaryItems(items).first;
  } catch (_) {
    return null;
  }
}
