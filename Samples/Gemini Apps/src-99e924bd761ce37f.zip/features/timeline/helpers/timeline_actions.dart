import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';

import 'package:expense_stalker_mobile/src/util/terminology.dart';

import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:collection/collection.dart';
import 'package:expense_stalker_mobile/src/util/exchange_rate_utils.dart';

import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/update_pulse_sheet.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/display_helpers.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/recurrence_advancer.dart';
import 'package:expense_stalker_mobile/src/util/snackbars.dart';
import 'package:expense_stalker_mobile/src/widgets/skip_until_sheet.dart';

DismissDirection? dismissDirection({
  required TimelineSwipeAction left,
  required TimelineSwipeAction right,
}) {
  final leftEnabled = left != TimelineSwipeAction.off;
  final rightEnabled = right != TimelineSwipeAction.off;
  if (!leftEnabled && !rightEnabled) return null;
  if (leftEnabled && rightEnabled) return DismissDirection.horizontal;
  if (leftEnabled) return DismissDirection.endToStart;
  return DismissDirection.startToEnd;
}

Widget dismissBackground(
  BuildContext context, {
  required TimelineSwipeAction action,
  required bool alignLeft,
  bool isRecorded = false,
}) {
  if (action == TimelineSwipeAction.off) return const SizedBox.shrink();
  final isEdit = action == TimelineSwipeAction.edit;

  // For archive action, show different UI based on whether item is already recorded
  final bool isUnrecording = !isEdit && isRecorded;

  final bg = isEdit
      ? Theme.of(context).colorScheme.primaryContainer
      : isUnrecording
          ? Theme.of(context).colorScheme.tertiaryContainer
          : Theme.of(context).colorScheme.secondaryContainer;
  final fg = isEdit
      ? Theme.of(context).colorScheme.onPrimaryContainer
      : isUnrecording
          ? Theme.of(context).colorScheme.onTertiaryContainer
          : Theme.of(context).colorScheme.onSecondaryContainer;
  final terminology = Terminology.of(context);
  final l10n = AppLocalizations.of(context);
  final label = isEdit
      ? l10n?.edit ?? 'Edit'
      : isUnrecording
          ? terminology.unmarkActionLabel
          : terminology.markActionLabel;
  final icon = isEdit
      ? Icons.edit_outlined
      : isUnrecording
          ? Icons.undo_outlined
          : Icons.check_circle_outline;
  return Container(
    color: bg,
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: alignLeft ? Alignment.centerLeft : Alignment.centerRight,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!alignLeft) ...[
          Text(label, style: TextStyle(color: fg)),
          const SizedBox(width: 8),
          Icon(icon, color: fg),
        ] else ...[
          Icon(icon, color: fg),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: fg)),
        ],
      ],
    ),
  );
}

enum _TimelineItemMenuAction {
  archive,
  editSeries,
  editPulse,
  skip,
  skipUntil,
  pause,
  resume,
}

Future<bool> handleItemAction(
  BuildContext context,
  TimelineItem item,
  TimelineSwipeAction action, {
  DateTime? focusedMonth,
}) async {
  final store = ExpenseStoreScope.read(context);
  final settings = AppSettingsScope.read(context);
  final l10n = AppLocalizations.of(context);
  switch (action) {
    case TimelineSwipeAction.off:
      return false;
    case TimelineSwipeAction.edit:
      final result = await showModalBottomSheet<TimelineItem>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => UpsertTimelineItemSheet(
          existing: item,
          defaultStartDate: store.selectedMonth,
          onDelete: () {
            store.deleteTimelineItem(item.id);
          },
        ),
      );
      if (result != null) {
        store.upsertTimelineItem(result);
        if (context.mounted) {
          showActivitySavedSnackBar(context, result);
        }
      }
      return false;
    case TimelineSwipeAction.archive:
      // Virtual items (ID starting with "virtual_") are standalone pulses that were
      // converted to TimelineItems for display. They already represent recorded
      // transactions, so archiving them should not create new pulses.
      // FIX: Prevent duplication by returning early - the UI should show the menu instead.
      if (item.id.value.startsWith('virtual_')) {
        // Virtual items are already recorded transactions - don't create duplicates.
        // Return false to indicate no dismissal, the UI will show the menu via openMenu().
        return false;
      }

      // Use focusedMonth if provided (e.g. from Pulse Screen acting on a specific occurrence),
      // otherwise default to the currently viewed month in the Timeline.
      final month = focusedMonth ?? store.selectedMonth;
      // Get period info for proper pulse filtering in paycheck mode
      final periodInfo = PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );
      final existing = findPulseForItemInMonth(
        item: item,
        pulses: store.pulseForMonth(month, periodInfo: periodInfo),
        month: month,
        settings: settings,
      );

      // If already recorded, allow unrecording (toggle behavior)
      if (existing != null) {
        // SNAPSHOT STATE FOR ROLLBACK
        final previousBalance = settings.currentBalanceCents;
        // Removed invalid getter call 'item.isClearedTemporarily'

        try {
          store.deletePulse(existing.id);
          store.clearTimelineItemClearedTemporarily(item.id);

          // NOTE: Sign Convention
          // amountMinorUnits is ALWAYS signed: negative for expenses, positive for income.
          // Subtracting a signed value correctly reverses the balance change:
          // - Deleting an expense (negative) subtracts negative = adds back to balance
          // - Deleting income (positive) subtracts positive = reduces balance
          //
          // Atomicity
          // These updates (balance, pot, item) are not atomic. If the app crashes between
          // steps, data may be inconsistent. The undo action in SnackBar provides recovery.
          // FIX(Issue #17): Added try-catch for basic runtime atomicity.
          if (!settings.balanceUpdatesDisabled) {
            settings.currentBalanceCents = safeAddBalance(
              settings.currentBalanceCents,
              -existing.amountMinorUnits,
            );
          }

          // Revert Money Pot balance if linked
          if (existing.moneyPotId != null) {
            final pot = settings.moneyPots.firstWhereOrNull(
              (p) => p.id == existing.moneyPotId,
            );
            if (pot != null) {
              // Convert pulse amount to pot's balance currency
              // FIX(Issue #16): Use historical exchange rate from the pulse to ensure correct reversal amount.
              // Pass pot to use pot's own currency settings
              final convertedAmount = convertPulseToBalanceCurrency(
                existing.amountMinorUnits,
                item,
                pot: pot,
                entry: existing,
                exchangeRateOverride: existing.exchangeRate,
              );
              final newBalance = pot.amountMinorUnits + convertedAmount;
              await settings.updateMoneyPot(
                pot.copyWith(amountMinorUnits: newBalance),
              );
              if (item.moneyPotId == existing.moneyPotId) {
                store.upsertTimelineItem(
                  item.copyWith(
                    remainingBalanceMinorUnits: Optional(newBalance),
                  ),
                );
              }
            }
          } else if (item.type == PulseType.debt &&
              item.remainingBalanceMinorUnits != null) {
            // Direct TimelineItem Balance Revert (No Money Pot linked)
            // FIX(Issue #16): Use historical exchange rate
            // No pot, so use item's balance currency
            final convertedAmount = convertPulseToBalanceCurrency(
              existing.amountMinorUnits,
              item,
              entry: existing,
              exchangeRateOverride: existing.exchangeRate,
            );
            final newBalance =
                item.remainingBalanceMinorUnits! + convertedAmount;
            store.upsertTimelineItem(
              item.copyWith(remainingBalanceMinorUnits: Optional(newBalance)),
            );
          }

          if (context.mounted) {
            final messenger = ScaffoldMessenger.of(context);
            messenger.removeCurrentSnackBar();
            messenger.showSnackBar(
              SnackBar(
                content: Text(
                  l10n?.unrecordedLabel(item.label) ??
                      'Unrecorded ${item.label}',
                ),
                duration: AppConstants.snackBarShort,
                showCloseIcon: true,
                action: SnackBarAction(
                  label: l10n?.undo ?? 'Undo',
                  onPressed: () async {
                    if (!settings.balanceUpdatesDisabled) {
                      settings.currentBalanceCents = safeAddBalance(
                        settings.currentBalanceCents,
                        existing.amountMinorUnits,
                      );
                    }
                    store.upsertPulse(existing);
                    store.clearTimelineItemClearedTemporarily(
                      item.id,
                    ); // Was likely cleared before if unrecording
                    // Re-apply Money Pot reduction
                    if (existing.moneyPotId != null) {
                      final pot = settings.moneyPots.firstWhereOrNull(
                        (p) => p.id == existing.moneyPotId,
                      );
                      if (pot != null) {
                        // Convert pulse amount to pot's balance currency
                        final convertedAmount = convertPulseToBalanceCurrency(
                          existing.amountMinorUnits,
                          item,
                          pot: pot,
                          entry: existing,
                          exchangeRateOverride: existing.exchangeRate,
                        );
                        final newBalance =
                            pot.amountMinorUnits - convertedAmount;
                        await settings.updateMoneyPot(
                          pot.copyWith(amountMinorUnits: newBalance),
                        );
                        if (item.moneyPotId == existing.moneyPotId) {
                          store.upsertTimelineItem(
                            item.copyWith(
                              remainingBalanceMinorUnits: Optional(newBalance),
                            ),
                          );
                        }
                      }
                    } else if (item.type == PulseType.debt &&
                        item.remainingBalanceMinorUnits != null) {
                      // Direct TimelineItem Balance Revert (No Money Pot linked)
                      final convertedAmount = convertPulseToBalanceCurrency(
                        existing.amountMinorUnits,
                        item,
                        entry: existing,
                        exchangeRateOverride: existing.exchangeRate,
                      );
                      final newBalance = item.remainingBalanceMinorUnits! -
                          convertedAmount; // Re-deduct
                      store.upsertTimelineItem(
                        item.copyWith(
                          remainingBalanceMinorUnits: Optional(newBalance),
                        ),
                      );
                    }
                  },
                ),
              ),
            );
          }
        } catch (e) {
          // ROLLBACK ON ERROR
          debugPrint('Error unrecording pulse: $e');
          store.upsertPulse(existing); // Restore pulse
          settings.currentBalanceCents = previousBalance; // Restore balance

          // Re-adding the pulse might not be enough if we modified the pot/item balance partialy.
          // Since pot/item updates happen last, if they fail, we just urge the basic restoration.

          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Failed to unrecord item: $e')),
            );
          }
          rethrow;
        }
        return false;
      }

      // FIX(Issue #30): Calculate scheduled date based on ITEM's recurrence, not viewing month.
      // For one-off items, use startDate. For recurring, calculate the occurrence date
      // that falls within this period.
      final DateTime scheduledDate;
      if (item.type == PulseType.oneOff ||
          item.type == PulseType.oneOffIncome) {
        // One-off items: scheduled date IS the start date
        scheduledDate = DateTime.utc(
          item.startDate.year,
          item.startDate.month,
          item.startDate.day,
        );
      } else {
        // Recurring items: find which month's occurrence falls in this period
        // The item appears in this period, so we need to determine if it's from
        // the current month or previous month (in paycheck mode, periods span months)
        DateTime occurrenceMonth = month;

        // Check if this item's occurrence is actually from the previous month's tail
        final prevMonth = DateTime.utc(month.year, month.month - 1);
        if (item.shouldAppearInMonth(prevMonth)) {
          final prevDaysInMonth = DateTime.utc(
            prevMonth.year,
            prevMonth.month + 1,
            0,
          ).day;
          final effectiveDayPrev = item.dayOfMonth > prevDaysInMonth
              ? prevDaysInMonth
              : item.dayOfMonth;
          final prevOccurrence = DateTime.utc(
            prevMonth.year,
            prevMonth.month,
            effectiveDayPrev,
          );

          // If the previous month's occurrence falls within this period, use it
          if (periodInfo.containsDate(prevOccurrence)) {
            occurrenceMonth = prevMonth;
          }
        }

        final daysInMonth = DateTime.utc(
          occurrenceMonth.year,
          occurrenceMonth.month + 1,
          0,
        ).day;
        final effectiveDay =
            item.dayOfMonth > daysInMonth ? daysInMonth : item.dayOfMonth;
        scheduledDate = DateTime.utc(
          occurrenceMonth.year,
          occurrenceMonth.month,
          effectiveDay,
        );
      }

      final pulseDate = archiveDateForPeriod(periodInfo);

      // FIX(Issue #31): Check for existing pulse to prevent duplicates.
      // This guards against double-taps, UI re-renders, or race conditions.
      //
      // In paycheck mode, periods span two calendar months (e.g. Feb 23 → Mar 22),
      // so we check that the existing pulse's recorded date falls within the
      // current period. The period-based check is sufficient — no need to also
      // match scheduled month/year, which is fragile across period boundaries.
      final existingDuplicate = store.pulses.any(
        (p) => p.timelineItemId == item.id && periodInfo.containsDate(p.date),
      );

      if (existingDuplicate) {
        // A pulse already exists for this item in this period - don't create another
        debugPrint(
          'Prevented duplicate pulse for ${item.label} in ${scheduledDate.month}/${scheduledDate.year}',
        );
        return false;
      }

      // For foreign-currency debts, the item's amountMinorUnits is in the
      // LOAN currency (e.g. £1,000). The pulse needs:
      //   - amountMinorUnits = app-currency settlement (e.g. €1,200 = £1,000 × 1.2)
      //   - transactionCurrency = loan currency (e.g. GBP)
      //   - transactionAmountMinorUnits = loan amount (e.g. £1,000)
      // This ensures the Mark Paid sheet shows the FX row correctly from the start.
      final bool isForeignDebt = item.balanceCurrency != null &&
          item.exchangeRate != null &&
          item.exchangeRate! > 0;

      final int pulseAmount;
      final AppCurrency? pulseTransactionCurrency;
      final int? pulseTransactionAmountMinorUnits;

      if (isForeignDebt) {
        if (item.transactionAmountMinorUnits != null) {
          // New convention: amountMinorUnits is already app currency (settlement)
          pulseAmount = item.amountMinorUnits;
          pulseTransactionCurrency =
              item.transactionCurrency ?? item.balanceCurrency;
          pulseTransactionAmountMinorUnits = item.transactionAmountMinorUnits;
        } else {
          // Legacy convention: amountMinorUnits is loan currency, convert to app
          pulseAmount = (item.amountMinorUnits * item.exchangeRate!).round();
          pulseTransactionCurrency = item.balanceCurrency;
          pulseTransactionAmountMinorUnits = item.amountMinorUnits;
        }
      } else {
        pulseAmount = item.amountMinorUnits;
        pulseTransactionCurrency = item.transactionCurrency;
        pulseTransactionAmountMinorUnits = item.transactionAmountMinorUnits;
      }

      final pulse = PulseEntry(
        id: newEntryId(),
        label: item.label,
        amountMinorUnits: pulseAmount,
        date: pulseDate,
        type: item.type,
        timelineItemId: item.id,
        category: item.category, // inherit category from activity
        origin: item.origin, // inherit origin from activity
        scheduledDate: scheduledDate, // scheduled date (now correctly computed)
        scheduledAmountMinorUnits:
            pulseAmount, // scheduled amount in app currency
        moneyPotId: item.moneyPotId, // inherit default pot from item
        transactionCurrency: pulseTransactionCurrency,
        transactionAmountMinorUnits: pulseTransactionAmountMinorUnits,
        exchangeRate: item.exchangeRate,
      );
      final confirmedPulse = await showModalBottomSheet<PulseEntry>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) {
          final terminology = Terminology.of(context);
          return UpdatePulseSheet(
            pulse: pulse,
            title: terminology.markActionLabel,
            confirmButtonLabel: terminology.markActionLabel,
            showMoneyPotSelector: false,
            // Pass debt item for foreign currency conversion breakdown
            debtItem: item.type == PulseType.debt ? item : null,
          );
        },
      );

      if (confirmedPulse == null) {
        return false;
      }

      // SNAPSHOT STATE FOR ROLLBACK
      final previousBalance = settings.currentBalanceCents;

      try {
        store.upsertPulse(confirmedPulse);
        store.markTimelineItemClearedTemporarily(item.id);
        if (!settings.balanceUpdatesDisabled) {
          settings.currentBalanceCents = safeAddBalance(
            settings.currentBalanceCents,
            confirmedPulse.amountMinorUnits,
          );
        }

        // Apply Money Pot reduction (if confirmed pulse has a linked pot)
        if (confirmedPulse.moneyPotId != null) {
          final pot = settings.moneyPots.firstWhereOrNull(
            (p) => p.id == confirmedPulse.moneyPotId,
          );
          if (pot != null) {
            // Convert pulse amount to pot's balance currency (uses pot's currency settings)
            final convertedAmount = convertPulseToBalanceCurrency(
              confirmedPulse.amountMinorUnits,
              item,
              pot: pot,
              entry: confirmedPulse,
            );
            final newBalance = pot.amountMinorUnits - convertedAmount;
            await settings.updateMoneyPot(
              pot.copyWith(amountMinorUnits: newBalance),
            );

            // Sync TimelineItem to new Pot Balance
            if (item.moneyPotId == confirmedPulse.moneyPotId &&
                item.type == PulseType.debt) {
              // Auto-set paidOffDate when debt is fully paid
              // FIX(Issue #15): Only mark paid if balance is EXACTLY 0.
              final updatedItem = item.copyWith(
                remainingBalanceMinorUnits: Optional(newBalance),
                paidOffDate: newBalance == 0
                    ? Optional(DateTime.now().toUtc())
                    : const Optional.absent(),
              );
              store.upsertTimelineItem(updatedItem);
            }
          }
        } else if (item.type == PulseType.debt &&
            item.remainingBalanceMinorUnits != null) {
          // Direct TimelineItem Balance Update (No Money Pot linked)
          // Uses item's balance currency since no pot is present
          final convertedAmount = convertPulseToBalanceCurrency(
            confirmedPulse.amountMinorUnits,
            item,
            entry: confirmedPulse,
          );
          final newBalance = item.remainingBalanceMinorUnits! - convertedAmount;
          // Auto-set paidOffDate when debt is fully paid
          // FIX(Issue #15): Only mark paid if balance is EXACTLY 0.
          final updatedItem = item.copyWith(
            remainingBalanceMinorUnits: Optional(newBalance),
            paidOffDate: newBalance == 0
                ? Optional(DateTime.now().toUtc())
                : const Optional.absent(),
          );
          store.upsertTimelineItem(updatedItem);
        }

        // Advance recurring item's start date to next occurrence (calendar mode only)
        // See RecurrenceAdvancer for details on when/why this happens.
        // FIX(Issue #4): Pass business day settings to prevent weekly/biweekly drift.
        final nextStartDate = RecurrenceAdvancer.calculateNextStartDate(
          item: item,
          scheduledDate: scheduledDate,
          viewPeriodMode: settings.viewPeriodMode,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
        );
        if (nextStartDate != null) {
          // Re-fetch to avoid overwriting concurrent updates (e.g., debt balance)
          final freshItem = store.timelineItems.firstWhereOrNull(
            (p) => p.id == item.id,
          );
          // Assert in debug mode if we had to fall back to stale data
          assert(
            freshItem != null,
            'TimelineItem ${item.id} not found in store - using stale data',
          );
          store.upsertTimelineItem(
            (freshItem ?? item).copyWith(startDate: nextStartDate),
          );
        }

        if (context.mounted) {
          final messenger = ScaffoldMessenger.of(context);
          messenger.removeCurrentSnackBar();
          messenger.showSnackBar(
            SnackBar(
              content: Text(
                l10n?.recordedLabel(item.label) ?? 'Recorded ${item.label}',
              ),
              duration: AppConstants.snackBarShort,
              showCloseIcon: true,
              action: SnackBarAction(
                label: l10n?.undo ?? 'Undo',
                onPressed: () async {
                  if (!settings.balanceUpdatesDisabled) {
                    settings.currentBalanceCents = safeAddBalance(
                      settings.currentBalanceCents,
                      -confirmedPulse.amountMinorUnits,
                    );
                  }
                  store.deletePulse(confirmedPulse.id);
                  store.clearTimelineItemClearedTemporarily(item.id);
                  // Revert Money Pot reduction
                  if (confirmedPulse.moneyPotId != null) {
                    final pot = settings.moneyPots.firstWhereOrNull(
                      (p) => p.id == confirmedPulse.moneyPotId,
                    );
                    if (pot != null) {
                      // Convert pulse amount to pot's balance currency
                      final convertedAmount = convertPulseToBalanceCurrency(
                        confirmedPulse.amountMinorUnits,
                        item,
                        pot: pot,
                        entry: confirmedPulse,
                      );
                      await settings.updateMoneyPot(
                        pot.copyWith(
                          amountMinorUnits:
                              pot.amountMinorUnits + convertedAmount,
                        ),
                      );
                    }
                  } else if (item.type == PulseType.debt &&
                      item.remainingBalanceMinorUnits != null) {
                    // Direct TimelineItem Balance Update Revert
                    final convertedAmount = convertPulseToBalanceCurrency(
                      confirmedPulse.amountMinorUnits,
                      item,
                      entry: confirmedPulse,
                    );
                    final freshItem = store.timelineItems.firstWhereOrNull(
                      (p) => p.id == item.id,
                    );
                    if (freshItem != null &&
                        freshItem.remainingBalanceMinorUnits != null) {
                      final newBalance = freshItem.remainingBalanceMinorUnits! +
                          convertedAmount;
                      store.upsertTimelineItem(
                        freshItem.copyWith(
                          remainingBalanceMinorUnits: Optional(newBalance),
                        ),
                      );
                    }
                  }
                },
              ),
            ),
          );
        }
      } catch (e) {
        // ROLLBACK ON ERROR
        debugPrint('Error recording pulse: $e');
        store.deletePulse(confirmedPulse.id); // Revert creation
        settings.currentBalanceCents = previousBalance; // Restore balance
        store.clearTimelineItemClearedTemporarily(item.id); // Unmark cleared

        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Failed to record item: $e')));
        }
        rethrow;
      }
      return false;
  }
}

Future<void> showTimelineItemMenu({
  required BuildContext context,
  required TimelineItem item,
  required DateTime month,
  required Offset position,
  required bool canArchive,
  PulseEntry? pulse,
  PeriodInfo? periodInfo,
}) async {
  // FIX(Issue #36): Use maybeOf to safely handle missing overlay ancestor.
  // Overlay.of throws if no overlay exists; maybeOf returns null instead.
  final overlayState = Overlay.maybeOf(context);
  if (overlayState == null) return;
  final overlay = overlayState.context.findRenderObject() as RenderBox?;
  if (overlay == null) return;
  final store = ExpenseStoreScope.read(context);
  final settings = AppSettingsScope.read(context);
  final localizations = AppLocalizations.of(context);
  final theme = Theme.of(context);
  final textTheme = theme.textTheme;

  // Get period info for proper date calculation in paycheck mode
  final effectivePeriodInfo = periodInfo ??
      PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

  // Check if item is already paid to show "Edit Pulse" option
  // Note: logic duplicated from handleItemAction to determine state
  final existingPulse = pulse ??
      (() {
        return findPulseForItemInMonth(
          item: item,
          pulses: store.pulseForMonth(month, periodInfo: effectivePeriodInfo),
          month: month,
          settings: settings,
        );
      })();
  final isPaid = existingPulse != null;

  // Use getDisplayValues to get the correct due date, respecting paycheck mode
  // split-month logic and actual pulse dates if already paid
  final displayValues = getDisplayValues(
    item: item,
    month: month,
    pulse: existingPulse,
    periodInfo: effectivePeriodInfo,
    businessAdjust: settings.paycheckBusinessAdjust,
    adjustDirection: settings.paycheckBusinessAdjustDirection,
  );

  // Format the full due date with month and year
  final dueDate = displayValues.date;
  // Use a standard full date format for the menu header to avoid duplication/ambiguity
  // arising from user's 'dayFormat' preference (card view setting) combined with manual labels.
  final formattedDate = DateFormat('d MMM y').format(dueDate);
  final dueText = '${localizations?.dueLabel ?? 'Due'} $formattedDate';

  final headerWidgets = <Widget>[
    Text(
      item.label,
      style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
    ),
    const SizedBox(height: 6),
    Text(
      formatMoneyFromCents(
        item.amountMinorUnits,
        settings.currency,
        showCents: settings.showCents,
      ),
      style: textTheme.bodyMedium?.copyWith(
        fontFeatures: const [FontFeature.tabularFigures()],
      ),
    ),
    const SizedBox(height: 6),
    Text(dueText, style: textTheme.bodySmall),
  ];
  if (item.frequency != null) {
    headerWidgets.add(
      Text(
        '${localizations?.frequencyLabel ?? 'Freq'} ${item.frequency!.label}',
        style: textTheme.bodySmall,
      ),
    );
  }
  // Show Actual vs Scheduled info if paid
  if (isPaid && existingPulse.amountMinorUnits != item.amountMinorUnits) {
    headerWidgets.add(const SizedBox(height: 6));
    headerWidgets.add(
      Text(
        'Actual: ${formatMoneyFromCents(existingPulse.amountMinorUnits, settings.currency, showCents: settings.showCents)}',
        style: textTheme.bodySmall?.copyWith(
          color: existingPulse.amountMinorUnits != item.amountMinorUnits
              ? theme.colorScheme.error
              : theme.colorScheme.primary,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  if (item.pausedDate != null) {
    headerWidgets.add(const SizedBox(height: 6));
    headerWidgets.add(
      Text(
        'Paused',
        style: textTheme.bodySmall?.copyWith(
          color: theme.colorScheme.error,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  headerWidgets.add(
    Text(
      Terminology.of(context).pulseTypeLabel(item.type),
      style: textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500),
    ),
  );
  final notes = item.notes?.trim();
  if (notes != null && notes.isNotEmpty) {
    headerWidgets.add(const SizedBox(height: 6));
    headerWidgets.add(
      Text(
        notes,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: textTheme.bodySmall?.copyWith(
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }

  // Determine if this is a past period to disable modification actions like skip/pause
  final DateTime currentPeriodMonth;
  if (settings.viewPeriodMode == ViewPeriodMode.paycheck &&
      settings.isPaycheckModeConfigured) {
    currentPeriodMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      DateTime.now(),
      settings.paycheckDay!,
      businessAdjust: settings.paycheckBusinessAdjust,
      adjustDirection: settings.paycheckBusinessAdjustDirection,
    );
  } else {
    currentPeriodMonth = monthOnly(DateTime.now());
  }
  final monthOnlyValue = monthOnly(month);
  final isCurrentPeriod = monthOnlyValue.year == currentPeriodMonth.year &&
      monthOnlyValue.month == currentPeriodMonth.month;
  final isPast =
      monthOnlyValue.isBefore(currentPeriodMonth) && !isCurrentPeriod;

  final selection = await showMenu<_TimelineItemMenuAction>(
    context: context,
    position: RelativeRect.fromLTRB(
      position.dx,
      position.dy,
      overlay.size.width - position.dx,
      overlay.size.height - position.dy,
    ),
    items: [
      PopupMenuItem<_TimelineItemMenuAction>(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        enabled: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: headerWidgets,
        ),
      ),
      const PopupMenuDivider(),
      // Only show mark as paid option for current period (not future pulse)
      // and NOT for spending envelopes (they use quick-spend flow)
      // Gray out (disable) if paused - action is visible but not actionable
      if (canArchive && item.type != PulseType.spendingEnvelope)
        PopupMenuItem<_TimelineItemMenuAction>(
          value:
              item.pausedDate == null ? _TimelineItemMenuAction.archive : null,
          enabled: item.pausedDate == null,
          child: Row(
            children: [
              Icon(
                isPaid ? Icons.undo_outlined : Icons.check_circle_outline,
                size: 20,
                color: item.pausedDate != null
                    ? theme.colorScheme.onSurface.withValues(alpha: 0.38)
                    : null,
              ),
              const SizedBox(width: 12),
              Text(
                isPaid
                    ? Terminology.of(context).unmarkActionLabel
                    : Terminology.of(context).markActionLabel,
                style: item.pausedDate != null
                    ? TextStyle(
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.38,
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      // Only show "Edit Pulse Details" for items that are paid AND in the current period
      // and NOT for spending envelopes
      if (isPaid && canArchive && item.type != PulseType.spendingEnvelope)
        PopupMenuItem<_TimelineItemMenuAction>(
          value: _TimelineItemMenuAction.editPulse,
          child: Row(
            children: [
              const Icon(Icons.receipt_long_outlined, size: 20),
              const SizedBox(width: 12),
              Text(localizations?.editPulseDetails ?? 'Edit Pulse Details'),
            ],
          ),
        ),
      PopupMenuItem<_TimelineItemMenuAction>(
        value: _TimelineItemMenuAction.editSeries,
        child: Row(
          children: [
            const Icon(Icons.edit_calendar_outlined, size: 20),
            const SizedBox(width: 12),
            // Use terminology preset for consistent labeling
            Text(
              isPaid
                  ? Terminology.of(context).editItemTitle
                  : (localizations?.edit ?? 'Edit'),
            ),
          ],
        ),
      ),

      // Pause/Skip options - ONLY for current or future periods
      if (item.frequency != null &&
          item.type != PulseType.spendingEnvelope &&
          !isPast) ...[
        const PopupMenuDivider(),
        if (item.isSkippedInMonth(month))
          const PopupMenuItem<_TimelineItemMenuAction>(
            value: _TimelineItemMenuAction
                .skip, // Re-use skip enum or add new? Re-using skip for toggle context is confusing?
            // Better to use a specific action or handle logic below.
            // Let's reuse 'skip' but handle logic based on state, similar to archive/unarchive.
            child: Row(
              children: [
                Icon(Icons.restore, size: 20),
                SizedBox(width: 12),
                Text('Unskip occurrence'),
              ],
            ),
          )
        else if (item.pausedDate == null) ...[
          const PopupMenuItem<_TimelineItemMenuAction>(
            value: _TimelineItemMenuAction.skip,
            child: Row(
              children: [
                Icon(Icons.skip_next_outlined, size: 20),
                SizedBox(width: 12),
                Text('Skip this occurrence'),
              ],
            ),
          ),
          const PopupMenuItem<_TimelineItemMenuAction>(
            value: _TimelineItemMenuAction.skipUntil,
            child: Row(
              children: [
                Icon(Icons.fast_forward_outlined, size: 20),
                SizedBox(width: 12),
                Text('Skip until...'),
              ],
            ),
          ),
          const PopupMenuItem<_TimelineItemMenuAction>(
            value: _TimelineItemMenuAction.pause,
            child: Row(
              children: [
                Icon(Icons.pause_circle_outline, size: 20),
                SizedBox(width: 12),
                Text('Pause series'),
              ],
            ),
          ),
        ] else ...[
          const PopupMenuItem<_TimelineItemMenuAction>(
            value: _TimelineItemMenuAction.resume,
            child: Row(
              children: [
                Icon(Icons.play_circle_outline, size: 20),
                SizedBox(width: 12),
                Text('Resume series'),
              ],
            ),
          ),
        ],
      ],
    ],
  );

  if (!context.mounted || selection == null) return;

  // Handle new pause/skip actions
  if (selection == _TimelineItemMenuAction.skip) {
    if (item.isSkippedInMonth(month)) {
      store.unskipTimelineItemInstance(item.id, month);
    } else {
      store.skipTimelineItemInstance(item.id, month);
    }
    return;
  }

  if (selection == _TimelineItemMenuAction.pause) {
    store.setTimelineItemPauseWindow(item.id, pausedDate: month);
    return;
  }

  if (selection == _TimelineItemMenuAction.resume) {
    store.resumeTimelineItem(item.id);
    return;
  }

  if (selection == _TimelineItemMenuAction.skipUntil) {
    final resumeDate = await showModalBottomSheet<DateTime>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SkipUntilSheet(item: item, currentMonth: month),
    );

    if (resumeDate != null) {
      store.setTimelineItemPauseWindow(
        item.id,
        pausedDate: month,
        autoResumeDate: resumeDate,
      );
    }
    return;
  }

  if (selection == _TimelineItemMenuAction.editPulse && existingPulse != null) {
    final oldMoneyPotId = existingPulse.moneyPotId;
    final oldAmount = existingPulse.amountMinorUnits;

    final updated = await showModalBottomSheet<PulseEntry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => UpdatePulseSheet(
        pulse: existingPulse,
        confirmButtonLabel: 'Update',
        onDelete: () {
          handleItemAction(
            context,
            item,
            TimelineSwipeAction.archive,
            focusedMonth: month,
          );
        },
        // Pass debt item for foreign currency conversion breakdown
        debtItem: item.type == PulseType.debt ? item : null,
      ),
    );

    if (updated != null && context.mounted) {
      // Balance update logic: remove old amount, add new amount
      if (!settings.balanceUpdatesDisabled) {
        settings.currentBalanceCents = safeAddBalance(
          settings.currentBalanceCents,
          -existingPulse.amountMinorUnits + updated.amountMinorUnits,
        );
      }
      store.upsertPulse(updated);

      // Handle Money Pot updates
      // 1. If money pot changed or amount changed
      if (oldMoneyPotId != updated.moneyPotId ||
          oldAmount != updated.amountMinorUnits) {
        // Revert old pot if existed
        if (oldMoneyPotId != null) {
          final oldPot = settings.moneyPots.firstWhereOrNull(
            (p) => p.id == oldMoneyPotId,
          );
          if (oldPot != null) {
            // Convert old amount to pot's balance currency
            final oldConvertedAmount = convertPulseToBalanceCurrency(
              oldAmount,
              item,
              pot: oldPot,
              entry: existingPulse,
            );
            // Revert: Add back the amount (since pulse reduced it)
            await settings.updateMoneyPot(
              oldPot.copyWith(
                amountMinorUnits: oldPot.amountMinorUnits + oldConvertedAmount,
              ),
            );
          }
        }

        // Apply to new pot if exists
        if (updated.moneyPotId != null) {
          final newPot = settings.moneyPots.firstWhereOrNull(
            (p) => p.id == updated.moneyPotId,
          );
          if (newPot != null) {
            // Convert new amount to pot's balance currency
            final newConvertedAmount = convertPulseToBalanceCurrency(
              updated.amountMinorUnits,
              item,
              pot: newPot,
              entry: updated,
            );
            // Apply: Deduct the amount
            final newBalance = newPot.amountMinorUnits - newConvertedAmount;
            await settings.updateMoneyPot(
              newPot.copyWith(amountMinorUnits: newBalance),
            );

            // Sync TimelineItem (if linked to this new Payee/Pot)
            if (item.moneyPotId == updated.moneyPotId &&
                item.type == PulseType.debt) {
              // Auto-set paidOffDate when debt is fully paid
              store.upsertTimelineItem(
                item.copyWith(
                  remainingBalanceMinorUnits: Optional(newBalance),
                  paidOffDate: newBalance == 0
                      ? Optional(DateTime.now().toUtc())
                      : const Optional.absent(),
                ),
              );
            }
          }
        }
      } else if (item.type == PulseType.debt &&
          item.remainingBalanceMinorUnits != null) {
        // Direct Update (No Pot Change, but Amount might have changed)
        // If Pot IS linked, the block above handles it (via Pot update).
        // If Pot is NOT linked (item.moneyPotId == null), we must update manually.
        if (item.moneyPotId == null) {
          final diff = updated.amountMinorUnits -
              oldAmount; // + if paid more (debt reduces more) or less?
          // Debt Balance = OldBalance + OldPulse - NewPulse
          // actually: Balance is remaining.
          // Prev Balance = Current + OldPulse.
          // New Balance = Prev Balance - NewPulse.
          // New Balance = Current + OldPulse - NewPulse.
          // New Balance = Current - (NewPulse - OldPulse).
          // New Balance = Current - diff.

          final newBalance = item.remainingBalanceMinorUnits! - diff;
          // Auto-set paidOffDate when debt is fully paid
          // FIX(Issue #15): Only mark paid if balance is EXACTLY 0.
          store.upsertTimelineItem(
            item.copyWith(
              remainingBalanceMinorUnits: Optional(newBalance),
              paidOffDate: newBalance == 0
                  ? Optional(DateTime.now().toUtc())
                  : const Optional.absent(),
            ),
          );
        }
      }
    }
    return;
  }

  final action = selection == _TimelineItemMenuAction.archive
      ? TimelineSwipeAction.archive
      : TimelineSwipeAction.edit;
  if (action == TimelineSwipeAction.archive && !canArchive) return;
  await handleItemAction(context, item, action, focusedMonth: month);
}

/// Determines if a pulse entry matches a timeline item for a given period.
///
/// A pulse matches a timeline item if:
/// 1. The pulse has an explicit `timelineItemId` matching the item's id
/// 2. The pulse date falls within the period boundaries
///
/// Pulses without a `timelineItemId` are standalone transactions and don't
/// match any timeline item - they simply appear in the period based on date.
bool pulseMatchesTimelineItem(
  PulseEntry pulse,
  TimelineItem item,
  DateTime month,
  AppSettingsStore settings, {
  PeriodInfo? precomputedPeriodInfo,
}) {
  // Pulses without explicit link don't match any timeline item
  if (pulse.timelineItemId == null) {
    return false;
  }

  // Check if this pulse is explicitly linked to this item
  if (pulse.timelineItemId != item.id) {
    return false;
  }

  // Verify pulse date is within the period boundaries
  final periodInfo = precomputedPeriodInfo ??
      PaycheckService.getPeriodInfo(
        month,
        settings.viewPeriodMode,
        settings.paycheckDay,
        businessAdjust: settings.paycheckBusinessAdjust,
        adjustDirection: settings.paycheckBusinessAdjustDirection,
      );

  return periodInfo.containsDate(pulse.date);
}

PulseEntry? findPulseForItemInMonth({
  required TimelineItem item,
  required List<PulseEntry> pulses,
  required DateTime month,
  required AppSettingsStore settings,
  PeriodInfo? periodInfo,
}) {
  // FIX: Virtual items (standalone pulses) need direct lookup by pulse ID
  if (item.id.value.startsWith('virtual_')) {
    final pulseIdValue = item.id.value.substring('virtual_'.length);
    return pulses.where((p) => p.id.value == pulseIdValue).firstOrNull;
  }

  for (final pulse in pulses) {
    if (pulseMatchesTimelineItem(
      pulse,
      item,
      month,
      settings,
      precomputedPeriodInfo: periodInfo,
    )) {
      return pulse;
    }
  }
  return null;
}

/// Creates the archive date for a pulse in the given period.
///
/// In calendar mode, uses today's date clamped to the reference month.
/// In paycheck mode, uses today's actual date since periods can span months.
/// This ensures the pulse date falls within the period boundaries.
DateTime archiveDateForPeriod(PeriodInfo periodInfo) {
  final now = DateTime.now().toUtc();

  // If now is within the period, use now (preserves time)
  if (periodInfo.containsDate(now)) {
    return now;
  }

  // If now is before the period start, use the period start
  if (now.isBefore(periodInfo.start)) {
    return periodInfo.start;
  }

  // If now is after the period end, use the period end (end of that day)
  return periodInfo.end
      .add(const Duration(days: 1))
      .subtract(const Duration(milliseconds: 1));
}

/// Legacy function - prefer archiveDateForPeriod when period info is available.
@Deprecated('Use archiveDateForPeriod instead')
DateTime archiveDateForMonth(DateTime month) {
  final today = DateTime.now().day;
  final maxDay = DateUtils.getDaysInMonth(month.year, month.month);
  final day = today <= maxDay ? today : maxDay;
  return DateTime.utc(month.year, month.month, day);
}

/// Checks if a timeline item has been cleared (paid) for a specific month.
///
/// This is a convenience wrapper around [findPulseForItemInMonth] for cases
/// where you only need a boolean result.
bool isItemClearedForMonth({
  required TimelineItem item,
  required DateTime month,
  required List<PulseEntry> pulses,
  required AppSettingsStore settings,
  PeriodInfo? periodInfo,
}) {
  return findPulseForItemInMonth(
        item: item,
        pulses: pulses,
        month: month,
        settings: settings,
        periodInfo: periodInfo,
      ) !=
      null;
}

/// Builds a lookup map for fast pulse matching.
///
/// Returns a map where:
/// - Keys are timeline item IDs for explicitly linked pulse
/// - Keys are timeline item IDs for explicitly linked pulse
///
/// Use this when you need to check multiple items against the same list of pulse,
/// then call [findPulseWithMap] for O(1) lookups.
Map<String, List<PulseEntry>> buildPulseLookupMap(List<PulseEntry> pulses) {
  final map = <String, List<PulseEntry>>{};
  for (final pulse in pulses) {
    if (pulse.timelineItemId != null) {
      (map[pulse.timelineItemId!] ??= []).add(pulse);
    }
  }
  return map;
}

/// Finds a matching pulse for an item using a pre-built lookup map.
///
/// Use [buildPulseLookupMap] to create the map, then call this for each item.
/// This is more efficient than [findPulseForItemInMonth] when checking many items
/// against the same pulse list.
///
/// FIX: Virtual items (standalone pulses converted to TimelineItems for display)
/// are recognized by their ID prefix "virtual_" and directly look up their pulse.
DateTime? findPulseWithMap({
  required TimelineItem item,
  required Map<String, List<PulseEntry>> pulseMap,
  required DateTime month,
  required AppSettingsStore settings,
  PeriodInfo? periodInfo,
  List<PulseEntry>? allPulses,
}) {
  // FIX: Virtual items are standalone pulses - they ARE the pulse, so they're always "cleared"
  // The ID format is "virtual_{pulseId}", so we extract the pulse ID and verify it exists.
  if (item.id.value.startsWith('virtual_')) {
    // Virtual items represent already-recorded transactions, so they count as cleared.
    // Return the item's startDate (which is set to the pulse date in convert_standalone_pulses.dart)
    return item.startDate;
  }

  // Check explicit links first
  final explicitMatches = pulseMap[item.id];
  if (explicitMatches != null) {
    for (final pulse in explicitMatches) {
      if (pulseMatchesTimelineItem(
        pulse,
        item,
        month,
        settings,
        precomputedPeriodInfo: periodInfo,
      )) {
        return pulse.date;
      }
    }
  }

  return null;
}
