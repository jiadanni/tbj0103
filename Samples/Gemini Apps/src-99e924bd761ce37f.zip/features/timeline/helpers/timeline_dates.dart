import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

List<DateTime> monthRange(
  DateTime start, {
  int before = 0,
  required int after,
}) {
  final base = monthOnly(start);
  final total = before + 1 + after;
  return List<DateTime>.generate(
    total,
    (index) => monthOnly(month_math.addMonths(base, index - before)),
    growable: false,
  );
}

DateTime monthForPage(DateTime origin, int pageIndex, int monthOriginPage) {
  final offset = pageIndex - monthOriginPage;
  return monthOnly(month_math.addMonths(origin, offset));
}

int monthsBetween(DateTime a, DateTime b) {
  return month_math.monthsBetween(a, b);
}

bool isPastMonth(DateTime month) {
  final now = monthOnly(DateTime.now());
  return monthOnly(month).isBefore(now);
}

String monthShortLabel(DateTime month) {
  const names = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return names[month.month - 1];
}

String dateLabel(DateTime date) {
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

enum GridZoomStage { twoMonths, fourMonths, sixMonths }

String gridHeaderLabel(DateTime month, GridZoomStage stage, Locale locale) {
  final localeName = locale.toLanguageTag();
  switch (stage) {
    case GridZoomStage.twoMonths:
      return DateFormat.yMMMM(localeName).format(month);
    case GridZoomStage.fourMonths:
      return DateFormat('MMM yy', localeName).format(month);
    case GridZoomStage.sixMonths:
      return DateFormat.yMd(localeName).format(month);
  }
}

GridZoomStage gridZoomStageForVisibleMonths(double visibleMonths) {
  if (visibleMonths <= 2.5) return GridZoomStage.twoMonths;
  if (visibleMonths <= 4.5) return GridZoomStage.fourMonths;
  return GridZoomStage.sixMonths;
}

/// Clamps a day-of-month value to the actual last day of the given month.
///
/// For example, if [day] is 31 but [month] is February 2025, returns 28.
/// This ensures display consistency with how archived pulse are recorded.
int effectiveDayOfMonth(int day, DateTime month) {
  final maxDay = DateUtils.getDaysInMonth(month.year, month.month);
  return day <= maxDay ? day : maxDay;
}

String formatDayOfMonth(DateTime date, DayFormat format) {
  final day = date.day;

  switch (format) {
    case DayFormat.number:
      return '$day';

    case DayFormat.ordinal:
      return _ordinal(day);

    case DayFormat.ordinalMonth:
      return '${_ordinal(day)} ${_monthShort(date)}';

    case DayFormat.numericMonthDay:
      return '${_twoDigits(date.month)}/${_twoDigits(day)}';

    case DayFormat.numericDayMonth:
      return '${_twoDigits(day)}/${_twoDigits(date.month)}';
  }
}

String _ordinal(int day) {
  if (day >= 11 && day <= 13) return '${day}th';
  switch (day % 10) {
    case 1:
      return '${day}st';
    case 2:
      return '${day}nd';
    case 3:
      return '${day}rd';
    default:
      return '${day}th';
  }
}

String _monthShort(DateTime date) {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return months[date.month - 1];
}

String _twoDigits(int n) {
  if (n >= 10) return '$n';
  return '0$n';
}
