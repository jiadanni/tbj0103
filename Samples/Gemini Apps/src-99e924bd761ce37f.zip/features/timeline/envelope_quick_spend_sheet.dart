import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/widgets/quick_amount_selector.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/spending_envelope_service.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item_sheet.dart';

/// Formats a date as "MMM d" (e.g., "Jan 15")
String _formatDate(DateTime date) {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${months[date.month - 1]} ${date.day}';
}

/// Bottom sheet for quick-spending from a spending envelope.
///
/// Shows circular preset amount buttons and allows selecting an amount
/// to deduct from the envelope's budget for the current period.
/// Also displays spending history with edit/delete capability.
class EnvelopeQuickSpendSheet extends StatefulWidget {
  const EnvelopeQuickSpendSheet({
    super.key,
    required this.envelope,
    required this.store,
    required this.month,
  });

  final TimelineItem envelope;
  final ExpenseStore store;
  final DateTime month;

  @override
  State<EnvelopeQuickSpendSheet> createState() =>
      _EnvelopeQuickSpendSheetState();
}

class _EnvelopeQuickSpendSheetState extends State<EnvelopeQuickSpendSheet> {
  bool _showHistory = false;
  String? _selectedOrigin;

  @override
  void initState() {
    super.initState();
    // Default to envelope's origin if set
    _selectedOrigin = widget.envelope.origin;
  }

  /// Returns origins available for selection: envelope's suggested origins + default origin
  List<String> get _availableOrigins {
    final origins = <String>{};

    // Add envelope's default origin if set
    if (widget.envelope.origin != null && widget.envelope.origin!.isNotEmpty) {
      origins.add(widget.envelope.origin!);
    }

    // Add suggested origins from envelope
    if (widget.envelope.suggestedOrigins != null) {
      origins.addAll(
        widget.envelope.suggestedOrigins!.where((o) => o.isNotEmpty),
      );
    }

    // Add recent origins from this envelope's history
    final recentOrigins = widget.store.pulses
        .where(
          (p) =>
              p.timelineItemId == widget.envelope.id &&
              p.origin != null &&
              p.origin!.isNotEmpty,
        )
        .map((p) => p.origin!)
        .toSet();
    origins.addAll(recentOrigins);

    return origins.toList();
  }

  void _handleAmountSelected(BuildContext context, int amountCents) {
    // Expenses are negative
    final finalAmount = -amountCents.abs();

    final pulse = PulseEntry(
      id: newEntryId(),
      label: widget.envelope.label,
      amountMinorUnits: finalAmount,
      date: DateTime.now(),
      type: PulseType.spendingEnvelope,
      timelineItemId: widget.envelope.id,
      category: widget.envelope.category,
      origin: _selectedOrigin ?? widget.envelope.origin,
      moneyPotId: widget.envelope.moneyPotId,
    );

    widget.store.upsertPulse(pulse);

    // Update balance
    final settings = AppSettingsScope.read(context);
    if (!settings.balanceUpdatesDisabled) {
      settings.currentBalanceCents += pulse.amountMinorUnits;
    }

    Navigator.pop(context);

    final originSuffix = _selectedOrigin != null && _selectedOrigin!.isNotEmpty
        ? ' at $_selectedOrigin'
        : '';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Spent ${formatMoney(amountCents, settings.currency, showDecimals: settings.showCents)} from ${widget.envelope.label}$originSuffix',
        ),
      ),
    );
  }

  void _showCustomAmountDialog(BuildContext context) {
    Navigator.pop(context);

    showDialog(
      context: context,
      builder: (ctx) => _CustomAmountDialog(
        envelope: widget.envelope,
        store: widget.store,
        initialOrigin: _selectedOrigin,
      ),
    );
  }

  void _editPulse(BuildContext context, PulseEntry pulse) {
    showDialog(
      context: context,
      builder: (ctx) => _EditPulseDialog(
        pulse: pulse,
        store: widget.store,
        envelope: widget.envelope,
      ),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _deletePulse(BuildContext context, PulseEntry pulse) async {
    final settings = AppSettingsScope.read(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Entry?'),
        content: Text(
          'Delete ${formatMoneyFromCents(pulse.amountMinorUnits.abs(), settings.currency, showCents: settings.showCents)} from ${_formatDate(pulse.date)}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      if (!mounted) return;
      if (!context.mounted) return;
      // Reverse the balance change
      if (!settings.balanceUpdatesDisabled) {
        settings.currentBalanceCents -= pulse.amountMinorUnits;
      }
      widget.store.deletePulse(pulse.id);
      setState(() {});

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Entry deleted')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final amounts = settings.customQuickAddAmounts;
    final pulses = widget.store.pulsesForMonth(widget.month);

    // Calculate current spending progress
    final period = SpendingEnvelopeService.getEnvelopePeriodDates(
      widget.envelope,
      widget.month,
      settings,
    );
    final spent = SpendingEnvelopeService.getSpentAmountForPeriod(
      widget.envelope,
      pulses,
      period,
    );
    final target = widget.envelope.amountMinorUnits.abs();
    final remaining = target - spent;
    final progress = target > 0 ? spent / target : 0.0;
    final isOverBudget = progress > 1.0;

    // Get history entries for this envelope
    final historyEntries = pulses
        .where((p) => p.timelineItemId == widget.envelope.id)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date)); // Most recent first

    final progressColor = isOverBudget
        ? (target == 0
            ? settings.debitColor
            : Theme.of(context).colorScheme.error)
        : (progress > 0.8 ? Colors.orange : settings.debitColor);

    return Container(
      padding: const EdgeInsets.only(bottom: 24),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with envelope name
          // Header with envelope name
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 8, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(width: 48), // Spacer for balance
                Text(
                  widget.envelope.label,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () async {
                    // Close this sheet
                    Navigator.pop(context);

                    // Open edit sheet
                    final result = await showModalBottomSheet<TimelineItem>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (context) => UpsertTimelineItemSheet(
                        existing: widget.envelope,
                        defaultStartDate: widget.month,
                      ),
                    );

                    if (result != null) {
                      widget.store.upsertTimelineItem(result);
                    }
                  },
                ),
              ],
            ),
          ),

          // Spending progress
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Progress bar
                SizedBox(
                  width: 80,
                  height: 8,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      backgroundColor: Theme.of(
                        context,
                      ).colorScheme.surfaceContainerHighest,
                      valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Spent / Target text
                Text(
                  '${formatMoneyFromCents(-spent, settings.currency, showCents: settings.showCents)} / ${formatMoneyFromCents(widget.envelope.amountMinorUnits, settings.currency, showCents: settings.showCents)}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: progressColor,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 16),
            child: Text(
              remaining >= 0
                  ? '${formatMoneyFromCents(remaining, settings.currency, showCents: settings.showCents)} remaining'
                  : '${formatMoneyFromCents(-remaining, settings.currency, showCents: settings.showCents)} ${target == 0 ? 'unplanned spending' : 'over budget'}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: remaining >= 0
                        ? Theme.of(context).colorScheme.onSurfaceVariant
                        : (target == 0
                            ? Theme.of(context).colorScheme.onSurfaceVariant
                            : Theme.of(context).colorScheme.error),
                  ),
            ),
          ),

          // Origin selector (if origins are available)
          if (_availableOrigins.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Where',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ..._availableOrigins.map((origin) {
                        final isSelected = _selectedOrigin == origin;
                        return ChoiceChip(
                          label: Text(origin),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() {
                              _selectedOrigin = selected ? origin : null;
                            });
                          },
                          labelStyle: TextStyle(
                            fontSize: 13,
                            color: isSelected
                                ? Theme.of(
                                    context,
                                  ).colorScheme.onSecondaryContainer
                                : Theme.of(context).colorScheme.onSurface,
                          ),
                          visualDensity: VisualDensity.compact,
                        );
                      }),
                      // "Other" chip to allow no selection / custom
                      if (_selectedOrigin != null &&
                          !_availableOrigins.contains(_selectedOrigin))
                        ChoiceChip(
                          label: Text(_selectedOrigin!),
                          selected: true,
                          onSelected: (_) {
                            setState(() {
                              _selectedOrigin = null;
                            });
                          },
                          labelStyle: TextStyle(
                            fontSize: 13,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSecondaryContainer,
                          ),
                          visualDensity: VisualDensity.compact,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Quick amount buttons
          QuickAmountSelector(
            amounts: amounts,
            onAmountSelected: (amount) =>
                _handleAmountSelected(context, amount),
          ),

          const SizedBox(height: 16),

          // Custom amount fallback
          TextButton(
            onPressed: () => _showCustomAmountDialog(context),
            child: const Text('Enter Custom Amount'),
          ),

          // History section
          if (historyEntries.isNotEmpty) ...[
            const Divider(height: 32),
            InkWell(
              onTap: () => setState(() => _showHistory = !_showHistory),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16.0,
                  vertical: 8.0,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'History (${historyEntries.length})',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Icon(
                      _showHistory ? Icons.expand_less : Icons.expand_more,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
            if (_showHistory)
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  itemCount: historyEntries.length,
                  itemBuilder: (context, index) {
                    final entry = historyEntries[index];
                    return Dismissible(
                      key: ValueKey(entry.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16.0),
                        color: Theme.of(context).colorScheme.error,
                        child: Icon(
                          Icons.delete,
                          color: Theme.of(context).colorScheme.onError,
                        ),
                      ),
                      confirmDismiss: (_) async {
                        await _deletePulse(context, entry);
                        return false; // We handle deletion ourselves
                      },
                      child: ListTile(
                        dense: true,
                        onTap: () => _editPulse(context, entry),
                        leading: Icon(
                          Icons.receipt_outlined,
                          size: 18,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                        title: Text(_formatDate(entry.date)),
                        subtitle:
                            entry.origin != null && entry.origin!.isNotEmpty
                                ? Text(
                                    entry.origin!,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                                  )
                                : null,
                        trailing: Text(
                          formatMoneyFromCents(
                            entry.amountMinorUnits,
                            settings.currency,
                            showCents: settings.showCents,
                          ),
                          style: TextStyle(
                            color: settings.debitColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ],
      ),
    );
  }
}

/// Dialog for editing an existing spending entry.
class _EditPulseDialog extends StatefulWidget {
  const _EditPulseDialog({
    required this.pulse,
    required this.store,
    required this.envelope,
  });

  final PulseEntry pulse;
  final ExpenseStore store;
  final TimelineItem envelope;

  @override
  State<_EditPulseDialog> createState() => _EditPulseDialogState();
}

class _EditPulseDialogState extends State<_EditPulseDialog> {
  late final TextEditingController _amountController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // Convert cents to dollars for display (absolute value since expenses are negative)
    final amountMajor = widget.pulse.amountMinorUnits.abs() / 100.0;
    final text = amountMajor == amountMajor.truncateToDouble()
        ? amountMajor.truncate().toString()
        : amountMajor.toString();
    _amountController = TextEditingController(text: text);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
      _amountController.selection = TextSelection(
        baseOffset: 0,
        extentOffset: _amountController.text.length,
      );
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;

    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return;

    final settings = AppSettingsScope.read(context);

    // Calculate the difference before rounding for balance adjustment
    final oldAmount = widget.pulse.amountMinorUnits;
    final newAmount = -rawAmountCents.abs(); // Negative for expenses
    final difference = newAmount - oldAmount;

    // Update the pulse
    final updated = widget.pulse.copyWith(amountMinorUnits: newAmount);

    widget.store.upsertPulse(updated);

    // Adjust balance by the difference
    if (!settings.balanceUpdatesDisabled) {
      settings.currentBalanceCents += difference;
    }

    if (mounted) {
      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Updated to ${formatMoney(rawAmountCents, settings.currency, showDecimals: settings.showCents)}',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);

    return AlertDialog(
      title: const Text('Edit Amount'),
      content: TextField(
        controller: _amountController,
        focusNode: _focusNode,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: UpsertTimelineItemStyle.compactInput(
          context,
          'Amount',
          hintText: '0.00',
        ).copyWith(
          prefixText: '- ',
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
        ),
        inputFormatters: [
          if (settings.showCents)
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
          else
            FilteringTextInputFormatter.digitsOnly,
        ],
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(onPressed: _submit, child: const Text('Save')),
      ],
    );
  }
}

/// Dialog for entering a custom spending amount.
class _CustomAmountDialog extends StatefulWidget {
  const _CustomAmountDialog({
    required this.envelope,
    required this.store,
    this.initialOrigin,
  });

  final TimelineItem envelope;
  final ExpenseStore store;
  final String? initialOrigin;

  @override
  State<_CustomAmountDialog> createState() => _CustomAmountDialogState();
}

class _CustomAmountDialogState extends State<_CustomAmountDialog> {
  late final TextEditingController _amountController;
  late final TextEditingController _originController;
  final FocusNode _focusNode = FocusNode();
  final FocusNode _originFocusNode = FocusNode();
  final LayerLink _originLayerLink = LayerLink();

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    // Use pre-selected origin if available, otherwise fall back to envelope's default
    _originController = TextEditingController(
      text: widget.initialOrigin ?? widget.envelope.origin ?? '',
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _originController.dispose();
    _focusNode.dispose();
    _originFocusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _amountController.text.trim();
    if (text.isEmpty) return;

    final rawAmountCents = tryParseMoneyToCents(text);
    if (rawAmountCents == null) return;

    final settings = AppSettingsScope.read(context);
    final roundedCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    // Expenses are negative
    final finalAmountCents = -roundedCents;

    final pulse = PulseEntry(
      id: newEntryId(),
      label: widget.envelope.label,
      amountMinorUnits: finalAmountCents,
      date: DateTime.now(),
      type: PulseType.spendingEnvelope,
      timelineItemId: widget.envelope.id,
      category: widget.envelope.category,
      origin: _originController.text.trim().isNotEmpty
          ? _originController.text.trim()
          : widget.envelope.origin,
      moneyPotId: widget.envelope.moneyPotId,
    );

    widget.store.upsertPulse(pulse);
    if (!settings.balanceUpdatesDisabled) {
      settings.currentBalanceCents += pulse.amountMinorUnits;
    }

    if (mounted) {
      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Spent ${formatMoney(roundedCents, settings.currency, showDecimals: settings.showCents)} from ${widget.envelope.label}',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);

    return AlertDialog(
      title: Text('Spend from ${widget.envelope.label}'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _amountController,
              focusNode: _focusNode,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: UpsertTimelineItemStyle.compactInput(
                context,
                'Amount',
                hintText: '0.00',
              ).copyWith(
                prefixText: '- ',
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 12,
                ),
              ),
              inputFormatters: [
                if (settings.showCents)
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                else
                  FilteringTextInputFormatter.digitsOnly,
              ],
              textInputAction: TextInputAction.next,
              onSubmitted: (_) => _originFocusNode.requestFocus(),
            ),
            const SizedBox(height: 16),
            RawAutocomplete<String>(
              textEditingController: _originController,
              focusNode: _originFocusNode,
              optionsBuilder: (TextEditingValue textEditingValue) {
                final suggestions = widget.envelope.suggestedOrigins ?? [];
                if (suggestions.isEmpty) {
                  return const Iterable<String>.empty();
                }
                if (textEditingValue.text.isEmpty) {
                  return suggestions;
                }
                return suggestions.where((option) {
                  return option.toLowerCase().contains(
                        textEditingValue.text.toLowerCase(),
                      );
                });
              },
              onSelected: (String selection) {
                _originController.text = selection;
              },
              fieldViewBuilder:
                  (context, controller, focusNode, onFieldSubmitted) {
                return CompositedTransformTarget(
                  link: _originLayerLink,
                  child: TextField(
                    controller: controller,
                    focusNode: focusNode,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface,
                      fontSize: 14,
                    ),
                    decoration: UpsertTimelineItemStyle.compactInput(
                      context,
                      'Origin (Optional)',
                      hintText: 'e.g., Starbucks',
                    ).copyWith(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 12,
                      ),
                    ),
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _submit(),
                  ),
                );
              },
              optionsViewBuilder: (context, onSelected, options) {
                return CompositedTransformFollower(
                  link: _originLayerLink,
                  showWhenUnlinked: false,
                  offset: const Offset(0, 48),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      elevation: 8.0,
                      borderRadius: BorderRadius.circular(8),
                      color: Theme.of(context).colorScheme.surfaceContainerHigh,
                      child: Container(
                        width: 240,
                        constraints: const BoxConstraints(maxHeight: 200),
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          shrinkWrap: true,
                          itemCount: options.length,
                          itemBuilder: (BuildContext context, int index) {
                            final option = options.elementAt(index);
                            return InkWell(
                              onTap: () => onSelected(option),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                child: Text(
                                  option,
                                  style: TextStyle(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onSurface,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(onPressed: _submit, child: const Text('Spend')),
      ],
    );
  }
}
