import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/settings/currency_service.dart';

class CurrenciesScreen extends StatefulWidget {
  const CurrenciesScreen({super.key});

  @override
  State<CurrenciesScreen> createState() => _CurrenciesScreenState();
}

class _CurrenciesScreenState extends State<CurrenciesScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  bool _isSyncing = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _syncRates() async {
    final settings = AppSettingsScope.read(context);
    final service = CurrencyService();

    setState(() => _isSyncing = true);

    try {
      final rates = await service.fetchLatestRates(
        base: settings.currency,
        symbols: settings.enabledCurrencies.toList(),
      );
      settings.updateAllExchangeRates(rates);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Exchange rates updated successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to sync rates: $e')));
      }
    } finally {
      if (mounted) setState(() => _isSyncing = false);
    }
  }

  void _showRateDialog(AppCurrency currency, double currentRate) {
    final info = getCurrencyInfo(currency);
    final baseInfo = getCurrencyInfo(AppSettingsScope.read(context).currency);
    final controller = TextEditingController(
      text: currentRate.toStringAsFixed(4),
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Rate for ${info.code}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('1 ${info.code} = X ${baseInfo.code}'),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: InputDecoration(
                labelText: 'Exchange Rate',
                suffixText: baseInfo.code,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final rate = double.tryParse(controller.text);
              if (rate != null && rate > 0) {
                AppSettingsScope.read(context).setExchangeRate(currency, rate);
              }
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;

    final filteredCurrencies = AppCurrency.values.where((c) {
      final info = getCurrencyInfo(c);
      final query = _searchQuery.toLowerCase();
      return info.code.toLowerCase().contains(query) ||
          info.symbol.toLowerCase().contains(query);
    }).toList();

    // Sort: Enabled first, then alphabetically
    filteredCurrencies.sort((a, b) {
      final aEnabled = settings.enabledCurrencies.contains(a);
      final bEnabled = settings.enabledCurrencies.contains(b);
      if (aEnabled && !bEnabled) return -1;
      if (!aEnabled && bEnabled) return 1;
      return getCurrencyInfo(a).code.compareTo(getCurrencyInfo(b).code);
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Currencies & Rates'),
        actions: [
          if (_isSyncing)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            )
          else
            IconButton(
              icon: const Icon(Icons.sync),
              tooltip: 'Sync with Frankfurter API',
              onPressed: _syncRates,
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search currencies (e.g. USD, €)',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
              onChanged: (value) => setState(() => _searchQuery = value),
            ),
          ),
          SwitchListTile(
            title: const Text('Auto-update Major Rates'),
            subtitle: const Text(
              'Fetch latest rates from Frankfurter API on sync',
            ),
            value: settings.autoUpdateRates,
            onChanged: (v) => settings.autoUpdateRates = v,
          ),
          const Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: filteredCurrencies.length,
              itemBuilder: (context, index) {
                final currency = filteredCurrencies[index];
                final info = getCurrencyInfo(currency);
                final isEnabled = settings.enabledCurrencies.contains(currency);
                final isBase = currency == settings.currency;
                final rate = settings.exchangeRates[currency] ?? 1.0;

                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isEnabled
                        ? colorScheme.primaryContainer
                        : colorScheme.surfaceContainerHighest,
                    child: Text(
                      info.symbol,
                      style: TextStyle(
                        color: isEnabled
                            ? colorScheme.onPrimaryContainer
                            : colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                  title: Row(
                    children: [
                      Text(
                        info.code,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if (isBase)
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: colorScheme.secondaryContainer,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            'BASE',
                            style: TextStyle(
                              fontSize: 10,
                              color: colorScheme.onSecondaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                  subtitle: Text(
                    isEnabled ? 'Rate: ${rate.toStringAsFixed(4)}' : 'Disabled',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (isEnabled && !isBase)
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 20),
                          onPressed: () => _showRateDialog(currency, rate),
                        ),
                      Switch(
                        value: isEnabled,
                        onChanged: isBase
                            ? null
                            : (v) {
                                if (v) {
                                  settings.enableCurrency(currency);
                                } else {
                                  settings.disableCurrency(currency);
                                }
                              },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
