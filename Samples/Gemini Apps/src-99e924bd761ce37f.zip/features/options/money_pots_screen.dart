import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_money_pot_sheet.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

/// Safe Tooltip widget that avoids ticker lifecycle issues
class SafeTooltip extends StatelessWidget {
  const SafeTooltip({super.key, required this.message, required this.child});

  final String message;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    // Don't wrap in Tooltip if message is empty
    if (message.isEmpty) {
      return child;
    }
    return Tooltip(message: message, child: child);
  }
}

class MoneyPotsScreen extends StatelessWidget {
  const MoneyPotsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.of(context);
    final store = ExpenseStoreScope.of(context);
    final pots = settings.moneyPotsSettings.moneyPots;
    final accounts = store.accounts;

    return Scaffold(
      appBar: AppBar(
        title: Text('Manage ${Terminology.of(context).potsLabel}'),
      ),
      body: pots.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    PhosphorIcons.wallet(),
                    size: 64,
                    color: Theme.of(
                      context,
                    ).colorScheme.outline.withValues(alpha: 0.5),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No ${Terminology.of(context).potsLabel.toLowerCase()} yet',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Theme.of(context).colorScheme.outline,
                        ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: () => _editPot(context, null),
                    icon: const Icon(Icons.add),
                    label: Text('Create ${Terminology.of(context).potLabel}'),
                  ),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: pots.length,
              separatorBuilder: (context, index) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final pot = pots[index];
                return _MoneyPotTile(
                  pot: pot,
                  accounts: accounts,
                  onEdit: () => _editPot(context, pot),
                );
              },
            ),
      floatingActionButton: pots.isNotEmpty
          ? FloatingActionButton(
              onPressed: () => _editPot(context, null),
              child: const Icon(Icons.add),
            )
          : null,
    );
  }

  Future<void> _editPot(BuildContext context, MoneyPot? pot) async {
    final settings = AppSettingsScope.read(context);
    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => UpsertMoneyPotSheet(initialPot: pot),
    );

    if (!context.mounted) return;

    if (result is MoneyPot) {
      if (pot == null) {
        settings.addMoneyPot(result);
      } else {
        settings.updateMoneyPot(result);
      }
    } else if (result is DeletePotMarker && pot != null) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Delete ${Terminology.of(context).potLabel}?'),
          content: Text('Are you sure you want to delete "${pot.name}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('Delete'),
            ),
          ],
        ),
      );
      if (confirmed == true) {
        settings.removeMoneyPot(pot.id);
      }
    }
  }
}

class _MoneyPotTile extends StatelessWidget {
  const _MoneyPotTile({
    required this.pot,
    required this.accounts,
    required this.onEdit,
  });

  final MoneyPot pot;
  final List<Account> accounts;
  final VoidCallback onEdit;

  String _getDisplayAmount(BuildContext context, AppSettingsStore settings) {
    var amount = pot.amountMinorUnits;
    var currency = pot.currency ?? settings.currency;

    if (pot.showInAppCurrency &&
        pot.currency != null &&
        pot.currency != settings.currency) {
      if (pot.exchangeRate != null && pot.exchangeRate! > 0) {
        amount = (amount / pot.exchangeRate!).round();
        currency = settings.currency;
      }
    }

    return formatMoney(amount, currency);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final settings = AppSettingsScope.of(context);

    final isDebt = pot.type == MoneyPotType.debt;
    final isSystemManaged = pot.isSystemManaged;

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: colorScheme.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: (pot.type == MoneyPotType.savings
                            ? colorScheme.primaryContainer
                            : colorScheme.errorContainer)
                        .withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    pot.type == MoneyPotType.savings
                        ? PhosphorIcons.trendUp()
                        : PhosphorIcons.trendDown(),
                    size: 20,
                    color: pot.type == MoneyPotType.savings
                        ? colorScheme.onPrimaryContainer
                        : colorScheme.onErrorContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        pot.name,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _getDisplayAmount(context, settings),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                if (isSystemManaged)
                  SafeTooltip(
                    message: 'Managed by linked debt item',
                    child: Icon(
                      Icons.edit_off_outlined,
                      color: colorScheme.outline.withValues(alpha: 0.5),
                    ),
                  )
                else
                  IconButton(
                    onPressed: onEdit,
                    icon: const Icon(Icons.edit_outlined),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            // Hide visibility section for debt pots (always account-specific)
            if (!isDebt) ...[
              const SizedBox(height: 16),
              const Divider(height: 1),
              const SizedBox(height: 12),
              Text(
                'Visibility',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              _AccountSelector(pot: pot, accounts: accounts),
            ],
          ],
        ),
      ),
    );
  }
}

class _AccountSelector extends StatelessWidget {
  const _AccountSelector({required this.pot, required this.accounts});

  final MoneyPot pot;
  final List<Account> accounts;

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        FilterChip(
          label: const Text('Global'),
          selected: pot.accountIds == null || pot.accountIds!.isEmpty,
          onSelected: pot.type == MoneyPotType.debt
              ? null
              : (selected) {
                  if (selected) {
                    settings.updateMoneyPot(
                      pot.copyWith(accountIds: const Optional(null)),
                    );
                  } else if (accounts.isNotEmpty) {
                    // If unselecting global, default to current account or first account
                    final currentAccount = ExpenseStoreScope.read(
                      context,
                    ).currentAccount;
                    settings.updateMoneyPot(
                      pot.copyWith(accountIds: Optional([currentAccount.id])),
                    );
                  }
                },
        ),
        ...accounts.map((account) {
          final isSelected = pot.accountIds?.contains(account.id) ?? false;
          return FilterChip(
            label: Text(account.name),
            selected: isSelected,
            onSelected: (selected) {
              List<AccountId> newIds = List.from(pot.accountIds ?? []);
              if (selected) {
                if (!newIds.contains(account.id)) {
                  newIds.add(account.id);
                }
              } else {
                newIds.remove(account.id);
              }

              // If no accounts selected, it becomes global (or we can force at least one?)
              // Per logic, empty = global.
              settings.updateMoneyPot(
                pot.copyWith(
                  accountIds: Optional(newIds.isEmpty ? null : newIds),
                ),
              );
            },
          );
        }),
      ],
    );
  }
}
