import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/config/version_info.dart';
import 'package:expense_stalker_mobile/src/features/export/export_screen.dart';
import 'package:expense_stalker_mobile/src/features/export/export_service.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/settings/onboarding_settings.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/features/debug/diagnostic_dashboard_screen.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';
import 'package:expense_stalker_mobile/src/features/options/categories_screen.dart';
import 'package:expense_stalker_mobile/src/features/options/currencies_screen.dart';
import 'package:expense_stalker_mobile/src/features/options/money_pots_screen.dart';
import 'package:expense_stalker_mobile/src/features/options/notification_settings_screen.dart';
import 'package:expense_stalker_mobile/src/features/insights/insight_settings_screen.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

class OptionsScreen extends StatefulWidget {
  const OptionsScreen({super.key, this.authService});

  final AuthService? authService;

  @override
  State<OptionsScreen> createState() => _OptionsScreenState();
}

class _OptionsScreenState extends State<OptionsScreen> {
  late final AuthService _authService;
  bool _authReady = false;
  bool _authEnabled = false;
  bool _biometricsEnabled = false;
  bool _biometricsAvailable = false;
  bool _hasPin = false;
  int _delayBeforeAuthSeconds = 0;
  bool _preventScreenshots = false;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String? _activeSectionTitle;
  AccountId? _selectedAccountId;
  late final TextEditingController _customPulseController;
  late final TextEditingController _customTimelineController;

  @override
  void initState() {
    super.initState();
    _authService = widget.authService ?? AuthService();
    _loadAuthSettings();
    // Initialize selected account after first frame when store is available
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        final store = ExpenseStoreScope.read(context);
        setState(() {
          _selectedAccountId = store.currentAccount.id;
          final settings = AppSettingsScope.read(context);
          _customPulseController = TextEditingController(
            text: settings.customPulseLabel,
          );
          _customTimelineController = TextEditingController(
            text: settings.customTimelineLabel,
          );
        });
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _customPulseController.dispose();
    _customTimelineController.dispose();
    super.dispose();
  }

  Future<void> _loadAuthSettings() async {
    await _authService.initialize();
    final authEnabled = await _authService.isAuthEnabled();
    final biometricsAvailable = await _authService.isBiometricAvailable();
    final biometricsEnabled = await _authService.useBiometrics();
    bool hasPin = false;
    try {
      hasPin = await _authService.hasPIN();
    } catch (_) {
      // Secure storage not available: treat as no PIN configured
      hasPin = false;
    }
    final delayBeforeAuthSeconds =
        await _authService.getDelayBeforeAuthSeconds();
    final preventScreenshots = await _authService.preventScreenshots();
    if (!mounted) return;
    setState(() {
      _authReady = true;
      _authEnabled = authEnabled;
      _biometricsAvailable = biometricsAvailable;
      _biometricsEnabled = biometricsEnabled;
      _hasPin = hasPin;
      _delayBeforeAuthSeconds = delayBeforeAuthSeconds;
      _preventScreenshots = preventScreenshots;
    });
  }

  Future<void> _showLinkOrphansDialog(BuildContext context) async {
    final store = ExpenseStoreScope.read(context);
    final messenger = ScaffoldMessenger.of(context);
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.of(context);
    final pulses = store.pulses;
    final timelineItems = store.timelineItems;

    // Find all orphaned pulses (no timelineItemId)
    final orphans = pulses.where((p) => p.timelineItemId == null).toList();

    if (orphans.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('No orphaned transactions found.')),
      );
      return;
    }

    // Sort orphans by date (newest first)
    orphans.sort((a, b) => b.date.compareTo(a.date));

    // Track selections: orphan index -> selected TimelineItem (null = skip/delete)
    final selections = <int, TimelineItem?>{};

    // Pre-populate with best guesses using label similarity
    for (var i = 0; i < orphans.length; i++) {
      final orphan = orphans[i];
      TimelineItem? bestMatch;
      int bestScore = 0;

      for (final item in timelineItems) {
        int score = 0;
        if (_labelsAreSimilar(orphan.label, item.label)) {
          score += 20;
        }
        if (item.amountMinorUnits == orphan.amountMinorUnits) {
          score += 10;
        }
        if (score > bestScore) {
          bestScore = score;
          bestMatch = item;
        }
      }
      // Only pre-select if we have a good match (label similarity)
      if (bestScore >= 20) {
        selections[i] = bestMatch;
      }
    }

    if (!mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text('Link ${orphans.length} Orphaned Transactions'),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Select which scheduled item to link each orphan to:',
                ),
                const SizedBox(height: 8),
                Text(
                  '(Leave empty to delete the orphan)',
                  style: Theme.of(ctx).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: orphans.length,
                    itemBuilder: (_, i) {
                      final orphan = orphans[i];
                      final dateStr =
                          '${orphan.date.day}/${orphan.date.month}/${orphan.date.year}';
                      final amount = formatMoneyFromCents(
                        orphan.amountMinorUnits,
                        settings.currency,
                      );

                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                orphan.label.isEmpty
                                    ? '(Untitled)'
                                    : orphan.label,
                                style: Theme.of(ctx).textTheme.titleSmall,
                              ),
                              Text(
                                '$amount • $dateStr',
                                style: Theme.of(ctx).textTheme.bodySmall,
                              ),
                              const SizedBox(height: 8),
                              DropdownButtonFormField<TimelineItem?>(
                                isExpanded: true,
                                decoration: const InputDecoration(
                                  labelText: 'Link to...',
                                  border: OutlineInputBorder(),
                                  contentPadding: EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 8,
                                  ),
                                ),
                                initialValue: selections[i],
                                items: [
                                  const DropdownMenuItem<TimelineItem?>(
                                    value: null,
                                    child: Text(
                                      '(Don\'t link / Delete)',
                                      style: TextStyle(
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ),
                                  ...timelineItems.map(
                                    (item) => DropdownMenuItem<TimelineItem?>(
                                      value: item,
                                      child: Text(
                                        '${item.label} (${formatMoneyFromCents(item.amountMinorUnits, settings.currency)})',
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                                onChanged: (val) {
                                  setDialogState(() => selections[i] = val);
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(l10n?.cancel ?? 'Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Apply Changes'),
            ),
          ],
        ),
      ),
    );

    if (confirmed == true) {
      int linkedCount = 0;
      int deletedCount = 0;

      for (var i = 0; i < orphans.length; i++) {
        final orphan = orphans[i];
        final targetItem = selections[i];

        if (targetItem != null) {
          // Link the orphan to the selected item
          store.upsertPulse(
            orphan.copyWith(
              timelineItemId: targetItem.id,
              category: targetItem.category,
              subcategory: targetItem.subcategory,
            ),
          );
          linkedCount++;
        } else if (selections.containsKey(i)) {
          // Explicitly set to null = delete the orphan
          store.deletePulse(orphan.id);
          deletedCount++;
        }
        // If not in selections at all, leave unchanged
      }

      if (mounted) {
        final messages = <String>[];
        if (linkedCount > 0) messages.add('Linked $linkedCount');
        if (deletedCount > 0) messages.add('Deleted $deletedCount');
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              messages.isEmpty ? 'No changes made.' : messages.join(', '),
            ),
          ),
        );
      }
    }
  }

  /// Check if two labels are similar enough to be potential duplicates.
  /// Handles cases like "Trainmore Gym Membership" vs "Gym Membership (Trainmore)"
  bool _labelsAreSimilar(String a, String b) {
    // Normalize: lowercase, remove punctuation, split into words
    Set<String> normalize(String s) {
      return s
          .toLowerCase()
          .replaceAll(RegExp(r'[^\w\s]'), ' ')
          .split(RegExp(r'\s+'))
          .where((w) => w.length > 2) // Ignore short words
          .toSet();
    }

    final wordsA = normalize(a);
    final wordsB = normalize(b);

    if (wordsA.isEmpty || wordsB.isEmpty) return false;

    // Check how many words overlap
    final intersection = wordsA.intersection(wordsB);
    final smaller =
        wordsA.length < wordsB.length ? wordsA.length : wordsB.length;

    // Consider similar if at least 50% of words from smaller set match
    return intersection.length >= (smaller * 0.5).ceil();
  }

  Future<void> _showFindDuplicatesDialog(BuildContext context) async {
    final store = ExpenseStoreScope.read(context);
    final messenger = ScaffoldMessenger.of(context);
    final timelineItems = store.activeTimelineItems;
    final pulses = store.pulses;

    // Group by amount
    final byAmount = <int, List<TimelineItem>>{};
    for (final item in timelineItems) {
      byAmount.putIfAbsent(item.amountMinorUnits, () => []).add(item);
    }

    // Find duplicate groups (same amount + similar labels)
    final duplicateGroups = <List<TimelineItem>>[];
    for (final group in byAmount.values.where((g) => g.length >= 2)) {
      // Check each pair for label similarity
      for (var i = 0; i < group.length; i++) {
        for (var j = i + 1; j < group.length; j++) {
          if (_labelsAreSimilar(group[i].label, group[j].label)) {
            duplicateGroups.add([group[i], group[j]]);
          }
        }
      }
    }

    if (!mounted) return;

    if (duplicateGroups.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('No duplicate items found.')),
      );
      return;
    }

    // Track which item to keep for each group
    final selections = <int, TimelineItem>{};
    for (var i = 0; i < duplicateGroups.length; i++) {
      selections[i] = duplicateGroups[i][0]; // Default to first
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Merge Duplicates?'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Found ${duplicateGroups.length} potential duplicate(s).'),
                const SizedBox(height: 8),
                const Text('Select which item to KEEP for each pair:'),
                const SizedBox(height: 12),
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: duplicateGroups.length,
                    itemBuilder: (_, i) {
                      final group = duplicateGroups[i];
                      final amount = formatMoneyFromCents(
                        group[0].amountMinorUnits,
                        AppSettingsScope.of(context).currency,
                      );
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: RadioGroup<TimelineItem>(
                            groupValue: selections[i],
                            onChanged: (val) {
                              if (val != null) {
                                setDialogState(() => selections[i] = val);
                              }
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Amount: $amount',
                                  style: Theme.of(ctx).textTheme.labelMedium,
                                ),
                                const SizedBox(height: 4),
                                ...group.map(
                                  (item) => ListTile(
                                    dense: true,
                                    contentPadding: EdgeInsets.zero,
                                    leading: Radio<TimelineItem>(value: item),
                                    title: Text(item.label),
                                    subtitle: Text('Day ${item.dayOfMonth}'),
                                    onTap: () => setDialogState(
                                      () => selections[i] = item,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(AppLocalizations.of(context)?.cancel ?? 'Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Merge All'),
            ),
          ],
        ),
      ),
    );

    if (confirmed == true) {
      int mergedCount = 0;
      for (var i = 0; i < duplicateGroups.length; i++) {
        final group = duplicateGroups[i];
        final keep = selections[i];
        if (keep == null) continue;

        for (final item in group) {
          if (item.id == keep.id) continue; // Skip the kept item

          // Reassign all pulses from duplicate to kept item
          final itemPulses = pulses.where((p) => p.timelineItemId == item.id);
          for (final pulse in itemPulses) {
            store.upsertPulse(
              pulse.copyWith(
                timelineItemId: keep.id,
                category: keep.category,
                subcategory: keep.subcategory,
              ),
            );
          }

          // Archive the duplicate item
          store.setTimelineItemArchived(item.id, true);
          mergedCount++;
        }
      }

      if (mounted) {
        messenger.showSnackBar(
          SnackBar(content: Text('Merged $mergedCount duplicate items.')),
        );
      }
    }
  }

  Future<void> _showRemoveHistoricalTransactionsDialog(
    BuildContext context,
  ) async {
    final store = ExpenseStoreScope.read(context);
    final messenger = ScaffoldMessenger.of(context);
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.of(context);

    // Find the earliest transaction date
    DateTime startDate;
    if (store.pulses.isNotEmpty) {
      startDate = store.pulses.fold<DateTime>(
        store.pulses.first.date,
        (earliest, p) => p.date.isBefore(earliest) ? p.date : earliest,
      );
    } else {
      // Fallback to first day of last month
      startDate = DateTime(DateTime.now().year, DateTime.now().month - 1, 1);
    }
    DateTime endDate = DateTime.now();
    PulseSource? selectedSource;
    String searchQuery = '';

    if (!mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          // Filter pulses based on current criteria
          final filteredPulses = store.pulses.where((p) {
            final matchesDate =
                !p.date.isBefore(startDate) && !p.date.isAfter(endDate);
            final matchesSource =
                selectedSource == null || p.source == selectedSource;
            final matchesSearch = searchQuery.isEmpty ||
                p.label.toLowerCase().contains(searchQuery.toLowerCase()) ||
                (p.rawImportDescription?.toLowerCase().contains(
                          searchQuery.toLowerCase(),
                        ) ??
                    false);

            return matchesDate && matchesSource && matchesSearch;
          }).toList();

          final totalAmount = filteredPulses.fold(
            0,
            (sum, p) => sum + p.amountMinorUnits,
          );
          final amountFormatted = formatMoneyFromCents(
            totalAmount.abs(),
            settings.currency,
          );
          final amountColor = totalAmount > 0
              ? Colors.green
              : (totalAmount < 0 ? Colors.red : null);

          return AlertDialog(
            title: const Text('Remove Historical Transactions'),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Select criteria for removal:'),
                    const SizedBox(height: 16),
                    // Date Range
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Date Range'),
                      subtitle: Text(
                        '${startDate.day}/${startDate.month}/${startDate.year} - ${endDate.day}/${endDate.month}/${endDate.year}',
                      ),
                      trailing: const Icon(Icons.date_range),
                      onTap: () async {
                        final picked = await showDateRangePicker(
                          context: ctx,
                          initialDateRange: DateTimeRange(
                            start: startDate,
                            end: endDate,
                          ),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (picked != null) {
                          setDialogState(() {
                            startDate = picked.start;
                            endDate = picked.end;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    // Source Filter
                    DropdownButtonFormField<PulseSource?>(
                      initialValue: selectedSource,
                      decoration: const InputDecoration(
                        labelText: 'Source (Optional)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: null,
                          child: Text('All Sources'),
                        ),
                        ...PulseSource.values.map(
                          (s) =>
                              DropdownMenuItem(value: s, child: Text(s.name)),
                        ),
                      ],
                      onChanged: (val) =>
                          setDialogState(() => selectedSource = val),
                    ),
                    const SizedBox(height: 16),
                    // Search Filter
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Search Label/Description (Optional)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                      ),
                      onChanged: (val) =>
                          setDialogState(() => searchQuery = val),
                    ),
                    const SizedBox(height: 24),
                    // Summary
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Theme.of(
                          ctx,
                        ).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Transactions Found:'),
                              Text(
                                '${filteredPulses.length}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total Net Amount:'),
                              Text(
                                amountFormatted,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: amountColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(l10n?.cancel ?? 'Cancel'),
              ),
              FilledButton(
                onPressed: filteredPulses.isEmpty
                    ? null
                    : () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(ctx).colorScheme.error,
                  foregroundColor: Theme.of(ctx).colorScheme.onError,
                ),
                child: const Text('Remove Transactions'),
              ),
            ],
          );
        },
      ),
    );

    if (confirmed == true) {
      // Re-calculate to be safe
      final pulsesToDelete = store.pulses.where((p) {
        final matchesDate =
            !p.date.isBefore(startDate) && !p.date.isAfter(endDate);
        final matchesSource =
            selectedSource == null || p.source == selectedSource;
        final matchesSearch = searchQuery.isEmpty ||
            p.label.toLowerCase().contains(searchQuery.toLowerCase()) ||
            (p.rawImportDescription?.toLowerCase().contains(
                      searchQuery.toLowerCase(),
                    ) ??
                false);

        return matchesDate && matchesSource && matchesSearch;
      }).toList();

      if (pulsesToDelete.isEmpty) return;

      store.transaction((transaction) {
        for (final pulse in pulsesToDelete) {
          transaction.deletePulse(pulse.id);
        }
        transaction.commit();
      });

      if (mounted) {
        messenger.showSnackBar(
          SnackBar(
            content: Text('Removed ${pulsesToDelete.length} transactions.'),
          ),
        );
      }
    }
  }

  Future<void> _exportDebugBundle(BuildContext context) async {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 24),
            Text('Exporting debug bundle...'),
          ],
        ),
      ),
    );

    try {
      final snapshot = store.createSnapshot();
      await ExportService.instance.exportDebugBundle(
        snapshot,
        settings,
        accountName: store.currentAccount.name,
      );

      if (mounted) {
        navigator.pop(); // Dismiss loading dialog
        messenger.showSnackBar(
          const SnackBar(content: Text('Debug bundle exported successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        navigator.pop(); // Dismiss loading dialog
        if (e is! ExportCancelledException) {
          messenger.showSnackBar(SnackBar(content: Text('Export failed: $e')));
        }
      }
    }
  }

  Future<void> _setAuthEnabled(BuildContext context, bool enabled) async {
    if (!_authReady) return;
    final l10n = AppLocalizations.of(context);
    final messenger = ScaffoldMessenger.of(context);

    if (enabled && !_hasPin) {
      // Enabling auth requires setting up a PIN first
      final didSet = await _showPinSetupDialog(
        context,
        title: l10n?.setSecurityPIN ?? 'Set Security PIN',
      );
      if (!didSet) return;
    } else if (!enabled && _hasPin) {
      // Disabling auth requires verifying the current PIN first
      final verified = await _showPinVerifyDialog(context);
      if (!verified) return;
    }

    await _authService.setAuthEnabled(enabled);
    if (!mounted) return;
    // If disabling authentication, the AuthService will remove the PIN.
    // Update local state to reflect the immediate removal so the UI updates
    // (disable PIN edit button, biometric toggles, etc.).
    if (!enabled) {
      bool hasPinNow = false;
      try {
        hasPinNow = await _authService.hasPIN();
      } catch (_) {
        hasPinNow = false;
      }
      setState(() {
        _authEnabled = enabled;
        _hasPin = hasPinNow;
      });
    } else {
      setState(() => _authEnabled = enabled);
    }
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          enabled
              ? (l10n?.authEnabled ?? 'Authentication Enabled')
              : (l10n?.authDisabled ?? 'Authentication Disabled'),
        ),
        duration: AppConstants.snackBarShort,
      ),
    );

    // If we disabled authentication and the PIN was removed, show confirmation
    if (!enabled && !_hasPin) {
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(l10n?.pinRemoved ?? 'PIN Removed'),
          duration: AppConstants.snackBarShort,
        ),
      );
    }
  }

  Future<void> _setBiometricsEnabled(bool enabled) async {
    await _authService.setUseBiometrics(enabled);
    if (!mounted) return;
    setState(() => _biometricsEnabled = enabled);
  }

  Future<void> _setDelayBeforeAuthSeconds(int seconds) async {
    await _authService.setDelayBeforeAuthSeconds(seconds);
    if (!mounted) return;
    setState(() => _delayBeforeAuthSeconds = seconds);
  }

  Future<void> _setPreventScreenshots(
    BuildContext context,
    bool enabled,
  ) async {
    if (!_authReady) return;
    final l10n = AppLocalizations.of(context);
    final messenger = ScaffoldMessenger.of(context);

    // Require authentication to be enabled and a PIN to be set before enabling screenshot protection
    if (!_authEnabled || !_hasPin) {
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(
            l10n?.pinRequiredForScreenshotProtection ??
                'PIN required for screenshot protection',
          ),
          duration: AppConstants.snackBarNormal,
        ),
      );
      return;
    }

    // Always require authentication to change this security setting
    // Try biometrics first
    var authenticated = await _authService.authenticateWithBiometrics(
      reason: l10n?.authenticateToChangeScreenshotSetting ??
          'Authenticate to change screenshot setting',
    );

    // Fall back to PIN if biometrics failed/unavailable
    if (!authenticated) {
      if (!mounted) return;
      // ignore: use_build_context_synchronously
      authenticated = await _showPinVerifyDialog(context);
    }

    if (!authenticated) return;
    if (!mounted) return;

    await _authService.setPreventScreenshots(enabled);
    if (!mounted) return;
    setState(() => _preventScreenshots = enabled);

    // Notify the app to update the screenshot flag
    _ScreenshotProtectionNotifier.instance.notify(enabled);

    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          enabled
              ? (l10n?.screenshotProtectionEnabled ??
                  'Screenshot protection enabled')
              : (l10n?.screenshotProtectionDisabled ??
                  'Screenshot protection disabled'),
        ),
        duration: AppConstants.snackBarShort,
      ),
    );
  }

  Future<void> _changePin(BuildContext context) async {
    final l10n = AppLocalizations.of(context);
    if (!_hasPin) {
      await _showPinSetupDialog(
        context,
        title: l10n?.setSecurityPIN ?? 'Set Security PIN',
      );
      return;
    }

    final verified = await _showPinVerifyDialog(context);
    if (!verified) return;
    if (!mounted) return;
    await _showPinSetupDialog(
      // ignore: use_build_context_synchronously
      context,
      title: l10n?.changeSecurityPIN ?? 'Change Security PIN',
    );
  }

  Future<bool> _showPinSetupDialog(
    BuildContext context, {
    required String title,
  }) async {
    final l10n = AppLocalizations.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) =>
          _PinSetupDialog(title: title, authService: _authService),
    );
    if (result == true && mounted) {
      final newHasPin = await _authService.hasPIN();
      setState(() => _hasPin = newHasPin);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(l10n?.pinChanged ?? 'PIN Changed'),
          duration: AppConstants.snackBarShort,
        ),
      );
      return true;
    }
    return false;
  }

  Future<bool> _showPinVerifyDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => _PinVerifyDialog(authService: _authService),
    );
    return result ?? false;
  }

  String _secondsLabel(AppLocalizations? l10n, int seconds) {
    if (seconds == 0) return l10n?.off ?? 'Off';
    if (seconds >= 60) {
      final minutes = seconds ~/ 60;
      return minutes == 1 ? '1 min' : '$minutes min';
    }
    if (seconds == 1) return '1 sec';
    return '$seconds sec';
  }

  Future<void> _showQuickAmountsEditDialog(BuildContext context) async {
    final settings = AppSettingsScope.read(context);
    final currentAmounts = settings.customQuickAddAmounts;
    final l10n = AppLocalizations.of(context);

    // Controllers
    final controllers = currentAmounts.map((amount) {
      // Amount is in cents/minor units. format for display.
      // We'll format as whole number for editing if possible, or decimal if needed.
      // But typically these are round numbers.
      // Let's us formatMoney but remove symbol and separators for editing if simpler,
      // OR just parse double.
      final amountMajor =
          amount / 100.0; // Assuming cents for simplicity in edit
      // Remove trailing .0
      final text = amountMajor == amountMajor.truncateToDouble()
          ? amountMajor.truncate().toString()
          : amountMajor.toString();
      return TextEditingController(text: text);
    }).toList();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(Terminology.of(context).budgetQuickSpendLabel),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(Terminology.of(context).budgetQuickSpendSubtitle),
            const SizedBox(height: 16),
            ...List.generate(controllers.length, (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: TextField(
                  controller: controllers[index],
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Amount ${index + 1}',
                    border: const OutlineInputBorder(),
                  ),
                ),
              );
            }),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final newAmounts = <int>[];
              for (final controller in controllers) {
                final text = controller.text.trim();
                // Simple parsing logic matching our standard standard
                // We multiply by 100 effectively by parsing as double then *100
                // This matches how we loaded it: amount / 100.0
                final val = double.tryParse(text);
                if (val != null) {
                  newAmounts.add((val * 100).round());
                } else {
                  // Fallback to existing if invalid? Or 0?
                  newAmounts.add(currentAmounts[newAmounts.length]);
                }
              }

              settings.customQuickAddAmounts = newAmounts;
              Navigator.pop(ctx);
            },
            child: Text(l10n?.save ?? 'Save'),
          ),
        ],
      ),
    );

    for (final c in controllers) {
      c.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.of(context);

    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        final palette = _OptionsPalette.of(context);
        final l10n = AppLocalizations.of(context);
        final t = Terminology.of(context);
        final delayOptions = <int>{
          0,
          5,
          15,
          30,
          60,
          120, // 2 min
          300, // 5 min
          600, // 10 min
          _delayBeforeAuthSeconds,
        }.toList()
          ..sort();

        final sections = [
          _SearchableSection(
            title: l10n?.appearance ?? 'Appearance',
            icon: PhosphorIcons.palette(),
            options: [
              _SearchableOption(
                keywords: [
                  l10n?.textSize ?? 'Text Size',
                  l10n?.textSizeSubtitle ?? 'Adjust app font scale',
                  l10n?.textSizeSmall ?? 'Small',
                  l10n?.textSizeDefault ?? 'Default',
                  l10n?.textSizeLarge ?? 'Large',
                  l10n?.textSizeExtraLarge ?? 'Extra Large',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.textT(),
                  title: l10n?.textSize ?? 'Text Size',
                  subtitle: l10n?.textSizeSubtitle ?? 'Adjust app font scale',
                  trailing: _OptionsDropdown<TextScalePreset>(
                    value: settings.textScalePreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.textScalePreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: TextScalePreset.small,
                        child: Text(l10n?.textSizeSmall ?? 'Small'),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.normal,
                        child: Text(l10n?.textSizeDefault ?? 'Default'),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.large,
                        child: Text(l10n?.textSizeLarge ?? 'Large'),
                      ),
                      DropdownMenuItem(
                        value: TextScalePreset.extraLarge,
                        child: Text(l10n?.textSizeExtraLarge ?? 'Extra Large'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.fontFamily ?? 'Font Family',
                  l10n?.fontFamilySubtitle ?? 'Choose a custom font',
                  l10n?.system ?? 'System',
                  l10n?.fontMonospace ?? 'Monospace',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.textAa(),
                  title: l10n?.fontFamily ?? 'Font Family',
                  subtitle: l10n?.fontFamilySubtitle ?? 'Choose a custom font',
                  trailing: _OptionsDropdown<FontPreset>(
                    value: settings.fontPreset,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.fontPreset = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: FontPreset.system,
                        child: Text(l10n?.system ?? 'System'),
                      ),
                      DropdownMenuItem(
                        value: FontPreset.monospace,
                        child: Text(l10n?.fontMonospace ?? 'Monospace'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.appTheme ?? 'App Theme',
                  l10n?.appThemeSubtitle ?? 'Customize app appearance',
                  l10n?.appThemeClassic ?? 'Classic',
                  l10n?.appThemeOcean ?? 'Ocean',
                  l10n?.appThemeSunset ?? 'Sunset',
                  l10n?.appThemeMonochrome ?? 'Monochrome',
                  l10n?.appThemeForest ?? 'Forest',
                ],
                widget: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Text(
                        l10n?.appTheme ?? 'App Theme',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    ),
                    VisualColorSelector<AppThemePreset>(
                      value: settings.appThemePreset,
                      items: AppThemePreset.values,
                      onChanged: (v) => settings.appThemePreset = v,
                      colorsBuilder: (preset) {
                        final palette = ThemeSettings.getPalette(preset);
                        return [palette.primary, palette.background];
                      },
                    ),
                  ],
                ),
              ),
              _SearchableOption(
                keywords: ['randomize', 'theme', 'resume', 'color'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.arrowsClockwise(),
                  title: 'Randomize on Resume',
                  subtitle: 'Change theme when app is resumed',
                  trailing: Switch(
                    value: settings.randomizeColorOnResume,
                    onChanged: (v) => settings.randomizeColorOnResume = v,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['randomize', 'theme', 'swipe', 'period', 'color'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.selectionBackground(),
                  title: 'Randomize on Swipe',
                  subtitle: 'Change theme when swiping between periods',
                  trailing: Switch(
                    value: settings.randomizeColorOnPeriodChange,
                    onChanged: (v) => settings.randomizeColorOnPeriodChange = v,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'custom colors',
                  'enable colors',
                  'tweak colors',
                  'manual colors',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.swatches(),
                  title: 'Use Custom Colors',
                  subtitle: 'Enable manual control over transaction colors',
                  trailing: Switch(
                    value: settings.useCustomColors,
                    onChanged: (v) => settings.useCustomColors = v,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              if (settings.useCustomColors) ...[
                _SearchableOption(
                  keywords: [l10n?.debitColor ?? 'Debit Color'],
                  widget: _OptionsTile(
                    icon: PhosphorIcons.minusCircle(),
                    iconColor: settings.debitColor,
                    title: l10n?.debitColor ?? 'Debit Color',
                    trailing: _ColorSwatch(
                      color: settings.debitColor,
                      onTap: () => _showColorPicker(
                        context,
                        settings.debitColor,
                        (color) => settings.debitColor = color,
                        l10n?.debitColor ?? 'Debit Color',
                      ),
                    ),
                  ),
                ),
                _SearchableOption(
                  keywords: [l10n?.creditColor ?? 'Credit Color'],
                  widget: _OptionsTile(
                    icon: PhosphorIcons.plusCircle(),
                    iconColor: settings.creditColor,
                    title: l10n?.creditColor ?? 'Credit Color',
                    trailing: _ColorSwatch(
                      color: settings.creditColor,
                      onTap: () => _showColorPicker(
                        context,
                        settings.creditColor,
                        (color) => settings.creditColor = color,
                        l10n?.creditColor ?? 'Credit Color',
                      ),
                    ),
                  ),
                ),
                _SearchableOption(
                  keywords: [l10n?.neutralColor ?? 'Neutral Color'],
                  widget: _OptionsTile(
                    icon: PhosphorIcons.circle(),
                    iconColor: settings.neutralColor,
                    title: l10n?.neutralColor ?? 'Neutral Color',
                    trailing: _ColorSwatch(
                      color: settings.neutralColor,
                      onTap: () => _showColorPicker(
                        context,
                        settings.neutralColor,
                        (color) => settings.neutralColor = color,
                        l10n?.neutralColor ?? 'Neutral Color',
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
          _SearchableSection(
            title: l10n?.security ?? 'Security',
            icon: PhosphorIcons.lockSimple(),
            options: [
              _SearchableOption(
                keywords: [
                  l10n?.requireAuthentication ?? 'Require Authentication',
                  l10n?.requireAuthenticationSubtitle ??
                      'Authenticate to open the app',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.shield(),
                  title:
                      l10n?.requireAuthentication ?? 'Require Authentication',
                  subtitle: l10n?.requireAuthenticationSubtitle ??
                      'Authenticate to open the app',
                  trailing: Switch(
                    value: _authEnabled,
                    onChanged: _authReady
                        ? (value) => _setAuthEnabled(context, value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.biometricAuthentication ?? 'Biometric Authentication',
                  l10n?.pinRequiredForBiometrics ??
                      'PIN required to enable biometrics',
                  l10n?.biometricAuthenticationSubtitle ??
                      'Unlock with FaceID/Fingerprint',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.fingerprint(),
                  title: l10n?.biometricAuthentication ??
                      'Biometric Authentication',
                  subtitle: !_hasPin
                      ? (l10n?.pinRequiredForBiometrics ??
                          'PIN required to enable biometrics')
                      : (l10n?.biometricAuthenticationSubtitle ??
                          'Unlock with FaceID/Fingerprint'),
                  trailing: Switch(
                    // Biometrics requires: auth ready, auth enabled, biometrics available, AND a PIN set as fallback
                    value: _biometricsEnabled && _hasPin,
                    onChanged: _authReady &&
                            _authEnabled &&
                            _biometricsAvailable &&
                            _hasPin
                        ? (value) => _setBiometricsEnabled(value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.pin ?? 'PIN',
                  l10n?.changeSecurityPIN ?? 'Change Security PIN',
                  l10n?.setSecurityPIN ?? 'Set Security PIN',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.key(),
                  title: _hasPin
                      ? (l10n?.changeSecurityPIN ?? 'Change Security PIN')
                      : (l10n?.setSecurityPIN ?? 'Set Security PIN'),
                  trailing: FilledButton(
                    // Only allow editing/setting PIN when authentication is enabled
                    onPressed: _authReady && _authEnabled
                        ? () => _changePin(context)
                        : null,
                    child: Text(l10n?.edit ?? 'Edit'),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.authDelayBeforePrompt ?? 'Authentication Delay',
                  l10n?.authDelayBeforePromptSubtitle ??
                      'Waiting time before prompting again',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.timer(),
                  title: l10n?.authDelayBeforePrompt ?? 'Authentication Delay',
                  subtitle: l10n?.authDelayBeforePromptSubtitle ??
                      'Waiting time before prompting again',
                  trailing: _OptionsDropdown<int>(
                    value: _delayBeforeAuthSeconds,
                    onChanged: !_authReady || !_authEnabled
                        ? null
                        : (value) {
                            if (value == null) return;
                            _setDelayBeforeAuthSeconds(value);
                          },
                    items: delayOptions
                        .map(
                          (value) => DropdownMenuItem(
                            value: value,
                            child: Text(_secondsLabel(l10n, value)),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.preventScreenshots ?? 'Prevent Screenshots',
                  l10n?.preventScreenshotsSubtitle ??
                      'Hide app content in app switcher',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.screencast(),
                  title: l10n?.preventScreenshots ?? 'Prevent Screenshots',
                  subtitle: l10n?.preventScreenshotsSubtitle ??
                      'Hide app content in app switcher',
                  trailing: Switch(
                    value: _preventScreenshots,
                    onChanged: _authReady
                        ? (value) => _setPreventScreenshots(context, value)
                        : null,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: 'Insights',
            icon: PhosphorIcons.lightbulb(),
            options: [
              _SearchableOption(
                keywords: ['insights', 'smart', 'behavioral', 'organic'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.magicWand(),
                  title: 'Configure Insights',
                  subtitle: 'Manage dismissed insights and preferences',
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const InsightSettingsScreen(),
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'notifications',
                  'alerts',
                  'daily',
                  'weekly',
                  'reminders',
                  'push',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.bell(),
                  title: 'Notifications',
                  subtitle:
                      store.currentAccount.settings.notificationsEnabled == true
                          ? 'Enabled'
                          : 'Off',
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const NotificationSettingsScreen(),
                    ),
                  ),
                ),
              ),
            ],
          ),
          // Account Settings section with account picker
          _SearchableSection(
            title: 'Account Settings',
            icon: PhosphorIcons.userCircle(),
            options: [
              _SearchableOption(
                keywords: [
                  'Account',
                  'Select Account',
                  'Switch Account Settings',
                ],
                widget: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Edit settings for:',
                        style: Theme.of(context)
                            .textTheme
                            .labelMedium
                            ?.copyWith(color: palette.textSecondary),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 300),
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              color: palette.surfaceAlt,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: palette.border),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 4,
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<AccountId>(
                                  value: _selectedAccountId,
                                  isExpanded: true,
                                  icon: PhosphorIcon(
                                    PhosphorIcons.caretDown(),
                                    color: palette.textSecondary,
                                  ),
                                  dropdownColor: palette.surface,
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(color: palette.textPrimary),
                                  onChanged: (AccountId? newId) {
                                    if (newId != null) {
                                      setState(() {
                                        _selectedAccountId = newId;
                                      });
                                    }
                                  },
                                  items: store.accounts.map((account) {
                                    final isCurrent =
                                        account.id == store.currentAccount.id;
                                    return DropdownMenuItem<AccountId>(
                                      value: account.id,
                                      child: Row(
                                        children: [
                                          Expanded(child: Text(account.name)),
                                          if (isCurrent)
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                horizontal: 6,
                                                vertical: 2,
                                              ),
                                              decoration: BoxDecoration(
                                                color: palette.theme.withValues(
                                                  alpha: 0.2,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                'ACTIVE',
                                                style: TextStyle(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                  color: palette.theme,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // --- Account Details (Not Synced) ---
              _SearchableOption(
                keywords: [],
                widget: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
                  child: Text(
                    'ACCOUNT DETAILS',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.theme,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ),

              _SearchableOption(
                keywords: ['View Period', 'Calendar', 'Paycheck Period'],
                widget: Builder(
                  builder: (context) {
                    final selectedAccount = _selectedAccountId != null
                        ? store.getAccountById(_selectedAccountId!)
                        : null;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _OptionsTile(
                          icon: PhosphorIcons.calendarCheck(),
                          title: 'View Period',
                          subtitle: selectedAccount?.viewPeriodMode ==
                                  ViewPeriodMode.paycheck
                              ? 'Paycheck Period'
                              : 'Calendar Month',
                          trailing: _OptionsDropdown<ViewPeriodMode>(
                            value: selectedAccount?.viewPeriodMode ??
                                ViewPeriodMode.calendar,
                            onChanged: (ViewPeriodMode? mode) {
                              if (_selectedAccountId == null || mode == null) {
                                return;
                              }
                              store.updateAccountSettings(
                                _selectedAccountId!,
                                viewPeriodMode: mode,
                              );
                            },
                            items: const [
                              DropdownMenuItem<ViewPeriodMode>(
                                value: ViewPeriodMode.calendar,
                                child: Text('Calendar'),
                              ),
                              DropdownMenuItem<ViewPeriodMode>(
                                value: ViewPeriodMode.paycheck,
                                child: Text('Paycheck'),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          child: Text(
                            'Choose "Calendar" for standard monthly budgeting (1st to 31st). Choose "Paycheck" to align your budget months with your salary schedule.',
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              if (_selectedAccountId != null &&
                  store.getAccountById(_selectedAccountId!)?.viewPeriodMode ==
                      ViewPeriodMode.paycheck) ...[
                _SearchableOption(
                  keywords: ['Payday', 'Paycheck Day', 'Salary Day'],
                  widget: Builder(
                    builder: (context) {
                      final selectedAccount = _selectedAccountId != null
                          ? store.getAccountById(_selectedAccountId!)
                          : null;
                      return _OptionsTile(
                        icon: PhosphorIcons.calendar(),
                        title: 'Payday',
                        subtitle: selectedAccount?.paycheckDay != null
                            ? 'Day ${selectedAccount!.paycheckDay}'
                            : 'Not set',
                        trailing: _OptionsDropdown<int?>(
                          value: selectedAccount?.paycheckDay,
                          onChanged: (int? day) {
                            if (_selectedAccountId == null) return;
                            store.updateAccountSettings(
                              _selectedAccountId!,
                              paycheckDay: day,
                              clearPaycheckDay: day == null,
                            );
                          },
                          items: [
                            const DropdownMenuItem<int?>(
                              value: null,
                              child: Text('Not set'),
                            ),
                            ...List.generate(28, (i) => i + 1).map(
                              (day) => DropdownMenuItem<int?>(
                                value: day,
                                child: Text('$day'),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                _SearchableOption(
                  keywords: ['Business Day Adjust', 'Weekend', 'Paycheck'],
                  widget: Builder(
                    builder: (context) {
                      final selectedAccount = _selectedAccountId != null
                          ? store.getAccountById(_selectedAccountId!)
                          : null;
                      return _OptionsTile(
                        icon: PhosphorIcons.briefcase(),
                        title: 'Business Day Adjust',
                        subtitle:
                            selectedAccount?.paycheckBusinessAdjust == true
                                ? 'Adjust if payday falls on weekend'
                                : 'Off',
                        trailing: Switch(
                          value:
                              selectedAccount?.paycheckBusinessAdjust ?? false,
                          onChanged: (bool value) {
                            if (_selectedAccountId == null) return;
                            store.updateAccountSettings(
                              _selectedAccountId!,
                              paycheckBusinessAdjust: value,
                            );
                          },
                          activeTrackColor: palette.theme,
                        ),
                      );
                    },
                  ),
                ),
                _SearchableOption(
                  keywords: ['Adjust Direction', 'Before', 'After', 'Paycheck'],
                  widget: Builder(
                    builder: (context) {
                      final selectedAccount = _selectedAccountId != null
                          ? store.getAccountById(_selectedAccountId!)
                          : null;
                      final isBusinessAdjustEnabled =
                          selectedAccount?.paycheckBusinessAdjust ?? false;
                      return _OptionsTile(
                        icon: Icons.swap_horiz,
                        title: 'Adjust Direction',
                        subtitle: !isBusinessAdjustEnabled
                            ? 'Enable Business Day Adjust first'
                            : selectedAccount
                                        ?.paycheckBusinessAdjustDirection ==
                                    PaycheckAdjustDirection.before
                                ? 'Pay before weekend'
                                : 'Pay after weekend',
                        trailing: _OptionsDropdown<PaycheckAdjustDirection>(
                          value: selectedAccount
                                  ?.paycheckBusinessAdjustDirection ??
                              PaycheckAdjustDirection.before,
                          onChanged: !isBusinessAdjustEnabled
                              ? null
                              : (PaycheckAdjustDirection? dir) {
                                  if (_selectedAccountId == null || dir == null) {
                                    return;
                                  }
                                  store.updateAccountSettings(
                                    _selectedAccountId!,
                                    paycheckBusinessAdjustDirection: dir,
                                  );
                                },
                          items: const [
                            DropdownMenuItem<PaycheckAdjustDirection>(
                              value: PaycheckAdjustDirection.before,
                              child: Text('Before'),
                            ),
                            DropdownMenuItem<PaycheckAdjustDirection>(
                              value: PaycheckAdjustDirection.after,
                              child: Text('After'),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],

              // --- Synced Account Settings ---
              _SearchableOption(
                keywords: [],
                widget: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
                  child: Text(
                    'SHARED PLANNER SETTINGS',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.theme,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Sync',
                  'Settings',
                  'Across Accounts',
                  'Apply to all',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.arrowsClockwise(),
                  title: l10n?.syncSettingsAcrossAccounts ??
                      'Sync Settings Across Accounts',
                  subtitle: l10n?.syncSettingsAcrossAccountsSubtitle ??
                      'Apply settings to all accounts',
                  trailing: Switch(
                    value: settings.syncSettingsAcrossAccounts,
                    onChanged: (value) =>
                        settings.syncSettingsAcrossAccounts = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),

              _SearchableOption(
                keywords: [
                  'Timeline View',
                  'Month',
                  'Grid',
                  'Sheet',
                  'Default View',
                ],
                widget: Builder(
                  builder: (context) {
                    final selectedAccount = _selectedAccountId != null
                        ? store.getAccountById(_selectedAccountId!)
                        : null;
                    String subtitle;
                    String description;
                    switch (selectedAccount?.timelineViewMode) {
                      case TimelineViewMode.grid:
                        subtitle = 'Multi-month Grid';
                        description = 'See multiple months at a glance';
                        break;
                      case TimelineViewMode.sheet:
                        subtitle = 'Spreadsheet';
                        description = 'Horizontal scrollable timeline';
                        break;
                      default:
                        subtitle = 'Single Month';
                        description = 'Focus on one month at a time';
                    }
                    return _OptionsTile(
                      icon: PhosphorIcons.squaresFour(),
                      title: 'Default Timeline View',
                      subtitle: '$subtitle — $description',
                      trailing: _OptionsDropdown<TimelineViewMode>(
                        value: selectedAccount?.timelineViewMode ??
                            TimelineViewMode.month,
                        onChanged: (TimelineViewMode? mode) {
                          if (_selectedAccountId == null || mode == null) {
                            return;
                          }
                          store.updateAccountSettings(
                            _selectedAccountId!,
                            timelineViewMode: mode,
                            syncToAll: settings.syncSettingsAcrossAccounts,
                          );
                        },
                        items: const [
                          DropdownMenuItem<TimelineViewMode>(
                            value: TimelineViewMode.month,
                            child: Text('Month'),
                          ),
                          DropdownMenuItem<TimelineViewMode>(
                            value: TimelineViewMode.grid,
                            child: Text('Grid'),
                          ),
                          DropdownMenuItem<TimelineViewMode>(
                            value: TimelineViewMode.sheet,
                            child: Text('Sheet'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Future Balance',
                  'Zero Baseline',
                  'Projected',
                  'Starting Balance',
                ],
                widget: Builder(
                  builder: (context) {
                    final selectedAccount = _selectedAccountId != null
                        ? store.getAccountById(_selectedAccountId!)
                        : null;
                    final useZero =
                        selectedAccount?.timelineUseZeroBaseline ?? false;
                    final zeroFormatted = formatMoney(
                      0,
                      settings.currency,
                      showDecimals: false,
                    );

                    return _OptionsTile(
                      icon: PhosphorIcons.chartLineUp(),
                      title: 'Future Month Balance',
                      subtitle: useZero
                          ? 'Start from zero ($zeroFormatted)'
                          : 'Use projected balance',
                      trailing: _OptionsDropdown<bool>(
                        value: useZero,
                        onChanged: (bool? val) {
                          if (_selectedAccountId == null || val == null) return;
                          store.updateAccountSettings(
                            _selectedAccountId!,
                            timelineUseZeroBaseline: val,
                            syncToAll: settings.syncSettingsAcrossAccounts,
                          );
                        },
                        items: [
                          const DropdownMenuItem<bool>(
                            value: false,
                            child: Text('Projected'),
                          ),
                          DropdownMenuItem<bool>(
                            value: true,
                            child: Text('Zero ($zeroFormatted)'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              _SearchableOption(
                keywords: ['Auto-update Balance', 'Account Balance', 'Sync'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.arrowsClockwise(),
                  title: 'Auto-update Balance',
                  subtitle:
                      'Allow actions like archiving to automatically change your account balance',
                  trailing: Switch(
                    value: !settings.balanceUpdatesDisabled,
                    onChanged: (value) =>
                        settings.balanceUpdatesDisabled = !value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),

              _SearchableOption(
                keywords: [
                  l10n?.categories ?? 'Categories',
                  'Manage Categories',
                  'Custom',
                  'Default',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.tag(),
                  title: 'Manage Categories',
                  subtitle: 'Add or edit custom expense and income types',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const CategoriesScreen(),
                      ),
                    );
                  },
                  trailing: PhosphorIcon(
                    PhosphorIcons.caretRight(),
                    color: palette.textSecondary,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.timeline ?? 'Timeline',
                  l10n?.dayAsNumber ?? 'Day Number',
                  l10n?.dayAsOrdinal ?? 'Day Ordinal',
                  'date format',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.calendar(),
                  title: 'Date Format',
                  trailing: _OptionsDropdown<DayFormat>(
                    value: settings.dayFormat,
                    onChanged: (v) {
                      if (v != null) settings.dayFormat = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: DayFormat.number,
                        child: Text(l10n?.dayAsNumber ?? 'Day Number'),
                      ),
                      DropdownMenuItem(
                        value: DayFormat.ordinal,
                        child: Text(l10n?.dayAsOrdinal ?? 'Day Ordinal'),
                      ),
                      const DropdownMenuItem(
                        value: DayFormat.ordinalMonth,
                        child: Text('21st Jan'),
                      ),
                      const DropdownMenuItem(
                        value: DayFormat.numericMonthDay,
                        child: Text('01/21'),
                      ),
                      const DropdownMenuItem(
                        value: DayFormat.numericDayMonth,
                        child: Text('21/01'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.categoryPresetTitle ?? 'Category Presets',
                  l10n?.categoryPresetDefault ?? 'Default',
                  l10n?.categoryPresetCustom ?? 'Custom Only',
                  l10n?.categoryPresetBoth ?? 'Both',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.squaresFour(),
                  title: l10n?.categoryPresetTitle ?? 'Category Presets',
                  trailing: _OptionsDropdown<CategoryPresetMode>(
                    value: settings.categoryPresetMode,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.categoryPresetMode = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: CategoryPresetMode.defaultPresets,
                        child: Text(l10n?.categoryPresetDefault ?? 'Default'),
                      ),
                      DropdownMenuItem(
                        value: CategoryPresetMode.customOnly,
                        child: Text(
                          l10n?.categoryPresetCustom ?? 'Custom Only',
                        ),
                      ),
                      DropdownMenuItem(
                        value: CategoryPresetMode.both,
                        child: Text(l10n?.categoryPresetBoth ?? 'Both'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.groupByDate ?? 'Group by Date',
                  l10n?.groupByDateSubtitle ?? 'Group items by due date',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.rows(),
                  title: l10n?.groupByDate ?? 'Group by Date',
                  subtitle:
                      l10n?.groupByDateSubtitle ?? 'Group items by due date',
                  trailing: Switch(
                    value: settings.timelineGroupByDate,
                    onChanged: (value) => settings.timelineGroupByDate = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.groupByTheme ?? 'Group by Theme',
                  l10n?.groupByThemeSubtitle ?? 'Group items by theme color',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.paintBrush(),
                  title: l10n?.groupByTheme ?? 'Group by Theme',
                  subtitle: l10n?.groupByThemeSubtitle ??
                      'Group items by theme color',
                  trailing: Switch(
                    value: settings.timelineGroupByTheme,
                    onChanged: (value) => settings.timelineGroupByTheme = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [],
                widget: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
                  child: Text(
                    'VIEW-SPECIFIC SETTINGS',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.theme,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ),

              // Month View Subsection
              const _SearchableOption(
                keywords: ['Month View', 'Single month', 'Month Mode'],
                widget: _OptionsTile(
                  icon: Icons.calendar_view_month,
                  title: 'Month View',
                  subtitle: 'Single month card settings',
                ),
              ),
              _SearchableOption(
                keywords: ['Month View', 'Display mode'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: 'Display Mode',
                    trailing: _OptionsDropdown<MonthCardDisplayMode>(
                      value: settings.monthCardDisplayMode,
                      onChanged: (v) =>
                          v != null ? settings.monthCardDisplayMode = v : null,
                      items: const [
                        DropdownMenuItem(
                          value: MonthCardDisplayMode.full,
                          child: Text('Full Name'),
                        ),
                        DropdownMenuItem(
                          value: MonthCardDisplayMode.acronym,
                          child: Text('Acronym'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Month View', 'Origin'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: l10n?.showPulseOrigin ?? 'Show Origin',
                    trailing: Switch(
                      value: settings.getTimelineShowPulseOrigin(
                        TimelineViewMode.month,
                      ),
                      onChanged: (v) => settings.setTimelineShowPulseOrigin(
                        TimelineViewMode.month,
                        v,
                      ),
                      activeTrackColor: palette.theme,
                    ),
                  ),
                ),
              ),

              // Grid View Subsection
              _SearchableOption(
                keywords: ['Grid View', 'Multi-month grid'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.squaresFour(),
                  title: 'Grid View',
                  subtitle: 'Multi-month grid settings',
                ),
              ),
              _SearchableOption(
                keywords: ['Grid View', 'Display mode'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: 'Display Mode',
                    trailing: _OptionsDropdown<MultiMonthDisplayMode>(
                      value: settings.getMultiMonthDisplayMode(
                        TimelineViewMode.grid,
                      ),
                      onChanged: (v) => v != null
                          ? settings.setMultiMonthDisplayMode(
                              TimelineViewMode.grid,
                              v,
                            )
                          : null,
                      items: const [
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.automatic,
                          child: Text('Automatic'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.full,
                          child: Text('Full Name'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.acronym,
                          child: Text('Acronym'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.icon,
                          child: Text('Icon'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Grid View', 'Origin'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: l10n?.showPulseOrigin ?? 'Show Origin',
                    trailing: Switch(
                      value: settings.getTimelineShowPulseOrigin(
                        TimelineViewMode.grid,
                      ),
                      onChanged: (v) => settings.setTimelineShowPulseOrigin(
                        TimelineViewMode.grid,
                        v,
                      ),
                      activeTrackColor: palette.theme,
                    ),
                  ),
                ),
              ),

              // Spreadsheet View Subsection
              _SearchableOption(
                keywords: ['Spreadsheet View', 'Sheet view', 'Timeline'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.table(),
                  title: 'Spreadsheet View',
                  subtitle: 'Horizontal scrollable timeline settings',
                ),
              ),
              _SearchableOption(
                keywords: ['Spreadsheet View', 'Display mode'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: 'Display Mode',
                    trailing: _OptionsDropdown<MultiMonthDisplayMode>(
                      value: settings.getMultiMonthDisplayMode(
                        TimelineViewMode.sheet,
                      ),
                      onChanged: (v) => v != null
                          ? settings.setMultiMonthDisplayMode(
                              TimelineViewMode.sheet,
                              v,
                            )
                          : null,
                      items: const [
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.automatic,
                          child: Text('Automatic'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.full,
                          child: Text('Full Name'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.acronym,
                          child: Text('Acronym'),
                        ),
                        DropdownMenuItem(
                          value: MultiMonthDisplayMode.icon,
                          child: Text('Icon'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Spreadsheet View', 'Origin'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: l10n?.showPulseOrigin ?? 'Show Origin',
                    trailing: Switch(
                      value: settings.getTimelineShowPulseOrigin(
                        TimelineViewMode.sheet,
                      ),
                      onChanged: (v) => settings.setTimelineShowPulseOrigin(
                        TimelineViewMode.sheet,
                        v,
                      ),
                      activeTrackColor: palette.theme,
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Balance Projection', 'Graph', 'Projection'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.chartLineUp(),
                  title: 'Balance Projection',
                  subtitle: 'Projection sheet settings',
                ),
              ),
              _SearchableOption(
                keywords: ['Balance Projection', 'Envelopes', 'Deduct'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: Terminology.of(context).deductBudgetsLabel,
                    subtitle: Terminology.of(context).deductBudgetsSubtitle,
                    trailing: Switch(
                      value: settings.balanceProjectionDeductEnvelopes,
                      onChanged: (v) =>
                          settings.balanceProjectionDeductEnvelopes = v,
                      activeTrackColor: palette.theme,
                    ),
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Balance Projection', 'Delta', 'Net Change'],
                widget: Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _OptionsTile(
                    title: 'Show Delta',
                    subtitle: 'Default state for showing net change',
                    trailing: Switch(
                      value: settings.balanceProjectionShowDelta,
                      onChanged: (v) => settings.balanceProjectionShowDelta = v,
                      activeTrackColor: palette.theme,
                    ),
                  ),
                ),
              ),

              _SearchableOption(
                keywords: [
                  l10n?.monthTotalsDisplayTitle ?? 'Totals Display',
                  'Show ${t.itemStatusLabel} totals',
                  'Include ${t.itemStatusLabel} items',
                ],
                widget: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        l10n?.monthTotalsDisplayTitle ?? 'Totals Display',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 6),
                      CheckboxListTile(
                        value: settings.monthTotalsDisplayMode ==
                            MonthTotalsDisplayMode.showClearedRow,
                        onChanged: (value) {
                          settings.monthTotalsDisplayMode = value == true
                              ? MonthTotalsDisplayMode.showClearedRow
                              : MonthTotalsDisplayMode.includeCleared;
                        },
                        title: Text(
                          'Show ${t.itemStatusLabel.toLowerCase()} totals in a second row',
                        ),
                        subtitle: Text(
                          'Include ${t.itemStatusLabel.toLowerCase()} items in totals',
                        ),
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.timelineTapAction ?? 'Tap Action',
                  l10n?.timelineTapActionMenu ?? 'Show Menu',
                  l10n?.timelineTapActionArchive ?? 'Mark as Paid',
                  'Tap Action',
                  'Item Tap',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.handTap(),
                  title: 'Item Tap Action',
                  subtitle: settings.timelineTapAction == TimelineTapAction.menu
                      ? 'Show menu with options'
                      : 'Quick mark as paid',
                  onTap: () {
                    if (settings.timelineTapAction == TimelineTapAction.menu) {
                      settings.timelineTapAction = TimelineTapAction.archive;
                    } else {
                      settings.timelineTapAction = TimelineTapAction.menu;
                    }
                  },
                ),
              ),
              _SearchableOption(
                keywords: ['Quick Spending', 'Amounts', 'Spending Envelope'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.lightning(),
                  title: Terminology.of(context).budgetQuickSpendLabel,
                  subtitle: Terminology.of(context).budgetQuickSpendSubtitle,
                  onTap: () => _showQuickAmountsEditDialog(context),
                  trailing: PhosphorIcon(PhosphorIcons.caretRight()),
                ),
              ),
              _SearchableOption(
                keywords: [
                  l10n?.terminologyPreset ?? 'Terminology',
                  l10n?.terminologyPresetSubtitle ?? 'Customize app labels',
                  l10n?.terminologyDefault ?? 'Default',
                  l10n?.terminologyBills ?? 'Bills',
                  l10n?.terminologyBudget ?? 'Budget',
                  l10n?.terminologyCustom ?? 'Custom',
                ],
                widget: Column(
                  children: [
                    _OptionsTile(
                      icon: PhosphorIcons.tag(),
                      title: l10n?.terminologyPreset ?? 'Terminology',
                      subtitle: l10n?.terminologyPresetSubtitle ??
                          'Customize app labels',
                      trailing: _OptionsDropdown<TerminologyPreset>(
                        value: settings.terminologyPreset,
                        onChanged: (v) {
                          if (v == null) return;
                          settings.terminologyPreset = v;
                        },
                        items: [
                          DropdownMenuItem(
                            value: TerminologyPreset.defaultTerms,
                            child: Text(l10n?.terminologyDefault ?? 'Default'),
                          ),
                          DropdownMenuItem(
                            value: TerminologyPreset.bills,
                            child: Text(l10n?.terminologyBills ?? 'Bills'),
                          ),
                          DropdownMenuItem(
                            value: TerminologyPreset.budget,
                            child: Text(l10n?.terminologyBudget ?? 'Budget'),
                          ),
                          DropdownMenuItem(
                            value: TerminologyPreset.custom,
                            child: Text(l10n?.terminologyCustom ?? 'Custom'),
                          ),
                        ],
                      ),
                    ),
                    if (settings.terminologyPreset == TerminologyPreset.custom)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(64, 0, 16, 16),
                        child: Column(
                          children: [
                            TextField(
                              controller: _customPulseController,
                              decoration: InputDecoration(
                                labelText:
                                    l10n?.customPulseLabel ?? 'Pulse Label',
                                hintText: l10n?.customPulseLabelHint ??
                                    'e.g. Transaction',
                                border: const OutlineInputBorder(),
                              ),
                              onChanged: (v) => settings.customPulseLabel =
                                  v.trim().isEmpty ? null : v.trim(),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _customTimelineController,
                              decoration: InputDecoration(
                                labelText: l10n?.customActivityLabel ??
                                    'Activity Label',
                                hintText: l10n?.customActivityLabelHint ??
                                    'e.g. Pulse',
                                border: const OutlineInputBorder(),
                              ),
                              onChanged: (v) => settings.customTimelineLabel =
                                  v.trim().isEmpty ? null : v.trim(),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: l10n?.exportAndImportTitle ?? 'Backup & Restore',
            icon: PhosphorIcons.cloudArrowUp(),
            options: [
              _SearchableOption(
                keywords: [
                  l10n?.exportAndImportTitle ?? 'Backup & Restore',
                  l10n?.saveYourData ?? 'Export Data',
                  l10n?.restoreYourData ?? 'Import Data',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.arrowsDownUp(),
                  title: l10n?.exportAndImportTitle ?? 'Backup & Restore',
                  subtitle:
                      '${l10n?.saveYourData ?? 'Export'} ${l10n?.restoreYourData ?? 'Import'}',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const ExportScreen()),
                    );
                  },
                ),
              ),
            ],
          ),

          _SearchableSection(
            title: l10n?.currency ?? 'Currency',
            icon: PhosphorIcons.currencyCircleDollar(),
            options: [
              _SearchableOption(
                keywords: [
                  l10n?.displayCurrency ?? 'Display Currency',
                  l10n?.currency_eur ?? 'Euro (€)',
                  l10n?.currency_usd ?? 'US Dollar (\$)',
                  l10n?.currency_gbp ?? 'British Pound (£)',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.currencyCircleDollar(),
                  title: l10n?.displayCurrency ?? 'Display Currency',
                  trailing: _OptionsDropdown<AppCurrency>(
                    value: settings.currency,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.currency = v;
                    },
                    items: [
                      DropdownMenuItem(
                        value: AppCurrency.eur,
                        child: Text(l10n?.currency_eur ?? 'Euro (€)'),
                      ),
                      DropdownMenuItem(
                        value: AppCurrency.usd,
                        child: Text(l10n?.currency_usd ?? 'US Dollar (\$)'),
                      ),
                      DropdownMenuItem(
                        value: AppCurrency.gbp,
                        child: Text(l10n?.currency_gbp ?? 'British Pound (£)'),
                      ),
                    ],
                  ),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Currencies',
                  'Exchange Rates',
                  'Frankfurter',
                  'Manual',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.arrowsClockwise(),
                  title: 'Currencies & Rates',
                  subtitle: 'Configure enabled currencies and exchange rates',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const CurrenciesScreen(),
                      ),
                    );
                  },
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Show Cents', 'Display decimals in prices'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.moneyWavy(),
                  title: 'Show Cents',
                  subtitle: 'Display decimals in prices',
                  trailing: Switch(
                    value: settings.showCents,
                    onChanged: (value) => settings.showCents = value,
                    activeTrackColor: palette.theme,
                    inactiveThumbColor: palette.textSecondary,
                    inactiveTrackColor: palette.surfaceAlt,
                  ),
                ),
              ),
              _SearchableOption(
                keywords: ['Round Up To', 'Auto-round inputs up to nearest'],
                widget: _OptionsTile(
                  icon: Icons.functions,
                  title: 'Round Up To',
                  subtitle: 'Auto-round inputs up to nearest...',
                  trailing: _OptionsDropdown<int>(
                    value: settings.roundingIncrement,
                    onChanged: (v) {
                      if (v == null) return;
                      settings.roundingIncrement = v;
                    },
                    items: const [
                      DropdownMenuItem(value: 0, child: Text('None')),
                      DropdownMenuItem(value: 1, child: Text('Nearest 1')),
                      DropdownMenuItem(value: 5, child: Text('Nearest 5')),
                      DropdownMenuItem(value: 10, child: Text('Nearest 10')),
                      DropdownMenuItem(value: 50, child: Text('Nearest 50')),
                      DropdownMenuItem(value: 100, child: Text('Nearest 100')),
                    ],
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: l10n?.region ?? 'Region',
            icon: PhosphorIcons.globe(),
            options: [
              _SearchableOption(
                keywords: [
                  l10n?.regionPreset ?? 'Region Preset',
                  l10n?.regionPresetDescription ??
                      'Choose your localized settings',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.globe(),
                  title: l10n?.regionPreset ?? 'Region Preset',
                  subtitle: l10n?.regionPresetDescription ??
                      'Choose your localized settings',
                  trailing: _OptionsDropdown<String>(
                    value: settings.regionPresetId,
                    onChanged: (value) {
                      if (value == null) return;
                      settings.regionPresetId = value;
                    },
                    items: settings.regionPresets
                        .map(
                          (preset) => DropdownMenuItem(
                            value: preset.id,
                            child: Text(preset.label),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
            ],
          ),
          _SearchableSection(
            title: 'Money Pots',
            icon: PhosphorIcons.wallet(),
            options: [
              _SearchableOption(
                keywords: [
                  'Manage Money Pots',
                  'Money Pots',
                  'Savings',
                  'Debt',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.wallet(),
                  title: 'Manage Money Pots',
                  subtitle: 'Configure money pots and account assignments',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const MoneyPotsScreen(),
                      ),
                    );
                  },
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                ),
              ),
            ],
          ),

          _SearchableSection(
            title: 'About',
            icon: PhosphorIcons.info(),
            options: [
              _SearchableOption(
                keywords: ['About', 'Version', 'Build', 'Commit', 'Hash'],
                widget: FutureBuilder<PackageInfo>(
                  future: PackageInfo.fromPlatform(),
                  builder: (context, snapshot) {
                    final info = snapshot.data;
                    final fullAppVersion = VersionInfo.appVersion;
                    final versionParts = fullAppVersion.split('+');
                    final version = versionParts.isNotEmpty
                        ? versionParts[0]
                        : (info?.version ?? fullAppVersion);
                    final buildNumber = versionParts.length > 1
                        ? versionParts[1]
                        : (info?.buildNumber ?? '1');
                    const commitHash = VersionInfo.gitCommitHash;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _OptionsTile(
                          icon: PhosphorIcons.hash(),
                          title: 'Version',
                          subtitle: version,
                          trailing: Text(
                            '#$buildNumber',
                            style: Theme.of(context)
                                .textTheme
                                .labelMedium
                                ?.copyWith(color: palette.textSecondary),
                          ),
                        ),
                        _OptionsTile(
                          icon: PhosphorIcons.gitCommit(),
                          title: 'Commit Hash',
                          subtitle: commitHash,
                          onTap: () async {
                            final url = Uri.parse(
                              'https://github.com/jiadanni/expense-stalker/commit/$commitHash',
                            );
                            if (await canLaunchUrl(url)) {
                              await launchUrl(url);
                            }
                          },
                          trailing: PhosphorIcon(
                            PhosphorIcons.arrowSquareOut(),
                            size: 16,
                            color: palette.textSecondary,
                          ),
                        ),
                        _OptionsTile(
                          icon: PhosphorIcons.playCircle(),
                          title: l10n?.onboardingReplayTitle ??
                              'Replay Onboarding',
                          subtitle: l10n?.onboardingReplaySubtitle ??
                              'Watch the introductory tour again',
                          onTap: () async {
                            final confirmed = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: Text(
                                  l10n?.onboardingReplayTitle ??
                                      'Replay Onboarding',
                                ),
                                content: Text(
                                  l10n?.onboardingReplayConfirm ??
                                      'Are you sure you want to reset and replay the onboarding tour?',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx, false),
                                    child: Text(l10n?.cancel ?? 'Cancel'),
                                  ),
                                  FilledButton(
                                    onPressed: () => Navigator.pop(ctx, true),
                                    child: Text(
                                      l10n?.onboardingReplayAction ?? 'Replay',
                                    ),
                                  ),
                                ],
                              ),
                            );
                            if (confirmed == true && context.mounted) {
                              // Reset onboarding and close settings
                              final storage = await StorageProvider.create();
                              final onboarding =
                                  await OnboardingSettings.loadOrCreate(
                                storage,
                              );
                              await onboarding.reset();
                              if (context.mounted) {
                                Navigator.of(context).pop();
                                // Show snackbar to inform user to restart
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      l10n?.onboardingReplayRestart ??
                                          'Restart the app to begin the tour',
                                    ),
                                  ),
                                );
                              }
                            }
                          },
                          trailing: Icon(
                            Icons.chevron_right,
                            color: palette.textSecondary,
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),

          // Debug Section
          _SearchableSection(
            title: 'Debug',
            icon: PhosphorIcons.bug(),
            options: [
              _SearchableOption(
                keywords: ['Debug', 'Link', 'Orphans', 'Cleanup', 'Fix'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.link(),
                  title: 'Link Orphaned Transactions',
                  subtitle: 'Fix duplicates by linking orphans',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () => _showLinkOrphansDialog(context),
                ),
              ),
              _SearchableOption(
                keywords: ['Debug', 'Find', 'Duplicates', 'Merge', 'Cleanup'],
                widget: _OptionsTile(
                  icon: PhosphorIcons.copySimple(),
                  title: 'Find Duplicate Items',
                  subtitle: 'Find and merge duplicate scheduled entries',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () => _showFindDuplicatesDialog(context),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Debug',
                  'Remove',
                  'Transactions',
                  'Historical',
                  'Cleanup',
                  'Delete',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.trash(),
                  title: 'Remove Historical Transactions',
                  subtitle: 'Batch delete transactions by date range',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () => _showRemoveHistoricalTransactionsDialog(context),
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Debug',
                  'Logs',
                  'Errors',
                  'Diagnostics',
                  'Troubleshooting',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.chartBar(),
                  title: 'Diagnostic Dashboard',
                  subtitle: 'View event logs and error history',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const DiagnosticDashboardScreen(),
                      ),
                    );
                  },
                ),
              ),
              _SearchableOption(
                keywords: [
                  'Debug',
                  'Export',
                  'Bundle',
                  'AI',
                  'Support',
                  'Diagnostics',
                ],
                widget: _OptionsTile(
                  icon: PhosphorIcons.export(),
                  title: 'Export Debug Bundle',
                  subtitle: 'Export data, logs & settings for AI analysis',
                  trailing: Icon(
                    Icons.chevron_right,
                    color: palette.textSecondary,
                  ),
                  onTap: () => _exportDebugBundle(context),
                ),
              ),
            ],
          ),
        ];

        final isDesktop = MediaQuery.sizeOf(context).width >= 1024;
        String? effectiveSectionTitle = _activeSectionTitle;
        if (isDesktop && effectiveSectionTitle == null && _searchQuery.isEmpty && sections.isNotEmpty) {
          effectiveSectionTitle = sections.first.title;
        }

        _SearchableSection? activeSection;
        if (effectiveSectionTitle != null) {
          activeSection = sections.cast<_SearchableSection?>().firstWhere(
                (s) => s?.title == effectiveSectionTitle,
                orElse: () => null,
              );
        }

        Widget buildDesktopLayout() {
          final masterCategories = sections.map((section) {
            final isSelected = section.title == effectiveSectionTitle;
            return _OptionsTile(
              icon: section.icon,
              title: section.title,
              isSelected: isSelected,
              trailing: isSelected
                  ? PhosphorIcon(PhosphorIcons.caretRight(), color: palette.theme)
                  : null,
              onTap: () {
                _searchController.clear();
                setState(() {
                  _searchQuery = '';
                  _activeSectionTitle = section.title;
                });
              },
            );
          }).toList();

          final masterList = ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 16, 32),
            children: [
              _OptionsHeader(title: l10n?.optionsTitle ?? 'Options'),
              const SizedBox(height: 16),
              _SearchField(
                controller: _searchController,
                onChanged: (val) {
                  setState(() {
                    _searchQuery = val;
                    if (val.isNotEmpty) {
                      _activeSectionTitle = null;
                    }
                  });
                },
              ),
              const SizedBox(height: 16),
              _OptionsSection(
                title: 'Categories',
                icon: PhosphorIcons.listBullets(),
                padding: EdgeInsets.zero,
                child: Column(children: _withDividers(masterCategories, palette)),
              ),
            ],
          );

          Widget detailList;
          if (_searchQuery.isNotEmpty) {
            final searchFiltered = <Widget>[];
            for (final section in sections) {
              final visibleOptions = section.getVisibleOptions(_searchQuery);
              if (visibleOptions.isNotEmpty) {
                searchFiltered.add(
                  _OptionsSection(
                    title: section.title,
                    icon: section.icon,
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: _withDividers(
                        visibleOptions.map((o) => o.widget).toList(),
                        palette,
                      ),
                    ),
                  ),
                );
                searchFiltered.add(const SizedBox(height: 20));
              }
            }
            detailList = ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 20, 32),
              children: [
                const _OptionsHeader(title: 'Search Results'),
                const SizedBox(height: 16),
                ...searchFiltered,
              ],
            );
          } else if (activeSection != null) {
            detailList = ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 20, 32),
              children: [
                _OptionsHeader(title: activeSection.title),
                const SizedBox(height: 16),
                _OptionsSection(
                  title: activeSection.title,
                  icon: activeSection.icon,
                  padding: EdgeInsets.zero,
                  child: Column(
                    children: _withDividers(
                      activeSection.options.map((o) => o.widget).toList(),
                      palette,
                    ),
                  ),
                ),
              ],
            );
          } else {
            detailList = const SizedBox.shrink();
          }

          return Row(
            children: [
              SizedBox(width: 360, child: masterList),
              VerticalDivider(width: 1, thickness: 1, color: palette.border),
              Expanded(
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: detailList,
                  ),
                ),
              ),
            ],
          );
        }

        Widget buildMobileLayout() {
          final filtered = <Widget>[];

          if (activeSection != null && _searchQuery.isEmpty) {
            filtered.add(
              _OptionsSection(
                title: activeSection.title,
                icon: activeSection.icon,
                padding: EdgeInsets.zero,
                child: Column(
                  children: _withDividers(
                    activeSection.options.map((o) => o.widget).toList(),
                    palette,
                  ),
                ),
              ),
            );
          } else if (_searchQuery.isEmpty) {
            final categoryTiles = sections.map((section) {
              return _OptionsTile(
                icon: section.icon,
                title: section.title,
                trailing: PhosphorIcon(
                  PhosphorIcons.caretRight(),
                  color: palette.textSecondary,
                ),
                onTap: () {
                  _searchController.clear();
                  setState(() {
                    _searchQuery = '';
                    _activeSectionTitle = section.title;
                  });
                },
              );
            }).toList();

            filtered.add(
              _OptionsSection(
                title: 'Settings Categories',
                icon: PhosphorIcons.listBullets(),
                padding: EdgeInsets.zero,
                child: Column(children: _withDividers(categoryTiles, palette)),
              ),
            );
          } else {
            for (final section in sections) {
              final visibleOptions = section.getVisibleOptions(_searchQuery);
              if (visibleOptions.isNotEmpty) {
                filtered.add(
                  _OptionsSection(
                    title: section.title,
                    icon: section.icon,
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: _withDividers(
                        visibleOptions.map((o) => o.widget).toList(),
                        palette,
                      ),
                    ),
                  ),
                );
                filtered.add(const SizedBox(height: 20));
              }
            }
          }

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            children: [
              _OptionsHeader(
                title: (activeSection != null && _searchQuery.isEmpty)
                    ? activeSection.title
                    : (l10n?.optionsTitle ?? 'Options'),
              ),
              const SizedBox(height: 16),
              _SearchField(
                controller: _searchController,
                onChanged: (val) {
                  setState(() {
                    _searchQuery = val;
                    if (val.isNotEmpty) {
                      _activeSectionTitle = null; // Clear active section when searching
                    }
                  });
                },
              ),
              const SizedBox(height: 16),
              ...filtered,
            ],
          );
        }

        return PopScope(
          canPop: activeSection == null || _searchQuery.isNotEmpty || isDesktop,
          onPopInvokedWithResult: (didPop, result) {
            if (didPop) return;
            if (!isDesktop && activeSection != null && _searchQuery.isEmpty) {
              setState(() {
                _activeSectionTitle = null;
              });
            }
          },
          child: Scaffold(
            backgroundColor: palette.backgroundBottom,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: (!isDesktop && activeSection != null && _searchQuery.isEmpty)
                  ? BackButton(
                      // Go back to the settings root list, not close the screen.
                      onPressed: () =>
                          setState(() => _activeSectionTitle = null),
                    )
                  : const CloseButton(),
            ),
            body: Stack(
              children: [
                const _OptionsBackdrop(),
                SafeArea(
                  child: isDesktop
                      ? buildDesktopLayout()
                      : Center(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 720),
                            child: buildMobileLayout(),
                          ),
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

List<Widget> _withDividers(List<Widget> children, _OptionsPalette palette) {
  final output = <Widget>[];
  for (var i = 0; i < children.length; i++) {
    if (i > 0) {
      output.add(
        Divider(height: 1, thickness: 1, indent: 64, color: palette.border),
      );
    }
    output.add(children[i]);
  }
  return output;
}

class _OptionsBackdrop extends StatelessWidget {
  const _OptionsBackdrop();

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [palette.backgroundTop, palette.backgroundBottom],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -80,
              left: -40,
              child: _GlowOrb(color: palette.glowPrimary, size: 220),
            ),
            Positioned(
              top: 240,
              right: -30,
              child: _GlowOrb(color: palette.glowSecondary, size: 160),
            ),
            Positioned(
              bottom: -120,
              right: -60,
              child: _GlowOrb(color: palette.glowMuted, size: 260),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  const _GlowOrb({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
        ),
      ),
    );
  }
}

class _OptionsHeader extends StatelessWidget {
  const _OptionsHeader({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: textTheme.headlineSmall?.copyWith(
            color: palette.textPrimary,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.4,
          ),
        ),
        const SizedBox(height: 14),
        Container(
          width: 52,
          height: 4,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            gradient: LinearGradient(
              colors: [palette.theme, palette.themeSoft],
            ),
          ),
        ),
      ],
    );
  }
}

class _OptionsSection extends StatelessWidget {
  const _OptionsSection({
    required this.title,
    required this.icon,
    required this.child,
    this.padding = const EdgeInsets.symmetric(vertical: 6),
  });

  final String title;
  final IconData icon;
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [palette.surfaceAlt, palette.surface],
                ),
                border: Border.all(color: palette.border),
              ),
              child: Icon(icon, size: 16, color: palette.textSecondary),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: textTheme.titleSmall?.copyWith(
                color: palette.textSecondary,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        _OptionsSurface(padding: padding, child: child),
      ],
    );
  }
}

class _OptionsSurface extends StatelessWidget {
  const _OptionsSurface({
    required this.child,
    this.padding = const EdgeInsets.symmetric(vertical: 6),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppConstants.radiusSheetTop),
        border: Border.all(color: palette.border),
        gradient: LinearGradient(
          colors: [palette.surface, palette.surfaceAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: palette.shadow,
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

class _OptionsTile extends StatelessWidget {
  const _OptionsTile({
    required this.title,
    this.subtitle,
    this.trailing,
    this.icon,
    this.iconColor,
    this.onTap,
    this.isSelected = false,
  });

  final String title;
  final String? subtitle;
  final Widget? trailing;
  final IconData? icon;
  final Color? iconColor;
  final VoidCallback? onTap;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;

    final content = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Builder(
              builder: (context) {
                final iconData = icon;
                if (iconData == null) return const SizedBox.shrink();
                return _OptionsLeadingIcon(
                  icon: iconData,
                  color: isSelected ? palette.theme : iconColor,
                );
              },
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.titleSmall?.copyWith(
                    color: isSelected ? palette.theme : palette.textPrimary,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    subtitle!,
                    style: textTheme.bodySmall?.copyWith(
                      color: isSelected ? palette.themeSoft : palette.textSecondary,
                    ),
                  ),
                ],
              ],
            ),
          ),
          // ignore: use_null_aware_elements
          if (trailing != null) trailing!,
        ],
      ),
    );

    if (onTap == null && !isSelected) {
      return content;
    }

    return Material(
      color: isSelected ? palette.theme.withValues(alpha: 0.1) : Colors.transparent,
      borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
        onTap: onTap,
        hoverColor: palette.theme.withValues(alpha: 0.05),
        child: content,
      ),
    );
  }
}

class _OptionsLeadingIcon extends StatelessWidget {
  const _OptionsLeadingIcon({required this.icon, this.color});

  final IconData icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final iconColor = color ?? palette.textSecondary;

    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color?.withValues(alpha: 0.3) ?? palette.border,
        ),
        gradient: LinearGradient(
          colors: [
            color?.withValues(alpha: 0.15) ?? palette.surfaceAlt,
            color?.withValues(alpha: 0.05) ?? palette.surface,
          ],
        ),
      ),
      child: Icon(icon, size: 18, color: iconColor),
    );
  }
}

class _OptionsDropdown<T> extends StatelessWidget {
  const _OptionsDropdown({
    required this.value,
    required this.onChanged,
    required this.items,
  });

  final T value;
  final ValueChanged<T?>? onChanged;
  final List<DropdownMenuItem<T>> items;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return DecoratedBox(
      decoration: BoxDecoration(
        color: palette.surfaceAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: palette.border),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<T>(
            value: value,
            onChanged: onChanged,
            items: items,
            isDense: true,
            icon: Icon(PhosphorIcons.caretDown(), color: palette.textSecondary),
            dropdownColor: palette.surface,
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(color: palette.textPrimary),
          ),
        ),
      ),
    );
  }
}

class _PinSetupDialog extends StatefulWidget {
  const _PinSetupDialog({required this.title, required this.authService});

  final String title;
  final AuthService authService;

  @override
  State<_PinSetupDialog> createState() => _PinSetupDialogState();
}

class _PinSetupDialogState extends State<_PinSetupDialog> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmController = TextEditingController();
  String? _errorMessage;
  bool _isSaving = false;

  @override
  void dispose() {
    _pinController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_isSaving) return;
    final l10n = AppLocalizations.of(context);
    final pin = _pinController.text.trim();
    final confirm = _confirmController.text.trim();

    if (pin.length < AuthService.minPinLength) {
      setState(() => _errorMessage = l10n?.pinTooShort ?? 'PIN too short');
      return;
    }
    if (pin != confirm) {
      setState(
        () => _errorMessage = l10n?.pinsDoNotMatch ?? 'PINs do not match',
      );
      return;
    }

    setState(() {
      _isSaving = true;
      _errorMessage = null;
    });

    try {
      await widget.authService.setPIN(pin);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isSaving = false;
        _errorMessage = error is ArgumentError
            ? error.message.toString()
            : error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _pinController,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: AuthService.maxPinLength,
            decoration: InputDecoration(
              labelText: l10n?.enterPIN ?? 'Enter PIN',
              errorText: _errorMessage,
              counterText: '', // Hide character count
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _confirmController,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: AuthService.maxPinLength,
            decoration: InputDecoration(
              labelText: l10n?.confirmPIN ?? 'Confirm PIN',
              errorText: _errorMessage,
              counterText: '', // Hide character count
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text(l10n?.cancel ?? 'Cancel'),
        ),
        FilledButton(
          onPressed: _isSaving ? null : _submit,
          child: Text(l10n?.save ?? 'Save'),
        ),
      ],
    );
  }
}

class _PinVerifyDialog extends StatefulWidget {
  const _PinVerifyDialog({required this.authService});

  final AuthService authService;

  @override
  State<_PinVerifyDialog> createState() => _PinVerifyDialogState();
}

class _PinVerifyDialogState extends State<_PinVerifyDialog> {
  final TextEditingController _pinController = TextEditingController();
  String? _errorMessage;
  bool _isVerifying = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_isVerifying) return;
    final l10n = AppLocalizations.of(context);
    final pin = _pinController.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorMessage = l10n?.enterPIN ?? 'Enter PIN');
      return;
    }

    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    final result = await widget.authService.verifyPIN(pin);
    if (!mounted) return;
    if (result == PinVerificationResult.success) {
      Navigator.pop(context, true);
      return;
    }

    setState(() {
      _isVerifying = false;
      _errorMessage = l10n?.incorrectPIN ?? 'Incorrect PIN';
      _pinController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return AlertDialog(
      title: Text(l10n?.enterYourPIN ?? 'Enter PIN'),
      content: TextField(
        controller: _pinController,
        keyboardType: TextInputType.number,
        obscureText: true,
        maxLength: AuthService.maxPinLength,
        decoration: InputDecoration(
          labelText: l10n?.pin ?? 'PIN',
          errorText: _errorMessage,
          counterText: '', // Hide character count
        ),
        onSubmitted: (_) => _verify(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text(l10n?.cancel ?? 'Cancel'),
        ),
        FilledButton(
          onPressed: _isVerifying ? null : _verify,
          child: Text(l10n?.verify ?? 'Verify'),
        ),
      ],
    );
  }
}

class RadioListTile<T> extends StatelessWidget {
  const RadioListTile({
    super.key,
    required this.value,
    this.title,
    this.subtitle,
  });

  final T value;
  final Widget? title;
  final Widget? subtitle;

  @override
  Widget build(BuildContext context) {
    final radioGroup = RadioGroup.maybeOf<T>(context);
    if (radioGroup == null) {
      throw StateError('RadioListTile must be used inside a RadioGroup');
    }
    final palette = _OptionsPalette.of(context);
    final textTheme = Theme.of(context).textTheme;
    final selected = radioGroup.groupValue == value;

    return Theme(
      data: Theme.of(context).copyWith(
        radioTheme: RadioThemeData(
          fillColor: WidgetStateProperty.resolveWith(
            (states) => states.contains(WidgetState.selected)
                ? palette.theme
                : palette.textSecondary,
          ),
        ),
      ),
      child: InkWell(
        onTap: () => radioGroup.onChanged(value),
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? palette.selection : palette.surfaceAlt,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? palette.selectionBorder : palette.border,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: palette.shadow,
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Radio<T>(
                value: value,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: const VisualDensity(
                  horizontal: -4,
                  vertical: -4,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title != null)
                      DefaultTextStyle(
                        style: (textTheme.titleSmall ?? const TextStyle())
                            .copyWith(
                          color: palette.textPrimary,
                          fontWeight:
                              selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        child: title!,
                      ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 4),
                      DefaultTextStyle(
                        style: (textTheme.bodySmall ?? const TextStyle())
                            .copyWith(color: palette.textSecondary),
                        child: subtitle!,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OptionsPalette {
  const _OptionsPalette({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.surface,
    required this.surfaceAlt,
    required this.border,
    required this.theme,
    required this.themeSoft,
    required this.textPrimary,
    required this.textSecondary,
    required this.shadow,
    required this.glowPrimary,
    required this.glowSecondary,
    required this.glowMuted,
    required this.chip,
    required this.chipBorder,
    required this.selection,
    required this.selectionBorder,
  });

  final Color backgroundTop;
  final Color backgroundBottom;
  final Color surface;
  final Color surfaceAlt;
  final Color border;
  final Color theme;
  final Color themeSoft;
  final Color textPrimary;
  final Color textSecondary;
  final Color shadow;
  final Color glowPrimary;
  final Color glowSecondary;
  final Color glowMuted;
  final Color chip;
  final Color chipBorder;
  final Color selection;
  final Color selectionBorder;

  static _OptionsPalette of(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // All colors are now derived from the theme's ColorScheme
    // This ensures the Options screen reflects the selected app theme
    final backgroundTop = scheme.surface;
    final backgroundBottom = scheme.surfaceContainerLowest;
    final surface = scheme.surfaceContainerHigh;
    final surfaceAlt = scheme.surfaceContainerHighest;
    final border = isDark
        ? Colors.white.withValues(alpha: 0.08)
        : Colors.black.withValues(alpha: 0.08);
    final primaryColor = scheme.primary;
    final themeSoft = scheme.primary.withValues(alpha: isDark ? 0.28 : 0.18);
    final textPrimary = scheme.onSurface;
    final textSecondary = scheme.onSurfaceVariant;
    final shadow = isDark
        ? Colors.black.withValues(alpha: 0.35)
        : Colors.black.withValues(alpha: 0.08);
    final glowPrimary = scheme.primary.withValues(alpha: isDark ? 0.35 : 0.2);
    final glowSecondary = scheme.tertiary.withValues(
      alpha: isDark ? 0.25 : 0.16,
    );
    final glowMuted = scheme.secondary.withValues(alpha: isDark ? 0.2 : 0.12);
    final chip = scheme.surfaceContainerLow;
    final chipBorder = isDark
        ? Colors.white.withValues(alpha: 0.1)
        : Colors.black.withValues(alpha: 0.08);
    final selection = scheme.primary.withValues(alpha: isDark ? 0.18 : 0.12);
    final selectionBorder = scheme.primary.withValues(
      alpha: isDark ? 0.5 : 0.4,
    );

    return _OptionsPalette(
      backgroundTop: backgroundTop,
      backgroundBottom: backgroundBottom,
      surface: surface,
      surfaceAlt: surfaceAlt,
      border: border,
      theme: primaryColor,
      themeSoft: themeSoft,
      textPrimary: textPrimary,
      textSecondary: textSecondary,
      shadow: shadow,
      glowPrimary: glowPrimary,
      glowSecondary: glowSecondary,
      glowMuted: glowMuted,
      chip: chip,
      chipBorder: chipBorder,
      selection: selection,
      selectionBorder: selectionBorder,
    );
  }
}

/// A tappable color swatch for displaying and editing a color.
class _ColorSwatch extends StatelessWidget {
  const _ColorSwatch({required this.color, required this.onTap});

  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          border: Border.all(
            color: isDark
                ? Colors.white.withValues(alpha: 0.2)
                : Colors.black.withValues(alpha: 0.1),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Icon(
          PhosphorIcons.pencilSimple(),
          size: 16,
          color: _contrastColor(color),
        ),
      ),
    );
  }

  /// Returns white or black based on the luminance of the given color.
  Color _contrastColor(Color color) {
    final luminance = color.computeLuminance();
    return luminance > 0.5 ? Colors.black : Colors.white;
  }
}

/// Shows a color picker dialog.
void _showColorPicker(
  BuildContext context,
  Color currentColor,
  ValueChanged<Color> onColorChanged,
  String title,
) {
  showDialog(
    context: context,
    builder: (context) => _ColorPickerDialog(
      currentColor: currentColor,
      onColorChanged: onColorChanged,
      title: title,
    ),
  );
}

/// A simple color picker dialog with preset colors and HSL sliders.
class _ColorPickerDialog extends StatefulWidget {
  const _ColorPickerDialog({
    required this.currentColor,
    required this.onColorChanged,
    required this.title,
  });

  final Color currentColor;
  final ValueChanged<Color> onColorChanged;
  final String title;

  @override
  State<_ColorPickerDialog> createState() => _ColorPickerDialogState();
}

class _ColorPickerDialogState extends State<_ColorPickerDialog> {
  late HSVColor _hsvColor;

  // Preset colors for quick selection
  static const List<Color> _presetColors = [
    Color(0xFFE53935), // Red
    Color(0xFFD81B60), // Pink
    Color(0xFF8E24AA), // Purple
    Color(0xFF5E35B1), // Deep Purple
    Color(0xFF3949AB), // Indigo
    Color(0xFF1E88E5), // Blue
    Color(0xFF039BE5), // Light Blue
    Color(0xFF00ACC1), // Cyan
    Color(0xFF00897B), // Teal
    Color(0xFF43A047), // Green
    Color(0xFF7CB342), // Light Green
    Color(0xFFC0CA33), // Lime
    Color(0xFFFDD835), // Yellow
    Color(0xFFFFB300), // Amber
    Color(0xFFFB8C00), // Orange
    Color(0xFFF4511E), // Deep Orange
    Color(0xFF6D4C41), // Brown
    Color(0xFF757575), // Gray
  ];

  @override
  void initState() {
    super.initState();
    _hsvColor = HSVColor.fromColor(widget.currentColor);
  }

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);
    final selectedColor = _hsvColor.toColor();

    return AlertDialog(
      backgroundColor: palette.surface,
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current color preview
            Center(
              child: Container(
                width: 80,
                height: 80,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: selectedColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: palette.border, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: selectedColor.withValues(alpha: 0.5),
                      blurRadius: 16,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
            // Preset colors grid
            Text(
              'Presets',
              style: Theme.of(
                context,
              ).textTheme.labelMedium?.copyWith(color: palette.textSecondary),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _presetColors.map((color) {
                final isSelected = selectedColor.toARGB32() == color.toARGB32();
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _hsvColor = HSVColor.fromColor(color);
                    });
                  },
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isSelected ? Colors.white : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? PhosphorIcon(
                            PhosphorIcons.check(),
                            size: 18,
                            color: Colors.white,
                          )
                        : null,
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            // HSL Sliders
            Text(
              'Custom',
              style: Theme.of(
                context,
              ).textTheme.labelMedium?.copyWith(color: palette.textSecondary),
            ),
            const SizedBox(height: 8),
            // Hue slider
            _buildSliderRow(
              'H',
              _hsvColor.hue,
              360,
              (v) => setState(() => _hsvColor = _hsvColor.withHue(v)),
              _buildHueGradient(),
            ),
            // Saturation slider
            _buildSliderRow(
              'S',
              _hsvColor.saturation * 100,
              100,
              (v) =>
                  setState(() => _hsvColor = _hsvColor.withSaturation(v / 100)),
              LinearGradient(
                colors: [
                  HSVColor.fromAHSV(
                    1,
                    _hsvColor.hue,
                    0,
                    _hsvColor.value,
                  ).toColor(),
                  HSVColor.fromAHSV(
                    1,
                    _hsvColor.hue,
                    1,
                    _hsvColor.value,
                  ).toColor(),
                ],
              ),
            ),
            // Value/Brightness slider
            _buildSliderRow(
              'V',
              _hsvColor.value * 100,
              100,
              (v) => setState(() => _hsvColor = _hsvColor.withValue(v / 100)),
              LinearGradient(
                colors: [
                  Colors.black,
                  HSVColor.fromAHSV(
                    1,
                    _hsvColor.hue,
                    _hsvColor.saturation,
                    1,
                  ).toColor(),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(AppLocalizations.of(context)?.cancel ?? 'Cancel'),
        ),
        FilledButton(
          onPressed: () {
            widget.onColorChanged(selectedColor);
            Navigator.of(context).pop();
          },
          child: Text(AppLocalizations.of(context)?.save ?? 'Save'),
        ),
      ],
    );
  }

  Widget _buildSliderRow(
    String label,
    double value,
    double max,
    ValueChanged<double> onChanged,
    Gradient gradient,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 20,
            child: Text(label, style: Theme.of(context).textTheme.labelSmall),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 16,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
                trackShape: _GradientTrackShape(gradient: gradient),
              ),
              child: Slider(
                value: value,
                min: 0,
                max: max,
                onChanged: onChanged,
              ),
            ),
          ),
          SizedBox(
            width: 36,
            child: Text(
              value.toInt().toString(),
              style: Theme.of(context).textTheme.labelSmall,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Gradient _buildHueGradient() {
    return const LinearGradient(
      colors: [
        Color.fromARGB(255, 255, 0, 0),
        Color.fromARGB(255, 255, 255, 0),
        Color.fromARGB(255, 0, 255, 0),
        Color.fromARGB(255, 0, 255, 255),
        Color.fromARGB(255, 0, 0, 255),
        Color.fromARGB(255, 255, 0, 255),
        Color.fromARGB(255, 255, 0, 0),
      ],
    );
  }
}

/// Singleton notifier for screenshot protection state changes.
///
/// This allows the options screen to notify the app when the screenshot
/// protection setting changes, without tight coupling.
class _ScreenshotProtectionNotifier {
  _ScreenshotProtectionNotifier._();

  static final _ScreenshotProtectionNotifier instance =
      _ScreenshotProtectionNotifier._();

  final List<void Function(bool)> _listeners = [];

  void addListener(void Function(bool) listener) {
    _listeners.add(listener);
  }

  void removeListener(void Function(bool) listener) {
    _listeners.remove(listener);
  }

  void notify(bool enabled) {
    for (final listener in _listeners) {
      listener(enabled);
    }
  }
}

/// Public getter for screenshot protection notifier.
/// Used by app.dart to listen for changes.
// ignore: library_private_types_in_public_api
_ScreenshotProtectionNotifier get screenshotProtectionNotifier =>
    _ScreenshotProtectionNotifier.instance;

/// A custom slider track shape that renders a gradient background.
class _GradientTrackShape extends RoundedRectSliderTrackShape {
  const _GradientTrackShape({required this.gradient});

  final Gradient gradient;

  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required Offset thumbCenter,
    Offset? secondaryOffset,
    bool isDiscrete = false,
    bool isEnabled = false,
    double additionalActiveTrackHeight = 0,
  }) {
    final trackHeight = sliderTheme.trackHeight ?? 4;
    final trackLeft = offset.dx;
    final trackTop = offset.dy + (parentBox.size.height - trackHeight) / 2;
    final trackWidth = parentBox.size.width;

    final trackRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(trackLeft, trackTop, trackWidth, trackHeight),
      Radius.circular(trackHeight / 2),
    );

    final paint = Paint()..shader = gradient.createShader(trackRect.outerRect);

    context.canvas.drawRRect(trackRect, paint);
  }
}

class _SearchableOption {
  final Widget widget;
  final List<String> keywords;

  const _SearchableOption({required this.widget, required this.keywords});

  bool matches(String query) {
    if (query.isEmpty) return true;
    final lowerQuery = query.toLowerCase();
    return keywords.any((k) => k.toLowerCase().contains(lowerQuery));
  }
}

class _SearchableSection {
  final String title;
  final IconData icon;
  final List<_SearchableOption> options;

  const _SearchableSection({
    required this.title,
    required this.icon,
    required this.options,
  });

  List<_SearchableOption> getVisibleOptions(String query) {
    if (query.isEmpty) return options;
    return options.where((opt) => opt.matches(query)).toList();
  }
}

class _SearchField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  const _SearchField({required this.controller, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: 'Search options...',
          prefixIcon: PhosphorIcon(PhosphorIcons.magnifyingGlass()),
          filled: true,
          fillColor: Theme.of(
            context,
          ).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16),
        ),
      ),
    );
  }
}

/// Horizontal segmented pill selector replacing vertical RadioListTiles.
/// Used for Theme Mode selection (System/Light/Dark).
class SegmentedPillSelector<T> extends StatelessWidget {
  const SegmentedPillSelector({
    super.key,
    required this.value,
    required this.options,
    required this.onChanged,
  });

  final T value;
  final Map<T, String> options;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: palette.surfaceAlt,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        children: options.entries.map((entry) {
          final isSelected = entry.key == value;
          return Expanded(
            child: GestureDetector(
              onTap: () => onChanged(entry.key),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOutBack,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: isSelected
                      ? palette.theme.withValues(alpha: 0.15)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? palette.theme.withValues(alpha: 0.5)
                        : Colors.transparent,
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  entry.value,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.w500,
                        color:
                            isSelected ? palette.theme : palette.textSecondary,
                      ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// Horizontal scrollable color circle selector.
/// Used for App Theme Preset selection.
class VisualColorSelector<T> extends StatelessWidget {
  const VisualColorSelector({
    super.key,
    required this.value,
    required this.items,
    required this.onChanged,
    required this.colorsBuilder,
  });

  final T value;
  final List<T> items;
  final ValueChanged<T> onChanged;
  final List<Color> Function(T) colorsBuilder;

  @override
  Widget build(BuildContext context) {
    final palette = _OptionsPalette.of(context);

    return SizedBox(
      height: 60,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (context, index) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final item = items[index];
          final isSelected = item == value;
          final colors = colorsBuilder(item);
          final primaryColor = colors.isNotEmpty ? colors[0] : Colors.grey;
          final secondaryColor = colors.length > 1 ? colors[1] : primaryColor;

          return GestureDetector(
            onTap: () => onChanged(item),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 44,
              height: 44,
              margin: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [primaryColor, secondaryColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: isSelected ? palette.theme : palette.border,
                  width: isSelected ? 3 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: primaryColor.withValues(alpha: 0.4),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ]
                    : null,
              ),
              child: isSelected
                  ? PhosphorIcon(
                      PhosphorIcons.check(),
                      size: 20,
                      color: _contrastColor(primaryColor),
                    )
                  : null,
            ),
          );
        },
      ),
    );
  }

  Color _contrastColor(Color color) =>
      color.computeLuminance() > 0.5 ? Colors.black : Colors.white;
}
