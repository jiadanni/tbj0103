import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Region and currency selection step.
class RegionCurrencyStep extends StatelessWidget {
  const RegionCurrencyStep({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.selectedRegionId,
    required this.selectedCurrency,
    required this.onRegionSelected,
    required this.onCurrencySelected,
  });

  final VoidCallback onNext;
  final VoidCallback onBack;
  final String selectedRegionId;
  final AppCurrency selectedCurrency;
  final ValueChanged<String> onRegionSelected;
  final ValueChanged<AppCurrency> onCurrencySelected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Back button
            IconButton(
              onPressed: onBack,
              icon: PhosphorIcon(
                PhosphorIcons.arrowLeft(),
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Title
            Text(
              l10n?.onboardingRegionTitle ?? 'Region & Currency',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingSmall),

            Text(
              l10n?.onboardingRegionSubtitle ??
                  'Choose your defaults for the best experience.',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),

            const SizedBox(height: AppConstants.paddingXLarge),

            // Region presets
            Text(
              l10n?.onboardingRegionPreset ?? 'Region Preset',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Region selection chips
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: AppSettingsPresets.regionPresets.map((preset) {
                final isSelected = preset.id == selectedRegionId;
                return ChoiceChip(
                  label: Text(preset.label),
                  selected: isSelected,
                  onSelected: (_) {
                    onRegionSelected(preset.id);
                    // Also update currency if preset has one
                    if (preset.currency != null) {
                      onCurrencySelected(preset.currency!);
                    }
                  },
                  selectedColor: colorScheme.primaryContainer,
                  backgroundColor: colorScheme.surfaceContainerHighest,
                  labelStyle: TextStyle(
                    color: isSelected
                        ? colorScheme.onPrimaryContainer
                        : colorScheme.onSurface,
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: AppConstants.paddingXLarge),

            // Currency dropdown
            Text(
              l10n?.onboardingCurrencyLabel ?? 'Currency',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                border: Border.all(
                  color: colorScheme.outline.withValues(alpha: 0.3),
                ),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<AppCurrency>(
                  value: selectedCurrency,
                  isExpanded: true,
                  icon: PhosphorIcon(
                    PhosphorIcons.caretDown(),
                    color: colorScheme.onSurface,
                  ),
                  items: AppCurrency.values.map((currency) {
                    return DropdownMenuItem<AppCurrency>(
                      value: currency,
                      child: Row(
                        children: [
                          Text(
                            currency.symbol,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              currency.name.toUpperCase(),
                              style: theme.textTheme.bodyLarge,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (currency) {
                    if (currency != null) {
                      onCurrencySelected(currency);
                    }
                  },
                ),
              ),
            ),

            const Spacer(),

            // Info card
            Container(
              padding: const EdgeInsets.all(AppConstants.paddingMedium),
              decoration: BoxDecoration(
                color: colorScheme.primaryContainer.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
              ),
              child: Row(
                children: [
                  PhosphorIcon(
                    PhosphorIcons.info(),
                    color: colorScheme.primary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      l10n?.onboardingCurrencyHint ??
                          'You can change these anytime in settings.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withValues(alpha: 0.8),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppConstants.paddingLarge),

            // Next button
            SizedBox(
              width: double.infinity,
              height: AppConstants.buttonHeightPrimary,
              child: FilledButton(
                onPressed: onNext,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusButton,
                    ),
                  ),
                ),
                child: Text(
                  l10n?.onboardingContinue ?? 'Continue',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),
          ],
        ),
      ),
    );
  }
}
