import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Welcome step - first screen of onboarding wizard.
class WelcomeStep extends StatelessWidget {
  const WelcomeStep({super.key, required this.onGetStarted});

  final VoidCallback onGetStarted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Spacer(flex: 2),

            // App Icon with glow effect
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: colorScheme.primaryContainer.withValues(alpha: 0.3),
                boxShadow: [
                  BoxShadow(
                    color: colorScheme.primary.withValues(alpha: 0.2),
                    blurRadius: 40,
                    spreadRadius: 10,
                  ),
                ],
              ),
              child: PhosphorIcon(
                PhosphorIcons.wallet(PhosphorIconsStyle.duotone),
                size: 80,
                color: colorScheme.primary,
              ),
            ),

            const SizedBox(height: AppConstants.paddingXLarge),

            // App title
            Text(
              l10n?.appTitle ?? 'Expense Stalker',
              style: theme.textTheme.headlineLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Tagline
            Text(
              l10n?.onboardingWelcomeTagline ?? 'Sleek, Private, Minimalist.',
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.7),
                height: 1.5,
              ),
            ),

            const Spacer(flex: 3),

            // Feature highlights
            _FeatureHighlight(
              icon: PhosphorIcons.calendarCheck(PhosphorIconsStyle.duotone),
              text: l10n?.onboardingFeatureTimeline ?? 'Timeline View',
              color: colorScheme.primary,
            ),
            const SizedBox(height: AppConstants.paddingMedium),
            _FeatureHighlight(
              icon: PhosphorIcons.pulse(PhosphorIconsStyle.duotone),
              text: l10n?.onboardingFeaturePulse ?? 'Pulse Entry',
              color: colorScheme.secondary,
            ),
            const SizedBox(height: AppConstants.paddingMedium),
            _FeatureHighlight(
              icon: PhosphorIcons.lightbulb(PhosphorIconsStyle.duotone),
              text: l10n?.onboardingFeatureInsights ?? 'Smart Insights',
              color: colorScheme.tertiary,
            ),

            const Spacer(flex: 2),

            // Get Started button
            SizedBox(
              width: double.infinity,
              height: AppConstants.buttonHeightPrimary,
              child: FilledButton(
                onPressed: onGetStarted,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusButton,
                    ),
                  ),
                ),
                child: Text(
                  l10n?.onboardingGetStarted ?? 'Get Started',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),
          ],
        ),
      ),
    );
  }
}

class _FeatureHighlight extends StatelessWidget {
  const _FeatureHighlight({
    required this.icon,
    required this.text,
    required this.color,
  });

  final IconData icon;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          ),
          child: PhosphorIcon(icon, size: 24, color: color),
        ),
        const SizedBox(width: AppConstants.paddingMedium),
        Expanded(
          child: Text(
            text,
            style: theme.textTheme.bodyLarge?.copyWith(
              color: theme.colorScheme.onSurface,
            ),
          ),
        ),
      ],
    );
  }
}
