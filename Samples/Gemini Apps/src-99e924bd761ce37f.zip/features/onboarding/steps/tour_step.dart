import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Reusable tour step for feature introduction slides.
class TourStep extends StatelessWidget {
  const TourStep({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.description,
    required this.features,
    this.isLastTourStep = false,
  });

  final VoidCallback onNext;
  final VoidCallback onBack;
  final IconData icon;
  final Color iconColor;
  final String title;
  final String description;
  final List<TourFeature> features;
  final bool isLastTourStep;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.paddingLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Back button
            IconButton(
              onPressed: onBack,
              icon: PhosphorIcon(
                PhosphorIcons.arrowLeft(),
                color: colorScheme.onSurface,
              ),
            ),

            const Spacer(),

            // Centered icon with glow
            Center(
              child: Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: iconColor.withValues(alpha: 0.15),
                  boxShadow: [
                    BoxShadow(
                      color: iconColor.withValues(alpha: 0.2),
                      blurRadius: 50,
                      spreadRadius: 20,
                    ),
                  ],
                ),
                child: PhosphorIcon(icon, size: 64, color: iconColor),
              ),
            ),

            const SizedBox(height: AppConstants.paddingXLarge),

            // Title
            Center(
              child: Text(
                title,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: colorScheme.onSurface,
                ),
                textAlign: TextAlign.center,
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),

            // Description
            Center(
              child: Text(
                description,
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: colorScheme.onSurface.withValues(alpha: 0.7),
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
            ),

            const Spacer(),

            // Feature list
            ...features.map(
              (feature) => Padding(
                padding: const EdgeInsets.only(
                  bottom: AppConstants.paddingMedium,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: iconColor.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(
                          AppConstants.radiusSmall,
                        ),
                      ),
                      child: PhosphorIcon(
                        feature.icon,
                        size: 20,
                        color: iconColor,
                      ),
                    ),
                    const SizedBox(width: AppConstants.paddingMedium),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            feature.title,
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: colorScheme.onSurface,
                            ),
                          ),
                          Text(
                            feature.subtitle,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: colorScheme.onSurface.withValues(
                                alpha: 0.6,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const Spacer(),

            // Next button
            SizedBox(
              width: double.infinity,
              height: AppConstants.buttonHeightPrimary,
              child: FilledButton(
                onPressed: onNext,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      AppConstants.radiusButton,
                    ),
                  ),
                ),
                child: Text(
                  isLastTourStep
                      ? (l10n?.onboardingAlmostDone ?? 'Almost Done')
                      : (l10n?.onboardingContinue ?? 'Continue'),
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),

            const SizedBox(height: AppConstants.paddingMedium),
          ],
        ),
      ),
    );
  }
}

/// Feature item for tour step.
class TourFeature {
  const TourFeature({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;
}
