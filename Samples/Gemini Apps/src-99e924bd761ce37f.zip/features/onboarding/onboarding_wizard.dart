import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

import 'package:expense_stalker_mobile/src/features/onboarding/widgets/step_indicator.dart';
import 'package:expense_stalker_mobile/src/features/onboarding/steps/account_setup_step.dart';
import 'package:expense_stalker_mobile/src/features/onboarding/steps/experience_step.dart';
import 'package:expense_stalker_mobile/src/features/onboarding/steps/complete_step.dart';

/// Data collected during onboarding wizard.
class OnboardingData {
  OnboardingData({
    this.accountName = '',
    this.startingBalance = 0,
    this.iconCodePoint,
    this.regionPresetId = 'auto',
    this.currency = AppCurrency.usd,
    this.demoDataEnabled = false,
  });

  String accountName;
  int startingBalance;
  int? iconCodePoint;
  String regionPresetId;
  AppCurrency currency;
  bool demoDataEnabled;
}

/// Main onboarding wizard with PageView-based navigation.
class OnboardingWizard extends StatefulWidget {
  const OnboardingWizard({
    super.key,
    required this.onComplete,
    required this.onSkip,
  });

  /// Called when user completes onboarding with collected data.
  final void Function(OnboardingData data) onComplete;

  /// Called when user skips onboarding.
  final VoidCallback onSkip;

  @override
  State<OnboardingWizard> createState() => _OnboardingWizardState();
}

class _OnboardingWizardState extends State<OnboardingWizard> {
  late final PageController _pageController;
  int _currentStep = 0;
  final OnboardingData _data = OnboardingData();

  // Account icon code points for selection
  static const _accountIconCodePoints = [
    0xe6bb, // wallet
    0xe0d0, // bank
    0xe22a, // creditCard
    0xe4c9, // piggyBank
    0xe186, // coins
    0xe162, // chartLine
    0xe333, // house
    0xe141, // car
    0xe04e, // airplane
    0xe5c3, // shoppingCart
    0xe30c, // heart
    0xe5fb, // star
  ];

  int _selectedIconIndex = 0;

  static const int _totalSteps = 3;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    // Initialize with system locale currency
    final locale = AppSettingsPresets.localeFromPlatform();
    _data.currency = AppSettingsPresets.currencyForLocale(locale);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goToStep(int step) {
    if (step < 0 || step >= _totalSteps) return;
    setState(() => _currentStep = step);
    _pageController.animateToPage(
      step,
      duration: AppConstants.animationPageTransition,
      curve: Curves.easeInOut,
    );
  }

  void _next() => _goToStep(_currentStep + 1);
  void _back() => _goToStep(_currentStep - 1);

  void _complete() {
    // Set icon code point if selected
    if (_selectedIconIndex >= 0 &&
        _selectedIconIndex < _accountIconCodePoints.length) {
      _data.iconCodePoint = _accountIconCodePoints[_selectedIconIndex];
    }
    widget.onComplete(_data);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);
    final isDark = theme.brightness == Brightness.dark;

    // Use theme-aware background
    final background = theme.scaffoldBackgroundColor;

    return Scaffold(
      body: Stack(
        children: [
          // Theme-aware background
          Container(color: background),

          // Subtle glow orbs for depth
          if (isDark) ...[
            Positioned(
              top: -100,
              right: -50,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      colorScheme.primary.withValues(alpha: 0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -50,
              left: -100,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      colorScheme.tertiary.withValues(alpha: 0.1),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ],

          // Main content
          Column(
            children: [
              // Skip button (not shown on complete step)
              if (_currentStep < _totalSteps - 1)
                SafeArea(
                  bottom: false,
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        top: AppConstants.paddingSmall,
                        right: AppConstants.paddingMedium,
                      ),
                      child: TextButton(
                        onPressed: widget.onSkip,
                        child: Text(
                          l10n?.onboardingSkip ?? 'Skip',
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

              // PageView
              Expanded(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  onPageChanged: (index) =>
                      setState(() => _currentStep = index),
                  children: [
                    // Step 0: Welcome & Basic Setup
                    AccountSetupStep(
                      onNext: _next,
                      accountName: _data.accountName,
                      startingBalance: _data.startingBalance,
                      selectedIconIndex: _selectedIconIndex,
                      selectedRegionId: _data.regionPresetId,
                      selectedCurrency: _data.currency,
                      onAccountNameChanged: (name) => _data.accountName = name,
                      onStartingBalanceChanged: (balance) =>
                          _data.startingBalance = balance,
                      onIconSelected: (index) =>
                          setState(() => _selectedIconIndex = index),
                      onRegionSelected: (id) =>
                          setState(() => _data.regionPresetId = id),
                      onCurrencySelected: (currency) =>
                          setState(() => _data.currency = currency),
                    ),

                    // Step 1: Feature Exploration & Demo Data
                    ExperienceStep(
                      onNext: _next,
                      onBack: _back,
                      demoDataEnabled: _data.demoDataEnabled,
                      onToggleDemoData: (enabled) =>
                          setState(() => _data.demoDataEnabled = enabled),
                    ),

                    // Step 2: Confirmation & Completion
                    CompleteStep(
                      onComplete: _complete,
                      onBack: _back,
                      accountName: _data.accountName,
                      demoDataEnabled: _data.demoDataEnabled,
                    ),
                  ],
                ),
              ),

              // Step indicator (not shown on first step anymore as it's the welcome/combined step?)
              // Actually, showing it might be good to see progress (1 of 3)
              if (_totalSteps > 1)
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      bottom: AppConstants.paddingLarge,
                    ),
                    child: StepIndicator(
                      totalSteps: _totalSteps,
                      currentStep: _currentStep,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
