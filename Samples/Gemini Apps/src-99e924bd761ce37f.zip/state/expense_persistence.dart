import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/expense_priority.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/checksum_util.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/state/map_decoder.dart';

/// Result of checksum validation during import.
enum ChecksumValidation {
  /// Checksum is valid - data integrity confirmed.
  valid,

  /// No checksum present (legacy export or checksum stripped).
  missing,

  /// Checksum mismatch - data may be corrupted.
  invalid,
}

class ExpensePersistence {
  ExpensePersistence._(this._storage);

  static const _kAccounts = 'expense.accounts';
  static const _kCurrentAccountId = 'expense.currentAccountId';

  // Account-specific key generators
  String _monthKey(AccountId accountId) => 'account.$accountId.selectedMonth';
  String _timelineKey(AccountId accountId) =>
      'account.$accountId.timelineItems';
  String _pulseKey(AccountId accountId) => 'account.$accountId.pulses';

  final StorageProvider _storage;

  static Future<ExpensePersistence> create() async {
    final storage = await StorageProvider.create();
    return ExpensePersistence._(storage);
  }

  /// Loads accounts metadata.
  Future<List<Account>> loadAccounts() async {
    final accountsJson = await _storage.getString(_kAccounts);
    if (accountsJson == null) {
      return [];
    }

    final List<dynamic> decoded = jsonDecode(accountsJson);
    return decoded
        .map((item) => Account.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveAccounts(List<Account> accounts) async {
    final json = jsonEncode(accounts.map((a) => a.toJson()).toList());
    await _storage.setString(_kAccounts, json);
  }

  Future<AccountId?> getCurrentAccountId() async {
    final id = await _storage.getString(_kCurrentAccountId);
    return id != null ? AccountId(id) : null;
  }

  Future<void> setCurrentAccountId(AccountId id) async {
    await _storage.setString(_kCurrentAccountId, id);
  }

  Future<ExpenseSnapshot?> load(AccountId accountId) async {
    try {
      final selectedMonthMillis = await _storage.getInt(_monthKey(accountId));
      final timelineJson = await _storage.getString(_timelineKey(accountId));
      final pulseJson = await _storage.getString(_pulseKey(accountId));

      if (selectedMonthMillis == null &&
          timelineJson == null &&
          pulseJson == null) {
        return null;
      }

      final selectedMonth = selectedMonthMillis == null
          ? monthOnly(DateTime.now())
          : monthOnly(
              DateTime.fromMillisecondsSinceEpoch(
                selectedMonthMillis,
                isUtc: true,
              ),
            );

      final snapshot = await compute((params) {
        List<TimelineItem> timelineItems = const [];
        if (params.timelineJson != null) {
          final decoded = jsonDecode(params.timelineJson!);
          if (decoded is List) {
            timelineItems = decoded
                .whereType<Map>()
                .map(
                  (m) => TimelineItemCodec.fromJson(m.cast<String, Object?>()),
                )
                .toList(growable: false);
          }
        }

        List<PulseEntry> pulses = const [];
        if (params.pulseJson != null) {
          final decoded = jsonDecode(params.pulseJson!);
          if (decoded is List) {
            pulses = decoded
                .whereType<Map>()
                .map((m) => PulseEntryCodec.fromJson(m.cast<String, Object?>()))
                .toList(growable: false);
          }
        }

        return (timelineItems: timelineItems, pulses: pulses);
      }, (timelineJson: timelineJson, pulseJson: pulseJson));

      return ExpenseSnapshot(
        selectedMonth: selectedMonth,
        timelineItems: snapshot.timelineItems,
        pulses: snapshot.pulses,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Critical error decoding persisted data for account $accountId',
        error: error,
        stackTrace: stackTrace,
      );
      // Rethrow so ExpenseStore doesn't assume the account is empty and overwrite it
      rethrow;
    }
  }

  Future<void> save(AccountId accountId, ExpenseSnapshot snapshot) async {
    final monthResult = await _storage.setInt(
      _monthKey(accountId),
      monthOnly(snapshot.selectedMonth).millisecondsSinceEpoch,
    );
    if (!monthResult) {
      throw StorageException(
        'Failed to persist selected month for account $accountId',
      );
    }

    final (timelineJson, pulseJson) = await compute((s) {
      final pj = jsonEncode(
        s.timelineItems.map(TimelineItemCodec.toJson).toList(),
      );
      final payj = jsonEncode(s.pulses.map(PulseEntryCodec.toJson).toList());
      return (pj, payj);
    }, snapshot);

    final timelineResult = await _storage.setString(
      _timelineKey(accountId),
      timelineJson,
    );
    if (!timelineResult) {
      throw StorageException(
        'Failed to persist timeline items for account $accountId',
      );
    }

    final pulseResult = await _storage.setString(
      _pulseKey(accountId),
      pulseJson,
    );
    if (!pulseResult) {
      throw StorageException('Failed to persist pulse for account $accountId');
    }
  }

  Future<void> deleteAccountData(AccountId accountId) async {
    final results = await Future.wait([
      _storage.remove(_monthKey(accountId)),
      _storage.remove(_timelineKey(accountId)),
      _storage.remove(_pulseKey(accountId)),
    ]);

    if (results.any((success) => !success)) {
      throw StorageException(
        'Failed to delete some account data for $accountId',
      );
    }
  }

  // --- Export/Import JSON helpers (shared between persistence and export service)

  Map<String, dynamic> snapshotToExportJson(
    ExpenseSnapshot snapshot, {
    Map<String, String>? encryption,
    bool excludePulses = false,
  }) {
    final base = {
      'version': 4,
      'exportDate': DateTime.now().toUtc().toIso8601String(),
      if (excludePulses) 'excludePulses': true,
    };

    if (encryption != null) {
      return {...base, 'encryption': encryption};
    }

    return {
      ...base,
      'selectedMonth': snapshot.selectedMonth.toUtc().toIso8601String(),
      'timelineItems':
          snapshot.timelineItems.map(TimelineItemCodec.toJson).toList(),
      'pulse': excludePulses
          ? <Map<String, dynamic>>[]
          : snapshot.pulses.map(PulseEntryCodec.toJson).toList(),
      if (snapshot.accountSettings != null)
        'account': snapshot.accountSettings!.toJson(),
      'moneyPots': snapshot.moneyPots.map((p) => p.toJson()).toList(),
    };
  }

  Map<String, dynamic> accountsToExportJson(
    List<Account> accounts,
    Map<String, ExpenseSnapshot> data, {
    Map<String, String>? encryption,
    bool excludePulses = false,
  }) {
    final base = {
      'version': 2,
      'exportDate': DateTime.now().toUtc().toIso8601String(),
      if (excludePulses) 'excludePulses': true,
    };

    if (encryption != null) {
      return {...base, 'encryption': encryption};
    }

    return {
      ...base,
      'accounts': accounts.map((a) {
        final snapshot = data[a.id];
        return {
          'metadata': a.toJson(),
          'data': snapshot != null
              ? {
                  'selectedMonth':
                      snapshot.selectedMonth.toUtc().toIso8601String(),
                  'timelineItems': snapshot.timelineItems
                      .map(TimelineItemCodec.toJson)
                      .toList(),
                  'pulse': excludePulses
                      ? <Map<String, dynamic>>[]
                      : snapshot.pulses.map(PulseEntryCodec.toJson).toList(),
                }
              : null,
        };
      }).toList(),
    };
  }

  /// Static convenience wrapper for exporting snapshot to JSON map.
  static Map<String, dynamic> toExportJson(
    ExpenseSnapshot snapshot, {
    Map<String, String>? encryption,
    bool excludePulses = false,
  }) {
    return ExpensePersistence._dummy().snapshotToExportJson(
      snapshot,
      encryption: encryption,
      excludePulses: excludePulses,
    );
  }

  static Map<String, dynamic> multiAccountToExportJson(
    List<Account> accounts,
    Map<String, ExpenseSnapshot> data, {
    Map<String, String>? encryption,
    bool excludePulses = false,
  }) {
    return ExpensePersistence._dummy().accountsToExportJson(
      accounts,
      data,
      encryption: encryption,
      excludePulses: excludePulses,
    );
  }

  /// Adds a SHA-256 checksum to the export JSON for data integrity validation.
  ///
  /// The checksum is calculated over the data fields (excluding metadata like
  /// version, exportDate, and the checksum itself) to detect corruption during
  /// import.
  static Future<Map<String, dynamic>> addChecksum(
    Map<String, dynamic> json,
  ) async {
    // Create a copy of the data without metadata fields for checksumming
    final dataToHash = Map<String, dynamic>.from(json)
      ..remove('version')
      ..remove('exportDate')
      ..remove('checksum')
      ..remove('encryption');

    final checksum = await ChecksumUtil.generateChecksum(dataToHash);

    return {...json, 'checksum': checksum};
  }

  /// Validates the checksum of an import JSON if present.
  ///
  /// Returns [ChecksumValidation.valid] if checksum matches,
  /// [ChecksumValidation.missing] if no checksum present (legacy export),
  /// [ChecksumValidation.invalid] if checksum doesn't match (corruption detected).
  static Future<ChecksumValidation> validateChecksum(
    Map<String, dynamic> json,
  ) async {
    final storedChecksum = json['checksum'] as String?;

    if (storedChecksum == null) {
      // Legacy export without checksum - allow but log
      debugLog(
        LogCategory.persistence,
        'Import file has no checksum (legacy format)',
      );
      return ChecksumValidation.missing;
    }

    // Create same data map used during export
    final dataToHash = Map<String, dynamic>.from(json)
      ..remove('version')
      ..remove('exportDate')
      ..remove('checksum')
      ..remove('encryption');

    final isValid = await ChecksumUtil.validateChecksum(
      dataToHash,
      storedChecksum,
    );

    if (!isValid) {
      ErrorTracker.instance.trackError(
        ErrorContext(
          category: 'import_validation',
          message: 'Import checksum validation failed - data may be corrupted',
          severity: ErrorSeverity.warning,
          additionalData: {'expectedChecksum': storedChecksum},
        ),
      );
      return ChecksumValidation.invalid;
    }

    debugLog(LogCategory.persistence, 'Import checksum validated successfully');
    return ChecksumValidation.valid;
  }

  /// Checks if the given export JSON is encrypted.
  static bool isEncrypted(Map<String, dynamic> json) {
    return json.containsKey('encryption');
  }

  /// Static convenience wrapper for creating snapshot from export JSON map.
  static ExpenseSnapshot fromExportJson(Map<String, dynamic> json) {
    return ExpensePersistence._dummy().snapshotFromExportJson(json);
  }

  static (List<Account>, Map<String, ExpenseSnapshot>)
      multiAccountFromExportJson(Map<String, dynamic> json) {
    final version = json['version'] as int? ?? 1;
    if (version == 1 || version == 3 || version == 4) {
      // Convert legacy v1/v3 to v2 format with a single account
      final snapshot = fromExportJson(json);
      final account = Account.create(name: 'Imported Account');
      return ([account], {account.id: snapshot});
    }

    if (version != 2) {
      throw FormatException('Unsupported export version: $version');
    }

    final accountsResult = <Account>[];
    final dataResult = <String, ExpenseSnapshot>{};

    final accountsRaw = json['accounts'] as List<dynamic>? ?? [];
    for (final item in accountsRaw) {
      if (item is Map<String, dynamic>) {
        final metadata = Account.fromJson(
          item['metadata'] as Map<String, dynamic>,
        );
        accountsResult.add(metadata);

        final dataRaw = item['data'] as Map<String, dynamic>?;
        if (dataRaw != null) {
          final selectedMonthStr = dataRaw['selectedMonth'] as String?;
          final selectedMonth = selectedMonthStr != null
              ? DateTime.parse(selectedMonthStr).toLocal()
              : DateTime.now();

          // Support both old and new field names for backward compatibility
          final timelineItemsRaw =
              (dataRaw['timelineItems'] as List<dynamic>?) ??
                  (dataRaw['plannerItems'] as List<dynamic>?) ??
                  [];
          final timelineItems = _parseListSafe(
            timelineItemsRaw,
            TimelineItemCodec.fromJson,
            'timeline item',
          );

          final pulsesRaw = (dataRaw['pulses'] as List<dynamic>?) ??
              (dataRaw['pulse'] as List<dynamic>?) ??
              (dataRaw['payments'] as List<dynamic>?) ??
              [];
          final pulses = _parseListSafe(
            pulsesRaw,
            PulseEntryCodec.fromJson,
            'pulse',
          );

          dataResult[metadata.id] = ExpenseSnapshot(
            selectedMonth: selectedMonth,
            timelineItems: timelineItems,
            pulses: pulses,
          );
        }
      }
    }

    return (accountsResult, dataResult);
  }

  // Private dummy constructor helper for static wrappers.
  static ExpensePersistence _dummy() => ExpensePersistence._(_DummyStorage());

  ExpenseSnapshot snapshotFromExportJson(Map<String, dynamic> json) {
    debugLog(
      LogCategory.persistence,
      'Starting import, json keys: ${json.keys.toList()}',
    );
    final version = json['version'] as int? ?? 1;
    debugLog(LogCategory.persistence, 'Version: $version');
    if (version > 4) {
      throw FormatException('Unsupported export version: $version');
    }

    if (version == 2) {
      // For v2 files, if we ask for a single snapshot, we just take the first account's data
      debugLog(
        LogCategory.persistence,
        'Version 2, using multiAccountFromExportJson',
      );
      final (_, data) = multiAccountFromExportJson(json);
      if (data.isEmpty) {
        debugLog(LogCategory.persistence, 'No data found in v2 format');
        return ExpenseSnapshot(
          selectedMonth: DateTime.now(),
          timelineItems: [],
          pulses: [],
        );
      }
      debugLog(
        LogCategory.persistence,
        'Loaded ${data.values.first.timelineItems.length} timeline items, ${data.values.first.pulses.length} pulses',
      );
      return data.values.first;
    }

    final selectedMonthStr = json['selectedMonth'] as String?;
    final selectedMonth = selectedMonthStr != null
        ? DateTime.parse(selectedMonthStr).toLocal()
        : DateTime.now();

    // Support both old and new field names for backward compatibility
    debugLog(
      LogCategory.persistence,
      'Checking for timelineItems/plannerItems...',
    );
    final timelineItemsRaw = (json['timelineItems'] as List<dynamic>?) ??
        (json['plannerItems'] as List<dynamic>?) ??
        [];
    debugLog(
      LogCategory.persistence,
      'Found ${timelineItemsRaw.length} timeline items in JSON',
    );

    debugLog(LogCategory.persistence, 'Checking for pulses/pulse/payments...');
    final pulsesRaw = (json['pulses'] as List<dynamic>?) ??
        (json['pulse'] as List<dynamic>?) ??
        (json['payments'] as List<dynamic>?) ??
        [];
    debugLog(
      LogCategory.persistence,
      'Found ${pulsesRaw.length} pulses in JSON',
    );

    try {
      final timelineItems = _parseListSafe(
        timelineItemsRaw,
        TimelineItemCodec.fromJson,
        'timeline item',
      );
      debugLog(
        LogCategory.persistence,
        'Parsed ${timelineItems.length} timeline items',
      );

      final pulses = _parseListSafe(
        pulsesRaw,
        PulseEntryCodec.fromJson,
        'pulse',
      );
      debugLog(LogCategory.persistence, 'Parsed ${pulses.length} pulses');

      return ExpenseSnapshot(
        selectedMonth: selectedMonth,
        timelineItems: timelineItems,
        pulses: pulses,
        accountSettings: json.containsKey('account')
            ? Account.fromJson(json['account'] as Map<String, dynamic>)
            : null,
        moneyPots: (json['moneyPots'] as List<dynamic>?)
                ?.map((e) => MoneyPot.fromJson(e as Map<String, dynamic>))
                .toList() ??
            const [],
      );
    } catch (e, stack) {
      debugLog(
        LogCategory.persistence,
        'Failed to parse',
        error: e,
        stackTrace: stack,
      );
      rethrow;
    }
  }

  bool validateSnapshot(ExpenseSnapshot snapshot) {
    // Basic validation: ids present, amounts reasonable, no duplicate ids
    final ids = <String>{};
    final timelineItemIds = <TimelineItemId>{};

    // Validate timeline items
    for (final item in snapshot.timelineItems) {
      if (item.id.isEmpty) return false;
      if (!ids.add(item.id)) return false; // Duplicate ID check
      timelineItemIds.add(item.id);
    }

    // Validate pulses
    for (final p in snapshot.pulses) {
      if (p.id.isEmpty) return false;
      if (!ids.add(p.id)) return false; // Duplicate ID check

      // Validate timelineItemId reference if present
      if (p.timelineItemId != null &&
          p.timelineItemId!.isNotEmpty &&
          !timelineItemIds.contains(p.timelineItemId)) {
        debugLog(
          LogCategory.persistence,
          'Pulse ${p.id} references non-existent timeline item ${p.timelineItemId}',
        );
        // Don't fail validation - just a broken reference, still importable
        // The pulse will work fine, just won't be linked to a timeline item
      }
    }

    return true;
  }

  static List<T> _parseListSafe<T>(
    List<dynamic> rawList,
    T Function(Map<String, Object?>) mapper,
    String itemName,
  ) {
    final result = <T>[];
    var skippedCount = 0;

    for (var i = 0; i < rawList.length; i++) {
      final raw = rawList[i];
      if (raw is! Map) {
        if (skippedCount++ < 5) {
          debugLog(
            LogCategory.persistence,
            'Skipping invalid $itemName at index $i: not a map',
          );
        }
        continue;
      }
      try {
        result.add(mapper(raw.cast<String, Object?>()));
      } catch (e, st) {
        if (skippedCount++ < 5) {
          // Log first 5 errors to avoid spamming log on massive corruption
          debugLog(
            LogCategory.persistence,
            'Skipping invalid $itemName at index $i',
            error: e,
            stackTrace: st,
          );
        }
      }
    }

    if (skippedCount > 0) {
      debugLog(
        LogCategory.persistence,
        'Skipped total of $skippedCount invalid ${itemName}s',
      );
    }

    return result;
  }
}

class _DummyStorage implements StorageProvider {
  @override
  Future<bool?> getBool(String key) async => null;

  @override
  Future<int?> getInt(String key) async => null;

  @override
  Future<String?> getString(String key) async => null;

  @override
  Future<bool> setBool(String key, bool value) async => false;

  @override
  Future<bool> setInt(String key, int value) async => false;

  @override
  Future<bool> setString(String key, String value) async => false;

  @override
  Future<List<String>?> getStringList(String key) async => null;

  @override
  Future<bool> setStringList(String key, List<String> value) async => false;

  @override
  Future<bool> remove(String key) async => false;
}

// ... (existing imports preserved by tool location) ...

class ExpenseSnapshot {
  const ExpenseSnapshot({
    required this.selectedMonth,
    required this.timelineItems,
    required this.pulses,
    this.accountSettings,
    this.moneyPots = const [], // Default empty for backwards compatibility
  });

  final DateTime selectedMonth;
  final List<TimelineItem> timelineItems;
  final List<PulseEntry> pulses;
  final Account? accountSettings;
  final List<MoneyPot> moneyPots;
}

class TimelineItemCodec {
  static Map<String, Object?> toJson(TimelineItem item) => {
        'id': item.id,
        'label': item.label,
        'amountMinorUnits': item.amountMinorUnits,
        'dayOfMonth': item.dayOfMonth,
        'startDate': item.startDate.toUtc().toIso8601String(),
        'notes': item.notes,
        'type': item.type.name,
        'frequency': item.frequency?.name,
        'archived': item.archived,
        'paidOffDate': item.paidOffDate?.toUtc().toIso8601String(),
        'remainingBalanceMinorUnits': item.remainingBalanceMinorUnits,
        'originalAmountMinorUnits': item.originalAmountMinorUnits,
        'category': item.category,
        'subcategory': item.subcategory,
        'origin': item.origin,
        'company': item.origin, // Keep for backward compatibility
        'priority': item.priority?.name,
        'isSalary': item.isSalary,
        'useAsPaycheckBoundary': item.useAsPaycheckBoundary,
        'moneyPotId': item.moneyPotId,

        'balanceCurrency': item.balanceCurrency?.name,
        'exchangeRate': item.exchangeRate,

        'useActualsForCurrentBalance': item.useActualsForCurrentBalance,
        'useActualsForFutureBalance': item.useActualsForFutureBalance,
        'suggestedOrigins': item.suggestedOrigins,
        'quickAddAmounts': item.quickAddAmounts,
        'transactionCurrency': item.transactionCurrency?.name,
        'transactionAmountMinorUnits': item.transactionAmountMinorUnits,
        'skippedDates':
            item.skippedDates?.map((d) => d.millisecondsSinceEpoch).toList(),
        'pausedDate': item.pausedDate?.toUtc().toIso8601String(),
        'autoResumeDate': item.autoResumeDate?.toUtc().toIso8601String(),
        'valueHistory': item.valueHistory
            ?.map(
              (c) => {
                'effectiveDate': c.effectiveDate.toUtc().toIso8601String(),
                'amountMinorUnits': c.amountMinorUnits,
              },
            )
            .toList(),
      };

  static TimelineItem fromJson(Map<String, Object?> json) {
    final d = MapDecoder(json);
    final typeStr = d.getString('type');
    final frequencyStr = d.getString('frequency');
    final amountMinorUnits = d.getInt('amountMinorUnits') ??
        d.getInt('amountCents') ??
        d.getInt('amount') ??
        d.getInt('cents') ??
        d.getInt('amount_minor_units') ??
        0;

    // Migrate old frequency-based system to new type + frequency system
    PulseType type;
    RecurrenceFrequency? frequency;

    if (typeStr != null) {
      // New format with explicit type
      try {
        type = PulseType.values.byName(typeStr);
      } catch (error) {
        debugLog(
          LogCategory.persistence,
          'Invalid PulseType "$typeStr", defaulting to recurring',
          error: error,
        );
        type = PulseType.recurring;
      }

      if (frequencyStr != null) {
        try {
          frequency = RecurrenceFrequency.values.byName(frequencyStr);
        } catch (error) {
          debugLog(
            LogCategory.persistence,
            'Invalid RecurrenceFrequency "$frequencyStr", attempting legacy mapping',
            error: error,
          );
          frequency = _mapLegacyFrequency(frequencyStr);
        }
      }
    } else {
      // Legacy format - infer type from old frequency field or notes
      final notes = (d.getString('notes')?.toLowerCase()) ?? '';

      if (frequencyStr == 'oneTime' ||
          notes.contains('fixed term') ||
          notes.contains('fixed-term')) {
        type = PulseType.oneOff;
        frequency = null;
      } else if (notes.contains('debt')) {
        type = PulseType.debt;
        frequency =
            _mapLegacyFrequency(frequencyStr) ?? RecurrenceFrequency.monthly;
      } else {
        type = PulseType.recurring;
        frequency =
            _mapLegacyFrequency(frequencyStr) ?? RecurrenceFrequency.monthly;
      }
    }

    final remainingBalanceMinorUnits = d.getInt('remainingBalanceMinorUnits') ??
        d.getInt('remainingBalanceCents') ??
        d.getInt('remainingBalance') ??
        d.getInt('balance') ??
        d.getInt('remaining_balance_minor_units');
    final originalAmountMinorUnits = d.getInt('originalAmountMinorUnits') ??
        d.getInt('originalAmountCents') ??
        d.getInt('originalAmount') ??
        d.getInt('original_amount_minor_units');

    // Migration: For existing debts without originalAmountMinorUnits, use remainingBalanceMinorUnits
    final migratedOriginalAmount = originalAmountMinorUnits ??
        (type == PulseType.debt && remainingBalanceMinorUnits != null
            ? remainingBalanceMinorUnits
            : null);

    final potIdStr = d.getString('moneyPotId');

    return TimelineItem(
      id: TimelineItemId(d.getString('id') ?? newIdRaw()),
      label: d.getString('label') ?? 'Untitled',
      amountMinorUnits: amountMinorUnits,
      dayOfMonth: d.getInt('dayOfMonth') ?? 1,
      type: type,
      valueHistory: (json['valueHistory'] as List<dynamic>?)?.map((e) {
        final map = e as Map<String, Object?>;
        return TimelineItemValueChange(
          // Dates are stored as ISO timestamps
          effectiveDate: DateTime.parse(
            map['effectiveDate'] as String,
          ).toLocal(),
          amountMinorUnits: map['amountMinorUnits'] as int,
        );
      }).toList(),
      startDate: d.getIsoDateTime('startDate') ?? DateTime.now(),
      frequency: frequency,
      notes: d.getString('notes'),
      archived: d.getBool('archived') ?? false,
      paidOffDate: d.getIsoDateTime('paidOffDate'),
      remainingBalanceMinorUnits: remainingBalanceMinorUnits,
      originalAmountMinorUnits: migratedOriginalAmount,
      category: d.getString('category') ??
          d.getString('incomeCategory') ??
          d.getString('expenseCategory'),
      subcategory: d.getString('subcategory'),
      origin: d.getString('origin') ?? d.getString('company'),
      priority: _decodePriority(d.getString('priority')),
      suggestedOrigins:
          (json['suggestedOrigins'] as List<dynamic>?)?.cast<String>(),
      isSalary: d.getBool('isSalary') ?? false,
      useAsPaycheckBoundary: d.getBool('useAsPaycheckBoundary') ?? false,
      moneyPotId: potIdStr != null ? MoneyPotId(potIdStr) : null,
      balanceCurrency: decodeCurrency(d.getString('balanceCurrency')),
      exchangeRate: d.getDouble('exchangeRate'),
      useActualsForCurrentBalance: d.getBool('useActualsForCurrentBalance'),
      useActualsForFutureBalance: d.getBool('useActualsForFutureBalance'),
      quickAddAmounts: (json['quickAddAmounts'] as List<dynamic>?)?.cast<int>(),
      transactionCurrency: decodeCurrency(d.getString('transactionCurrency')),
      transactionAmountMinorUnits: d.getInt('transactionAmountMinorUnits'),
      skippedDates: (json['skippedDates'] as List<dynamic>?)
          ?.map(
            (e) => DateTime.fromMillisecondsSinceEpoch(e as int, isUtc: true),
          )
          .toList(),
      pausedDate: d.getIsoDateTime('pausedDate'),
      autoResumeDate: d.getIsoDateTime('autoResumeDate'),
    );
  }

  static RecurrenceFrequency? _mapLegacyFrequency(String? str) {
    if (str == null) return null;
    final lower = str.toLowerCase();
    if (lower.contains('weekly')) {
      if (lower.contains('bi')) return RecurrenceFrequency.biweekly;
      return RecurrenceFrequency.weekly;
    }
    if (lower.contains('monthly')) return RecurrenceFrequency.monthly;
    if (lower.contains('quarterly')) return RecurrenceFrequency.quarterly;
    if (lower.contains('yearly') || lower.contains('annual')) {
      return RecurrenceFrequency.yearly;
    }
    return null;
  }

  static ExpensePriority? _decodePriority(String? str) {
    if (str == null) return null;
    try {
      return ExpensePriority.values.byName(str);
    } catch (_) {
      return null;
    }
  }
}

class PulseEntryCodec {
  static Map<String, Object?> toJson(PulseEntry entry) => {
        'id': entry.id,
        'label': entry.label,
        'amountMinorUnits': entry.amountMinorUnits,
        'date': entry.date.millisecondsSinceEpoch,
        'type': _encodePulseType(entry.type),
        'timelineItemId': entry.timelineItemId,
        'notes': entry.notes,
        'category': entry.category,
        'subcategory': entry.subcategory,
        'origin': entry.origin,
        'company': entry.origin, // Keep for backward compatibility
        'scheduledDate': entry.scheduledDate?.millisecondsSinceEpoch,
        'scheduledAmountMinorUnits': entry.scheduledAmountMinorUnits,
        'moneyPotId': entry.moneyPotId,
        'transactionCurrency': entry.transactionCurrency?.name,
        'transactionAmountMinorUnits': entry.transactionAmountMinorUnits,
        'exchangeRate': entry.exchangeRate,
        // New source tracking fields (omit if default/null for smaller JSON)
        if (entry.source != PulseSource.manual) 'source': entry.source.name,
        if (entry.rawImportDescription != null)
          'rawImportDescription': entry.rawImportDescription,
        if (entry.categorizationConfidence != null)
          'categorizationConfidence': entry.categorizationConfidence,
        if (entry.importReference != null)
          'importReference': entry.importReference,
        if (entry.importMetadata != null)
          'importMetadata': entry.importMetadata,
        if (entry.transferPairId != null)
          'transferPairId': entry.transferPairId,
        if (entry.isInternalTransfer)
          'isInternalTransfer': entry.isInternalTransfer,
      };

  static PulseEntry fromJson(Map<String, Object?> json) {
    final d = MapDecoder(json);
    final millis = d.getInt('date');
    final scheduledDateMillis = d.getInt('scheduledDate');
    final timelineItemIdStr = d.getString('timelineItemId');
    final moneyPotIdStr = d.getString('moneyPotId');

    // Parse source with fallback for backward compatibility
    PulseSource source = PulseSource.manual;
    final sourceStr = d.getString('source');
    if (sourceStr != null) {
      try {
        source = PulseSource.values.byName(sourceStr);
      } catch (e) {
        source = PulseSource.manual; // Fallback for invalid values
      }
    }

    // Migration: reclassify oneOffIncome → oneOff for imported expenses that
    // were misclassified because positive debit amounts looked like income.
    // Only keep oneOffIncome if the category is clearly income-related.
    var type = _decodePulseType(d.getString('type')) ?? PulseType.oneOff;
    if (type == PulseType.oneOffIncome &&
        timelineItemIdStr == null &&
        sourceStr == null) {
      const incomeCategories = {
        'Salary',
        'Income',
        'Refund',
        'Gift',
        'Bonus',
        'Dividend',
        'Interest',
      };
      final category = d.getString('category');
      if (category == null || !incomeCategories.contains(category)) {
        type = PulseType.oneOff;
      }
    }

    return PulseEntry(
      id: EntryId(d.getString('id') ?? newIdRaw()),
      label: d.getString('label') ?? 'Untitled',
      amountMinorUnits: d.getInt('amountMinorUnits') ??
          d.getInt('amountCents') ??
          d.getInt('amount') ??
          d.getInt('cents') ??
          d.getInt('amount_minor_units') ??
          0,
      date: millis != null
          ? DateTime.fromMillisecondsSinceEpoch(millis, isUtc: true).toLocal()
          : DateTime.now(),
      type: type,
      timelineItemId:
          timelineItemIdStr != null ? TimelineItemId(timelineItemIdStr) : null,
      notes: d.getString('notes'),
      category: d.getString('category'),
      subcategory: d.getString('subcategory'),
      origin: d.getString('origin') ?? d.getString('company'),
      scheduledDate: scheduledDateMillis != null
          ? dateOnly(
              DateTime.fromMillisecondsSinceEpoch(
                scheduledDateMillis,
                isUtc: true,
              ),
            )
          : null,
      scheduledAmountMinorUnits: d.getInt('scheduledAmountMinorUnits') ??
          d.getInt('scheduledAmountCents') ??
          d.getInt('scheduledAmount') ??
          d.getInt('scheduled_amount_minor_units'),
      moneyPotId: moneyPotIdStr != null ? MoneyPotId(moneyPotIdStr) : null,
      transactionCurrency: decodeCurrency(d.getString('transactionCurrency')),
      transactionAmountMinorUnits: d.getInt('transactionAmountMinorUnits'),
      exchangeRate: d.getDouble('exchangeRate'),
      // New source tracking fields (defaults ensure backward compatibility)
      source: source,
      rawImportDescription: d.getString('rawImportDescription'),
      categorizationConfidence: d.getDouble('categorizationConfidence'),
      importReference: d.getString('importReference'),
      importMetadata: d.getString('importMetadata'),
      transferPairId: d.getString('transferPairId'),
      isInternalTransfer: d.getBool('isInternalTransfer') ?? false,
    );
  }

  static String _encodePulseType(PulseType type) {
    return switch (type) {
      PulseType.recurring => 'recurring',
      PulseType.recurringIncome => 'recurring-income',
      PulseType.debt => 'debt',
      PulseType.oneOff => 'one-off',
      PulseType.oneOffIncome => 'one-off-income',
      PulseType.spendingEnvelope => 'spending-envelope',
    };
  }

  static PulseType? _decodePulseType(Object? raw) {
    if (raw is! String) return null;
    return switch (raw) {
      'recurring' => PulseType.recurring,
      'recurring-income' => PulseType.recurringIncome,
      'debt' => PulseType.debt,
      'one-off' || 'one_off' || 'oneoff' || 'oneOff' => PulseType.oneOff,
      'one-off-income' || 'oneOffIncome' => PulseType.oneOffIncome,
      'spending-envelope' || 'spendingEnvelope' => PulseType.spendingEnvelope,
      _ => null,
    };
  }
}

class StorageException implements Exception {
  StorageException(this.message);
  final String message;

  @override
  String toString() => 'StorageException: $message';
}
