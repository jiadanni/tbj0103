import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';

/// Result type for storage operations that can distinguish between
/// missing data and storage failures.
sealed class StorageResult<T> {
  const StorageResult();
}

/// Data was found and successfully read.
class StorageSuccess<T> extends StorageResult<T> {
  const StorageSuccess(this.value);
  final T value;
}

/// Key was not found (no data stored for this key).
class StorageNotFound<T> extends StorageResult<T> {
  const StorageNotFound();
}

/// Storage operation failed due to an error.
class StorageFailure<T> extends StorageResult<T> {
  const StorageFailure(this.error, [this.stackTrace]);
  final Object error;
  final StackTrace? stackTrace;
}

/// Encrypted storage provider using `flutter_secure_storage`.
///
/// Stores values securely in the platform-provided secure store (Keychain/Keystore).
class EncryptedStorageProvider implements StorageProvider {
  EncryptedStorageProvider._(this._storage);

  final FlutterSecureStorage _storage;

  /// Create an instance. An optional [storage] may be provided for testing.
  ///
  /// Uses platform-specific secure storage options:
  /// - **iOS**: `first_unlock_this_device` - data only accessible after first device
  ///   unlock and never leaves device (not included in backups). This is the most
  ///   secure option for financial data.
  /// - **Android**: EncryptedSharedPreferences with AES256 encryption.
  ///
  /// Note: Data stored with these settings won't survive device migration.
  /// Users should use the app's export feature to backup data before switching devices.
  static Future<EncryptedStorageProvider> create({
    FlutterSecureStorage? storage,
  }) async {
    final storageInstance = storage ??
        const FlutterSecureStorage(
          iOptions: IOSOptions(
            accessibility: KeychainAccessibility.first_unlock_this_device,
          ),
          aOptions: AndroidOptions(
              // encryptedSharedPreferences: true, // Deprecated and ignored in newer versions
              ),
        );
    return EncryptedStorageProvider._(storageInstance);
  }

  /// Get a string with detailed result type.
  /// Use this when you need to distinguish between missing data and storage errors.
  Future<StorageResult<String>> getStringResult(String key) async {
    try {
      final value = await _storage.read(key: key);
      if (value == null) {
        return const StorageNotFound();
      }
      return StorageSuccess(value);
    } catch (error, stackTrace) {
      _trackStorageError('read', key, error, stackTrace);
      return StorageFailure(error, stackTrace);
    }
  }

  @override
  Future<String?> getString(String key) async {
    final result = await getStringResult(key);
    return switch (result) {
      StorageSuccess(:final value) => value,
      StorageNotFound() => null,
      StorageFailure(:final error, :final stackTrace) => _handleError(
          'getString',
          key,
          error,
          stackTrace,
        ),
    };
  }

  @override
  Future<bool> setString(String key, String value) async {
    try {
      await _storage.write(key: key, value: value);
      return true;
    } catch (error, stackTrace) {
      _trackStorageError('write', key, error, stackTrace);
      return false;
    }
  }

  @override
  Future<List<String>?> getStringList(String key) async {
    final s = await getString(key);
    if (s == null) return null;
    try {
      final decoded = jsonDecode(s) as List;
      return decoded.map((e) => e.toString()).toList();
    } catch (error, stackTrace) {
      _trackStorageError('decode_list', key, error, stackTrace);
      return null;
    }
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    return setString(key, jsonEncode(value));
  }

  @override
  Future<int?> getInt(String key) async {
    final s = await getString(key);
    if (s == null) return null;
    return int.tryParse(s);
  }

  @override
  Future<bool> setInt(String key, int value) async {
    return setString(key, value.toString());
  }

  @override
  Future<bool?> getBool(String key) async {
    final s = await getString(key);
    if (s == null) return null;
    if (s == '1' || s.toLowerCase() == 'true') return true;
    if (s == '0' || s.toLowerCase() == 'false') return false;
    return null;
  }

  @override
  Future<bool> setBool(String key, bool value) async {
    return setString(key, value ? '1' : '0');
  }

  @override
  Future<bool> remove(String key) async {
    try {
      await _storage.delete(key: key);
      return true;
    } catch (error, stackTrace) {
      _trackStorageError('delete', key, error, stackTrace);
      return false;
    }
  }

  /// Track storage errors to ErrorTracker for debugging.
  void _trackStorageError(
    String operation,
    String key,
    Object error,
    StackTrace stackTrace,
  ) {
    ErrorTracker.instance.trackException(
      'encrypted_storage',
      'Encrypted storage $operation failed for key: $key',
      error,
      stackTrace,
      severity: ErrorSeverity.error,
      additionalData: {'operation': operation, 'key': key},
    );

    // Also log to console in debug mode
    if (kDebugMode) {
      debugPrint(
        '⚠️ EncryptedStorage: $operation failed for key "$key": $error',
      );
    }
  }

  /// Handle errors for nullable return methods - logs and returns null.
  T? _handleError<T>(
    String method,
    String key,
    Object error,
    StackTrace? stackTrace,
  ) {
    // Error already tracked in getStringResult, just return null for backwards compatibility
    return null;
  }
}
