import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

/// Handles export/import of global app settings (excluding account-specific data).
///
/// Exported settings include:
/// - Theme settings (theme mode, colors, fonts, text scale)
/// - Currency settings (primary currency, enabled currencies, exchange rates)
/// - Timeline display settings (view mode, swipe actions, display options)
/// - Global money pots (those not bound to specific accounts)
///
/// Excluded (account-specific):
/// - Account names and IDs
/// - Paycheck day and adjustment settings
/// - Starting balance
/// - Money pots bound to specific accounts
class SettingsExport {
  const SettingsExport._();

  static const int kSettingsExportVersion = 1;

  /// Export global settings to JSON map.
  static Map<String, dynamic> toJson(AppSettingsStore store) {
    return {
      'version': kSettingsExportVersion,
      'exportDate': DateTime.now().toUtc().toIso8601String(),
      'theme': _themeToJson(store),
      'currency': _currencyToJson(store),
      'timeline': _timelineToJson(store),
      'moneyPots': _moneyPotsToJson(store),
      'regionPresetId': store.regionPresetId,
      'syncSettingsAcrossAccounts': store.syncSettingsAcrossAccounts,
    };
  }

  /// Import settings from JSON map and apply to store.
  ///
  /// Returns true if import was successful, false otherwise.
  static Future<bool> applyFromJson(
    AppSettingsStore store,
    Map<String, dynamic> json,
  ) async {
    try {
      final version = json['version'] as int? ?? 1;
      if (version > kSettingsExportVersion) {
        throw FormatException('Unsupported settings export version: $version');
      }

      // Apply theme settings
      final theme = json['theme'] as Map<String, dynamic>?;
      if (theme != null) {
        _applyThemeFromJson(store, theme);
      }

      // Apply currency settings
      final currency = json['currency'] as Map<String, dynamic>?;
      if (currency != null) {
        _applyCurrencyFromJson(store, currency);
      }

      // Apply timeline settings
      final timeline = json['timeline'] as Map<String, dynamic>?;
      if (timeline != null) {
        _applyTimelineFromJson(store, timeline);
      }

      // Apply money pots (only global ones)
      final moneyPots = json['moneyPots'] as List<dynamic>?;
      if (moneyPots != null) {
        await _applyMoneyPotsFromJson(store, moneyPots);
      }

      // Apply region preset
      final regionPresetId = json['regionPresetId'] as String?;
      if (regionPresetId != null) {
        store.regionPresetId = regionPresetId;
      }

      // Apply sync settings preference
      final syncSettings = json['syncSettingsAcrossAccounts'] as bool?;
      if (syncSettings != null) {
        store.syncSettingsAcrossAccounts = syncSettings;
      }

      return true;
    } catch (_) {
      return false;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Theme Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  static Map<String, dynamic> _themeToJson(AppSettingsStore store) {
    return {
      // Note: themeMode removed - each theme now defines its own brightness (immersive themes)
      'useCustomColors': store.useCustomColors,
      'appThemePreset': AppSettingsCodecs.encodeAppThemePreset(
        store.appThemePreset,
      ),
      // ignore: deprecated_member_use
      'debitColor': store.debitColor.value,
      // ignore: deprecated_member_use
      'creditColor': store.creditColor.value,
      // ignore: deprecated_member_use
      'neutralColor': store.neutralColor.value,
      'textScalePreset': AppSettingsCodecs.encodeTextScalePreset(
        store.textScalePreset,
      ),
      'fontPreset': AppSettingsCodecs.encodeFontPreset(store.fontPreset),
    };
  }

  static void _applyThemeFromJson(
    AppSettingsStore store,
    Map<String, dynamic> json,
  ) {
    // Note: themeMode import skipped - each theme now defines its own brightness (immersive themes)

    final useCustomColors = json['useCustomColors'] as bool?;
    if (useCustomColors != null) store.useCustomColors = useCustomColors;

    final appThemePreset = AppSettingsCodecs.decodeAppThemePreset(
      json['appThemePreset'] as String?,
    );
    if (appThemePreset != null) store.appThemePreset = appThemePreset;

    final debitColor = json['debitColor'] as int?;
    // ignore: deprecated_member_use
    if (debitColor != null) store.debitColor = Color(debitColor);

    final creditColor = json['creditColor'] as int?;
    // ignore: deprecated_member_use
    if (creditColor != null) store.creditColor = Color(creditColor);

    final neutralColor = json['neutralColor'] as int?;
    // ignore: deprecated_member_use
    if (neutralColor != null) store.neutralColor = Color(neutralColor);

    final textScalePreset = AppSettingsCodecs.decodeTextScalePreset(
      json['textScalePreset'] as String?,
    );
    if (textScalePreset != null) store.textScalePreset = textScalePreset;

    final fontPreset = AppSettingsCodecs.decodeFontPreset(
      json['fontPreset'] as String?,
    );
    if (fontPreset != null) store.fontPreset = fontPreset;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Currency Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  static Map<String, dynamic> _currencyToJson(AppSettingsStore store) {
    return {
      'currency': encodeCurrency(store.currency),
      'showCents': store.showCents,
      'roundingIncrement': store.roundingIncrement,
      'autoUpdateRates': store.autoUpdateRates,
      'enabledCurrencies': store.enabledCurrencies.map(encodeCurrency).toList(),
      'exchangeRates': store.exchangeRates.map(
        (k, v) => MapEntry(encodeCurrency(k), v),
      ),
    };
  }

  static void _applyCurrencyFromJson(
    AppSettingsStore store,
    Map<String, dynamic> json,
  ) {
    final currency = decodeCurrency(json['currency'] as String?);
    if (currency != null) store.currency = currency;

    final showCents = json['showCents'] as bool?;
    if (showCents != null) store.showCents = showCents;

    final roundingIncrement = json['roundingIncrement'] as int?;
    if (roundingIncrement != null) store.roundingIncrement = roundingIncrement;

    final autoUpdateRates = json['autoUpdateRates'] as bool?;
    if (autoUpdateRates != null) store.autoUpdateRates = autoUpdateRates;

    final enabledCurrencies = json['enabledCurrencies'] as List<dynamic>?;
    if (enabledCurrencies != null) {
      // First, add all from import
      for (final currencyStr in enabledCurrencies) {
        final c = decodeCurrency(currencyStr as String?);
        if (c != null) store.enableCurrency(c);
      }
    }

    final exchangeRates = json['exchangeRates'] as Map<String, dynamic>?;
    if (exchangeRates != null) {
      final rates = <AppCurrency, double>{};
      exchangeRates.forEach((key, value) {
        final c = decodeCurrency(key);
        if (c != null && value is num) {
          rates[c] = value.toDouble();
        }
      });
      if (rates.isNotEmpty) {
        store.updateAllExchangeRates(rates);
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Timeline Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  static Map<String, dynamic> _timelineToJson(AppSettingsStore store) {
    return {
      'dayFormat': AppSettingsCodecs.encodeDayFormat(store.dayFormat),
      'timelineSwipeLeft': AppSettingsCodecs.encodeSwipeAction(
        store.timelineSwipeLeft,
      ),
      'timelineSwipeRight': AppSettingsCodecs.encodeSwipeAction(
        store.timelineSwipeRight,
      ),
      'timelineTapAction': AppSettingsCodecs.encodeTimelineTapAction(
        store.timelineTapAction,
      ),
      'pulseSwipeLeft': AppSettingsCodecs.encodePulseSwipeAction(
        store.pulseSwipeLeft,
      ),
      'pulseSwipeRight': AppSettingsCodecs.encodePulseSwipeAction(
        store.pulseSwipeRight,
      ),
      'pulseDisplayMode': AppSettingsCodecs.encodePulseDisplayMode(
        store.pulseDisplayMode,
      ),
      'enableTabSwipe': store.enableTabSwipe,
      'timelineUseZeroBaseline': store.timelineUseZeroBaseline,
      'timelineShowClearedItems': store.timelineShowClearedItems,
      'timelineSortOrder': AppSettingsCodecs.encodeSortOrder(
        store.timelineSortOrder,
      ),
      'timelineDateSortMode': AppSettingsCodecs.encodeTimelineDateSortMode(
        store.timelineDateSortMode,
      ),
      'timelineGroupByDate': store.timelineGroupByDate,
      'timelineGroupByTheme': store.timelineGroupByTheme,
      'timelineShowPulseOrigin': store.timelineShowPulseOrigin,
      'monthCardDisplayMode': AppSettingsCodecs.encodeMonthCardDisplayMode(
        store.monthCardDisplayMode,
      ),
      'monthTotalsDisplayMode': AppSettingsCodecs.encodeMonthTotalsDisplayMode(
        store.monthTotalsDisplayMode,
      ),
      'multiMonthDisplayMode': AppSettingsCodecs.encodeMultiMonthDisplayMode(
        store.multiMonthDisplayMode,
      ),
      'terminologyPreset': AppSettingsCodecs.encodeTerminologyPreset(
        store.terminologyPreset,
      ),
      'timelineViewMode': AppSettingsCodecs.encodeTimelineViewMode(
        store.timelineViewMode,
      ),
      'pulseFilterType': AppSettingsCodecs.encodePulsesFilterType(
        store.pulseFilterType,
      ),
      'pulseGroupBy': AppSettingsCodecs.encodePulsesGroupBy(store.pulseGroupBy),
      'pulseShowArchived': store.pulseShowArchived,
      'categoryPresetMode': AppSettingsCodecs.encodeCategoryPresetMode(
        store.categoryPresetMode,
      ),
      'customPulseLabel': store.customPulseLabel,
      'customTimelineLabel': store.customTimelineLabel,
    };
  }

  static void _applyTimelineFromJson(
    AppSettingsStore store,
    Map<String, dynamic> json,
  ) {
    final dayFormat = AppSettingsCodecs.decodeDayFormat(
      json['dayFormat'] as String?,
    );
    if (dayFormat != null) store.dayFormat = dayFormat;

    final timelineSwipeLeft = AppSettingsCodecs.decodeSwipeAction(
      json['timelineSwipeLeft'] as String?,
    );
    if (timelineSwipeLeft != null) store.timelineSwipeLeft = timelineSwipeLeft;

    final timelineSwipeRight = AppSettingsCodecs.decodeSwipeAction(
      json['timelineSwipeRight'] as String?,
    );
    if (timelineSwipeRight != null) {
      store.timelineSwipeRight = timelineSwipeRight;
    }

    final timelineTapAction = AppSettingsCodecs.decodeTimelineTapAction(
      json['timelineTapAction'] as String?,
    );
    if (timelineTapAction != null) store.timelineTapAction = timelineTapAction;

    final pulseSwipeLeft = AppSettingsCodecs.decodePulseSwipeAction(
      json['pulseSwipeLeft'] as String?,
    );
    if (pulseSwipeLeft != null) store.pulseSwipeLeft = pulseSwipeLeft;

    final pulseSwipeRight = AppSettingsCodecs.decodePulseSwipeAction(
      json['pulseSwipeRight'] as String?,
    );
    if (pulseSwipeRight != null) store.pulseSwipeRight = pulseSwipeRight;

    final pulseDisplayMode = AppSettingsCodecs.decodePulseDisplayMode(
      json['pulseDisplayMode'] as String?,
    );
    if (pulseDisplayMode != null) store.pulseDisplayMode = pulseDisplayMode;

    final enableTabSwipe = json['enableTabSwipe'] as bool?;
    if (enableTabSwipe != null) store.enableTabSwipe = enableTabSwipe;

    final timelineUseZeroBaseline = json['timelineUseZeroBaseline'] as bool?;
    if (timelineUseZeroBaseline != null) {
      store.timelineUseZeroBaseline = timelineUseZeroBaseline;
    }

    final timelineShowClearedItems = json['timelineShowClearedItems'] as bool?;
    if (timelineShowClearedItems != null) {
      store.timelineShowClearedItems = timelineShowClearedItems;
    }

    final timelineSortOrder = AppSettingsCodecs.decodeSortOrder(
      json['timelineSortOrder'] as String?,
    );
    if (timelineSortOrder != null) store.timelineSortOrder = timelineSortOrder;

    final timelineDateSortMode = AppSettingsCodecs.decodeTimelineDateSortMode(
      json['timelineDateSortMode'] as String?,
    );
    if (timelineDateSortMode != null) {
      store.timelineDateSortMode = timelineDateSortMode;
    }

    final timelineGroupByDate = json['timelineGroupByDate'] as bool?;
    if (timelineGroupByDate != null) {
      store.timelineGroupByDate = timelineGroupByDate;
    }

    final timelineGroupByTheme = json['timelineGroupByTheme'] as bool?;
    if (timelineGroupByTheme != null) {
      store.timelineGroupByTheme = timelineGroupByTheme;
    }

    final timelineShowPulseOrigin = json['timelineShowPulseOrigin'] as bool?;
    if (timelineShowPulseOrigin != null) {
      store.timelineShowPulseOrigin = timelineShowPulseOrigin;
    }

    final monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(
      json['monthCardDisplayMode'] as String?,
    );
    if (monthCardDisplayMode != null) {
      store.monthCardDisplayMode = monthCardDisplayMode;
    }

    final monthTotalsDisplayMode =
        AppSettingsCodecs.decodeMonthTotalsDisplayMode(
      json['monthTotalsDisplayMode'] as String?,
    );
    if (monthTotalsDisplayMode != null) {
      store.monthTotalsDisplayMode = monthTotalsDisplayMode;
    }

    final multiMonthDisplayMode = AppSettingsCodecs.decodeMultiMonthDisplayMode(
      json['multiMonthDisplayMode'] as String?,
    );
    if (multiMonthDisplayMode != null) {
      store.multiMonthDisplayMode = multiMonthDisplayMode;
    }

    final terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(
      json['terminologyPreset'] as String?,
    );
    if (terminologyPreset != null) store.terminologyPreset = terminologyPreset;

    final timelineViewMode = AppSettingsCodecs.decodeTimelineViewMode(
      json['timelineViewMode'] as String?,
    );
    if (timelineViewMode != null) store.timelineViewMode = timelineViewMode;

    final pulseFilterType = AppSettingsCodecs.decodePulsesFilterType(
      json['pulseFilterType'] as String?,
    );
    if (pulseFilterType != null) store.pulseFilterType = pulseFilterType;

    final pulseGroupBy = AppSettingsCodecs.decodePulsesGroupBy(
      json['pulseGroupBy'] as String?,
    );
    if (pulseGroupBy != null) store.pulseGroupBy = pulseGroupBy;

    final pulseShowArchived = json['pulseShowArchived'] as bool?;
    if (pulseShowArchived != null) store.pulseShowArchived = pulseShowArchived;

    final categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(
      json['categoryPresetMode'] as String?,
    );
    if (categoryPresetMode != null) {
      store.categoryPresetMode = categoryPresetMode;
    }

    final customPulseLabel = json['customPulseLabel'] as String?;
    if (customPulseLabel != null) store.customPulseLabel = customPulseLabel;

    final customTimelineLabel = json['customTimelineLabel'] as String? ??
        json['customActivityLabel'] as String?;
    if (customTimelineLabel != null) {
      store.customTimelineLabel = customTimelineLabel;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Money Pots Export/Import
  // ─────────────────────────────────────────────────────────────────────────

  static List<Map<String, dynamic>> _moneyPotsToJson(AppSettingsStore store) {
    // Only export global money pots (those with null or empty accountIds)
    final globalPots = store.moneyPotsSettings.moneyPots.where((pot) {
      return pot.accountIds == null || pot.accountIds!.isEmpty;
    });

    return globalPots.map((pot) => pot.toJson()).toList();
  }

  static Future<void> _applyMoneyPotsFromJson(
    AppSettingsStore store,
    List<dynamic> json,
  ) async {
    for (final potJson in json) {
      if (potJson is Map<String, dynamic>) {
        try {
          final pot = MoneyPot.fromJson(potJson);
          // Only add if not already present and is global
          if (pot.accountIds == null || pot.accountIds!.isEmpty) {
            final exists = store.moneyPotsSettings.moneyPots.any(
              (p) => p.id == pot.id,
            );
            if (!exists) {
              await store.addMoneyPot(pot);
            }
          }
        } catch (_) {
          // Skip invalid pot entries
        }
      }
    }
  }
}
