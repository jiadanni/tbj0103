/// Configuration for storage encryption.
///
/// Set `kEnableEncryption` to `true` to enable encrypted storage. When
/// enabled the app uses an encrypted backend (flutter_secure_storage) for
/// sensitive values and migrates known plaintext keys from SharedPreferences
/// into the encrypted store on first run.
///
/// **Current Status**: Encryption is ENABLED. The code uses
/// `EncryptedStorageProvider` by default.
///
/// Notes and implications:
/// - Migration: On first run with encryption enabled the app will attempt to
///   migrate a set of known keys from SharedPreferences into secure storage
///   using `StorageMigration`. Migration is best-effort and retried on next
///   launch if incomplete; see StorageMigration for details.
/// - Developer workflow: If you are developing and do not want encryption
///   enabled locally, set `kEnableEncryption` to `false`. Be careful when
///   toggling this flag after users have data — toggling may trigger
///   migration behavior.
/// - Ensure `flutter_secure_storage` is present in `pubspec.yaml` when
///   encryption is enabled.
///
library;

/// Feature flag for storage encryption. When `true` the app uses
/// `EncryptedStorageProvider` and will perform migration from plaintext
/// SharedPreferences when needed.
const bool kEnableEncryption = true;
