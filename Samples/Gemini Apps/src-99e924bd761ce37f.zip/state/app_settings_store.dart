import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_presets.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/memory_storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/timeline_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';
import 'package:expense_stalker_mobile/src/state/settings/insight_settings.dart';

export 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
export 'package:expense_stalker_mobile/src/state/settings/theme_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/currency_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/timeline_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/money_pots_settings.dart';
export 'package:expense_stalker_mobile/src/state/settings/insight_settings.dart';

class AppSettingsStore extends ChangeNotifier {
  AppSettingsStore._(
    this._storage,
    this.themeSettings,
    this.currencySettings,
    this.timelineSettings,
    this.moneyPotsSettings,
    this.insightSettings,
    this._regionPresetId,
    this._syncSettingsAcrossAccounts,
  ) {
    // Initialize selective notifiers with default values
    timelineShowClearedItemsNotifier = ValueNotifier<bool>(true);
    timelineViewModeNotifier = ValueNotifier<TimelineViewMode>(
      TimelineViewMode.month,
    );
    monthCardDisplayModeNotifier = ValueNotifier<MonthCardDisplayMode>(
      MonthCardDisplayMode.full,
    );

    themeSettings.addListener(notifyListeners);
    currencySettings.addListener(notifyListeners);
    timelineSettings.addListener(() {
      _updateSelectiveNotifiers();
      notifyListeners();
    });
    moneyPotsSettings.addListener(notifyListeners);
    insightSettings.addListener(notifyListeners);
  }

  final StorageProvider _storage;

  final ThemeSettings themeSettings;
  final CurrencySettings currencySettings;
  final TimelineSettings timelineSettings;
  final MoneyPotsSettings moneyPotsSettings;
  final InsightSettings insightSettings;

  String _regionPresetId;
  bool _syncSettingsAcrossAccounts;

  // Reference to ExpenseStore for account-specific settings delegation
  ExpenseStore? _expenseStore;

  // Listener callback stored for proper cleanup on dispose
  VoidCallback? _expenseStoreListener;

  // Selective notifiers for hot properties (granular listening)
  late final ValueNotifier<bool> timelineShowClearedItemsNotifier;
  late final ValueNotifier<TimelineViewMode> timelineViewModeNotifier;
  late final ValueNotifier<MonthCardDisplayMode> monthCardDisplayModeNotifier;

  /// Bind the ExpenseStore after both are initialized.
  /// This allows paycheck settings to be read from the current account.
  void bindExpenseStore(ExpenseStore store) {
    // Remove any previous listener if re-binding (defensive)
    if (_expenseStoreListener != null && _expenseStore != null) {
      _expenseStore!.removeListener(_expenseStoreListener!);
    }

    _expenseStore = store;
    // Initialize with current account
    timelineSettings.setAccountId(store.currentAccount.id);
    insightSettings.setAccountId(store.currentAccount.id);
    // Initial migration: move any pots stored in accounts to global moneyPotsSettings
    // if they aren't already there.
    for (final account in store.accounts) {
      if (account.moneyPots.isNotEmpty) {
        for (final pot in account.moneyPots) {
          final exists = moneyPotsSettings.moneyPots.any((p) => p.id == pot.id);
          if (!exists) {
            moneyPotsSettings.addMoneyPot(
              pot.copyWith(accountIds: Optional([account.id])),
            );
          }
        }
      }
    }

    // Initialize selective notifiers with current account values immediately
    _updateSelectiveNotifiers();

    // Create and store the listener callback for proper cleanup
    _expenseStoreListener = _onExpenseStoreChanged;
    store.addListener(_expenseStoreListener!);
  }

  /// Callback for ExpenseStore changes. Named method for proper removeListener cleanup.
  void _onExpenseStoreChanged() {
    final nextId = _expenseStore?.currentAccount.id;
    if (nextId != null && timelineSettings.accountId != nextId) {
      // Propagate account change to timeline settings
      // This will call notifyListeners() when it finishes loading settings
      timelineSettings.setAccountId(nextId);
      insightSettings.setAccountId(nextId);
      _updateSelectiveNotifiers(); // Update with new account settings
    } else {
      // If the account didn't change, we still notify so proxied
      // properties (like timelineSortOrder) are seen as updated by listeners.
      _updateSelectiveNotifiers(); // Update in case account properties changed
      notifyListeners();
    }
  }

  static const _kRegionPreset = 'settings.regionPreset';

  // Forward keys for loadOrCreate convenience (though usage is internal now)
  static const _kCurrency = 'settings.currency';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';
  static const _kDayFormat = 'settings.dayFormat';
  static const _kTimelineSwipeLeft = 'settings.timeline.swipeLeft';
  static const _kTimelineSwipeRight = 'settings.timeline.swipeRight';
  static const _kTimelineTapAction = 'settings.timeline.tapAction';
  static const _kPulseSwipeLeft = 'settings.pulse.swipeLeft';
  static const _kPulseSwipeRight = 'settings.pulse.swipeRight';
  static const _kPulseDisplayMode = 'settings.pulse.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kTimelineUseZeroBaseline = 'settings.timeline.useZeroBaseline';
  static const _kTimelineShowClearedItems =
      'settings.timeline.showClearedItems';
  static const _kTimelineShowSkippedItems =
      'settings.timeline.showSkippedItems';
  static const _kTimelineSortOrder = 'settings.timeline.sortOrder';
  static const _kTimelineDateSortMode = 'settings.timeline.dateSortMode';

  static const _kColorPreset = 'settings.colors.preset';
  static const _kUseCustomColors = 'settings.colors.useCustomColors';
  static const _kAppThemePreset = 'settings.colors.appThemePreset';
  static const _kDebitColor = 'settings.colors.debit';
  static const _kCreditColor = 'settings.colors.credit';
  static const _kNeutralColor = 'settings.colors.neutral';
  static const _kTimelineGroupByDate = 'settings.timeline.groupByDate';
  static const _kTimelineGroupByTheme = 'settings.timeline.groupByTheme';
  static const _kTimelineShowPulseOrigin = 'settings.timeline.showPulseOrigin';

  static const _kMonthCardDisplayMode =
      'settings.timeline.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode =
      'settings.timeline.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayMode =
      'settings.timeline.multiMonthDisplayMode';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kTextScalePreset = 'settings.textScale';
  static const _kFontPreset = 'settings.fontPreset';
  static const _kTimelineViewMode = 'settings.timeline.viewMode';
  static const _kShowCents = 'settings.currency.showCents';
  static const _kRoundingIncrement = 'settings.currency.roundingIncrement';
  static const _kPulsesFilterType = 'settings.pulse.filterType';
  static const _kPulsesGroupBy = 'settings.pulse.groupBy';
  static const _kPulsesShowArchived = 'settings.pulse.showArchived';
  static const _kCategoryPresetMode = 'settings.timeline.categoryPresetMode';
  static const _kMoneyPots = 'settings.moneyPots';
  static const _kMoneyPotsSectionLabel = 'settings.moneyPots.sectionLabel';
  static const _kMoneyPotsShowForeignCurrencyDebtInAppCurrency =
      'settings.moneyPots.showForeignCurrencyDebtInAppCurrency';
  static const _kMoneyPotsCollapsed = 'settings.moneyPots.collapsed';
  static const _kMoneyPotsGridColumns = 'settings.moneyPots.gridColumns';
  static const _kMoneyPotsMaxVisibleRows = 'settings.moneyPots.maxVisibleRows';
  static const _kEnabledCurrencies = 'settings.currency.enabledCurrencies';
  static const _kExchangeRates = 'settings.currency.exchangeRates';
  static const _kAutoUpdateRates = 'settings.currency.autoUpdateRates';
  static const _kSyncSettingsAcrossAccounts =
      'settings.syncSettingsAcrossAccounts';
  static const _kCustomPulseLabel = 'settings.terminology.customPulseLabel';
  static const _kCustomTimelineLabel =
      'settings.terminology.customTimelineLabel';
  static const _kCustomActivityLabel =
      'settings.terminology.customActivityLabel';
  static const _kRandomizeColorOnResume = 'settings.colors.randomizeOnResume';
  static const _kRandomizeColorOnPeriodChange =
      'settings.colors.randomizeOnPeriodChange';

  static const _kInsightDismissedIds = 'settings.insights.dismissedIds';
  static const _kInsightPinnedIds = 'settings.insights.pinnedIds';
  static const _kInsightMinDataDaysOverride =
      'settings.insights.minDataDaysOverride';
  static const _kShowBehavioralInsights =
      'settings.insights.showBehavioralInsights';
  static const _kIncludeInternalTransfersInReports =
      'settings.insights.includeInternalTransfers';

  // ===========================================================================
  // Static Data Access Accessors (Delegated)
  // ===========================================================================

  // ===========================================================================
  // Proxied Getters
  // ===========================================================================

  String get regionPresetId => _regionPresetId;
  List<RegionPreset> get regionPresets => AppSettingsPresets.regionPresets;
  RegionPreset get regionPreset =>
      AppSettingsPresets.regionPresetForId(_regionPresetId);

  // Theme Proxies
  bool get useCustomColors => themeSettings.useCustomColors;
  AppThemePreset get appThemePreset => themeSettings.appThemePreset;
  Color get debitColor => themeSettings.debitColor;
  Color get creditColor => themeSettings.creditColor;
  Color get neutralColor => themeSettings.neutralColor;
  Color get themeSeedColor => themeSettings.themeSeedColor;
  TextScalePreset get textScalePreset => themeSettings.textScalePreset;
  FontPreset get fontPreset => themeSettings.fontPreset;
  double get textScaleFactor => themeSettings.textScaleFactor;
  String? get fontFamily => themeSettings.fontFamily;
  bool get randomizeColorOnResume => themeSettings.randomizeColorOnResume;
  bool get randomizeColorOnPeriodChange =>
      themeSettings.randomizeColorOnPeriodChange;
  ThemePalette get themePalette => themeSettings.themePalette;

  // Currency Proxies
  AppCurrency get currency => currencySettings.currency;
  int get currentBalanceCents =>
      _expenseStore?.currentAccount.currentBalanceCents ??
      currencySettings.currentBalanceCents;
  bool get showCents => currencySettings.showCents;
  int get roundingIncrement => currencySettings.roundingIncrement;
  Set<AppCurrency> get enabledCurrencies => currencySettings.enabledCurrencies;
  Map<AppCurrency, double> get exchangeRates => currencySettings.exchangeRates;
  bool get autoUpdateRates => currencySettings.autoUpdateRates;

  // Timeline Proxies
  // Timeline Proxies - Account specific with global fallback
  DayFormat get dayFormat =>
      _expenseStore?.currentAccount.dayFormat ?? timelineSettings.dayFormat;
  TimelineSwipeAction get timelineSwipeLeft =>
      _expenseStore?.currentAccount.timelineSwipeLeft ??
      timelineSettings.timelineSwipeLeft;
  TimelineSwipeAction get timelineSwipeRight =>
      _expenseStore?.currentAccount.timelineSwipeRight ??
      timelineSettings.timelineSwipeRight;
  TimelineTapAction get timelineTapAction =>
      _expenseStore?.currentAccount.timelineTapAction ??
      timelineSettings.timelineTapAction;
  PulseSwipeAction get pulseSwipeLeft =>
      _expenseStore?.currentAccount.pulseSwipeLeft ??
      timelineSettings.pulseSwipeLeft;
  PulseSwipeAction get pulseSwipeRight =>
      _expenseStore?.currentAccount.pulseSwipeRight ??
      timelineSettings.pulseSwipeRight;
  PulseDisplayMode get pulseDisplayMode =>
      _expenseStore?.currentAccount.pulseDisplayMode ??
      timelineSettings.pulseDisplayMode;
  bool get enableTabSwipe =>
      _expenseStore?.currentAccount.enableTabSwipe ??
      timelineSettings.enableTabSwipe;
  bool get timelineUseZeroBaseline =>
      _expenseStore?.currentAccount.timelineUseZeroBaseline ??
      timelineSettings.timelineUseZeroBaseline;
  bool get timelineShowClearedItems =>
      _expenseStore?.currentAccount.timelineShowClearedItems ??
      timelineSettings.timelineShowClearedItems;
  bool get timelineShowSkippedItems =>
      _expenseStore?.currentAccount.timelineShowSkippedItems ??
      timelineSettings.timelineShowSkippedItems;
  bool get timelineShowIncome => timelineSettings.timelineShowIncome;
  bool get timelineShowExpense => timelineSettings.timelineShowExpense;
  TimelineSortOrder get timelineSortOrder =>
      _expenseStore?.currentAccount.timelineSortOrder ??
      timelineSettings.timelineSortOrder;
  TimelineDateSortMode get timelineDateSortMode =>
      _expenseStore?.currentAccount.timelineDateSortMode ??
      timelineSettings.timelineDateSortMode;

  // ViewPeriodMode is account-specific
  ViewPeriodMode get viewPeriodMode =>
      _expenseStore?.currentAccount.viewPeriodMode ?? ViewPeriodMode.calendar;

  // Account-specific settings - these are ONLY stored in the Account model
  // If no account is loaded, we return sensible defaults but cannot persist changes
  int? get paycheckDay => _expenseStore?.currentAccount.paycheckDay;
  bool get isPaycheckModeConfigured => paycheckDay != null;
  bool get paycheckBusinessAdjust =>
      _expenseStore?.currentAccount.paycheckBusinessAdjust ?? true;
  PaycheckAdjustDirection get paycheckBusinessAdjustDirection =>
      _expenseStore?.currentAccount.paycheckBusinessAdjustDirection ??
      PaycheckAdjustDirection.after;
  bool get paycheckShowMonthInTimeline =>
      _expenseStore?.currentAccount.paycheckShowMonthInTimeline ?? false;
  int get startingBalanceCents =>
      _expenseStore?.currentAccount.startingBalanceCents ?? 0;
  bool get timelineGroupByDate =>
      _expenseStore?.currentAccount.timelineGroupByDate ??
      timelineSettings.timelineGroupByDate;
  bool get timelineGroupByTheme =>
      _expenseStore?.currentAccount.timelineGroupByTheme ??
      timelineSettings.timelineGroupByTheme;
  bool get timelineSplitClearedAndPending =>
      _expenseStore?.currentAccount.timelineSplitClearedAndPending ??
      timelineSettings.timelineSplitClearedAndPending; // [NEW]
  bool get timelineShowSubcategories =>
      _expenseStore?.currentAccount.timelineShowSubcategories ??
      timelineSettings.timelineShowSubcategories; // [NEW]
  bool getTimelineShowPulseOrigin(TimelineViewMode mode) {
    return _expenseStore?.currentAccount.getTimelineShowPulseOrigin(mode) ??
        timelineSettings.getTimelineShowPulseOrigin(mode);
  }

  // Insight settings - Account specific with global fallback
  Set<String> get dismissedInsightIds =>
      _expenseStore?.currentAccount.settings.dismissedInsightIds ??
      insightSettings.dismissedInsightIds;

  bool get includeInternalTransfersInReports =>
      _expenseStore?.currentAccount.settings.includeInternalTransfers ??
      insightSettings.includeInternalTransfers;

  set includeInternalTransfersInReports(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateAccountSettings(
        _expenseStore!.currentAccount.id,
        includeInternalTransfers: value,
      );
    } else {
      insightSettings.includeInternalTransfers = value;
    }
  }

  Set<String> get pinnedInsightIds =>
      _expenseStore?.currentAccount.settings.pinnedInsightIds ??
      insightSettings.pinnedInsightIds;

  bool get timelineShowPulseOrigin {
    final mode = timelineViewMode;
    return getTimelineShowPulseOrigin(mode);
  }

  MonthCardDisplayMode get monthCardDisplayMode =>
      _expenseStore?.currentAccount.monthCardDisplayMode ??
      timelineSettings.monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode =>
      _expenseStore?.currentAccount.monthTotalsDisplayMode ??
      timelineSettings.monthTotalsDisplayMode;
  MultiMonthDisplayMode getMultiMonthDisplayMode(TimelineViewMode mode) {
    return _expenseStore?.currentAccount.getMultiMonthDisplayMode(mode) ??
        timelineSettings.getMultiMonthDisplayMode(mode);
  }

  MultiMonthDisplayMode get multiMonthDisplayMode {
    final mode = timelineViewMode;
    return getMultiMonthDisplayMode(mode);
  }

  TerminologyPreset get terminologyPreset =>
      _expenseStore?.currentAccount.terminologyPreset ??
      timelineSettings.terminologyPreset;
  TimelineViewMode get timelineViewMode =>
      _expenseStore?.currentAccount.timelineViewMode ??
      timelineSettings.timelineViewMode;
  PulsesFilterType get pulseFilterType =>
      _expenseStore?.currentAccount.pulseFilterType ??
      timelineSettings.pulseFilterType;
  String? get pulseFilterCategory => timelineSettings
      .pulseFilterCategory; // [NEW] Account-specific handled by timelineSettings internal logic via setAccountId
  PulsesGroupBy get pulseGroupBy =>
      _expenseStore?.currentAccount.pulseGroupBy ??
      timelineSettings.pulseGroupBy;
  bool get pulseShowArchived =>
      _expenseStore?.currentAccount.pulseShowArchived ??
      timelineSettings.pulseShowArchived;
  CategoryPresetMode get categoryPresetMode =>
      _expenseStore?.currentAccount.categoryPresetMode ??
      timelineSettings.categoryPresetMode;
  String? get customPulseLabel =>
      _expenseStore?.currentAccount.customPulseLabel ??
      timelineSettings.customPulseLabel;
  String? get customTimelineLabel =>
      _expenseStore?.currentAccount.customTimelineLabel ??
      timelineSettings.customTimelineLabel;
  String? get customActivityLabel =>
      _expenseStore?.currentAccount.customActivityLabel ??
      timelineSettings.customActivityLabel;
  List<int> get customQuickAddAmounts => timelineSettings.customQuickAddAmounts;
  bool get balanceUpdatesDisabled =>
      _expenseStore?.currentAccount.balanceUpdatesDisabled ?? false;
  Map<String, int> get categoryIcons =>
      _expenseStore?.currentAccount.categoryIcons ?? const {};

  bool get globalEnvelopeCurrentDeductActuals =>
      timelineSettings.globalEnvelopeCurrentDeductActuals;
  bool get globalEnvelopeFutureDeductActuals =>
      timelineSettings.globalEnvelopeFutureDeductActuals;

  bool get balanceProjectionDeductEnvelopes =>
      timelineSettings.balanceProjectionDeductEnvelopes;
  bool get balanceProjectionShowDelta =>
      timelineSettings.balanceProjectionShowDelta;

  bool get envelopesSectionCollapsed =>
      timelineSettings.envelopesSectionCollapsed;
  set envelopesSectionCollapsed(bool value) =>
      timelineSettings.envelopesSectionCollapsed = value;

  // Sync Settings
  bool get syncSettingsAcrossAccounts => _syncSettingsAcrossAccounts;

  // Money Pots - can be global or account-specific via MoneyPot.accountIds
  List<MoneyPot> get moneyPots {
    final allPots = moneyPotsSettings.moneyPots;
    if (_expenseStore == null) return allPots;

    final currentAccountId = _expenseStore!.currentAccount.id;
    return allPots.where((pot) {
      final accountIds = pot.accountIds;
      // Global if null or empty
      if (accountIds == null || accountIds.isEmpty) return true;
      // Or if it contains our account
      return accountIds.contains(currentAccountId);
    }).toList();
  }

  String get moneyPotsSectionLabel {
    // If we have an account-specific label, use it. Otherwise fallback to global.
    return _expenseStore?.currentAccount.moneyPotsSectionLabel ??
        moneyPotsSettings.sectionLabel;
  }

  bool get showForeignCurrencyDebtInAppCurrency =>
      moneyPotsSettings.showForeignCurrencyDebtInAppCurrency;

  set showForeignCurrencyDebtInAppCurrency(bool value) =>
      moneyPotsSettings.showForeignCurrencyDebtInAppCurrency = value;

  bool get moneyPotsSectionCollapsed => moneyPotsSettings.collapsed;
  set moneyPotsSectionCollapsed(bool value) =>
      moneyPotsSettings.collapsed = value;

  int get moneyPotsGridColumns => moneyPotsSettings.gridColumns;
  set moneyPotsGridColumns(int value) => moneyPotsSettings.gridColumns = value;

  int get moneyPotsMaxVisibleRows => moneyPotsSettings.maxVisibleRows;
  set moneyPotsMaxVisibleRows(int value) =>
      moneyPotsSettings.maxVisibleRows = value;

  Future<void> updateMoneyPotsSectionLabel(String label) async {
    // Prefer updating the current account's label if possible
    if (_expenseStore != null) {
      await _expenseStore!.updateMoneyPotsSectionLabel(label);
    } else {
      moneyPotsSettings.sectionLabel = label;
    }
  }

  Future<void> addMoneyPot(MoneyPot pot) async {
    moneyPotsSettings.addMoneyPot(pot);
  }

  Future<void> updateMoneyPot(MoneyPot pot) async {
    moneyPotsSettings.updateMoneyPot(pot);
  }

  Future<void> removeMoneyPot(String id) async {
    moneyPotsSettings.removeMoneyPot(id);
  }

  // ===========================================================================
  // Proxied Setters
  // ===========================================================================

  set useCustomColors(bool value) => themeSettings.useCustomColors = value;
  set appThemePreset(AppThemePreset value) =>
      themeSettings.appThemePreset = value;
  set debitColor(Color value) => themeSettings.debitColor = value;
  set creditColor(Color value) => themeSettings.creditColor = value;
  set neutralColor(Color value) => themeSettings.neutralColor = value;
  set textScalePreset(TextScalePreset value) =>
      themeSettings.textScalePreset = value;
  set fontPreset(FontPreset value) => themeSettings.fontPreset = value;
  set randomizeColorOnResume(bool value) =>
      themeSettings.randomizeColorOnResume = value;
  set randomizeColorOnPeriodChange(bool value) =>
      themeSettings.randomizeColorOnPeriodChange = value;

  set currency(AppCurrency value) => currencySettings.currency = value;

  // =====================
  // Logic for region preset
  // =====================

  set regionPresetId(String value) {
    if (_regionPresetId == value) return;
    _regionPresetId = value;
    _storage.setString(_kRegionPreset, value);
    final preset = AppSettingsPresets.regionPresetForId(value);
    final locale = AppSettingsPresets.localeFromPlatform();
    final nextCurrency =
        preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
    final nextDayFormat =
        preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);

    currencySettings.currency = nextCurrency;
    timelineSettings.dayFormat = nextDayFormat;
    notifyListeners();
  }

  // Setters for proxies
  set currentBalanceCents(int value) {
    if (_expenseStore != null) {
      _expenseStore!.updateCurrentBalance(value);
    } else {
      currencySettings.currentBalanceCents = value;
    }
  }

  set showCents(bool value) => currencySettings.showCents = value;
  set roundingIncrement(int value) =>
      currencySettings.roundingIncrement = value;
  set autoUpdateRates(bool value) => currencySettings.autoUpdateRates = value;
  void enableCurrency(AppCurrency value) =>
      currencySettings.enableCurrency(value);
  void disableCurrency(AppCurrency value) =>
      currencySettings.disableCurrency(value);
  void setExchangeRate(AppCurrency currency, double rate) =>
      currencySettings.setExchangeRate(currency, rate);
  void updateAllExchangeRates(Map<AppCurrency, double> rates) =>
      currencySettings.updateAllExchangeRates(rates);

  set dayFormat(DayFormat value) {
    if (_expenseStore != null) {
      _expenseStore!.updateDayFormat(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.dayFormat = value;
    }
  }

  set timelineSwipeLeft(TimelineSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineSwipeLeft(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineSwipeLeft = value;
    }
  }

  set timelineSwipeRight(TimelineSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineSwipeRight(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineSwipeRight = value;
    }
  }

  set timelineTapAction(TimelineTapAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineTapAction(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineTapAction = value;
    }
  }

  set pulseSwipeLeft(PulseSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulseSwipeLeft(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseSwipeLeft = value;
    }
  }

  set pulseSwipeRight(PulseSwipeAction value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulseSwipeRight(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseSwipeRight = value;
    }
  }

  set pulseDisplayMode(PulseDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulseDisplayMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseDisplayMode = value;
    }
  }

  set enableTabSwipe(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateEnableTabSwipe(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.enableTabSwipe = value;
    }
  }

  set timelineUseZeroBaseline(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineUseZeroBaseline(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineUseZeroBaseline = value;
    }
  }

  set timelineShowClearedItems(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineShowClearedItems(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineShowClearedItems = value;
    }
  }

  set timelineShowSkippedItems(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineShowSkippedItems(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineShowSkippedItems = value;
    }
  }

  set timelineShowIncome(bool value) {
    timelineSettings.timelineShowIncome = value;
  }

  set timelineShowExpense(bool value) {
    timelineSettings.timelineShowExpense = value;
  }

  set timelineSortOrder(TimelineSortOrder value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineSortOrder(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineSortOrder = value;
    }
  }

  set timelineDateSortMode(TimelineDateSortMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineDateSortMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineDateSortMode = value;
    }
  }

  set viewPeriodMode(ViewPeriodMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateViewPeriodMode(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }

  // Paycheck setters - these are account-specific only
  set paycheckDay(int? value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckDay(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }

  set paycheckBusinessAdjust(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjust(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }

  set paycheckBusinessAdjustDirection(PaycheckAdjustDirection value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePaycheckBusinessAdjustDirection(value);
    }
    // Silently ignore if no account is available - this is account-specific only
  }

  Future<void> dismissInsight(String id) async {
    if (_expenseStore != null) {
      final current =
          _expenseStore!.currentAccount.settings.dismissedInsightIds;
      if (!current.contains(id)) {
        await _expenseStore!.updateAccountSettings(
          _expenseStore!.currentAccount.id,
          dismissedInsightIds: {...current, id},
        );
      }
    } else {
      await insightSettings.dismissInsight(id);
    }
  }

  Future<void> restoreInsight(String id) async {
    if (_expenseStore != null) {
      final current =
          _expenseStore!.currentAccount.settings.dismissedInsightIds;
      if (current.contains(id)) {
        final newSet = Set<String>.from(current)..remove(id);
        await _expenseStore!.updateAccountSettings(
          _expenseStore!.currentAccount.id,
          dismissedInsightIds: newSet,
        );
      }
    } else {
      await insightSettings.restoreInsight(id);
    }
  }

  Future<void> togglePinInsight(String id) async {
    if (_expenseStore != null) {
      final current = _expenseStore!.currentAccount.settings.pinnedInsightIds;
      final newSet = Set<String>.from(current);
      if (newSet.contains(id)) {
        newSet.remove(id);
      } else {
        newSet.add(id);
      }
      await _expenseStore!.updateAccountSettings(
        _expenseStore!.currentAccount.id,
        pinnedInsightIds: newSet,
      );
    } else {
      await insightSettings.togglePinInsight(id);
    }
  }

  Future<void> restoreAllInsights() async {
    if (_expenseStore != null) {
      await _expenseStore!.updateAccountSettings(
        _expenseStore!.currentAccount.id,
        dismissedInsightIds: {},
      );
    } else {
      await insightSettings.restoreAllInsights();
    }
  }

  set startingBalanceCents(int value) {
    if (_expenseStore != null) {
      _expenseStore!.updateStartingBalance(value);
    } else {
      currencySettings.currentBalanceCents = value;
    }
  }

  set timelineGroupByDate(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineGroupByDate(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineGroupByDate = value;
    }
  }

  set timelineGroupByTheme(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineGroupByTheme(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineGroupByTheme = value;
    }
  }

  set timelineSplitClearedAndPending(bool value) {
    // [NEW]
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineSplitClearedAndPending(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineSplitClearedAndPending = value;
    }
  }

  set timelineShowSubcategories(bool value) {
    // [NEW]
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineShowSubcategories(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineShowSubcategories = value;
    }
  }

  void setTimelineShowPulseOrigin(TimelineViewMode mode, bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineShowPulseOrigin(
        value,
        mode: mode,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.setTimelineShowPulseOrigin(mode, value);
    }
  }

  set timelineShowPulseOrigin(bool value) {
    final mode = timelineViewMode;
    setTimelineShowPulseOrigin(mode, value);
  }

  set monthCardDisplayMode(MonthCardDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateMonthCardDisplayMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.monthCardDisplayMode = value;
    }
  }

  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateMonthTotalsDisplayMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.monthTotalsDisplayMode = value;
    }
  }

  void setMultiMonthDisplayMode(
    TimelineViewMode mode,
    MultiMonthDisplayMode value,
  ) {
    if (_expenseStore != null) {
      _expenseStore!.updateMultiMonthDisplayMode(
        value,
        viewMode: mode,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.setMultiMonthDisplayMode(mode, value);
    }
  }

  set multiMonthDisplayMode(MultiMonthDisplayMode value) {
    final mode = timelineViewMode;
    setMultiMonthDisplayMode(mode, value);
  }

  set terminologyPreset(TerminologyPreset value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTerminologyPreset(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.terminologyPreset = value;
    }
  }

  set timelineViewMode(TimelineViewMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateTimelineViewMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.timelineViewMode = value;
    }
  }

  set pulseFilterType(PulsesFilterType value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulsesFilterType(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseFilterType = value;
    }
  }

  set pulseFilterCategory(String? value) =>
      timelineSettings.pulseFilterCategory = value; // [NEW]
  set pulseGroupBy(PulsesGroupBy value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulsesGroupBy(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseGroupBy = value;
    }
  }

  set pulseShowArchived(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updatePulsesShowArchived(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.pulseShowArchived = value;
    }
  }

  set categoryPresetMode(CategoryPresetMode value) {
    if (_expenseStore != null) {
      _expenseStore!.updateCategoryPresetMode(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.categoryPresetMode = value;
    }
  }

  set customPulseLabel(String? value) {
    if (_expenseStore != null) {
      // NOTE: We don't have a specific method in ExpenseStore for this yet,
      // but Account.copyWith will handle it if we add it.
      // For now, let's assume we'll update it via Account.
      _expenseStore!.updateCustomPulseLabel(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.customPulseLabel = value;
    }
  }

  set customTimelineLabel(String? value) {
    if (_expenseStore != null) {
      _expenseStore!.updateCustomTimelineLabel(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    } else {
      timelineSettings.customTimelineLabel = value;
    }
  }

  set balanceUpdatesDisabled(bool value) {
    if (_expenseStore != null) {
      _expenseStore!.updateBalanceUpdatesDisabled(
        value,
        syncToAll: _syncSettingsAcrossAccounts,
      );
    }
    // No global fallback needed as this is strictly account logic
  }

  void setRandomTheme() => themeSettings.setRandomTheme();

  set customQuickAddAmounts(List<int> value) =>
      timelineSettings.customQuickAddAmounts = value;

  set syncSettingsAcrossAccounts(bool value) {
    if (_syncSettingsAcrossAccounts == value) return;
    _syncSettingsAcrossAccounts = value;
    _storage.setBool(_kSyncSettingsAcrossAccounts, value);
    notifyListeners();
  }

  set globalEnvelopeCurrentDeductActuals(bool value) =>
      timelineSettings.globalEnvelopeCurrentDeductActuals = value;
  set globalEnvelopeFutureDeductActuals(bool value) =>
      timelineSettings.globalEnvelopeFutureDeductActuals = value;

  set balanceProjectionDeductEnvelopes(bool value) =>
      timelineSettings.balanceProjectionDeductEnvelopes = value;
  set balanceProjectionShowDelta(bool value) =>
      timelineSettings.balanceProjectionShowDelta = value;

  /// Creates an instance with default settings and in-memory storage.
  /// Useful for testing.
  factory AppSettingsStore.withSampleData() {
    final storage = MemoryStorageProvider();

    // Create default theme settings
    final themeSettings = ThemeSettings(
      storage,
      initialAppThemePreset: AppThemePreset.monochrome,
      initialUseCustomColors: false,
      initialDebitColor: ThemeSettings.getPalette(
        AppThemePreset.monochrome,
      ).debitColor.toARGB32(),
      initialCreditColor: ThemeSettings.getPalette(
        AppThemePreset.monochrome,
      ).creditColor.toARGB32(),
      initialNeutralColor: ThemeSettings.getPalette(
        AppThemePreset.monochrome,
      ).neutralColor.toARGB32(),
      initialTextScalePreset: TextScalePreset.normal,
      initialFontPreset: FontPreset.system,
      initialRandomizeColorOnResume: false,
      initialRandomizeColorOnPeriodChange: false,
    );

    // Create default currency settings
    final currencySettings = CurrencySettings(
      storage,
      initialCurrency: AppCurrency.usd,
      initialBalanceCents: 0,
      initialShowCents: true,
      initialRoundingIncrement: 0,
      initialEnabledCurrencies: {AppCurrency.usd},
      initialExchangeRates: {},
      initialAutoUpdateRates: false,
    );

    // Create default timeline settings
    final timelineSettings = TimelineSettings(
      storage,
      initialDayFormat: DayFormat.number,
      initialSwipeLeft: TimelineSwipeAction.off,
      initialSwipeRight: TimelineSwipeAction.off,
      initialTapAction: TimelineTapAction.archive,
      initialPulseSwipeLeft: PulseSwipeAction.off,
      initialPulseSwipeRight: PulseSwipeAction.off,
      initialPulseDisplayMode: PulseDisplayMode.automatic,
      initialEnableTabSwipe: false,
      initialUseZeroBaseline: false,
      initialShowClearedItems: true,
      initialShowSkippedItems: false,
      initialSortOrder: TimelineSortOrder.chronological,
      initialDateSortMode: TimelineDateSortMode.scheduledDate,
      initialGroupByDate: false,
      initialGroupByTheme: false,
      initialSplitClearedAndPending: false,
      initialShowSubcategories: false,
      initialShowPulseOrigin: false,
      initialMonthCardDisplayMode: MonthCardDisplayMode.full,
      initialMonthTotalsDisplayMode: MonthTotalsDisplayMode.includeCleared,
      initialMultiMonthDisplayMode: MultiMonthDisplayMode.automatic,
      initialTerminologyPreset: TerminologyPreset.defaultTerms,
      initialViewMode: TimelineViewMode.month,
      initialPulsesFilterType: PulsesFilterType.all,
      initialPulsesGroupBy: PulsesGroupBy.none,
      initialPulsesShowArchived: false,
      initialCategoryPresetMode: CategoryPresetMode.defaultPresets,
    );

    // Create default money pots settings
    final moneyPotsSettings = MoneyPotsSettings(
      storage,
      initialMoneyPots: [],
      initialSectionLabel: MoneyPotsSettings.defaultSectionLabel,
      initialShowForeignCurrencyDebtInAppCurrency: false,
      initialCollapsed: false,
    );

    // Create default insight settings
    final insightSettings = InsightSettings(
      storage,
      initialDismissedIds: {},
      initialPinnedIds: {},
      initialMinDataDaysOverride: null,
      initialShowBehavioralInsights: false,
      initialIncludeInternalTransfers: false,
    );

    return AppSettingsStore._(
      storage,
      themeSettings,
      currencySettings,
      timelineSettings,
      moneyPotsSettings,
      insightSettings,
      AppSettingsPresets.autoPresetId,
      false, // syncSettingsAcrossAccounts
    );
  }

  static Future<AppSettingsStore> loadOrCreate() async {
    final storage = await StorageProvider.create();
    try {
      // Load all values
      final currencyStored = await storage.getString(_kCurrency);
      final balance = await storage.getInt(_kCurrentBalanceCents) ?? 0;
      final dayFormatStored = await storage.getString(_kDayFormat);
      final swipeLeft = AppSettingsCodecs.decodeSwipeAction(
            await storage.getString(_kTimelineSwipeLeft),
          ) ??
          TimelineSwipeAction.off;
      final swipeRight = AppSettingsCodecs.decodeSwipeAction(
            await storage.getString(_kTimelineSwipeRight),
          ) ??
          TimelineSwipeAction.off;
      final timelineTapAction = AppSettingsCodecs.decodeTimelineTapAction(
            await storage.getString(_kTimelineTapAction),
          ) ??
          TimelineTapAction.archive;
      final pulseSwipeLeft = AppSettingsCodecs.decodePulseSwipeAction(
            await storage.getString(_kPulseSwipeLeft),
          ) ??
          PulseSwipeAction.off;
      final pulseSwipeRight = AppSettingsCodecs.decodePulseSwipeAction(
            await storage.getString(_kPulseSwipeRight),
          ) ??
          PulseSwipeAction.off;
      final pulseDisplayMode = AppSettingsCodecs.decodePulseDisplayMode(
            await storage.getString(_kPulseDisplayMode),
          ) ??
          PulseDisplayMode.automatic;
      final enableTabSwipe = await storage.getBool(_kEnableTabSwipe) ?? false;
      final useZeroBaseline =
          await storage.getBool(_kTimelineUseZeroBaseline) ?? false;
      final showClearedItems =
          await storage.getBool(_kTimelineShowClearedItems) ?? true;

      final regionPresetId = await storage.getString(_kRegionPreset) ??
          AppSettingsPresets.autoPresetId;
      final preset = AppSettingsPresets.regionPresetForId(regionPresetId);
      final locale = AppSettingsPresets.localeFromPlatform();
      final fallbackCurrency =
          preset.currency ?? AppSettingsPresets.currencyForLocale(locale);
      final fallbackDayFormat =
          preset.dayFormat ?? AppSettingsPresets.dayFormatForLocale(locale);

      final resolvedCurrency =
          decodeCurrency(currencyStored) ?? fallbackCurrency;
      final resolvedDayFormat =
          AppSettingsCodecs.decodeDayFormat(dayFormatStored) ??
              fallbackDayFormat;

      final sortOrder = AppSettingsCodecs.decodeSortOrder(
            await storage.getString(_kTimelineSortOrder),
          ) ??
          TimelineSortOrder.chronological;
      final dateSortMode = AppSettingsCodecs.decodeTimelineDateSortMode(
            await storage.getString(_kTimelineDateSortMode),
          ) ??
          TimelineDateSortMode.scheduledDate;
      // Note: Paycheck settings are now part of Account model only. Removed global loading logic.

      final themePresetRaw = await storage.getString(_kAppThemePreset);
      final appThemePreset =
          AppSettingsCodecs.decodeAppThemePreset(themePresetRaw) ??
              AppThemePreset.monochrome;

      // Color Migration: old colorPreset == 'custom' becomes useCustomColors = true
      final colorPresetRaw = await storage.getString(_kColorPreset);
      final wasCustom = colorPresetRaw == 'custom';
      final useCustomColors =
          await storage.getBool(_kUseCustomColors) ?? wasCustom;

      final debitColorValue = await storage.getInt(_kDebitColor) ??
          ThemeSettings.getPalette(appThemePreset).debitColor.toARGB32();
      final creditColorValue = await storage.getInt(_kCreditColor) ??
          ThemeSettings.getPalette(appThemePreset).creditColor.toARGB32();
      final neutralColorValue = await storage.getInt(_kNeutralColor) ??
          ThemeSettings.getPalette(appThemePreset).neutralColor.toARGB32();

      final timelineGroupByDate =
          await storage.getBool(_kTimelineGroupByDate) ?? false;
      final timelineGroupByTheme =
          await storage.getBool(_kTimelineGroupByTheme) ?? false;
      final timelineShowPulseOrigin =
          await storage.getBool(_kTimelineShowPulseOrigin) ?? false;
      final timelineShowSkippedItems =
          await storage.getBool(_kTimelineShowSkippedItems) ?? false;

      final monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(
            await storage.getString(_kMonthCardDisplayMode),
          ) ??
          MonthCardDisplayMode.full;
      final monthTotalsDisplayMode =
          AppSettingsCodecs.decodeMonthTotalsDisplayMode(
                await storage.getString(_kMonthTotalsDisplayMode),
              ) ??
              MonthTotalsDisplayMode.includeCleared;
      final multiMonthDisplayMode =
          AppSettingsCodecs.decodeMultiMonthDisplayMode(
                await storage.getString(_kMultiMonthDisplayMode),
              ) ??
              MultiMonthDisplayMode.automatic;

      final terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(
            await storage.getString(_kTerminologyPreset),
          ) ??
          TerminologyPreset.defaultTerms;
      final textScalePreset = AppSettingsCodecs.decodeTextScalePreset(
            await storage.getString(_kTextScalePreset),
          ) ??
          TextScalePreset.normal;
      final fontPreset = AppSettingsCodecs.decodeFontPreset(
            await storage.getString(_kFontPreset),
          ) ??
          FontPreset.system;
      final timelineViewMode = AppSettingsCodecs.decodeTimelineViewMode(
            await storage.getString(_kTimelineViewMode),
          ) ??
          TimelineViewMode.month;

      final randomizeColorOnResume =
          await storage.getBool(_kRandomizeColorOnResume) ?? false;
      final randomizeColorOnPeriodChange =
          await storage.getBool(_kRandomizeColorOnPeriodChange) ?? false;

      final showCents = await storage.getBool(_kShowCents) ?? true;
      final roundingIncrement = await storage.getInt(_kRoundingIncrement) ?? 0;

      final pulseFilterType = AppSettingsCodecs.decodePulsesFilterType(
            await storage.getString(_kPulsesFilterType),
          ) ??
          PulsesFilterType.all;
      final pulseGroupBy = AppSettingsCodecs.decodePulsesGroupBy(
            await storage.getString(_kPulsesGroupBy),
          ) ??
          PulsesGroupBy.none;
      final pulseShowArchived =
          await storage.getBool(_kPulsesShowArchived) ?? false;
      final categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(
            await storage.getString(_kCategoryPresetMode),
          ) ??
          CategoryPresetMode.defaultPresets;

      final customPulseLabel = await storage.getString(_kCustomPulseLabel);
      final customTimelineLabel =
          await storage.getString(_kCustomTimelineLabel) ??
              await storage.getString(_kCustomActivityLabel);

      final enabledCurrenciesRaw = await storage.getString(_kEnabledCurrencies);
      final exchangeRatesRaw = await storage.getString(_kExchangeRates);
      final autoUpdateRates = await storage.getBool(_kAutoUpdateRates) ?? true;

      Set<AppCurrency>? enabledCurrencies;
      if (enabledCurrenciesRaw != null) {
        enabledCurrencies = enabledCurrenciesRaw
            .split(',')
            .map(decodeCurrency)
            .whereType<AppCurrency>()
            .toSet();
      }

      Map<AppCurrency, double>? exchangeRates;
      if (exchangeRatesRaw != null) {
        try {
          final Map<String, dynamic> decoded = json.decode(exchangeRatesRaw);
          exchangeRates = {};
          decoded.forEach((key, value) {
            final currency = decodeCurrency(key);
            if (currency != null) {
              exchangeRates![currency] = (value as num).toDouble();
            }
          });
        } catch (e, st) {
          debugLog(
            LogCategory.persistence,
            'Failed to decode exchange rates',
            error: e,
            stackTrace: st,
          );
        }
      }

      final moneyPotsJson = await storage.getString(_kMoneyPots);
      List<MoneyPot> moneyPots = [];
      if (moneyPotsJson != null) {
        try {
          final List<dynamic> list = jsonDecode(moneyPotsJson);
          moneyPots = list.map((e) => MoneyPot.fromJson(e)).toList();
        } catch (e) {
          debugLog(
            LogCategory.persistence,
            'Failed to decode money pots',
            error: e,
          );
        }
      }

      final moneyPotsSectionLabel = await storage.getString(
        _kMoneyPotsSectionLabel,
      );
      final showForeignCurrencyDebtInAppCurrency = await storage.getBool(
            _kMoneyPotsShowForeignCurrencyDebtInAppCurrency,
          ) ??
          false;
      final moneyPotsCollapsed =
          await storage.getBool(_kMoneyPotsCollapsed) ?? false;
      final moneyPotsGridColumns =
          await storage.getInt(_kMoneyPotsGridColumns) ?? 2;
      final moneyPotsMaxVisibleRows =
          await storage.getInt(_kMoneyPotsMaxVisibleRows) ?? 2;

      final syncSettingsAcrossAccounts =
          await storage.getBool(_kSyncSettingsAcrossAccounts) ?? false;

      final insightDismissedIds =
          await storage.getStringList(_kInsightDismissedIds) ?? [];
      final insightPinnedIds =
          await storage.getStringList(_kInsightPinnedIds) ?? [];
      final insightMinDataDaysOverride = await storage.getInt(
        _kInsightMinDataDaysOverride,
      );
      final showBehavioralInsights =
          await storage.getBool(_kShowBehavioralInsights) ?? false;
      final includeInternalTransfers =
          await storage.getBool(_kIncludeInternalTransfersInReports) ?? false;

      return AppSettingsStore._(
        storage,
        ThemeSettings(
          storage,
          initialAppThemePreset: appThemePreset,
          initialUseCustomColors: useCustomColors,
          initialDebitColor: debitColorValue,
          initialCreditColor: creditColorValue,
          initialNeutralColor: neutralColorValue,
          initialTextScalePreset: textScalePreset,
          initialFontPreset: fontPreset,
          initialRandomizeColorOnResume: randomizeColorOnResume,
          initialRandomizeColorOnPeriodChange: randomizeColorOnPeriodChange,
        ),
        CurrencySettings(
          storage,
          initialCurrency: resolvedCurrency,
          initialBalanceCents: balance,
          initialShowCents: showCents,
          initialRoundingIncrement: roundingIncrement,
          initialEnabledCurrencies: enabledCurrencies,
          initialExchangeRates: exchangeRates,
          initialAutoUpdateRates: autoUpdateRates,
        ),
        TimelineSettings(
          storage,
          initialDayFormat: resolvedDayFormat,
          initialSwipeLeft: swipeLeft,
          initialSwipeRight: swipeRight,
          initialTapAction: timelineTapAction,
          initialPulseSwipeLeft: pulseSwipeLeft,
          initialPulseSwipeRight: pulseSwipeRight,
          initialPulseDisplayMode: pulseDisplayMode,
          initialEnableTabSwipe: enableTabSwipe,
          initialUseZeroBaseline: useZeroBaseline,
          initialShowClearedItems: showClearedItems,
          initialShowSkippedItems: timelineShowSkippedItems,
          initialSortOrder: sortOrder,
          initialDateSortMode: dateSortMode,
          initialGroupByDate: timelineGroupByDate,
          initialGroupByTheme: timelineGroupByTheme,
          initialSplitClearedAndPending: false,
          initialShowSubcategories: false,
          initialShowPulseOrigin: timelineShowPulseOrigin,
          initialMonthCardDisplayMode: monthCardDisplayMode,
          initialMonthTotalsDisplayMode: monthTotalsDisplayMode,
          initialMultiMonthDisplayMode: multiMonthDisplayMode,
          initialTerminologyPreset: terminologyPreset,
          initialViewMode: timelineViewMode,
          initialPulsesFilterType: pulseFilterType,
          initialPulsesGroupBy: pulseGroupBy,
          initialPulsesShowArchived: pulseShowArchived,
          initialCategoryPresetMode: categoryPresetMode,
          initialCustomPulseLabel: customPulseLabel,
          initialCustomTimelineLabel: customTimelineLabel,
        ),
        MoneyPotsSettings(
          storage,
          initialMoneyPots: moneyPots,
          initialSectionLabel: moneyPotsSectionLabel,
          initialShowForeignCurrencyDebtInAppCurrency:
              showForeignCurrencyDebtInAppCurrency,
          initialCollapsed: moneyPotsCollapsed,
          initialGridColumns: moneyPotsGridColumns,
          initialMaxVisibleRows: moneyPotsMaxVisibleRows,
        ),
        InsightSettings(
          storage,
          initialDismissedIds: insightDismissedIds.toSet(),
          initialPinnedIds: insightPinnedIds.toSet(),
          initialMinDataDaysOverride: insightMinDataDaysOverride,
          initialShowBehavioralInsights: showBehavioralInsights,
          initialIncludeInternalTransfers: includeInternalTransfers,
        ),
        regionPresetId,
        syncSettingsAcrossAccounts,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to load settings',
        error: error,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  void _updateSelectiveNotifiers() {
    // Resolve dual-layer resolution (account > global) for hot properties
    final store = _expenseStore;

    timelineShowClearedItemsNotifier.value =
        store?.currentAccount.timelineShowClearedItems ??
            timelineSettings.timelineShowClearedItems;

    timelineViewModeNotifier.value = store?.currentAccount.timelineViewMode ??
        timelineSettings.timelineViewMode;

    monthCardDisplayModeNotifier.value =
        store?.currentAccount.monthCardDisplayMode ??
            timelineSettings.monthCardDisplayMode;

    if (store != null) {
      insightSettings.updateFromAccount(
        store.currentAccount.settings.dismissedInsightIds,
        store.currentAccount.settings.pinnedInsightIds,
      );
    }
  }

  @override
  void dispose() {
    // Remove listener from ExpenseStore if bound
    if (_expenseStoreListener != null && _expenseStore != null) {
      _expenseStore!.removeListener(_expenseStoreListener!);
      _expenseStoreListener = null;
    }

    themeSettings.removeListener(notifyListeners);
    currencySettings.removeListener(notifyListeners);
    timelineSettings.removeListener(notifyListeners);
    themeSettings.dispose();
    currencySettings.dispose();
    timelineSettings.dispose();
    moneyPotsSettings.dispose();

    // Dispose selective notifiers
    timelineShowClearedItemsNotifier.dispose();
    timelineViewModeNotifier.dispose();
    monthCardDisplayModeNotifier.dispose();

    super.dispose();
  }
}

class AppSettingsScope extends InheritedNotifier<AppSettingsStore> {
  const AppSettingsScope({
    super.key,
    required AppSettingsStore store,
    required super.child,
  }) : super(notifier: store);

  static AppSettingsStore of(BuildContext context) {
    final scope =
        context.dependOnInheritedWidgetOfExactType<AppSettingsScope>();
    if (scope == null) {
      throw StateError('AppSettingsStore not found in widget tree.');
    }
    return scope.notifier!;
  }

  static AppSettingsStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppSettingsScope>();
    if (scope == null) {
      throw StateError('AppSettingsStore not found in widget tree.');
    }
    return scope.notifier!;
  }
}
