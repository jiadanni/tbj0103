import 'dart:ui' as ui;

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

/// Region preset configuration for app localization.
///
/// Defines predefined region presets with associated currency and day format
/// preferences, and provides utility methods for locale detection.
class AppSettingsPresets {
  AppSettingsPresets._(); // Prevent instantiation

  static const String autoPresetId = 'auto';

  static const List<RegionPreset> regionPresets = <RegionPreset>[
    RegionPreset(id: autoPresetId, label: 'System locale'),
    RegionPreset(
      id: 'europe',
      label: 'Europe',
      currency: AppCurrency.eur,
      dayFormat: DayFormat.ordinal,
    ),
    RegionPreset(
      id: 'us',
      label: 'United States',
      currency: AppCurrency.usd,
      dayFormat: DayFormat.number,
    ),
    RegionPreset(
      id: 'uk',
      label: 'United Kingdom',
      currency: AppCurrency.gbp,
      dayFormat: DayFormat.ordinal,
    ),
  ];

  /// Finds a region preset by its ID, returning the auto preset if not found.
  static RegionPreset regionPresetForId(String id) {
    return regionPresets.firstWhere(
      (preset) => preset.id == id,
      orElse: () => regionPresets.first,
    );
  }

  /// Gets the platform's current locale.
  static ui.Locale localeFromPlatform() {
    return ui.PlatformDispatcher.instance.locale;
  }

  /// Infers the appropriate currency based on the device's locale.
  static AppCurrency currencyForLocale(ui.Locale locale) {
    final country = (locale.countryCode ?? '').toLowerCase();
    switch (country) {
      case 'us':
      case 'ca':
      case 'au':
        return AppCurrency.usd;
      case 'gb':
      case 'uk':
        return AppCurrency.gbp;
      default:
        return AppCurrency.eur;
    }
  }

  /// Infers the appropriate day format based on the device's locale.
  static DayFormat dayFormatForLocale(ui.Locale locale) {
    final country = (locale.countryCode ?? '').toLowerCase();
    if (country == 'us') return DayFormat.number;
    return DayFormat.ordinal;
  }
}
