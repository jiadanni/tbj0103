import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

class MemoryStorageProvider implements StorageProvider {
  final Map<String, Object> _store = {};

  @override
  Future<bool?> getBool(String key) async => _store[key] as bool?;

  @override
  Future<int?> getInt(String key) async => _store[key] as int?;

  @override
  Future<String?> getString(String key) async => _store[key] as String?;

  @override
  Future<List<String>?> getStringList(String key) async =>
      (_store[key] as List<dynamic>?)?.cast<String>();

  @override
  Future<bool> setBool(String key, bool value) async {
    _store[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _store[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _store[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _store[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _store.remove(key);
    return true;
  }
}
