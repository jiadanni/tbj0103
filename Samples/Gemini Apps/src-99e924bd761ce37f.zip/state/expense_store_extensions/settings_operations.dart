part of '../expense_store.dart';

extension SettingsOperations on ExpenseStore {
  /// Update the paycheck day for the current account
  Future<void> updatePaycheckDay(int? day) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final clampedDay = day?.clamp(1, 31);
    if (_currentAccount.paycheckDay == clampedDay) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckDay: clampedDay,
      clearPaycheckDay: day == null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck business day adjustment setting
  Future<void> updatePaycheckBusinessAdjust(bool adjust) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.paycheckBusinessAdjust == adjust) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjust: adjust,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the paycheck adjust direction
  Future<void> updatePaycheckBusinessAdjustDirection(
    PaycheckAdjustDirection direction,
  ) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.paycheckBusinessAdjustDirection == direction) return;

    final updatedAccount = _currentAccount.copyWith(
      paycheckBusinessAdjustDirection: direction,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the starting balance for the current account
  Future<void> updateStartingBalance(int cents) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.startingBalanceCents == cents) return;

    final updatedAccount = _currentAccount.copyWith(
      startingBalanceCents: cents,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update the current balance for the current account
  Future<void> updateCurrentBalance(int cents) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (_currentAccount.currentBalanceCents == cents) return;

    final updatedAccount = _currentAccount.copyWith(
      currentBalanceCents: cents,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> updateTimelineSortOrder(
    TimelineSortOrder order, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineSortOrder == order) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineSortOrder: order),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineDateSortMode(
    TimelineDateSortMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineDateSortMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineDateSortMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateViewPeriodMode(ViewPeriodMode mode) async {
    // Note: ViewPeriodMode is strictly account-specific, no syncToAll
    if (_currentAccount.viewPeriodMode == mode) return;
    await _updateAccountSetting((a) => a.copyWith(viewPeriodMode: mode));
  }

  Future<void> updateTimelineViewMode(
    TimelineViewMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineViewMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineViewMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineShowClearedItems(
    bool show, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineShowClearedItems == show) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineShowClearedItems: show),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineShowSkippedItems(
    bool show, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineShowSkippedItems == show) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineShowSkippedItems: show),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineGroupByDate(
    bool group, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineGroupByDate == group) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineGroupByDate: group),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineGroupByTheme(
    bool group, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineGroupByTheme == group) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineGroupByTheme: group),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineSplitClearedAndPending(
    bool split, {
    bool syncToAll = false,
  }) async {
    // [NEW]
    if (!syncToAll && _currentAccount.timelineSplitClearedAndPending == split) {
      return;
    }
    await _updateAccountSetting(
      (a) => a.copyWith(timelineSplitClearedAndPending: split),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineShowSubcategories(
    bool show, {
    bool syncToAll = false,
  }) async {
    // [NEW]
    if (!syncToAll && _currentAccount.timelineShowSubcategories == show) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineShowSubcategories: show),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineShowPulseOrigin(
    bool show, {
    TimelineViewMode? mode,
    bool syncToAll = false,
  }) async {
    if (mode == null) {
      // Legacy behavior: update all
      await _updateAccountSetting(
        (a) => a.copyWith(timelineShowPulseOrigin: show),
        syncToAll: syncToAll,
      );
      return;
    }

    await _updateAccountSetting((a) {
      switch (mode) {
        case TimelineViewMode.month:
          return a.copyWith(timelineShowPulseOriginMonth: show);
        case TimelineViewMode.sheet:
          return a.copyWith(timelineShowPulseOriginSheet: show);
        case TimelineViewMode.grid:
          return a.copyWith(timelineShowPulseOriginGrid: show);
      }
    }, syncToAll: syncToAll);
  }

  Future<void> updateMonthTotalsDisplayMode(
    MonthTotalsDisplayMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.monthTotalsDisplayMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(monthTotalsDisplayMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateMonthCardDisplayMode(
    MonthCardDisplayMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.monthCardDisplayMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(monthCardDisplayMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateMultiMonthDisplayMode(
    MultiMonthDisplayMode mode, {
    TimelineViewMode? viewMode,
    bool syncToAll = false,
  }) async {
    if (viewMode == null) {
      // Legacy behavior: update all
      await _updateAccountSetting(
        (a) => a.copyWith(multiMonthDisplayMode: mode),
        syncToAll: syncToAll,
      );
      return;
    }

    await _updateAccountSetting((a) {
      switch (viewMode) {
        case TimelineViewMode.month:
          return a.copyWith(multiMonthDisplayModeMonth: mode);
        case TimelineViewMode.sheet:
          return a.copyWith(multiMonthDisplayModeSheet: mode);
        case TimelineViewMode.grid:
          return a.copyWith(multiMonthDisplayModeGrid: mode);
      }
    }, syncToAll: syncToAll);
  }

  Future<void> updateDayFormat(
    DayFormat format, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.dayFormat == format) return;
    await _updateAccountSetting(
      (a) => a.copyWith(dayFormat: format),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineSwipeLeft(
    TimelineSwipeAction action, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineSwipeLeft == action) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineSwipeLeft: action),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineSwipeRight(
    TimelineSwipeAction action, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineSwipeRight == action) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineSwipeRight: action),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineTapAction(
    TimelineTapAction action, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineTapAction == action) return;
    await _updateAccountSetting(
      (a) => a.copyWith(timelineTapAction: action),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulseSwipeLeft(
    PulseSwipeAction action, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseSwipeLeft == action) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseSwipeLeft: action),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulseSwipeRight(
    PulseSwipeAction action, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseSwipeRight == action) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseSwipeRight: action),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulseDisplayMode(
    PulseDisplayMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseDisplayMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseDisplayMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateEnableTabSwipe(
    bool enable, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.enableTabSwipe == enable) return;
    await _updateAccountSetting(
      (a) => a.copyWith(enableTabSwipe: enable),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTimelineUseZeroBaseline(
    bool useZero, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.timelineUseZeroBaseline == useZero) {
      return;
    }
    await _updateAccountSetting(
      (a) => a.copyWith(timelineUseZeroBaseline: useZero),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateBalanceUpdatesDisabled(
    bool disabled, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.balanceUpdatesDisabled == disabled) {
      return;
    }
    await _updateAccountSetting(
      (a) => a.copyWith(balanceUpdatesDisabled: disabled),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateTerminologyPreset(
    TerminologyPreset preset, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.terminologyPreset == preset) return;
    await _updateAccountSetting(
      (a) => a.copyWith(terminologyPreset: preset),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateCustomPulseLabel(
    String? label, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.customPulseLabel == label) return;
    await _updateAccountSetting(
      (a) => a.copyWith(customPulseLabel: label),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateCustomActivityLabel(
    String? label, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.customTimelineLabel == label) return;
    await _updateAccountSetting(
      (a) => a.copyWith(customTimelineLabel: label),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateCustomTimelineLabel(
    String? label, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.customTimelineLabel == label) return;
    await _updateAccountSetting(
      (a) => a.copyWith(customTimelineLabel: label),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulsesFilterType(
    PulsesFilterType type, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseFilterType == type) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseFilterType: type),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulsesGroupBy(
    PulsesGroupBy grouping, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseGroupBy == grouping) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseGroupBy: grouping),
      syncToAll: syncToAll,
    );
  }

  Future<void> updatePulsesShowArchived(
    bool show, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.pulseShowArchived == show) return;
    await _updateAccountSetting(
      (a) => a.copyWith(pulseShowArchived: show),
      syncToAll: syncToAll,
    );
  }

  Future<void> updateCategoryPresetMode(
    CategoryPresetMode mode, {
    bool syncToAll = false,
  }) async {
    if (!syncToAll && _currentAccount.categoryPresetMode == mode) return;
    await _updateAccountSetting(
      (a) => a.copyWith(categoryPresetMode: mode),
      syncToAll: syncToAll,
    );
  }

  Future<void> addCustomCategory(
    String category, {
    required bool isIncome,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmed = category.trim();
    if (trimmed.isEmpty) return;

    final existing = isIncome
        ? _currentAccount.customIncomeCategories
        : _currentAccount.customExpenseCategories;
    if (existing.contains(trimmed)) return;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: isIncome
          ? null
          : [..._currentAccount.customExpenseCategories, trimmed],
      customIncomeCategories: isIncome
          ? [..._currentAccount.customIncomeCategories, trimmed]
          : null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> removeCustomCategory(
    String category, {
    required bool isIncome,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final existing = isIncome
        ? _currentAccount.customIncomeCategories
        : _currentAccount.customExpenseCategories;
    if (!existing.contains(category)) return;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: isIncome
          ? null
          : _currentAccount.customExpenseCategories
              .where((c) => c != category)
              .toList(),
      customIncomeCategories: isIncome
          ? _currentAccount.customIncomeCategories
              .where((c) => c != category)
              .toList()
          : null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> renameCustomCategory(
    String oldName,
    String newName, {
    required bool isIncome,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmedNew = newName.trim();
    if (trimmedNew.isEmpty || trimmedNew == oldName) return;

    final existing = isIncome
        ? _currentAccount.customIncomeCategories
        : _currentAccount.customExpenseCategories;
    if (!existing.contains(oldName)) return;

    final updatedExpense = isIncome
        ? _currentAccount.customExpenseCategories
        : _currentAccount.customExpenseCategories
            .map((c) => c == oldName ? trimmedNew : c)
            .toList();
    final updatedIncome = isIncome
        ? _currentAccount.customIncomeCategories
            .map((c) => c == oldName ? trimmedNew : c)
            .toList()
        : _currentAccount.customIncomeCategories;

    final updatedAccount = _currentAccount.copyWith(
      customExpenseCategories: updatedExpense,
      customIncomeCategories: updatedIncome,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> addCustomSubcategory(String category, String subcategory) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmed = subcategory.trim();
    if (trimmed.isEmpty) return;

    final Map<String, List<String>> updatedSubcats = Map.from(
      _currentAccount.customSubcategories,
    );
    final existing = updatedSubcats[category] ?? [];
    if (existing.contains(trimmed)) return;

    updatedSubcats[category] = [...existing, trimmed];

    final updatedAccount = _currentAccount.copyWith(
      customSubcategories: updatedSubcats,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> removeCustomSubcategory(
    String category,
    String subcategory,
  ) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final Map<String, List<String>> updatedSubcats = Map.from(
      _currentAccount.customSubcategories,
    );
    final existing = updatedSubcats[category] ?? [];
    if (!existing.contains(subcategory)) return;

    updatedSubcats[category] = existing.where((s) => s != subcategory).toList();
    if (updatedSubcats[category]!.isEmpty) {
      updatedSubcats.remove(category);
    }

    final updatedAccount = _currentAccount.copyWith(
      customSubcategories: updatedSubcats,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> renameCustomSubcategory(
    String category,
    String oldName,
    String newName,
  ) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final trimmedNew = newName.trim();
    if (trimmedNew.isEmpty || trimmedNew == oldName) return;

    final Map<String, List<String>> updatedSubcats = Map.from(
      _currentAccount.customSubcategories,
    );
    final existing = updatedSubcats[category] ?? [];
    if (!existing.contains(oldName)) return;

    updatedSubcats[category] =
        existing.map((s) => s == oldName ? trimmedNew : s).toList();

    final updatedAccount = _currentAccount.copyWith(
      customSubcategories: updatedSubcats,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  Future<void> updateCategoryIcon(String category, int? iconCodePoint) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedIcons = Map<String, int>.from(_currentAccount.categoryIcons);
    if (iconCodePoint == null) {
      updatedIcons.remove(category);
    } else {
      updatedIcons[category] = iconCodePoint;
    }

    final updatedAccount = _currentAccount.copyWith(
      categoryIcons: updatedIcons,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update money pots for the current account
  Future<void> updateMoneyPots(List<MoneyPot> pots) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      moneyPots: pots,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Update money pots section label for the current account
  Future<void> updateMoneyPotsSectionLabel(String? label) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedAccount = _currentAccount.copyWith(
      moneyPotsSectionLabel: label,
      clearMoneyPotsSectionLabel: label == null,
      lastModified: DateTime.now(),
    );

    await _updateCurrentAccount(updatedAccount, persistence);
  }

  /// Add a money pot to the current account
  Future<void> addMoneyPot(MoneyPot pot) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedPots = [..._currentAccount.moneyPots, pot];
    await updateMoneyPots(updatedPots);
  }

  /// Update a money pot in the current account
  Future<void> updateMoneyPot(MoneyPot pot) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final index = _currentAccount.moneyPots.indexWhere((p) => p.id == pot.id);
    if (index < 0) return;

    final updatedPots = List<MoneyPot>.from(_currentAccount.moneyPots);
    updatedPots[index] = pot;
    await updateMoneyPots(updatedPots);
  }

  /// Remove a money pot from the current account
  Future<void> removeMoneyPot(String id) async {
    final persistence = _persistence;
    if (persistence == null) return;

    final updatedPots =
        _currentAccount.moneyPots.where((p) => p.id != id).toList();
    await updateMoneyPots(updatedPots);

    // Clean up orphaned moneyPotId references on pulses
    final potId = MoneyPotId(id);
    final nextPulses = _pulses.toList(growable: true);
    var changed = false;
    for (var i = 0; i < nextPulses.length; i++) {
      if (nextPulses[i].moneyPotId == potId) {
        nextPulses[i] = nextPulses[i].copyWith(moneyPotId: null);
        changed = true;
      }
    }
    if (changed) {
      _pulses = List.unmodifiable(nextPulses);
      _touch();
    }
  }

  Future<void> _updateAccountSetting(
    Account Function(Account) updater, {
    bool syncToAll = false,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    if (syncToAll) {
      await _accountQueue.enqueue(() async {
        final List<Account> updatedAccounts = _accounts.map((account) {
          return updater(account).copyWith(lastModified: DateTime.now());
        }).toList();

        await persistence.saveAccounts(updatedAccounts);
        _accounts = List.unmodifiable(updatedAccounts);

        // Find current account in the updated list
        final currentIndex = updatedAccounts.indexWhere(
          (a) => a.id == _currentAccount.id,
        );
        if (currentIndex >= 0) {
          _currentAccount = updatedAccounts[currentIndex];
        }

        _touch();
      });
    } else {
      final updatedAccount = updater(
        _currentAccount,
      ).copyWith(lastModified: DateTime.now());
      await _updateCurrentAccount(updatedAccount, persistence);
    }
  }

  Future<void> _updateCurrentAccount(
    Account updatedAccount,
    ExpensePersistence persistence,
  ) async {
    await _accountQueue.enqueue(() async {
      final index = _accounts.indexWhere((a) => a.id == updatedAccount.id);
      if (index < 0) return;

      final List<Account> updatedAccounts = List.from(_accounts);
      updatedAccounts[index] = updatedAccount;

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);
      _currentAccount = updatedAccount;

      _touch();
    });
  }

  /// Update settings for a specific account (not necessarily the current one).
  /// This is used by the Account Settings section in Options to edit any account.
  Future<void> updateAccountSettings(
    AccountId accountId, {
    bool syncToAll = false,
    int? paycheckDay,
    bool? clearPaycheckDay,
    bool? paycheckBusinessAdjust,
    PaycheckAdjustDirection? paycheckBusinessAdjustDirection,
    int? startingBalanceCents,
    int? currentBalanceCents,
    TimelineSortOrder? timelineSortOrder,
    TimelineDateSortMode? timelineDateSortMode,
    ViewPeriodMode? viewPeriodMode,
    TimelineViewMode? timelineViewMode,
    bool? timelineShowClearedItems,
    bool? timelineShowSkippedItems,
    bool? timelineGroupByDate,
    bool? timelineGroupByTheme,
    bool? timelineSplitClearedAndPending, // [NEW]
    bool? timelineShowPulseOrigin,
    bool? timelineShowPulseOriginMonth,
    bool? timelineShowPulseOriginSheet,
    bool? timelineShowPulseOriginGrid,
    MonthTotalsDisplayMode? monthTotalsDisplayMode,
    MonthCardDisplayMode? monthCardDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayMode,
    MultiMonthDisplayMode? multiMonthDisplayModeMonth,
    MultiMonthDisplayMode? multiMonthDisplayModeSheet,
    MultiMonthDisplayMode? multiMonthDisplayModeGrid,
    DayFormat? dayFormat,
    TimelineSwipeAction? timelineSwipeLeft,
    TimelineSwipeAction? timelineSwipeRight,
    TimelineTapAction? timelineTapAction,
    PulseSwipeAction? pulseSwipeLeft,
    PulseSwipeAction? pulseSwipeRight,
    PulseDisplayMode? pulseDisplayMode,
    bool? enableTabSwipe,
    bool? timelineUseZeroBaseline,
    TerminologyPreset? terminologyPreset,
    PulsesFilterType? pulseFilterType,
    PulsesGroupBy? pulseGroupBy,
    bool? pulseShowArchived,
    CategoryPresetMode? categoryPresetMode,
    String? customPulseLabel,
    String? customTimelineLabel,
    Map<String, int>? categoryIcons,
    bool? balanceUpdatesDisabled,
    bool? notificationsEnabled,
    bool? dailyAlertEnabled,
    int? dailyAlertHour,
    int? dailyAlertMinute,
    bool? weeklyAlertEnabled,
    int? weeklyAlertHour,
    int? weeklyAlertMinute,
    bool? weeklySummaryEnabled,
    int? weeklySummaryHour,
    int? weeklySummaryMinute,
    int? weekStartDay,
    Map<String, List<String>>? customSubcategories, // [NEW]
    Set<String>? dismissedInsightIds,
    Set<String>? pinnedInsightIds,
    bool? includeInternalTransfers,
  }) async {
    final persistence = _persistence;
    if (persistence == null) return;

    await _accountQueue.enqueue(() async {
      // 1. Determine which fields are being updated
      // 2. Apply to the specific account
      // 3. If syncToAll is true, apply syncable fields to ALL accounts

      final List<Account> updatedAccounts = _accounts
          .map((account) {
            final isTarget = account.id == accountId;

            // If not the target and syncToAll is false, skip
            if (!isTarget && !syncToAll) return account;

            // If not the target but syncToAll is true, only update SYNCABLE fields
            final shouldUpdate = isTarget || syncToAll;
            if (!shouldUpdate) return account;

            return account.copyWith(
              // Account-specific (Only update if isTarget)
              paycheckDay: isTarget
                  ? (paycheckDay ?? account.paycheckDay)
                  : account.paycheckDay,
              clearPaycheckDay: isTarget ? (clearPaycheckDay ?? false) : false,
              paycheckBusinessAdjust: isTarget
                  ? (paycheckBusinessAdjust ?? account.paycheckBusinessAdjust)
                  : account.paycheckBusinessAdjust,
              paycheckBusinessAdjustDirection: isTarget
                  ? (paycheckBusinessAdjustDirection ??
                      account.paycheckBusinessAdjustDirection)
                  : account.paycheckBusinessAdjustDirection,
              startingBalanceCents: isTarget
                  ? (startingBalanceCents ?? account.startingBalanceCents)
                  : account.startingBalanceCents,
              currentBalanceCents: isTarget
                  ? (currentBalanceCents ?? account.currentBalanceCents)
                  : account.currentBalanceCents,
              viewPeriodMode: isTarget
                  ? (viewPeriodMode ?? account.viewPeriodMode)
                  : account.viewPeriodMode,

              // Syncable fields (Update if isTarget OR if syncToAll)
              timelineSortOrder: timelineSortOrder ?? account.timelineSortOrder,
              timelineDateSortMode:
                  timelineDateSortMode ?? account.timelineDateSortMode,
              timelineViewMode: timelineViewMode ?? account.timelineViewMode,
              timelineShowClearedItems:
                  timelineShowClearedItems ?? account.timelineShowClearedItems,
              timelineShowSkippedItems:
                  timelineShowSkippedItems ?? account.timelineShowSkippedItems,
              timelineGroupByDate:
                  timelineGroupByDate ?? account.timelineGroupByDate,
              timelineGroupByTheme:
                  timelineGroupByTheme ?? account.timelineGroupByTheme,
              timelineSplitClearedAndPending: timelineSplitClearedAndPending ??
                  account.timelineSplitClearedAndPending, // [NEW]
              timelineShowPulseOrigin: timelineShowPulseOrigin,
              timelineShowPulseOriginMonth: timelineShowPulseOriginMonth ??
                  account.timelineShowPulseOriginMonth,

              timelineShowPulseOriginSheet: timelineShowPulseOriginSheet ??
                  account.timelineShowPulseOriginSheet,
              timelineShowPulseOriginGrid: timelineShowPulseOriginGrid ??
                  account.timelineShowPulseOriginGrid,
              monthTotalsDisplayMode:
                  monthTotalsDisplayMode ?? account.monthTotalsDisplayMode,
              monthCardDisplayMode:
                  monthCardDisplayMode ?? account.monthCardDisplayMode,
              multiMonthDisplayMode: multiMonthDisplayMode,
              multiMonthDisplayModeMonth: multiMonthDisplayModeMonth ??
                  account.multiMonthDisplayModeMonth,
              multiMonthDisplayModeSheet: multiMonthDisplayModeSheet ??
                  account.multiMonthDisplayModeSheet,
              multiMonthDisplayModeGrid: multiMonthDisplayModeGrid ??
                  account.multiMonthDisplayModeGrid,
              dayFormat: dayFormat ?? account.dayFormat,
              timelineSwipeLeft: timelineSwipeLeft ?? account.timelineSwipeLeft,
              timelineSwipeRight:
                  timelineSwipeRight ?? account.timelineSwipeRight,
              timelineTapAction: timelineTapAction ?? account.timelineTapAction,
              pulseSwipeLeft: pulseSwipeLeft ?? account.pulseSwipeLeft,
              pulseSwipeRight: pulseSwipeRight ?? account.pulseSwipeRight,
              pulseDisplayMode: pulseDisplayMode ?? account.pulseDisplayMode,
              enableTabSwipe: enableTabSwipe ?? account.enableTabSwipe,
              timelineUseZeroBaseline:
                  timelineUseZeroBaseline ?? account.timelineUseZeroBaseline,
              terminologyPreset: terminologyPreset ?? account.terminologyPreset,
              pulseFilterType: pulseFilterType ?? account.pulseFilterType,
              pulseGroupBy: pulseGroupBy ?? account.pulseGroupBy,
              pulseShowArchived: pulseShowArchived ?? account.pulseShowArchived,
              categoryPresetMode:
                  categoryPresetMode ?? account.categoryPresetMode,
              customPulseLabel: customPulseLabel ?? account.customPulseLabel,
              customTimelineLabel:
                  customTimelineLabel ?? account.customTimelineLabel,
              customSubcategories:
                  customSubcategories ?? account.customSubcategories, // [NEW]
              categoryIcons: categoryIcons ?? account.categoryIcons,
              balanceUpdatesDisabled:
                  balanceUpdatesDisabled ?? account.balanceUpdatesDisabled,
              notificationsEnabled:
                  notificationsEnabled ?? account.notificationsEnabled,
              dailyAlertEnabled: dailyAlertEnabled ?? account.dailyAlertEnabled,
              dailyAlertHour: dailyAlertHour ?? account.dailyAlertHour,
              dailyAlertMinute: dailyAlertMinute ?? account.dailyAlertMinute,
              weeklyAlertEnabled:
                  weeklyAlertEnabled ?? account.weeklyAlertEnabled,
              weeklyAlertHour: weeklyAlertHour ?? account.weeklyAlertHour,
              weeklyAlertMinute: weeklyAlertMinute ?? account.weeklyAlertMinute,
              weeklySummaryEnabled:
                  weeklySummaryEnabled ?? account.weeklySummaryEnabled,
              weeklySummaryHour: weeklySummaryHour ?? account.weeklySummaryHour,
              weeklySummaryMinute:
                  weeklySummaryMinute ?? account.weeklySummaryMinute,
              weekStartDay: weekStartDay ?? account.weekStartDay,
              dismissedInsightIds:
                  dismissedInsightIds ?? account.settings.dismissedInsightIds,
              pinnedInsightIds:
                  pinnedInsightIds ?? account.settings.pinnedInsightIds,
              includeInternalTransfers: includeInternalTransfers ??
                  account.settings.includeInternalTransfers,
              lastModified: DateTime.now(),
            );
          })
          .cast<Account>()
          .toList();

      await persistence.saveAccounts(updatedAccounts);
      _accounts = List.unmodifiable(updatedAccounts);

      // Refresh _currentAccount from the updated list
      final currentIndex = updatedAccounts.indexWhere(
        (a) => a.id == _currentAccount.id,
      );
      if (currentIndex >= 0) {
        _currentAccount = updatedAccounts[currentIndex];
      }

      _touch();
    });
  }
}
