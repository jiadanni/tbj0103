part of '../expense_store.dart';

extension AccountOperations on ExpenseStore {
  Future<void> switchAccount(AccountId accountId) async {
    if (accountId == _currentAccount.id) return;
    final persistence = _persistence;
    if (persistence == null) return;

    // Track this as the pending switch - supersedes any earlier pending switch
    _pendingSwitchAccountId = accountId;
    // Increment operation ID to invalidate any in-flight operations
    final operationId = ++_switchOperationId;

    await _accountQueue.enqueue(() async {
      await _switchAccountInternal(accountId, operationId);
    });
  }

  /// Internal implementation of account switching, must be called from within
  /// an _accountQueue.enqueue block or during initialization.
  ///
  /// [operationId] is used to detect superseded operations. If the current
  /// [_switchOperationId] differs from [operationId], this operation was
  /// superseded by a newer switch request and should abort.
  Future<void> _switchAccountInternal(
    AccountId accountId, [
    int? operationId,
  ]) async {
    final persistence = _persistence;
    if (persistence == null) return;
    if (accountId == _currentAccount.id) return;

    // Check if this switch was superseded by a newer request
    // Use both account ID and operation ID for robust detection
    if (_pendingSwitchAccountId != accountId) {
      debugLog(
        LogCategory.persistence,
        'Account switch to $accountId superseded by $_pendingSwitchAccountId',
      );
      return;
    }
    if (operationId != null && _switchOperationId != operationId) {
      debugLog(
        LogCategory.persistence,
        'Account switch operation $operationId superseded by $_switchOperationId',
      );
      return;
    }

    try {
      // Ensure current work is saved before switching
      _debounceTimer?.cancel();
      await _saveQueue.enqueue(
        () => persistence.save(_currentAccount.id, _snapshot()),
      );

      // Check again after save - both account ID and operation ID
      if (_pendingSwitchAccountId != accountId) return;
      if (operationId != null && _switchOperationId != operationId) return;

      // Validate account still exists
      final nextAccount = _accounts.cast<Account?>().firstWhere(
            (a) => a?.id == accountId,
            orElse: () => null,
          );
      if (nextAccount == null) {
        debugLog(
          LogCategory.persistence,
          'Account $accountId no longer exists, aborting switch',
        );
        return;
      }

      final snapshot = await _accountService?.loadAccountData(accountId);

      // Final check after async load - operation ID provides definitive answer
      if (operationId != null && _switchOperationId != operationId) {
        debugLog(
          LogCategory.persistence,
          'Account switch to $accountId aborted: operation $operationId superseded by $_switchOperationId after load',
        );
        return;
      }
      if (_pendingSwitchAccountId != accountId) return;

      if (snapshot != null) {
        _currentAccount = nextAccount;
        _selectedMonth = monthOnly(DateTime.now());
        _timelineItems = List.unmodifiable(snapshot.timelineItems);
        _pulses = List.unmodifiable(snapshot.pulses);

        await persistence.setCurrentAccountId(accountId);

        _cacheDirty = true;
        _touch();
      }
    } finally {
      // Only clear if we are the one who set it (and no newer request came in)
      if (_pendingSwitchAccountId == accountId) {
        _pendingSwitchAccountId = null;
      }
    }
  }

  Future<void> createAccount(
    String name, {
    TestDatasetSize? testSize,
    int? iconCodePoint,
  }) async {
    final service = _accountService;
    if (service == null) return;

    await _accountQueue.enqueue(() async {
      final updatedAccounts = await service.createAccount(
        _accounts,
        name,
        testSize: testSize,
        iconCodePoint: iconCodePoint,
      );

      _accounts = List.unmodifiable(updatedAccounts);
      _touch();
    });
  }

  Future<void> deleteAccount(AccountId accountId) async {
    if (_accounts.length <= 1) return;

    final service = _accountService;
    if (service == null) return;

    await _accountQueue.enqueue(() async {
      // Re-validate inside the queue
      if (_accounts.length <= 1) return;
      if (!_accounts.any((a) => a.id == accountId)) return;

      final result = await service.deleteAccount(
        _accounts,
        accountId,
        _currentAccount.id,
      );

      _accounts = List.unmodifiable(result.accounts);

      if (result.wasCurrent) {
        // Safe to call internal logic as we are already in the queue
        await _switchAccountInternal(_accounts.first.id);
      } else {
        _touch();
      }
    });
  }

  Future<void> updateAccount({
    required AccountId accountId,
    String? name,
    int? iconCodePoint,
  }) async {
    final service = _accountService;
    if (service == null) return;

    await _accountQueue.enqueue(() async {
      final updatedAccounts = await service.updateAccount(
        _accounts,
        accountId,
        name: name,
        iconCodePoint: iconCodePoint,
      );

      _accounts = List.unmodifiable(updatedAccounts);

      // Update local current account if it was updated
      if (accountId == _currentAccount.id) {
        _currentAccount = _accounts.firstWhere((a) => a.id == accountId);
      }

      _touch();
    });
  }

  /// Get an account by ID (or null if not found)
  Account? getAccountById(AccountId accountId) {
    final index = _accounts.indexWhere((a) => a.id == accountId);
    return index >= 0 ? _accounts[index] : null;
  }
}
