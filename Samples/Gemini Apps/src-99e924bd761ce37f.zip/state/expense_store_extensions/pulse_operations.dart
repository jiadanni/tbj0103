part of '../expense_store.dart';

extension PulseOperations on ExpenseStore {
  List<PulseEntry> pulsesForMonth(DateTime month, {PeriodInfo? periodInfo}) {
    _ensureCachesValid();
    String cacheKey;

    if (periodInfo != null) {
      cacheKey =
          '${periodInfo.start.millisecondsSinceEpoch}_${periodInfo.end.millisecondsSinceEpoch}';
    } else {
      final m = monthOnly(month);
      cacheKey = '${m.year}${m.month.toString().padLeft(2, '0')}';
    }

    // Return cached result if available
    if (_pulseForMonthCache.containsKey(cacheKey)) {
      return _pulseForMonthCache[cacheKey]!;
    }

    // Compute and cache
    final result = periodInfo != null
        ? (_pulses
            .where((p) => periodInfo.containsDate(p.date))
            .toList(growable: false)
          ..sort((a, b) => b.date.compareTo(a.date)))
        : (_pulses
            .where(
              (p) =>
                  p.date.year == monthOnly(month).year &&
                  p.date.month == monthOnly(month).month,
            )
            .toList(growable: false)
          ..sort((a, b) => b.date.compareTo(a.date)));

    _pulseForMonthCache[cacheKey] = result;
    return result;
  }

  /// Backwards-compatible alias for pulsesForMonth
  List<PulseEntry> pulseForMonth(DateTime month, {PeriodInfo? periodInfo}) {
    return pulsesForMonth(month, periodInfo: periodInfo);
  }

  List<PulseEntry> pulsesForSelectedMonth({PeriodInfo? periodInfo}) {
    final cacheKey = periodInfo != null
        ? '${periodInfo.start.millisecondsSinceEpoch}_${periodInfo.end.millisecondsSinceEpoch}'
        : '${_selectedMonth.year}${_selectedMonth.month.toString().padLeft(2, '0')}';

    _ensureCachesValid();

    if (_cachedSelectedMonthPulses != null &&
        _cachedPulsesCacheKey == cacheKey) {
      return _cachedSelectedMonthPulses!;
    }

    _cachedPulsesCacheKey = cacheKey;
    _cachedSelectedMonthPulses = pulsesForMonth(
      _selectedMonth,
      periodInfo: periodInfo,
    );
    return _cachedSelectedMonthPulses!;
  }

  /// Get filtered pulse based on search query and filter settings.
  /// Results are cached and only recomputed when inputs change.
  List<PulseEntry> getFilteredPulses({
    required String searchQuery,
    required PulsesFilterType filterType,
    String? filterCategory,
    required bool showArchived,
  }) {
    // Compute hash of pulse IDs to detect data changes
    final pulseHash = Object.hashAll(_pulses.map((p) => p.id));

    final newKey = (
      search: searchQuery,
      type: filterType,
      category: filterCategory,
      archived: showArchived,
      hash: pulseHash,
    );

    // Return cached if key matches
    if (_filteredCacheKey == newKey && _cachedFilteredPulses != null) {
      return _cachedFilteredPulses!;
    }

    _filteredCacheKey = newKey;

    // Filter pulses
    final filtered = <PulseEntry>[];
    for (final pulse in _pulses) {
      // Search query matching
      if (searchQuery.isNotEmpty) {
        final query = searchQuery.toLowerCase();
        final matchesLabel = pulse.label.toLowerCase().contains(query);
        final matchesCategory =
            pulse.category?.toLowerCase().contains(query) ?? false;
        final matchesOrigin =
            pulse.origin?.toLowerCase().contains(query) ?? false;
        final matchesNotes =
            pulse.notes?.toLowerCase().contains(query) ?? false;

        if (!matchesLabel &&
            !matchesCategory &&
            !matchesOrigin &&
            !matchesNotes) {
          continue;
        }
      }

      // Archived filter
      final timelineItem = _timelineItems.firstWhereOrNull(
        (p) => p.id == pulse.timelineItemId,
      );
      if (!showArchived && timelineItem?.archived == true) {
        continue;
      }

      // Type filter
      switch (filterType) {
        case PulsesFilterType.all:
          break;
        case PulsesFilterType.income:
          if (pulse.amountMinorUnits <= 0) continue;
          break;
        case PulsesFilterType.expenses:
          if (pulse.amountMinorUnits >= 0) continue;
          break;
        case PulsesFilterType.category:
          if (pulse.category != filterCategory) continue;
          break;
        case PulsesFilterType.debt:
          if (pulse.type != PulseType.debt) continue;
          break;
        case PulsesFilterType.oneOff:
          if (pulse.type != PulseType.oneOff &&
              pulse.type != PulseType.oneOffIncome) {
            continue;
          }
          break;
        case PulsesFilterType.recurring:
          // Recurring types: recurring expense, recurring income, debt (debt payments recur)
          if (pulse.type != PulseType.recurring &&
              pulse.type != PulseType.recurringIncome &&
              pulse.type != PulseType.debt) {
            continue;
          }
          break;
        case PulsesFilterType.envelopes:
          if (pulse.type != PulseType.spendingEnvelope) continue;
          break;
      }

      filtered.add(pulse);
    }

    _cachedFilteredPulses = filtered;
    return filtered;
  }

  int plannedTotalCentsForSelectedMonth() {
    return activeTimelineItems.fold(0, (sum, p) => sum + p.amountMinorUnits);
  }

  int paidTotalCentsForSelectedMonth() {
    return pulsesForSelectedMonth().fold(
      0,
      (sum, p) => sum + p.amountMinorUnits,
    );
  }

  List<String> getUserCategories({required bool isIncome}) {
    // Compute hash of items and pulse to detect changes
    int itemsHash = 0;
    for (final item in _timelineItems) {
      itemsHash ^= item.id.hashCode ^ item.category.hashCode;
    }
    int pulseHash = 0;
    for (final p in _pulses) {
      pulseHash ^= p.id.hashCode ^ p.category.hashCode;
    }

    // Return cached result if hashes match
    if (isIncome) {
      if (_cachedUserIncomeCategories != null &&
          _cachedCategoriesItemsHash == itemsHash &&
          _cachedCategoriesPulsesHash == pulseHash) {
        return _cachedUserIncomeCategories!;
      }
    } else {
      if (_cachedUserExpenseCategories != null &&
          _cachedCategoriesItemsHash == itemsHash &&
          _cachedCategoriesPulsesHash == pulseHash) {
        return _cachedUserExpenseCategories!;
      }
    }

    // Update hash
    _cachedCategoriesItemsHash = itemsHash;
    _cachedCategoriesPulsesHash = pulseHash;

    // Compute categories
    final categories = <String>{};

    // Add explicitly configured custom categories first
    if (isIncome) {
      categories.addAll(_currentAccount.customIncomeCategories);
    } else {
      categories.addAll(_currentAccount.customExpenseCategories);
    }

    for (final item in _timelineItems) {
      if (item.type.isIncomeType == isIncome) {
        final cat = item.category;
        if (cat != null && cat.isNotEmpty) {
          categories.add(cat);
        }
      }
    }
    for (final pulse in _pulses) {
      if (pulse.type.isIncomeType == isIncome) {
        if (pulse.category != null && pulse.category!.isNotEmpty) {
          categories.add(pulse.category!);
        }
      }
    }

    final result = categories.toList()..sort();

    // Cache result
    if (isIncome) {
      _cachedUserIncomeCategories = result;
    } else {
      _cachedUserExpenseCategories = result;
    }

    return result;
  }

  void upsertPulse(PulseEntry entry) {
    final normalized = entry;
    _pulses = ExpenseStore._replaceOrAddById<PulseEntry, EntryId>(
      _pulses,
      normalized,
      (p) => p.id,
    );
    _touch();
  }

  void deletePulse(EntryId id) {
    _pulses = List.unmodifiable(_pulses.where((p) => p.id != id));
    _touch();
  }

  /// Removes duplicate pulses that have identical content.
  /// Deduplicates based on:
  /// - Linked items: TimelineItemId + Date (YYYY-MM-DD)
  /// - Unlinked items: Label + Amount + Date (YYYY-MM-DD)
  int cleanupDuplicatePulses() {
    final seen = <String, EntryId>{};
    final toDelete = <EntryId>{};

    for (final pulse in _pulses) {
      String key;
      final dateStr =
          '${pulse.date.year}-${pulse.date.month}-${pulse.date.day}';

      if (pulse.timelineItemId != null) {
        // Linked: Same Item ID on Same Day = Duplicate
        key = 'LINKED_${pulse.timelineItemId!.value}_$dateStr';
      } else {
        // Unlinked: Same Label + Amount on Same Day = Duplicate
        key = 'UNLINKED_${pulse.label}_${pulse.amountMinorUnits}_$dateStr';
      }

      if (seen.containsKey(key)) {
        // We found a duplicate!
        // To decide which to keep, we could check which one has more data (e.g. notes),
        // but if they are true duplicates, it doesn't matter.
        // We'll keep the first one we saw (arbitrary) and delete this one.
        toDelete.add(pulse.id);
      } else {
        seen[key] = pulse.id;
      }
    }

    if (toDelete.isNotEmpty) {
      _pulses = List.unmodifiable(
        _pulses.where((p) => !toDelete.contains(p.id)),
      );
      _touch(forceImmediate: true); // Save immediately to persist the cleanup
    }

    return toDelete.length;
  }
}
