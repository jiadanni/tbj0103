part of '../expense_store.dart';

extension TimelineOperations on ExpenseStore {
  void setSelectedMonth(DateTime month) {
    final next = monthOnly(month);
    if (_selectedMonth.year == next.year &&
        _selectedMonth.month == next.month) {
      return;
    }
    _selectedMonth = next;
    selectedMonthNotifier.value = next; // Selective notification
    _touch();
  }

  void goToPreviousMonth() {
    _selectedMonth = monthOnly(
      DateTime.utc(_selectedMonth.year, _selectedMonth.month - 1),
    );
    _touch();
  }

  void goToNextMonth() {
    _selectedMonth = monthOnly(
      DateTime.utc(_selectedMonth.year, _selectedMonth.month + 1),
    );
    _touch();
  }

  void upsertTimelineItem(TimelineItem item) {
    _timelineItems =
        ExpenseStore._replaceOrAddById<TimelineItem, TimelineItemId>(
      _timelineItems,
      item,
      (p) => p.id,
    );
    _touch();
  }

  void setTimelineItemArchived(TimelineItemId id, bool archived) {
    final index = _timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final next = _timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(archived: archived);
    _timelineItems = List.unmodifiable(next);

    if (!archived) {
      _pulses = List.unmodifiable(_pulses.where((p) => p.timelineItemId != id));
    }
    _touch();
  }

  void deleteTimelineItem(TimelineItemId id, {bool keepHistory = true}) {
    _timelineItems = List.unmodifiable(_timelineItems.where((p) => p.id != id));

    if (keepHistory) {
      // Unlink pulses (make them standalone)
      final nextPulses = _pulses.toList(growable: true);
      for (var i = 0; i < nextPulses.length; i++) {
        if (nextPulses[i].timelineItemId == id) {
          nextPulses[i] = nextPulses[i].copyWith(
            timelineItemId: null,
            scheduledDate: null,
            scheduledAmountMinorUnits: null,
          );
        }
      }
      _pulses = List.unmodifiable(nextPulses);
    } else {
      // Delete associated pulses
      _pulses = List.unmodifiable(_pulses.where((p) => p.timelineItemId != id));
    }
    _touch();
  }

  void markTimelineItemClearedTemporarily(
    TimelineItemId id, {
    Duration? duration,
  }) {
    _recentlyClearedTimelineItemIds.add(id);
    recentlyClearedNotifier.value = Set.from(_recentlyClearedTimelineItemIds);

    _recentlyClearedTimers.remove(id)?.cancel();
    _recentlyClearedTimers[id] = Timer(
      duration ?? ExpenseStore._kClearedVisibleDuration,
      () {
        if (_recentlyClearedTimelineItemIds.remove(id)) {
          recentlyClearedNotifier.value = Set.from(
            _recentlyClearedTimelineItemIds,
          );
          // ignore: deprecated_member_use_from_same_package
          notifyListeners();
        }
        _recentlyClearedTimers.remove(id)?.cancel();
      },
    );
    // ignore: deprecated_member_use_from_same_package
    notifyListeners();
  }

  void clearTimelineItemClearedTemporarily(TimelineItemId id) {
    _recentlyClearedTimers.remove(id)?.cancel();
    if (_recentlyClearedTimelineItemIds.remove(id)) {
      recentlyClearedNotifier.value = Set.from(_recentlyClearedTimelineItemIds);
      // ignore: deprecated_member_use_from_same_package
      notifyListeners();
    }
  }

  /// Skips a specific instance of a timeline item by adding its month to the skipped list.
  void skipTimelineItemInstance(TimelineItemId id, DateTime date) {
    final index = _timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final item = _timelineItems[index];
    final normalizedDate = DateMath.toUtcMonth(date);

    // Avoid duplicates
    if (item.skippedDates?.any(
          (d) => DateMath.toUtcMonth(d).isAtSameMomentAs(normalizedDate),
        ) ??
        false) {
      return;
    }

    final newSkipped = <DateTime>[...?item.skippedDates, normalizedDate];

    final next = _timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(skippedDates: Optional(newSkipped));
    _timelineItems = List.unmodifiable(next);
    _touch();
  }

  /// Removes a specific date from the skipped list (un-skip).
  void unskipTimelineItemInstance(TimelineItemId id, DateTime date) {
    final index = _timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final item = _timelineItems[index];
    if (item.skippedDates == null) return;

    final normalizedDate = DateMath.toUtcMonth(date);
    final newSkipped = item.skippedDates!
        .where((d) => !DateMath.toUtcMonth(d).isAtSameMomentAs(normalizedDate))
        .toList();

    if (newSkipped.length == item.skippedDates!.length) return; // No change

    final next = _timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(skippedDates: Optional(newSkipped));
    _timelineItems = List.unmodifiable(next);
    _touch();
  }

  /// Sets the pause window for a timeline item.
  /// If [autoResumeDate] is null, it pauses indefinitely.
  void setTimelineItemPauseWindow(
    TimelineItemId id, {
    required DateTime pausedDate,
    DateTime? autoResumeDate,
  }) {
    final index = _timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final next = _timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(
      pausedDate: Optional(pausedDate),
      autoResumeDate: autoResumeDate != null
          ? Optional(autoResumeDate)
          : const Optional.absent(),
    );
    _timelineItems = List.unmodifiable(next);
    _touch();
  }

  /// Resumes a paused timeline item by clearing the pause window.
  void resumeTimelineItem(TimelineItemId id) {
    final index = _timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final next = _timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(
      pausedDate: const Optional.absent(),
      autoResumeDate: const Optional.absent(),
    );
    _timelineItems = List.unmodifiable(next);
    _touch();
  }
}
