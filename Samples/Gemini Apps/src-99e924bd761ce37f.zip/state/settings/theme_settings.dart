import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';

/// Defines a complete immersive color palette for a theme preset.
/// Each theme is fully self-contained with its own background, surfaces, and brightness.
/// No light/dark mode variants - each theme IS its brightness.
class ThemePalette {
  const ThemePalette({
    required this.name,
    required this.primary,
    required this.background,
    required this.surface,
    required this.surfaceContainer,
    required this.brightness,
    required this.debitColor,
    required this.creditColor,
    required this.neutralColor,
  });

  /// Display name for the theme
  final String name;

  /// Primary/accent color for buttons, links, highlights
  final Color primary;

  /// Main background color (scaffold, app background)
  final Color background;

  /// Surface color for cards, dialogs, sheets
  final Color surface;

  /// Elevated surface color for containers, elevated cards
  final Color surfaceContainer;

  /// Whether this is a light or dark theme (determines text contrast)
  final Brightness brightness;

  /// Default debit (expense) color for this theme
  final Color debitColor;

  /// Default credit (income) color for this theme
  final Color creditColor;

  /// Default neutral color for this theme
  final Color neutralColor;
}

class ThemeSettings extends ChangeNotifier {
  ThemeSettings(
    this._storage, {
    required AppThemePreset initialAppThemePreset,
    required bool initialUseCustomColors,
    required int initialDebitColor,
    required int initialCreditColor,
    required int initialNeutralColor,
    required TextScalePreset initialTextScalePreset,
    required FontPreset initialFontPreset,
    required bool initialRandomizeColorOnResume,
    required bool initialRandomizeColorOnPeriodChange,
  })  : _appThemePreset = initialAppThemePreset,
        _useCustomColors = initialUseCustomColors,
        _debitColorValue = initialDebitColor,
        _creditColorValue = initialCreditColor,
        _neutralColorValue = initialNeutralColor,
        _textScalePreset = initialTextScalePreset,
        _fontPreset = initialFontPreset,
        _randomizeColorOnResume = initialRandomizeColorOnResume,
        _randomizeColorOnPeriodChange = initialRandomizeColorOnPeriodChange;

  final StorageProvider _storage;

  static const _kAppThemePreset = 'settings.colors.appThemePreset';
  static const _kUseCustomColors = 'settings.colors.useCustomColors';
  static const _kDebitColor = 'settings.colors.debit';
  static const _kCreditColor = 'settings.colors.credit';
  static const _kNeutralColor = 'settings.colors.neutral';
  static const _kTextScalePreset = 'settings.textScale';
  static const _kFontPreset = 'settings.fontPreset';
  static const _kRandomizeColorOnResume = 'settings.colors.randomizeOnResume';
  static const _kRandomizeColorOnPeriodChange =
      'settings.colors.randomizeOnPeriodChange';

  static const Map<AppThemePreset, ThemePalette> _themePalettes = {
    // ═══════════════════════════════════════════════════════════════
    // LIGHT THEMES (bright backgrounds, dark text)
    // ═══════════════════════════════════════════════════════════════

    // Classic - Professional slate blue, elegant and calm
    AppThemePreset.classic: ThemePalette(
      name: 'Classic',
      primary: Color(0xFF303F9F), // Deeper indigo for contrast
      background: Color(0xFFC5CAE9), // Deep indigo wash (Immersive)
      surface: Color(0xFFE8EAF6), // Light indigo surface
      surfaceContainer: Color(0xFFD1D9E6), // Medium indigo elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFB71C1C), // Deeper Red
      creditColor: Color(0xFF1B5E20), // Deeper Green
      neutralColor: Color(0xFF455A64), // Blue grey
    ),

    // Monochrome - Clean neutral gray, minimal and focused
    AppThemePreset.monochrome: ThemePalette(
      name: 'Monochrome',
      primary: Color(0xFF455A64), // Darker blue grey for contrast
      background: Color(0xFFECEFF1), // Light blue-gray
      surface: Color(0xFFFAFAFA), // Near-white surface for cards
      surfaceContainer: Color(0xFFE0E0E0), // Light gray elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFB71C1C), // Deep red
      creditColor: Color(0xFF2E7D32), // Deep green
      neutralColor: Color(0xFF546E7A), // Blue grey
    ),

    // Sunflower - Warm cheerful yellow, energetic
    AppThemePreset.sunflower: ThemePalette(
      name: 'Sunflower',
      primary: Color(0xFFE65100), // Deep orange for contrast
      background: Color(0xFFFFECB3), // Rich buttery yellow (Immersive)
      surface: Color(0xFFFFF3C4), // Warm cream that matches the yellow
      surfaceContainer: Color(
        0xFFFFE082,
      ), // Slightly deeper yellow for elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFBF360C), // Deep burnt orange
      creditColor: Color(0xFF1B5E20), // Dark forest green
      neutralColor: Color(0xFF5D4037), // Brown
    ),

    // Blossom - Soft pastel pink, gentle and romantic
    AppThemePreset.blossom: ThemePalette(
      name: 'Blossom',
      primary: Color(0xFFC2185B), // Deeper rose for better contrast
      background: Color(0xFFF8BBD0), // Rich pink (Immersive)
      surface: Color(0xFFFCE4EC), // Light pink surface
      surfaceContainer: Color(0xFFF8BBD0), // Match background for elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFAD1457), // Deep rose
      creditColor: Color(0xFF00695C), // Deep teal for contrast
      neutralColor: Color(0xFF5D4037), // Brown for better visibility
    ),

    // Lavender - Elegant soft purple, soothing
    AppThemePreset.lavender: ThemePalette(
      name: 'Lavender',
      primary: Color(0xFF6A1B9A), // Deeper purple for contrast
      background: Color(0xFFE1BEE7), // Rich lavender (Immersive)
      surface: Color(0xFFEDE7F6), // Soft purple surface
      surfaceContainer: Color(0xFFD1C4E9), // Medium purple elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFB71C1C), // Deep red - better contrast on purple
      creditColor: Color(0xFF1B5E20), // Deep green - standard semantic color
      neutralColor: Color(0xFF37474F), // Dark blue-grey
    ),

    // Sage - Natural calming green, grounded
    AppThemePreset.sage: ThemePalette(
      name: 'Sage',
      primary: Color(0xFF33691E), // Deeper green for contrast
      background: Color(0xFFC5E1A5), // Rich sage green (Immersive)
      surface: Color(0xFFE8F5E9), // Very light green surface
      surfaceContainer: Color(0xFFDCEDC8), // Light sage elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFB71C1C), // Deep red
      creditColor: Color(
        0xFF0D47A1,
      ), // Deep blue - contrasts with green background
      neutralColor: Color(0xFF4E342E), // Dark Brown
    ),

    // Sky - Fresh airy blue, open and light
    AppThemePreset.sky: ThemePalette(
      name: 'Sky',
      primary: Color(0xFF01579B), // Deeper blue for contrast
      background: Color(0xFFB3E5FC), // Rich sky blue (Immersive)
      surface: Color(0xFFE1F5FE), // Light sky surface
      surfaceContainer: Color(0xFF81D4FA), // Bright sky elevation
      brightness: Brightness.light,
      debitColor: Color(0xFFB71C1C), // Deep red - standard semantic color
      creditColor: Color(0xFF1B5E20), // Deep green - contrasts with blue
      neutralColor: Color(0xFF37474F), // Dark Blue grey
    ),

    // Rose - Warm coral pink, friendly
    AppThemePreset.rose: ThemePalette(
      name: 'Rose',
      primary: Color(0xFFBF360C), // Deep coral for contrast
      background: Color(0xFFFFCCBC), // Deep peach (Immersive)
      surface: Color(0xFFFFE0D6), // Warm peach surface
      surfaceContainer: Color(0xFFFFAB91), // Medium coral elevation
      brightness: Brightness.light,
      debitColor: Color(0xFF880E4F), // Deep magenta (distinct from coral bg)
      creditColor: Color(0xFF1B5E20), // Deep green
      neutralColor: Color(0xFF4E342E), // Dark Brown
    ),

    // Noir - True OLED black, minimal and elegant
    AppThemePreset.noir: ThemePalette(
      name: 'Noir',
      primary: Color(0xFFFFFFFF), // Pure white accent
      background: Color(0xFF000000), // True black
      surface: Color(0xFF1C1C1E), // Dark gray surface
      surfaceContainer: Color(0xFF2C2C2E), // Elevated gray
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF5252), // Bright Red
      creditColor: Color(0xFF69F0AE), // Bright Green
      neutralColor: Color(0xFFE0E0E0), // Light Grey
    ),

    // Midnight - Deep navy blue, focused and calm
    AppThemePreset.midnight: ThemePalette(
      name: 'Midnight',
      primary: Color(0xFF448AFF), // Blue accent
      background: Color(0xFF0D1B2A), // Deep navy
      surface: Color(0xFF1B263B), // Dark blue surface
      surfaceContainer: Color(0xFF415A77), // Elevated blue
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF8A80), // Brighter Red accent
      creditColor: Color(0xFFB9F6CA), // Brighter Green accent
      neutralColor: Color(0xFFBBDEFB), // Lighter blue
    ),

    // Ocean - Rich teal depths, calming and deep
    AppThemePreset.ocean: ThemePalette(
      name: 'Ocean',
      primary: Color(0xFF4DD0E1), // Bright cyan accent
      background: Color(0xFF004D40), // Deeper teal background
      surface: Color(0xFF00695C), // Teal surface (lighter than bg)
      surfaceContainer: Color(0xFF00796B), // Elevated teal (lighter still)
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF8A80), // Bright coral red
      creditColor: Color(0xFFB9F6CA), // Mint green - contrasts with teal
      neutralColor: Color(0xFFB0BEC5), // Light Blue grey
    ),

    // Forest - Deep woodland green, natural and grounded
    AppThemePreset.forest: ThemePalette(
      name: 'Forest',
      primary: Color(0xFFAED581), // Light green accent
      background: Color(0xFF1B5E20), // Deep forest green (Immersive)
      surface: Color(0xFF2E7D32), // Green surface (lighter than bg)
      surfaceContainer: Color(0xFF43A047), // Elevated green (lighter still)
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF8A80), // Bright coral red
      creditColor: Color(0xFF81D4FA), // Light sky blue - contrasts with green
      neutralColor: Color(0xFFD7CCC8), // Light Brown/Tan
    ),

    // Emerald - Rich jewel green, luxurious
    AppThemePreset.emerald: ThemePalette(
      name: 'Emerald',
      primary: Color(0xFF64FFDA), // Bright teal accent
      background: Color(0xFF004D40), // Deep teal (Immersive)
      surface: Color(0xFF00695C), // Jewel surface (lighter than bg)
      surfaceContainer: Color(0xFF00897B), // Elevated emerald (lighter still)
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF80AB), // Bright pink accent
      creditColor: Color(0xFFB2DFDB), // Light teal - harmonious with green
      neutralColor: Color(0xFFE0E0E0), // Light grey
    ),

    // Sunset - Warm amber evening, cozy
    AppThemePreset.sunset: ThemePalette(
      name: 'Sunset',
      primary: Color(0xFFFFB74D), // Amber accent
      background: Color(0xFF3E2723), // Deep brown (Immersive)
      surface: Color(0xFF4E342E), // Warm dark surface
      surfaceContainer: Color(0xFF5D4037), // Elevated amber
      brightness: Brightness.dark,
      debitColor: Color(0xFFFF8A80), // Bright coral red
      creditColor: Color(0xFFA5D6A7), // Light green - standard semantic color
      neutralColor: Color(0xFFD7CCC8), // Lighter brown
    ),

    // Terracotta - Earthy clay tones, warm and grounded
    AppThemePreset.terracotta: ThemePalette(
      name: 'Terracotta',
      primary: Color(0xFFFFAB91), // Coral accent
      background: Color(0xFFBF360C), // Deep rust (Immersive)
      surface: Color(0xFFD84315), // Dark terracotta
      surfaceContainer: Color(0xFFFF7043), // Elevated clay
      brightness: Brightness.dark,
      debitColor: Color(0xFFF8BBD0), // Light pink - better contrast than coral
      creditColor: Color(0xFFA5D6A7), // Light green - standard semantic color
      neutralColor: Color(0xFFF5F5F5), // White-ish grey
    ),

    // Coffee - Rich earthy brown, warm and sophisticated
    AppThemePreset.coffee: ThemePalette(
      name: 'Coffee',
      primary: Color(0xFFD7CCC8), // Light brown accent
      background: Color(0xFF3E2723), // Deep espresso (Immersive)
      surface: Color(0xFF4E342E), // Dark coffee surface
      surfaceContainer: Color(0xFF5D4037), // Elevated brown
      brightness: Brightness.dark,
      debitColor: Color(0xFFFFCCBC), // Softer Coral
      creditColor: Color(0xFFC8E6C9), // Softer Green
      neutralColor: Color(0xFFF5F5F5), // White-ish grey
    ),

    // Crimson - Bold deep red, powerful
    AppThemePreset.crimson: ThemePalette(
      name: 'Crimson',
      primary: Color(0xFFEF9A9A), // Light red accent
      background: Color(0xFFB71C1C), // Deep crimson (Immersive)
      surface: Color(0xFFC62828), // Dark red surface
      surfaceContainer: Color(0xFFD32F2F), // Elevated crimson
      brightness: Brightness.dark,
      debitColor: Color(0xFFFFCDD2), // Slightly stronger pink for visibility
      creditColor: Color(0xFFA5D6A7), // Light green - standard semantic color
      neutralColor: Color(0xFFF5F5F5), // White-ish grey
    ),

    // Berry - Deep magenta, bold and vibrant
    AppThemePreset.berry: ThemePalette(
      name: 'Berry',
      primary: Color(0xFFF48FB1), // Pink accent
      background: Color(0xFF880E4F), // Deep berry (Immersive)
      surface: Color(0xFFAD1457), // Dark magenta surface
      surfaceContainer: Color(0xFFC2185B), // Elevated berry
      brightness: Brightness.dark,
      debitColor: Color(0xFFFCE4EC), // Lighter pink
      creditColor: Color(0xFF80DEEA), // Lighter Cyan
      neutralColor: Color(0xFFF3E5F5), // Lighter purple
    ),
  };

  /// Get the theme palette for a preset
  static ThemePalette getPalette(AppThemePreset preset) =>
      _themePalettes[preset] ?? _themePalettes[AppThemePreset.classic]!;

  static const Map<TextScalePreset, double> _textScaleFactors = {
    TextScalePreset.small: 0.9,
    TextScalePreset.normal: 1.0,
    TextScalePreset.large: 1.1,
    TextScalePreset.extraLarge: 1.25,
  };

  static const Map<FontPreset, String?> _fontFamilies = {
    FontPreset.system: null,
    FontPreset.monospace: 'monospace',
  };

  AppThemePreset _appThemePreset;
  bool _useCustomColors;
  int _debitColorValue;
  int _creditColorValue;
  int _neutralColorValue;
  TextScalePreset _textScalePreset;
  FontPreset _fontPreset;
  bool _randomizeColorOnResume;
  bool _randomizeColorOnPeriodChange;

  AppThemePreset get appThemePreset => _appThemePreset;
  bool get useCustomColors => _useCustomColors;

  Color get debitColor =>
      _useCustomColors ? Color(_debitColorValue) : themePalette.debitColor;
  Color get creditColor =>
      _useCustomColors ? Color(_creditColorValue) : themePalette.creditColor;
  Color get neutralColor =>
      _useCustomColors ? Color(_neutralColorValue) : themePalette.neutralColor;

  TextScalePreset get textScalePreset => _textScalePreset;
  FontPreset get fontPreset => _fontPreset;

  double get textScaleFactor => _textScaleFactors[_textScalePreset] ?? 1.0;
  String? get fontFamily => _fontFamilies[_fontPreset];
  bool get randomizeColorOnResume => _randomizeColorOnResume;
  bool get randomizeColorOnPeriodChange => _randomizeColorOnPeriodChange;
  ThemePalette get themePalette => getPalette(_appThemePreset);
  Color get themeSeedColor => themeSeedColorForPreset(_appThemePreset);

  /// Helper to get seed color without using current themePalette
  static Color themeSeedColorForPreset(AppThemePreset preset) =>
      getPalette(preset).primary;

  set useCustomColors(bool value) {
    if (_useCustomColors == value) return;
    _useCustomColors = value;
    _storage.setBool(_kUseCustomColors, value);
    notifyListeners();
  }

  set appThemePreset(AppThemePreset value) {
    if (_appThemePreset == value) return;
    _appThemePreset = value;
    _storage.setString(
      _kAppThemePreset,
      AppSettingsCodecs.encodeAppThemePreset(value),
    );
    notifyListeners();
  }

  set debitColor(Color value) {
    final intValue = value.toARGB32();
    if (_debitColorValue == intValue) return;
    _debitColorValue = intValue;
    _storage.setInt(_kDebitColor, intValue);
    // Explicitly enabling custom colors when user sets a color manually
    if (!_useCustomColors) {
      _useCustomColors = true;
      _storage.setBool(_kUseCustomColors, true);
    }
    notifyListeners();
  }

  set creditColor(Color value) {
    final intValue = value.toARGB32();
    if (_creditColorValue == intValue) return;
    _creditColorValue = intValue;
    _storage.setInt(_kCreditColor, intValue);
    // Explicitly enabling custom colors when user sets a color manually
    if (!_useCustomColors) {
      _useCustomColors = true;
      _storage.setBool(_kUseCustomColors, true);
    }
    notifyListeners();
  }

  set neutralColor(Color value) {
    final intValue = value.toARGB32();
    if (_neutralColorValue == intValue) return;
    _neutralColorValue = intValue;
    _storage.setInt(_kNeutralColor, intValue);
    // Explicitly enabling custom colors when user sets a color manually
    if (!_useCustomColors) {
      _useCustomColors = true;
      _storage.setBool(_kUseCustomColors, true);
    }
    notifyListeners();
  }

  set textScalePreset(TextScalePreset value) {
    if (_textScalePreset == value) return;
    _textScalePreset = value;
    _storage.setString(
      _kTextScalePreset,
      AppSettingsCodecs.encodeTextScalePreset(value),
    );
    notifyListeners();
  }

  set fontPreset(FontPreset value) {
    if (_fontPreset == value) return;
    _fontPreset = value;
    _storage.setString(_kFontPreset, AppSettingsCodecs.encodeFontPreset(value));
    notifyListeners();
  }

  set randomizeColorOnResume(bool value) {
    if (_randomizeColorOnResume == value) return;
    _randomizeColorOnResume = value;
    _storage.setBool(_kRandomizeColorOnResume, value);
    notifyListeners();
  }

  set randomizeColorOnPeriodChange(bool value) {
    if (_randomizeColorOnPeriodChange == value) return;
    _randomizeColorOnPeriodChange = value;
    _storage.setBool(_kRandomizeColorOnPeriodChange, value);
    notifyListeners();
  }

  void setRandomTheme() {
    appThemePreset = AppThemePreset.getRandom();
  }
}
