import 'package:expense_stalker_mobile/src/models/currency.dart';

enum DayFormat {
  number, // e.g., "1", "2", "28"
  ordinal, // e.g., "1st", "2nd", "28th"
  ordinalMonth, // e.g., "21st Jan"
  numericMonthDay, // e.g., "01/21"
  numericDayMonth, // e.g., "21/01"
}

enum PulseDisplayMode {
  automatic, // Auto-fit based on zoom level
  full, // Full name: "Monthly Rent"
  acronym, // Acronym: "MR"
  icon, // Icon only
}

/// Display mode for month card view (no icon option - doesn't work well with categories)
enum MonthCardDisplayMode {
  full, // Full name: "Monthly Rent"
  acronym, // Acronym: "MR"
}

/// Display mode for month totals in single month view.
enum MonthTotalsDisplayMode {
  includeCleared, // Totals include cleared items
  showClearedRow, // Totals include cleared items + extra cleared row
}

/// Display mode for multi-month grid view (optional override or automatic)
enum MultiMonthDisplayMode {
  automatic, // Auto-fit based on zoom level (uses effectiveDisplayMode)
  full, // Full name
  acronym, // Acronym
  icon, // Icon only
}

enum TimelineSwipeAction { off, edit, archive }

enum TimelineTapAction { archive, menu }

enum PulseSwipeAction { off, edit, delete }

enum TimelineSortOrder {
  chronological,
  reverseChronological,
  nameAscending,
  nameDescending,
}

enum TimelineDateSortMode {
  scheduledDate, // Sort by when pulse were supposed to happen
  actualDate, // Sort by when pulse were actually recorded
}

enum ViewPeriodMode {
  calendar, // Traditional calendar month (1st - last day)
  paycheck, // Custom period based on payday (e.g., 25th - 24th)
}

enum PaycheckAdjustDirection { before, after }

/// Preset options for the overall app theme (primary color)
enum AppThemePreset {
  classic, // Indigo (Original)
  ocean, // Teal
  sunset, // Deep Orange
  monochrome, // BlueGrey (Default)
  forest, // Green
  berry, // Pink/Magenta
  lavender, // Purple
  midnight, // Deep Blue
  rose, // Rose/Coral
  // New warm tones
  // New cool tones
  sky, // Sky Blue/Cyan
  // New vibrant tones
  // New earthy tones
  terracotta, // Terracotta/Clay
  sage, // Sage Green
  // New distinct themes
  noir, // OLED Black
  crimson, // Bold Red
  sunflower, // Vivid Yellow
  emerald, // Jewel Green
  coffee, // Earthy Brown
  blossom // Soft Pastel Pink
  ;

  /// Returns a random theme preset
  static AppThemePreset getRandom() {
    final values = AppThemePreset.values;
    return values[DateTime.now().microsecondsSinceEpoch % values.length];
  }
}

/// Terminology presets for customizing UI labels
enum TerminologyPreset {
  defaultTerms, // "Scheduled", "Paid", "Mark Paid"
  bills, // "Bills", "Paid", "Mark Paid"
  budget, // "Budget", "Done", "Mark Done"
  custom, // User-defined labels
}

enum TextScalePreset { small, normal, large, extraLarge }

enum FontPreset { system, monospace }

/// View mode for the timeline screen (single month, grid, or spreadsheet)
enum TimelineViewMode {
  month, // Single month with PageView
  grid, // Multi-month grid view
  sheet, // Horizontal spreadsheet view
}

/// Filter options for the pulse/scheduled screen
enum PulsesFilterType {
  all, // Show all items
  income, // Show only income items (recurring + one-off)
  expenses, // Show only expense items (recurring + one-off)
  debt, // Show only debt items
  oneOff, // Show only one-off items (income + expense)
  recurring, // Show only recurring items (income + expense)
  category, // Show items matching a specific category
  envelopes, // Show only spending envelope items
}

/// Grouping options for the pulse/scheduled screen
enum PulsesGroupBy {
  none, // No grouping (flat list)
  category, // Group by income/expense category
  type, // Group by pulse type
  origin, // Group by origin/provider
  dueDate, // Group by next due date
}

/// Modes for category suggestions
enum CategoryPresetMode {
  defaultPresets, // Use predefined categories (default)
  customOnly, // Use only categories already used by the user
  both, // Use both predefined and user categories
}

/// Types of notifications the app can send
enum NotificationType {
  dailyAlert, // Daily projected activity + balance
  weeklyAlert, // Start of week reminder
  weeklySummary, // End of week summary
}

/// Scope for money pots storage

class RegionPreset {
  const RegionPreset({
    required this.id,
    required this.label,
    this.currency,
    this.dayFormat,
  });

  final String id;
  final String label;
  final AppCurrency? currency;
  final DayFormat? dayFormat;
}
