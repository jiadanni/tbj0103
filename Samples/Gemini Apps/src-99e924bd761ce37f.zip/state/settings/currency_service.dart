import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http_certificate_pinning/http_certificate_pinning.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';

/// Service for fetching exchange rates from Frankfurter API.
class CurrencyService {
  static const String _baseUrl = 'api.frankfurter.dev';

  /// Fetches latest exchange rates from Frankfurter.
  ///
  /// [base] is the currency to use as the base (e.g., USD).
  /// [symbols] optional list of currencies to fetch rates for.
  Future<Map<AppCurrency, double>> fetchLatestRates({
    required AppCurrency base,
    List<AppCurrency>? symbols,
  }) async {
    final baseCode = getCurrencyInfo(base).code;

    final queryParameters = {'base': baseCode};

    if (symbols != null && symbols.isNotEmpty) {
      final symbolCodes = symbols
          .where((s) => getCurrencyInfo(s).isFrankfurterSupported)
          .map((s) => getCurrencyInfo(s).code)
          .join(',');
      if (symbolCodes.isNotEmpty) {
        queryParameters['symbols'] = symbolCodes;
      }
    }

    try {
      final uri = Uri.https(_baseUrl, '/v1/latest', queryParameters);

      // Perform SSL Certificate Pinning Check before making the request
      final secure = await HttpCertificatePinning.check(
        serverURL: uri.toString(),
        headerHttp: {},
        sha: SHA.SHA256,
        allowedSHAFingerprints: [
          'DwvQ1IfpDBACB++djP0Z3eeJt9sdAJhqY/22hkAy/wI='
        ],
        timeout: 50,
      );

      if (secure.contains('CONNECTION_SECURE')) {
        final response = await http.get(uri);

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final Map<String, dynamic> rates = data['rates'];

          final Map<AppCurrency, double> result = {};

          // Add base currency with rate 1.0
          result[base] = 1.0;

          for (final entry in rates.entries) {
            final currencyCode = entry.key;
            final rate = (entry.value as num).toDouble();

            // Reverse find AppCurrency by code
            final appCurrency = _findCurrencyByCode(currencyCode);
            if (appCurrency != null) {
              result[appCurrency] = rate;
            }
          }

          return result;
        } else {
          throw Exception(
            'Failed to load exchange rates: ${response.statusCode}',
          );
        }
      } else {
        throw Exception('Insecure connection: SSL pinning failed.');
      }
    } catch (e) {
      throw Exception('Error fetching exchange rates: $e');
    }
  }

  AppCurrency? _findCurrencyByCode(String code) {
    for (final currency in AppCurrency.values) {
      if (getCurrencyInfo(currency).code == code) {
        return currency;
      }
    }
    return null;
  }
}
