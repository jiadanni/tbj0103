import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

/// Settings for onboarding wizard state management.
///
/// Tracks:
/// - Whether onboarding has been completed
/// - Version of onboarding completed (for "What's New" flows)
/// - Whether demo data was enabled during onboarding
/// - Completion timestamp
class OnboardingSettings extends ChangeNotifier {
  OnboardingSettings(
    this._storage, {
    required bool initialComplete,
    required int initialVersion,
    required bool initialDemoDataEnabled,
    required String? initialCompletedAt,
  })  : _isComplete = initialComplete,
        _version = initialVersion,
        _demoDataEnabled = initialDemoDataEnabled,
        _completedAt = initialCompletedAt;

  final StorageProvider _storage;

  static const _kComplete = 'onboarding.complete';
  static const _kVersion = 'onboarding.version';
  static const _kDemoDataEnabled = 'onboarding.demoData';
  static const _kCompletedAt = 'onboarding.completedAt';

  /// Current onboarding version. Increment to trigger "What's New" for existing users.
  static const int currentVersion = 1;

  bool _isComplete;
  int _version;
  bool _demoDataEnabled;
  String? _completedAt;

  /// Whether onboarding has been completed.
  bool get isComplete => _isComplete;

  /// Version of onboarding that was completed.
  int get version => _version;

  /// Whether demo data was enabled during onboarding.
  bool get demoDataEnabled => _demoDataEnabled;

  /// ISO timestamp of when onboarding was completed.
  String? get completedAt => _completedAt;

  /// Returns true if onboarding wizard should be shown.
  /// Shows if not completed, or if a newer onboarding version exists.
  bool get shouldShowOnboarding => !_isComplete || _version < currentVersion;

  /// Load or create onboarding settings from storage.
  static Future<OnboardingSettings> loadOrCreate(
    StorageProvider storage,
  ) async {
    final complete = await storage.getBool(_kComplete) ?? false;
    final version = await storage.getInt(_kVersion) ?? 0;
    final demoDataEnabled = await storage.getBool(_kDemoDataEnabled) ?? false;
    final completedAt = await storage.getString(_kCompletedAt);

    return OnboardingSettings(
      storage,
      initialComplete: complete,
      initialVersion: version,
      initialDemoDataEnabled: demoDataEnabled,
      initialCompletedAt: completedAt,
    );
  }

  /// Mark onboarding as complete with current version.
  Future<void> markComplete({bool demoDataEnabled = false}) async {
    _isComplete = true;
    _version = currentVersion;
    _demoDataEnabled = demoDataEnabled;
    _completedAt = DateTime.now().toUtc().toIso8601String();

    await _storage.setBool(_kComplete, true);
    await _storage.setInt(_kVersion, currentVersion);
    await _storage.setBool(_kDemoDataEnabled, demoDataEnabled);
    await _storage.setString(_kCompletedAt, _completedAt!);
    notifyListeners();
  }

  /// Reset onboarding state (for "Replay Introduction" option).
  Future<void> reset() async {
    _isComplete = false;
    _version = 0;
    // Keep demoDataEnabled as historical record

    await _storage.setBool(_kComplete, false);
    await _storage.setInt(_kVersion, 0);
    notifyListeners();
  }

  /// Update demo data preference.
  Future<void> setDemoDataEnabled(bool enabled) async {
    if (_demoDataEnabled == enabled) return;
    _demoDataEnabled = enabled;
    await _storage.setBool(_kDemoDataEnabled, enabled);
    notifyListeners();
  }
}
