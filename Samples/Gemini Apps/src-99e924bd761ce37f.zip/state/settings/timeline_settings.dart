import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_codecs.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

class TimelineSettings extends ChangeNotifier {
  TimelineSettings(
    this._storage, {
    required DayFormat initialDayFormat,
    required TimelineSwipeAction initialSwipeLeft,
    required TimelineSwipeAction initialSwipeRight,
    required TimelineTapAction initialTapAction,
    required PulseSwipeAction initialPulseSwipeLeft,
    required PulseSwipeAction initialPulseSwipeRight,
    required PulseDisplayMode initialPulseDisplayMode,
    required bool initialEnableTabSwipe,
    required bool initialUseZeroBaseline,
    required bool initialShowClearedItems,
    required bool initialShowSkippedItems,
    required TimelineSortOrder initialSortOrder,
    required TimelineDateSortMode initialDateSortMode,
    required bool initialGroupByDate,
    required bool initialGroupByTheme,
    required bool initialSplitClearedAndPending, // [NEW]
    required bool initialShowSubcategories, // [NEW]
    required bool initialShowPulseOrigin,
    required MonthCardDisplayMode initialMonthCardDisplayMode,
    required MonthTotalsDisplayMode initialMonthTotalsDisplayMode,
    required MultiMonthDisplayMode initialMultiMonthDisplayMode,
    required TerminologyPreset initialTerminologyPreset,
    required TimelineViewMode initialViewMode,
    required PulsesFilterType initialPulsesFilterType,
    required PulsesGroupBy initialPulsesGroupBy,
    required bool initialPulsesShowArchived,
    required CategoryPresetMode initialCategoryPresetMode,
    String? initialCustomPulseLabel,
    String? initialCustomTimelineLabel,
  })  : _defaultDayFormat = initialDayFormat,
        _defaultSwipeLeft = initialSwipeLeft,
        _defaultSwipeRight = initialSwipeRight,
        _defaultTapAction = initialTapAction,
        _defaultPulseSwipeLeft = initialPulseSwipeLeft,
        _defaultPulseSwipeRight = initialPulseSwipeRight,
        _defaultPulseDisplayMode = initialPulseDisplayMode,
        _defaultEnableTabSwipe = initialEnableTabSwipe,
        _defaultUseZeroBaseline = initialUseZeroBaseline,
        _defaultShowClearedItems = initialShowClearedItems,
        _defaultShowSkippedItems = initialShowSkippedItems,
        _defaultSortOrder = initialSortOrder,
        _defaultDateSortMode = initialDateSortMode,
        _defaultGroupByDate = initialGroupByDate,
        _defaultGroupByTheme = initialGroupByTheme,
        _defaultSplitClearedAndPending = initialSplitClearedAndPending, // [NEW]
        _defaultShowSubcategories = initialShowSubcategories, // [NEW]
        _defaultShowPulseOrigin = initialShowPulseOrigin,
        _defaultMonthCardDisplayMode = initialMonthCardDisplayMode,
        _defaultMonthTotalsDisplayMode = initialMonthTotalsDisplayMode,
        _defaultMultiMonthDisplayMode = initialMultiMonthDisplayMode,
        _defaultTerminologyPreset = initialTerminologyPreset,
        _defaultViewMode = initialViewMode,
        _defaultPulsesFilterType = initialPulsesFilterType,
        _defaultPulsesGroupBy = initialPulsesGroupBy,
        _defaultPulsesShowArchived = initialPulsesShowArchived,
        _defaultCategoryPresetMode = initialCategoryPresetMode,
        _globalEnvelopeCurrentDeductActuals = false, // Default to Budget
        _globalEnvelopeFutureDeductActuals = false, // Default to Budget

        _dayFormat = initialDayFormat,
        _timelineSwipeLeft = initialSwipeLeft,
        _timelineSwipeRight = initialSwipeRight,
        _timelineTapAction = initialTapAction,
        _pulseSwipeLeft = initialPulseSwipeLeft,
        _pulseSwipeRight = initialPulseSwipeRight,
        _pulseDisplayMode = initialPulseDisplayMode,
        _enableTabSwipe = initialEnableTabSwipe,
        _timelineUseZeroBaseline = initialUseZeroBaseline,
        _timelineShowClearedItems = initialShowClearedItems,
        _timelineShowSkippedItems = initialShowSkippedItems,
        _timelineSortOrder = initialSortOrder,
        _timelineDateSortMode = initialDateSortMode,
        _timelineGroupByDate = initialGroupByDate,
        _timelineGroupByTheme = initialGroupByTheme,
        _timelineSplitClearedAndPending =
            initialSplitClearedAndPending, // [NEW]
        _timelineShowSubcategories = initialShowSubcategories, // [NEW]
        _monthCardDisplayMode = initialMonthCardDisplayMode,
        _monthTotalsDisplayMode = initialMonthTotalsDisplayMode,
        _multiMonthDisplayModeLegacy = initialMultiMonthDisplayMode,
        _terminologyPreset = initialTerminologyPreset,
        _timelineViewMode = initialViewMode,
        _pulseFilterType = initialPulsesFilterType,
        _pulseGroupBy = initialPulsesGroupBy,
        _pulseShowArchived = initialPulsesShowArchived,
        _categoryPresetMode = initialCategoryPresetMode,
        _customPulseLabel = initialCustomPulseLabel,
        _customTimelineLabel = initialCustomTimelineLabel {
    // Initialize maps with default values
    for (final mode in TimelineViewMode.values) {
      _timelineShowPulseOriginMap[mode] = initialShowPulseOrigin;
      _multiMonthDisplayModeMap[mode] = initialMultiMonthDisplayMode;
    }
  }

  final StorageProvider _storage;
  AccountId? _accountId;

  // Default values (fallbacks)
  final DayFormat _defaultDayFormat;
  final TimelineSwipeAction _defaultSwipeLeft;
  final TimelineSwipeAction _defaultSwipeRight;
  final TimelineTapAction _defaultTapAction;
  final PulseSwipeAction _defaultPulseSwipeLeft;
  final PulseSwipeAction _defaultPulseSwipeRight;
  final PulseDisplayMode _defaultPulseDisplayMode;
  final bool _defaultEnableTabSwipe;
  final bool _defaultUseZeroBaseline;
  final bool _defaultShowClearedItems;
  final bool _defaultShowSkippedItems;
  final TimelineSortOrder _defaultSortOrder;
  final TimelineDateSortMode _defaultDateSortMode;
  final bool _defaultGroupByDate;
  final bool _defaultGroupByTheme;
  final bool _defaultSplitClearedAndPending; // [NEW]
  final bool _defaultShowSubcategories; // [NEW]
  final bool _defaultShowPulseOrigin;

  final MonthCardDisplayMode _defaultMonthCardDisplayMode;
  final MonthTotalsDisplayMode _defaultMonthTotalsDisplayMode;
  final MultiMonthDisplayMode _defaultMultiMonthDisplayMode;
  final TerminologyPreset _defaultTerminologyPreset;
  final TimelineViewMode _defaultViewMode;
  final PulsesFilterType _defaultPulsesFilterType;
  final PulsesGroupBy _defaultPulsesGroupBy;
  final bool _defaultPulsesShowArchived;
  final CategoryPresetMode _defaultCategoryPresetMode;

  // Keys
  static const _kDayFormat = 'settings.dayFormat';
  static const _kTimelineSwipeLeft = 'settings.timeline.swipeLeft';
  static const _kTimelineSwipeRight = 'settings.timeline.swipeRight';
  static const _kTimelineTapAction = 'settings.timeline.tapAction';
  static const _kPulseSwipeLeft = 'settings.pulse.swipeLeft';
  static const _kPulseSwipeRight = 'settings.pulse.swipeRight';
  static const _kPulseDisplayMode = 'settings.pulse.displayMode';
  static const _kEnableTabSwipe = 'settings.navigation.enableTabSwipe';
  static const _kTimelineUseZeroBaseline = 'settings.timeline.useZeroBaseline';
  static const _kTimelineShowClearedItems =
      'settings.timeline.showClearedItems';
  static const _kTimelineShowSkippedItems =
      'settings.timeline.showSkippedItems';
  static const _kTimelineShowIncome = 'settings.timeline.showIncome';
  static const _kTimelineShowExpense = 'settings.timeline.showExpense';
  static const _kTimelineSortOrder = 'settings.timeline.sortOrder';
  static const _kTimelineDateSortMode = 'settings.timeline.dateSortMode';
  static const _kTimelineGroupByDate = 'settings.timeline.groupByDate';
  static const _kTimelineSplitClearedAndPending =
      'settings.timeline.splitClearedAndPending'; // [NEW]
  static const _kTimelineShowSubcategories =
      'settings.timeline.showSubcategories'; // [NEW]

  // Legacy key for migration
  static const _kTimelineShowPulseOriginLegacy =
      'settings.timeline.showPulseOrigin';
  static const _kTimelineShowPulseOriginPrefix =
      'settings.timeline.showPulseOrigin';
  static const _kTimelineGroupByTheme = 'settings.timeline.groupByTheme';
  static const _kMonthCardDisplayMode =
      'settings.timeline.monthCardDisplayMode';
  static const _kMonthTotalsDisplayMode =
      'settings.timeline.monthTotalsDisplayMode';
  static const _kMultiMonthDisplayModeLegacy =
      'settings.timeline.multiMonthDisplayMode';
  static const _kMultiMonthDisplayModePrefix =
      'settings.timeline.multiMonthDisplayMode';
  static const _kGlobalEnvelopeCurrentDeductActuals =
      'settings.timeline.envelope.currentDeductActuals';
  static const _kGlobalEnvelopeFutureDeductActuals =
      'settings.timeline.envelope.futureDeductActuals';
  static const _kTerminologyPreset = 'settings.terminologyPreset';
  static const _kTimelineViewMode = 'settings.timeline.viewMode';
  static const _kPulsesFilterType = 'settings.pulse.filterType';
  static const _kPulsesGroupBy = 'settings.pulse.groupBy';
  static const _kPulsesShowArchived = 'settings.pulse.showArchived';
  static const _kCategoryPresetMode = 'settings.timeline.categoryPresetMode';
  static const _kPulsesFilterCategory =
      'settings.pulse.filterCategory'; // [NEW]
  static const _kCustomPulseLabel = 'settings.terminology.customPulseLabel';
  static const _kCustomTimelineLabel =
      'settings.terminology.customTimelineLabel';
  static const _kCustomActivityLabelLegacy =
      'settings.terminology.customActivityLabel';
  static const _kEnvelopesSectionCollapsed =
      'settings.timeline.envelopesSectionCollapsed';

  DayFormat _dayFormat;
  TimelineSwipeAction _timelineSwipeLeft;
  TimelineSwipeAction _timelineSwipeRight;
  TimelineTapAction _timelineTapAction;
  PulseSwipeAction _pulseSwipeLeft;
  PulseSwipeAction _pulseSwipeRight;
  PulseDisplayMode _pulseDisplayMode;
  bool _enableTabSwipe;
  bool _timelineUseZeroBaseline;
  bool _timelineShowClearedItems;
  bool _timelineShowSkippedItems;
  bool _timelineShowIncome = true;
  bool _timelineShowExpense = true;
  TimelineSortOrder _timelineSortOrder;
  TimelineDateSortMode _timelineDateSortMode;
  bool _timelineGroupByDate;
  bool _timelineGroupByTheme;
  bool _timelineSplitClearedAndPending; // [NEW]
  bool _timelineShowSubcategories; // [NEW]
  final Map<TimelineViewMode, bool> _timelineShowPulseOriginMap = {};

  MonthCardDisplayMode _monthCardDisplayMode;
  MonthTotalsDisplayMode _monthTotalsDisplayMode;
  final Map<TimelineViewMode, MultiMonthDisplayMode> _multiMonthDisplayModeMap =
      {};
  MultiMonthDisplayMode _multiMonthDisplayModeLegacy;
  TerminologyPreset _terminologyPreset;
  TimelineViewMode _timelineViewMode;
  PulsesFilterType _pulseFilterType;
  PulsesGroupBy _pulseGroupBy;
  bool _pulseShowArchived;
  CategoryPresetMode _categoryPresetMode;
  String? _pulseFilterCategory; // [NEW]
  String? _customPulseLabel;
  String? _customTimelineLabel;
  String? _customActivityLabel;
  bool _envelopesSectionCollapsed = false;

  bool _globalEnvelopeCurrentDeductActuals;
  bool _globalEnvelopeFutureDeductActuals;

  DayFormat get dayFormat => _dayFormat;
  TimelineSwipeAction get timelineSwipeLeft => _timelineSwipeLeft;
  TimelineSwipeAction get timelineSwipeRight => _timelineSwipeRight;
  TimelineTapAction get timelineTapAction => _timelineTapAction;
  PulseSwipeAction get pulseSwipeLeft => _pulseSwipeLeft;
  PulseSwipeAction get pulseSwipeRight => _pulseSwipeRight;
  PulseDisplayMode get pulseDisplayMode => _pulseDisplayMode;
  bool get enableTabSwipe => _enableTabSwipe;
  bool get timelineUseZeroBaseline => _timelineUseZeroBaseline;
  bool get timelineShowClearedItems => _timelineShowClearedItems;
  bool get timelineShowSkippedItems => _timelineShowSkippedItems;
  bool get timelineShowIncome => _timelineShowIncome;
  bool get timelineShowExpense => _timelineShowExpense;
  TimelineSortOrder get timelineSortOrder => _timelineSortOrder;
  TimelineDateSortMode get timelineDateSortMode => _timelineDateSortMode;
  bool get timelineGroupByDate => _timelineGroupByDate;
  bool get timelineGroupByTheme => _timelineGroupByTheme;
  bool get timelineSplitClearedAndPending =>
      _timelineSplitClearedAndPending; // [NEW]
  bool get timelineShowSubcategories => _timelineShowSubcategories; // [NEW]

  bool getTimelineShowPulseOrigin(TimelineViewMode mode) =>
      _timelineShowPulseOriginMap[mode] ?? _defaultShowPulseOrigin;

  MultiMonthDisplayMode getMultiMonthDisplayMode(TimelineViewMode mode) =>
      _multiMonthDisplayModeMap[mode] ?? _defaultMultiMonthDisplayMode;

  // Deprecated usage: returns mostly correct val (current view or default)
  // But ideally we should always ask with a mode.
  // For backwards compatibility with AppSettingsStore proxy:
  // We'll let AppSettingsStore decide which mode it wants (via the getter there).
  // But since this getter must return a bool, we can't fully support the old interface
  // without context.
  // Actually, AppSettingsStore will implement the logic of "current view", so we just need
  // methods to get/set by mode.

  MonthCardDisplayMode get monthCardDisplayMode => _monthCardDisplayMode;
  MonthTotalsDisplayMode get monthTotalsDisplayMode => _monthTotalsDisplayMode;

  @Deprecated('Use getMultiMonthDisplayMode(mode)')
  MultiMonthDisplayMode get multiMonthDisplayMode =>
      _multiMonthDisplayModeLegacy;
  TerminologyPreset get terminologyPreset => _terminologyPreset;
  TimelineViewMode get timelineViewMode => _timelineViewMode;
  PulsesFilterType get pulseFilterType => _pulseFilterType;
  PulsesGroupBy get pulseGroupBy => _pulseGroupBy;
  bool get pulseShowArchived => _pulseShowArchived;
  CategoryPresetMode get categoryPresetMode => _categoryPresetMode;
  String? get pulseFilterCategory => _pulseFilterCategory; // [NEW]
  String? get customPulseLabel => _customPulseLabel;
  String? get customTimelineLabel => _customTimelineLabel;
  String? get customActivityLabel => _customActivityLabel;
  bool get envelopesSectionCollapsed => _envelopesSectionCollapsed;

  AccountId? get accountId => _accountId;
  bool get globalEnvelopeCurrentDeductActuals =>
      _globalEnvelopeCurrentDeductActuals;
  bool get globalEnvelopeFutureDeductActuals =>
      _globalEnvelopeFutureDeductActuals;

  String _key(String baseKey) {
    if (_accountId != null) {
      return 'account.$_accountId.$baseKey';
    }
    return baseKey;
  }

  Future<void> setAccountId(AccountId? id) async {
    if (_accountId == id) return;
    _accountId = id;
    await _loadSettings();
    notifyListeners();
  }

  Future<void> _loadSettings() async {
    // Helper to read string with fallback:
    // 1. Account key (if account set)
    // 2. Global key
    Future<String?> readString(String baseKey) async {
      if (_accountId != null) {
        final accountVal = await _storage.getString(_key(baseKey));
        if (accountVal != null) return accountVal;
      }
      return _storage.getString(baseKey);
    }

    // Helper for bool
    Future<bool?> readBool(String baseKey) async {
      if (_accountId != null) {
        final accountVal = await _storage.getBool(_key(baseKey));
        if (accountVal != null) return accountVal;
      }
      return _storage.getBool(baseKey);
    }

    // Helper for int

    _dayFormat =
        AppSettingsCodecs.decodeDayFormat(await readString(_kDayFormat)) ??
            _defaultDayFormat;
    _timelineSwipeLeft = AppSettingsCodecs.decodeSwipeAction(
          await readString(_kTimelineSwipeLeft),
        ) ??
        _defaultSwipeLeft;
    _timelineSwipeRight = AppSettingsCodecs.decodeSwipeAction(
          await readString(_kTimelineSwipeRight),
        ) ??
        _defaultSwipeRight;
    _timelineTapAction = AppSettingsCodecs.decodeTimelineTapAction(
          await readString(_kTimelineTapAction),
        ) ??
        _defaultTapAction;
    _pulseSwipeLeft = AppSettingsCodecs.decodePulseSwipeAction(
          await readString(_kPulseSwipeLeft),
        ) ??
        _defaultPulseSwipeLeft;
    _pulseSwipeRight = AppSettingsCodecs.decodePulseSwipeAction(
          await readString(_kPulseSwipeRight),
        ) ??
        _defaultPulseSwipeRight;
    _pulseDisplayMode = AppSettingsCodecs.decodePulseDisplayMode(
          await readString(_kPulseDisplayMode),
        ) ??
        _defaultPulseDisplayMode;

    _enableTabSwipe =
        await readBool(_kEnableTabSwipe) ?? _defaultEnableTabSwipe;
    _timelineUseZeroBaseline =
        await readBool(_kTimelineUseZeroBaseline) ?? _defaultUseZeroBaseline;
    _timelineShowClearedItems =
        await readBool(_kTimelineShowClearedItems) ?? _defaultShowClearedItems;
    _timelineShowSkippedItems =
        await readBool(_kTimelineShowSkippedItems) ?? _defaultShowSkippedItems;
    _timelineShowIncome = await readBool(_kTimelineShowIncome) ?? true;
    _timelineShowExpense = await readBool(_kTimelineShowExpense) ?? true;

    _timelineSortOrder = AppSettingsCodecs.decodeSortOrder(
          await readString(_kTimelineSortOrder),
        ) ??
        _defaultSortOrder;
    _timelineDateSortMode = AppSettingsCodecs.decodeTimelineDateSortMode(
          await readString(_kTimelineDateSortMode),
        ) ??
        _defaultDateSortMode;

    _timelineGroupByDate =
        await readBool(_kTimelineGroupByDate) ?? _defaultGroupByDate;
    _timelineGroupByTheme =
        await readBool(_kTimelineGroupByTheme) ?? _defaultGroupByTheme;
    _timelineSplitClearedAndPending =
        await readBool(_kTimelineSplitClearedAndPending) ??
            _defaultSplitClearedAndPending; // [NEW]
    _timelineShowSubcategories = await readBool(_kTimelineShowSubcategories) ??
        _defaultShowSubcategories; // [NEW]

    // Load per-view origin settings with legacy fallback

    final legacyOrigin = await readBool(_kTimelineShowPulseOriginLegacy) ??
        _defaultShowPulseOrigin;
    for (final mode in TimelineViewMode.values) {
      final key = '$_kTimelineShowPulseOriginPrefix.${mode.name}';
      final val = await readBool(key);
      _timelineShowPulseOriginMap[mode] = val ?? legacyOrigin;
    }

    _monthCardDisplayMode = AppSettingsCodecs.decodeMonthCardDisplayMode(
          await readString(_kMonthCardDisplayMode),
        ) ??
        _defaultMonthCardDisplayMode;
    _monthTotalsDisplayMode = AppSettingsCodecs.decodeMonthTotalsDisplayMode(
          await readString(_kMonthTotalsDisplayMode),
        ) ??
        _defaultMonthTotalsDisplayMode;

    // Load per-view multi-month settings with legacy fallback
    final legacyMultiMonth = AppSettingsCodecs.decodeMultiMonthDisplayMode(
          await readString(_kMultiMonthDisplayModeLegacy),
        ) ??
        _defaultMultiMonthDisplayMode;
    _multiMonthDisplayModeLegacy = legacyMultiMonth;
    for (final mode in TimelineViewMode.values) {
      final key = '$_kMultiMonthDisplayModePrefix.${mode.name}';
      final valStr = await readString(key);
      _multiMonthDisplayModeMap[mode] =
          AppSettingsCodecs.decodeMultiMonthDisplayMode(valStr) ??
              legacyMultiMonth;
    }

    _globalEnvelopeCurrentDeductActuals =
        await readBool(_kGlobalEnvelopeCurrentDeductActuals) ?? false;
    _globalEnvelopeFutureDeductActuals =
        await readBool(_kGlobalEnvelopeFutureDeductActuals) ?? false;

    _terminologyPreset = AppSettingsCodecs.decodeTerminologyPreset(
          await readString(_kTerminologyPreset),
        ) ??
        _defaultTerminologyPreset;
    _timelineViewMode = AppSettingsCodecs.decodeTimelineViewMode(
          await readString(_kTimelineViewMode),
        ) ??
        _defaultViewMode;

    _pulseFilterType = AppSettingsCodecs.decodePulsesFilterType(
          await readString(_kPulsesFilterType),
        ) ??
        _defaultPulsesFilterType;
    _pulseGroupBy = AppSettingsCodecs.decodePulsesGroupBy(
          await readString(_kPulsesGroupBy),
        ) ??
        _defaultPulsesGroupBy;
    _pulseShowArchived =
        await readBool(_kPulsesShowArchived) ?? _defaultPulsesShowArchived;
    _categoryPresetMode = AppSettingsCodecs.decodeCategoryPresetMode(
          await readString(_kCategoryPresetMode),
        ) ??
        _defaultCategoryPresetMode;
    _pulseFilterCategory = await readString(_kPulsesFilterCategory); // [NEW]
    _customPulseLabel = await readString(_kCustomPulseLabel);
    _customTimelineLabel = await readString(_kCustomTimelineLabel) ??
        await readString(_kCustomActivityLabelLegacy);
    _customActivityLabel =
        await readString(_kCustomActivityLabelLegacy) ?? _customTimelineLabel;
    _envelopesSectionCollapsed =
        await readBool(_kEnvelopesSectionCollapsed) ?? false;

    final quickAddAmountsStr = await readString(_kQuickAddAmounts);
    if (quickAddAmountsStr != null && quickAddAmountsStr.isNotEmpty) {
      try {
        _customQuickAddAmounts =
            quickAddAmountsStr.split(',').map(int.parse).toList();
      } catch (_) {
        // Fallback to defaults if parsing fails
      }
    }
    // Balance Projection
    _balanceProjectionDeductEnvelopes =
        await readBool(_kBalanceProjectionDeductEnvelopes) ?? true;
    _balanceProjectionShowDelta =
        await readBool(_kBalanceProjectionShowDelta) ?? true;
  }

  set dayFormat(DayFormat value) {
    if (_dayFormat == value) return;
    _dayFormat = value;
    _storage.setString(
      _key(_kDayFormat),
      AppSettingsCodecs.encodeDayFormat(value),
    );
    notifyListeners();
  }

  set timelineSwipeLeft(TimelineSwipeAction value) {
    if (_timelineSwipeLeft == value) return;
    _timelineSwipeLeft = value;
    _storage.setString(
      _key(_kTimelineSwipeLeft),
      AppSettingsCodecs.encodeSwipeAction(value),
    );
    notifyListeners();
  }

  set timelineSwipeRight(TimelineSwipeAction value) {
    if (_timelineSwipeRight == value) return;
    _timelineSwipeRight = value;
    _storage.setString(
      _key(_kTimelineSwipeRight),
      AppSettingsCodecs.encodeSwipeAction(value),
    );
    notifyListeners();
  }

  set timelineTapAction(TimelineTapAction value) {
    if (_timelineTapAction == value) return;
    _timelineTapAction = value;
    _storage.setString(
      _key(_kTimelineTapAction),
      AppSettingsCodecs.encodeTimelineTapAction(value),
    );
    notifyListeners();
  }

  set pulseSwipeLeft(PulseSwipeAction value) {
    if (_pulseSwipeLeft == value) return;
    _pulseSwipeLeft = value;
    _storage.setString(
      _key(_kPulseSwipeLeft),
      AppSettingsCodecs.encodePulseSwipeAction(value),
    );
    notifyListeners();
  }

  set pulseSwipeRight(PulseSwipeAction value) {
    if (_pulseSwipeRight == value) return;
    _pulseSwipeRight = value;
    _storage.setString(
      _key(_kPulseSwipeRight),
      AppSettingsCodecs.encodePulseSwipeAction(value),
    );
    notifyListeners();
  }

  set pulseDisplayMode(PulseDisplayMode value) {
    if (_pulseDisplayMode == value) return;
    _pulseDisplayMode = value;
    _storage.setString(
      _key(_kPulseDisplayMode),
      AppSettingsCodecs.encodePulseDisplayMode(value),
    );
    notifyListeners();
  }

  set enableTabSwipe(bool value) {
    if (_enableTabSwipe == value) return;
    _enableTabSwipe = value;
    _storage.setBool(_key(_kEnableTabSwipe), value);
    notifyListeners();
  }

  set timelineUseZeroBaseline(bool value) {
    if (_timelineUseZeroBaseline == value) return;
    _timelineUseZeroBaseline = value;
    _storage.setBool(_key(_kTimelineUseZeroBaseline), value);
    notifyListeners();
  }

  set timelineShowClearedItems(bool value) {
    if (_timelineShowClearedItems == value) return;
    _timelineShowClearedItems = value;
    _storage.setBool(_key(_kTimelineShowClearedItems), value);
    notifyListeners();
  }

  set timelineShowSkippedItems(bool value) {
    if (_timelineShowSkippedItems == value) return;
    _timelineShowSkippedItems = value;
    _storage.setBool(_key(_kTimelineShowSkippedItems), value);
    notifyListeners();
  }

  set timelineShowIncome(bool value) {
    if (_timelineShowIncome == value) return;
    _timelineShowIncome = value;
    _storage.setBool(_key(_kTimelineShowIncome), value);
    notifyListeners();
  }

  set timelineShowExpense(bool value) {
    if (_timelineShowExpense == value) return;
    _timelineShowExpense = value;
    _storage.setBool(_key(_kTimelineShowExpense), value);
    notifyListeners();
  }

  set timelineSortOrder(TimelineSortOrder value) {
    if (_timelineSortOrder == value) return;
    _timelineSortOrder = value;
    _storage.setString(
      _key(_kTimelineSortOrder),
      AppSettingsCodecs.encodeSortOrder(value),
    );
    notifyListeners();
  }

  set timelineDateSortMode(TimelineDateSortMode value) {
    if (_timelineDateSortMode == value) return;
    _timelineDateSortMode = value;
    _storage.setString(
      _key(_kTimelineDateSortMode),
      AppSettingsCodecs.encodeTimelineDateSortMode(value),
    );
    notifyListeners();
  }

  set timelineGroupByDate(bool value) {
    if (_timelineGroupByDate == value) return;
    _timelineGroupByDate = value;
    _storage.setBool(_key(_kTimelineGroupByDate), value);
    notifyListeners();
  }

  set timelineGroupByTheme(bool value) {
    if (_timelineGroupByTheme == value) return;
    _timelineGroupByTheme = value;
    _storage.setBool(_key(_kTimelineGroupByTheme), value);
    notifyListeners();
  }

  set timelineSplitClearedAndPending(bool value) {
    // [NEW]
    if (_timelineSplitClearedAndPending == value) return;
    _timelineSplitClearedAndPending = value;
    _storage.setBool(_key(_kTimelineSplitClearedAndPending), value);
    notifyListeners();
  }

  set timelineShowSubcategories(bool value) {
    // [NEW]
    if (_timelineShowSubcategories == value) return;
    _timelineShowSubcategories = value;
    _storage.setBool(_key(_kTimelineShowSubcategories), value);
    notifyListeners();
  }

  void setTimelineShowPulseOrigin(TimelineViewMode mode, bool value) {
    if (_timelineShowPulseOriginMap[mode] == value) return;
    _timelineShowPulseOriginMap[mode] = value;
    _storage.setBool(
      _key('$_kTimelineShowPulseOriginPrefix.${mode.name}'),
      value,
    );
    notifyListeners();
  }

  set monthCardDisplayMode(MonthCardDisplayMode value) {
    if (_monthCardDisplayMode == value) return;
    _monthCardDisplayMode = value;
    _storage.setString(
      _key(_kMonthCardDisplayMode),
      AppSettingsCodecs.encodeMonthCardDisplayMode(value),
    );
    notifyListeners();
  }

  set monthTotalsDisplayMode(MonthTotalsDisplayMode value) {
    if (_monthTotalsDisplayMode == value) return;
    _monthTotalsDisplayMode = value;
    _storage.setString(
      _key(_kMonthTotalsDisplayMode),
      AppSettingsCodecs.encodeMonthTotalsDisplayMode(value),
    );
    notifyListeners();
  }

  set multiMonthDisplayMode(MultiMonthDisplayMode value) {
    if (_multiMonthDisplayModeLegacy == value) return;
    _multiMonthDisplayModeLegacy = value;
    _storage.setString(
      _key(_kMultiMonthDisplayModeLegacy),
      AppSettingsCodecs.encodeMultiMonthDisplayMode(value),
    );
    notifyListeners();
  }

  void setMultiMonthDisplayMode(
    TimelineViewMode mode,
    MultiMonthDisplayMode value,
  ) {
    if (_multiMonthDisplayModeMap[mode] == value) return;
    _multiMonthDisplayModeMap[mode] = value;
    _storage.setString(
      _key('$_kMultiMonthDisplayModePrefix.${mode.name}'),
      AppSettingsCodecs.encodeMultiMonthDisplayMode(value),
    );
    notifyListeners();
  }

  set terminologyPreset(TerminologyPreset value) {
    if (_terminologyPreset == value) return;
    _terminologyPreset = value;
    _storage.setString(
      _key(_kTerminologyPreset),
      AppSettingsCodecs.encodeTerminologyPreset(value),
    );
    notifyListeners();
  }

  set timelineViewMode(TimelineViewMode value) {
    if (_timelineViewMode == value) return;
    _timelineViewMode = value;
    _storage.setString(
      _key(_kTimelineViewMode),
      AppSettingsCodecs.encodeTimelineViewMode(value),
    );
    notifyListeners();
  }

  set pulseFilterType(PulsesFilterType value) {
    if (_pulseFilterType == value) return;
    _pulseFilterType = value;
    _storage.setString(
      _key(_kPulsesFilterType),
      AppSettingsCodecs.encodePulsesFilterType(value),
    );
    notifyListeners();
  }

  set pulseGroupBy(PulsesGroupBy value) {
    if (_pulseGroupBy == value) return;
    _pulseGroupBy = value;
    _storage.setString(
      _key(_kPulsesGroupBy),
      AppSettingsCodecs.encodePulsesGroupBy(value),
    );
    notifyListeners();
  }

  set pulseShowArchived(bool value) {
    if (_pulseShowArchived == value) return;
    _pulseShowArchived = value;
    _storage.setBool(_key(_kPulsesShowArchived), value);
    notifyListeners();
  }

  set categoryPresetMode(CategoryPresetMode value) {
    if (_categoryPresetMode == value) return;
    _categoryPresetMode = value;
    _storage.setString(
      _key(_kCategoryPresetMode),
      AppSettingsCodecs.encodeCategoryPresetMode(value),
    );
    notifyListeners();
  }

  // [NEW]
  set pulseFilterCategory(String? value) {
    if (_pulseFilterCategory == value) return;
    _pulseFilterCategory = value;
    if (value == null) {
      _storage.remove(_key(_kPulsesFilterCategory));
    } else {
      _storage.setString(_key(_kPulsesFilterCategory), value);
    }
    notifyListeners();
  }

  // Quick Spending Amounts
  static const _kQuickAddAmounts = 'settings.timeline.quickAddAmounts';
  List<int> _customQuickAddAmounts = const [
    500,
    1000,
    2000,
    3000,
    5000,
    10000,
  ]; // Default 5, 10, 20, 30, 50, 100

  List<int> get customQuickAddAmounts =>
      List.unmodifiable(_customQuickAddAmounts);

  set customQuickAddAmounts(List<int> value) {
    if (listEquals(_customQuickAddAmounts, value)) return;
    _customQuickAddAmounts = List.from(value);
    _storage.setString(_key(_kQuickAddAmounts), value.join(','));
    notifyListeners();
  }

  set customPulseLabel(String? value) {
    if (_customPulseLabel == value) return;
    _customPulseLabel = value;
    if (value == null) {
      _storage.remove(_key(_kCustomPulseLabel));
    } else {
      _storage.setString(_key(_kCustomPulseLabel), value);
    }
    notifyListeners();
  }

  set customTimelineLabel(String? value) {
    if (_customTimelineLabel == value) return;
    _customTimelineLabel = value;
    if (value == null) {
      _storage.remove(_key(_kCustomTimelineLabel));
    } else {
      _storage.setString(_key(_kCustomTimelineLabel), value);
    }
    notifyListeners();
  }

  set customActivityLabel(String? value) {
    if (_customActivityLabel == value) return;
    _customActivityLabel = value;
    if (value == null) {
      _storage.remove(_key(_kCustomActivityLabelLegacy));
    } else {
      _storage.setString(_key(_kCustomActivityLabelLegacy), value);
    }
    notifyListeners();
  }

  set globalEnvelopeCurrentDeductActuals(bool value) {
    if (_globalEnvelopeCurrentDeductActuals == value) return;
    _globalEnvelopeCurrentDeductActuals = value;
    _storage.setBool(_key(_kGlobalEnvelopeCurrentDeductActuals), value);
    notifyListeners();
  }

  set globalEnvelopeFutureDeductActuals(bool value) {
    if (_globalEnvelopeFutureDeductActuals == value) return;
    _globalEnvelopeFutureDeductActuals = value;
    _storage.setBool(_key(_kGlobalEnvelopeFutureDeductActuals), value);
    notifyListeners();
  }

  // Balance Projection
  static const _kBalanceProjectionDeductEnvelopes =
      'settings.timeline.balanceProjection.deductEnvelopes';
  static const _kBalanceProjectionShowDelta =
      'settings.timeline.balanceProjection.showDelta';

  bool _balanceProjectionDeductEnvelopes = true;
  bool _balanceProjectionShowDelta = true;

  bool get balanceProjectionDeductEnvelopes =>
      _balanceProjectionDeductEnvelopes;
  bool get balanceProjectionShowDelta => _balanceProjectionShowDelta;

  set balanceProjectionDeductEnvelopes(bool value) {
    if (_balanceProjectionDeductEnvelopes == value) return;
    _balanceProjectionDeductEnvelopes = value;
    _storage.setBool(_key(_kBalanceProjectionDeductEnvelopes), value);
    notifyListeners();
  }

  set balanceProjectionShowDelta(bool value) {
    if (_balanceProjectionShowDelta == value) return;
    _balanceProjectionShowDelta = value;
    _storage.setBool(_key(_kBalanceProjectionShowDelta), value);
    notifyListeners();
  }

  set envelopesSectionCollapsed(bool value) {
    if (_envelopesSectionCollapsed == value) return;
    _envelopesSectionCollapsed = value;
    _storage.setBool(_key(_kEnvelopesSectionCollapsed), value);
    notifyListeners();
  }
}
