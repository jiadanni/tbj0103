import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';

class CurrencySettings extends ChangeNotifier {
  CurrencySettings(
    this._storage, {
    required AppCurrency initialCurrency,
    required int initialBalanceCents,
    required bool initialShowCents,
    required int initialRoundingIncrement,
    Set<AppCurrency>? initialEnabledCurrencies,
    Map<AppCurrency, double>? initialExchangeRates,
    bool initialAutoUpdateRates = true,
  })  : _currency = initialCurrency,
        _currentBalanceCents = initialBalanceCents,
        _showCents = initialShowCents,
        _roundingIncrement = initialRoundingIncrement,
        _enabledCurrencies = initialEnabledCurrencies ??
            {AppCurrency.usd, AppCurrency.eur, AppCurrency.gbp},
        _exchangeRates = initialExchangeRates ?? {},
        _autoUpdateRates = initialAutoUpdateRates;

  final StorageProvider _storage;

  static const _kCurrency = 'settings.currency';
  static const _kCurrentBalanceCents = 'settings.currentBalanceCents';
  static const _kShowCents = 'settings.currency.showCents';
  static const _kRoundingIncrement = 'settings.currency.roundingIncrement';
  static const _kEnabledCurrencies = 'settings.currency.enabledCurrencies';
  static const _kExchangeRates = 'settings.currency.exchangeRates';
  static const _kAutoUpdateRates = 'settings.currency.autoUpdateRates';

  AppCurrency _currency;
  int _currentBalanceCents;
  bool _showCents;
  int _roundingIncrement;
  Set<AppCurrency> _enabledCurrencies;
  Map<AppCurrency, double> _exchangeRates;
  bool _autoUpdateRates;

  AppCurrency get currency => _currency;
  int get currentBalanceCents => _currentBalanceCents;
  bool get showCents => _showCents;
  int get roundingIncrement => _roundingIncrement;
  Set<AppCurrency> get enabledCurrencies =>
      Set.unmodifiable(_enabledCurrencies);
  Map<AppCurrency, double> get exchangeRates =>
      Map.unmodifiable(_exchangeRates);
  bool get autoUpdateRates => _autoUpdateRates;

  set currency(AppCurrency value) {
    if (_currency == value) return;
    _currency = value;
    _storage.setString(_kCurrency, encodeCurrency(value));
    notifyListeners();
  }

  set currentBalanceCents(int value) {
    if (_currentBalanceCents == value) return;
    _currentBalanceCents = value;
    _storage.setInt(_kCurrentBalanceCents, value);
    notifyListeners();
  }

  set showCents(bool value) {
    if (_showCents == value) return;
    _showCents = value;
    _storage.setBool(_kShowCents, value);
    notifyListeners();
  }

  set roundingIncrement(int value) {
    if (_roundingIncrement == value) return;
    _roundingIncrement = value;
    _storage.setInt(_kRoundingIncrement, value);
    notifyListeners();
  }

  set autoUpdateRates(bool value) {
    if (_autoUpdateRates == value) return;
    _autoUpdateRates = value;
    _storage.setBool(_kAutoUpdateRates, value);
    notifyListeners();
  }

  void enableCurrency(AppCurrency currency) {
    if (_enabledCurrencies.contains(currency)) return;
    _enabledCurrencies = {..._enabledCurrencies, currency};
    _persistEnabledCurrencies();
    notifyListeners();
  }

  void disableCurrency(AppCurrency currency) {
    if (currency == _currency) return; // Can't disable active currency
    if (!_enabledCurrencies.contains(currency)) return;
    _enabledCurrencies = Set.from(_enabledCurrencies)..remove(currency);
    _persistEnabledCurrencies();
    notifyListeners();
  }

  void setExchangeRate(AppCurrency currency, double rate) {
    if (_exchangeRates[currency] == rate) return;
    _exchangeRates = {..._exchangeRates, currency: rate};
    _persistExchangeRates();
    notifyListeners();
  }

  void updateAllExchangeRates(Map<AppCurrency, double> rates) {
    _exchangeRates = {..._exchangeRates, ...rates};
    _persistExchangeRates();
    notifyListeners();
  }

  void _persistEnabledCurrencies() {
    _storage.setString(
      _kEnabledCurrencies,
      _enabledCurrencies.map(encodeCurrency).join(','),
    );
  }

  void _persistExchangeRates() {
    final Map<String, dynamic> encoded = {};
    _exchangeRates.forEach((key, value) {
      encoded[encodeCurrency(key)] = value;
    });
    _storage.setString(_kExchangeRates, json.encode(encoded));
  }
}
