import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';

class MoneyPotsSettings extends ChangeNotifier {
  MoneyPotsSettings(
    this._storage, {
    required List<MoneyPot> initialMoneyPots,
    String? initialSectionLabel,
    bool initialShowForeignCurrencyDebtInAppCurrency = false,
    bool initialCollapsed = false,
    int initialGridColumns = 2,
    int initialMaxVisibleRows = 2,
  })  : _moneyPots = initialMoneyPots,
        _sectionLabel = initialSectionLabel ?? 'Money Pots',
        _showForeignCurrencyDebtInAppCurrency =
            initialShowForeignCurrencyDebtInAppCurrency,
        _collapsed = initialCollapsed,
        _gridColumns = initialGridColumns,
        _maxVisibleRows = initialMaxVisibleRows;

  final StorageProvider _storage;

  static const _kMoneyPots = 'settings.moneyPots';
  static const _kSectionLabel = 'settings.moneyPots.sectionLabel';
  static const _kShowForeignCurrencyDebtInAppCurrency =
      'settings.moneyPots.showForeignCurrencyDebtInAppCurrency';
  static const _kCollapsed = 'settings.moneyPots.collapsed';
  static const _kGridColumns = 'settings.moneyPots.gridColumns';
  static const _kMaxVisibleRows = 'settings.moneyPots.maxVisibleRows';
  static const defaultSectionLabel = 'Money Pots';

  List<MoneyPot> _moneyPots;
  String _sectionLabel;
  bool _showForeignCurrencyDebtInAppCurrency;
  bool _collapsed;
  int _gridColumns;
  int _maxVisibleRows;

  List<MoneyPot> get moneyPots => List.unmodifiable(_moneyPots);

  String get sectionLabel => _sectionLabel;

  bool get showForeignCurrencyDebtInAppCurrency =>
      _showForeignCurrencyDebtInAppCurrency;

  set sectionLabel(String value) {
    if (_sectionLabel == value) return;
    _sectionLabel = value;
    _storage.setString(_kSectionLabel, value);
    notifyListeners();
  }

  set showForeignCurrencyDebtInAppCurrency(bool value) {
    if (_showForeignCurrencyDebtInAppCurrency == value) return;
    _showForeignCurrencyDebtInAppCurrency = value;
    _storage.setBool(_kShowForeignCurrencyDebtInAppCurrency, value);
    notifyListeners();
  }

  bool get collapsed => _collapsed;

  set collapsed(bool value) {
    if (_collapsed == value) return;
    _collapsed = value;
    _storage.setBool(_kCollapsed, value);
    notifyListeners();
  }

  int get gridColumns => _gridColumns;

  set gridColumns(int value) {
    if (_gridColumns == value) return;
    _gridColumns = value;
    _storage.setInt(_kGridColumns, value);
    notifyListeners();
  }

  int get maxVisibleRows => _maxVisibleRows;

  set maxVisibleRows(int value) {
    if (_maxVisibleRows == value) return;
    _maxVisibleRows = value;
    _storage.setInt(_kMaxVisibleRows, value);
    notifyListeners();
  }

  void addMoneyPot(MoneyPot pot) {
    _moneyPots = [..._moneyPots, pot];
    _save();
    notifyListeners();
  }

  void updateMoneyPot(MoneyPot pot) {
    final index = _moneyPots.indexWhere((p) => p.id == pot.id);
    if (index != -1) {
      final newPots = List<MoneyPot>.from(_moneyPots);
      newPots[index] = pot;
      _moneyPots = newPots;
      _save();
      notifyListeners();
    }
  }

  void removeMoneyPot(String id) {
    _moneyPots = _moneyPots.where((p) => p.id != id).toList();
    _save();
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final jsonList = _moneyPots.map((p) => p.toJson()).toList();
      await _storage.setString(_kMoneyPots, jsonEncode(jsonList));
    } catch (e, stack) {
      debugLog(
        LogCategory.persistence,
        'Failed to save money pots',
        error: e,
        stackTrace: stack,
      );
    }
  }
}
