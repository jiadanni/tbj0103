import 'package:flutter/foundation.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

class InsightSettings extends ChangeNotifier {
  InsightSettings(
    this._storage, {
    required Set<String> initialDismissedIds,
    required Set<String> initialPinnedIds,
    required int? initialMinDataDaysOverride,
    required bool initialShowBehavioralInsights,
    required bool initialIncludeInternalTransfers,
  })  : _dismissedInsightIds = initialDismissedIds,
        _pinnedInsightIds = initialPinnedIds,
        _minDataDaysOverride = initialMinDataDaysOverride,
        _showBehavioralInsights = initialShowBehavioralInsights,
        _includeInternalTransfers = initialIncludeInternalTransfers;

  final StorageProvider _storage;
  AccountId? _accountId;

  static const _kDismissedIds = 'settings.insights.dismissedIds';
  static const _kPinnedIds = 'settings.insights.pinnedIds';
  static const _kMinDataDaysOverride = 'settings.insights.minDataDaysOverride';
  static const _kShowBehavioralInsights =
      'settings.insights.showBehavioralInsights';
  static const _kIncludeInternalTransfers =
      'settings.insights.includeInternalTransfers';

  String _key(String base) =>
      _accountId == null ? base : 'account.${_accountId!.value}.$base';

  final Set<String> _dismissedInsightIds;
  final Set<String> _pinnedInsightIds;
  int? _minDataDaysOverride;
  bool _showBehavioralInsights;
  bool _includeInternalTransfers;

  Future<void> setAccountId(AccountId? accountId) async {
    if (_accountId == accountId) return;
    _accountId = accountId;

    // Load account-specific values with fallback to global
    final dismissed = await _readStringList(_kDismissedIds);
    _dismissedInsightIds.clear();
    if (dismissed != null) {
      _dismissedInsightIds.addAll(dismissed);
    }

    final pinned = await _readStringList(_kPinnedIds);
    _pinnedInsightIds.clear();
    if (pinned != null) {
      _pinnedInsightIds.addAll(pinned);
    }

    notifyListeners();
  }

  void updateFromAccount(Set<String> dismissed, Set<String> pinned) {
    bool changed = false;
    if (!setEquals(_dismissedInsightIds, dismissed)) {
      _dismissedInsightIds.clear();
      _dismissedInsightIds.addAll(dismissed);
      changed = true;
    }
    if (!setEquals(_pinnedInsightIds, pinned)) {
      _pinnedInsightIds.clear();
      _pinnedInsightIds.addAll(pinned);
      changed = true;
    }
    if (changed) notifyListeners();
  }

  Future<List<String>?> _readStringList(String baseKey) async {
    if (_accountId != null) {
      final accountVal = await _storage.getStringList(_key(baseKey));
      if (accountVal != null) return accountVal;
    }
    return _storage.getStringList(baseKey);
  }

  Set<String> get dismissedInsightIds => Set.unmodifiable(_dismissedInsightIds);
  Set<String> get pinnedInsightIds => Set.unmodifiable(_pinnedInsightIds);
  int? get minDataDaysOverride => _minDataDaysOverride;
  bool get showBehavioralInsights => _showBehavioralInsights;
  bool get includeInternalTransfers => _includeInternalTransfers;

  Future<void> dismissInsight(String id) async {
    if (_dismissedInsightIds.contains(id)) return;
    _dismissedInsightIds.add(id);
    await _saveDismissedIds();
    notifyListeners();
  }

  Future<void> restoreInsight(String id) async {
    if (!_dismissedInsightIds.contains(id)) return;
    _dismissedInsightIds.remove(id);
    await _saveDismissedIds();
    notifyListeners();
  }

  Future<void> restoreAllInsights() async {
    if (_dismissedInsightIds.isEmpty) return;
    _dismissedInsightIds.clear();
    await _saveDismissedIds();
    notifyListeners();
  }

  Future<void> _saveDismissedIds() async {
    await _storage.setStringList(
      _key(_kDismissedIds),
      _dismissedInsightIds.toList(),
    );
  }

  Future<void> togglePinInsight(String id) async {
    if (_pinnedInsightIds.contains(id)) {
      _pinnedInsightIds.remove(id);
    } else {
      _pinnedInsightIds.add(id);
    }
    await _storage.setStringList(_key(_kPinnedIds), _pinnedInsightIds.toList());
    notifyListeners();
  }

  set minDataDaysOverride(int? value) {
    if (_minDataDaysOverride == value) return;
    _minDataDaysOverride = value;
    if (value == null) {
      _storage.remove(_key(_kMinDataDaysOverride));
    } else {
      _storage.setInt(_key(_kMinDataDaysOverride), value);
    }
    notifyListeners();
  }

  set showBehavioralInsights(bool value) {
    if (_showBehavioralInsights == value) return;
    _showBehavioralInsights = value;
    _storage.setBool(_key(_kShowBehavioralInsights), value);
    notifyListeners();
  }

  set includeInternalTransfers(bool value) {
    if (_includeInternalTransfers == value) return;
    _includeInternalTransfers = value;
    _storage.setBool(_key(_kIncludeInternalTransfers), value);
    notifyListeners();
  }
}
