import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';

/// Encoding and decoding utilities for AppSettings.
///
/// This class provides static methods to convert between domain enums and
/// their string representations for storage and retrieval.
class AppSettingsCodecs {
  AppSettingsCodecs._(); // Prevent instantiation

  // ============================================================================
  // Theme Mode Encoding/Decoding
  // ============================================================================

  static String encodeThemeMode(ThemeMode mode) {
    return switch (mode) {
      ThemeMode.system => 'system',
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
    };
  }

  static ThemeMode? decodeThemeMode(String? raw) {
    return switch (raw) {
      'system' => ThemeMode.system,
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => null,
    };
  }

  // ============================================================================
  // Day Format Encoding/Decoding
  // ============================================================================

  static String encodeDayFormat(DayFormat format) {
    return switch (format) {
      DayFormat.number => 'number',
      DayFormat.ordinal => 'ordinal',
      DayFormat.ordinalMonth => 'ordinalMonth',
      DayFormat.numericMonthDay => 'numericMonthDay',
      DayFormat.numericDayMonth => 'numericDayMonth',
    };
  }

  static DayFormat? decodeDayFormat(String? raw) {
    return switch (raw) {
      'number' => DayFormat.number,
      'ordinal' => DayFormat.ordinal,
      'ordinalMonth' => DayFormat.ordinalMonth,
      'numericMonthDay' => DayFormat.numericMonthDay,
      'numericDayMonth' => DayFormat.numericDayMonth,
      _ => null,
    };
  }

  // ============================================================================
  // Timeline Swipe Action Encoding/Decoding
  // ============================================================================

  static String encodeSwipeAction(TimelineSwipeAction action) {
    return switch (action) {
      TimelineSwipeAction.off => 'off',
      TimelineSwipeAction.edit => 'edit',
      TimelineSwipeAction.archive => 'archive',
    };
  }

  static TimelineSwipeAction? decodeSwipeAction(String? raw) {
    return switch (raw) {
      'off' => TimelineSwipeAction.off,
      'edit' => TimelineSwipeAction.edit,
      'archive' => TimelineSwipeAction.archive,
      _ => null,
    };
  }

  // ============================================================================
  // Timeline Tap Action Encoding/Decoding
  // ============================================================================

  static String encodeTimelineTapAction(TimelineTapAction action) {
    return switch (action) {
      TimelineTapAction.archive => 'archive',
      TimelineTapAction.menu => 'menu',
    };
  }

  static TimelineTapAction? decodeTimelineTapAction(String? raw) {
    return switch (raw) {
      'archive' => TimelineTapAction.archive,
      'menu' => TimelineTapAction.menu,
      _ => null,
    };
  }

  // ============================================================================
  // Pulse Swipe Action Encoding/Decoding
  // ============================================================================

  static String encodePulseSwipeAction(PulseSwipeAction action) {
    return switch (action) {
      PulseSwipeAction.off => 'off',
      PulseSwipeAction.edit => 'edit',
      PulseSwipeAction.delete => 'delete',
    };
  }

  static PulseSwipeAction? decodePulseSwipeAction(String? raw) {
    return switch (raw) {
      'off' => PulseSwipeAction.off,
      'edit' => PulseSwipeAction.edit,
      'delete' => PulseSwipeAction.delete,
      _ => null,
    };
  }

  // ============================================================================
  // Pulse Display Mode Encoding/Decoding
  // ============================================================================

  static String encodePulseDisplayMode(PulseDisplayMode mode) {
    return switch (mode) {
      PulseDisplayMode.automatic => 'auto',
      PulseDisplayMode.full => 'full',
      PulseDisplayMode.acronym => 'acronym',
      PulseDisplayMode.icon => 'icon',
    };
  }

  static PulseDisplayMode? decodePulseDisplayMode(String? raw) {
    return switch (raw) {
      'auto' => PulseDisplayMode.automatic,
      'full' => PulseDisplayMode.full,
      'acronym' => PulseDisplayMode.acronym,
      'icon' => PulseDisplayMode.icon,
      _ => null,
    };
  }

  // ============================================================================
  // Timeline Sort Order Encoding/Decoding
  // ============================================================================

  static String encodeSortOrder(TimelineSortOrder order) {
    return switch (order) {
      TimelineSortOrder.chronological => 'chronological',
      TimelineSortOrder.reverseChronological => 'reverse',
      TimelineSortOrder.nameAscending => 'nameAsc',
      TimelineSortOrder.nameDescending => 'nameDesc',
    };
  }

  static TimelineSortOrder? decodeSortOrder(String? raw) {
    return switch (raw) {
      'chronological' => TimelineSortOrder.chronological,
      'reverse' => TimelineSortOrder.reverseChronological,
      'nameAsc' => TimelineSortOrder.nameAscending,
      'nameDesc' => TimelineSortOrder.nameDescending,
      _ => null,
    };
  }

  // ============================================================================
  // Timeline Date Sort Mode Encoding/Decoding
  // ============================================================================

  static String encodeTimelineDateSortMode(TimelineDateSortMode mode) {
    return switch (mode) {
      TimelineDateSortMode.scheduledDate => 'scheduled',
      TimelineDateSortMode.actualDate => 'actual',
    };
  }

  static TimelineDateSortMode? decodeTimelineDateSortMode(String? raw) {
    return switch (raw) {
      'scheduled' => TimelineDateSortMode.scheduledDate,
      'actual' => TimelineDateSortMode.actualDate,
      _ => null,
    };
  }

  // ============================================================================
  // View Period Mode Encoding/Decoding
  // ============================================================================

  static String encodeViewPeriodMode(ViewPeriodMode mode) {
    return switch (mode) {
      ViewPeriodMode.calendar => 'calendar',
      ViewPeriodMode.paycheck => 'paycheck',
    };
  }

  static ViewPeriodMode? decodeViewPeriodMode(String? raw) {
    return switch (raw) {
      'calendar' => ViewPeriodMode.calendar,
      'paycheck' => ViewPeriodMode.paycheck,
      _ => null,
    };
  }

  // ============================================================================
  // Paycheck Adjust Direction Encoding/Decoding
  // ============================================================================

  static String encodeAdjustDirection(PaycheckAdjustDirection d) {
    return switch (d) {
      PaycheckAdjustDirection.before => 'before',
      PaycheckAdjustDirection.after => 'after',
    };
  }

  static PaycheckAdjustDirection? decodeAdjustDirection(String? raw) {
    return switch (raw) {
      'before' => PaycheckAdjustDirection.before,
      'after' => PaycheckAdjustDirection.after,
      _ => null,
    };
  }

  // ============================================================================
  // Color Preset Encoding/Decoding
  // ============================================================================

  // ============================================================================
  // App Theme Preset Encoding/Decoding
  // ============================================================================

  static String encodeAppThemePreset(AppThemePreset preset) {
    return switch (preset) {
      AppThemePreset.classic => 'classic',
      AppThemePreset.ocean => 'ocean',
      AppThemePreset.sunset => 'sunset',
      AppThemePreset.monochrome => 'monochrome',
      AppThemePreset.forest => 'forest',
      AppThemePreset.berry => 'berry',
      AppThemePreset.lavender => 'lavender',
      AppThemePreset.midnight => 'midnight',
      AppThemePreset.rose => 'rose',
      AppThemePreset.sky => 'sky',
      AppThemePreset.terracotta => 'terracotta',
      AppThemePreset.sage => 'sage',
      AppThemePreset.noir => 'noir',
      AppThemePreset.crimson => 'crimson',
      AppThemePreset.sunflower => 'sunflower',
      AppThemePreset.emerald => 'emerald',
      AppThemePreset.coffee => 'coffee',
      AppThemePreset.blossom => 'blossom',
    };
  }

  static AppThemePreset? decodeAppThemePreset(String? raw) {
    return switch (raw) {
      'classic' => AppThemePreset.classic,
      'ocean' => AppThemePreset.ocean,
      'sunset' => AppThemePreset.sunset,
      'monochrome' => AppThemePreset.monochrome,
      'forest' => AppThemePreset.forest,
      'berry' => AppThemePreset.berry,
      'lavender' => AppThemePreset.lavender,
      'midnight' => AppThemePreset.midnight,
      'rose' => AppThemePreset.rose,
      'mint' => AppThemePreset.ocean, // Migration: Mint -> Ocean
      'amber' => AppThemePreset.sunset, // Migration: Amber -> Sunset
      'copper' => AppThemePreset.terracotta, // Migration: Copper -> Terracotta
      'frost' => AppThemePreset.sky, // Migration: Frost -> Sky
      'sky' => AppThemePreset.sky,
      'arctic' => AppThemePreset.midnight, // Migration: Arctic -> Midnight
      'lime' => AppThemePreset.sage, // Migration: Lime -> Sage
      'fuchsia' => AppThemePreset.berry, // Migration: Fuchsia -> Berry
      'electric' => AppThemePreset.lavender, // Migration: Electric -> Lavender
      'terracotta' => AppThemePreset.terracotta,
      'sage' => AppThemePreset.sage,
      'noir' => AppThemePreset.noir,
      'crimson' => AppThemePreset.crimson,
      'sunflower' => AppThemePreset.sunflower,
      'emerald' => AppThemePreset.emerald,
      'coffee' => AppThemePreset.coffee,
      'blossom' => AppThemePreset.blossom,
      _ => null,
    };
  }

  // ============================================================================
  // Month Card Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMonthCardDisplayMode(MonthCardDisplayMode mode) {
    return switch (mode) {
      MonthCardDisplayMode.full => 'full',
      MonthCardDisplayMode.acronym => 'acronym',
    };
  }

  static MonthCardDisplayMode? decodeMonthCardDisplayMode(String? raw) {
    return switch (raw) {
      'full' => MonthCardDisplayMode.full,
      'acronym' => MonthCardDisplayMode.acronym,
      _ => null,
    };
  }

  // ============================================================================
  // Month Totals Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMonthTotalsDisplayMode(MonthTotalsDisplayMode mode) {
    return switch (mode) {
      MonthTotalsDisplayMode.includeCleared => 'includeCleared',
      MonthTotalsDisplayMode.showClearedRow => 'showClearedRow',
    };
  }

  static MonthTotalsDisplayMode? decodeMonthTotalsDisplayMode(String? raw) {
    return switch (raw) {
      'includeCleared' => MonthTotalsDisplayMode.includeCleared,
      'showClearedRow' => MonthTotalsDisplayMode.showClearedRow,
      _ => null,
    };
  }

  // ============================================================================
  // Multi-Month Display Mode Encoding/Decoding
  // ============================================================================

  static String encodeMultiMonthDisplayMode(MultiMonthDisplayMode mode) {
    return switch (mode) {
      MultiMonthDisplayMode.automatic => 'auto',
      MultiMonthDisplayMode.full => 'full',
      MultiMonthDisplayMode.acronym => 'acronym',
      MultiMonthDisplayMode.icon => 'icon',
    };
  }

  static MultiMonthDisplayMode? decodeMultiMonthDisplayMode(String? raw) {
    return switch (raw) {
      'auto' => MultiMonthDisplayMode.automatic,
      'full' => MultiMonthDisplayMode.full,
      'acronym' => MultiMonthDisplayMode.acronym,
      'icon' => MultiMonthDisplayMode.icon,
      _ => null,
    };
  }

  // ============================================================================
  // Terminology Preset Encoding/Decoding
  // ============================================================================

  static String encodeTerminologyPreset(TerminologyPreset preset) {
    return switch (preset) {
      TerminologyPreset.defaultTerms => 'default',
      TerminologyPreset.bills => 'bills',
      TerminologyPreset.budget => 'budget',
      TerminologyPreset.custom => 'custom',
    };
  }

  static TerminologyPreset? decodeTerminologyPreset(String? raw) {
    return switch (raw) {
      'default' => TerminologyPreset.defaultTerms,
      'bills' => TerminologyPreset.bills,
      'budget' => TerminologyPreset.budget,
      'custom' => TerminologyPreset.custom,
      _ => null,
    };
  }

  // ============================================================================
  // Text Scale Preset Encoding/Decoding
  // ============================================================================

  static String encodeTextScalePreset(TextScalePreset preset) {
    return switch (preset) {
      TextScalePreset.small => 'small',
      TextScalePreset.normal => 'normal',
      TextScalePreset.large => 'large',
      TextScalePreset.extraLarge => 'extraLarge',
    };
  }

  static TextScalePreset? decodeTextScalePreset(String? raw) {
    return switch (raw) {
      'small' => TextScalePreset.small,
      'normal' => TextScalePreset.normal,
      'large' => TextScalePreset.large,
      'extraLarge' => TextScalePreset.extraLarge,
      _ => null,
    };
  }

  // ============================================================================
  // Font Preset Encoding/Decoding
  // ============================================================================

  static String encodeFontPreset(FontPreset preset) {
    return switch (preset) {
      FontPreset.system => 'system',
      FontPreset.monospace => 'monospace',
    };
  }

  static FontPreset? decodeFontPreset(String? raw) {
    return switch (raw) {
      'system' => FontPreset.system,
      'monospace' => FontPreset.monospace,
      _ => null,
    };
  }

  // ============================================================================
  // Timeline View Mode Encoding/Decoding
  // ============================================================================

  static String encodeTimelineViewMode(TimelineViewMode mode) {
    return switch (mode) {
      TimelineViewMode.month => 'month',
      TimelineViewMode.grid => 'grid',
      TimelineViewMode.sheet => 'sheet',
    };
  }

  static TimelineViewMode? decodeTimelineViewMode(String? raw) {
    return switch (raw) {
      'month' => TimelineViewMode.month,
      'grid' => TimelineViewMode.grid,
      'sheet' => TimelineViewMode.sheet,
      _ => null,
    };
  }

  // ============================================================================
  // Pulses Filter Type Encoding/Decoding
  // ============================================================================

  static String encodePulsesFilterType(PulsesFilterType type) {
    return switch (type) {
      PulsesFilterType.all => 'all',
      PulsesFilterType.income => 'income',
      PulsesFilterType.expenses => 'expenses',
      PulsesFilterType.debt => 'debt',
      PulsesFilterType.oneOff => 'oneOff',
      PulsesFilterType.recurring => 'recurring',
      PulsesFilterType.category => 'category',
      PulsesFilterType.envelopes => 'envelopes',
    };
  }

  static PulsesFilterType? decodePulsesFilterType(String? raw) {
    return switch (raw) {
      'all' => PulsesFilterType.all,
      'income' => PulsesFilterType.income,
      'expenses' => PulsesFilterType.expenses,
      'debt' => PulsesFilterType.debt,
      'oneOff' => PulsesFilterType.oneOff,
      'recurring' => PulsesFilterType.recurring,
      'category' => PulsesFilterType.category,
      'envelopes' => PulsesFilterType.envelopes,
      _ => null,
    };
  }

  // ============================================================================
  // Pulses Group By Encoding/Decoding
  // ============================================================================

  static String encodePulsesGroupBy(PulsesGroupBy groupBy) {
    return switch (groupBy) {
      PulsesGroupBy.none => 'none',
      PulsesGroupBy.category => 'category',
      PulsesGroupBy.type => 'type',
      PulsesGroupBy.origin => 'origin',
      PulsesGroupBy.dueDate => 'dueDate',
    };
  }

  static PulsesGroupBy? decodePulsesGroupBy(String? raw) {
    return switch (raw) {
      'none' => PulsesGroupBy.none,
      'category' => PulsesGroupBy.category,
      'type' => PulsesGroupBy.type,
      'origin' || 'company' => PulsesGroupBy.origin,
      'dueDate' => PulsesGroupBy.dueDate,
      _ => null,
    };
  }

  // ============================================================================
  // Category Preset Mode Encoding/Decoding
  // ============================================================================

  static String encodeCategoryPresetMode(CategoryPresetMode mode) {
    return switch (mode) {
      CategoryPresetMode.defaultPresets => 'default',
      CategoryPresetMode.customOnly => 'custom',
      CategoryPresetMode.both => 'both',
    };
  }

  static CategoryPresetMode? decodeCategoryPresetMode(String? raw) {
    return switch (raw) {
      'default' => CategoryPresetMode.defaultPresets,
      'custom' => CategoryPresetMode.customOnly,
      'both' => CategoryPresetMode.both,
      _ => null,
    };
  }
}
