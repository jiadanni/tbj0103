import 'dart:async';
import 'dart:convert';
import 'package:flutter/widgets.dart';

import 'package:expense_stalker_mobile/src/models/account.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/state/expense_persistence.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/util/async_queue.dart';
import 'package:collection/collection.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/debug_logger.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/test_data_generator.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/services/account_service.dart';
import 'package:expense_stalker_mobile/src/services/import_service.dart';

part 'expense_store_extensions/account_operations.dart';
part 'expense_store_extensions/settings_operations.dart';
part 'expense_store_extensions/timeline_operations.dart';
part 'expense_store_extensions/pulse_operations.dart';

class ExpenseStore extends ChangeNotifier {
  List<Account> _accounts;
  Account _currentAccount;
  DateTime _selectedMonth;
  List<TimelineItem> _timelineItems;
  List<PulseEntry> _pulses;
  final ExpensePersistence? _persistence;
  Timer? _debounceTimer;
  final AsyncQueue _saveQueue = AsyncQueue();
  final AsyncQueue _accountQueue = AsyncQueue();

  late final AccountService? _accountService;
  late final ImportService? _importService;

  /// Flag to indicate that caches need to be recomputed.
  bool _cacheDirty = true;

  /// The account ID being switched to, used to detect superseded switches.
  AccountId? _pendingSwitchAccountId;

  /// Monotonically increasing operation ID for account switches.
  /// Used to detect when an account switch operation has been superseded.
  int _switchOperationId = 0;

  // Selective notifiers for granular listening
  late final ValueNotifier<DateTime> selectedMonthNotifier;
  late final ValueNotifier<List<TimelineItem>> activeTimelineItemsNotifier;
  late final ValueNotifier<List<PulseEntry>> pulseNotifier;
  late final ValueNotifier<Set<TimelineItemId>> recentlyClearedNotifier;

  ExpenseStore({
    required List<Account> accounts,
    required Account currentAccount,
    required DateTime selectedMonth,
    required List<TimelineItem> timelineItems,
    required List<PulseEntry> pulses,
    ExpensePersistence? persistence,
  })  : _accounts = List.unmodifiable(accounts),
        _currentAccount = currentAccount,
        _selectedMonth = monthOnly(selectedMonth),
        _timelineItems = List.unmodifiable(timelineItems),
        _pulses = List.unmodifiable(pulses),
        _persistence = persistence {
    // Initialize selective notifiers
    selectedMonthNotifier = ValueNotifier<DateTime>(_selectedMonth);
    activeTimelineItemsNotifier = ValueNotifier<List<TimelineItem>>(
      _timelineItems.where((p) => !p.archived).toList(),
    );
    pulseNotifier = ValueNotifier<List<PulseEntry>>(_pulses);
    recentlyClearedNotifier = ValueNotifier<Set<TimelineItemId>>({});

    if (persistence != null) {
      _accountService = AccountService(persistence);
      _importService = ImportService(persistence);
    } else {
      _accountService = null;
      _importService = null;
    }
  }

  List<Account> get accounts => _accounts;
  Account get currentAccount => _currentAccount;
  DateTime get selectedMonth => _selectedMonth;
  ExpensePersistence? get persistence => _persistence;

  List<TimelineItem> get timelineItems => _timelineItems;
  List<PulseEntry> get pulses => _pulses;

  Future<void> saveNow() async {
    final p = _persistence;
    if (p == null) return;
    _debounceTimer?.cancel();
    await _saveQueue.enqueue(() => p.save(_currentAccount.id, _snapshot()));
  }

  static Future<ExpenseStore> loadOrCreate() async {
    final persistence = await ExpensePersistence.create();
    try {
      final accounts = await persistence.loadAccounts();
      final currentAccountId = await persistence.getCurrentAccountId();

      Account selectedAccount;
      if (accounts.isEmpty) {
        // First run or no accounts: create a default Main Account
        selectedAccount = Account.create(name: 'Main Account');
        await persistence.saveAccounts([selectedAccount]);
        await persistence.setCurrentAccountId(selectedAccount.id);

        final store = ExpenseStore(
          accounts: [selectedAccount],
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          timelineItems: [],
          pulses: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      selectedAccount = accounts.firstWhere(
        (a) => a.id == currentAccountId,
        orElse: () => accounts.first,
      );

      final snapshot = await persistence.load(selectedAccount.id);
      if (snapshot == null) {
        // Account exists but data is missing? Unusual but handle it
        final store = ExpenseStore(
          accounts: accounts,
          currentAccount: selectedAccount,
          selectedMonth: DateTime.now(),
          timelineItems: [],
          pulses: [],
          persistence: persistence,
        );
        await persistence.save(selectedAccount.id, store._snapshot());
        return store;
      }

      return ExpenseStore(
        accounts: accounts,
        currentAccount: selectedAccount,
        selectedMonth: snapshot.selectedMonth,
        timelineItems: snapshot.timelineItems,
        pulses: snapshot.pulses,
        persistence: persistence,
      );
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to load expenses, creating emergency account',
        error: error,
        stackTrace: stackTrace,
      );
      final emergencyAccount = Account.create(name: 'Rescue Account');
      return ExpenseStore(
        accounts: [emergencyAccount],
        currentAccount: emergencyAccount,
        selectedMonth: DateTime.now(),
        timelineItems: [],
        pulses: [],
        persistence: persistence,
      );
    }
  }

  /// Factory for tests
  factory ExpenseStore.withSampleData() {
    final account = Account.create(name: 'Test Account', isTestData: true);
    final testData = TestDataGenerator.generate(size: TestDatasetSize.standard);
    return ExpenseStore(
      accounts: [account],
      currentAccount: account,
      selectedMonth: DateTime.now(),
      timelineItems: testData.timelineItems,
      pulses: testData.pulses,
    );
  }

  /// Populate the current account with demo data for exploration.
  /// Uses TestDataGenerator to create ~50 realistic transactions across 12 months.
  Future<void> populateDemoData() async {
    final testData = TestDataGenerator.generate(size: TestDatasetSize.standard);

    // Mark current account as having test data
    final updatedAccount = _currentAccount.copyWith(isTestData: true);
    _currentAccount = updatedAccount;

    // Update accounts list
    _accounts = List.unmodifiable(
      _accounts.map((a) => a.id == updatedAccount.id ? updatedAccount : a),
    );

    // Add generated data
    _timelineItems = List.unmodifiable([
      ..._timelineItems,
      ...testData.timelineItems,
    ]);
    _pulses = List.unmodifiable([..._pulses, ...testData.pulses]);

    _touch(forceImmediate: true);

    // Persist accounts update
    await _persistence?.saveAccounts(_accounts);
  }

  Set<TimelineItemId> get recentlyClearedTimelineItemIds =>
      Set.unmodifiable(_recentlyClearedTimelineItemIds);

  /// Returns all active (non-archived) timeline items.
  List<TimelineItem> get activeTimelineItems {
    _ensureCachesValid();
    return _cachedActiveTimelineItems ??=
        _timelineItems.where((p) => !p.archived).toList(growable: false);
  }

  List<TimelineItem> get archivedTimelineItems {
    _ensureCachesValid();
    return _cachedArchivedTimelineItems ??=
        _timelineItems.where((p) => p.archived).toList(growable: false);
  }

  void invalidatePulsesCache() {
    if (_cacheDirty) return;
    _cacheDirty = true;
    _pulseForMonthCache.clear(); // Clear month-based pulse cache
    _cachedCategoriesItemsHash = -1; // Invalidate categories cache
    _cachedCategoriesPulsesHash = -1;
    // ignore: deprecated_member_use_from_same_package
    notifyListeners();
  }

  void clearAllData() {
    _selectedMonth = monthOnly(DateTime.now());
    _timelineItems = const [];
    _pulses = const [];
    _touch(forceImmediate: true);
  }

  ExpenseSnapshot createSnapshot({List<MoneyPot> moneyPots = const []}) =>
      _snapshot(moneyPots: moneyPots);

  /// Creates a recovery backup of the current account data before destructive operations.
  ///
  /// The backup is stored with a timestamped key and can be used to recover data
  /// if an import corrupts the existing data. Only keeps the most recent backup
  /// to avoid storage bloat.
  Future<bool> _createRecoveryBackup() async {
    final persistence = _persistence;
    if (persistence == null) return false;

    try {
      final snapshot = _snapshot();
      final backupJson = ExpensePersistence.toExportJson(snapshot);
      final backupString = jsonEncode(backupJson);

      // Get storage provider to save the backup
      final storage = await StorageProvider.create();
      final backupKey =
          'recovery.${_currentAccount.id}.${DateTime.now().millisecondsSinceEpoch}';

      // Clean up old backups for this account (keep only the most recent)
      final oldBackupKey = await storage.getString(
        'recovery.${_currentAccount.id}.latest_key',
      );
      if (oldBackupKey != null) {
        await storage.remove(oldBackupKey);
      }

      // Save the new backup
      final success = await storage.setString(backupKey, backupString);
      if (success) {
        await storage.setString(
          'recovery.${_currentAccount.id}.latest_key',
          backupKey,
        );
        debugLog(
          LogCategory.persistence,
          'Created recovery backup: $backupKey',
        );
      }
      return success;
    } catch (error, stackTrace) {
      ErrorTracker.instance.trackException(
        'recovery_backup',
        'Failed to create recovery backup before import',
        error,
        stackTrace,
        severity: ErrorSeverity.warning,
      );
      return false;
    }
  }

  /// Retrieves the latest recovery backup for the current account.
  ///
  /// Returns the backup snapshot if available, null otherwise.
  Future<ExpenseSnapshot?> getRecoveryBackup() async {
    try {
      final storage = await StorageProvider.create();
      final backupKey = await storage.getString(
        'recovery.${_currentAccount.id}.latest_key',
      );
      if (backupKey == null) return null;

      final backupString = await storage.getString(backupKey);
      if (backupString == null) return null;

      final json = jsonDecode(backupString) as Map<String, dynamic>;
      return ExpensePersistence.fromExportJson(json);
    } catch (error, stackTrace) {
      debugLog(
        LogCategory.persistence,
        'Failed to read recovery backup',
        error: error,
        stackTrace: stackTrace,
      );
      return null;
    }
  }

  Future<bool> importSnapshot(ExpenseSnapshot snapshot) async {
    final service = _importService;
    if (service == null) {
      return false;
    }

    // Create a recovery backup before importing (non-blocking failure)
    await _createRecoveryBackup();

    final success = await service.importSnapshot(snapshot);
    if (!success) return false;

    // Apply the snapshot to the store
    _selectedMonth = monthOnly(snapshot.selectedMonth);
    _timelineItems = List.unmodifiable(snapshot.timelineItems);
    _pulses = List.unmodifiable(snapshot.pulses);
    _touch(forceImmediate: true);
    return true;
  }

  @override
  @Deprecated('Use selective notifiers (selectedMonthNotifier, etc.) instead')
  void notifyListeners() {
    super.notifyListeners();
  }

  @override
  void dispose() {
    final persistence = _persistence;

    _debounceTimer?.cancel();
    for (final timer in _recentlyClearedTimers.values) {
      timer.cancel();
    }
    _recentlyClearedTimers.clear();

    // Dispose selective notifiers
    selectedMonthNotifier.dispose();
    activeTimelineItemsNotifier.dispose();
    pulseNotifier.dispose();
    recentlyClearedNotifier.dispose();

    // CRITICAL: Ensure any pending changes are saved before disposing.
    // If a pulse was just added and the 2-second debounce timer hasn't fired yet,
    // we must save immediately to prevent data loss when the app closes.
    if (persistence != null) {
      final accountId = _currentAccount.id;
      _saveQueue.enqueue(() => persistence.save(accountId, _snapshot()));
    }

    super.dispose();
  }

  // --- Internal helpers and state ---

  List<TimelineItem>? _cachedActiveTimelineItems;
  List<TimelineItem>? _cachedArchivedTimelineItems;
  List<PulseEntry>? _cachedSelectedMonthPulses;
  String? _cachedPulsesCacheKey;
  List<String>? _cachedUserIncomeCategories;
  List<String>? _cachedUserExpenseCategories;
  int _cachedCategoriesItemsHash = -1;
  int _cachedCategoriesPulsesHash = -1;
  List<PulseEntry>? _cachedFilteredPulses;
  ({
    String search,
    PulsesFilterType type,
    String? category,
    bool archived,
    int hash,
  })? _filteredCacheKey;

  final Map<String, List<PulseEntry>> _pulseForMonthCache = {};
  final Map<TimelineItemId, Timer> _recentlyClearedTimers = {};
  final Set<TimelineItemId> _recentlyClearedTimelineItemIds = {};

  static const Duration _kSaveDebounce = AppConstants.saveDebounceDuration;
  static const Duration _kClearedVisibleDuration = Duration(seconds: 5);

  static List<T> _replaceOrAddById<T, ID>(
    List<T> list,
    T item,
    ID Function(T) idOf,
  ) {
    final index = list.indexWhere((e) => idOf(e) == idOf(item));
    final next = list.toList(growable: true);
    if (index >= 0) {
      next[index] = item;
    } else {
      next.add(item);
    }
    return List.unmodifiable(next);
  }

  void _ensureCachesValid() {
    if (!_cacheDirty) return;
    _cachedActiveTimelineItems = null;
    _cachedArchivedTimelineItems = null;
    _cachedSelectedMonthPulses = null;
    _cachedPulsesCacheKey = null;
    _pulseForMonthCache.clear();
    _cachedUserIncomeCategories = null;
    _cachedUserExpenseCategories = null;
    _cachedCategoriesItemsHash = -1;
    _cachedCategoriesPulsesHash = -1;
    _cachedFilteredPulses = null;
    _filteredCacheKey = null;
    _cacheDirty = false;
  }

  void _touch({bool forceImmediate = false}) {
    _cacheDirty = true;
    activeTimelineItemsNotifier.value =
        _timelineItems.where((p) => !p.archived).toList();
    pulseNotifier.value = _pulses;
    // ignore: deprecated_member_use_from_same_package
    notifyListeners();

    if (forceImmediate) {
      saveNow();
    } else {
      _scheduleSave();
    }
  }

  void _scheduleSave() {
    final persistence = _persistence;
    if (persistence == null) return;

    final accountId = _currentAccount.id;
    _debounceTimer?.cancel();
    _debounceTimer = Timer(_kSaveDebounce, () {
      _saveQueue.enqueue(() async {
        try {
          await persistence.save(accountId, _snapshot());
        } catch (error, stackTrace) {
          debugLog(
            LogCategory.persistence,
            'Failed to save snapshot for account $accountId',
            error: error,
            stackTrace: stackTrace,
          );
          ErrorTracker.instance.trackError(
            ErrorContext(
              category: 'persistence',
              message: 'Failed to save account $accountId',
              severity: ErrorSeverity.error,
              error: error,
              additionalData: {'stack': stackTrace.toString()},
            ),
          );
        }
      });
    });
  }

  ExpenseSnapshot _snapshot({List<MoneyPot> moneyPots = const []}) =>
      ExpenseSnapshot(
        selectedMonth: _selectedMonth,
        timelineItems: _timelineItems,
        pulses: _pulses,
        accountSettings: _currentAccount,
        moneyPots: moneyPots,
      );
}

/// A transaction wrapper for batching multiple store mutations.
///
/// Use [ExpenseStore.transaction] to create a transaction. All mutations
/// within the transaction are batched together with a single notification
/// and save operation when [commit] is called.
///
/// Example:
/// ```dart
/// store.transaction((tx) {
///   tx.upsertTimelineItem(item);
///   tx.upsertPulse(pulse);
///   tx.commit();
/// });
/// ```
class StoreTransaction {
  final ExpenseStore _store;
  bool _committed = false;
  bool _dirty = false;

  StoreTransaction._(this._store);

  /// Adds or updates a timeline item.
  void upsertTimelineItem(TimelineItem item) {
    _checkNotCommitted();
    _store._timelineItems =
        ExpenseStore._replaceOrAddById<TimelineItem, TimelineItemId>(
      _store._timelineItems,
      item,
      (p) => p.id,
    );
    _dirty = true;
  }

  /// Adds or updates a pulse entry.
  void upsertPulse(PulseEntry entry) {
    _checkNotCommitted();
    _store._pulses = ExpenseStore._replaceOrAddById<PulseEntry, EntryId>(
      _store._pulses,
      entry,
      (p) => p.id,
    );
    _dirty = true;
  }

  /// Deletes a timeline item by ID.
  ///
  /// If [keepHistory] is true, associated pulses are unlinked (become standalone).
  /// If false, associated pulses are also deleted.
  void deleteTimelineItem(TimelineItemId id, {bool keepHistory = true}) {
    _checkNotCommitted();
    _store._timelineItems = List.unmodifiable(
      _store._timelineItems.where((p) => p.id != id),
    );

    if (keepHistory) {
      // Unlink pulses (make them standalone)
      final nextPulses = _store._pulses.toList(growable: true);
      for (var i = 0; i < nextPulses.length; i++) {
        if (nextPulses[i].timelineItemId == id) {
          nextPulses[i] = nextPulses[i].copyWith(timelineItemId: null);
        }
      }
      _store._pulses = List.unmodifiable(nextPulses);
    } else {
      // Delete associated pulses
      _store._pulses = List.unmodifiable(
        _store._pulses.where((p) => p.timelineItemId != id),
      );
    }
    _dirty = true;
  }

  /// Deletes a pulse by ID.
  void deletePulse(EntryId id) {
    _checkNotCommitted();
    _store._pulses = List.unmodifiable(_store._pulses.where((p) => p.id != id));
    _dirty = true;
  }

  /// Sets the archived state of a timeline item.
  void setTimelineItemArchived(TimelineItemId id, bool archived) {
    _checkNotCommitted();
    final index = _store._timelineItems.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final next = _store._timelineItems.toList(growable: true);
    next[index] = next[index].copyWith(archived: archived);
    _store._timelineItems = List.unmodifiable(next);

    if (!archived) {
      _store._pulses = List.unmodifiable(
        _store._pulses.where((p) => p.timelineItemId != id),
      );
    }
    _dirty = true;
  }

  /// Commits all batched mutations with a single notification and save.
  ///
  /// Must be called exactly once. Throws if called multiple times.
  void commit({bool forceImmediate = false}) {
    _checkNotCommitted();
    _committed = true;
    if (_dirty) {
      _store._touch(forceImmediate: forceImmediate);
    }
  }

  void _checkNotCommitted() {
    if (_committed) {
      throw StateError('Transaction already committed');
    }
  }
}

// Extension to add transaction method to ExpenseStore
extension TransactionSupport on ExpenseStore {
  /// Executes multiple mutations atomically with a single notification.
  ///
  /// The [action] callback receives a [StoreTransaction] that can be used
  /// to batch mutations. Call [StoreTransaction.commit] when done.
  ///
  /// Example:
  /// ```dart
  /// store.transaction((tx) {
  ///   tx.upsertTimelineItem(item);
  ///   tx.upsertPulse(pulse);
  ///   tx.commit();
  /// });
  /// ```
  void transaction(void Function(StoreTransaction tx) action) {
    final tx = StoreTransaction._(this);
    action(tx);
    // Auto-commit if not already committed
    if (!tx._committed && tx._dirty) {
      tx.commit();
    }
  }
}

class ExpenseStoreScope extends InheritedNotifier<ExpenseStore> {
  const ExpenseStoreScope({
    super.key,
    required ExpenseStore store,
    required super.child,
  }) : super(notifier: store);

  static ExpenseStore of(BuildContext context) {
    final scope =
        context.dependOnInheritedWidgetOfExactType<ExpenseStoreScope>();
    if (scope == null) {
      throw StateError('ExpenseStoreScope not found in widget tree.');
    }
    return scope.notifier!;
  }

  static ExpenseStore read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<ExpenseStoreScope>();
    if (scope == null) {
      throw StateError('ExpenseStoreScope not found in widget tree.');
    }
    return scope.notifier!;
  }
}
