import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import 'package:expense_stalker_mobile/src/features/insights/insights_screen.dart';
import 'package:expense_stalker_mobile/src/features/pulse/pulse_screen.dart';
import 'package:expense_stalker_mobile/src/features/timeline/timeline_screen.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

/// Breakpoint above which the shell switches from a bottom nav to a side rail.
const double _kDesktopBreakpoint = 1024.0;

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tabIndex = 0;
  bool _initialized = false;
  // Keep page indices stable without a PageController on desktop.
  final PageController _pageController = PageController(initialPage: 0);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onDestinationSelected(int index) {
    setState(() => _tabIndex = index);
    // Animate the PageView even on desktop so the page content switches.
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final terminology = Terminology.of(context);
    final isDesktop = MediaQuery.sizeOf(context).width >= _kDesktopBreakpoint;

    final navItems = [
      _NavItem(
        icon: PhosphorIcons.calendar(),
        selectedIcon: PhosphorIcons.calendar(PhosphorIconsStyle.fill),
        label: terminology.timelineTabLabel,
      ),
      _NavItem(
        icon: PhosphorIcons.wallet(),
        selectedIcon: PhosphorIcons.wallet(PhosphorIconsStyle.fill),
        label: terminology.pulseTabLabel,
      ),
      _NavItem(
        icon: PhosphorIcons.chartLine(),
        selectedIcon: PhosphorIcons.chartLine(PhosphorIconsStyle.fill),
        label: terminology.insightsTabLabel,
      ),
    ];

    const List<Widget> tabs = [
      TimelineScreen(),
      PulseScreen(),
      InsightsScreen(),
    ];

    final pageView = PageView(
      controller: _pageController,
      physics: const NeverScrollableScrollPhysics(),
      onPageChanged: (index) {
        if (!mounted) return;
        setState(() => _tabIndex = index);
      },
      children: tabs,
    );

    if (isDesktop) {
      return Scaffold(
        body: Row(
          children: [
            _DesktopNavRail(
              selectedIndex: _tabIndex,
              onDestinationSelected: _onDestinationSelected,
              items: navItems,
            ),
            const VerticalDivider(width: 1, thickness: 1),
            Expanded(child: pageView),
          ],
        ),
      );
    }

    return Scaffold(
      body: pageView,
      bottomNavigationBar: _CustomBottomNav(
        selectedIndex: _tabIndex,
        onDestinationSelected: _onDestinationSelected,
        items: navItems,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Desktop Navigation Rail
// ─────────────────────────────────────────────────────────────────────────────

class _DesktopNavRail extends StatelessWidget {
  const _DesktopNavRail({
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.items,
  });

  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<_NavItem> items;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return NavigationRail(
      selectedIndex: selectedIndex,
      onDestinationSelected: onDestinationSelected,
      labelType: NavigationRailLabelType.all,
      backgroundColor: theme.colorScheme.surface,
      selectedIconTheme: IconThemeData(color: theme.colorScheme.primary),
      unselectedIconTheme:
          IconThemeData(color: theme.colorScheme.onSurfaceVariant),
      selectedLabelTextStyle: theme.textTheme.labelSmall?.copyWith(
        color: theme.colorScheme.primary,
        fontWeight: FontWeight.w600,
      ),
      unselectedLabelTextStyle: theme.textTheme.labelSmall?.copyWith(
        color: theme.colorScheme.onSurfaceVariant,
      ),
      destinations: items
          .map(
            (item) => NavigationRailDestination(
              icon: Icon(item.icon),
              selectedIcon: Icon(item.selectedIcon),
              label: Text(item.label),
            ),
          )
          .toList(),
    );
  }
}

/// Data class for navigation items
class _NavItem {
  const _NavItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });

  final IconData icon;
  final IconData selectedIcon;
  final String label;
}

/// Custom bottom navigation bar with top-line indicator instead of pill
class _CustomBottomNav extends StatelessWidget {
  const _CustomBottomNav({
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.items,
  });

  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<_NavItem> items;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 72 + MediaQuery.paddingOf(context).bottom,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: theme.colorScheme.outlineVariant.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == selectedIndex;

            return Expanded(
              child: _NavItemWidget(
                item: item,
                isSelected: isSelected,
                onTap: () => onDestinationSelected(index),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _NavItemWidget extends StatelessWidget {
  const _NavItemWidget({
    required this.item,
    required this.isSelected,
    required this.onTap,
  });

  final _NavItem item;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = isSelected
        ? theme.colorScheme.primary
        : theme.colorScheme.onSurfaceVariant;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          // Top-line indicator
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            height: 2,
            width: isSelected ? 32 : 0,
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
              borderRadius: BorderRadius.circular(1),
            ),
          ),
          const Spacer(),
          // Icon
          Icon(
            isSelected ? item.selectedIcon : item.icon,
            color: color,
            size: 24,
          ),
          const SizedBox(height: 4),
          // Label
          Text(
            item.label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              fontSize: 11,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
