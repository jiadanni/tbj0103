// ignore_for_file: use_build_context_synchronously
import 'dart:io';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:expense_stalker_mobile/src/app/home_shell.dart';
import 'package:expense_stalker_mobile/src/features/onboarding/onboarding_wizard.dart';
import 'package:expense_stalker_mobile/src/features/options/options_screen.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/auth_service.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/state/session_manager.dart';
import 'package:expense_stalker_mobile/src/state/settings/onboarding_settings.dart';
import 'package:expense_stalker_mobile/src/state/storage_provider.dart';
import 'package:expense_stalker_mobile/src/widgets/error_boundary.dart';
import 'package:expense_stalker_mobile/src/widgets/lock_screen.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/error_tracker.dart';

class ExpenseStalkerApp extends StatefulWidget {
  const ExpenseStalkerApp({
    super.key,
    required this.store,
    required this.settings,
    required this.onboardingSettings,
  });

  final ExpenseStore store;
  final AppSettingsStore settings;
  final OnboardingSettings onboardingSettings;

  @override
  State<ExpenseStalkerApp> createState() => _ExpenseStalkerAppState();
}

class _ExpenseStalkerAppState extends State<ExpenseStalkerApp>
    with WidgetsBindingObserver {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  late final AuthService _authService;
  late final SessionManager _sessionManager;
  StorageProvider? _storage;
  bool _isLocked = false;
  bool _isInitialized = false;
  bool _showPrivacyScreen = false; // Hide content when app is in background
  bool _isAuthenticating = false; // Prevent re-lock during biometric prompt
  bool _showOnboarding = false; // Show onboarding wizard for fresh installs

  static const _screenshotChannel = MethodChannel(
    'com.expensestalker/screenshot',
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _authService = AuthService();
    _initializeAuth();

    // Check if onboarding should be shown
    _showOnboarding = widget.onboardingSettings.shouldShowOnboarding;

    // Listen for screenshot protection setting changes
    screenshotProtectionNotifier.addListener(_onScreenshotProtectionChanged);

    // Check for crash reports after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkForCrashReport());
  }

  Future<void> _initializeAuth() async {
    await _authService.initialize();
    if (!mounted) return;

    // Create storage provider for session manager (needed for persisting standby time)
    _storage = await StorageProvider.create();
    _sessionManager = SessionManager(_authService, storage: _storage);

    final isAuthEnabled = await _authService.isAuthEnabled();
    if (!mounted) return;

    // Always set up the lock callback so it works when auth is enabled later
    _sessionManager.startSession(
      context,
      onLock: () {
        if (mounted) {
          setState(() => _isLocked = true);
        }
      },
    );

    // Apply initial screenshot protection setting
    final preventScreenshots = await _authService.preventScreenshots();
    if (!mounted) return;

    _setScreenshotProtection(preventScreenshots);

    if (mounted) {
      setState(() {
        _isLocked = isAuthEnabled;
        _isInitialized = true;
      });
    }

    // Listen for settings changes that affect period boundaries
    widget.settings.addListener(_onSettingsChanged);
  }

  Future<void> _checkForCrashReport() async {
    final report = await ErrorTracker.instance.loadCrashReport();
    if (report != null && mounted) {
      final context = _navigatorKey.currentContext;
      if (context != null) {
        _showCrashReportDialog(context, report);
      }
    }
  }

  void _showCrashReportDialog(BuildContext context, ErrorContext report) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        final l10n = AppLocalizations.of(context);
        return AlertDialog(
          title: Text(
            l10n?.appTitle ?? 'Expense Stalker',
          ), // Using appTitle as a safe fallback
          content: const Text(
            'The app crashed last time. Would you like to send an anonymous report to help us fix it?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showCrashReportDetails(context, report);
              },
              child: const Text('View Report'),
            ),
            TextButton(
              onPressed: () {
                ErrorTracker.instance.deleteCrashReport();
                Navigator.of(context).pop();
              },
              child: const Text('Don\'t Send'),
            ),
            FilledButton(
              onPressed: () {
                // Simulate sending
                ErrorTracker.instance.deleteCrashReport();
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Report sent. Thank you!')),
                );
              },
              child: const Text('Send'),
            ),
          ],
        );
      },
    );
  }

  void _showCrashReportDetails(BuildContext context, ErrorContext report) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Crash Report Details'),
        content: SingleChildScrollView(
          child: SelectableText(report.toJsonString(pretty: true)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
          FilledButton(
            onPressed: () {
              // Re-open the main dialog to let user choose action
              Navigator.of(context).pop();
              _showCrashReportDialog(context, report);
            },
            child: const Text('Back'),
          ),
        ],
      ),
    );
  }

  void _onScreenshotProtectionChanged(bool enabled) {
    _setScreenshotProtection(enabled);
  }

  Future<void> _setScreenshotProtection(bool enabled) async {
    try {
      await _screenshotChannel.invokeMethod('setSecureFlag', {
        'enabled': enabled,
      });
    } on PlatformException {
      // Platform doesn't support screenshot protection, ignore
    } on MissingPluginException {
      // Method channel not implemented on this platform, ignore
    }
  }

  void _onSettingsChanged() {
    // Invalidate expense store cache when period-related settings change
    widget.store.invalidatePulsesCache();
  }

  /// Returns true if this platform uses desktop lifecycle semantics.
  /// On desktop, `inactive` merely means the window lost focus — it is NOT
  /// a background/paused state and must not trigger lock or privacy screens.
  static bool get _isDesktop =>
      !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        (!_isDesktop && state == AppLifecycleState.inactive) ||
        (_isDesktop && state == AppLifecycleState.hidden)) {
      // App going to background - show privacy screen immediately.
      // On desktop: only `hidden` (minimised/occluded) counts as background.
      // On mobile: both `paused` and `inactive` count.
      _onBackground();
    } else if (state == AppLifecycleState.resumed) {
      // App returning from foreground - check if we need to lock
      _onResume();
    }
  }

  Future<void> _onBackground() async {
    // Don't enter standby while authenticating (biometric prompt causes inactive state)
    if (_isAuthenticating) return;
    // Don't enter standby if already locked (lock screen is visible)
    if (_isLocked) return;
    // Show privacy screen immediately to hide content in app switcher
    setState(() => _showPrivacyScreen = true);
    // Force immediate save of any pending changes before going to background
    widget.store.saveNow();
    await _sessionManager.enterStandby();
  }

  Future<void> _onResume() async {
    // Don't process resume while authenticating (biometric prompt dismissal causes resume)
    if (_isAuthenticating) return;
    // Don't process if already locked (lock screen is handling authentication)
    if (_isLocked) {
      setState(() => _showPrivacyScreen = false);
      return;
    }
    // Check if the delay timeout has expired and we need to lock
    final shouldLock = await _sessionManager.shouldLockOnResume();

    if (shouldLock && mounted) {
      // Delay has expired - trigger the lock which will show the auth challenge
      // _showPrivacyScreen is already true from _onBackground
      _sessionManager.lock();
    } else if (mounted) {
      // Within grace period - hide privacy screen to show content
      setState(() => _showPrivacyScreen = false);
    }

    // Randomize theme on resume if enabled
    if (widget.settings.randomizeColorOnResume) {
      widget.settings.setRandomTheme();
    }
  }

  @override
  void dispose() {
    widget.settings.removeListener(_onSettingsChanged);
    screenshotProtectionNotifier.removeListener(_onScreenshotProtectionChanged);
    WidgetsBinding.instance.removeObserver(this);
    // Dispose session manager to clean up any resources
    _sessionManager.dispose();
    // Force immediate save before disposing to ensure all changes are persisted
    widget.store.saveNow();
    super.dispose();
  }

  void _onUnlock() {
    setState(() {
      _isLocked = false;
      _isAuthenticating = false; // Reset auth flag now that we're unlocked
      _showPrivacyScreen = false; // Clear privacy screen after successful auth
    });
    // Tell session manager the user has authenticated successfully
    _sessionManager
        .unlock(); // Now returns Future, but we can await it without blocking UI
  }

  Future<void> _onOnboardingComplete(OnboardingData data) async {
    // Apply collected data to stores
    final store = widget.store;
    final settings = widget.settings;

    // Update account with onboarding data
    await store.updateAccount(
      accountId: store.currentAccount.id,
      name: data.accountName,
      iconCodePoint: data.iconCodePoint,
    );

    // Update starting balance via account settings
    await store.updateStartingBalance(data.startingBalance);

    // Update currency settings
    settings.currencySettings.currency = data.currency;

    // Populate demo data if enabled
    if (data.demoDataEnabled) {
      await store.populateDemoData();
    }

    // Mark onboarding as complete
    await widget.onboardingSettings.markComplete(
      demoDataEnabled: data.demoDataEnabled,
    );

    if (mounted) {
      setState(() => _showOnboarding = false);
    }
  }

  Future<void> _onOnboardingSkip() async {
    // Mark onboarding as complete without changes
    await widget.onboardingSettings.markComplete();

    if (mounted) {
      setState(() => _showOnboarding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const MaterialApp(
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    return AppSettingsScope(
      store: widget.settings,
      child: ExpenseStoreScope(
        store: widget.store,
        child: AnimatedBuilder(
          animation: widget.settings,
          builder: (context, _) {
            final preset = widget.settings.appThemePreset;
            final fontFamily = widget.settings.fontFamily;
            // Each theme is now fully immersive - no light/dark variants
            final theme = _buildTheme(preset, fontFamily);
            return MaterialApp(
              navigatorKey: _navigatorKey,
              debugShowCheckedModeBanner: false,
              title: 'Expense Stalker',
              builder: (context, child) {
                final mediaQuery = MediaQuery.of(context);
                final textScale = mediaQuery.textScaler.scale(1) *
                    widget.settings.textScaleFactor;

                final appContent = MediaQuery(
                  data: mediaQuery.copyWith(
                    textScaler: TextScaler.linear(textScale),
                  ),
                  child: child ?? const SizedBox.shrink(),
                );

                return Stack(
                  children: [
                    appContent,
                    // Overlay privacy screen if needed (only if not locked, as lock screen covers everything)
                    if (_showPrivacyScreen && !_isLocked)
                      const _PrivacyScreen(),
                    // Overlay onboarding wizard (between privacy and lock screen)
                    if (_showOnboarding && !_isLocked)
                      OnboardingWizard(
                        onComplete: _onOnboardingComplete,
                        onSkip: _onOnboardingSkip,
                      ),
                    // Overlay lock screen on top of everything
                    if (_isLocked)
                      LockScreen(
                        authService: _authService,
                        onUnlock: _onUnlock,
                        onAuthStateChanged: (isAuthenticating) {
                          _isAuthenticating = isAuthenticating;
                        },
                      ),
                  ],
                );
              },
              localizationsDelegates: const [
                AppLocalizations.delegate,
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              supportedLocales: const [
                Locale('en'),
                Locale('es'), // Spanish
                Locale('fr'), // French
                Locale('nl'), // Dutch
                Locale('de'), // German
                Locale('it'), // Italian
                Locale('pt'), // Portuguese
                Locale('ru'), // Russian
                Locale('zh'), // Chinese
                Locale('ja'), // Japanese
                Locale('ko'), // Korean
                Locale('ar'), // Arabic
                Locale('hi'), // Hindi
                Locale('tr'), // Turkish
                Locale('pl'), // Polish
                Locale('vi'), // Vietnamese
                Locale('id'), // Indonesian
                Locale('sv'), // Swedish
              ],
              // No themeMode - each theme IS its brightness
              theme: theme,
              home: const ErrorBoundary(child: HomeShell()),
            );
          },
        ),
      ),
    );
  }

  /// Builds a full ThemeData based on the selected AppThemePreset.
  /// Each theme is now fully immersive - the palette defines its own brightness.
  ThemeData _buildTheme(AppThemePreset preset, String? fontFamily) {
    final palette = ThemeSettings.getPalette(preset);
    final brightness = palette.brightness;
    final isDark = brightness == Brightness.dark;

    // Generate the base scheme from the seed, using palette's brightness
    var scheme = ColorScheme.fromSeed(
      seedColor: palette.primary,
      brightness: brightness,
    );

    // Override with the palette-defined immersive colors
    // Calculate onPrimary based on primary luminance for proper contrast
    final onPrimary =
        palette.primary.computeLuminance() > 0.5 ? Colors.black : Colors.white;
    // Mix primary color into surface containers for a branded feel
    final surfaceHigh = Color.lerp(
      palette.surfaceContainer,
      palette.primary,
      isDark ? 0.08 : 0.05,
    )!;
    final surfaceHighest = Color.lerp(
      palette.surfaceContainer,
      palette.primary,
      isDark ? 0.12 : 0.08,
    )!;

    scheme = scheme.copyWith(
      primary: palette.primary,
      onPrimary: onPrimary,
      surface: palette.surface,
      surfaceContainerHighest: surfaceHighest,
      surfaceContainerHigh: surfaceHigh,
      surfaceContainer: palette.surface,
      surfaceContainerLow: palette.background,
      surfaceContainerLowest: palette.background,
      // Stronger surface tint for elevation differentiation
      surfaceTint: palette.primary.withValues(alpha: isDark ? 0.12 : 0.08),
      // Explicitly set text/icon colors based on background luminance for maximum contrast.
      // This is critical for immersive themes where the seed-generated onSurface may be too dim.
      onSurface: isDark ? Colors.white : Colors.black,
      onSurfaceVariant: isDark
          ? Colors.white.withValues(alpha: 0.7)
          : Colors.black.withValues(alpha: 0.6),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: fontFamily,
      brightness: brightness,
      scaffoldBackgroundColor: palette.background,
      dividerTheme: DividerThemeData(
        color: isDark
            ? Colors.white.withValues(alpha: 0.2) // Increased from 0.1
            : Colors.black.withValues(alpha: 0.15), // Increased from 0.1
      ),
      // Use theme-aware surface tints for elevated components
      appBarTheme: AppBarTheme(
        surfaceTintColor: scheme.surfaceTint,
        backgroundColor: palette.surface,
      ),
      cardTheme: CardThemeData(
        surfaceTintColor: scheme.surfaceTint,
        color: palette.surface,
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: palette.surface,
        surfaceTintColor: scheme.surfaceTint,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(AppConstants.radiusSheetTop),
          ),
        ),
      ),
      dialogTheme: DialogThemeData(backgroundColor: palette.surface),
      // Style chips to match the theme
      chipTheme: ChipThemeData(
        backgroundColor: palette.surfaceContainer,
        selectedColor: scheme.secondaryContainer,
        labelStyle: TextStyle(color: scheme.onSurface),
        secondaryLabelStyle: TextStyle(color: scheme.onSurfaceVariant),
        side: BorderSide(color: scheme.outlineVariant),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: scheme.onSurface,
        contentTextStyle: TextStyle(color: scheme.surface),
        actionTextColor: scheme.inversePrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

/// Privacy screen shown when app goes to background to hide sensitive data.
/// Intentionally minimal - just shows the app icon, no text to confuse users.
class _PrivacyScreen extends StatelessWidget {
  const _PrivacyScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        child: Center(
          child: Icon(
            Icons.account_balance_wallet_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
          ),
        ),
      ),
    );
  }
}
