import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';

import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:intl/intl.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

class TimelineItemPicker extends StatefulWidget {
  const TimelineItemPicker({
    super.key,
    required this.month,
    required this.items,
    required this.existingPulses,
    this.currentLinkedItemId,
  });

  final DateTime month;
  final List<TimelineItem> items;
  final List<PulseEntry> existingPulses;
  final TimelineItemId? currentLinkedItemId;

  @override
  State<TimelineItemPicker> createState() => _TimelineItemPickerState();
}

class _TimelineItemPickerState extends State<TimelineItemPicker> {
  List<TimelineItem> _availableItems = [];
  Set<String> _takenItemIds = {};

  @override
  void initState() {
    super.initState();
    _processItems();
  }

  @override
  void didUpdateWidget(covariant TimelineItemPicker oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.month != widget.month ||
        oldWidget.items != widget.items ||
        oldWidget.existingPulses != widget.existingPulses ||
        oldWidget.currentLinkedItemId != widget.currentLinkedItemId) {
      _processItems();
    }
  }

  void _processItems() {
    setState(() {
      // 1. Identify items already taken by OTHER pulses in this month
      _takenItemIds = <String>{};
      for (final pulse in widget.existingPulses) {
        // Skip if it's the current pulse we are presumably editing (though we don't pass the pulse ID here,
        // the caller should pass \"existingPulses\" excluding the current one if they want to avoid self-collision,
        // OR we just check against currentLinkedItemId)
        if (pulse.timelineItemId != null) {
          // If this ID is currently linked to THIS pulse (via prop), don't mark as taken
          if (pulse.timelineItemId!.value == widget.currentLinkedItemId?.value) {
            continue;
          }
          _takenItemIds.add(pulse.timelineItemId!.value);
        }
      }

      // 2. Filter items that appear in this month
      _availableItems = widget.items.where((item) {
        return item.shouldAppearInMonth(widget.month);
      }).toList();

      // 3. Sort by day
      _availableItems.sort((a, b) => a.dayOfMonth.compareTo(b.dayOfMonth));
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_availableItems.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(32),
        alignment: Alignment.center,
        child: Text(
          'No scheduled items found for this month.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
          textAlign: TextAlign.center,
        ),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Link to Bill or Schedule',
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: _availableItems.length,
          separatorBuilder: (context, index) => const Divider(height: 1),
          itemBuilder: (context, index) {
            final item = _availableItems[index];
            final isTaken = _takenItemIds.contains(item.id.value);
            final isSelected =
                item.id.value == widget.currentLinkedItemId?.value;
            final settings = AppSettingsScope.read(context);

            return ListTile(
              title: Text(
                item.label,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  decoration: isTaken ? TextDecoration.lineThrough : null,
                  color: isTaken
                      ? Theme.of(
                          context,
                        ).colorScheme.onSurface.withValues(alpha: 0.5)
                      : null,
                ),
              ),
              subtitle: Text(
                DateFormat.MMMd().format(
                  DateTime(
                    widget.month.year,
                    widget.month.month,
                    item.dayOfMonth,
                  ),
                ),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    formatMoneyFromCents(
                      item.amountMinorUnits,
                      settings.currency,
                      showCents: settings.showCents,
                    ),
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFeatures: const [FontFeature.tabularFigures()],
                      color: isTaken
                          ? Theme.of(
                              context,
                            ).colorScheme.onSurface.withValues(alpha: 0.5)
                          : null,
                    ),
                  ),
                  if (isSelected)
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Icon(
                        Icons.check_circle,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    )
                  else if (isTaken)
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        'Linked',
                        style: TextStyle(
                          fontSize: 10,
                          color: Theme.of(context).colorScheme.error,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              onTap: isTaken
                  ? null
                  : () {
                      Navigator.pop(context, item.id);
                    },
              enabled: !isTaken,
            );
          },
        ),
      ],
    );
  }
}
