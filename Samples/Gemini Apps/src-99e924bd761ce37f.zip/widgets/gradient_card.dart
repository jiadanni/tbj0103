import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

/// A sleek gradient card widget with glassmorphic styling.
///
/// This widget provides a modern, dark gradient background with subtle
/// borders and shadows, replacing the standard Material Card for a more
/// distinctive look.
class GradientCard extends StatelessWidget {
  const GradientCard({
    super.key,
    required this.child,
    this.isPast = false,
    this.isCurrent = false,
    this.fullBleed = false,
    this.borderRadius = AppConstants.radiusXLarge,
    this.margin,
    this.padding,
  });

  final Widget child;

  /// Whether this card represents a past period (reduced opacity).
  final bool isPast;

  /// Whether this card represents the current period (highlighted border).
  final bool isCurrent;

  /// Whether the card should be full-bleed (edge-to-edge with no margins/radius).
  /// Used for the "Infinity Canvas" layout.
  final bool fullBleed;

  /// Corner radius for the card.
  final double borderRadius;

  /// Optional margin around the card.
  final EdgeInsetsGeometry? margin;

  /// Optional padding inside the card.
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final colorScheme = Theme.of(context).colorScheme;

    // Use theme-derived surface colors that will pick up theme tinting
    // This makes cards visually consistent with the selected theme
    final List<Color> gradientColors;
    if (isDark) {
      gradientColors = [
        colorScheme.surfaceContainerHigh,
        colorScheme.surfaceContainerLow,
      ];
    } else {
      // Full bleed: subtle gradient from slightly darker at top to white
      gradientColors = fullBleed
          ? [
              colorScheme.surfaceContainerLowest.withValues(alpha: 0.7),
              colorScheme.surface,
            ]
          : [
              colorScheme.surfaceContainerLowest,
              colorScheme.surfaceContainerLow,
            ];
    }

    // Full bleed mode: no border, no shadows, no radius
    final effectiveRadius = fullBleed ? 0.0 : borderRadius;

    // Use theme outline for border with subtle primary color influence
    // Highlight border for current period (but not in fullBleed mode)
    final Color? borderColor;
    final double borderWidth;
    if (fullBleed) {
      borderColor = null;
      borderWidth = 0.0;
    } else if (isCurrent) {
      borderColor = colorScheme.primary.withValues(alpha: 0.8);
      borderWidth = 2.0;
    } else {
      borderColor = isDark
          ? colorScheme.outlineVariant.withValues(alpha: 0.6)
          : colorScheme.outlineVariant.withValues(alpha: 0.5);
      borderWidth = 1.0;
    }

    // Use theme shadow color (but not in fullBleed mode)
    final shadowColor = isDark
        ? colorScheme.shadow.withValues(alpha: 0.4)
        : colorScheme.shadow.withValues(alpha: 0.1);

    Widget card = Container(
      margin: fullBleed ? EdgeInsets.zero : margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(effectiveRadius),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: gradientColors,
        ),
        border: borderColor != null
            ? Border.all(color: borderColor, width: borderWidth)
            : null,
        boxShadow: fullBleed
            ? null
            : [
                if (isCurrent)
                  BoxShadow(
                    color: colorScheme.primary.withValues(alpha: 0.15),
                    blurRadius: 20,
                    spreadRadius: 2,
                    offset: Offset.zero,
                  ),
                BoxShadow(
                  color: shadowColor.withValues(alpha: shadowColor.a * 0.5),
                  blurRadius: 12,
                  offset: const Offset(0, 8),
                ),
                BoxShadow(
                  color: shadowColor,
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(effectiveRadius),
        child:
            padding != null ? Padding(padding: padding!, child: child) : child,
      ),
    );

    // Reduce opacity for past periods
    if (isPast) {
      card = Opacity(opacity: AppConstants.opacityPast, child: card);
    }

    return card;
  }
}

/// A pill-shaped header widget for displaying date range and balance.
///
/// Used at the top of month cards to show the period label and starting
/// or ending balance in a sleek, rounded container.
class PillHeader extends StatelessWidget {
  const PillHeader({
    super.key,
    required this.label,
    this.badge,
    this.trailing,
    this.onTrailingTap,
    this.onLabelTap,
  });

  /// The main label text (e.g., "Dec 22 - Jan 21").
  final String label;

  /// Optional badge widget (e.g., "CURRENT" tag).
  final Widget? badge;

  /// Optional trailing widget or text (e.g., balance amount).
  final Widget? trailing;

  /// Optional callback when trailing is tapped.
  final VoidCallback? onTrailingTap;

  /// Optional callback when the label is tapped.
  final VoidCallback? onLabelTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final headerStyle = textTheme.titleMedium?.copyWith(
      fontWeight: FontWeight.w600,
      color: colorScheme.onSurface,
    );

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingNormal,
        vertical: AppConstants.paddingSmall,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingNormal,
        vertical: AppConstants.paddingSmall + 2, // 9
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
        color: colorScheme.surfaceContainer.withValues(
          alpha: 0.7,
        ), // Increased from 0.5
        border: Border.all(
          color: colorScheme.outlineVariant.withValues(
            alpha: 0.6,
          ), // Increased from 0.4
          width: 0.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: InkWell(
              onTap: onLabelTap,
              borderRadius: BorderRadius.circular(8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Text(
                      label,
                      style: headerStyle,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      softWrap: false,
                    ),
                  ),
                  if (badge != null) ...[const SizedBox(width: 8), badge!],
                ],
              ),
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            if (onTrailingTap != null)
              InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: onTrailingTap,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 2,
                    horizontal: 4,
                  ),
                  child: trailing,
                ),
              )
            else
              trailing!,
          ],
        ],
      ),
    );
  }
}

/// A styled footer widget for displaying summary information.
///
/// Used at the bottom of month cards to show credits, debits, and totals.
class GradientCardFooter extends StatelessWidget {
  const GradientCardFooter({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingNormal,
        AppConstants.paddingSmall,
        AppConstants.paddingNormal,
        AppConstants.paddingSmall,
      ),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        border: Border(
          top: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: 0.5),
          ),
        ),
      ),
      child: child,
    );
  }
}
