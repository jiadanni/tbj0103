import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

class SummaryCards extends StatelessWidget {
  const SummaryCards({
    super.key,
    required this.plannedCents,
    required this.paidCents,
    this.currency = AppCurrency.eur,
    this.showCents = true,
  });

  final int plannedCents;
  final int paidCents;
  final AppCurrency currency;
  final bool showCents;

  @override
  Widget build(BuildContext context) {
    final deltaCents = plannedCents - paidCents;

    return Row(
      children: [
        Expanded(
          child: _SummaryCard(
            label: AppLocalizations.of(context)!.plannedLabel,
            cents: plannedCents,
            currency: currency,
            showCents: showCents,
            color: plannedCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _SummaryCard(
            label: AppLocalizations.of(context)!.paidLabel,
            cents: paidCents,
            currency: currency,
            showCents: showCents,
            color: paidCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _SummaryCard(
            label: AppLocalizations.of(context)!.deltaLabel,
            cents: deltaCents,
            currency: currency,
            showCents: showCents,
            color: deltaCents < 0
                ? Theme.of(context).colorScheme.error
                : Theme.of(context).colorScheme.primary,
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.cents,
    required this.currency,
    required this.color,
    this.showCents = true,
  });

  final String label;
  final int cents;
  final AppCurrency currency;
  final Color color;
  final bool showCents;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppConstants.paddingNormal),
      decoration: BoxDecoration(
        color: Theme.of(
          context,
        ).colorScheme.surfaceContainerHigh.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        border: Border.all(
          color: Theme.of(
            context,
          ).colorScheme.outlineVariant.withValues(alpha: 0.4),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.2,
                ),
          ),
          const SizedBox(height: 6),
          Text(
            formatMoneyFromCents(cents, currency, showCents: showCents),
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w700,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }
}
