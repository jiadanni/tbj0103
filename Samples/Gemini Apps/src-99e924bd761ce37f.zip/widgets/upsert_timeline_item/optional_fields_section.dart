import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'upsert_timeline_item_style.dart';

class OptionalFieldsSection extends StatefulWidget {
  const OptionalFieldsSection({
    super.key,
    required this.categoryController,
    required this.categoryFocusNode,
    required this.categoryLayerLink,
    required this.selectedCategory,
    required this.originController,
    required this.isSalary,
    required this.notesController,
    required this.isIncomeMode,
    required this.type,
    required this.onCategorySelected,
    required this.onIsSalaryChanged,
    required this.selectedMoneyPotId,
    required this.onMoneyPotChanged,
    this.remainingBalanceController,
    this.balanceCurrency,
    this.onBalanceCurrencyChanged,

    // Updated params
    this.useActualsForCurrentBalance,
    required this.onUseActualsCurrentChanged,
    this.useActualsForFutureBalance,
    required this.onUseActualsFutureChanged,
    required this.buildCompactCheckbox,
    required this.suggestedOrigins,
    required this.onSuggestedOriginsChanged,
    this.quickAddAmounts,
    this.onEditQuickAmounts,
  });

  final TextEditingController categoryController;
  final FocusNode categoryFocusNode;
  final LayerLink categoryLayerLink;
  final String? selectedCategory;
  final TextEditingController originController;
  final bool isSalary;

  final TextEditingController notesController;
  final bool isIncomeMode;
  final PulseType type;
  final ValueChanged<String?> onCategorySelected;
  final ValueChanged<bool> onIsSalaryChanged;

  final MoneyPotId? selectedMoneyPotId;
  final ValueChanged<MoneyPotId?> onMoneyPotChanged;
  final TextEditingController? remainingBalanceController;
  final AppCurrency? balanceCurrency;
  final ValueChanged<AppCurrency?>? onBalanceCurrencyChanged;

  // New strategy fields
  final bool? useActualsForCurrentBalance;
  final ValueChanged<bool?> onUseActualsCurrentChanged;

  final bool? useActualsForFutureBalance;
  final ValueChanged<bool?> onUseActualsFutureChanged;

  final List<String> suggestedOrigins;
  final ValueChanged<List<String>> onSuggestedOriginsChanged;

  final List<int>? quickAddAmounts;
  final VoidCallback? onEditQuickAmounts;

  /// Callback to build the compact checkbox which depends on parent theme state
  final Widget Function({
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) buildCompactCheckbox;

  @override
  State<OptionalFieldsSection> createState() => _OptionalFieldsSectionState();
}

class _OptionalFieldsSectionState extends State<OptionalFieldsSection> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surfaceVariant = colorScheme.surfaceContainerLow;

    final settings = AppSettingsScope.of(context);

    return Container(
      decoration: BoxDecoration(
        color: surfaceVariant,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          // Header tap area
          InkWell(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.tune_outlined, size: 16, color: textSecondary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      l10n?.moreOptions ?? 'More options',
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.5 : 0,
                    duration: AppConstants.animationNormal,
                    child: Icon(
                      Icons.keyboard_arrow_down,
                      size: 18,
                      color: textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Expandable content
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Salary toggle - only for recurring income
                  if (widget.isIncomeMode &&
                      widget.type == PulseType.recurringIncome) ...[
                    const SizedBox(height: 8),
                    widget.buildCompactCheckbox(
                      value: widget.isSalary,
                      onChanged: (v) => widget.onIsSalaryChanged(v ?? false),
                      label: l10n?.primarySalary ?? 'Primary Salary',
                      subtitle: l10n?.primarySalaryHint ??
                          'Used to sync paycheck period settings',
                    ),
                  ],
                  const SizedBox(height: 8),

                  // Spending Envelope Options
                  if (widget.type == PulseType.spendingEnvelope) ...[
                    // Strategy for Current Month
                    _buildStrategyDropdown(
                      context: context,
                      label: 'Current Month Deduction',
                      value: widget.useActualsForCurrentBalance,
                      onChanged: widget.onUseActualsCurrentChanged,
                    ),
                    const SizedBox(height: 12),

                    // Strategy for Future Months
                    _buildStrategyDropdown(
                      context: context,
                      label: 'Future Month Deduction',
                      value: widget.useActualsForFutureBalance,
                      onChanged: widget.onUseActualsFutureChanged,
                    ),
                    const SizedBox(height: 12),

                    if (widget.onEditQuickAmounts != null) ...[
                      UpsertTimelineItemStyle.labeledField(
                        context: context,
                        label: 'Quick Spend Amounts',
                        child: InkWell(
                          onTap: widget.onEditQuickAmounts,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: colorScheme.outlineVariant,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    widget.quickAddAmounts != null
                                        ? widget.quickAddAmounts!
                                            .map(
                                              (a) =>
                                                  (a / 100).toStringAsFixed(0),
                                            )
                                            .join(', ')
                                        : 'Using Global Settings',
                                    style: TextStyle(
                                      color: widget.quickAddAmounts != null
                                          ? textPrimary
                                          : textSecondary,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                Icon(
                                  Icons.edit_outlined,
                                  size: 16,
                                  color: textSecondary,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ],

                  // Track in Money Pots (for recurring expenses)
                  if (!widget.isIncomeMode &&
                      widget.type == PulseType.recurring) ...[
                    // Toggle switch
                    SwitchListTile(
                      title: Text(
                        'Track in Money Pots',
                        style: TextStyle(
                          fontSize: 13,
                          color: textPrimary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        widget.selectedMoneyPotId != null
                            ? 'Automatic pot created with this name'
                            : 'Keeps a running balance of pulse',
                        style: TextStyle(fontSize: 11, color: textSecondary),
                      ),
                      value: widget.selectedMoneyPotId != null,
                      onChanged: (bool value) {
                        if (value) {
                          widget.onMoneyPotChanged(
                            const MoneyPotId('enable_smart_tracking'),
                          );
                        } else {
                          widget.onMoneyPotChanged(null);
                        }
                      },
                      contentPadding: EdgeInsets.zero,
                      visualDensity: VisualDensity.compact,
                    ),

                    if (widget.selectedMoneyPotId != null) ...[
                      const SizedBox(height: 6),
                      // Balance Field
                      if (widget.remainingBalanceController != null) ...[
                        UpsertTimelineItemStyle.labeledField(
                          context: context,
                          label: 'Pot Balance',
                          child: TextField(
                            controller: widget.remainingBalanceController,
                            style: TextStyle(color: textPrimary, fontSize: 14),
                            keyboardType: const TextInputType.numberWithOptions(
                              decimal: true,
                            ),
                            decoration: UpsertTimelineItemStyle.compactInput(
                              context,
                              'Current balance',
                              prefixText: currencySymbol(
                                widget.balanceCurrency ??
                                    settings.currencySettings.currency,
                              ),
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                    ],
                  ],

                  // Notes field with label
                  UpsertTimelineItemStyle.labeledField(
                    context: context,
                    label: 'Notes',
                    child: TextField(
                      controller: widget.notesController,
                      style: TextStyle(color: textPrimary, fontSize: 14),
                      decoration: UpsertTimelineItemStyle.compactInput(
                        context,
                        'Add notes (optional)',
                        floatingLabel: false,
                      ),
                      maxLength: AppConstants.maxNotesLength,
                      maxLines: 2,
                      textInputAction: TextInputAction.done,
                    ),
                  ),
                ],
              ),
            ),
            crossFadeState: _isExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: AppConstants.animationNormal,
          ),
        ],
      ),
    );
  }

  Widget _buildStrategyDropdown({
    required BuildContext context,
    required String label,
    required bool? value,
    required ValueChanged<bool?> onChanged,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;

    return UpsertTimelineItemStyle.labeledField(
      context: context,
      label: label,
      child: DropdownButtonFormField<bool?>(
        initialValue: value,
        decoration: UpsertTimelineItemStyle.compactInput(
          context,
          '',
          floatingLabel: false,
        ),
        style: TextStyle(color: textPrimary, fontSize: 13),
        dropdownColor: colorScheme.surfaceContainerHigh,
        icon: Icon(Icons.arrow_drop_down, color: colorScheme.onSurfaceVariant),
        items: const [
          DropdownMenuItem(value: null, child: Text('Use Global Default')),
          DropdownMenuItem(value: false, child: Text('Deduct Budgeted Amount')),
          DropdownMenuItem(value: true, child: Text('Deduct Actual Spending')),
        ],
        onChanged: onChanged,
      ),
    );
  }
}
