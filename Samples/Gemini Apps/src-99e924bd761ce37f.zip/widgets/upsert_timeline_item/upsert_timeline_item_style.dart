import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

/// Common styling and helper widgets for UpsertTimelineItem.
class UpsertTimelineItemStyle {
  const UpsertTimelineItemStyle._();

  static InputDecoration compactInput(
    BuildContext context,
    String label, {
    String? helperText,
    String? errorText,
    String? hintText,
    Widget? suffixIcon,
    TextStyle? helperStyle,
    Widget? prefix,
    String? prefixText,
    String? suffixText,
    bool floatingLabel = false, // Default to false for deflutter style
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant;

    return InputDecoration(
      labelText: label,
      hintText: hintText,
      labelStyle: TextStyle(color: textSecondary, fontSize: 13),
      hintStyle: TextStyle(
        color: textSecondary.withValues(alpha: 0.6),
        fontSize: 13,
      ),
      helperText: helperText,
      helperStyle: helperStyle ?? TextStyle(color: textSecondary, fontSize: 11),
      helperMaxLines: 1,
      errorText: errorText,
      errorStyle: const TextStyle(fontSize: 11),
      suffixIcon: suffixIcon,
      prefix: prefix,
      prefixText: prefixText,
      suffixText: suffixText,
      filled: true,
      fillColor: surface,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        borderSide: BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        borderSide: BorderSide(color: border.withValues(alpha: 0.8)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        borderSide: BorderSide(color: colorScheme.error),
      ),
      floatingLabelBehavior: FloatingLabelBehavior.never,
      counterText: '',
    );
  }

  static Widget buildCompactCheckbox({
    required BuildContext context,
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;

    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: Checkbox(
                value: value,
                onChanged: onChanged,
                visualDensity: VisualDensity.compact,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(color: textPrimary, fontSize: 13),
                  ),
                  if (subtitle.isNotEmpty)
                    Text(
                      subtitle,
                      style: TextStyle(color: textSecondary, fontSize: 11),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget labeledField({
    required BuildContext context,
    required String label,
    required Widget child,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    final textSecondary = colorScheme.onSurfaceVariant;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 6),
          child: Text(
            label,
            style: TextStyle(
              color: textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        child,
      ],
    );
  }
}
