import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

class HeroAmountDisplay extends StatelessWidget {
  const HeroAmountDisplay({
    super.key,
    required this.controller,
    required this.isIncomeMode,
    required this.accentIncome,
    required this.accentExpense,
    required this.currencySymbol,
    required this.showCents,
    required this.type,
  });

  final TextEditingController controller;
  final bool isIncomeMode;
  final Color accentIncome;
  final Color accentExpense;
  final String currencySymbol;
  final bool showCents;
  final PulseType type;

  String get _label {
    if (type == PulseType.debt) return 'Instalment *';
    return 'Amount *';
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final accentColor = isIncomeMode ? accentIncome : accentExpense;
    final sign = isIncomeMode ? '+' : '−';

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Subtle label
        Text(
          _label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 6),
        // Hero container
        Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHigh.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(AppConstants.radiusHero),
          ),
          child: TextField(
            controller: controller,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.w700,
              color: accentColor,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: EdgeInsets.zero,
              isDense: true,
              prefixText: '$sign $currencySymbol ',
              prefixStyle: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w300,
                color: accentColor.withValues(alpha: 0.6),
              ),
              hintText: showCents ? '0.00' : '0',
              hintStyle: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w300,
                color: colorScheme.onSurface.withValues(alpha: 0.2),
              ),
            ),
            keyboardType: TextInputType.numberWithOptions(
              signed: false,
              decimal: showCents,
            ),
            inputFormatters: [
              if (showCents)
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
              else
                FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(AppConstants.maxAmountLength),
            ],
            textInputAction: TextInputAction.next,
          ),
        ),
      ],
    );
  }
}
