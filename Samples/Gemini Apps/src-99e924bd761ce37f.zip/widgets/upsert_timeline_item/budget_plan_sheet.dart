import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart'; // For ViewPeriodMode

class BudgetPlanSheet extends StatefulWidget {
  const BudgetPlanSheet({
    super.key,
    required this.initialHistory,
    required this.baseAmountMinorUnits,
    required this.currency,
    required this.itemType,
    required this.startDate,
    this.timelineItemId,
    this.onChanged,
  });

  final List<TimelineItemValueChange>? initialHistory;
  final int baseAmountMinorUnits;
  final AppCurrency currency;
  final PulseType itemType;
  final DateTime startDate;
  final TimelineItemId? timelineItemId;
  final ValueChanged<List<TimelineItemValueChange>>? onChanged;

  @override
  State<BudgetPlanSheet> createState() => _BudgetPlanSheetState();
}

class _BudgetPlanSheetState extends State<BudgetPlanSheet> {
  late List<TimelineItemValueChange> _history;

  // We'll show historic months up to startDate + next 24 months
  static const int _monthsToPlanFuture = 24;

  late DateTime _listStartDate;
  late int _totalMonths;
  late ViewPeriodMode _viewMode;
  late int? _paycheckDay;

  // Cache for actual spending
  final Map<DateTime, int> _actualsCache = {};

  bool _initialized = false;

  late ScrollController _scrollController;
  // ignore: unused_field
  final bool _initialScrollPerformed = false;

  @override
  void initState() {
    super.initState();
    _history =
        widget.initialHistory != null ? List.from(widget.initialHistory!) : [];
    _sortHistory();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (!_initialized) {
      // Initialize settings
      final store = ExpenseStoreScope.read(
        context,
      ); // Read mostly static settings
      _viewMode = store.currentAccount.viewPeriodMode;
      _paycheckDay = store.currentAccount.paycheckDay;

      _initializeDateRange();
      _loadActuals();
      _initScrollController();
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _initScrollController() {
    // ... logic remains the same, just keeping the method definition clear if needed in context
    // Actually we just touched lines around here.
    final now = DateTime.now();
    // Re-calculate basic current period start just for finding "current" in list
    final currentPeriodInfo = PaycheckService.getPeriodInfo(
      now,
      _viewMode,
      _paycheckDay,
      businessAdjust: true,
    );
    final currentPeriodStart = currentPeriodInfo.start;

    // We can estimate it using month math on the reference months
    final listStartRefMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      _listStartDate,
      _paycheckDay ?? 1,
      businessAdjust: true,
    );
    final currentRefMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      currentPeriodStart,
      _paycheckDay ?? 1,
      businessAdjust: true,
    );

    final currentMonthIndex = month_math.monthsBetween(
      listStartRefMonth,
      currentRefMonth,
    );

    // Approx ListTile height with subtitle is ~72.
    // Plus we have 8px padding at top of list.
    final double itemHeight = 72.0;

    // We want the current month to be visible.
    // Ideally near the top, but not hidden under header if we used slivers (here it's just a column).
    // Let's set offset to show current item at top.
    final initialOffset = (currentMonthIndex * itemHeight);

    _scrollController = ScrollController(
      initialScrollOffset: initialOffset.clamp(0.0, double.infinity),
    );
  }

  void _initializeDateRange() {
    final now = DateTime.now();

    // Determine the "Current Period" start based on mode
    final currentPeriod = PaycheckService.getPeriodInfo(
      now,
      _viewMode,
      _paycheckDay,
      businessAdjust: true, // Default to true as per settings?
      // actually we should probably respect the setting for business adjust
      // let's assume true for now or read from settings if we can.
    );

    final currentPeriodStart = currentPeriod.start;

    // Determine Start Date for the list
    // We want to show history from the item's start date
    // But we need to align the item's start date to a Period Start

    // Find the period that CONTAINS the widget.startDate
    // If widget.startDate is in the middle of a period, we want that period's start.

    // To find the period start for an arbitrary date, we can use:
    // 1. Get reference month for that date
    // 2. Get period info for that reference month

    // Note: PaycheckService.getCurrentPaycheckPeriodMonth returns the "Reference Month" (ending month)
    final startRefMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      widget.startDate,
      _paycheckDay ?? 1,
      businessAdjust: true, // simplified
    );

    final startPeriod = PaycheckService.getPeriodInfo(
      startRefMonth,
      _viewMode,
      _paycheckDay,
      businessAdjust: true,
    );

    DateTime effectiveListStart = startPeriod.start;

    // If start date is future (after current period start), show from current period at least?
    if (effectiveListStart.isAfter(currentPeriodStart)) {
      _listStartDate = currentPeriodStart;
    } else {
      _listStartDate = effectiveListStart;
    }

    // Determine End Date (Current Period + 24 months)
    // We can just iterate 24 periods from current

    // Calculate total periods
    // We can approximate months between
    final monthsDiff = month_math.monthsBetween(
      _listStartDate,
      currentPeriodStart,
    );
    _totalMonths = monthsDiff + _monthsToPlanFuture + 1;
  }

  void _loadActuals() {
    if (widget.timelineItemId == null) return;

    final store = ExpenseStoreScope.read(context);
    // Filter pulses for this item
    final pulses = store.pulses.where(
      (p) => p.timelineItemId == widget.timelineItemId,
    );

    // Group by period
    for (final pulse in pulses) {
      // Find which period this pulse belongs to
      // We can use the pulse date to find the reference month
      final refMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
        pulse.date,
        _paycheckDay ?? 1,
        businessAdjust: true,
      );

      final period = PaycheckService.getPeriodInfo(
        refMonth,
        _viewMode,
        _paycheckDay,
        businessAdjust: true,
      );

      final periodStart = period.start;

      final currentSum = _actualsCache[periodStart] ?? 0;
      _actualsCache[periodStart] = currentSum + pulse.amountMinorUnits;
    }
  }

  void _sortHistory() {
    _history.sort((a, b) => a.effectiveDate.compareTo(b.effectiveDate));
  }

  int _getAmountForDate(DateTime date) {
    if (_history.isEmpty) {
      return widget.baseAmountMinorUnits;
    }

    // Find the latest change where effectiveDate <= date
    // Use dateOnly() to compare just the date part, ignoring time
    final dateNormalized = dateOnly(date);
    TimelineItemValueChange? latestChange;
    for (final change in _history) {
      final changeDate = dateOnly(change.effectiveDate);
      if (changeDate.isAtSameMomentAs(dateNormalized) ||
          changeDate.isBefore(dateNormalized)) {
        latestChange = change;
      } else {
        break; // History is sorted, so subsequent changes are in the future
      }
    }

    return latestChange?.amountMinorUnits ?? widget.baseAmountMinorUnits;
  }

  Future<void> _editMonthAmount(
    DateTime periodStart,
    DateTime periodEnd,
    String label,
  ) async {
    final currentAmount = _getAmountForDate(periodEnd);

    // Find next period start
    // If we rely on month math, we can just add 1 month to the Reference Month of this period
    // The periodStart might be adjusted, so adding 1 month to it directly is risky for finding next period?
    // Actually, PaycheckService logic uses month math on reference month.

    // Let's reverse eng: find ref month for this periodStart
    final refMonth = PaycheckService.getCurrentPaycheckPeriodMonth(
      periodStart, // safe to use start?
      // Wait, if period starts Dec 25, ref month is Jan.
      // If we ask for Dec 25, it returns Jan. Correct.
      _paycheckDay ?? 1,
      businessAdjust: true,
    );

    final nextRefMonth = month_math.addMonths(refMonth, 1);
    final nextPeriod = PaycheckService.getPeriodInfo(
      nextRefMonth,
      _viewMode,
      _paycheckDay,
      businessAdjust: true,
    );

    // We need to know what the amount WOULD be next month if we didn't intervene
    // This effectively captures the "revert" amount if we are creating a temporary change
    final projectedNextAmount = _getAmountForDate(nextPeriod.end);

    final newAmount = await _showAmountDialog(
      initialAmount: currentAmount,
      label: label,
    );
    if (newAmount == null) return;

    if (newAmount == currentAmount) return; // No change

    setState(() {
      // 1. Update/Add change for THIS period
      // Remove any existing exact match first
      _history.removeWhere(
        (c) => dateOnly(c.effectiveDate) == dateOnly(periodEnd),
      );

      _history.add(
        TimelineItemValueChange(
          effectiveDate: periodEnd,
          amountMinorUnits: newAmount,
        ),
      );

      // 2. Ensure NEXT month reverts/stays at what it should be
      // Check if there is already an explicit change for next month
      final hasExplicitNextChange = _history.any(
        (c) => dateOnly(c.effectiveDate) == dateOnly(nextPeriod.end),
      );

      if (!hasExplicitNextChange) {
        // If no explicit change for next month, we insert one to "lock in" the projected amount
        // effectively isolating the change we just made to the current month.
        _history.add(
          TimelineItemValueChange(
            effectiveDate: nextPeriod.end,
            amountMinorUnits: projectedNextAmount,
          ),
        );
      }

      _sortHistory();
      widget.onChanged?.call(_history);
    });
  }

  Future<int?> _showAmountDialog({
    required int initialAmount,
    required String label,
  }) async {
    final controller = TextEditingController(
      text: (initialAmount.abs() / 100).toStringAsFixed(2),
    );

    return showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Budget for $label'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          autofocus: true,
          decoration: InputDecoration(
            prefixText: getCurrencyInfo(widget.currency).symbol,
            hintText: '0.00',
            labelText: 'Amount',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final val = double.tryParse(controller.text);
              if (val != null) {
                final cents = (val * 100).round();
                // Envelopes are negative expenses usually
                final isExpense = !widget.itemType.isIncomeType;
                final signedCents = isExpense ? -cents.abs() : cents.abs();
                Navigator.pop(context, signedCents);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  String _formatAmount(int minorUnits) {
    return formatMoney(minorUnits, widget.currency);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Calculate current period start for highlighting in the list
    final now = DateTime.now();
    final currentPeriodInfo = PaycheckService.getPeriodInfo(
      now,
      _viewMode,
      _paycheckDay,
      businessAdjust: true,
    );
    final currentPeriodStart = currentPeriodInfo.start;

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      child: Column(
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _viewMode == ViewPeriodMode.paycheck
                            ? 'Budget Plan'
                            : 'Monthly Budget Plan',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _viewMode == ViewPeriodMode.paycheck
                            ? 'Tap a period to override the limit. Past periods act as report.'
                            : 'Tap a month to override the limit. Past months act as report.',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Budget List
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: _totalMonths,
              itemBuilder: (context, index) {
                // Calculate period for this index
                // We start from _listStartDate's reference month and add index
                final startRefMonth =
                    PaycheckService.getCurrentPaycheckPeriodMonth(
                  _listStartDate,
                  _paycheckDay ?? 1,
                  businessAdjust: true,
                );
                final loopRefMonth = month_math.addMonths(startRefMonth, index);

                final period = PaycheckService.getPeriodInfo(
                  loopRefMonth,
                  _viewMode,
                  _paycheckDay,
                  businessAdjust: true,
                );

                final periodStart = period.start;
                final periodEnd = period.end;

                final amount = _getAmountForDate(periodEnd);

                // Compare period start to current period start to determine status
                // (using dateOnly to be safe)
                final isPast = dateOnly(
                  periodStart,
                ).isBefore(dateOnly(currentPeriodStart));
                final isCurrent = dateOnly(
                  periodStart,
                ).isAtSameMomentAs(dateOnly(currentPeriodStart));

                // Get actuals for this period
                final actualSpending = _actualsCache[
                    periodStart]; // Can be null if no spend or future

                return ListTile(
                  onTap: () =>
                      _editMonthAmount(periodStart, periodEnd, period.label),
                  title: Text(
                    period
                        .label, // Use formatted label (e.g. "Dec 25 - Jan 24")
                    style: TextStyle(
                      fontWeight:
                          isCurrent ? FontWeight.bold : FontWeight.normal,
                      color: isPast ? theme.colorScheme.outline : null,
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // If past/current and we have actuals, show "Actual vs Limit"
                      if (actualSpending != null && (isPast || isCurrent)) ...[
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'Limit: ${_formatAmount(amount)}',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.outline,
                              ),
                            ),
                            Text(
                              'Actual: ${_formatAmount(actualSpending)}',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: (actualSpending.abs() > amount.abs())
                                    ? theme.colorScheme.error
                                    : theme.colorScheme
                                        .primary, // Red if over budget
                              ),
                            ),
                          ],
                        ),
                      ] else ...[
                        // Future or no data: just show limit
                        Text(
                          _formatAmount(amount),
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight:
                                isCurrent ? FontWeight.bold : FontWeight.normal,
                            color: isCurrent ? theme.colorScheme.primary : null,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],

                      const SizedBox(width: 8),
                      // ignore: deprecated_member_use
                      Icon(
                        Icons.edit,
                        size: 16,
                        color: theme.colorScheme.onSurfaceVariant.withValues(
                          alpha: 0.5,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(context, _history);
                },
                child: const Text('Done'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
