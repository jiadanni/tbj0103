import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';

class ValueHistorySheet extends StatefulWidget {
  const ValueHistorySheet({
    super.key,
    required this.initialHistory,
    required this.baseAmountMinorUnits,
    required this.isIncome,
    required this.currency,
    this.itemType,
  });

  final List<TimelineItemValueChange>? initialHistory;
  final int baseAmountMinorUnits;
  final bool isIncome;
  final AppCurrency currency;
  final PulseType? itemType;

  @override
  State<ValueHistorySheet> createState() => _ValueHistorySheetState();
}

class _ValueHistorySheetState extends State<ValueHistorySheet> {
  late List<TimelineItemValueChange> _history;

  @override
  void initState() {
    super.initState();
    _history =
        widget.initialHistory != null ? List.from(widget.initialHistory!) : [];
    _sortHistory();
  }

  void _sortHistory() {
    _history.sort((a, b) => a.effectiveDate.compareTo(b.effectiveDate));
  }

  Future<void> _addChange() async {
    final now = DateTime.now();
    final initialDate = DateTime(
      now.year,
      now.month + 1,
      1,
    ); // Default to next month

    // Pick Date
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (pickedDate == null) return;

    // Pick Amount
    if (!mounted) return;
    final amount = await _showAmountDialog();
    if (amount == null) return;

    setState(() {
      // Remove existing change on same date if any (compare date-only)
      _history.removeWhere(
        (c) => dateOnly(c.effectiveDate) == dateOnly(pickedDate),
      );

      _history.add(
        TimelineItemValueChange(
          effectiveDate: pickedDate,
          amountMinorUnits: amount,
        ),
      );
      _sortHistory();
    });
  }

  Future<int?> _showAmountDialog({int? initialAmount}) async {
    final controller = TextEditingController(
      text: initialAmount != null
          ? (initialAmount.abs() / 100).toStringAsFixed(2)
          : '',
    );

    return showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter Amount'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          autofocus: true,
          decoration: InputDecoration(
            prefixText: getCurrencyInfo(widget.currency).symbol,
            hintText: '0.00',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final val = double.tryParse(controller.text);
              if (val != null) {
                final cents = (val * 100).round();
                // Ensure correct sign based on income/expense
                // But typically we store positive for amountMinorUnits and type determines sign?
                // In TimelineItem construct, amount is signed.
                // Here we want to respect the item type.
                // If it's income, amount > 0. If expense, amount < 0.
                final signedCents =
                    widget.isIncome ? cents.abs() : -cents.abs();
                Navigator.pop(context, signedCents);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _editChange(TimelineItemValueChange change) async {
    final newAmount = await _showAmountDialog(
      initialAmount: change.amountMinorUnits,
    );
    if (newAmount != null) {
      setState(() {
        final index = _history.indexOf(change);
        if (index != -1) {
          _history[index] = TimelineItemValueChange(
            effectiveDate: change.effectiveDate,
            amountMinorUnits: newAmount,
          );
        }
      });
    }
  }

  void _deleteChange(TimelineItemValueChange change) {
    setState(() {
      _history.remove(change);
    });
  }

  String _formatAmount(int minorUnits) {
    return formatMoney(minorUnits, widget.currency);
  }

  String _formatDate(DateTime date) {
    return DateFormat.yMMMd().format(date);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      child: Column(
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Builder(
                    builder: (context) {
                      final isEnvelope =
                          widget.itemType == PulseType.spendingEnvelope;
                      return Text(
                        isEnvelope
                            ? 'Monthly Budget Plan'
                            : 'Scheduled Changes',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    },
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Builder(
                  builder: (context) {
                    final isEnvelope =
                        widget.itemType == PulseType.spendingEnvelope;
                    return Text(
                      isEnvelope
                          ? 'Adjust your budget for specific months (e.g., higher spending for holidays).'
                          : 'Changes to the amount will apply from the selected date onwards.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 16),

                // Base amount card (read only representation)
                Card(
                  elevation: 0,
                  color: theme.colorScheme.surfaceContainerLow,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: theme.colorScheme.outlineVariant),
                  ),
                  child: ListTile(
                    leading: const Icon(Icons.start),
                    title: Builder(
                      builder: (context) {
                        final isEnvelope =
                            widget.itemType == PulseType.spendingEnvelope;
                        return Text(
                          isEnvelope ? 'Base Budget' : 'Initial Amount',
                        );
                      },
                    ),
                    subtitle: Builder(
                      builder: (context) {
                        final isEnvelope =
                            widget.itemType == PulseType.spendingEnvelope;
                        return Text(
                          isEnvelope
                              ? 'Default for all months'
                              : 'Before any scheduled changes',
                        );
                      },
                    ),
                    trailing: Text(
                      _formatAmount(widget.baseAmountMinorUnits),
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),

                if (_history.isEmpty) ...[
                  const SizedBox(height: 32),
                  Center(
                    child: Builder(
                      builder: (context) {
                        final isEnvelope =
                            widget.itemType == PulseType.spendingEnvelope;
                        return Text(
                          isEnvelope
                              ? 'No budget variations yet'
                              : 'No scheduled changes yet',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                            fontStyle: FontStyle.italic,
                          ),
                        );
                      },
                    ),
                  ),
                ] else ...[
                  const SizedBox(height: 16),
                  Builder(
                    builder: (context) {
                      final t = Terminology.of(context);
                      final isEnvelope =
                          widget.itemType == PulseType.spendingEnvelope;
                      return Text(
                        isEnvelope
                            ? '${t.plannedLabel} Variations'
                            : t.historyLabel,
                        style: theme.textTheme.labelMedium?.copyWith(
                          color: theme.colorScheme.primary,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  ..._history.map((change) {
                    final isFuture = change.effectiveDate.isAfter(
                      DateTime.now(),
                    );

                    return Dismissible(
                      key: ValueKey(
                        '${change.effectiveDate}_${change.amountMinorUnits}',
                      ),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16),
                        color: theme.colorScheme.errorContainer,
                        child: Icon(
                          Icons.delete,
                          color: theme.colorScheme.onErrorContainer,
                        ),
                      ),
                      onDismissed: (_) => _deleteChange(change),
                      child: Card(
                        elevation: 0,
                        margin: const EdgeInsets.only(bottom: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color: isFuture
                                ? theme.colorScheme.primary.withValues(
                                    alpha: 0.5,
                                  )
                                : theme.colorScheme.outlineVariant,
                          ),
                        ),
                        child: ListTile(
                          onTap: () => _editChange(change),
                          leading: Icon(
                            isFuture ? Icons.upcoming : Icons.history,
                            color: isFuture ? theme.colorScheme.primary : null,
                          ),
                          title: Text(
                            _formatAmount(change.amountMinorUnits),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            'Effective: ${_formatDate(change.effectiveDate)}',
                          ),
                          trailing: const Icon(Icons.edit, size: 16),
                        ),
                      ),
                    );
                  }),
                ],
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _addChange,
                    icon: const Icon(Icons.add),
                    label: const Text('Add Change'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      Navigator.pop(context, _history);
                    },
                    child: const Text('Done'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
