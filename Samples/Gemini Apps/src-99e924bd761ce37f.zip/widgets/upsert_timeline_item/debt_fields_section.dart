import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/widgets/debt_pulse_calculator.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'upsert_timeline_item_style.dart';

const MoneyPotId _kNewMoneyPotId = MoneyPotId('new_money_pot');

class DebtFieldsSection extends StatelessWidget {
  const DebtFieldsSection({
    super.key,
    required this.remainingBalanceController,
    required this.balanceCurrency,
    required this.exchangeRateController,
    required this.settlementAmountController,
    required this.selectedMoneyPotId,
    required this.amountController,
    required this.dayController,
    required this.frequency,
    required this.startDate,
    required this.isEditMode,
    required this.isPaidOff,
    required this.onBalanceCurrencyChanged,
    required this.onMoneyPotChanged,
    required this.onIsPaidOffChanged,
    required this.buildCompactCheckbox,
    this.potCurrency,
    this.onPotCurrencyChanged,
    this.valueHistory,
  });

  final TextEditingController remainingBalanceController;
  final AppCurrency? balanceCurrency;
  final TextEditingController exchangeRateController;

  /// Controller for the app-currency settlement amount (auto-calculated from
  /// instalment × exchange rate). Only used when balanceCurrency != null.
  final TextEditingController settlementAmountController;

  final MoneyPotId? selectedMoneyPotId;
  final TextEditingController amountController;
  final TextEditingController dayController;
  final RecurrenceFrequency? frequency;
  final DateTime startDate;
  final bool isEditMode;
  final bool isPaidOff;
  final ValueChanged<AppCurrency?> onBalanceCurrencyChanged;
  final ValueChanged<MoneyPotId?> onMoneyPotChanged;
  final ValueChanged<bool> onIsPaidOffChanged;
  final Widget Function({
    required bool value,
    required ValueChanged<bool?> onChanged,
    required String label,
    required String subtitle,
  }) buildCompactCheckbox;

  /// The currency for the money pot (can differ from debt's balance currency).
  /// If null, defaults to debt's balance currency (or app currency if debt has no balance currency).
  final AppCurrency? potCurrency;

  /// Called when the user changes the pot currency selection.
  final ValueChanged<AppCurrency?>? onPotCurrencyChanged;

  /// Value history (configured payment amounts for specific months).
  final List<TimelineItemValueChange>? valueHistory;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.of(context);
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Foreign Currency Checkbox
        buildCompactCheckbox(
          value: balanceCurrency != null,
          onChanged: (value) {
            if (value == true && balanceCurrency == null) {
              // Enable foreign currency mode - set a default currency if none selected
              onBalanceCurrencyChanged(
                settings.currencySettings.enabledCurrencies.firstWhere(
                  (c) => c != settings.currency,
                  orElse: () => settings.currency,
                ),
              );
            } else if (value == false && balanceCurrency != null) {
              // Disable foreign currency mode - clear currency and exchange rate
              onBalanceCurrencyChanged(null);
              exchangeRateController.clear();
            }
          },
          label: 'Loan is in foreign currency',
          subtitle:
              'Enable to track debt in a different currency than your app currency',
        ),
        const SizedBox(height: 12),

        // Currency & Balance Row (shown if foreign currency is enabled)
        if (balanceCurrency != null) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildLabelWithInfo(
                      context,
                      'Loan Currency',
                      'The currency this debt is denominated in.',
                    ),
                    DropdownButtonFormField<AppCurrency?>(
                      initialValue: balanceCurrency,
                      decoration: UpsertTimelineItemStyle.compactInput(
                        context,
                        '',
                        floatingLabel: false,
                      ),
                      items: [
                        ...AppCurrency.values.where((c) {
                          return settings.currencySettings.enabledCurrencies
                                  .contains(c) ||
                              c == balanceCurrency;
                        }).map(
                          (c) => DropdownMenuItem<AppCurrency?>(
                            value: c,
                            child: Text(
                              currencySymbol(c),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                      onChanged: onBalanceCurrencyChanged,
                      style: TextStyle(color: textPrimary, fontSize: 13),
                      dropdownColor: surface,
                      isExpanded: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildLabelWithInfo(
                      context,
                      l10n?.remainingBalanceLabel ?? 'Remaining Balance',
                      l10n?.remainingBalanceHelper ??
                          'Total amount left to pay off',
                    ),
                    TextField(
                      controller: remainingBalanceController,
                      style: TextStyle(color: textPrimary, fontSize: 14),
                      decoration: UpsertTimelineItemStyle.compactInput(
                        context,
                        '0.00',
                        floatingLabel: false,
                      ),
                      keyboardType: const TextInputType.numberWithOptions(
                        signed: false,
                        decimal: true,
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*\.?\d{0,2}'),
                        ),
                        LengthLimitingTextInputFormatter(
                          AppConstants.maxBalanceLength,
                        ),
                      ],
                      textInputAction: TextInputAction.next,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Exchange Rate (only if loan is foreign)
          _buildLabelWithInfo(
            context,
            'Exchange Rate *',
            '1 ${currencySymbol(balanceCurrency!)} = ? ${currencySymbol(settings.currency)}',
          ),
          TextField(
            controller: exchangeRateController,
            style: TextStyle(color: textPrimary, fontSize: 14),
            decoration: UpsertTimelineItemStyle.compactInput(
              context,
              '1.08',
              floatingLabel: false,
            ).copyWith(
              prefixText: '1 ${currencySymbol(balanceCurrency!)} = ',
              prefixStyle: TextStyle(color: textSecondary, fontSize: 13),
              suffixText: currencySymbol(settings.currency),
              suffixStyle: TextStyle(color: textSecondary, fontSize: 13),
            ),
            keyboardType: const TextInputType.numberWithOptions(
              signed: false,
              decimal: true,
            ),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,4}')),
            ],
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),

          // Settlement amount (app currency equivalent, auto-calculated)
          _buildLabelWithInfo(
            context,
            'Settlement (${currencySymbol(settings.currency)})',
            'The equivalent amount in your app currency. Auto-calculated from instalment × rate.',
          ),
          TextField(
            controller: settlementAmountController,
            style: TextStyle(color: textPrimary, fontSize: 14),
            decoration: UpsertTimelineItemStyle.compactInput(
              context,
              '0.00',
              floatingLabel: false,
            ).copyWith(
              prefixText: '${currencySymbol(settings.currency)} ',
              prefixStyle: TextStyle(color: textSecondary, fontSize: 13),
              suffixIcon: Tooltip(
                message: 'Auto-calculated',
                child: Icon(
                  Icons.calculate_outlined,
                  size: 18,
                  color: textSecondary.withValues(alpha: 0.5),
                ),
              ),
            ),
            keyboardType: const TextInputType.numberWithOptions(
              signed: false,
              decimal: true,
            ),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),
        ] else ...[
          // Balance field only (for domestic debt)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildLabelWithInfo(
                context,
                l10n?.remainingBalanceLabel ?? 'Remaining Balance',
                l10n?.remainingBalanceHelper ?? 'Total amount left to pay off',
              ),
              TextField(
                controller: remainingBalanceController,
                style: TextStyle(color: textPrimary, fontSize: 14),
                decoration: UpsertTimelineItemStyle.compactInput(
                  context,
                  '0.00',
                  floatingLabel: false,
                ),
                keyboardType: const TextInputType.numberWithOptions(
                  signed: false,
                  decimal: true,
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
                  LengthLimitingTextInputFormatter(
                    AppConstants.maxBalanceLength,
                  ),
                ],
                textInputAction: TextInputAction.next,
              ),
            ],
          ),
          const SizedBox(height: 12),
        ],

        // Track in Money Pot Toggle
        SwitchListTile(
          title: Text(
            'Track in Money Pots',
            style: TextStyle(
              fontSize: 13,
              color: textPrimary,
              fontWeight: FontWeight.w500,
            ),
          ),
          value: selectedMoneyPotId != null,
          onChanged: (bool value) {
            if (value) {
              onMoneyPotChanged(_kNewMoneyPotId);
            } else {
              onMoneyPotChanged(null);
            }
          },
          contentPadding: EdgeInsets.zero,
          visualDensity: VisualDensity.compact,
        ),

        if (selectedMoneyPotId != null) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: surface.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: colorScheme.outlineVariant.withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Track Balance as:',
                  style: TextStyle(
                    color: textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildPotCurrencyOption(
                      context: context,
                      label: balanceCurrency != null
                          ? currencySymbol(balanceCurrency!)
                          : currencySymbol(settings.currency),
                      subtitle: balanceCurrency != null
                          ? 'Tracks exact loan units. Converts for Net Worth.'
                          : 'Tracks in app currency.',
                      isSelected: potCurrency ==
                              (balanceCurrency ?? settings.currency) ||
                          (potCurrency == null && balanceCurrency == null),
                      onTap: () => onPotCurrencyChanged?.call(balanceCurrency),
                    ),
                    const SizedBox(width: 8),
                    if (balanceCurrency != null) ...[
                      _buildPotCurrencyOption(
                        context: context,
                        label: currencySymbol(settings.currency),
                        subtitle:
                            'Converts loan balance to your local currency.',
                        isSelected: potCurrency == null ||
                            potCurrency == settings.currency,
                        onTap: () => onPotCurrencyChanged?.call(null),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  potCurrency != null && potCurrency != settings.currency
                      ? 'The money pot will hold ${currencySymbol(potCurrency!)}. We will convert it back to ${currencySymbol(settings.currency)} for your total Net Worth.'
                      : 'The balance will be converted to ${currencySymbol(settings.currency)} and tracked in your local currency.',
                  style: TextStyle(
                    color: textSecondary,
                    fontSize: 11,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        const SizedBox(height: 6),

        DebtPulseCalculator(
          remainingBalanceController: remainingBalanceController,
          // When FX is active, use the settlement amount (app currency)
          // for payoff estimation since that's what gets deducted from
          // the balance tracking.
          amountController: balanceCurrency != null
              ? settlementAmountController
              : amountController,
          dayOfMonthController: dayController,
          frequency: frequency,
          startDate: startDate,
          exchangeRate: balanceCurrency != null
              ? null // Already using converted settlement amount
              : double.tryParse(exchangeRateController.text),
          balanceCurrency: balanceCurrency,
          appCurrency: settings.currency,
          valueHistory: valueHistory,
        ),
        if (isEditMode) ...[
          const SizedBox(height: 4),
          buildCompactCheckbox(
            value: isPaidOff,
            onChanged: (v) => onIsPaidOffChanged(v ?? false),
            label: l10n?.markAsPaidOff ?? 'Mark as paid off',
            subtitle: l10n?.paidOffHelperText ??
                'Debt will no longer appear in future months',
          ),
        ],
      ],
    );
  }

  Widget _buildPotCurrencyOption({
    required BuildContext context,
    required String label,
    required String subtitle,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? colorScheme.primary.withValues(alpha: 0.1)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isSelected
                  ? colorScheme.primary
                  : colorScheme.outlineVariant.withValues(alpha: 0.5),
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              Text(
                label,
                style: TextStyle(
                  color:
                      isSelected ? colorScheme.primary : colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: isSelected
                      ? colorScheme.primary.withValues(alpha: 0.8)
                      : colorScheme.onSurfaceVariant,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabelWithInfo(
    BuildContext context,
    String label,
    String tooltip,
  ) {
    final colorScheme = Theme.of(context).colorScheme;
    final textSecondary = colorScheme.onSurfaceVariant;

    return Padding(
      padding: const EdgeInsets.only(left: 2, bottom: 6),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              color: textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 4),
          Tooltip(
            message: tooltip,
            triggerMode: TooltipTriggerMode.tap,
            showDuration: const Duration(seconds: 3),
            child: Icon(
              Icons.info_outline,
              size: 14,
              color: textSecondary.withValues(alpha: 0.7),
            ),
          ),
        ],
      ),
    );
  }
}
