// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/util/date_math.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/settings/settings_enums.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';

/// Result returned from [ScheduleModificationsSheet].
class ScheduleModificationsResult {
  const ScheduleModificationsResult({
    required this.valueHistory,
    required this.skippedDates,
    this.pausedDate,
    this.autoResumeDate,
  });

  final List<TimelineItemValueChange> valueHistory;
  final List<DateTime> skippedDates;
  final DateTime? pausedDate;
  final DateTime? autoResumeDate;
}

/// A sheet that shows upcoming periods with their scheduled amounts,
/// allowing users to toggle skips or set a pause range.
class ScheduleModificationsSheet extends StatefulWidget {
  const ScheduleModificationsSheet({
    super.key,
    required this.initialHistory,
    required this.baseAmountMinorUnits,
    required this.isIncome,
    required this.currency,
    this.itemType,
    this.initialSkippedDates,
    this.initialPausedDate,
    this.initialAutoResumeDate,
    this.startDate,
    this.viewPeriodMode = ViewPeriodMode.calendar,
    this.paycheckDay,
    this.isSalary = false,
  });

  final List<TimelineItemValueChange>? initialHistory;
  final int baseAmountMinorUnits;
  final bool isIncome;
  final AppCurrency currency;
  final PulseType? itemType;
  final List<DateTime>? initialSkippedDates;
  final DateTime? initialPausedDate;
  final DateTime? initialAutoResumeDate;
  final DateTime? startDate;
  final ViewPeriodMode viewPeriodMode;
  final int? paycheckDay;
  final bool isSalary;

  @override
  State<ScheduleModificationsSheet> createState() =>
      _ScheduleModificationsSheetState();
}

class _ScheduleModificationsSheetState
    extends State<ScheduleModificationsSheet> {
  late List<TimelineItemValueChange> _history;
  late Set<DateTime> _skippedPeriods; // Using Set for O(1) lookup
  DateTime? _pausedDate;
  DateTime? _autoResumeDate;

  // Number of periods to show in the list
  static const _periodsToShow = 12;

  @override
  void initState() {
    super.initState();
    _history =
        widget.initialHistory != null ? List.from(widget.initialHistory!) : [];
    _skippedPeriods = widget.initialSkippedDates != null
        ? widget.initialSkippedDates!.map(DateMath.toUtcMonth).toSet()
        : {};
    _pausedDate = widget.initialPausedDate;
    _autoResumeDate = widget.initialAutoResumeDate;
    _sortHistory();
  }

  void _sortHistory() {
    _history.sort((a, b) => a.effectiveDate.compareTo(b.effectiveDate));
  }

  bool get _isPaycheckMode => widget.viewPeriodMode == ViewPeriodMode.paycheck;
  String get _periodLabel => _isPaycheckMode ? 'period' : 'month';

  /// Gets the period info for a given reference month.
  PeriodInfo _getPeriodInfo(DateTime referenceMonth) {
    return PaycheckService.getPeriodInfo(
      referenceMonth,
      widget.viewPeriodMode,
      widget.paycheckDay,
    );
  }

  /// Checks if a period is skipped (either individually or via pause window).
  bool _isPeriodSkipped(DateTime period) {
    final normalized = DateMath.toUtcMonth(period);

    // Check individual skips
    if (_skippedPeriods.contains(normalized)) return true;

    // Check pause window
    if (_pausedDate != null) {
      final pauseStart = DateMath.toUtcMonth(_pausedDate!);
      if (!normalized.isBefore(pauseStart)) {
        if (_autoResumeDate != null) {
          final pauseEnd = DateMath.toUtcMonth(_autoResumeDate!);
          return normalized.isBefore(pauseEnd);
        }
        return true; // Paused indefinitely
      }
    }

    return false;
  }

  /// Gets the effective amount for a period (considering value history).
  int _getAmountForPeriod(DateTime period) {
    // In Paycheck mode, the effective date is the start of the period (e.g. Dec 25)
    // In Calendar mode, it's the 1st of the month.
    final effectivePeriodStart = _getPeriodInfo(period).start;

    // Find the most recent value change that's on or before this period start
    int amount = widget.baseAmountMinorUnits;
    for (final change in _history) {
      // Since history is sorted by date, we can iterate forward
      if (!change.effectiveDate.isAfter(effectivePeriodStart)) {
        amount = change.amountMinorUnits;
      } else {
        // Future changes don't affect this period
        break;
      }
    }
    return amount;
  }

  /// Toggles skip status for an individual period.
  void _togglePeriodSkip(DateTime period) {
    final normalized = DateMath.toUtcMonth(period);
    setState(() {
      if (_skippedPeriods.contains(normalized)) {
        _skippedPeriods.remove(normalized);
      } else {
        _skippedPeriods.add(normalized);
      }
    });
  }

  /// Shows dialog to set a pause range.
  Future<void> _showPauseRangeDialog() async {
    final periods = _generatePeriods(_periodsToShow);

    // Find current selections
    int? startIndex = _pausedDate != null
        ? periods.indexWhere(
            (p) => DateMath.toUtcMonth(
              p,
            ).isAtSameMomentAs(DateMath.toUtcMonth(_pausedDate!)),
          )
        : null;
    int? endIndex = _autoResumeDate != null
        ? periods.indexWhere(
            (p) => DateMath.toUtcMonth(
              p,
            ).isAtSameMomentAs(DateMath.toUtcMonth(_autoResumeDate!)),
          )
        : null;

    if (startIndex == -1) startIndex = null;
    if (endIndex == -1) endIndex = null;

    final result = await showModalBottomSheet<_PauseRangeResult>(
      context: context,
      isScrollControlled: true,
      builder: (context) => _PauseRangeSheet(
        periods: periods,
        getPeriodInfo: _getPeriodInfo,
        initialStartIndex: startIndex,
        initialEndIndex: endIndex,
        periodLabel: _periodLabel,
      ),
    );

    if (result == null) return;

    setState(() {
      if (result.cleared) {
        _pausedDate = null;
        _autoResumeDate = null;
      } else {
        _pausedDate = result.startPeriod;
        _autoResumeDate = result.endPeriod;
      }
    });
  }

  /// Generates a list of upcoming periods.
  List<DateTime> _generatePeriods(int count) {
    final now = DateTime.now();
    final periods = <DateTime>[];

    var current = _isPaycheckMode
        ? PaycheckService.getCurrentPaycheckPeriodMonth(
            now, widget.paycheckDay ?? 1)
        : DateMath.toUtcMonth(now);

    for (var i = 0; i < count; i++) {
      periods.add(current);
      current = DateTime.utc(current.year, current.month + 1, 1);
    }

    return periods;
  }

  void _clearAllSkips() {
    setState(() {
      _skippedPeriods.clear();
      _pausedDate = null;
      _autoResumeDate = null;
    });
  }

  String _formatAmount(int minorUnits) {
    return formatMoney(minorUnits, widget.currency);
  }

  Future<void> _editAmount(
    BuildContext context,
    DateTime period,
    int currentAmount,
  ) async {
    final info = _getPeriodInfo(period);
    final currencyInfo = getCurrencyInfo(widget.currency);

    final abs = currentAmount.abs();
    final major = abs ~/ currencyInfo.subunitRatio;
    final minor = abs % currencyInfo.subunitRatio;
    final textVal = currencyInfo.decimalDigits > 0
        ? '$major.${minor.toString().padLeft(currencyInfo.decimalDigits, '0')}'
        : major.toString();

    final amountController = TextEditingController(text: textVal);
    bool applyToFuture = true;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(
                'Edit Amount for ${info.label}',
                style: const TextStyle(fontSize: 18),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: amountController,
                    decoration: InputDecoration(
                      labelText: 'Amount',
                      prefixText: currencyInfo.symbol,
                      border: const OutlineInputBorder(),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Apply to:',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  RadioListTile<bool>(
                    title: Text('This $_periodLabel only'),
                    value: false,
                    groupValue: applyToFuture,
                    onChanged: (val) => setState(() => applyToFuture = val!),
                    contentPadding: EdgeInsets.zero,
                  ),
                  RadioListTile<bool>(
                    title: Text('This and future ${_periodLabel}s'),
                    value: true,
                    groupValue: applyToFuture,
                    onChanged: (val) => setState(() => applyToFuture = val!),
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true) {
      final newAmountStr = amountController.text;
      final parsedAmount = tryParseMoney(newAmountStr, widget.currency);
      if (parsedAmount == null) return;
      // Preserve the sign convention: expenses are negative, income is positive.
      // tryParseMoney always returns a positive value, so apply the correct sign.
      final newAmount = widget.isIncome ? parsedAmount : -parsedAmount;
      if (newAmount == currentAmount) return;

      setState(() {
        final effectiveDate = _getPeriodInfo(period).start;

        if (applyToFuture) {
          // Remove any existing changes on or after this date
          _history.removeWhere(
            (c) => !c.effectiveDate.isBefore(effectiveDate),
          );
          // Add the new change
          _history.add(
            TimelineItemValueChange(
              effectiveDate: effectiveDate,
              amountMinorUnits: newAmount,
            ),
          );
        } else {
          // Just this period
          _history.removeWhere(
            (c) => c.effectiveDate.isAtSameMomentAs(effectiveDate),
          );
          _history.add(
            TimelineItemValueChange(
              effectiveDate: effectiveDate,
              amountMinorUnits: newAmount,
            ),
          );

          // Restore amount for next period if no explicit change exists
          final nextPeriodRef = _isPaycheckMode
              ? DateTime.utc(period.year, period.month + 1, period.day)
              : DateTime.utc(period.year, period.month + 1, 1);
          final nextPeriodStart = _getPeriodInfo(nextPeriodRef).start;

          final existingNext = _history.any(
            (c) => c.effectiveDate.isAtSameMomentAs(nextPeriodStart),
          );
          if (!existingNext) {
            _history.add(
              TimelineItemValueChange(
                effectiveDate: nextPeriodStart,
                amountMinorUnits: currentAmount,
              ),
            );
          }
        }
        _sortHistory();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final now = DateTime.now();
    final periods = _generatePeriods(_periodsToShow);

    final hasAnySkips = _skippedPeriods.isNotEmpty || _pausedDate != null;

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      child: Column(
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.isSalary ? 'Paycheck Schedule' : 'Schedule',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Tap a $_periodLabel to skip it',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Periods list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: periods.length,
              itemBuilder: (context, index) {
                final period = periods[index];
                final info = _getPeriodInfo(period);
                final isSkipped = _isPeriodSkipped(period);
                final amount = _getAmountForPeriod(period);
                final isCurrentPeriod = info.containsDate(now);

                return ListTile(
                  onTap: () => _togglePeriodSkip(period),
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: isSkipped
                          ? theme.colorScheme.errorContainer.withValues(
                              alpha: 0.5,
                            )
                          : (isCurrentPeriod
                              ? theme.colorScheme.primaryContainer
                              : theme.colorScheme.surfaceContainerHighest),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      isSkipped
                          ? Icons.event_busy
                          : (isCurrentPeriod ? Icons.today : Icons.event),
                      color: isSkipped
                          ? theme.colorScheme.error
                          : (isCurrentPeriod
                              ? theme.colorScheme.primary
                              : theme.colorScheme.onSurfaceVariant),
                      size: 20,
                    ),
                  ),
                  title: Text(
                    info.label,
                    style: TextStyle(
                      fontWeight: isCurrentPeriod ? FontWeight.bold : null,
                      decoration: isSkipped ? TextDecoration.lineThrough : null,
                      color: isSkipped ? theme.colorScheme.outline : null,
                    ),
                  ),
                  subtitle: isCurrentPeriod
                      ? Text(
                          'Current $_periodLabel',
                          style: TextStyle(
                            color: theme.colorScheme.primary,
                            fontSize: 12,
                          ),
                        )
                      : null,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      InkWell(
                        onTap: () => _editAmount(context, period, amount),
                        borderRadius: BorderRadius.circular(4),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 2,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _formatAmount(amount),
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  decoration: isSkipped
                                      ? TextDecoration.lineThrough
                                      : null,
                                  color: isSkipped
                                      ? theme.colorScheme.outline
                                      : (widget.isIncome
                                          ? Colors.green.shade700
                                          : theme.colorScheme.error),
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.edit,
                                size: 14,
                                color: isSkipped
                                    ? theme.colorScheme.outline
                                    : theme.colorScheme.primary,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        isSkipped
                            ? Icons.check_box
                            : Icons.check_box_outline_blank,
                        color: isSkipped
                            ? theme.colorScheme.error
                            : theme.colorScheme.outline,
                        size: 20,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          const Divider(height: 1),

          // Footer actions
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Pause Range button
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _showPauseRangeDialog,
                        icon: Icon(
                          _pausedDate != null ? Icons.edit : Icons.pause,
                          size: 18,
                        ),
                        label: Text(
                          _pausedDate != null
                              ? 'Edit Pause Range'
                              : 'Pause Range...',
                        ),
                      ),
                    ),
                    if (hasAnySkips) ...[
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: _clearAllSkips,
                        icon: const Icon(Icons.clear_all),
                        tooltip: 'Clear all skips',
                        style: IconButton.styleFrom(
                          foregroundColor: theme.colorScheme.error,
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 12),
                // Done button
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      Navigator.pop(
                        context,
                        ScheduleModificationsResult(
                          valueHistory: _history,
                          skippedDates: _skippedPeriods.toList()..sort(),
                          pausedDate: _pausedDate,
                          autoResumeDate: _autoResumeDate,
                        ),
                      );
                    },
                    child: const Text('Done'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Result from pause range selection.
class _PauseRangeResult {
  const _PauseRangeResult({
    this.startPeriod,
    this.endPeriod,
    this.cleared = false,
  });

  final DateTime? startPeriod;
  final DateTime? endPeriod;
  final bool cleared;
}

/// Sheet for selecting a pause range.
class _PauseRangeSheet extends StatefulWidget {
  const _PauseRangeSheet({
    required this.periods,
    required this.getPeriodInfo,
    this.initialStartIndex,
    this.initialEndIndex,
    required this.periodLabel,
  });

  final List<DateTime> periods;
  final PeriodInfo Function(DateTime) getPeriodInfo;
  final int? initialStartIndex;
  final int? initialEndIndex;
  final String periodLabel;

  @override
  State<_PauseRangeSheet> createState() => _PauseRangeSheetState();
}

class _PauseRangeSheetState extends State<_PauseRangeSheet> {
  int? _startIndex;
  int? _endIndex;
  bool _indefinite = false;

  @override
  void initState() {
    super.initState();
    _startIndex = widget.initialStartIndex;
    _endIndex = widget.initialEndIndex;
    _indefinite =
        widget.initialStartIndex != null && widget.initialEndIndex == null;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.7,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Set Pause Range',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Instructions
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Select a start ${widget.periodLabel} and optionally an end ${widget.periodLabel}',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),

          // Period selectors
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _buildPeriodDropdown(
                    label: 'From',
                    value: _startIndex,
                    onChanged: (index) {
                      setState(() {
                        _startIndex = index;
                        // If end is before start, clear it
                        if (_endIndex != null &&
                            index != null &&
                            _endIndex! < index) {
                          _endIndex = null;
                        }
                      });
                    },
                  ),
                ),
                const SizedBox(width: 16),
                const Icon(Icons.arrow_forward),
                const SizedBox(width: 16),
                Expanded(
                  child: _indefinite
                      ? Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 16,
                          ),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: theme.colorScheme.outline,
                            ),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            'Indefinitely',
                            style: theme.textTheme.bodyLarge?.copyWith(
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        )
                      : _buildPeriodDropdown(
                          label: 'Until',
                          value: _endIndex,
                          minIndex: (_startIndex ?? 0) + 1,
                          onChanged: (index) {
                            setState(() {
                              _endIndex = index;
                            });
                          },
                        ),
                ),
              ],
            ),
          ),

          // Indefinite toggle
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: CheckboxListTile(
              value: _indefinite,
              onChanged: (value) {
                setState(() {
                  _indefinite = value ?? false;
                  if (_indefinite) {
                    _endIndex = null;
                  }
                });
              },
              title: const Text('Pause indefinitely'),
              subtitle: const Text('No automatic resume'),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
            ),
          ),

          const Spacer(),

          // Actions
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Clear button (only if there's a pause set)
                if (widget.initialStartIndex != null)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.pop(
                          context,
                          const _PauseRangeResult(cleared: true),
                        );
                      },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: theme.colorScheme.error,
                      ),
                      child: const Text('Clear Pause'),
                    ),
                  ),
                if (widget.initialStartIndex != null) const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: _startIndex != null
                        ? () {
                            Navigator.pop(
                              context,
                              _PauseRangeResult(
                                startPeriod: widget.periods[_startIndex!],
                                endPeriod: _indefinite || _endIndex == null
                                    ? null
                                    : widget.periods[_endIndex!],
                              ),
                            );
                          }
                        : null,
                    child: const Text('Set Pause'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodDropdown({
    required String label,
    required int? value,
    required ValueChanged<int?> onChanged,
    int minIndex = 0,
  }) {
    return DropdownButtonFormField<int>(
      initialValue: value != null && value >= minIndex ? value : null,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      isExpanded: true,
      items: [
        for (var i = minIndex; i < widget.periods.length; i++)
          DropdownMenuItem(
            value: i,
            child: Text(
              widget.getPeriodInfo(widget.periods[i]).label,
              overflow: TextOverflow.ellipsis,
            ),
          ),
      ],
      onChanged: onChanged,
    );
  }
}
