import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

class TimelineItemTypeSelector extends StatelessWidget {
  const TimelineItemTypeSelector({
    super.key,
    required this.type,
    required this.isIncomeMode,
    required this.onTypeChanged,
  });

  final PulseType type;
  final bool isIncomeMode;
  final ValueChanged<PulseType> onTypeChanged;

  @override
  Widget build(BuildContext context) {
    final subtypes = isIncomeMode
        ? [PulseType.recurringIncome, PulseType.oneOffIncome]
        : [
            PulseType.recurring,
            PulseType.oneOff,
            PulseType.debt,
            PulseType.spendingEnvelope,
          ];

    final colorScheme = Theme.of(context).colorScheme;
    final textSecondary = colorScheme.onSurfaceVariant;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 8),
          child: Text(
            'Type:',
            style: TextStyle(
              color: textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        LayoutBuilder(
          builder: (context, constraints) {
            final itemWidth = (constraints.maxWidth - 8) / 2;
            return Wrap(
              spacing: 8,
              runSpacing: 8,
              children: subtypes.map((t) {
                final isSelected = type == t;
                return SizedBox(
                  width: itemWidth,
                  child: ChoiceChip(
                    label: Center(
                      child: Text(
                        _getShortLabel(context, t),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                    ),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) onTypeChanged(t);
                    },
                    showCheckmark: false,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    labelPadding: EdgeInsets.zero,
                    visualDensity: VisualDensity.standard,
                    materialTapTargetSize: MaterialTapTargetSize.padded,
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }

  String _getShortLabel(BuildContext context, PulseType type) {
    final t = Terminology.of(context);
    switch (type) {
      case PulseType.recurring:
      case PulseType.recurringIncome:
        return t.recurringLabel;
      case PulseType.oneOff:
      case PulseType.oneOffIncome:
        return t.oneOffLabel;
      case PulseType.debt:
        return t.debtLabel;
      case PulseType.spendingEnvelope:
        return t.budgetLabel;
    }
  }
}

class IncomeExpenseToggle extends StatefulWidget {
  const IncomeExpenseToggle({
    super.key,
    required this.isIncomeMode,
    required this.accentIncome,
    required this.accentExpense,
    required this.onToggle,
  });

  final bool isIncomeMode;
  final Color accentIncome;
  final Color accentExpense;
  final ValueChanged<bool> onToggle;

  @override
  State<IncomeExpenseToggle> createState() => _IncomeExpenseToggleState();
}

class _IncomeExpenseToggleState extends State<IncomeExpenseToggle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<Alignment> _alignmentAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: AppConstants.animationNormal,
      vsync: this,
    );
    _alignmentAnimation = AlignmentTween(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic),
    );
    // Start at correct position if editing an income item
    if (widget.isIncomeMode) _controller.value = 1.0;
  }

  @override
  void didUpdateWidget(IncomeExpenseToggle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isIncomeMode != oldWidget.isIncomeMode) {
      widget.isIncomeMode ? _controller.forward() : _controller.reverse();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final expenseLabel = Terminology.of(context).expenseLabel;
    final incomeLabel = Terminology.of(context).incomeLabel;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
      ),
      padding: const EdgeInsets.all(2),
      child: IntrinsicHeight(
        child: IntrinsicWidth(
          child: Stack(
            children: [
              // Sliding pill background
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _alignmentAnimation,
                  builder: (context, child) {
                    final accentColor = widget.isIncomeMode
                        ? widget.accentIncome
                        : widget.accentExpense;
                    return Align(
                      alignment: _alignmentAnimation.value,
                      child: FractionallySizedBox(
                        widthFactor: 0.5,
                        heightFactor: 1.0,
                        child: Container(
                          decoration: BoxDecoration(
                            color: accentColor.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(
                              AppConstants.radiusSmall - 2,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              // Text labels (these define the Stack's size)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildLabel(
                    context,
                    expenseLabel,
                    !widget.isIncomeMode,
                    widget.accentExpense,
                    () => widget.onToggle(false),
                  ),
                  _buildLabel(
                    context,
                    incomeLabel,
                    widget.isIncomeMode,
                    widget.accentIncome,
                    () => widget.onToggle(true),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(
    BuildContext context,
    String label,
    bool isSelected,
    Color color,
    VoidCallback onTap,
  ) {
    final colorScheme = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: AnimatedDefaultTextStyle(
          duration: AppConstants.animationFast,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            color: isSelected ? color : colorScheme.onSurfaceVariant,
          ),
          child: Text(label),
        ),
      ),
    );
  }
}
