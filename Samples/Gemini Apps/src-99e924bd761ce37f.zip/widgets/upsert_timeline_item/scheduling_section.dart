import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';

class SchedulingSection extends StatelessWidget {
  final PulseType type;
  final DateTime startDate;
  final String? customDateLabel;
  final RecurrenceFrequency? frequency;
  final VoidCallback onPickStartDate;
  final ValueChanged<RecurrenceFrequency?> onFrequencyChanged;

  const SchedulingSection({
    super.key,
    required this.type,
    required this.startDate,
    this.customDateLabel,
    required this.frequency,
    required this.onPickStartDate,
    required this.onFrequencyChanged,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;
    final surface = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant;

    return UpsertTimelineItemStyle.labeledField(
      context: context,
      label: 'Schedule',
      child: Row(
        children: [
          // Date picker
          InkWell(
            onTap: onPickStartDate,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.calendar_today_outlined,
                    size: 14,
                    color: textSecondary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    customDateLabel ??
                        'Starting ${DateFormat.yMMM().format(startDate)}',
                    style: TextStyle(color: textPrimary, fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
          // Frequency dropdown (if applicable)
          if (type != PulseType.oneOff && type != PulseType.oneOffIncome) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: border),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<RecurrenceFrequency>(
                  value: frequency,
                  dropdownColor: surface,
                  isDense: true,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  icon: Icon(
                    Icons.keyboard_arrow_down,
                    size: 18,
                    color: textSecondary,
                  ),
                  items: RecurrenceFrequency.values
                      .map(
                        (freq) => DropdownMenuItem(
                          value: freq,
                          child: Text(freq.label),
                        ),
                      )
                      .toList(),
                  onChanged: onFrequencyChanged,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
