import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/pulse_source.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
import 'package:expense_stalker_mobile/src/widgets/timeline_item_picker.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

/// Bottom sheet for editing an existing pulse entry (the "Actual" record).
///
/// Allows modifying the actual amount, date, and notes.
/// Returns the updated [PulseEntry] on save, or null if cancelled.
class UpdatePulseSheet extends StatefulWidget {
  const UpdatePulseSheet({
    super.key,
    required this.pulse,
    this.title,
    this.showMoneyPotSelector = true,
    this.confirmButtonLabel,
    this.onDelete,
    this.debtItem,
  });

  final PulseEntry pulse;
  final String? title;

  /// Whether to show the money pot selector dropdown.
  /// Set to false for the Record Pulse flow (only debts should use money pots,
  /// and that should be configured in the Edit Pulse menu).
  final bool showMoneyPotSelector;
  final String? confirmButtonLabel;
  final VoidCallback? onDelete;

  /// Optional: The debt TimelineItem this payment is for.
  /// When provided, shows a conversion breakdown for foreign currency debts.
  final TimelineItem? debtItem;

  @override
  State<UpdatePulseSheet> createState() => _UpdatePulseSheetState();
}

class _UpdatePulseSheetState extends State<UpdatePulseSheet> {
  late final TextEditingController _amountController;
  late DateTime _date;
  MoneyPotId? _selectedMoneyPotId;
  TimelineItemId? _timelineItemId;
  String? _selectedCategory;
  bool _isFrozen = false;

  // FX Fields
  AppCurrency? _transactionCurrency;
  late final TextEditingController _settlementAmountController;
  late final TextEditingController _rateController;

  @override
  void initState() {
    super.initState();
    final pulse = widget.pulse;
    _selectedCategory = pulse.category;

    // Store absolute value
    _amountController = TextEditingController(
      text: (pulse.amountMinorUnits.abs() / 100).toStringAsFixed(2),
    );
    _date = pulse.date;
    _selectedMoneyPotId = pulse.moneyPotId;
    _timelineItemId = pulse.timelineItemId;

    // Determine if frozen (past period)
    final statsSettings = AppSettingsScope.read(context);
    final now = DateTime.now();
    final DateTime currentPeriodMonth =
        (statsSettings.viewPeriodMode == ViewPeriodMode.paycheck &&
                statsSettings.isPaycheckModeConfigured)
            ? PaycheckService.getCurrentPaycheckPeriodMonth(
                now,
                statsSettings.paycheckDay!,
                businessAdjust: statsSettings.paycheckBusinessAdjust,
                adjustDirection: statsSettings.paycheckBusinessAdjustDirection,
              )
            : monthOnly(now);

    final pulseMonth = monthOnly(pulse.date);
    // Frozen if past period OR if this is a bank import (bank statement is source of truth)
    _isFrozen =
        pulseMonth.isBefore(currentPeriodMonth) || pulse.source.isBankImport;

    _transactionCurrency = pulse.transactionCurrency;

    // Settlement Amount (always populated with database amount)
    _settlementAmountController = TextEditingController(
      text: (pulse.transactionCurrency != null)
          ? (pulse.amountMinorUnits.abs() / 100).toStringAsFixed(2)
          : '',
    );

    // Rate
    String initialRate = '';
    if (pulse.exchangeRate != null) {
      initialRate = pulse.exchangeRate!.toString();
    } else if (pulse.transactionCurrency != null &&
        pulse.transactionAmountMinorUnits != null &&
        pulse.transactionAmountMinorUnits != 0) {
      final rate = pulse.amountMinorUnits.abs() /
          pulse.transactionAmountMinorUnits!.abs();
      initialRate = rate.toStringAsFixed(4);
    }
    _rateController = TextEditingController(text: initialRate);

    // If FX, Amount Controller = Transaction Amount
    if (pulse.transactionCurrency != null &&
        pulse.transactionAmountMinorUnits != null) {
      _amountController.text =
          (pulse.transactionAmountMinorUnits!.abs() / 100).toStringAsFixed(2);
    }

    // For foreign-currency debt items where no transaction currency is set yet,
    // pre-populate the FX row using the debt's balance currency and exchange rate.
    // This ensures the settlement amount (e.g. €1,200) is shown immediately on open
    // rather than only appearing after the user taps into the field.
    if (_transactionCurrency == null &&
        widget.debtItem?.balanceCurrency != null &&
        widget.debtItem!.exchangeRate != null &&
        widget.debtItem!.exchangeRate! > 0) {
      _transactionCurrency = widget.debtItem!.balanceCurrency;
      _rateController.text = widget.debtItem!.exchangeRate!.toStringAsFixed(
        widget.debtItem!.exchangeRate! % 1 == 0 ? 0 : 1,
      );
      // Amount controller already holds the loan-currency amount (e.g. 1000).
      // Compute the settlement amount in app currency (e.g. 1000 × 1.2 = 1200).
      final loanAmount = double.tryParse(_amountController.text) ?? 0;
      final settlement = loanAmount * widget.debtItem!.exchangeRate!;
      _settlementAmountController.text = settlement.toStringAsFixed(2);
    }

    // Listeners
    _amountController.addListener(_onTransactionAmountChanged);
    _rateController.addListener(_onRateChanged);
  }

  @override
  void dispose() {
    _amountController.removeListener(_onTransactionAmountChanged);
    _rateController.removeListener(_onRateChanged);
    _amountController.dispose();
    _settlementAmountController.dispose();
    _rateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);
    final colorScheme = Theme.of(context).colorScheme;

    // Use theme colors for consistency with immersive themes
    final backgroundTop = colorScheme.surface;
    final backgroundBottom = colorScheme.surfaceContainerLow;
    final surface = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant.withValues(alpha: 0.5);
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;

    // Determines if income based on pulse type (not user toggleable here)
    final isIncome = widget.pulse.type.isIncomeType;
    final accentColor =
        isIncome ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    var categories = getCategorySuggestions(
      isIncome: isIncome,
      mode: settings.categoryPresetMode,
      userCategories: store.getUserCategories(isIncome: isIncome),
    );
    // Ensure the currently selected category is in the list, even if it's
    // a custom/legacy value not in presets. Without this, DropdownButtonFormField
    // throws an assertion error when initialValue doesn't match any item.
    if (_selectedCategory != null && !categories.contains(_selectedCategory)) {
      categories = [_selectedCategory!, ...categories];
    }

    InputDecoration compactInput(String label, {String? hintText}) {
      return InputDecoration(
        labelText: label,
        hintText: hintText,
        labelStyle: TextStyle(color: textSecondary, fontSize: 12),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        filled: true,
        fillColor: surface,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 12,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundTop, backgroundBottom],
        ),
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 12 + bottomInset),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header: Title + Delete button (if onDelete is provided)
                Row(
                  children: [
                    const SizedBox(
                      width: 40,
                    ), // Balance the delete icon for centering
                    Expanded(
                      child: Text(
                        widget.title ??
                            (isIncome
                                ? (l10n?.recordIncome ?? 'Record Income')
                                : (l10n?.recordExpense ?? 'Record Expense')),
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    if (widget.onDelete != null)
                      IconButton(
                        onPressed: _confirmDelete,
                        icon: Icon(
                          Icons.delete_outline,
                          color: colorScheme.error,
                          size: 20,
                        ),
                        tooltip: 'Delete',
                        visualDensity: VisualDensity.compact,
                      )
                    else
                      const SizedBox(width: 40),
                  ],
                ),
                // Compact header: Title + scheduled amount inline
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      child: Text(
                        widget.pulse.label,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: textPrimary,
                            ),
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (widget.pulse.scheduledAmountMinorUnits != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: surface,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          formatMoneyFromCents(
                            widget.pulse.scheduledAmountMinorUnits!,
                            settings.currency,
                            showCents: settings.showCents,
                          ),
                          style: TextStyle(
                            color: textSecondary,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                // Bank import indicator
                if (widget.pulse.source.isBankImport) ...[
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: colorScheme.tertiaryContainer.withValues(
                            alpha: 0.5,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.account_balance,
                              size: 12,
                              color: colorScheme.onTertiaryContainer,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Bank Import',
                              style: TextStyle(
                                color: colorScheme.onTertiaryContainer,
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 10),

                // Amount & Date Row - Amount includes currency suffix
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Amount Field with Currency Suffix
                      Expanded(
                        flex: 3,
                        child: Row(
                          children: [
                            // Amount input
                            Expanded(
                              child: TextField(
                                controller: _amountController,
                                readOnly: _isFrozen,
                                style: TextStyle(
                                  color:
                                      _isFrozen ? textSecondary : textPrimary,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                                decoration: compactInput('Amount').copyWith(
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 12,
                                  ),
                                  prefixIcon: Padding(
                                    padding: const EdgeInsets.only(
                                      left: 12,
                                      right: 4,
                                    ),
                                    child: Text(
                                      isIncome ? '+' : '−',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: _isFrozen
                                            ? accentColor.withValues(alpha: 0.5)
                                            : accentColor,
                                      ),
                                    ),
                                  ),
                                  prefixIconConstraints: const BoxConstraints(
                                    minWidth: 28,
                                    minHeight: 0,
                                  ),
                                  // Right border radius removed for seamless connection
                                  border: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.outlineVariant
                                          .withValues(alpha: 0.5),
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.outlineVariant
                                          .withValues(alpha: 0.5),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomLeft: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.primary,
                                      width: 1.5,
                                    ),
                                  ),
                                ),
                                keyboardType: TextInputType.numberWithOptions(
                                  signed: false,
                                  decimal: settings.showCents,
                                ),
                                inputFormatters: [
                                  if (settings.showCents)
                                    FilteringTextInputFormatter.allow(
                                      RegExp(r'^\d*\.?\d{0,2}'),
                                    )
                                  else
                                    FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(
                                    AppConstants.maxAmountLength,
                                  ),
                                ],
                                textInputAction: TextInputAction.next,
                              ),
                            ),
                            // Currency Selector - attached to amount field
                            SizedBox(
                              width: 58,
                              child: DropdownButtonFormField<AppCurrency?>(
                                initialValue: _transactionCurrency,
                                decoration:
                                    compactInput('', hintText: '').copyWith(
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 4,
                                    vertical: 12,
                                  ),
                                  enabled: !_isFrozen,
                                  // Left border radius removed for seamless connection
                                  border: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.outlineVariant
                                          .withValues(alpha: 0.5),
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.outlineVariant
                                          .withValues(alpha: 0.5),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.only(
                                      topRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                      bottomRight: Radius.circular(
                                        AppConstants.radiusMedium,
                                      ),
                                    ),
                                    borderSide: BorderSide(
                                      color: colorScheme.primary,
                                      width: 1.5,
                                    ),
                                  ),
                                ),
                                icon: Icon(
                                  Icons.arrow_drop_down,
                                  size: 18,
                                  color: _isFrozen ? Colors.transparent : null,
                                ),
                                isExpanded: true,
                                items: [
                                  DropdownMenuItem<AppCurrency?>(
                                    value: null,
                                    child: Text(
                                      currencySymbol(settings.currency),
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: _isFrozen
                                            ? textSecondary
                                            : textPrimary,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  ...AppCurrency.values
                                      .where(
                                        (c) =>
                                            // Include enabled currencies + the currently selected
                                            // transaction currency (may have been disabled since)
                                            (settings.currencySettings
                                                    .enabledCurrencies
                                                    .contains(c) ||
                                                c == _transactionCurrency) &&
                                            c != settings.currency,
                                      )
                                      .map(
                                        (c) => DropdownMenuItem<AppCurrency?>(
                                          value: c,
                                          child: Text(
                                            currencySymbol(c),
                                            style: TextStyle(
                                              fontSize: 13,
                                              color: _isFrozen
                                                  ? textSecondary
                                                  : textPrimary,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ),
                                ],
                                onChanged: _isFrozen
                                    ? null
                                    : _handleTransactionCurrencyChanged,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Date Picker - always interactive unless explicitly frozen
                      Expanded(
                        flex: 2,
                        child: InkWell(
                          onTap: _pickDate,
                          borderRadius: BorderRadius.circular(
                            AppConstants.radiusMedium,
                          ),
                          child: InputDecorator(
                            decoration: compactInput('Date').copyWith(
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 12,
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.calendar_today,
                                  size: 16,
                                  color: textSecondary,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    DateFormat.MMMd().format(_date),
                                    style: TextStyle(
                                      color: textPrimary,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Secondary FX Row
                if (_transactionCurrency != null) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: TextField(
                          controller: _settlementAmountController,
                          readOnly: _isFrozen,
                          style: TextStyle(
                            color: _isFrozen ? textSecondary : textPrimary,
                            fontSize: 13,
                          ),
                          decoration: compactInput(
                            'Settlement (${currencySymbol(settings.currency)})',
                          ),
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 1,
                        child: TextField(
                          controller: _rateController,
                          readOnly: _isFrozen,
                          style: TextStyle(
                            color: _isFrozen ? textSecondary : textPrimary,
                            fontSize: 13,
                          ),
                          decoration: compactInput('Rate', hintText: '1.0'),
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                      ),
                    ],
                  ),
                ],

                const SizedBox(height: 12),

                // Category Dropdown
                DropdownButtonFormField<String?>(
                  initialValue: _selectedCategory,
                  decoration: compactInput('Category'),
                  items: [
                    const DropdownMenuItem<String?>(
                      value: null,
                      child: Text('Uncategorized'),
                    ),
                    ...categories.map(
                      (cat) => DropdownMenuItem<String?>(
                        value: cat,
                        child: Text(cat),
                      ),
                    ),
                  ],
                  onChanged: _isFrozen
                      ? null
                      : (value) => setState(() => _selectedCategory = value),
                  style: TextStyle(
                    color: _isFrozen ? textSecondary : textPrimary,
                    fontSize: 13,
                  ),
                  dropdownColor: surface,
                  icon: Icon(
                    Icons.arrow_drop_down,
                    color: _isFrozen ? Colors.transparent : null,
                  ),
                ),

                const SizedBox(height: 8),

                // Track in Money Pot - inline chip style (only shown in Edit Pulse flow, not Record Pulse)
                // Only show for recurring expenses/debts, not one-off transactions
                if (widget.showMoneyPotSelector &&
                    !widget.pulse.type.isIncomeType &&
                    widget.pulse.type != PulseType.oneOff &&
                    settings.moneyPots.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.savings_outlined,
                        size: 14,
                        color: textSecondary,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Pot:',
                        style: TextStyle(color: textSecondary, fontSize: 12),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: SizedBox(
                          height: 32,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              _buildPotChip(
                                null,
                                'None',
                                textPrimary,
                                textSecondary,
                                surface,
                                colorScheme,
                              ),
                              ...settings.moneyPots.map(
                                (pot) => _buildPotChip(
                                  pot.id,
                                  pot.name,
                                  textPrimary,
                                  textSecondary,
                                  surface,
                                  colorScheme,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],

                // Debt Conversion Breakdown - Show when paying a debt with foreign balance currency
                if (widget.debtItem != null &&
                    widget.debtItem!.type == PulseType.debt &&
                    widget.debtItem!.balanceCurrency != null) ...[
                  _buildDebtConversionBreakdown(
                    settings,
                    textSecondary,
                    surface,
                  ),
                  const SizedBox(height: 8),
                ],

                const SizedBox(height: 12),

                // Link to Schedule Section
                _buildLinkToScheduleSection(
                  context,
                  settings,
                  surface,
                  textPrimary,
                  textSecondary,
                ),

                const SizedBox(height: 12),

                // Save Button - more compact
                FilledButton(
                  onPressed: _handleSave,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusButton,
                      ),
                    ),
                  ),
                  child: Text(
                    widget.confirmButtonLabel ?? (l10n?.save ?? 'Save'),
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleTransactionCurrencyChanged(AppCurrency? currency) {
    setState(() {
      _transactionCurrency = currency;
      if (currency != null) {
        if (_rateController.text.isEmpty) {
          _rateController.text = '1.0';
        }
        _updateSettlementCalculation();
      }
    });
  }

  void _onTransactionAmountChanged() {
    if (_transactionCurrency != null) {
      _updateSettlementCalculation();
    }
  }

  void _onRateChanged() {
    if (_transactionCurrency != null) {
      _updateSettlementCalculation();
    }
  }

  void _updateSettlementCalculation() {
    final transAmount = double.tryParse(_amountController.text) ?? 0;
    final rate = double.tryParse(_rateController.text) ?? 0;
    if (rate > 0) {
      final settlement = transAmount * rate;
      final currentSettlement =
          double.tryParse(_settlementAmountController.text) ?? 0;
      if ((settlement - currentSettlement).abs() > 0.005) {
        _settlementAmountController.text = settlement.toStringAsFixed(2);
      }
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(
        () => _date = DateTime(
          picked.year,
          picked.month,
          picked.day,
          _date.hour,
          _date.minute,
          _date.second,
          _date.millisecond,
          _date.microsecond,
        ),
      );
    }
  }

  Future<void> _confirmDelete() async {
    final isBankImport = widget.pulse.source.isBankImport;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Transaction?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Are you sure you want to remove this transaction? This cannot be undone.',
            ),
            if (isBankImport) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Theme.of(
                    context,
                  ).colorScheme.errorContainer.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.warning_amber_rounded,
                      color: Theme.of(context).colorScheme.error,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'This is a bank import. Re-importing the same statement may recreate it.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Theme.of(context).colorScheme.onErrorContainer,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(AppLocalizations.of(context)?.cancel ?? 'Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: Text(AppLocalizations.of(context)?.delete ?? 'Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      widget.onDelete?.call();
      Navigator.pop(context); // Close the sheet
    }
  }

  Widget _buildPotChip(
    MoneyPotId? potId,
    String label,
    Color textPrimary,
    Color textSecondary,
    Color surface,
    ColorScheme colorScheme,
  ) {
    final isSelected = _selectedMoneyPotId == potId;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: ChoiceChip(
        label: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: isSelected ? colorScheme.onPrimary : textSecondary,
          ),
        ),
        selected: isSelected,
        onSelected: _isFrozen
            ? null
            : (_) => setState(() => _selectedMoneyPotId = potId),
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        labelPadding: const EdgeInsets.symmetric(horizontal: 2),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        backgroundColor: surface,
        selectedColor: colorScheme.primary,
        side: BorderSide(
          color: isSelected
              ? colorScheme.primary
              : colorScheme.outlineVariant.withValues(alpha: 0.3),
        ),
      ),
    );
  }

  /// Builds a conversion breakdown showing how the payment converts to the debt's currency.
  ///
  /// Example: "$100 USD → €92 EUR → £78.20 GBP applied to debt"
  Widget _buildDebtConversionBreakdown(
    AppSettingsStore settings,
    Color textSecondary,
    Color surface,
  ) {
    final debtItem = widget.debtItem;
    if (debtItem == null) return const SizedBox.shrink();
    final debtCurrency = debtItem.balanceCurrency;
    if (debtCurrency == null) return const SizedBox.shrink();
    final debtRate = debtItem.exchangeRate ?? 1.0;

    // Calculate the amounts at each step
    double paymentAmount;
    String paymentCurrencySymbol;
    double settlementAmount;

    if (_transactionCurrency != null) {
      // Payment is in a foreign currency
      paymentAmount = double.tryParse(_amountController.text) ?? 0;
      paymentCurrencySymbol = currencySymbol(_transactionCurrency!);
      settlementAmount = double.tryParse(_settlementAmountController.text) ?? 0;
    } else {
      // Payment is in app currency
      paymentAmount = double.tryParse(_amountController.text) ?? 0;
      paymentCurrencySymbol = currencySymbol(settings.currency);
      settlementAmount = paymentAmount;
    }

    // Calculate how much will be applied to the debt balance
    double debtBalanceReduction;

    // Check if payment is directly in debt currency (no double conversion)
    if (_transactionCurrency == debtCurrency) {
      debtBalanceReduction = paymentAmount;
    } else {
      // Convert settlement (app currency) to debt currency
      debtBalanceReduction = settlementAmount / debtRate;
    }

    final appCurrencySymbol = currencySymbol(settings.currency);
    final debtCurrencySymbol = currencySymbol(debtCurrency);

    // Build the conversion string
    String conversionText;
    if (_transactionCurrency == debtCurrency) {
      // Direct payment in debt currency
      conversionText =
          '$paymentCurrencySymbol${paymentAmount.toStringAsFixed(2)} applied directly to debt';
    } else if (_transactionCurrency != null) {
      // Three-currency conversion: Transaction → App → Debt
      conversionText =
          '$paymentCurrencySymbol${paymentAmount.toStringAsFixed(2)} → '
          '$appCurrencySymbol${settlementAmount.toStringAsFixed(2)} → '
          '$debtCurrencySymbol${debtBalanceReduction.toStringAsFixed(2)} applied to debt';
    } else {
      // Two-currency conversion: App → Debt
      conversionText =
          '$appCurrencySymbol${settlementAmount.toStringAsFixed(2)} → '
          '$debtCurrencySymbol${debtBalanceReduction.toStringAsFixed(2)} applied to debt';
    }

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(
            context,
          ).colorScheme.outlineVariant.withValues(alpha: 0.5),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.currency_exchange,
            size: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              conversionText,
              style: TextStyle(
                color: textSecondary,
                fontSize: 12,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleSave() {
    // If FX:
    //   Transaction = _amountController
    //   Settlement = _settlementAmountController
    // If Default:
    //   Transaction = null
    //   Settlement = _amountController

    double? rawTransactionAmt;
    double? rawSettlementAmt;

    if (_transactionCurrency != null) {
      rawTransactionAmt = double.tryParse(_amountController.text);
      rawSettlementAmt = double.tryParse(_settlementAmountController.text);
    } else {
      rawTransactionAmt = null;
      rawSettlementAmt = double.tryParse(_amountController.text);
    }

    if (rawSettlementAmt == null) return;
    final rawAmountCents = (rawSettlementAmt * 100).round();

    // Apply rounding to Settlement
    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    // Apply Sign
    final signedAmountCents =
        widget.pulse.type.isIncomeType ? finalAmountCents : -finalAmountCents;

    // Transaction Amount Handling
    int? transactionAmountCents;
    if (rawTransactionAmt != null) {
      transactionAmountCents = (rawTransactionAmt * 100).round();
      transactionAmountCents = widget.pulse.type.isIncomeType
          ? transactionAmountCents
          : -transactionAmountCents;
    }

    final updated = widget.pulse.copyWith(
      amountMinorUnits: signedAmountCents,
      date: _date,
      category: _selectedCategory,
      moneyPotId: _selectedMoneyPotId,
      timelineItemId: _timelineItemId,
      transactionCurrency: _transactionCurrency,
      transactionAmountMinorUnits: transactionAmountCents,
      exchangeRate: _transactionCurrency == null
          ? null
          : double.tryParse(_rateController.text),
    );

    Navigator.pop(context, updated);
  }

  Widget _buildLinkToScheduleSection(
    BuildContext context,
    AppSettingsStore settings,
    Color surface,
    Color textPrimary,
    Color textSecondary,
  ) {
    // Only show for bank-imported transactions — regular scheduled items
    // already have an explicit timelineItemId set when marked as paid.
    if (!widget.pulse.source.isBankImport) return const SizedBox.shrink();

    // Don't show for spending envelopes or pure transfers usually, but user might want to link transfer to a bill
    // Restrict to core types if needed, but for now allow all

    final store = ExpenseStoreScope.read(context);
    String? linkedItemLabel;

    if (_timelineItemId != null) {
      final item = store.activeTimelineItems
          .where((i) => i.id == _timelineItemId)
          .firstOrNull;
      linkedItemLabel = item?.label;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        border: Border.all(
          color: Theme.of(
            context,
          ).colorScheme.outlineVariant.withValues(alpha: 0.5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Link to Bill / Schedule',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          if (_timelineItemId != null) ...[
            Row(
              children: [
                Icon(
                  Icons.link,
                  size: 16,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        linkedItemLabel ?? 'Unknown Item',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: textPrimary,
                        ),
                      ),
                      Text(
                        'Linked',
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _timelineItemId = null;
                    });
                  },
                  icon: Icon(Icons.close, size: 18, color: textSecondary),
                  tooltip: 'Unlink',
                ),
              ],
            ),
          ] else ...[
            InkWell(
              onTap: _handleLinkToSchedule,
              borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Icon(Icons.add_link, size: 18, color: textSecondary),
                    const SizedBox(width: 8),
                    Text(
                      'Select scheduled item...',
                      style: TextStyle(
                        fontStyle: FontStyle.italic,
                        color: textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _handleLinkToSchedule() async {
    final store = ExpenseStoreScope.read(context);
    final result = await showModalBottomSheet<TimelineItemId>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => TimelineItemPicker(
        month: monthOnly(_date), // Use pulse date month
        items: store.activeTimelineItems,
        existingPulses: store.pulses,
        currentLinkedItemId: _timelineItemId,
      ),
    );

    if (result != null) {
      setState(() {
        _timelineItemId = result;
      });
    }
  }
}
