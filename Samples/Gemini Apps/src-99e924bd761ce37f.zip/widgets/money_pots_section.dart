import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;
import 'package:expense_stalker_mobile/src/widgets/upsert_money_pot_sheet.dart';

import 'package:expense_stalker_mobile/src/features/timeline/helpers/pot_projection.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';

class MoneyPotsSection extends StatefulWidget {
  const MoneyPotsSection({
    super.key,
    required this.settings,
    this.month,
    this.items = const [],
    this.pulses = const [],
  });

  final AppSettingsStore settings;

  /// The month being displayed. If provided, debt balances will be projected
  /// based on assumed pulse between the current month and this month.
  final DateTime? month;

  /// List of timeline items to look up linked debt items for balance projection.
  final List<TimelineItem> items;

  /// List of pulses for the current month (to account for cleared state).
  final List<PulseEntry> pulses;

  @override
  State<MoneyPotsSection> createState() => _MoneyPotsSectionState();
}

class _MoneyPotsSectionState extends State<MoneyPotsSection> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  AppSettingsStore get settings => widget.settings;
  DateTime? get month => widget.month;
  List<TimelineItem> get items => widget.items;
  List<PulseEntry> get pulses => widget.pulses;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pots = settings.moneyPots.where((pot) {
      if (pot.type != MoneyPotType.debt) return true;
      return _calculateProjectedBalance(pot, pulses) > 0;
    }).toList();

    final creditColor = settings.creditColor;
    final debitColor = settings.debitColor;
    final collapsed = settings.moneyPotsSectionCollapsed == true;

    return Column(
      children: [
        Divider(
          height: 1,
          color: Theme.of(context).dividerColor.withValues(alpha: 0.5),
        ),

        // Header Row (Collapsible Toggle)
        InkWell(
          onTap: () => settings.moneyPotsSectionCollapsed = !collapsed,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              AppConstants.paddingNormal,
              8, // Slightly more padding for touch target
              AppConstants.paddingNormal,
              8,
            ),
            child: Row(
              children: [
                // Label
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onLongPress: () => _showSectionOptions(context),
                    child: Text(
                      settings.moneyPotsSettings.sectionLabel,
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface, // Improved from onSurfaceVariant
                            fontWeight:
                                FontWeight.w700, // Added for extra clarity
                            decoration: TextDecoration.underline,
                            decorationStyle: TextDecorationStyle.dotted,
                          ),
                    ),
                  ),
                ),

                // Chevron
                Icon(
                  collapsed ? Icons.expand_less : Icons.expand_more,
                  size: 20,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),

                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () => _editPot(context, null),
                  child: Icon(
                    Icons.add_circle_outline,
                    size: 20,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
        ),

        // Collapsible Content
        AnimatedSize(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
          alignment: Alignment.topCenter,
          child: collapsed
              ? const SizedBox.shrink()
              : Column(
                  children: [
                    if (pots.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(
                          bottom: AppConstants.paddingXSmall,
                          left: AppConstants.paddingNormal,
                          right: AppConstants.paddingNormal,
                        ),
                        child: SizedBox(
                          width: double.infinity,
                          child: Text(
                            'No pots configured',
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface
                                          .withValues(
                                            alpha: 0.7,
                                          ), // Improved from outline
                                      fontStyle: FontStyle.italic,
                                    ),
                          ),
                        ),
                      )
                    else if (pots.length == 1)
                      ...pots.map(
                        (pot) => _buildPotTile(
                          context,
                          pot,
                          creditColor,
                          debitColor,
                          pulses,
                        ),
                      )
                    else
                      _buildPotsGrid(
                        context,
                        pots,
                        creditColor,
                        debitColor,
                        pulses,
                      ),

                    // Extra bottom padding when expanded
                    const SizedBox(height: 8),
                  ],
                ),
        ),
      ],
    );
  }

  /// Builds the pots grid, with optional pagination via PageView.
  Widget _buildPotsGrid(
    BuildContext context,
    List<MoneyPot> pots,
    Color creditColor,
    Color debitColor,
    List<PulseEntry> pulses,
  ) {
    final columns = settings.moneyPotsGridColumns;
    final maxRows = settings.moneyPotsMaxVisibleRows;
    final potsPerPage = columns * maxRows;
    final totalPages = (pots.length / potsPerPage).ceil();

    const rowHeight = 52.0;
    final gridHeight = maxRows * rowHeight;

    Widget buildGrid(List<MoneyPot> pagePots) {
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          mainAxisExtent: rowHeight,
          crossAxisSpacing: AppConstants.paddingSmall,
          mainAxisSpacing: 0,
        ),
        itemCount: pagePots.length,
        itemBuilder: (context, index) => _buildPotCard(
          context,
          pagePots[index],
          creditColor,
          debitColor,
          pulses,
        ),
      );
    }

    // Single page — no PageView overhead
    if (totalPages <= 1) {
      return Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingNormal,
        ),
        child: buildGrid(pots),
      );
    }

    // Multi-page with horizontal swipe
    return Column(
      children: [
        SizedBox(
          height: gridHeight,
          child: PageView.builder(
            controller: _pageController,
            itemCount: totalPages,
            onPageChanged: (page) => setState(() => _currentPage = page),
            itemBuilder: (context, pageIndex) {
              final start = pageIndex * potsPerPage;
              final end = (start + potsPerPage).clamp(0, pots.length);
              final pagePots = pots.sublist(start, end);

              return Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppConstants.paddingNormal,
                ),
                child: buildGrid(pagePots),
              );
            },
          ),
        ),

        // Dot indicators
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(totalPages, (index) {
              final isActive = index == _currentPage;
              return Container(
                width: isActive ? 8 : 6,
                height: isActive ? 8 : 6,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isActive
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withValues(alpha: 0.3),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }

  /// Calculates the projected balance for a debt pot based on assumed pulse.
  int _calculateProjectedBalance(MoneyPot pot, List<PulseEntry> pulses) {
    if (month == null) return pot.amountMinorUnits;

    final currentMonthNormalized = monthOnly(DateTime.now());
    final displayMonthNormalized = monthOnly(month!);

    if (displayMonthNormalized.isBefore(currentMonthNormalized)) {
      return pot.amountMinorUnits;
    }
    if (displayMonthNormalized.isAtSameMomentAs(currentMonthNormalized)) {
      return pot.amountMinorUnits;
    }

    // To get the projection for a specific future month, we need to project from "now"
    // through all months up to the displayMonth.
    final range = month_math.monthRange(
      currentMonthNormalized,
      after: month_math.monthsBetween(
        currentMonthNormalized,
        displayMonthNormalized,
      ),
    );

    // We don't have a full pulseForMonth here, so we'll assume no pulses in future months
    // for the sake of the simple card view, which is standard for "planned" projections.
    final projections = projectMoneyPotBalances(
      initialPots: settings.moneyPots,
      months: range,
      items: items,
      pulseForMonth: (m) =>
          monthOnly(m) == currentMonthNormalized ? pulses : const [],
      settings: settings,
      currentMonth: currentMonthNormalized,
    );

    final potProjection = projections.last.firstWhereOrNull(
      (p) => p.id == pot.id,
    );
    return potProjection?.amountMinorUnits ?? pot.amountMinorUnits;
  }

  /// Converts pot amount to app currency if the pot's setting is enabled.
  int _convertPotAmountToAppCurrency(MoneyPot pot, int amount) {
    final showInAppCurrency = pot.showInAppCurrency;
    final appCurrency = settings.currencySettings.currency;
    final potCurrency = pot.currency;

    if (!showInAppCurrency ||
        potCurrency == null ||
        potCurrency == appCurrency) {
      return amount;
    }

    // Direct exchange rate on the pot takes precedence
    if (pot.exchangeRate != null && pot.exchangeRate! > 0) {
      return (amount / pot.exchangeRate!).round();
    }

    // Fallback to linked item for debt pots (legacy support)
    TimelineItem? linkedItem;
    for (final item in items) {
      if (item.moneyPotId == pot.id) {
        linkedItem = item;
        break;
      }
    }

    if (linkedItem != null &&
        linkedItem.exchangeRate != null &&
        linkedItem.exchangeRate! > 0) {
      final rate = linkedItem.exchangeRate;
      return (amount / rate!).round();
    }

    return amount;
  }

  // Helper to determine display currency
  AppCurrency _getDisplayCurrency(MoneyPot pot) {
    final showInAppCurrency = pot.showInAppCurrency;
    final appCurrency = settings.currencySettings.currency;
    final potCurrency = pot.currency;

    if (showInAppCurrency &&
        potCurrency != null &&
        potCurrency != appCurrency) {
      if (pot.exchangeRate != null && pot.exchangeRate! > 0) {
        return appCurrency;
      }

      // Check if conversion is possible (requires linked item with rate)
      TimelineItem? linkedItem;
      for (final item in items) {
        if (item.moneyPotId == pot.id) {
          linkedItem = item;
          break;
        }
      }
      if (linkedItem?.exchangeRate != null && linkedItem!.exchangeRate! > 0) {
        return appCurrency;
      }
    }

    return potCurrency ?? appCurrency;
  }

  Widget _buildPotCard(
    BuildContext context,
    MoneyPot pot,
    Color creditColor,
    Color debitColor,
    List<PulseEntry> pulses,
  ) {
    final projected = _calculateProjectedBalance(pot, pulses);
    final amount = _convertPotAmountToAppCurrency(pot, projected);
    final currency = _getDisplayCurrency(pot);
    final displayColor =
        pot.type == MoneyPotType.savings ? creditColor : debitColor;

    // Check if projected (approximate)
    final isProjected = projected != pot.amountMinorUnits;
    // Note: this projection check is basic. If conversion changes, amount changes too.
    // We check purely based on logic: is this future?

    return InkWell(
      onTap: () => _editPot(context, pot),
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingSmall,
          vertical: 2,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              pot.name,
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Row(
              children: [
                if (isProjected)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Icon(
                      projected < pot.amountMinorUnits
                          ? Icons.trending_down
                          : Icons.trending_up,
                      size: 12,
                      color: displayColor.withValues(alpha: 0.7),
                    ),
                  ),
                Expanded(
                  child: Text(
                    formatMoneyFromCents(
                      amount,
                      currency,
                      showCents: settings.showCents,
                    ),
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: displayColor,
                          fontWeight: FontWeight.w600,
                          fontFeatures: const [FontFeature.tabularFigures()],
                          fontStyle: isProjected ? FontStyle.italic : null,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPotTile(
    BuildContext context,
    MoneyPot pot,
    Color creditColor,
    Color debitColor,
    List<PulseEntry> pulses,
  ) {
    final projected = _calculateProjectedBalance(pot, pulses);
    final amount = _convertPotAmountToAppCurrency(pot, projected);
    final currency = _getDisplayCurrency(pot);
    final displayColor =
        pot.type == MoneyPotType.savings ? creditColor : debitColor;
    final isProjected = projected != pot.amountMinorUnits;

    return InkWell(
      onTap: () => _editPot(context, pot),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppConstants.paddingNormal,
          vertical: 3.0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                pot.name,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isProjected)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Icon(
                      projected < pot.amountMinorUnits
                          ? Icons.trending_down
                          : Icons.trending_up,
                      size: 14,
                      color: displayColor.withValues(alpha: 0.7),
                    ),
                  ),
                Text(
                  formatMoneyFromCents(
                    amount,
                    currency,
                    showCents: settings.showCents,
                  ),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: displayColor,
                        fontWeight: FontWeight.w600,
                        fontFeatures: const [FontFeature.tabularFigures()],
                        fontStyle: isProjected ? FontStyle.italic : null,
                      ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showSectionOptions(BuildContext context) async {
    final controller = TextEditingController(
      text: settings.moneyPotsSectionLabel,
    );

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Section Options'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: controller,
                  autofocus: true,
                  decoration: const InputDecoration(
                    labelText: 'Section Label',
                    hintText: 'e.g., Savings Goals',
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _buildDropdown<int>(
                        label: 'Columns',
                        value: settings.moneyPotsGridColumns,
                        items: const [1, 2, 3],
                        onChanged: (v) {
                          if (v != null) {
                            settings.moneyPotsGridColumns = v;
                            setDialogState(() {});
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildDropdown<int>(
                        label: 'Visible rows',
                        value: settings.moneyPotsMaxVisibleRows,
                        items: const [1, 2, 3, 4],
                        onChanged: (v) {
                          if (v != null) {
                            settings.moneyPotsMaxVisibleRows = v;
                            setDialogState(() {});
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Done'),
              ),
            ],
          );
        },
      ),
    );

    if (controller.text.isNotEmpty &&
        controller.text != settings.moneyPotsSectionLabel) {
      await settings.updateMoneyPotsSectionLabel(controller.text);
    }
  }

  Widget _buildDropdown<T>({
    required String label,
    required T value,
    required List<T> items,
    required ValueChanged<T?> onChanged,
  }) {
    return InputDecorator(
      decoration: InputDecoration(
        labelText: label,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        border: const OutlineInputBorder(),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value: value,
          isDense: true,
          isExpanded: true,
          items: items
              .map((e) => DropdownMenuItem<T>(value: e, child: Text('$e')))
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Future<void> _editPot(BuildContext context, MoneyPot? pot) async {
    if (pot != null && pot.isSystemManaged) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('This pot is managed by its linked debt item'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => UpsertMoneyPotSheet(initialPot: pot),
    );

    if (result is MoneyPot) {
      if (pot == null) {
        await settings.addMoneyPot(result);
      } else {
        await settings.updateMoneyPot(result);
      }
    } else if (result is DeletePotMarker) {
      if (pot != null) {
        await settings.removeMoneyPot(pot.id);
      }
    }
  }
}
