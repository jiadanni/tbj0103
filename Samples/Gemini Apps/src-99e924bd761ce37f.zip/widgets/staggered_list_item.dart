import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';

/// Wraps a child widget with a staggered fade+slide entrance animation.
///
/// Each item delays its animation start by [index] * [itemDelay], capped
/// at [maxDelay]. This creates a cascading reveal effect when list items
/// first appear.
class StaggeredListItem extends StatefulWidget {
  const StaggeredListItem({
    super.key,
    required this.index,
    required this.child,
    this.itemDelay = AppConstants.staggerItemDelay,
    this.maxDelay = AppConstants.staggerMaxDelay,
    this.duration = AppConstants.staggerItemDuration,
  });

  final int index;
  final Widget child;
  final Duration itemDelay;
  final Duration maxDelay;
  final Duration duration;

  @override
  State<StaggeredListItem> createState() => _StaggeredListItemState();
}

class _StaggeredListItemState extends State<StaggeredListItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fadeAnimation;
  late final Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    final curve = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(curve);
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, 0.15),
      end: Offset.zero,
    ).animate(curve);

    // Stagger the start: each item waits index * itemDelay, capped at maxDelay
    final delayMs = (widget.index * widget.itemDelay.inMilliseconds).clamp(
      0,
      widget.maxDelay.inMilliseconds,
    );
    Future.delayed(Duration(milliseconds: delayMs), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SlideTransition(position: _slideAnimation, child: widget.child),
    );
  }
}
