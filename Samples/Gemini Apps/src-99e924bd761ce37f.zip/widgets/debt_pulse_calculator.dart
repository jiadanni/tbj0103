import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/debt_calculator.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';

/// Displays the estimated payoff date for a debt payment plan.
///
/// Shows a card with:
/// - The calculated final pulse date
/// - Number of remaining instalments (based on base amount + any value history overrides)
///
/// Only renders if all required inputs are valid (remaining balance, amount, frequency).
class DebtPulseCalculator extends StatelessWidget {
  const DebtPulseCalculator({
    super.key,
    required this.remainingBalanceController,
    required this.amountController,
    required this.dayOfMonthController,
    required this.frequency,
    required this.startDate,
    this.exchangeRate,
    this.balanceCurrency,
    this.appCurrency,
    this.valueHistory,
  });

  final TextEditingController remainingBalanceController;
  final TextEditingController amountController;
  final TextEditingController dayOfMonthController;
  final RecurrenceFrequency? frequency;
  final DateTime startDate;
  final double? exchangeRate;
  final AppCurrency? balanceCurrency;
  final AppCurrency? appCurrency;
  final List<TimelineItemValueChange>? valueHistory;

  @override
  Widget build(BuildContext context) {
    final remainingBalanceMinorUnits = tryParseMoneyToCents(
      remainingBalanceController.text,
    );
    final amountMinorUnits = tryParseMoneyToCents(amountController.text);

    if (remainingBalanceMinorUnits == null ||
        remainingBalanceMinorUnits <= 0 ||
        amountMinorUnits == null ||
        amountMinorUnits <= 0 ||
        frequency == null) {
      return const SizedBox.shrink();
    }

    // Calculate effective pulse amount in loan currency
    // If debt is foreign, apply exchange rate to show timeline in app currency
    int effectivePulseCentsInAppCurrency;
    if (exchangeRate != null && exchangeRate! > 0) {
      // Amount is specified in loan currency, convert to app currency for display
      effectivePulseCentsInAppCurrency =
          (amountMinorUnits * exchangeRate!).round().clamp(1, 999999999999);
    } else {
      effectivePulseCentsInAppCurrency = amountMinorUnits;
    }

    final finalDate = DebtCalculator.calculateFinalPulseDate(
      type: PulseType.debt,
      remainingBalanceMinorUnits: remainingBalanceMinorUnits,
      amountMinorUnits: amountMinorUnits,
      frequency: frequency,
      startDate: startDate,
      // exchangeRate: exchangeRate, // removed
      balanceCurrency: balanceCurrency,
    );
    if (finalDate == null) return const SizedBox.shrink();

    // Pulse needed is calculated based on LOAN CURRENCY balance / LOAN CURRENCY amount
    final pulseNeeded = (remainingBalanceMinorUnits / amountMinorUnits).ceil();
    final formattedDate =
        '${finalDate.year}-${finalDate.month.toString().padLeft(2, '0')}-${finalDate.day.toString().padLeft(2, '0')}';

    final hasExchangeRate =
        exchangeRate != null && exchangeRate! > 0 && balanceCurrency != null;

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  size: 16,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Estimated payoff date',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              formattedDate,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              '$pulseNeeded ${pulseNeeded == 1 ? 'instalment' : 'instalments'} remaining',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            if (hasExchangeRate && appCurrency != null) ...[
              const SizedBox(height: 4),
              Text(
                'Each payment = ${currencySymbol(appCurrency!)}${(effectivePulseCentsInAppCurrency / 100).toStringAsFixed(2)} toward balance',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontStyle: FontStyle.italic,
                    ),
              ),
            ],
            if (valueHistory != null && valueHistory!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'Note: Payoff assumes base amount. Actual date may vary with monthly overrides.',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontStyle: FontStyle.italic,
                    ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
