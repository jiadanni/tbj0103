import 'package:flutter/widgets.dart';

/// Rebuilds only when the selected value changes (uses equality check).
///
/// This widget is useful for listening to a Listenable but only rebuilding
/// when a specific slice of its state changes. The [selector] function extracts
/// the relevant value, and the widget only rebuilds if the selected value
/// differs from the previous one.
///
/// Example:
/// ```dart
/// SelectiveListenableBuilder<ExpenseStore, DateTime>(
///   listenable: store,
///   selector: (store) => store.selectedMonth,
///   builder: (context, selectedMonth, child) {
///     return Text('Month: $selectedMonth');
///   },
/// )
/// ```
class SelectiveListenableBuilder<T extends Listenable, S>
    extends StatefulWidget {
  const SelectiveListenableBuilder({
    super.key,
    required this.listenable,
    required this.selector,
    required this.builder,
    this.child,
  });

  final T listenable;
  final S Function(T) selector;
  final Widget Function(BuildContext, S, Widget?) builder;
  final Widget? child;

  @override
  State<SelectiveListenableBuilder<T, S>> createState() =>
      _SelectiveListenableBuilderState<T, S>();
}

class _SelectiveListenableBuilderState<T extends Listenable, S>
    extends State<SelectiveListenableBuilder<T, S>> {
  late S _value;

  @override
  void initState() {
    super.initState();
    _value = widget.selector(widget.listenable);
    widget.listenable.addListener(_handleValueChanged);
  }

  @override
  void didUpdateWidget(SelectiveListenableBuilder<T, S> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.listenable != widget.listenable) {
      oldWidget.listenable.removeListener(_handleValueChanged);
      _value = widget.selector(widget.listenable);
      widget.listenable.addListener(_handleValueChanged);
    }
  }

  @override
  void dispose() {
    widget.listenable.removeListener(_handleValueChanged);
    super.dispose();
  }

  void _handleValueChanged() {
    final newValue = widget.selector(widget.listenable);
    if (newValue != _value) {
      setState(() {
        _value = newValue;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(context, _value, widget.child);
  }
}
