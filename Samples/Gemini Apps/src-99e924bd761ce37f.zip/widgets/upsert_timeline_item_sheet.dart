import 'package:collection/collection.dart';
import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';

import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/widgets/timeline_item_form_validators.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';
// For ViewPeriodMode
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/type_selector.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/debt_fields_section.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/optional_fields_section.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/hero_amount_display.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/scheduling_section.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/month_year_picker_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/budget_plan_sheet.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/schedule_modifications_sheet.dart';

/// Bottom sheet for creating or editing a timeline item.
///
/// Returns the updated [TimelineItem] on save, or null if cancelled.
class UpsertTimelineItemSheet extends StatefulWidget {
  const UpsertTimelineItemSheet({
    super.key,
    this.existing,
    required this.defaultStartDate,
    this.onDelete,
  });

  /// If provided, sheet is in edit mode. If null, create mode.
  final TimelineItem? existing;

  /// The default start date to use when creating a new timeline item.
  /// Typically set to the currently selected month.
  final DateTime defaultStartDate;

  /// Callback to execute when delete is confirmed.
  final VoidCallback? onDelete;

  @override
  State<UpsertTimelineItemSheet> createState() =>
      _UpsertTimelineItemSheetState();
}

class _UpsertTimelineItemSheetState extends State<UpsertTimelineItemSheet> {
  static const _kNewMoneyPotId = MoneyPotId('new_money_pot');
  late final TextEditingController _labelController;
  late final TextEditingController _amountController;
  late final TextEditingController _dayController;
  late final TextEditingController _notesController;
  late final TextEditingController _remainingBalanceController;
  late final TextEditingController _categoryController;
  late final TextEditingController _subcategoryController;
  late final TextEditingController _originController;
  late final FocusNode _categoryFocusNode;
  late final FocusNode _subcategoryFocusNode;
  late PulseType _type;
  RecurrenceFrequency? _frequency;
  late DateTime _startDate;
  bool _isPaidOff = false;
  String? _dayValidationError;
  String? _saveValidationError;
  String? _selectedCategory;
  String? _selectedSubcategory;
  late bool _isSalary;
  List<String> _suggestedOrigins = [];
  List<int>? _quickAddAmounts;
  List<TimelineItemValueChange> _valueHistory = [];
  List<DateTime> _skippedDates = [];
  DateTime? _pausedDate;
  DateTime? _autoResumeDate;

  bool? _useActualsForCurrentBalance;
  bool? _useActualsForFutureBalance;

  final LayerLink _categoryLayerLink = LayerLink();
  final LayerLink _subcategoryLayerLink = LayerLink();

  bool get _isIncomeMode => _type.isIncomeType;
  int get _baseAmount {
    final val = double.tryParse(_amountController.text) ?? 0;
    int base = (val * 100).round();
    return _isIncomeMode ? base.abs() : -base.abs();
  }

  bool get _isEditMode => widget.existing != null;
  MoneyPotId? _selectedMoneyPotId;
  AppCurrency? _balanceCurrency;
  late final TextEditingController _exchangeRateController;
  late final TextEditingController _settlementAmountController;

  // Money Pot Currency (can differ from debt's balance currency)
  // null = use app currency, otherwise use the specified currency
  AppCurrency? _potCurrency;

  bool _safeBool(bool? Function() f) {
    try {
      return f() == true;
    } catch (_) {
      return false;
    }
  }

  @override
  void initState() {
    super.initState();
    _categoryFocusNode = FocusNode();
    _subcategoryFocusNode = FocusNode();
    final existing = widget.existing;
    _labelController = TextEditingController(text: existing?.label ?? '');
    // Store absolute value only - sign is determined by income/expense toggle
    final item = widget.existing;
    _amountController = TextEditingController(
      text: (item != null)
          ? (item.amountMinorUnits.abs() / 100).toStringAsFixed(2)
          : '',
    );
    _dayController = TextEditingController(
      text: existing?.dayOfMonth.toString() ?? '',
    );
    _selectedMoneyPotId = existing?.moneyPotId;
    _balanceCurrency = existing?.balanceCurrency;

    int? initialBalanceCents = existing?.remainingBalanceMinorUnits;
    if (_selectedMoneyPotId != null) {
      final pot = AppSettingsScope.read(
        context,
      ).moneyPots.firstWhereOrNull((p) => p.id == _selectedMoneyPotId);
      if (pot != null) {
        initialBalanceCents = pot.amountMinorUnits;
        // Initialize pot currency from existing pot
        _potCurrency = pot.currency;
      } else {
        // Pot not found (e.g. after import where pot wasn't preserved)
        // Reset selection so the toggle is OFF by default instead of showing a broken state
        _selectedMoneyPotId = null;
      }
    }
    // Default pot currency to debt's balance currency for new pots
    _potCurrency ??= _balanceCurrency;

    _remainingBalanceController = TextEditingController(
      text: ((initialBalanceCents ?? 0) / 100).toStringAsFixed(2),
    );
    _notesController = TextEditingController(text: existing?.notes ?? '');
    _categoryController = TextEditingController(text: existing?.category ?? '');
    _subcategoryController = TextEditingController(
      text: existing?.subcategory ?? '',
    );
    _originController = TextEditingController(text: existing?.origin ?? '');
    _type = existing?.type ?? PulseType.recurring;
    _frequency = existing?.frequency ??
        (_type != PulseType.oneOff && _type != PulseType.oneOffIncome
            ? RecurrenceFrequency.monthly
            : null);
    _startDate = existing?.startDate ?? widget.defaultStartDate;
    _isPaidOff = existing?.paidOffDate != null;
    _selectedCategory = existing?.category;
    _selectedSubcategory = existing?.subcategory;
    _isSalary = _safeBool(() => existing?.isSalary);
    _suggestedOrigins = existing?.suggestedOrigins != null
        ? List<String>.from(existing!.suggestedOrigins!)
        : [];

    // Initialize new fields
    // If existing item has data, use it. If not, they are null (use global default).
    _useActualsForCurrentBalance = existing?.useActualsForCurrentBalance;
    _useActualsForFutureBalance = existing?.useActualsForFutureBalance;

    _exchangeRateController = TextEditingController(
      text: existing?.exchangeRate?.toString() ?? '',
    );

    // Dual FX fields for foreign currency debts:
    // When editing an item with transactionCurrency set, _amountController
    // shows the loan-currency instalment, _settlementAmountController shows
    // the app-currency settlement. For new items or domestic debts, settlement
    // stays empty until balanceCurrency is set.
    if (existing != null &&
        existing.transactionCurrency != null &&
        existing.transactionAmountMinorUnits != null) {
      // Edit mode with FX: amount controller = loan currency instalment
      _amountController.text =
          (existing.transactionAmountMinorUnits!.abs() / 100).toStringAsFixed(
        2,
      );
      _settlementAmountController = TextEditingController(
        text: (existing.amountMinorUnits.abs() / 100).toStringAsFixed(2),
      );
    } else if (existing != null &&
        existing.balanceCurrency != null &&
        existing.exchangeRate != null &&
        existing.exchangeRate! > 0) {
      // Legacy FX debt: amountMinorUnits is the loan amount, compute settlement
      final loanAmount = existing.amountMinorUnits.abs() / 100;
      final settlement = loanAmount * existing.exchangeRate!;
      _settlementAmountController = TextEditingController(
        text: settlement.toStringAsFixed(2),
      );
      // _amountController already has the loan amount from earlier init
    } else {
      _settlementAmountController = TextEditingController();
    }
    _quickAddAmounts = existing?.quickAddAmounts;
    _valueHistory = existing?.valueHistory ?? [];
    _skippedDates = existing?.skippedDates ?? [];
    _pausedDate = existing?.pausedDate;
    _autoResumeDate = existing?.autoResumeDate;

    // Add listener for real-time day validation
    _dayController.addListener(_validateDay);

    // Clear save validation error when user edits required fields
    _labelController.addListener(_clearSaveValidationError);
    _amountController.addListener(_clearSaveValidationError);
    _dayController.addListener(_clearSaveValidationError);

    // Add listeners for FX settlement auto-calculation
    _amountController.addListener(_updateSettlementCalculation);
    _exchangeRateController.addListener(_updateSettlementCalculation);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Initial validation will happen on first user interaction
    // We don't validate here to avoid setState during build
  }

  void _validateDay() {
    final result = TimelineItemFormValidation.validateDay(
      _dayController.text,
      context,
    );
    setState(() {
      _dayValidationError = result.dayError;
      // Note: result.dayInfoMessage not shown for compactness
    });
  }

  void _clearSaveValidationError() {
    if (_saveValidationError != null) {
      setState(() => _saveValidationError = null);
    }
  }

  /// Auto-calculates settlement amount when FX is active.
  /// Mirrors UpdatePulseSheet._updateSettlementCalculation pattern.
  void _updateSettlementCalculation() {
    if (_balanceCurrency == null) return;
    final transAmount = double.tryParse(_amountController.text) ?? 0;
    final rate = double.tryParse(_exchangeRateController.text) ?? 0;
    if (rate > 0) {
      final settlement = transAmount * rate;
      final currentSettlement =
          double.tryParse(_settlementAmountController.text) ?? 0;
      // Only update if materially different to avoid cursor jumping
      if ((settlement - currentSettlement).abs() > 0.005) {
        _settlementAmountController.text = settlement.toStringAsFixed(2);
      }
    }
  }

  @override
  void dispose() {
    _dayController.removeListener(_validateDay);
    _labelController.removeListener(_clearSaveValidationError);
    _amountController.removeListener(_clearSaveValidationError);
    _dayController.removeListener(_clearSaveValidationError);
    _amountController.removeListener(_updateSettlementCalculation);
    _exchangeRateController.removeListener(_updateSettlementCalculation);
    _labelController.dispose();
    _amountController.dispose();
    _settlementAmountController.dispose();
    _dayController.dispose();
    _notesController.dispose();
    _categoryController.dispose();
    _subcategoryController.dispose();
    _originController.dispose();
    _remainingBalanceController.dispose();
    _exchangeRateController.dispose();
    _categoryFocusNode.dispose();
    _subcategoryFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final l10n = AppLocalizations.of(context);
    final colorScheme = Theme.of(context).colorScheme;
    final settings = AppSettingsScope.of(context);
    final store = ExpenseStoreScope.read(context);

    // Theme-aware color palette
    final backgroundTop = colorScheme.surface;
    final backgroundBottom = colorScheme.surfaceContainerLowest;
    final textPrimary = colorScheme.onSurface;
    // Use app's credit/debit colors for income/expense accents
    final accentIncome = settings.creditColor;
    final accentExpense = settings.debitColor;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundTop, backgroundBottom],
        ),
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Grab handle
              Container(
                margin: const EdgeInsets.only(top: 8),
                width: 32,
                height: 4,
                decoration: BoxDecoration(
                  color: colorScheme.outlineVariant.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(16, 6, 16, 16 + bottomInset),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Title + Income/Expense toggle row
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              _isEditMode
                                  ? Terminology.of(context).editItemTitle
                                  : Terminology.of(context).newItemTitle,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: textPrimary,
                                  ),
                            ),
                          ),
                          IncomeExpenseToggle(
                            isIncomeMode: _isIncomeMode,
                            accentIncome: accentIncome,
                            accentExpense: accentExpense,
                            onToggle: (income) {
                              if (income) {
                                _switchToIncomeMode();
                              } else {
                                _switchToExpenseMode();
                              }
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Hero amount display
                      // When FX debt is active, the hero field shows loan currency
                      HeroAmountDisplay(
                        controller: _amountController,
                        isIncomeMode: _isIncomeMode,
                        accentIncome: accentIncome,
                        accentExpense: accentExpense,
                        currencySymbol: (_type == PulseType.debt &&
                                _balanceCurrency != null)
                            ? currencySymbol(_balanceCurrency!)
                            : currencySymbol(settings.currency),
                        showCents: settings.showCents,
                        type: _type,
                      ),
                      const SizedBox(height: 12),

                      // Name field
                      TextField(
                        controller: _labelController,
                        style: TextStyle(color: textPrimary, fontSize: 14),
                        decoration: UpsertTimelineItemStyle.compactInput(
                          context,
                          'Name *',
                          hintText: 'Enter name',
                        ),
                        maxLength: AppConstants.maxLabelLength,
                        textInputAction: TextInputAction.next,
                      ),
                      const SizedBox(height: 12),

                      // Debt-specific fields (early in the form for better UX)
                      if (_type == PulseType.debt)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: DebtFieldsSection(
                            remainingBalanceController:
                                _remainingBalanceController,
                            balanceCurrency: _balanceCurrency,
                            exchangeRateController: _exchangeRateController,
                            settlementAmountController:
                                _settlementAmountController,
                            selectedMoneyPotId: _selectedMoneyPotId,
                            amountController: _amountController,
                            dayController: _dayController,
                            frequency: _frequency,
                            startDate: _startDate,
                            isEditMode: _isEditMode,
                            isPaidOff: _isPaidOff,
                            onBalanceCurrencyChanged: (value) {
                              setState(() {
                                _balanceCurrency = value;
                                if (value == null) {
                                  _exchangeRateController.clear();
                                  _potCurrency =
                                      null; // Reset to app currency if loan becomes domestic
                                } else {
                                  _potCurrency ??= value;
                                }
                                // Otherwise preserve user's explicit pot currency choice
                              });
                            },
                            onMoneyPotChanged: _onMoneyPotChanged,
                            onIsPaidOffChanged: (value) =>
                                setState(() => _isPaidOff = value),
                            potCurrency: _potCurrency,
                            onPotCurrencyChanged: (value) =>
                                setState(() => _potCurrency = value),
                            buildCompactCheckbox: ({
                              required label,
                              required onChanged,
                              required subtitle,
                              required value,
                            }) {
                              return UpsertTimelineItemStyle
                                  .buildCompactCheckbox(
                                context: context,
                                value: value,
                                onChanged: onChanged,
                                label: label,
                                subtitle: subtitle,
                              );
                            },
                            valueHistory: _valueHistory,
                          ),
                        ),

                      // Category + Subcategory + Origin Row
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 3,
                            child: UpsertTimelineItemStyle.labeledField(
                              context: context,
                              label: l10n?.category ?? 'Category',
                              child: RawAutocomplete<String>(
                                textEditingController: _categoryController,
                                focusNode: _categoryFocusNode,
                                optionsBuilder:
                                    (TextEditingValue textEditingValue) {
                                  final suggestions = getCategorySuggestions(
                                    isIncome: _isIncomeMode,
                                    mode: settings.categoryPresetMode,
                                    userCategories: store.getUserCategories(
                                      isIncome: _isIncomeMode,
                                    ),
                                  );

                                  if (textEditingValue.text.isEmpty) {
                                    return suggestions;
                                  }
                                  return suggestions.where((option) {
                                    return option.toLowerCase().contains(
                                          textEditingValue.text.toLowerCase(),
                                        );
                                  });
                                },
                                onSelected: (String selection) {
                                  setState(() {
                                    _selectedCategory = selection;
                                    // Clear subcategory when category changes
                                    _selectedSubcategory = null;
                                    _subcategoryController.clear();
                                  });
                                },
                                fieldViewBuilder: (
                                  context,
                                  controller,
                                  focusNode,
                                  onFieldSubmitted,
                                ) {
                                  return CompositedTransformTarget(
                                    link: _categoryLayerLink,
                                    child: TextField(
                                      controller: controller,
                                      focusNode: focusNode,
                                      style: TextStyle(
                                        color: textPrimary,
                                        fontSize: 13,
                                      ),
                                      decoration:
                                          UpsertTimelineItemStyle.compactInput(
                                        context,
                                        'Category',
                                        floatingLabel: false,
                                      ),
                                      onChanged: (value) {
                                        setState(() {
                                          _selectedCategory =
                                              value.trim().isEmpty
                                                  ? null
                                                  : value.trim();
                                          // Don't clear subcategory on typing, only on selection change if needed
                                        });
                                      },
                                      onSubmitted: (_) => onFieldSubmitted(),
                                    ),
                                  );
                                },
                                optionsViewBuilder:
                                    (context, onSelected, options) {
                                  return CompositedTransformFollower(
                                    link: _categoryLayerLink,
                                    showWhenUnlinked: false,
                                    offset: const Offset(0, 40),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: Material(
                                        elevation: 8.0,
                                        borderRadius: BorderRadius.circular(8),
                                        color: colorScheme.surfaceContainerHigh,
                                        child: Container(
                                          width: 160,
                                          constraints: const BoxConstraints(
                                            maxHeight: 180,
                                          ),
                                          child: ListView.builder(
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 4,
                                            ),
                                            shrinkWrap: true,
                                            itemCount: options.length,
                                            itemBuilder: (
                                              BuildContext context,
                                              int index,
                                            ) {
                                              final option =
                                                  options.elementAt(index);
                                              return InkWell(
                                                onTap: () => onSelected(option),
                                                child: Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                    horizontal: 12,
                                                    vertical: 8,
                                                  ),
                                                  child: Text(
                                                    option,
                                                    style: TextStyle(
                                                      color: textPrimary,
                                                      fontSize: 13,
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Subcategory Field
                          if (_selectedCategory != null &&
                              getSubcategorySuggestions(
                                category: _selectedCategory!,
                                isIncome: _isIncomeMode,
                              ).isNotEmpty) ...[
                            Expanded(
                              flex: 3,
                              child: UpsertTimelineItemStyle.labeledField(
                                context: context,
                                label: l10n?.subcategory ?? 'Subcategory',
                                child: RawAutocomplete<String>(
                                  textEditingController: _subcategoryController,
                                  focusNode: _subcategoryFocusNode,
                                  optionsBuilder:
                                      (TextEditingValue textEditingValue) {
                                    final suggestions =
                                        getSubcategorySuggestions(
                                      category: _selectedCategory!,
                                      isIncome: _isIncomeMode,
                                    );

                                    if (textEditingValue.text.isEmpty) {
                                      return suggestions;
                                    }
                                    return suggestions.where((option) {
                                      return option.toLowerCase().contains(
                                            textEditingValue.text.toLowerCase(),
                                          );
                                    });
                                  },
                                  onSelected: (String selection) {
                                    setState(
                                      () => _selectedSubcategory = selection,
                                    );
                                  },
                                  fieldViewBuilder: (
                                    context,
                                    controller,
                                    focusNode,
                                    onFieldSubmitted,
                                  ) {
                                    return CompositedTransformTarget(
                                      link: _subcategoryLayerLink,
                                      child: TextField(
                                        controller: controller,
                                        focusNode: focusNode,
                                        style: TextStyle(
                                          color: textPrimary,
                                          fontSize: 13,
                                        ),
                                        decoration: UpsertTimelineItemStyle
                                            .compactInput(
                                          context,
                                          'Subcategory',
                                          floatingLabel: false,
                                        ),
                                        onChanged: (value) {
                                          setState(
                                            () => _selectedSubcategory =
                                                value.trim().isEmpty
                                                    ? null
                                                    : value.trim(),
                                          );
                                        },
                                        onSubmitted: (_) => onFieldSubmitted(),
                                      ),
                                    );
                                  },
                                  optionsViewBuilder:
                                      (context, onSelected, options) {
                                    return CompositedTransformFollower(
                                      link: _subcategoryLayerLink,
                                      showWhenUnlinked: false,
                                      offset: const Offset(0, 40),
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Material(
                                          elevation: 8.0,
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          color:
                                              colorScheme.surfaceContainerHigh,
                                          child: Container(
                                            width: 140,
                                            constraints: const BoxConstraints(
                                              maxHeight: 180,
                                            ),
                                            child: ListView.builder(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                vertical: 4,
                                              ),
                                              shrinkWrap: true,
                                              itemCount: options.length,
                                              itemBuilder: (
                                                BuildContext context,
                                                int index,
                                              ) {
                                                final option =
                                                    options.elementAt(index);
                                                return InkWell(
                                                  onTap: () => onSelected(
                                                    option,
                                                  ),
                                                  child: Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                      horizontal: 12,
                                                      vertical: 8,
                                                    ),
                                                    child: Text(
                                                      option,
                                                      style: TextStyle(
                                                        color: textPrimary,
                                                        fontSize: 13,
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                          ],

                          if (_type != PulseType.spendingEnvelope) ...[
                            Expanded(
                              flex: 2,
                              child: UpsertTimelineItemStyle.labeledField(
                                context: context,
                                label: 'Origin',
                                child: TextField(
                                  controller: _originController,
                                  style: TextStyle(
                                    color: textPrimary,
                                    fontSize: 13,
                                  ),
                                  decoration:
                                      UpsertTimelineItemStyle.compactInput(
                                    context,
                                    'Origin',
                                    floatingLabel: false,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            // Day field
                            Expanded(
                              flex: 1,
                              child: UpsertTimelineItemStyle.labeledField(
                                context: context,
                                label: 'Day *',
                                child: TextField(
                                  controller: _dayController,
                                  style: TextStyle(
                                    color: textPrimary,
                                    fontSize: 13,
                                  ),
                                  decoration:
                                      UpsertTimelineItemStyle.compactInput(
                                    context,
                                    '1-31',
                                    floatingLabel: false,
                                    errorText: _dayValidationError,
                                  ),
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),

                      // Suggested Origins (Only for Spending Envelopes)
                      if (_type == PulseType.spendingEnvelope) ...[
                        const SizedBox(height: 8),
                        UpsertTimelineItemStyle.labeledField(
                          context: context,
                          label: 'Suggested Origins (for autocomplete)',
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Wrap(
                                spacing: 8,
                                runSpacing: 4,
                                children: [
                                  ..._suggestedOrigins.map(
                                    (origin) => Chip(
                                      label: Text(
                                        origin,
                                        style: const TextStyle(fontSize: 12),
                                      ),
                                      deleteIcon: const Icon(
                                        Icons.close,
                                        size: 14,
                                      ),
                                      onDeleted: () {
                                        setState(() {
                                          _suggestedOrigins = List<String>.from(
                                            _suggestedOrigins,
                                          )..remove(origin);
                                        });
                                      },
                                      visualDensity: VisualDensity.compact,
                                      materialTapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                    ),
                                  ),
                                  ActionChip(
                                    label: const Text(
                                      'Add',
                                      style: TextStyle(fontSize: 12),
                                    ),
                                    avatar: const Icon(Icons.add, size: 14),
                                    onPressed: () async {
                                      final controller =
                                          TextEditingController();
                                      final result = await showDialog<String>(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                          title: const Text(
                                            'Add Suggested Origin',
                                          ),
                                          content: TextField(
                                            controller: controller,
                                            autofocus: true,
                                            decoration: const InputDecoration(
                                              labelText: 'Origin Name',
                                            ),
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () =>
                                                  Navigator.pop(context),
                                              child: const Text('Cancel'),
                                            ),
                                            TextButton(
                                              onPressed: () => Navigator.pop(
                                                context,
                                                controller.text,
                                              ),
                                              child: const Text('Add'),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (result != null &&
                                          result.trim().isNotEmpty) {
                                        final trimmed = result.trim();
                                        // Case-insensitive duplicate check
                                        final alreadyExists =
                                            _suggestedOrigins.any(
                                          (o) =>
                                              o.toLowerCase() ==
                                              trimmed.toLowerCase(),
                                        );
                                        if (!alreadyExists) {
                                          setState(() {
                                            _suggestedOrigins =
                                                List<String>.from(
                                              _suggestedOrigins,
                                            )..add(trimmed);
                                          });
                                        }
                                      }
                                    },
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 8),

                      // Type section
                      TimelineItemTypeSelector(
                        type: _type,
                        isIncomeMode: _isIncomeMode,
                        onTypeChanged: _selectSubtype,
                      ),
                      const SizedBox(height: 8),

                      // Schedule section with label
                      Builder(
                        builder: (context) {
                          String? customDateLabel;

                          if (_type == PulseType.spendingEnvelope &&
                              store.currentAccount.viewPeriodMode ==
                                  ViewPeriodMode.paycheck) {
                            final period = PaycheckService.getPeriodInfo(
                              _startDate,
                              ViewPeriodMode.paycheck,
                              store.currentAccount.paycheckDay,
                              businessAdjust: true,
                            );
                            customDateLabel = 'Start Period: ${period.label}';
                          }

                          return SchedulingSection(
                            type: _type,
                            startDate: _startDate,
                            customDateLabel: customDateLabel,
                            frequency: _frequency,
                            onPickStartDate: _pickStartDate,
                            onFrequencyChanged: (value) {
                              if (value != null) {
                                setState(() => _frequency = value);
                              }
                            },
                          );
                        },
                      ),
                      const SizedBox(height: 8),

                      // Collapsible optional fields section
                      const SizedBox(height: 8),
                      OptionalFieldsSection(
                        categoryController: _categoryController,
                        categoryFocusNode: _categoryFocusNode,
                        categoryLayerLink: _categoryLayerLink,
                        selectedCategory: _selectedCategory,
                        originController: _originController,
                        isSalary: _isSalary,
                        notesController: _notesController,
                        isIncomeMode: _isIncomeMode,
                        type: _type,
                        onCategorySelected: (value) =>
                            setState(() => _selectedCategory = value),
                        onIsSalaryChanged: (value) =>
                            setState(() => _isSalary = value),
                        suggestedOrigins: _suggestedOrigins,
                        onSuggestedOriginsChanged: (value) =>
                            setState(() => _suggestedOrigins = value),
                        selectedMoneyPotId: _selectedMoneyPotId,
                        onMoneyPotChanged: _onMoneyPotChanged,
                        remainingBalanceController: _remainingBalanceController,
                        balanceCurrency: _balanceCurrency,
                        onBalanceCurrencyChanged: (AppCurrency? value) {
                          setState(() => _balanceCurrency = value);
                        },

                        // Pass new fields
                        useActualsForCurrentBalance:
                            _useActualsForCurrentBalance,
                        useActualsForFutureBalance: _useActualsForFutureBalance,
                        onUseActualsCurrentChanged: (val) =>
                            setState(() => _useActualsForCurrentBalance = val),
                        onUseActualsFutureChanged: (val) =>
                            setState(() => _useActualsForFutureBalance = val),

                        // Legacy handlers removed/updated
                        quickAddAmounts: _quickAddAmounts,
                        onEditQuickAmounts: _showQuickAmountsEditDialog,
                        buildCompactCheckbox: ({
                          required label,
                          required onChanged,
                          required subtitle,
                          required value,
                        }) {
                          return UpsertTimelineItemStyle.buildCompactCheckbox(
                            context: context,
                            value: value,
                            onChanged: onChanged,
                            label: label,
                            subtitle: subtitle,
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      // Scheduled Changes / Value History integration (moved here & redesigned)
                      if (_type == PulseType.recurring ||
                          _type == PulseType.recurringIncome ||
                          _type == PulseType.spendingEnvelope ||
                          _type == PulseType.debt) ...[
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.tonalIcon(
                            onPressed: () async {
                              final currentBaseAmount = _baseAmount;

                              if (_type == PulseType.spendingEnvelope) {
                                // Spending envelopes use the dedicated BudgetPlanSheet
                                final result = await showModalBottomSheet<
                                    List<TimelineItemValueChange>>(
                                  context: context,
                                  isScrollControlled: true,
                                  backgroundColor: Colors.transparent,
                                  builder: (context) {
                                    return BudgetPlanSheet(
                                      initialHistory: _valueHistory,
                                      baseAmountMinorUnits: currentBaseAmount,
                                      currency: settings.currency,
                                      itemType: _type,
                                      startDate: _startDate,
                                      timelineItemId: widget.existing?.id,
                                      onChanged: (history) {
                                        setState(() {
                                          _valueHistory = history;
                                        });
                                      },
                                    );
                                  },
                                );

                                if (result != null) {
                                  setState(() {
                                    _valueHistory = result;
                                  });
                                }
                              } else {
                                // Other recurring types use the combined modifications sheet
                                final result = await showModalBottomSheet<
                                    ScheduleModificationsResult>(
                                  context: context,
                                  isScrollControlled: true,
                                  backgroundColor: Colors.transparent,
                                  builder: (context) {
                                    return ScheduleModificationsSheet(
                                      initialHistory: _valueHistory,
                                      baseAmountMinorUnits: currentBaseAmount,
                                      isIncome: _isIncomeMode,
                                      currency: settings.currency,
                                      itemType: _type,
                                      initialSkippedDates: _skippedDates,
                                      initialPausedDate: _pausedDate,
                                      initialAutoResumeDate: _autoResumeDate,
                                      startDate: _startDate,
                                      viewPeriodMode: settings.viewPeriodMode,
                                      paycheckDay: settings.paycheckDay,
                                      isSalary: _isSalary,
                                    );
                                  },
                                );

                                if (result != null) {
                                  setState(() {
                                    _valueHistory = result.valueHistory;
                                    _skippedDates = result.skippedDates;
                                    _pausedDate = result.pausedDate;
                                    _autoResumeDate = result.autoResumeDate;
                                  });
                                }
                              }
                            },
                            icon: const Icon(Icons.calendar_month, size: 20),
                            label: Builder(
                              builder: (context) {
                                final isEnvelope =
                                    _type == PulseType.spendingEnvelope;
                                final hasModifications =
                                    _valueHistory.isNotEmpty ||
                                        _skippedDates.isNotEmpty ||
                                        _pausedDate != null;
                                final fallbackLabel = _isSalary
                                    ? 'Paycheck Schedule'
                                    : 'Schedule';

                                if (!hasModifications) {
                                  return Text(
                                    isEnvelope
                                        ? 'Plan Monthly Variation'
                                        : fallbackLabel,
                                  );
                                }
                                // Count modifications
                                final changesCount = _valueHistory
                                    .where(
                                      (c) =>
                                          c.amountMinorUnits.abs() !=
                                          _baseAmount.abs(),
                                    )
                                    .length;
                                final skipCount = _skippedDates.length +
                                    (_pausedDate != null ? 1 : 0);
                                final totalMods = changesCount + skipCount;
                                final buttonLabel = isEnvelope
                                    ? 'Manage Schedule'
                                    : fallbackLabel;
                                return Text('$buttonLabel ($totalMods)');
                              },
                            ),
                            style: FilledButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                  AppConstants.radiusButton,
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (_valueHistory.isNotEmpty ||
                            _skippedDates.isNotEmpty ||
                            _pausedDate != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 8, left: 4),
                            child: Builder(
                              builder: (context) {
                                final isEnvelope =
                                    _type == PulseType.spendingEnvelope;
                                if (isEnvelope) {
                                  return Text(
                                    'Amount varies by month based on plan.',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: colorScheme.primary,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  );
                                }
                                // Build description for non-envelope items
                                final parts = <String>[];
                                if (_valueHistory.isNotEmpty) {
                                  parts.add('amount changes');
                                }
                                if (_skippedDates.isNotEmpty) {
                                  parts.add('${_skippedDates.length} skipped');
                                }
                                if (_pausedDate != null) {
                                  parts.add('paused');
                                }
                                return Text(
                                  'Has ${parts.join(', ')}.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: colorScheme.primary,
                                    fontStyle: FontStyle.italic,
                                  ),
                                );
                              },
                            ),
                          ),
                        const SizedBox(height: 24),
                      ],

                      // Validation error (inline, visible inside the sheet)
                      if (_saveValidationError != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            _saveValidationError!,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: colorScheme.error,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),

                      // Save button
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            FilledButton(
                              onPressed: _handleSave,
                              style: FilledButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 18,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(
                                    AppConstants.radiusButton,
                                  ),
                                ),
                              ),
                              child: Text(
                                widget.existing != null
                                    ? (l10n?.save ?? 'Save')
                                    : (l10n?.add ?? 'Add'),
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            if (_isEditMode && widget.onDelete != null) ...[
                              const SizedBox(height: 12),
                              TextButton(
                                onPressed: _confirmDelete,
                                style: TextButton.styleFrom(
                                  foregroundColor: colorScheme.error,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 18,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                      AppConstants.radiusButton,
                                    ),
                                  ),
                                ),
                                child: Text(
                                  l10n?.delete ?? 'Delete',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmDelete() async {
    final l10n = AppLocalizations.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n?.delete ?? 'Delete'),
        content: Text(
          l10n?.deleteConfirmationMessage(widget.existing?.label ?? '') ??
              'Are you sure you want to delete this item?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(l10n?.cancel ?? 'Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: Text(l10n?.delete ?? 'Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      widget.onDelete?.call();
      Navigator.pop(context); // Close the sheet
    }
  }

  void _switchToExpenseMode() async {
    if (_isIncomeMode) {
      // Show warning in edit mode
      if (_isEditMode) {
        final l10n = AppLocalizations.of(context);
        final proceed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Change Type'),
            content: const Text(
              'Changing from income to expense may affect your balance calculations. '
              'Existing payment records will not be updated.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(l10n?.cancel ?? 'Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Continue'),
              ),
            ],
          ),
        );
        if (proceed != true) return;
      }
      setState(() {
        _type = _type == PulseType.oneOffIncome
            ? PulseType.oneOff
            : PulseType.recurring;
        if (_type != PulseType.oneOff) {
          _frequency ??= RecurrenceFrequency.monthly;
        }
      });
    }
  }

  void _switchToIncomeMode() async {
    if (!_isIncomeMode) {
      // Show warning in edit mode
      if (_isEditMode) {
        final l10n = AppLocalizations.of(context);
        final proceed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Change Type'),
            content: const Text(
              'Changing from expense to income may affect your balance calculations. '
              'Existing payment records will not be updated.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(l10n?.cancel ?? 'Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Continue'),
              ),
            ],
          ),
        );
        if (proceed != true) return;
      }
      setState(() {
        _type = _type == PulseType.oneOff
            ? PulseType.oneOffIncome
            : PulseType.recurringIncome;
        if (_type != PulseType.oneOffIncome) {
          _frequency ??= RecurrenceFrequency.monthly;
        }
      });
    }
  }

  void _selectSubtype(PulseType type) {
    setState(() {
      _type = type;
      if (type == PulseType.oneOff || type == PulseType.oneOffIncome) {
        _frequency = null;
      } else {
        _frequency ??= RecurrenceFrequency.monthly;
      }
    });
  }

  Future<void> _pickStartDate() async {
    // Use custom MonthYearPickerSheet to select only Month and Year
    // This returns the 1st of the selected month
    final picked = await showModalBottomSheet<DateTime>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final store = ExpenseStoreScope.read(context);
        final isEnvelopeInPaycheck = _type == PulseType.spendingEnvelope &&
            store.currentAccount.viewPeriodMode == ViewPeriodMode.paycheck;

        return MonthYearPickerSheet(
          initialDate: _startDate,
          firstDate: DateTime(2000),
          lastDate: DateTime(2100),
          title: isEnvelopeInPaycheck ? 'Select Start Period' : null,
        );
      },
    );

    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  Future<void> _handleSave() async {
    final label = _labelController.text.trim();

    final rawAmountCents = tryParseMoneyToCents(_amountController.text);
    final dayText = _dayController.text.trim();
    // For spending envelopes, use day 1 as default if not provided
    final day = (_type == PulseType.spendingEnvelope && dayText.isEmpty)
        ? 1
        : int.tryParse(dayText);

    // Validate all inputs at once
    String? validationError = TimelineItemFormValidation.validateSaveInputs(
      label: label,
      amountMinorUnits: rawAmountCents,
      dayText: dayText,
      dayValidationError: _dayValidationError,
      context: context,
      pulseType: _type,
      // Debt-specific validation: require exchange rate for foreign currency debts
      balanceCurrency: _balanceCurrency,
      exchangeRate: double.tryParse(_exchangeRateController.text),
    );

    if (validationError != null) {
      setState(() => _saveValidationError = validationError);
      return;
    }

    // Clear any previous validation error on successful save
    _saveValidationError = null;

    // day and rawAmountCents must be non-null at this point due to validation
    if (day == null || rawAmountCents == null) {
      throw StateError('Internal error: invalid form validation state');
    }

    // If history is used, we sort it before saving
    if (_valueHistory.isNotEmpty) {
      _valueHistory.sort((a, b) => a.effectiveDate.compareTo(b.effectiveDate));
    }

    // Apply rounding
    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    // Determine FX fields for foreign currency debts.
    // When balanceCurrency is set:
    //   - amountMinorUnits = settlement amount (app currency) — what affects balance
    //   - transactionCurrency = loan currency
    //   - transactionAmountMinorUnits = loan-currency instalment
    final bool hasFxDebt = _type == PulseType.debt && _balanceCurrency != null;

    final int effectiveAmountCents;
    AppCurrency? txCurrency;
    int? txAmountMinorUnits;

    if (hasFxDebt) {
      // Settlement amount from the auto-calculated field
      final rawSettlementCents = tryParseMoneyToCents(
        _settlementAmountController.text,
      );
      if (rawSettlementCents == null || rawSettlementCents == 0) {
        final messenger = ScaffoldMessenger.of(context);
        messenger.clearSnackBars();
        messenger.showSnackBar(
          const SnackBar(
            content: Text(
              'Settlement amount is required for foreign currency debts',
            ),
            duration: Duration(seconds: 2),
          ),
        );
        return;
      }
      effectiveAmountCents = roundUpToIncrement(
        rawSettlementCents,
        settings.roundingIncrement * 100,
      );
      txCurrency = _balanceCurrency;
      txAmountMinorUnits = _isIncomeMode ? finalAmountCents : -finalAmountCents;
    } else {
      effectiveAmountCents = finalAmountCents;
    }

    // Apply sign based on income/expense mode
    // Income types are positive, expense types are negative
    final amountMinorUnits =
        _isIncomeMode ? effectiveAmountCents : -effectiveAmountCents;

    final remainingBalanceMinorUnits =
        (_type == PulseType.debt || _selectedMoneyPotId != null)
            ? tryParseMoneyToCents(_remainingBalanceController.text)
            : null;

    // Determine finalMoneyPotId synchronously (generate ID now, create pot later)
    MoneyPotId? finalMoneyPotId = _selectedMoneyPotId;
    final needsNewMoneyPot =
        _selectedMoneyPotId == const MoneyPotId('enable_smart_tracking') ||
            _selectedMoneyPotId == _kNewMoneyPotId;
    if (needsNewMoneyPot) {
      finalMoneyPotId = newMoneyPotId();
    }

    // Build result SYNCHRONOUSLY - no awaits that can break the flow
    final result = widget.existing == null
        ? TimelineItem(
            id: newTimelineItemId(),
            label: label,
            amountMinorUnits: amountMinorUnits,
            dayOfMonth: day,
            type: _type,
            startDate: DateTime.utc(_startDate.year, _startDate.month, day),
            frequency: _frequency,
            notes: _notesController.text.trim().isEmpty
                ? null
                : _notesController.text.trim(),
            archived: false,
            paidOffDate: null,
            remainingBalanceMinorUnits: remainingBalanceMinorUnits,
            originalAmountMinorUnits:
                _type == PulseType.debt ? remainingBalanceMinorUnits : null,
            category: _selectedCategory,
            subcategory: _selectedSubcategory,
            origin: _originController.text.trim().isEmpty
                ? null
                : _originController.text.trim(),
            isSalary: _isSalary && _type == PulseType.recurringIncome,
            moneyPotId:
                needsNewMoneyPot ? finalMoneyPotId : _selectedMoneyPotId,
            balanceCurrency: _type == PulseType.debt ? _balanceCurrency : null,
            exchangeRate: _type == PulseType.debt && _balanceCurrency != null
                ? double.tryParse(_exchangeRateController.text)
                : null,
            transactionCurrency: txCurrency,
            transactionAmountMinorUnits: txAmountMinorUnits,
            useActualsForCurrentBalance: _type == PulseType.spendingEnvelope
                ? _useActualsForCurrentBalance
                : null,
            useActualsForFutureBalance: _type == PulseType.spendingEnvelope
                ? _useActualsForFutureBalance
                : null,
            quickAddAmounts: _quickAddAmounts,
            valueHistory: _valueHistory.isEmpty ? null : _valueHistory,
            skippedDates: _skippedDates.isEmpty ? null : _skippedDates,
            pausedDate: _pausedDate,
            autoResumeDate: _autoResumeDate,
          )
        : widget.existing!.copyWith(
            label: label,
            amountMinorUnits: amountMinorUnits,
            dayOfMonth: day,
            type: _type,
            frequency: Optional(_frequency),
            startDate: DateTime.utc(_startDate.year, _startDate.month, day),
            notes: _notesController.text.trim().isEmpty
                ? const Optional.absent()
                : Optional.value(_notesController.text.trim()),
            paidOffDate:
                _isPaidOff ? Optional(DateTime.now()) : const Optional.absent(),
            remainingBalanceMinorUnits: Optional(remainingBalanceMinorUnits),
            category: Optional(_selectedCategory),
            subcategory: Optional(_selectedSubcategory),
            origin: _originController.text.trim().isEmpty
                ? const Optional.absent()
                : Optional.value(_originController.text.trim()),
            isSalary: _isSalary && _type == PulseType.recurringIncome,
            moneyPotId: needsNewMoneyPot
                ? Optional(finalMoneyPotId)
                : Optional(_selectedMoneyPotId),
            balanceCurrency: _type == PulseType.debt
                ? Optional(_balanceCurrency)
                : const Optional.absent(),
            exchangeRate: _type == PulseType.debt && _balanceCurrency != null
                ? Optional(double.tryParse(_exchangeRateController.text))
                : const Optional.absent(),
            transactionCurrency:
                hasFxDebt ? Optional(txCurrency) : const Optional.absent(),
            transactionAmountMinorUnits: hasFxDebt
                ? Optional(txAmountMinorUnits)
                : const Optional.absent(),
            useActualsForCurrentBalance: _type == PulseType.spendingEnvelope
                ? Optional(_useActualsForCurrentBalance)
                : const Optional.absent(),
            useActualsForFutureBalance: _type == PulseType.spendingEnvelope
                ? Optional(_useActualsForFutureBalance)
                : const Optional.absent(),
            suggestedOrigins: Optional(_suggestedOrigins),
            quickAddAmounts: Optional(_quickAddAmounts),
            valueHistory: _valueHistory.isEmpty
                ? const Optional.absent()
                : Optional(_valueHistory),
            skippedDates: _skippedDates.isEmpty
                ? const Optional.absent()
                : Optional(_skippedDates),
            pausedDate: Optional(_pausedDate),
            autoResumeDate: Optional(_autoResumeDate),
          );

    // CRITICAL: Pop the result IMMEDIATELY - before any async side-effects.
    // This guarantees the item is returned to PulseScreen and saved.
    if (mounted) {
      Navigator.pop(context, result);
    }

    // ---- FIRE-AND-FORGET SIDE EFFECTS (run after pop) ----
    // These operations happen after the sheet is dismissed. If any fail,
    // the item is still saved. User can fix Money Pot issues later.

    // Create new Money Pot if needed
    if (needsNewMoneyPot && finalMoneyPotId != null) {
      final currentAccountId = ExpenseStoreScope.read(
        context,
      ).currentAccount.id;
      // For debts, use user-selected pot currency (defaults to debt's balance currency)
      // If pot currency is null, pot tracks in app currency
      final potCurrencyToUse = _type == PulseType.debt ? _potCurrency : null;

      final rawRate = double.tryParse(_exchangeRateController.text);

      // Calculate amount for the pot:
      // If pot currency matches loan currency, use the raw remaining balance.
      // If pot currency is App Currency and loan is foreign, convert balance using the rate.
      int potAmount = remainingBalanceMinorUnits ?? 0;
      double? potExchangeRate;

      if (_type == PulseType.debt &&
          _balanceCurrency != null &&
          rawRate != null &&
          rawRate > 0) {
        if (potCurrencyToUse == null || potCurrencyToUse == settings.currency) {
          // App Currency Pot: Balance / Rate (e.g. 1000 GBP / 0.83 = 1204 EUR)
          potAmount = (potAmount / rawRate).round();
        } else if (potCurrencyToUse == _balanceCurrency) {
          // Foreign Currency Pot: Amount stays same, but we need INVERTED rate for net worth
          // 1 GBP = ? EUR => (1 / rawRate)
          potExchangeRate = 1.0 / rawRate;
        }
      }

      final newPot = MoneyPot(
        id: finalMoneyPotId,
        name: label,
        amountMinorUnits: potAmount,
        type: MoneyPotType.debt,
        isSystemManaged: true,
        accountIds: [currentAccountId],
        currency: potCurrencyToUse,
        exchangeRate: potExchangeRate,
      );
      settings.addMoneyPot(newPot);
    } else if (_selectedMoneyPotId != null && !needsNewMoneyPot) {
      // Update the pot linked to this item
      final pot = settings.moneyPots.firstWhereOrNull(
        (p) => p.id == _selectedMoneyPotId,
      );
      if (pot != null) {
        final needsNameUpdate = pot.name != label;
        final rawRate = double.tryParse(_exchangeRateController.text);

        int potAmount = remainingBalanceMinorUnits ?? pot.amountMinorUnits;
        AppCurrency? newPotCurrency =
            _type == PulseType.debt ? _potCurrency : pot.currency;
        double? newPotExchangeRate;

        if (_type == PulseType.debt &&
            _balanceCurrency != null &&
            rawRate != null &&
            rawRate > 0) {
          if (newPotCurrency == null || newPotCurrency == settings.currency) {
            potAmount = (potAmount / rawRate).round();
          } else if (newPotCurrency == _balanceCurrency) {
            newPotExchangeRate = 1.0 / rawRate;
          }
        }

        final needsBalanceUpdate = pot.amountMinorUnits != potAmount;
        final needsCurrencyUpdate = pot.currency != newPotCurrency ||
            pot.exchangeRate != newPotExchangeRate;
        final needsTypeUpdate = pot.type == MoneyPotType.savings;

        if (needsNameUpdate ||
            needsBalanceUpdate ||
            needsTypeUpdate ||
            needsCurrencyUpdate) {
          final currentAccountId = ExpenseStoreScope.read(
            context,
          ).currentAccount.id;
          final potAccountIds = pot.accountIds;
          final updatedPot = MoneyPot(
            id: pot.id,
            name: needsNameUpdate ? label : pot.name,
            amountMinorUnits: potAmount,
            type: needsTypeUpdate ? MoneyPotType.debt : pot.type,
            currency: newPotCurrency,
            accountIds: (needsTypeUpdate &&
                    (potAccountIds == null || potAccountIds.isEmpty))
                ? [currentAccountId]
                : pot.accountIds,
            isSystemManaged: pot.isSystemManaged,
            showInAppCurrency: pot.showInAppCurrency,
            exchangeRate: newPotExchangeRate,
          );
          settings.updateMoneyPot(updatedPot);
        }
      }
    }

    // CLEANUP: If we unlinked a Money Pot, check if it's orphaned
    if (widget.existing != null) {
      final oldPotId = widget.existing!.moneyPotId;
      final newPotId = result.moneyPotId;

      if (oldPotId != null && newPotId != oldPotId) {
        final store = ExpenseStoreScope.read(context);
        final isUsedByOthers = store.activeTimelineItems.any(
          (i) => i.moneyPotId == oldPotId && i.id != result.id,
        );

        if (!isUsedByOthers) {
          settings.removeMoneyPot(oldPotId); // Fire-and-forget
        }
      }
    }

    // If it's a salary item, show the paycheck sync dialog
    if (result.isSalary) {
      _showPaycheckSyncDialog(result);
    }
  }

  Future<void> _showPaycheckSyncDialog(TimelineItem salaryItem) async {
    final dayNum = salaryItem.dayOfMonth;
    final dayStr = dayNum == 1
        ? '1st'
        : dayNum == 2
            ? '2nd'
            : dayNum == 3
                ? '3rd'
                : dayNum == 21
                    ? '21st'
                    : dayNum == 22
                        ? '22nd'
                        : dayNum == 23
                            ? '23rd'
                            : dayNum == 31
                                ? '31st'
                                : '${dayNum}th';

    if (!mounted) return;

    final l10n = AppLocalizations.of(context);
    final shouldSync = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n?.syncPaycheckTitle ?? 'Sync Paycheck'),
        content: Text(
          l10n?.syncPaycheckMessage(dayStr) ??
              'Would you like to sync your paycheck date?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(l10n?.noThanks ?? 'No Thanks'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(l10n?.syncAction ?? 'Sync'),
          ),
        ],
      ),
    );

    if (shouldSync == true && mounted) {
      final settings = AppSettingsScope.read(context);
      settings.paycheckDay = salaryItem.dayOfMonth;
    }
  }

  Future<void> _showQuickAmountsEditDialog() async {
    final settings = AppSettingsScope.read(context);
    final currentAmounts = _quickAddAmounts ?? settings.customQuickAddAmounts;

    final controllers = List.generate(6, (index) {
      final amount = index < currentAmounts.length ? currentAmounts[index] : 0;
      final amountMajor = amount / 100.0;
      final text = amountMajor == amountMajor.truncateToDouble()
          ? amountMajor.truncate().toString()
          : amountMajor.toString();
      return TextEditingController(text: text);
    });

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Quick Spend Amounts'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Set the 6 quick access amounts for this envelope.'),
              const SizedBox(height: 16),
              ...List.generate(controllers.length, (index) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: TextField(
                    controller: controllers[index],
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: InputDecoration(
                      labelText: 'Amount ${index + 1}',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          if (_quickAddAmounts != null)
            TextButton(
              onPressed: () {
                setState(() => _quickAddAmounts = null);
                Navigator.pop(ctx);
              },
              child: const Text('Reset to Default'),
            ),
          FilledButton(
            onPressed: () {
              final newAmounts = <int>[];
              for (final controller in controllers) {
                final text = controller.text.trim();
                final val = double.tryParse(text);
                if (val != null) {
                  newAmounts.add((val * 100).round());
                } else {
                  newAmounts.add(0);
                }
              }
              setState(() => _quickAddAmounts = newAmounts);
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    for (final c in controllers) {
      c.dispose();
    }
  }

  void _onMoneyPotChanged(MoneyPotId? value) {
    if (value == const MoneyPotId('enable_smart_tracking')) {
      // Smart Tracking: Try to find a pot with same name (case-insensitive)
      // If found -> select it.
      // If not found -> select Create New.
      final settings = AppSettingsScope.read(context);
      final itemName = _labelController.text.trim().toLowerCase();

      MoneyPot? match;
      if (itemName.isNotEmpty) {
        // Simple case-insensitive match on name
        try {
          match = settings.moneyPots.firstWhere(
            (p) => p.name.trim().toLowerCase() == itemName,
          );
        } catch (_) {
          // No match found
        }
      }

      setState(() {
        _selectedMoneyPotId = match?.id ?? _kNewMoneyPotId;
      });
    } else {
      // Standard selection
      setState(() {
        _selectedMoneyPotId = value;

        // If user manually switched to a specific pot (and it's not "New"),
        // we might want to sync Debt Fields (Remaining Balance) if we were in Debt mode.
        // Even if we are in Recurring mode, it doesn't hurt to have the logic here.
        if (value != _kNewMoneyPotId && value != null) {
          final settings = AppSettingsScope.read(context);
          try {
            final pot = settings.moneyPots.firstWhere((p) => p.id == value);
            // Only update text if empty or different?
            // Standard behavior was to overwrite.
            _remainingBalanceController.text =
                (pot.amountMinorUnits / 100).toStringAsFixed(2);
          } catch (_) {
            // MoneyPot not found, ignore
          }
        }
      });
    }
  }
}
