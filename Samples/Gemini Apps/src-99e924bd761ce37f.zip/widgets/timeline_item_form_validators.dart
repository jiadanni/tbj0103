import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/util/validation.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';

/// Result of day-of-month validation.
///
/// [dayError] is set if validation failed, [dayInfoMessage] is set for
/// informational messages (e.g., "This day doesn't exist in February").
class DayValidationResult {
  final String? dayError;
  final String? dayInfoMessage;

  const DayValidationResult({
    required this.dayError,
    required this.dayInfoMessage,
  });
}

/// Validation logic for the timeline item form.
///
/// Provides static methods for validating individual fields and enforcing
/// constraints on pulse amounts based on pulse type.
class TimelineItemFormValidation {
  TimelineItemFormValidation._(); // Prevent instantiation

  /// Validates the day-of-month input.
  ///
  /// Returns a DayValidationResult with error and/or info messages.
  /// Days > 28 trigger an info message about month-end handling.
  static DayValidationResult validateDay(String text, BuildContext context) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.required,
        dayInfoMessage: null,
      );
    }

    final day = int.tryParse(trimmed);

    if (day == null) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.enterValidNumber,
        dayInfoMessage: null,
      );
    }

    if (day < 1 || day > 31) {
      return DayValidationResult(
        dayError: AppLocalizations.of(context)!.dayOutOfRange,
        dayInfoMessage: null,
      );
    }

    if (day > 28) {
      return DayValidationResult(
        dayError: null,
        dayInfoMessage: AppLocalizations.of(
          context,
        )!
            .pulseScheduledLastDay(day),
      );
    }

    return const DayValidationResult(dayError: null, dayInfoMessage: null);
  }

  /// Validates that the amount is within acceptable bounds.
  ///
  /// Returns an error message if validation fails, null otherwise.
  static String? validateAmountBounds(
    int amountMinorUnits, {
    bool allowZero = false,
  }) {
    return validateAmountMinorUnits(amountMinorUnits, allowZero: allowZero);
  }

  /// Validates all required inputs for saving a timeline item.
  ///
  /// Checks that label, amount, and day are provided and valid.
  /// Day is optional for spending envelopes.
  /// For debts with foreign balance currency, exchange rate is required.
  /// Returns an error message if any validation fails, null if all valid.
  static String? validateSaveInputs({
    required String label,
    required int? amountMinorUnits,
    required String dayText,
    required String? dayValidationError,
    required BuildContext context,
    PulseType? pulseType,
    // Debt-specific validation
    dynamic balanceCurrency,
    double? exchangeRate,
  }) {
    // Spending envelopes don't require a day
    final isDayRequired = pulseType != PulseType.spendingEnvelope;

    if (label.isEmpty || amountMinorUnits == null) {
      return AppLocalizations.of(context)!.enterNameAmountDay;
    }

    if (isDayRequired && dayText.isEmpty) {
      return AppLocalizations.of(context)!.enterNameAmountDay;
    }

    final amountError = validateAmountMinorUnits(
      amountMinorUnits.abs(),
      allowZero: pulseType == PulseType.spendingEnvelope,
    );
    if (amountError != null) {
      return amountError;
    }

    if (isDayRequired && dayValidationError != null) {
      return dayValidationError;
    }

    if (isDayRequired) {
      final day = int.tryParse(dayText.trim());
      if (day != null && (day < 1 || day > 31)) {
        return AppLocalizations.of(context)!.dayOutOfRange;
      }
    }

    // Debt-specific: If balance currency is set, exchange rate is required
    if (pulseType == PulseType.debt &&
        balanceCurrency != null &&
        (exchangeRate == null || exchangeRate <= 0)) {
      return 'Exchange rate is required when debt is in a foreign currency';
    }

    return null;
  }

  /// Enforces the correct sign for an amount based on pulse type.
  ///
  /// Income types must be positive, expense types must be negative.
  /// Debt amounts stay positive (they represent pulse amounts).
  /// Modifies the controller's text if the sign is incorrect.
  static void enforceAmountSign(
    TextEditingController controller,
    PulseType type,
  ) {
    final text = controller.text.trim();
    if (text.isEmpty) return;

    final amount = double.tryParse(text);
    if (amount == null) return;

    final shouldBePositive = type.isIncomeType;
    final isPositive = amount > 0;
    final isNegative = amount < 0;

    String? nextText;
    if (shouldBePositive && isNegative) {
      nextText = text.replaceFirst(RegExp(r'^-+'), '');
    } else if (!shouldBePositive && isPositive && type != PulseType.debt) {
      nextText = '-$text';
    }
    // Note: Debt amounts stay positive (they represent pulse amounts)

    if (nextText == null || nextText == text) return;
    controller.value = controller.value.copyWith(
      text: nextText,
      selection: TextSelection.collapsed(offset: nextText.length),
      composing: TextRange.empty,
    );
  }
}
