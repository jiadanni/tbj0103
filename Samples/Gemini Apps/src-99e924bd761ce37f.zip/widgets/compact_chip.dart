import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

/// Compact filter chip with optional icon
class CompactChip extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool isSelected;
  final bool usePrimaryColor;
  final bool small;
  final VoidCallback onTap;

  const CompactChip({
    super.key,
    required this.label,
    this.icon,
    required this.isSelected,
    this.usePrimaryColor = false,
    this.small = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final bgColor = isSelected
        ? (usePrimaryColor
            ? colorScheme.primaryContainer
            : colorScheme.secondaryContainer)
        : Colors.transparent;

    final borderColor = isSelected
        ? (usePrimaryColor ? colorScheme.primary : colorScheme.secondary)
        : colorScheme.outlineVariant;

    final textColor = isSelected
        ? (usePrimaryColor
            ? colorScheme.onPrimaryContainer
            : colorScheme.onSecondaryContainer)
        : colorScheme.onSurfaceVariant;

    final hPad = small ? 8.0 : 10.0;
    final vPad = small ? 6.0 : 8.0;
    final iconSize = small ? 12.0 : 14.0;
    final textStyle =
        small ? theme.textTheme.labelSmall : theme.textTheme.labelMedium;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: EdgeInsets.symmetric(horizontal: hPad, vertical: vPad),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
          border: Border.all(color: borderColor, width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null && !small) ...[
              PhosphorIcon(icon!, size: iconSize, color: textColor),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: textStyle?.copyWith(
                color: textColor,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
            if (isSelected && !small) ...[
              const SizedBox(width: 4),
              PhosphorIcon(PhosphorIcons.check(), size: 12, color: textColor),
            ],
          ],
        ),
      ),
    );
  }
}
