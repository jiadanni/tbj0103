import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/util/debt_calculator.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:intl/intl.dart';

class PaymentScheduleDialog extends StatelessWidget {
  const PaymentScheduleDialog({
    super.key,
    required this.item,
    required this.settings,
  });

  final TimelineItem item;
  final AppSettingsStore settings;

  @override
  Widget build(BuildContext context) {
    // Only works for debt items
    if (item.type != PulseType.debt ||
        item.remainingBalanceMinorUnits == null) {
      return const SizedBox.shrink();
    }

    // Calculate schedule
    final schedule = DebtCalculator.calculatePaymentSchedule(
      type: item.type,
      remainingBalanceMinorUnits: item.remainingBalanceMinorUnits,
      amountMinorUnits: item.amountMinorUnits,
      frequency: item.frequency,
      startDate: item.startDate,
      // exchangeRate: item.exchangeRate, // removed
    );

    if (schedule == null || schedule.isEmpty) {
      return AlertDialog(
        title: const Text('Payment Schedule'),
        content: const Text(
          'Unable to calculate payment schedule. Please check the amount and frequency.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      );
    }

    final theme = Theme.of(context);
    final currency = item.balanceCurrency ?? settings.currency;
    final dateFormat = DateFormat.yMMMMd();

    return AlertDialog(
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Payment Schedule', style: theme.textTheme.headlineSmall),
          const SizedBox(height: 4),
          Text(
            '${schedule.length} remaining payments',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: schedule.length,
          separatorBuilder: (context, index) => const Divider(height: 1),
          itemBuilder: (context, index) {
            final entry = schedule[index];
            return ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                radius: 12,
                backgroundColor: theme.colorScheme.surfaceContainerHighest,
                child: Text(
                  '${entry.paymentNumber}',
                  style: theme.textTheme.labelSmall?.copyWith(fontSize: 10),
                ),
              ),
              title: Text(
                dateFormat.format(entry.date),
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                'Balance: ${formatMoneyFromCents(entry.remainingBalanceAfter, currency, showCents: settings.showCents)}',
                style: theme.textTheme.bodySmall,
              ),
              trailing: Text(
                formatMoneyFromCents(
                  entry.paymentAmount,
                  currency,
                  showCents: settings.showCents,
                ),
                style: theme.textTheme.titleSmall?.copyWith(
                  color: theme.colorScheme.primary,
                ),
              ),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}
