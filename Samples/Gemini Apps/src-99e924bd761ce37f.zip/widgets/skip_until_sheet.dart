import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/models/timeline_item.dart';
import 'package:expense_stalker_mobile/src/util/dates.dart';
import 'package:expense_stalker_mobile/src/util/month_arithmetic.dart'
    as month_math;

class SkipUntilSheet extends StatelessWidget {
  const SkipUntilSheet({
    super.key,
    required this.item,
    required this.currentMonth,
  });

  final TimelineItem item;
  final DateTime currentMonth;

  @override
  Widget build(BuildContext context) {
    // Generate valid future occurrences
    final occurrences = _generateOccurrences(item, currentMonth);

    return DraggableScrollableSheet(
      initialChildSize: 0.5,
      minChildSize: 0.3,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Column(
          children: [
            // Drag handle
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 32,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.outlineVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Skip Until...',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            if (occurrences.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text('No future occurrences found.'),
              )
            else
              Expanded(
                child: ListView.separated(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: occurrences.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final date = occurrences[index];
                    return ListTile(
                      title: Text('Resume on ${monthLabel(date)}'),
                      subtitle: Text(
                        'Skips ${index + 1} occurrence${index + 1 > 1 ? 's' : ''}',
                      ),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        Navigator.pop(context, date);
                      },
                    );
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  List<DateTime> _generateOccurrences(TimelineItem item, DateTime startMonth) {
    final results = <DateTime>[];
    if (item.frequency == null) return results;

    // Start looking from NEXT month relative to current
    var candidate = month_math.addMonths(startMonth, 1);

    // Generate up to 24 future occurrences
    int safetyCounter = 0;
    while (results.length < 24 && safetyCounter < 100) {
      if (item.shouldAppearInMonth(candidate)) {
        results.add(candidate);
      }
      candidate = month_math.addMonths(candidate, 1);
      safetyCounter++;
    }

    return results;
  }
}
