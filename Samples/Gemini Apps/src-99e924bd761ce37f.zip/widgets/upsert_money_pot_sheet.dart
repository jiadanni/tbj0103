import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/models/money_pot.dart';
import 'package:expense_stalker_mobile/src/util/validation.dart';
import 'package:expense_stalker_mobile/src/models/currency.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/optional.dart';
import 'package:expense_stalker_mobile/src/util/terminology.dart';
import 'package:flutter/services.dart';

class UpsertMoneyPotSheet extends StatefulWidget {
  const UpsertMoneyPotSheet({super.key, this.initialPot});

  final MoneyPot? initialPot;

  @override
  State<UpsertMoneyPotSheet> createState() => _UpsertMoneyPotSheetState();
}

class _UpsertMoneyPotSheetState extends State<UpsertMoneyPotSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _amountController;
  late TextEditingController _exchangeRateController;
  late MoneyPotType _selectedType;
  AppCurrency? _selectedCurrency;
  List<AccountId>? _selectedAccountIds;
  late bool _showInAppCurrency;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initialPot?.name);

    final initialAmount = widget.initialPot?.amountMinorUnits != null
        ? (widget.initialPot!.amountMinorUnits / 100.0).toStringAsFixed(2)
        : '';
    _amountController = TextEditingController(text: initialAmount);

    _selectedType = widget.initialPot?.type ?? MoneyPotType.savings;
    _selectedCurrency = widget.initialPot?.currency;
    _selectedAccountIds = widget.initialPot?.accountIds;
    _showInAppCurrency = widget.initialPot?.showInAppCurrency ?? false;
    _exchangeRateController = TextEditingController(
      text: widget.initialPot?.exchangeRate?.toString() ?? '',
    );

    // Enforce non-global for debt pots (legacy data fix)
    if (_selectedType == MoneyPotType.debt &&
        (_selectedAccountIds == null || _selectedAccountIds!.isEmpty)) {
      // Since we are in initState, we can't use context for ExpenseStoreScope yet safely in all cases,
      // but for a sheet it's usually fine. However, we'll wait until build if needed or just use a default.
      // Actually, let's do it in a post-frame callback or just handle it in build.
      // Better: handle it in build or use the context-independent way if possible.
      // For now, let's just use the current account from the store.
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_selectedType == MoneyPotType.debt &&
        (_selectedAccountIds == null || _selectedAccountIds!.isEmpty)) {
      final currentAccountId = ExpenseStoreScope.read(
        context,
      ).currentAccount.id;
      setState(() {
        _selectedAccountIds = [currentAccountId];
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    _exchangeRateController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final amountString = _amountController.text.trim();
      final amountDouble = double.tryParse(amountString) ?? 0.0;
      final amountMinorUnits = (amountDouble * 100).round();

      final pot = widget.initialPot?.copyWith(
            name: name,
            amountMinorUnits: amountMinorUnits,
            type: _selectedType,
            currency: Optional(_selectedCurrency),
            accountIds: Optional(_selectedAccountIds),
            showInAppCurrency: _showInAppCurrency,
            exchangeRate: Optional(
              double.tryParse(_exchangeRateController.text.trim()),
            ),
          ) ??
          MoneyPot.create(
            name: name,
            amountMinorUnits: amountMinorUnits,
            type: _selectedType,
            currency: _selectedCurrency,
            accountIds: _selectedAccountIds,
            showInAppCurrency: _showInAppCurrency,
            exchangeRate: double.tryParse(_exchangeRateController.text.trim()),
          );

      Navigator.of(context).pop(pot);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final settings = AppSettingsScope.of(context);
    final isEditing = widget.initialPot != null;

    // Use theme-aware colors from the palette
    final surface = colorScheme.surface;
    final surfaceContainer = colorScheme.surfaceContainerHigh;
    final border = colorScheme.outlineVariant;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;

    InputDecoration outlinedInput(String label, {String? hintText}) {
      return InputDecoration(
        labelText: label,
        hintText: hintText,
        labelStyle: TextStyle(color: textSecondary, fontSize: 12),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        filled: true,
        fillColor: surface,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 12,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
          borderSide: BorderSide(color: theme.colorScheme.primary, width: 1.5),
        ),
      );
    }

    return Material(
      color: Colors.transparent,
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Title
                Text(
                  isEditing
                      ? 'Edit ${Terminology.of(context).potLabel}'
                      : 'New ${Terminology.of(context).potLabel}',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: textPrimary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),

                // Name & Balance in a row
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Name field
                      Expanded(
                        flex: 3,
                        child: TextFormField(
                          controller: _nameController,
                          style: TextStyle(color: textPrimary, fontSize: 14),
                          decoration: outlinedInput(
                            'Name',
                            hintText: 'e.g. Vacation',
                          ),
                          validator: (value) => validateLabel(value, 'Name'),
                          textCapitalization: TextCapitalization.sentences,
                          readOnly:
                              isEditing && _selectedType == MoneyPotType.debt,
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Balance field
                      Expanded(
                        flex: 2,
                        child: TextFormField(
                          controller: _amountController,
                          style: TextStyle(color: textPrimary, fontSize: 14),
                          decoration: outlinedInput('Balance'),
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(
                              RegExp(r'^\d+\.?\d{0,2}'),
                            ),
                          ],
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Type & Currency in a row
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Type buttons
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Type',
                              style: TextStyle(
                                color: textSecondary,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            SizedBox(
                              width: double.infinity,
                              child: SegmentedButton<MoneyPotType>(
                                segments: const [
                                  ButtonSegment(
                                    value: MoneyPotType.savings,
                                    label: Text(
                                      'Savings',
                                      style: TextStyle(fontSize: 13),
                                    ),
                                    icon: Icon(
                                      Icons.savings_outlined,
                                      size: 16,
                                    ),
                                  ),
                                  ButtonSegment(
                                    value: MoneyPotType.debt,
                                    label: Text(
                                      'Debt',
                                      style: TextStyle(fontSize: 13),
                                    ),
                                    icon: Icon(
                                      Icons.account_balance_outlined,
                                      size: 16,
                                    ),
                                  ),
                                ],
                                selected: {_selectedType},
                                onSelectionChanged:
                                    (Set<MoneyPotType> newSelection) {
                                  setState(() {
                                    _selectedType = newSelection.first;
                                    if (_selectedType == MoneyPotType.debt &&
                                        (_selectedAccountIds == null ||
                                            _selectedAccountIds!.isEmpty)) {
                                      final currentAccountId =
                                          ExpenseStoreScope.read(
                                        context,
                                      ).currentAccount.id;
                                      _selectedAccountIds = [
                                        currentAccountId,
                                      ];
                                    }
                                  });
                                },
                                showSelectedIcon: false,
                                style: SegmentedButton.styleFrom(
                                  visualDensity: VisualDensity.compact,
                                  padding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  foregroundColor: colorScheme.onSurfaceVariant,
                                  selectedBackgroundColor:
                                      colorScheme.primaryContainer,
                                  selectedForegroundColor:
                                      colorScheme.onPrimaryContainer,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Currency dropdown
                      Expanded(
                        child: DropdownButtonFormField<AppCurrency?>(
                          initialValue: _selectedCurrency,
                          decoration: outlinedInput('Currency'),
                          style: TextStyle(color: textPrimary, fontSize: 14),
                          dropdownColor: surfaceContainer,
                          items: [
                            DropdownMenuItem<AppCurrency?>(
                              value: null,
                              child: Text(
                                'Default (${currencyLabel(settings.currencySettings.currency)})',
                              ),
                            ),
                            ...AppCurrency.values.where((c) {
                              return settings.currencySettings.enabledCurrencies
                                      .contains(c) ||
                                  c ==
                                      _selectedCurrency; // Always show currently selected
                            }).map((currency) {
                              return DropdownMenuItem<AppCurrency?>(
                                value: currency,
                                child: Text(currencyLabel(currency)),
                              );
                            }),
                          ],
                          onChanged: (value) {
                            setState(() => _selectedCurrency = value);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Visibility dropdown
                if (_selectedType != MoneyPotType.debt) ...[
                  DropdownButtonFormField<bool>(
                    initialValue: _selectedAccountIds == null ||
                        _selectedAccountIds!.isEmpty,
                    decoration: outlinedInput('Visibility'),
                    style: TextStyle(color: textPrimary, fontSize: 14),
                    dropdownColor: surfaceContainer,
                    items: const [
                      DropdownMenuItem(
                        value: true,
                        child: Text('Global (All Accounts)'),
                      ),
                      DropdownMenuItem(
                        value: false,
                        child: Text('Specific Accounts'),
                      ),
                    ],
                    onChanged: (isGlobal) {
                      if (isGlobal == true) {
                        setState(() => _selectedAccountIds = null);
                      } else {
                        final currentAccountId = ExpenseStoreScope.read(
                          context,
                        ).currentAccount.id;
                        setState(
                          () => _selectedAccountIds = [currentAccountId],
                        );
                      }
                    },
                  ),
                ],

                // Account chips (only when specific accounts selected and NOT a debt)
                if (_selectedAccountIds != null &&
                    _selectedType != MoneyPotType.debt) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: ExpenseStoreScope.of(context).accounts.map((
                      account,
                    ) {
                      final isSelected = _selectedAccountIds!.contains(
                        account.id,
                      );
                      return FilterChip(
                        label: Text(
                          account.name,
                          style: const TextStyle(fontSize: 12),
                        ),
                        selected: isSelected,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                        onSelected: (selected) {
                          setState(() {
                            final next = List<AccountId>.from(
                              _selectedAccountIds!,
                            );
                            if (selected) {
                              if (!next.contains(account.id)) {
                                next.add(account.id);
                              }
                            } else {
                              next.remove(account.id);
                              if (next.isEmpty) {
                                _selectedAccountIds = null;
                                return;
                              }
                            }
                            _selectedAccountIds = next;
                          });
                        },
                      );
                    }).toList(),
                  ),
                ],

                // Show in app currency toggle (for pots with foreign currency)
                if (_selectedCurrency != null &&
                    _selectedCurrency !=
                        settings.currencySettings.currency) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    title: Text(
                      'Show in ${getCurrencyInfo(settings.currencySettings.currency).code}',
                      style: TextStyle(color: textPrimary, fontSize: 14),
                    ),
                    subtitle: Text(
                      'Convert balance to app currency',
                      style: TextStyle(color: textSecondary, fontSize: 12),
                    ),
                    value: _showInAppCurrency,
                    onChanged: (value) =>
                        setState(() => _showInAppCurrency = value),
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                  ),
                  if (_showInAppCurrency) ...[
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _exchangeRateController,
                      style: TextStyle(color: textPrimary, fontSize: 14),
                      decoration: outlinedInput('Exchange Rate').copyWith(
                        hintText: 'e.g. 1.25',
                        helperText:
                            'How many ${_selectedCurrency!.name.toUpperCase()} per 1 ${settings.currencySettings.currency.name.toUpperCase()}',
                        helperStyle: TextStyle(
                          color: textSecondary,
                          fontSize: 11,
                        ),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r'^\d+\.?\d*'),
                        ),
                      ],
                      validator: (value) {
                        if (_showInAppCurrency &&
                            (value == null || value.isEmpty)) {
                          return 'Required';
                        }
                        if (value != null &&
                            value.isNotEmpty &&
                            double.tryParse(value) == null) {
                          return 'Invalid number';
                        }
                        return null;
                      },
                    ),
                  ],
                ],
                const SizedBox(height: 20),

                // Action buttons
                FilledButton(
                  onPressed: _submit,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusButton,
                      ),
                    ),
                  ),
                  child: Text(
                    isEditing ? 'Save' : 'Create',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (isEditing) ...[
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop(const DeletePotMarker());
                    },
                    style: TextButton.styleFrom(
                      foregroundColor: theme.colorScheme.error,
                    ),
                    child: const Text('Delete'),
                  ),
                ],
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DeletePotMarker {
  const DeletePotMarker();
}
