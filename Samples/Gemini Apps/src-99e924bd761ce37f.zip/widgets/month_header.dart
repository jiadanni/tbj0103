import 'package:flutter/material.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/features/timeline/helpers/paycheck_service.dart';

class MonthHeader extends StatelessWidget {
  const MonthHeader({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.read(context);
    final settings = AppSettingsScope.read(context);
    return ListenableBuilder(
      listenable: Listenable.merge([store, settings]),
      builder: (context, _) {
        final periodInfo = PaycheckService.getPeriodInfo(
          store.selectedMonth,
          settings.viewPeriodMode,
          settings.paycheckDay,
          businessAdjust: settings.paycheckBusinessAdjust,
          adjustDirection: settings.paycheckBusinessAdjustDirection,
          includeMonth: settings.paycheckShowMonthInTimeline,
        );

        return Padding(
          padding: const EdgeInsets.fromLTRB(
            AppConstants.paddingMedium,
            AppConstants.paddingNormal,
            AppConstants.paddingMedium,
            AppConstants.paddingSmall,
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: AppConstants.paddingXSmall),
                    InkWell(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusMedium,
                      ),
                      onTap: () {
                        // Jump to period containing today
                        final now = DateTime.now();
                        DateTime targetMonth;
                        if (settings.viewPeriodMode ==
                                ViewPeriodMode.paycheck &&
                            settings.paycheckDay != null) {
                          targetMonth =
                              PaycheckService.getCurrentPaycheckPeriodMonth(
                            now,
                            settings.paycheckDay!,
                            businessAdjust: settings.paycheckBusinessAdjust,
                            adjustDirection:
                                settings.paycheckBusinessAdjustDirection,
                          );
                        } else {
                          targetMonth = DateTime.utc(now.year, now.month);
                        }
                        store.setSelectedMonth(targetMonth);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 2,
                          horizontal: 4,
                        ),
                        child: Text(
                          periodInfo.label,
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onSurfaceVariant,
                                  ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Previous period',
                onPressed: store.goToPreviousMonth,
                icon: const Icon(Icons.chevron_left),
              ),
              IconButton(
                tooltip: 'Next period',
                onPressed: store.goToNextMonth,
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
        );
      },
    );
  }
}
