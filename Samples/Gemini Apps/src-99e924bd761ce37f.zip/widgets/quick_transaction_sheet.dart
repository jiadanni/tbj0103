import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:expense_stalker_mobile/src/models/pulse_entry.dart';
import 'package:expense_stalker_mobile/src/config/app_constants.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/categories.dart';

import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/l10n/app_localizations.dart';
import 'package:expense_stalker_mobile/src/widgets/upsert_timeline_item/upsert_timeline_item_style.dart';

/// Bottom sheet for adding a quick standalone transaction.
///
/// Allows entering amount, label, date, category and income/expense toggle.
/// Returns a [PulseEntry] on save, or null if cancelled.
class QuickTransactionSheet extends StatefulWidget {
  const QuickTransactionSheet({super.key});

  @override
  State<QuickTransactionSheet> createState() => _QuickTransactionSheetState();
}

class _QuickTransactionSheetState extends State<QuickTransactionSheet> {
  late final TextEditingController _amountController;
  late final TextEditingController _labelController;
  late final TextEditingController _originController;
  late final TextEditingController _notesController;
  late DateTime _date;
  String? _selectedCategory;
  bool _isIncome = false;

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    _labelController = TextEditingController();
    _originController = TextEditingController();
    _notesController = TextEditingController();
    _date = DateTime.now();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _labelController.dispose();
    _originController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.9;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context);
    final settings = AppSettingsScope.read(context);
    final store = ExpenseStoreScope.read(context);

    // Use theme-aware colors from the palette
    final surface = colorScheme.surface;
    final surfaceContainer = colorScheme.surfaceContainerHigh;
    final textPrimary = colorScheme.onSurface;
    final textSecondary = colorScheme.onSurfaceVariant;

    // Use theme's debit/credit colors
    final accentColor = _isIncome
        ? settings.themeSettings.creditColor
        : settings.themeSettings.debitColor;

    final categories = getCategorySuggestions(
      isIncome: _isIncome,
      mode: settings.categoryPresetMode,
      userCategories: store.getUserCategories(isIncome: _isIncome),
    );

    return Container(
      decoration: BoxDecoration(
        color: surface,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppConstants.radiusSheetTop),
        ),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxHeight),
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 6, 16, 16 + bottomInset),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Text(
                  'Log Transaction',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: textPrimary,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),

                // Income/Expense Toggle
                Center(
                  child: SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                        value: false,
                        label: Text('Expense'),
                        icon: Icon(Icons.remove_circle_outline),
                      ),
                      ButtonSegment(
                        value: true,
                        label: Text('Income'),
                        icon: Icon(Icons.add_circle_outline),
                      ),
                    ],
                    selected: {_isIncome},
                    onSelectionChanged: (selected) {
                      setState(() {
                        _isIncome = selected.first;
                        _selectedCategory =
                            null; // Reset category when switching type
                      });
                    },
                    style: SegmentedButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      backgroundColor: Colors.transparent,
                      foregroundColor: colorScheme.onSurfaceVariant,
                      selectedBackgroundColor: colorScheme.primaryContainer,
                      selectedForegroundColor: colorScheme.onPrimaryContainer,
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Amount & Date Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Amount Field
                    Expanded(
                      flex: 1,
                      child: TextField(
                        controller: _amountController,
                        autofocus: true,
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: UpsertTimelineItemStyle.compactInput(
                          context,
                          'Amount',
                        ).copyWith(
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 12,
                          ),
                          prefixIcon: Padding(
                            padding: const EdgeInsets.only(
                              left: 12,
                              right: 4,
                            ),
                            child: Text(
                              _isIncome ? '+' : '−',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: accentColor,
                              ),
                            ),
                          ),
                          prefixIconConstraints: const BoxConstraints(
                            minWidth: 28,
                            minHeight: 0,
                          ),
                        ),
                        keyboardType: TextInputType.numberWithOptions(
                          signed: false,
                          decimal: settings.showCents,
                        ),
                        inputFormatters: [
                          if (settings.showCents)
                            FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d{0,2}'),
                            )
                          else
                            FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(
                            AppConstants.maxAmountLength,
                          ),
                        ],
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Date Picker
                    Expanded(
                      flex: 1,
                      child: InkWell(
                        onTap: _pickDate,
                        borderRadius: BorderRadius.circular(8),
                        child: InputDecorator(
                          decoration: UpsertTimelineItemStyle.compactInput(
                            context,
                            'Date',
                          ).copyWith(
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 12,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.calendar_today,
                                size: 16,
                                color: textSecondary,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  DateFormat.MMMd().format(_date),
                                  style: TextStyle(
                                    color: textPrimary,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Label
                TextField(
                  controller: _labelController,
                  style: TextStyle(color: textPrimary, fontSize: 14),
                  decoration: UpsertTimelineItemStyle.compactInput(
                    context,
                    'Label',
                    hintText: 'e.g., Starbucks, Rent',
                  ),
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 8),

                // Origin
                UpsertTimelineItemStyle.labeledField(
                  context: context,
                  label: 'Origin',
                  child: RawAutocomplete<String>(
                    textEditingController: _originController,
                    optionsBuilder: (TextEditingValue textEditingValue) {
                      // Get all unique origins from existing pulses (standalone or otherwise)
                      // This is a "quick add", so global suggestions make sense.
                      final allOrigins = store.pulses
                          .map((e) => e.origin)
                          .where((e) => e != null && e.isNotEmpty)
                          .cast<String>()
                          .toSet()
                          .toList();

                      if (textEditingValue.text.isEmpty) {
                        return const Iterable<String>.empty();
                      }
                      return allOrigins.where((option) {
                        return option.toLowerCase().contains(
                              textEditingValue.text.toLowerCase(),
                            );
                      });
                    },
                    onSelected: (String selection) {
                      _originController.text = selection;
                    },
                    fieldViewBuilder:
                        (context, controller, focusNode, onFieldSubmitted) {
                      return TextField(
                        controller: controller,
                        focusNode: focusNode,
                        style: TextStyle(color: textPrimary, fontSize: 13),
                        decoration: UpsertTimelineItemStyle.compactInput(
                          context,
                          'Origin (Optional)',
                          hintText: 'e.g., Netflix, Apple',
                          floatingLabel: false,
                        ),
                        textInputAction: TextInputAction.next,
                        onSubmitted: (_) => onFieldSubmitted(),
                      );
                    },
                    optionsViewBuilder: (context, onSelected, options) {
                      return Align(
                        alignment: Alignment.topLeft,
                        child: Material(
                          elevation: 8.0,
                          borderRadius: BorderRadius.circular(8),
                          color: surfaceContainer,
                          child: Container(
                            width: 250, // Slightly wider
                            constraints: const BoxConstraints(maxHeight: 200),
                            child: ListView.builder(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              shrinkWrap: true,
                              itemCount: options.length,
                              itemBuilder: (BuildContext context, int index) {
                                final option = options.elementAt(index);
                                return InkWell(
                                  onTap: () => onSelected(option),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 8,
                                    ),
                                    child: Text(
                                      option,
                                      style: TextStyle(
                                        color: textPrimary,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),

                // Category Dropdown
                DropdownButtonFormField<String?>(
                  initialValue: _selectedCategory,
                  decoration: UpsertTimelineItemStyle.compactInput(
                    context,
                    'Category',
                  ),
                  items: [
                    const DropdownMenuItem<String?>(
                      value: null,
                      child: Text('Uncategorized'),
                    ),
                    ...categories.map(
                      (cat) => DropdownMenuItem<String?>(
                        value: cat,
                        child: Text(cat),
                      ),
                    ),
                  ],
                  onChanged: (value) =>
                      setState(() => _selectedCategory = value),
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  dropdownColor: surfaceContainer,
                ),
                const SizedBox(height: 8),

                // Notes
                TextField(
                  controller: _notesController,
                  style: TextStyle(color: textPrimary, fontSize: 13),
                  decoration: UpsertTimelineItemStyle.compactInput(
                    context,
                    'Notes (Optional)',
                    hintText: 'Add extra details...',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 24),

                // Save Button
                FilledButton(
                  onPressed: _handleSave,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusButton,
                      ),
                    ),
                  ),
                  child: Text(
                    l10n?.save ?? 'Save',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(
        () => _date = DateTime(
          picked.year,
          picked.month,
          picked.day,
          _date.hour,
          _date.minute,
          _date.second,
          _date.millisecond,
          _date.microsecond,
        ),
      );
    }
  }

  void _handleSave() {
    final label = _labelController.text.trim();
    if (label.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Please enter a label')));
      return;
    }

    final rawAmountCents = tryParseMoneyToCents(_amountController.text);
    if (rawAmountCents == null || rawAmountCents == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount')),
      );
      return;
    }

    final settings = AppSettingsScope.read(context);
    final finalAmountCents = roundUpToIncrement(
      rawAmountCents,
      settings.roundingIncrement * 100,
    );

    final signedAmountCents = _isIncome ? finalAmountCents : -finalAmountCents;

    final entry = PulseEntry(
      id: newEntryId(),
      label: label,
      amountMinorUnits: signedAmountCents,
      date: _date,
      type: _isIncome ? PulseType.oneOffIncome : PulseType.oneOff,
      category: _selectedCategory,
      origin: _originController.text.trim().isEmpty
          ? null
          : _originController.text.trim(),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      timelineItemId: null, // Standalone!
    );

    Navigator.pop(context, entry);
  }
}
