import 'dart:math';
import 'package:flutter/material.dart';

class SparklineChart extends StatelessWidget {
  const SparklineChart({
    super.key,
    required this.values,
    required this.creditColor,
    required this.debitColor,
    this.labels = const [],
  });

  final List<num> values;
  final List<String> labels;
  final Color creditColor;
  final Color debitColor;

  // Approximate width per data point to allow comfortable reading
  static const double _pointWidth = 50.0;

  @override
  Widget build(BuildContext context) {
    // If no values, show empty
    if (values.isEmpty) return const SizedBox.expand();

    // Calculate required width
    final totalWidth = values.length * _pointWidth;

    // We want the chart to fill screen width at minimum, but scroll if larger
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: totalWidth < MediaQuery.of(context).size.width
            ? MediaQuery.of(context).size.width
            : totalWidth,
        child: CustomPaint(
          size: Size.infinite,
          painter: SparklinePainter(
            values: values,
            labels: labels,
            creditColor: creditColor,
            debitColor: debitColor,
          ),
        ),
      ),
    );
  }
}

class SparklinePainter extends CustomPainter {
  SparklinePainter({
    required this.values,
    required this.labels,
    required this.creditColor,
    required this.debitColor,
  });

  final List<num> values;
  final List<String> labels;
  final Color creditColor;
  final Color debitColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;

    final padding = 16.0;
    final bottomLabelHeight = 20.0;
    final chartWidth = size.width - (padding * 2);
    final chartHeight = size.height - (padding * 2) - bottomLabelHeight;

    // Find min/max for scaling
    final maxValue = values.reduce((a, b) => a > b ? a : b);
    final minValue = values.reduce((a, b) => a < b ? a : b);
    final range = (maxValue - minValue).toDouble();
    final range0 = range == 0 ? 1 : range; // Prevent division by zero

    // Draw Zero Line if visible (separate from milestones)
    if (minValue <= 0 && maxValue >= 0) {
      final zeroY =
          padding + chartHeight - (chartHeight * ((0 - minValue) / range0));
      final zeroLinePaint = Paint()
        ..color = Colors.grey.withValues(alpha: 0.5)
        ..strokeWidth = 1;
      canvas.drawLine(
        Offset(padding, zeroY),
        Offset(size.width - padding, zeroY),
        zeroLinePaint,
      );
    }

    // Calculate dynamic Y-axis divisions based on actual data range
    // We want 4-5 nicely spaced divisions
    final divisions = _calculateYAxisDivisions(
      minValue.toDouble(),
      maxValue.toDouble(),
    );

    final milestonePaint = Paint()
      ..color = Colors.grey.withValues(alpha: 0.2)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    final milestoneTextPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.left,
    );

    for (final divisionValue in divisions) {
      if (divisionValue > minValue && divisionValue < maxValue) {
        final normalizedM = (divisionValue - minValue) / range0;
        final mY = padding + chartHeight - (chartHeight * normalizedM);

        // Draw dashed line
        final dashWidth = 4.0;
        final dashSpace = 4.0;
        double startX = padding;
        while (startX < size.width - padding) {
          canvas.drawLine(
            Offset(startX, mY),
            Offset(startX + dashWidth, mY),
            milestonePaint,
          );
          startX += dashWidth + dashSpace;
        }

        // Draw Label (values are in cents, so divide by 100)
        final labelText = _formatAxisLabel(divisionValue);

        milestoneTextPainter.text = TextSpan(
          text: labelText,
          style: TextStyle(
            color: Colors.grey.withValues(alpha: 0.5),
            fontSize: 9,
            fontWeight: FontWeight.bold,
          ),
        );
        milestoneTextPainter.layout();
        milestoneTextPainter.paint(
          canvas,
          Offset(padding + 2, mY - milestoneTextPainter.height - 2),
        );
      }
    }

    // Build path for the sparkline
    final path = Path();
    final points = <Offset>[];

    for (int i = 0; i < values.length; i++) {
      final x = padding + (chartWidth * i / (values.length - 1));
      final normalizedValue = (values[i] - minValue) / range0;
      final y = padding + chartHeight - (chartHeight * normalizedValue);
      points.add(Offset(x, y));
    }

    if (points.isNotEmpty) {
      path.moveTo(points[0].dx, points[0].dy);
      for (int i = 1; i < points.length; i++) {
        // Smooth curve using quadratic bezier
        final prevPoint = points[i - 1];
        final curPoint = points[i];
        final controlPoint = Offset(
          (prevPoint.dx + curPoint.dx) / 2,
          (prevPoint.dy + curPoint.dy) / 2,
        );
        path.quadraticBezierTo(
          controlPoint.dx,
          controlPoint.dy,
          curPoint.dx,
          curPoint.dy,
        );
      }
    }

    // Draw line
    final linePaint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.7)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    canvas.drawPath(path, linePaint);

    // Draw filled area under line
    final fillPath = Path.from(path);
    fillPath.lineTo(points.last.dx, padding + chartHeight);
    fillPath.lineTo(points.first.dx, padding + chartHeight);
    fillPath.close();

    final fillPaint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.1)
      ..style = PaintingStyle.fill;

    canvas.drawPath(fillPath, fillPaint);

    // Draw X-Axis Line
    final axisPaint = Paint()
      ..color = Colors.grey.withValues(alpha: 0.5)
      ..strokeWidth = 1;
    canvas.drawLine(
      Offset(padding, padding + chartHeight),
      Offset(size.width - padding, padding + chartHeight),
      axisPaint,
    );

    // Draw points and Labels
    final pointPaint = Paint()
      ..color = Colors.blue
      ..strokeWidth = 1;

    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );

    for (int i = 0; i < points.length; i++) {
      final point = points[i];
      canvas.drawCircle(point, 3, pointPaint);

      // Draw Label
      if (i < labels.length) {
        textPainter.text = TextSpan(
          text: labels[i],
          style: TextStyle(
            color: Colors.grey.withValues(alpha: 0.8),
            fontSize: 10,
          ),
        );
        textPainter.layout();
        // Center text below point, at the bottom area
        final textX = point.dx - (textPainter.width / 2);
        final textY = size.height - bottomLabelHeight + 4; // Add some padding
        textPainter.paint(canvas, Offset(textX, textY));
      }
    }

    // Draw min/max points with different colors
    if (points.isNotEmpty) {
      final minIndex = values.indexOf(minValue);
      final maxIndex = values.indexOf(maxValue);

      if (minIndex >= 0) {
        canvas.drawCircle(
          points[minIndex],
          4,
          Paint()
            ..color = debitColor
            ..strokeWidth = 2
            ..style = PaintingStyle.stroke,
        );
      }

      if (maxIndex >= 0) {
        canvas.drawCircle(
          points[maxIndex],
          4,
          Paint()
            ..color = creditColor
            ..strokeWidth = 2
            ..style = PaintingStyle.stroke,
        );
      }
    }
  }

  @override
  bool shouldRepaint(SparklinePainter oldDelegate) {
    return oldDelegate.values != values ||
        oldDelegate.labels != labels ||
        oldDelegate.creditColor != creditColor ||
        oldDelegate.debitColor != debitColor;
  }

  /// Calculate evenly-spaced Y-axis divisions based on the data range.
  /// Returns a list of values (in cents) where divisions should be drawn.
  List<double> _calculateYAxisDivisions(double minValue, double maxValue) {
    final range = maxValue - minValue;
    if (range == 0) return [];

    // Target 4-5 divisions
    const targetDivisions = 5;

    // Calculate raw step size
    final rawStep = range / targetDivisions;

    // Find a "nice" step size (1, 2, 2.5, or 5 × 10^n)
    final magnitude = _magnitude(rawStep);
    final normalizedStep = rawStep / magnitude;

    double niceStep;
    if (normalizedStep <= 1) {
      niceStep = 1;
    } else if (normalizedStep <= 2) {
      niceStep = 2;
    } else if (normalizedStep <= 2.5) {
      niceStep = 2.5;
    } else if (normalizedStep <= 5) {
      niceStep = 5;
    } else {
      niceStep = 10;
    }

    final step = niceStep * magnitude;

    // Generate divisions starting from a "nice" value
    final start = (minValue / step).floor() * step;
    final divisions = <double>[];

    var current = start;
    while (current <= maxValue) {
      if (current > minValue) {
        divisions.add(current);
      }
      current += step;
    }

    return divisions;
  }

  /// Get the magnitude (power of 10) of a number
  double _magnitude(double value) {
    if (value == 0) return 1;
    final absValue = value.abs();
    final logValue = (log(absValue) / ln10).floor();
    return _pow10(logValue);
  }

  /// Calculate 10^n
  double _pow10(int n) {
    if (n >= 0) {
      double result = 1;
      for (int i = 0; i < n; i++) {
        result *= 10;
      }
      return result;
    } else {
      double result = 1;
      for (int i = 0; i > n; i--) {
        result /= 10;
      }
      return result;
    }
  }

  /// Format a Y-axis label value (in cents) to a readable string
  String _formatAxisLabel(double value) {
    // Convert from cents to dollars
    final dollars = value / 100;
    final absValue = dollars.abs();

    String formatted;
    if (absValue >= 1000000) {
      formatted =
          '${(dollars / 1000000).toStringAsFixed(absValue >= 10000000 ? 0 : 1)}M';
    } else if (absValue >= 1000) {
      formatted =
          '${(dollars / 1000).toStringAsFixed(absValue >= 10000 ? 0 : 1)}k';
    } else {
      formatted = dollars.toStringAsFixed(0);
    }

    return formatted;
  }
}
