import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:expense_stalker_mobile/src/state/expense_store.dart';
import 'package:expense_stalker_mobile/src/features/accounts/accounts_screen.dart';
import 'package:expense_stalker_mobile/src/util/ids.dart';
import 'package:expense_stalker_mobile/src/util/account_icons.dart';

class AccountSelector extends StatelessWidget {
  const AccountSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final store = ExpenseStoreScope.of(context);
    final accounts = store.accounts;
    final currentAccount = store.currentAccount;
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: PopupMenuButton<String>(
        tooltip: 'Switch Account',
        offset: const Offset(0, 48),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (currentAccount.isTestData)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: PhosphorIcon(
                    PhosphorIcons.flask(),
                    size: 16,
                    color: theme.colorScheme.secondary,
                  ),
                ),
              Flexible(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (!currentAccount.isTestData)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Icon(
                          AccountIcons.getIcon(
                            currentAccount.iconCodePoint,
                            isTestData: currentAccount.isTestData,
                          ),
                          size: 18,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    Flexible(
                      child: Text(
                        currentAccount.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              PhosphorIcon(
                PhosphorIcons.caretDown(),
                color: theme.colorScheme.primary,
                size: 18,
              ),
            ],
          ),
        ),
        itemBuilder: (context) {
          final items = <PopupMenuEntry<String>>[];

          // Add account switching options
          for (final account in accounts) {
            items.add(
              CheckedPopupMenuItem<String>(
                value: account.id,
                checked: account.id == currentAccount.id,
                child: Row(
                  children: [
                    if (account.isTestData)
                      if (account.isTestData)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: Icon(
                            AccountIcons.getIcon(
                              account.iconCodePoint,
                              isTestData: account.isTestData,
                            ),
                            size: 16,
                            color: theme.colorScheme.secondary,
                          ),
                        ),
                    if (!account.isTestData)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: Icon(
                          AccountIcons.getIcon(
                            account.iconCodePoint,
                            isTestData: account.isTestData,
                          ),
                          size: 16,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    Expanded(
                      child: Text(
                        account.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          // Add divider and manage accounts option
          items.add(const PopupMenuDivider());
          items.add(
            PopupMenuItem<String>(
              value: '_manage_accounts',
              child: Row(
                children: [
                  PhosphorIcon(
                    PhosphorIcons.gear(),
                    size: 20,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 12),
                  const Text('Manage Accounts'),
                ],
              ),
            ),
          );

          return items;
        },
        onSelected: (value) {
          if (value == '_manage_accounts') {
            Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const AccountsScreen()));
          } else {
            store.switchAccount(AccountId(value));
          }
        },
      ),
    );
  }
}
