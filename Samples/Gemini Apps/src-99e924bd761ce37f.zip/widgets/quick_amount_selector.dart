import 'package:flutter/material.dart';
import 'package:expense_stalker_mobile/src/util/money.dart';
import 'package:expense_stalker_mobile/src/state/app_settings_store.dart';

class QuickAmountSelector extends StatelessWidget {
  const QuickAmountSelector({
    super.key,
    required this.amounts,
    required this.onAmountSelected,
  });

  final List<int> amounts;
  final ValueChanged<int> onAmountSelected;

  @override
  Widget build(BuildContext context) {
    if (amounts.isEmpty) return const SizedBox.shrink();

    // Split amounts into two rows for 6 items (or any even number)
    final midpoint = (amounts.length / 2).ceil();
    final firstRow = amounts.take(midpoint).toList();
    final secondRow = amounts.skip(midpoint).toList();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainer,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: firstRow.map((amount) {
              return _AmountBubble(
                amountCents: amount,
                onTap: () => onAmountSelected(amount),
              );
            }).toList(),
          ),
          if (secondRow.isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: secondRow.map((amount) {
                return _AmountBubble(
                  amountCents: amount,
                  onTap: () => onAmountSelected(amount),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }
}

class _AmountBubble extends StatelessWidget {
  const _AmountBubble({required this.amountCents, required this.onTap});

  final int amountCents;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final settings = AppSettingsScope.read(context);
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final formattedAmount = formatMoney(
      amountCents,
      settings.currency,
      showDecimals:
          false, // Usually quick amounts are round numbers like $10, not $10.00
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(50),
        child: Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            color: colorScheme.primaryContainer,
            shape: BoxShape.circle,
            border: Border.all(
              color: colorScheme.primary.withValues(alpha: 0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: colorScheme.primary.withValues(alpha: 0.15),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            formattedAmount,
            style: theme.textTheme.titleMedium?.copyWith(
              color: colorScheme.onPrimaryContainer,
              fontWeight: FontWeight.bold,
              fontSize:
                  formattedAmount.length > 3 ? 14 : 16, // Scale down if long
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
